use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Laghachi `true` ma ọ bụrụ na pointer enweghị isi.
    ///
    /// Rịba ama na ụdị ndị a na-ejighị n'aka nwere ọtụtụ ihe null nwere ike, ebe ọ bụ naanị pointer pointer na-atụle, ọ bụghị ogologo ha, vtable, wdg.
    /// Ya mere, ntụaka abụọ na-enweghị isi ka nwere ike ha agaghị aha nhata.
    ///
    /// ## Àgwà n'oge const nwale
    ///
    /// Mgbe ejiri ọrụ a n'oge nyocha, ọ nwere ike ịlaghachi `false` maka akara ngosi nke na-abaghị uru na oge.
    /// Kpọmkwem, mgbe a pointer ka ụfọdụ ebe nchekwa na-dechapụ n'ofè ya ókè n'ụzọ dị otú ahụ na dapụtara pointer bụ null, ọrụ ka ga na-alọghachi `false`.
    ///
    /// E nweghị ụzọ ka CTFE mara zuru ọnọdụ nke na ebe nchekwa, anyị enweghị ike ịgwa ma ọ bụrụ na pointer bụ null ma ọ bụ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Tụlee site na nkedo na pointer dị mkpa, yabụ ndị na-egosi abụba na-atụle akụkụ "data" ha maka null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Nkedo onye na-egosi ụdị ọzọ.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Decompose pointer (ikekwe n'obosara) n'ime adreesị na metadata.
    ///
    /// Enwere ike ịmegharị pointer na [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Alaghachi `None` ma ọ bụrụ na ndị pointer bụ null, ma ọ bụ ọzọ alaghachi a na-akọrọ banyere uru ọbọp ke `Some`.Ọ bụrụ na uru nwere ike uninitialized, [`as_uninit_ref`] ga-eji kama.
    ///
    /// Maka onye na-agbanwe agbanwe lee [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na *ma pointer ahụ bụ NULL* ma ọ bụ * ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Ntuziaka ga-atụ aka n'ihe atụ nke `T`.
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa a na-atụ aka ka a ghara ịgbanwe (ma e wezụga n'ime `UnsafeCell`).
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    /// (The akụkụ banyere ịbụ initialized bụ ma n'ụzọ zuru ezu kpebiri, ma ruo mgbe ọ bụ, nanị mma obibia bụ iji hụ na ha na-n'ezie initialized.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Ulldị a na-elegharaghị anya
    ///
    /// Ọ bụrụ na ị kwenyesiri ike na pointer enweghị ike ịbụ ihe efu ma na-achọ ụdị `as_ref_unchecked` nke na-eweghachi `&T` kama `Option<&T>`, mara na ị nwere ike idebanye pointer ahụ ozugbo.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // NCHEKWA: nke bere kwesịrị nkwa na `self` bụ irè n'ihi na a
        // zoo ma ọ bụrụ na ọ bụghị null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Laghachite `None` ma ọ bụrụ na pointer adịghị mma, ma ọ bụ na ọ ga-alaghachi otu akara aka na uru ejiri na `Some`.
    /// N'adịghị ka [`as_ref`], nke a achọghị ka amalite ụkpụrụ ahụ.
    ///
    /// Maka onye na-agbanwe agbanwe lee [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na *ma pointer ahụ bụ NULL* ma ọ bụ * ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa a na-atụ aka ka a ghara ịgbanwe (ma e wezụga n'ime `UnsafeCell`).
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka akwụkwọ.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Na-agụta ihe depụtara site na pointer.
    ///
    /// `count` dị na nkeji nke T;ịmaatụ, `count` nke 3 na-anọchite anya nrụpụta pointer nke `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ọ bụrụ na e mebie nke ọ bụla n'ọnọdụ ndị a, nsonaazụ ya bụ Àgwà Akọwapụtaghị Ya:
    ///
    /// * Ma pointer na-ebute ma na-ebute ga-abụrịrị oke oke ma ọ bụ otu byte gafere na njedebe nke otu ihe ahụ ekenyeworo.
    /// Rịba ama na na Rust, a na-ewere mgbanwe (stack-allocated) ọ bụla dị ka ihe dị iche iche ekenyela.
    ///
    /// * Mgbakọ agbakọ,**na bytes**, enweghị ike ịbubata `isize`.
    ///
    /// * Mmebi ahụ ịbụ oke nwere ike ịdabere na "wrapping around" oghere adreesị.Nke ahụ bụ, ngwụcha ngwụcha ngwụcha,**na bytes** ga-adaba na ya.
    ///
    /// The compiler na ọkọlọtọ ọba akwụkwọ n'ozuzu na-agba mbọ iji hụ na oke mgbe iru a size ebe offset bụ nchegbu.
    /// Ihe atụ, `Vec` na `Box` hụ ha mgbe igbunye karịa `isize::MAX` bytes, otú `vec.as_ptr().add(vec.len())` bụ mgbe mma.
    ///
    /// Imirikiti nyiwe na-enweghị ike ịrụ ụdị oke a.
    /// Dịka ọmụmaatụ, enweghị ebe 64-bit a ma ama nwere ike inye arịrịọ maka 2 <sup>63</sup> bytes n'ihi njedebe tebụl ma ọ bụ kewaa oghere adreesị.
    /// Agbanyeghị, ụfọdụ nyiwe 32-bit na 16-bit nwere ike rụọ ọrụ nke ọma maka arịrịọ maka ihe karịrị `isize::MAX` bytes na ihe dịka Mgbatị Ahụ Ahụ.
    ///
    /// Ka o siri dị, ebe nchekwa sitere na ndị na-ekenye ihe ma ọ bụ faịlụ ndị edobeere nchekwa * nwere ike ibu oke ibu iji rụọ ọrụ a.
    ///
    /// Tụlee iji [`wrapping_offset`] kama ọ bụrụ na mgbochi ndị a siri ike afọ ojuju.
    /// Nanị uru nke usoro a bụ na ọ na-eme ka njikarịcha nchịkọta ihe ike dị ike.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `offset`.
        // Ihe enwetara na pointer dị mma maka ederede ebe ọ bụ na onye na-akpọ oku ga-ekwenye na ọ na-atụ aka n'otu ihe ahụ ekenyela dị ka `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Na-agukọta mbibi site na pointer site na iji mpịakọta akpakọrịta.
    /// `count` dị na nkeji nke T;ịmaatụ, `count` nke 3 na-anọchite anya nrụpụta pointer nke `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ọrụ a n'onwe ya na-adị mma mgbe niile, mana iji pointer rụpụtara adịghị.
    ///
    /// Ihe pointer rụpụtara na-adịgide n'otu ihe ahụ ekenyela `self` na-atụ aka.
    /// Enwere ike * ejighi ya iji nweta ihe ekenyela iche.Rịba ama na na Rust, a na-ewere mgbanwe (stack-allocated) ọ bụla dị ka ihe dị iche iche ekenyela.
    ///
    /// Ndị ọzọ okwu, `let z = x.wrapping_offset((y as isize) - (x as isize))` eme *bụghị* anam `z` otu `y` ọbụna ma ọ bụrụ na anyị iche `T` nwere size `1` na ọ dịghị ejupụta: `z` ka na-mmasị ka ihe `x` bụ mmasị, na dereferencing ọ bụ Undefined Àgwà ma `x` na `y` na-abanye n'otu ihe ahụ ekenyela.
    ///
    /// E jiri ya tụnyere [`offset`], usoro a na-egbu oge oge achọrọ ka ị nọrọ n'otu ihe ahụ ekenyepụtara: [`offset`] bụ Àgwà A Na-akọwaghị ozugbo mgbe ọ na-agafe oke ihe;`wrapping_offset` arụpụta a pointer ma ka na-eduga Undefined Àgwà ma ọ bụrụ na a pointer na-dereferenced mgbe ọ bụ nke na-ókè nke ihe ọ na-mmasị na.
    /// [`offset`] enwere ike kachasị mma ma bụrụ nke kachasị mma na koodu nwere arụmọrụ.
    ///
    /// Oge nyocha a na-egbu oge na-eche naanị uru nke pointer ahụ edepụtara, ọ bụghị ụkpụrụ dị n'etiti ejiri mee ihe n'oge ngụkọta nsonaazụ ikpeazụ.
    /// Ka ihe atụ, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` bụ mgbe otu dị ka `x`.Yabụ, ịhapụ ekenyela ihe wee banye ọzọ na-emecha kwere.
    ///
    /// Ọ bụrụ na ị chọrọ ka cross ihe ókè, tubà pointer na integer na-eme som e.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // Ghichaa iji pointer raw na ntinye nke ihe abuo
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: `arith_offset` intrinsic enweghị ihe ndị achọrọ iji kpọọ.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Alaghachi `None` ma ọ bụrụ na ndị pointer bụ null, ma ọ bụ ọzọ alaghachi a pụrụ iche banyere uru ọbọp ke `Some`.Ọ bụrụ na uru ahụ nwere ike ghara ịmatacha, a ga-eji [`as_uninit_mut`] mee ihe.
    ///
    /// Maka onye ịkọkọrịta ọnụ hụrụ [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na *ma pointer ahụ bụ NULL* ma ọ bụ * ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Ntuziaka ga-atụ aka n'ihe atụ nke `T`.
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa pointer na-atụ aka agaghị enweta (ịgụ ma ọ bụ dee) site na pointer ọ bụla ọzọ.
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    /// (The akụkụ banyere ịbụ initialized bụ ma n'ụzọ zuru ezu kpebiri, ma ruo mgbe ọ bụ, nanị mma obibia bụ iji hụ na ha na-n'ezie initialized.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ọ ga-ebipụta: "[4, 2, 3]".
    /// ```
    ///
    /// # Ulldị a na-elegharaghị anya
    ///
    /// Ọ bụrụ na ị na-n'aka na pointer apughi null ma na-achọ ụdị ụfọdụ nke `as_mut_unchecked` na-alaghachikwuru onye `&mut T` kama `Option<&mut T>`, mara na i nwere ike dereference na pointer ozugbo.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ọ ga-ebipụta: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // NCHEKWA: nke bere kwesịrị nkwa na `self` bụ-nti maka
        // ntụgharị ma ọ bụrụ na ọ baghị.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Weghachite `None` ma ọ bụrụ na pointer adịghị arụ ọrụ, ma ọ bụ na ọ ga-eweghachi akara pụrụ iche banyere uru ejiri na `Some`.
    /// N'ụzọ dị iche na [`as_mut`], a na-adịghị achọ na uru nwere na-initialized.
    ///
    /// N'ihi na Amalite Ijekọ counterpart ahụ [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na *ma pointer ahụ bụ NULL* ma ọ bụ * ihe ndị a niile bụ eziokwu:
    ///
    /// * Ekwesịrị ịkọwa pointer n'ụzọ ziri ezi.
    ///
    /// * Ọ ga-abụ "dereferencable" n'echiche akọwapụtara na [the module documentation].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa pointer na-atụ aka agaghị enweta (ịgụ ma ọ bụ dee) site na pointer ọ bụla ọzọ.
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-ekwenye na `self` na-ezute ihe niile
        // chọrọ maka akwụkwọ.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Alaghachite ma akara aka abụọ ga-aha nhatanha.
    ///
    /// N'oge ọrụ a na-akpa àgwà dị ka `self == other`.
    /// Agbanyeghị, n'ọnọdụ ụfọdụ (dịka, nyocha oge), ọ naghị ekwe omume mgbe niile ịchọpụta nha anya nke ntụzi aka abụọ, yabụ ọrụ a nwere ike iji nwayọ laghachi `false` maka akara aka nke mechara bụrụ nhata.
    ///
    /// Ma mgbe ọ laghachiri `true`, a na-ekwe nkwa ihe nha nha.
    ///
    /// Ọrụ a bụ enyo nke [`guaranteed_ne`], mana ọ bụghị ntụgharị ya.E nwere pointer atụnyere nke ma ọrụ laghachi `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Nloghachi uru nwere ike ịgbanwe dabere na compiler version na nwedịrị ike ịta koodu nwere ike ghara ịdabere na nsonaazụ nke ọrụ a maka ụda.
    /// A na-atụ aro ka ị jiri ọrụ a naanị maka njikarịcha arụmọrụ ebe ụkpụrụ azụghachi `false` site na ọrụ a anaghị emetụta nsonaazụ ya, kama ọ bụ naanị arụmọrụ ahụ.
    /// Nsonaazụ nke iji usoro a iji mee ka oge ezumike ma chịkọta oge na-akpa àgwà dị iche iche achọpụtabeghị.
    /// Ekwesighi iji usoro a ewebata ndiiche di otu a, ma o kwesịghị ka ọ kwụsie ike tupu anyị enwee nghọta ka mma banyere okwu a.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Alaghachi ma abụọ pointers na-ekwe nkwa na-ahaghị nhata.
    ///
    /// N'oge ọrụ a na-akpa àgwà dị ka `self != other`.
    /// Agbanyeghị, n'ọnọdụ ụfọdụ (dịka, nyocha oge), ọ gaghị ekwe omume mgbe niile ịchọpụta ahaghị nhata nke isi ihe abụọ, yabụ na ọrụ a nwere ike iji XR `false` laghachi azụ maka ihe nrịba ama nke mechara bụrụ enweghị nha.
    ///
    /// Ma mgbe ọ laghachiri `true`, a na-ekwe nkwa ntụpọ ahụ ahaghị nha.
    ///
    /// Ọrụ a bụ enyo nke [`guaranteed_eq`], mana ọ bụghị ntụgharị ya.E nwere njiri mara aka nke ọrụ abụọ na-alaghachi `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Nloghachi uru nwere ike ịgbanwe dabere na compiler version na nwedịrị ike ịta koodu nwere ike ghara ịdabere na nsonaazụ nke ọrụ a maka ụda.
    /// A na-atụ aro ka ị jiri ọrụ a naanị maka njikarịcha arụmọrụ ebe ụkpụrụ azụghachi `false` site na ọrụ a anaghị emetụta nsonaazụ ya, kama ọ bụ naanị arụmọrụ ahụ.
    /// Nsonaazụ nke iji usoro a iji mee ka oge ezumike ma chịkọta oge na-akpa àgwà dị iche iche achọpụtabeghị.
    /// Ekwesighi iji usoro a ewebata ndiiche di otu a, ma o kwesịghị ka ọ kwụsie ike tupu anyị enwee nghọta ka mma banyere okwu a.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Na-agụta ebe dị n'etiti etiti abụọ.Egoghachiri azụ dị na nkeji nke T: ebe dị anya site na bytes na-ekewa `mem::size_of::<T>()`.
    ///
    /// Ọrụ a bụ inverse nke [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Ọ bụrụ na e mebie nke ọ bụla n'ọnọdụ ndị a, nsonaazụ ya bụ Àgwà Akọwapụtaghị Ya:
    ///
    /// * Ma mbido na pointer ọzọ ga-abụrịrị oke oke ma ọ bụ otu byte gara aga na njedebe nke otu ekenyela ihe.
    /// Rịba ama na na Rust, a na-ewere mgbanwe (stack-allocated) ọ bụla dị ka ihe dị iche iche ekenyela.
    ///
    /// * Ma pointers ga-*ewepụtara* a pointer na otu ihe.
    ///   (Lee n'okpuru maka otu ihe atụ.)
    ///
    /// * Ebe dị anya n`etiti ihe atụ, na bytes, ga-abụrịrị otu agba gbara ọkpụrụkpụ nke nke `T`.
    ///
    /// * The anya n'etiti pointers,**na bytes**, ike erubiga ihe `isize`.
    ///
    /// * Ebe dị anya ịnọ n'ofe enweghị ike ịdabere na "wrapping around" oghere adreesị.
    ///
    /// Dị Rust adịghịkarị karịa `isize::MAX` na ekenye Rust anaghị agbakọta gburugburu adreesị ahụ, yabụ ihe nrịba ama abụọ dị na ụfọdụ ụdị Rust ụdị `T` ga-emeju afọ abụọ gara aga.
    ///
    /// Ọbá akwụkwọ ọkọlọtọ na-ahụkarị na nhọpụta anaghị eru nha ebe njedebe bụ nchegbu.
    /// Ihe atụ, `Vec` na `Box` hụ ha mgbe igbunye karịa `isize::MAX` bytes, otú `ptr_into_vec.offset_from(vec.as_ptr())` mgbe afọ abụọ gara ọnọdụ.
    ///
    /// Imirikiti nyiwe na-enweghị ike ịrụ nnukwu oke.
    /// Dịka ọmụmaatụ, enweghị ebe 64-bit a ma ama nwere ike inye arịrịọ maka 2 <sup>63</sup> bytes n'ihi njedebe tebụl ma ọ bụ kewaa oghere adreesị.
    /// Agbanyeghị, ụfọdụ nyiwe 32-bit na 16-bit nwere ike rụọ ọrụ nke ọma maka arịrịọ maka ihe karịrị `isize::MAX` bytes na ihe dịka Mgbatị Ahụ Ahụ.
    /// Ka o siri dị, ebe nchekwa sitere na ndị na-ekenye ihe ma ọ bụ faịlụ ndị edobeere nchekwa * nwere ike ibu oke ibu iji rụọ ọrụ a.
    /// (Rịba ama na [`offset`] na [`add`] nwekwara oke mmachi ma yabụ enweghị ike iji ya rụọ ọrụ ndị dị otú ahụ.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Nke a ọrụ panics ma ọ bụrụ na `T` bụ a Zero-sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// * Ejiji na-ezighi ezi:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Mee ptr2_other bụ "alias" nke ptr2, mana esitere na ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ebe ọ bụ na ptr2_other na ptr2 na-ewepụtara pointers dị iche iche ihe, Mgbakọ ha dechapụ na-undefined omume, n'agbanyeghị na ha na-ezo aka n'otu adreesị!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Undefined Àgwà
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Na-agụta deeti site na pointer (mma maka `.offset(count as isize)`).
    ///
    /// `count` dị na nkeji nke T;ịmaatụ, `count` nke 3 na-anọchite anya nrụpụta pointer nke `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ọ bụrụ na e mebie nke ọ bụla n'ọnọdụ ndị a, nsonaazụ ya bụ Àgwà Akọwapụtaghị Ya:
    ///
    /// * Ma pointer na-ebute ma na-ebute ga-abụrịrị oke oke ma ọ bụ otu byte gafere na njedebe nke otu ihe ahụ ekenyeworo.
    /// Rịba ama na na Rust, a na-ewere mgbanwe (stack-allocated) ọ bụla dị ka ihe dị iche iche ekenyela.
    ///
    /// * Mgbakọ agbakọ,**na bytes**, enweghị ike ịbubata `isize`.
    ///
    /// * Dechapụ ịnọ na-ókè ike ịdabere na "wrapping around" adreesị ohere.Nke ahụ bụ, nchịkọta na-enweghị ngwụcha ga-adaba na `usize`.
    ///
    /// The compiler na ọkọlọtọ ọba akwụkwọ n'ozuzu na-agba mbọ iji hụ na oke mgbe iru a size ebe offset bụ nchegbu.
    /// Ihe atụ, `Vec` na `Box` hụ ha mgbe igbunye karịa `isize::MAX` bytes, otú `vec.as_ptr().add(vec.len())` bụ mgbe mma.
    ///
    /// Imirikiti nyiwe na-enweghị ike ịrụ ụdị oke a.
    /// Dịka ọmụmaatụ, enweghị ebe 64-bit a ma ama nwere ike inye arịrịọ maka 2 <sup>63</sup> bytes n'ihi njedebe tebụl ma ọ bụ kewaa oghere adreesị.
    /// Agbanyeghị, ụfọdụ nyiwe 32-bit na 16-bit nwere ike rụọ ọrụ nke ọma maka arịrịọ maka ihe karịrị `isize::MAX` bytes na ihe dịka Mgbatị Ahụ Ahụ.
    ///
    /// Ka o siri dị, ebe nchekwa sitere na ndị na-ekenye ihe ma ọ bụ faịlụ ndị edobeere nchekwa * nwere ike ibu oke ibu iji rụọ ọrụ a.
    ///
    /// Tụlee iji [`wrapping_add`] kama ọ bụrụ na mgbochi ndị a siri ike afọ ojuju.
    /// Nanị uru nke usoro a bụ na ọ na-eme ka njikarịcha nchịkọta ihe ike dị ike.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Wepụtara dechapụ si a pointer (mma maka '.offset ((gua dị isize).wrapping_neg())`).
    ///
    /// `count` dị na nkeji nke T;ịmaatụ, `count` nke 3 na-anọchite anya nrụpụta pointer nke `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ọ bụrụ na e mebie nke ọ bụla n'ọnọdụ ndị a, nsonaazụ ya bụ Àgwà Akọwapụtaghị Ya:
    ///
    /// * Ma pointer na-ebute ma na-ebute ga-abụrịrị oke oke ma ọ bụ otu byte gafere na njedebe nke otu ihe ahụ ekenyeworo.
    /// Rịba ama na na Rust, a na-ewere mgbanwe (stack-allocated) ọ bụla dị ka ihe dị iche iche ekenyela.
    ///
    /// * Ihe mgbako agbako agbako enweghi ike igafe `isize::MAX`**bytes**.
    ///
    /// * Mmebi ahụ ịbụ oke nwere ike ịdabere na "wrapping around" oghere adreesị.Nke ahụ bụ, enweghi ngwụcha-nkenke nchikota ga dabara na a usize.
    ///
    /// The compiler na ọkọlọtọ ọba akwụkwọ n'ozuzu na-agba mbọ iji hụ na oke mgbe iru a size ebe offset bụ nchegbu.
    /// Ihe atụ, `Vec` na `Box` hụ ha mgbe igbunye karịa `isize::MAX` bytes, otú `vec.as_ptr().add(vec.len()).sub(vec.len())` bụ mgbe mma.
    ///
    /// Imirikiti nyiwe na-enweghị ike ịrụ ụdị oke a.
    /// Dịka ọmụmaatụ, enweghị ebe 64-bit a ma ama nwere ike inye arịrịọ maka 2 <sup>63</sup> bytes n'ihi njedebe tebụl ma ọ bụ kewaa oghere adreesị.
    /// Agbanyeghị, ụfọdụ nyiwe 32-bit na 16-bit nwere ike rụọ ọrụ nke ọma maka arịrịọ maka ihe karịrị `isize::MAX` bytes na ihe dịka Mgbatị Ahụ Ahụ.
    ///
    /// Ka o siri dị, ebe nchekwa sitere na ndị na-ekenye ihe ma ọ bụ faịlụ ndị edobeere nchekwa * nwere ike ibu oke ibu iji rụọ ọrụ a.
    ///
    /// Tụlee iji [`wrapping_sub`] kama ọ bụrụ na mgbochi ndị a siri ike afọ ojuju.
    /// Nanị uru nke usoro a bụ na ọ na-eme ka njikarịcha nchịkọta ihe ike dị ike.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Na-agukọta mbibi site na pointer site na iji mpịakọta akpakọrịta.
    /// (mma maka `.wrapping_offset(count as isize)`)
    ///
    /// `count` dị na nkeji nke T;ịmaatụ, `count` nke 3 na-anọchite anya nrụpụta pointer nke `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ọrụ a n'onwe ya na-adị mma mgbe niile, mana iji pointer rụpụtara adịghị.
    ///
    /// Ihe pointer rụpụtara na-adịgide n'otu ihe ahụ ekenyela `self` na-atụ aka.
    /// Enwere ike * ejighi ya iji nweta ihe ekenyela iche.Rịba ama na na Rust, a na-ewere mgbanwe (stack-allocated) ọ bụla dị ka ihe dị iche iche ekenyela.
    ///
    /// N`ikwu ya n`ụzọ ọzọ, `let z = x.wrapping_add((y as usize) - (x as usize))` anaghị eme * `z` ka ọ bụ `y` ọbụlagodi na anyị chere na `T` nwere nha `1` ma enweghị njupụta: `z` ka jikọtara na ihe `x` dị na ya, ma debe ya na ọ bụ agwa akparaghị ókè belụsọ na `x` na `y` na-abanye n'otu ihe ahụ ekenyela.
    ///
    /// E jiri ya tụnyere [`add`], usoro a na-egbu oge oge achọrọ ka ị nọrọ n'ime otu ihe ekenyela: [`add`] bụ Àgwà A Na-akọwaghị ozugbo mgbe ọ na-agafe oke ihe;`wrapping_add` arụpụta a pointer ma ka na-eduga Undefined Àgwà ma ọ bụrụ na a pointer na-dereferenced mgbe ọ bụ nke na-ókè nke ihe ọ na-mmasị na.
    /// [`add`] enwere ike kachasị mma ma bụrụ nke kachasị mma na koodu nwere arụmọrụ.
    ///
    /// Oge nyocha a na-egbu oge na-eche naanị uru nke pointer ahụ edepụtara, ọ bụghị ụkpụrụ dị n'etiti ejiri mee ihe n'oge ngụkọta nsonaazụ ikpeazụ.
    /// Iji maa atụ, `x.wrapping_add(o).wrapping_sub(o)` dị ka `x`.Yabụ, ịhapụ ekenyela ihe wee banye ọzọ na-emecha kwere.
    ///
    /// Ọ bụrụ na ị chọrọ ka cross ihe ókè, tubà pointer na integer na-eme som e.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // Ghichaa iji pointer raw na ntinye nke ihe abuo
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Nke a loop Mbipụta "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Na-agukọta mbibi site na pointer site na iji mpịakọta akpakọrịta.
    /// (mma maka '.wrapping_offset ((gụọ dị ka isize).wrapping_neg())`).)
    ///
    /// `count` dị na nkeji nke T;ịmaatụ, `count` nke 3 na-anọchite anya nrụpụta pointer nke `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Ọrụ a n'onwe ya na-adị mma mgbe niile, mana iji pointer rụpụtara adịghị.
    ///
    /// Ihe pointer rụpụtara na-adịgide n'otu ihe ahụ ekenyela `self` na-atụ aka.
    /// Enwere ike * ejighi ya iji nweta ihe ekenyela iche.Rịba ama na na Rust, a na-ewere mgbanwe (stack-allocated) ọ bụla dị ka ihe dị iche iche ekenyela.
    ///
    /// N`ikwu ya n`ụzọ ọzọ, `let z = x.wrapping_sub((x as usize) - (y as usize))` anaghị eme * `z` ka ọ bụ `y` ọbụlagodi na anyị chere na `T` nwere nha `1` ma enweghị njupụta: `z` ka jikọtara na ihe `x` dị na ya, ma debe ya na ọ bụ agwa akparaghị ókè belụsọ na `x` na `y` na-abanye n'otu ihe ahụ ekenyela.
    ///
    /// E jiri ya tụnyere [`sub`], usoro a na-egbu oge oge achọrọ ka ị nọrọ n'otu ihe ahụ ekenyepụtara: [`sub`] bụ Àgwà A Na-akọwaghị ozugbo mgbe ọ na-agafe oke ihe;`wrapping_sub` na-emepụta pointer ma ka na-eduga na Omume a na-akọwaghị ma ọ bụrụ na a na-edebanye pointer mgbe ọ na-enweghị oke nke ihe ejikọtara ya.
    /// [`sub`] enwere ike kachasị mma ma bụrụ nke kachasị mma na koodu nwere arụmọrụ.
    ///
    /// Oge nyocha a na-egbu oge na-eche naanị uru nke pointer ahụ edepụtara, ọ bụghị ụkpụrụ dị n'etiti ejiri mee ihe n'oge ngụkọta nsonaazụ ikpeazụ.
    /// Iji maa atụ, `x.wrapping_add(o).wrapping_sub(o)` dị ka `x`.Yabụ, ịhapụ ekenyela ihe wee banye ọzọ na-emecha kwere.
    ///
    /// Ọ bụrụ na ị chọrọ ka cross ihe ókè, tubà pointer na integer na-eme som e.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // Iterate eji a raw pointer na increments nke abụọ ọcha (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Nke a loop Mbipụta "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Setịpụrụ pointer uru na `ptr`.
    ///
    /// Ọ bụrụ na `self` bụ ntụpọ (fat) na ụdị enweghị atụ, ọrụ a ga-emetụta akụkụ pointer naanị, ebe maka (thin) na-atụ aka iji ụdị dị iche iche, nke a nwere otu mmetụta dịka ọrụ dị mfe.
    ///
    /// Ihe pointer ahụ ga-enwe ga-enwe ihe ngosi nke `val`, ya bụ, maka pointer pounter, ọrụ a bụ otu ihe ahụ dị ka ịmepụta pointer ọhụrụ yana akara pointer data nke `val` mana metadata nke `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ọrụ a bụ isi bara uru maka ikwe ka ịkọwa ihe pointer som na ihe ndị nwere abụba:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // bipụta "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SAFETY: Bụrụ na nke mkpa pointer, arụmọrụ a yiri
        // gaa ọrụ dị mfe.
        // Bụrụ na nke a abụba pointer, na nke ugbu a abụba pointer layout mmejuputa iwu, akpa ubi nke ndị dị otú ahụ a pointer bụ mgbe data pointer, nke a na dika kenyere.
        //
        unsafe { *thin = val };
        self
    }

    /// Na-agụ uru site na `self` na-enweghị ebugharị ya.
    /// Nke a na-ahapụ ebe nchekwa na `self` na-agbanweghi agbanwe.
    ///
    /// Hụ [`ptr::read`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka ``.
        unsafe { read(self) }
    }

    /// Na-eme otu ọnụ ọgụgụ bara uru nke `self` na-enweghị ebugharị ya.Nke a na-eme ka ebe nchekwa dị na `self` agbanweghi agbanwe.
    ///
    /// A na-ezube arụmọrụ dị iche iche iji rụọ ọrụ na I/O ebe nchekwa, ma kwe nkwa na ịghara ịchịkọta ya ma ọ bụ weghachite ya site na nchịkọta ndị ọzọ.
    ///
    ///
    /// Hụ [`ptr::read_volatile`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Na-agụ uru site na `self` na-enweghị ebugharị ya.
    /// Nke a na-ahapụ ebe nchekwa na `self` na-agbanweghi agbanwe.
    ///
    /// N'adịghị ka `read`, a na-atụnye pointer ahụ n'usoro.
    ///
    /// Hụ [`ptr::read_unaligned`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copies `count * size_of<T>` bytes si `self` ka `dest`.
    /// Isi mmalite ya na ebe ije ya nwere ike ju.
    ///
    /// NOTE: nke a nwere usoro iwu *otu* ahụ dị ka [`ptr::copy`].
    ///
    /// Hụ [`ptr::copy`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copies `count * size_of<T>` bytes si `self` ka `dest`.
    /// Isi mmalite na ebe njedebe ya *nwere ike* ghara ịgafe.
    ///
    /// NOTE: nke a nwere usoro iwu *otu* ahụ dị ka [`ptr::copy_nonoverlapping`].
    ///
    /// Hụ [`ptr::copy_nonoverlapping`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Copies `count * size_of<T>` bytes si `src` ka `self`.
    /// Isi mmalite ya na ebe ije ya nwere ike ju.
    ///
    /// NOTE: nke a nwere usoro iwu esemokwu nke [`ptr::copy`].
    ///
    /// Hụ [`ptr::copy`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Copies `count * size_of<T>` bytes si `src` ka `self`.
    /// Isi mmalite na ebe njedebe ya *nwere ike* ghara ịgafe.
    ///
    /// NOTE: nke a nwere usoro iwu esemokwu nke [`ptr::copy_nonoverlapping`].
    ///
    /// Hụ [`ptr::copy_nonoverlapping`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Na-ebibi onye nbibi ahụ (ma ọ bụrụ na ọ bụla) nke akara aka.
    ///
    /// Hụ [`ptr::drop_in_place`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Ghari ebe nchekwa na uru enyere ya n`agughi ma obu dobe uru ochie.
    ///
    ///
    /// Hụ [`ptr::write`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `write`.
        unsafe { write(self, val) }
    }

    /// Na-akpali ncheta na pointer akọwapụtara, ịtọlite `count * size_of::<T>()` bytes nke ebe nchekwa na-amalite na `self` na `val`.
    ///
    ///
    /// Hụ [`ptr::write_bytes`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Anamde a obodo dee nke a na ebe nchekwa ebe na nyere uru enweghị agụ ma ọ bụ na idobe ochie uru.
    ///
    /// A na-ezube arụmọrụ dị iche iche iji rụọ ọrụ na I/O ebe nchekwa, ma kwe nkwa na ịghara ịchịkọta ya ma ọ bụ weghachite ya site na nchịkọta ndị ọzọ.
    ///
    ///
    /// Hụ [`ptr::write_volatile`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Ghari ebe nchekwa na uru enyere ya n`agughi ma obu dobe uru ochie.
    ///
    ///
    /// N'adịghị ka `write`, na pointer nwere ike unaligned.
    ///
    /// Hụ [`ptr::write_unaligned`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Anọchie Anya uru na `self` na `src`, alaghachi ochie bara uru, na-enweghị idobe ma.
    ///
    ///
    /// Hụ [`ptr::replace`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `replace`.
        unsafe { replace(self, src) }
    }

    /// Swaps ụkpụrụ na abụọ mutable ebe nke otu ụdị, na-enweghị deinitializing ma.
    /// Ha nwere ike yitewere, n'adịghị ka `mem::swap` nke na-anọghị nhata.
    ///
    /// Hụ [`ptr::swap`] maka nsogbu nchekwa na ihe atụ.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `swap`.
        unsafe { swap(self, with) }
    }

    /// Na-agbakọ ụgwọ dị mkpa iji tinye ya na pointer iji mee ka ọ kwekọọ na `align`.
    ///
    /// Ọ bụrụ na ọ gaghị ekwe omume ịkwado pointer ahụ, mmejuputa laghachiri `usize::MAX`.
    /// Enwere ikike maka mmejuputa ka *laghachi* mgbe niile `usize::MAX`.
    /// Naanị arụmọrụ gị nke algorithm nwere ike ịdabere na iwepụ ya enwere ike iji ya rụọ ọrụ, ọ bụghị izi ezi ya.
    ///
    /// Dechapụ na-kwupụtara na ọnụ ọgụgụ nke `T` ọcha, ma ọ bụghị bytes.Enwere ike iji uru laghachiri na usoro `wrapping_add`.
    ///
    /// Onweghi nkwa obula na iwepu pointer a aghaghi iju ma obu gabiga oke nke ihe pointer ruturu aka.
    ///
    /// Ọ bụ ruo nke bere iji hụ na laghachi dechapụ bụ eziokwu niile okwu ndị ọzọ karịa itinye n'ọnọdụ.
    ///
    /// # Panics
    ///
    /// Ọrụ panics ma ọ bụrụ na `align` abụghị ike-nke-abụọ.
    ///
    /// # Examples
    ///
    /// Xnweta `u8` dịdebere `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ebe enwere ike ikwado pointer ahụ site na `offset`, ọ ga-atụ aka na mpụga oke
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // EGO: `align` enyochala ka ọ bụrụ ike nke 2 dị n'elu
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Laghachi ogologo nke a iberi raw.
    ///
    /// Ihe eweghachitere bụ ọnụọgụ nke **ihe**, ọ bụghị ọnụọgụ nke bytes.
    ///
    /// Arụ ọrụ a dị mma, ọbụlagodi mgbe enweghị ike ịtụba nza iberi n'ihi na pointer enweghị isi ma ọ bụ ahaghị ya.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: nke a dị mma n'ihi na `*const [T]` na `FatPtr<T>` nwere otu nhazi ahụ.
            // Naanị `std` nwere ike ime nkwa a.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Weghachite pointer raw na mpempe akwụkwọ.
    ///
    /// Nke a bụ Ẹkot nēfe `self` ka `*mut T`, ma ihe pịnye-adịghị ize ndụ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// O weghachite pointer raw na ihe mmeju ma obu mechie, na-emeghi nyocha.
    ///
    /// Kpọ usoro a site na ndekpọ na-enweghị oke ma ọ bụ mgbe `self` anaghị edepụta ya bụ *[omume a na-akọwaghị]* ọ bụrụgodi na ejighị pointer na-akpata.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // Nchedo: onye na-akpọ oku na-achọpụta na `self` nwere ike ịgbagha na `index` na-ókè.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Weghachi `None` ma ọ bụrụ na pointer enweghị isi, ma ọ bụ na ọ ga-eweghachi otu òkè iberibe na uru ejiri na `Some`.
    /// N'adịghị ka [`as_ref`], nke a achọghị ka amalite ụkpụrụ ahụ.
    ///
    /// Maka onye na-agbanwe agbanwe lee [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na *ma pointer ahụ bụ NULL* ma ọ bụ * ihe ndị a niile bụ eziokwu:
    ///
    /// * Ihe akara aka ga-abụ [valid] maka agụ maka `ptr.len() * mem::size_of::<T>()` ọtụtụ bytes, ọ ga-adakọrịrị nke ọma.Nke a pụtara akpan akpan:
    ///
    ///     * Dum ebe nchekwa nke a iberi ga-ẹdude n'ime otu ekenyela ihe!
    ///       Mpekere enweghị ike ịgafe ọtụtụ ihe ekenyepụtara.
    ///
    ///     * A ga-aharịrị onye na-atụtụ ihe ọbụlagodi mpekere efu.
    ///     Otu ihe kpatara nke a bụ na njikarịcha atụmatụ enum nwere ike ịdabere na amaokwu (gụnyere mpekere nke ogologo ọ bụla) iji kwekọọ na enweghị isi iji gosi ọdịiche dị na data ndị ọzọ.
    ///
    ///     Nwere ike ịnweta pointer nwere ike iji ya dị ka `data` maka mpekere ogologo-ogologo iji [`NonNull::dangling()`].
    ///
    /// * Mkpokọta `ptr.len() * mem::size_of::<T>()` nke iberi ahụ agaghị ebu karịa `isize::MAX`.
    ///   Hụ akwụkwọ nchekwa nke [`pointer::offset`].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa a na-atụ aka ka a ghara ịgbanwe (ma e wezụga n'ime `UnsafeCell`).
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// Leekwa [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Laghachi `None` ma ọ bụrụ na pointer adịghị arụ ọrụ, ma ọ bụ na ọ ga-eweghachi otu mpempe pụrụ iche na uru ejiri na `Some`.
    /// N'ụzọ dị iche na [`as_mut`], a na-adịghị achọ na uru nwere na-initialized.
    ///
    /// Maka onye ịkọkọrịta ọnụ hụrụ [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Mgbe ị na-akpọ usoro a, ị ga-ahụrịrị na *ma pointer ahụ bụ NULL* ma ọ bụ * ihe ndị a niile bụ eziokwu:
    ///
    /// * Nchịkọta ga-abụ [valid] maka ịgụ ma na-ede maka `ptr.len() * mem::size_of::<T>()` ọtụtụ bytes, ọ ga-adakọrịrị nke ọma.Nke a pụtara akpan akpan:
    ///
    ///     * Dum ebe nchekwa nke a iberi ga-ẹdude n'ime otu ekenyela ihe!
    ///       Mpekere enweghị ike ịgafe ọtụtụ ihe ekenyepụtara.
    ///
    ///     * A ga-aharịrị onye na-atụtụ ihe ọbụlagodi mpekere efu.
    ///     Otu ihe kpatara nke a bụ na njikarịcha atụmatụ enum nwere ike ịdabere na amaokwu (gụnyere mpekere nke ogologo ọ bụla) iji kwekọọ na enweghị isi iji gosi ọdịiche dị na data ndị ọzọ.
    ///
    ///     Nwere ike ịnweta pointer nwere ike iji ya dị ka `data` maka mpekere ogologo-ogologo iji [`NonNull::dangling()`].
    ///
    /// * Mkpokọta `ptr.len() * mem::size_of::<T>()` nke iberi ahụ agaghị ebu karịa `isize::MAX`.
    ///   Hụ akwụkwọ nchekwa nke [`pointer::offset`].
    ///
    /// * Kwesiri ịdebe iwu nke aha Rust, ebe ọ bụ na a laghachiri ndụ `'a` na-edozighị anya na ọ pụtaghị na ndụ data ahụ dị adị.
    ///   Karịsịa, maka oge ndụ a niile, ebe nchekwa pointer na-atụ aka agaghị enweta (ịgụ ma ọ bụ dee) site na pointer ọ bụla ọzọ.
    ///
    /// Nke a metụtara ọbụlagodi na nsonaazụ usoro a anaghị arụ ọrụ!
    ///
    /// Leekwa [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Nhata maka ntanye
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}