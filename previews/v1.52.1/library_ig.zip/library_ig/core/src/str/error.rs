//! Na-akọwa ụdị njehie utf8.

use crate::fmt;

/// Njehie nke nwere ike ime mgbe ị na-achọ ịkọwa usoro [`u8`] dị ka eriri.
///
/// Dị ka ndị dị otú ahụ, ezinụlọ `from_utf8` nke ọrụ na ụzọ maka [``String`] s na [`&str`] na-eji njehie a, dịka ọmụmaatụ.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Nke a njehie ụdị si ụzọ a pụrụ iji ike arụmọrụ yiri `String::from_utf8_lossy` enweghị allocating obo ebe nchekwa:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Alaghachi na index na nyere eriri ruo nke nti UTF-8 e kwupụtara.
    ///
    /// Ọ bụ ndepụta kachasị dị ka `from_utf8(&input[..index])` ga-alaghachi `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ụfọdụ abaghị uru, na vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 weghachite Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // nke abụọ byte abaghị uru ebe a
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Na-enye ozi ndị ọzọ gbasara ọdịda:
    ///
    /// * `None`: a rutere njedebe nke ntinye ahụ na-atụghị anya ya.
    ///   `self.valid_up_to()` bụ 1 ka 3 bytes site na njedebe nke ntinye.
    ///   Ọ bụrụ na a na-edozigharị usoro byte (dị ka faịlụ ma ọ bụ oghere ntanetị), nke a nwere ike ịbụ `char` ziri ezi nke usoro UTF-8 nke na-agafe ọtụtụ akụkụ.
    ///
    ///
    /// * `Some(len)`: ihe mberede a na-atụghị anya ya.
    ///   Ogologo enyere bụ nke usoro byte na-enweghị isi nke na-amalite na ndenye nke `valid_up_to()` nyere.
    ///   Nkpebi iwu ga-amaliteghachi mgbe usoro ahụ gasịrị (mgbe ịtisịrị [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) ọ bụrụ na ịnwe ngbanwe nke ọnwụ.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Njehie laghachi mgbe parsing a `bool` iji [`from_str`] ada ada
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}