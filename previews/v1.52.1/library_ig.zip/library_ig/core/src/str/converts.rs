//! Zọ iji mepụta `str` site na iberi bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Atọghata a iberi nke bytes ka a eriri iberi.
///
/// A na-eji eriri iberi ([`&str`]) eme ihe bytes ([`u8`]), a na-esikwa ya byte iberi ([`&[u8]`][byteslice]) site na bytes, yabụ na ọrụ a na-agbanwe n'etiti ha abụọ.
/// Ọ bụghị ihe niile byte Mpekere bụ nti eriri Mpekere, Otú ọ dị: [`&str`] na-achọ na ọ bụ nti UTF-8.
/// `from_utf8()` nlele iji hụ na bytes dị adị UTF-8, wee gbanwee ya.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ọ bụrụ na ị kwenyesiri ike na byte iberi ahụ dị UTF-8, na ịchọghị ibute ebe nyocha nke ndaba ahụ, enwere ụdị ọrụ a na-adịghị echekwa echekwa, [`from_utf8_unchecked`], nke nwere otu omume mana ọ na-eleghara nlele ahụ.
///
///
/// Ọ bụrụ na ịchọrọ `String` kama `&str`, tụlee [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Maka na ị nwere ike ịtọkọta-ekenye `[u8; N]`, ịnwere ike iwere [`&[u8]`][byteslice] ya, ọrụ a bụ otu ụzọ ị ga-esi nwee eriri ekenyegoro.Enwere ihe atụ nke a na ngalaba ihe atụ dị n'okpuru.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Laghachi `Err` ma ọ bụrụ na iberi bụghị UTF-8 na a nkọwa nke mere na-enye iberi abụghị UTF-8.
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::str;
///
/// // ụfọdụ bytes, na a vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Anyị maara na bytes ndị a dị irè, yabụ jiri `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Ezigbo bytes:
///
/// ```
/// use std::str;
///
/// // ụfọdụ abaghị uru, na vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Lee Docs maka [`Utf8Error`] maka nkọwa ndị ọzọ na iche iche nke njehie nke nwere ike laghachi.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ụfọdụ bytes, na a tojupụtara-ekenye n'usoro
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Anyị maara na bytes ndị a dị irè, yabụ jiri `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Naanị ịgba ọsọ nkwado.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Atọghari a mutable iberi nke bytes ka a mutable eriri iberi.
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" dị ka a na-agbanwe agbanwe vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Dika anyi mara na bytes ndia di ire, anyi nwere ike iji `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Ezigbo bytes:
///
/// ```
/// use std::str;
///
/// // Tesfọdụ bytes na-agbanwe agbanwe na vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Lee Docs maka [`Utf8Error`] maka nkọwa ndị ọzọ na iche iche nke njehie nke nwere ike laghachi.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Naanị ịgba ọsọ nkwado.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Na-agbanwe mkpụrụ nke bytes ka ọ bụrụ na ịchọọ na eriri ahụ nwere UTF-8 dị mma.
///
/// Hụ ụdị nchekwa, [`from_utf8`], maka ama ndị ọzọ.
///
/// # Safety
///
/// Ọrụ a enweghị nchedo n'ihi na ọ naghị achọpụta na bytes gafere ya bụ ezigbo UTF-8.
/// Ọ bụrụ na emebiri ihe mgbochi a, omume a na-akọwaghị akọwapụta, dị ka ndị ọzọ Rust na-eche na [`&str`] s dị mma UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::str;
///
/// // ụfọdụ bytes, na a vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ANY SA: onye na-akpọ oku ga-ekwusi ike na bytes `v` dị irè UTF-8.
    // Na-adaberekwa na `&str` na `&[u8]` nwere otu nhazi ahụ.
    unsafe { mem::transmute(v) }
}

/// Tọgharịrị iberi nke bytes ka a eriri iberi na-enweghị ịlele na eriri nwere nti UTF-8;mutable version.
///
///
/// Lee immutable version, [`from_utf8_unchecked()`] maka ozi ndị ọzọ.
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // NCHEKWA: nke bere kwesịrị nkwa na bytes `v`
    // dị UTF-8 dị mma, yabụ nkedo a na `*mut str` dị mma.
    // Ọzọkwa, pointer dereference bụ nchebe n'ihi na pointer si a akwụkwọ nke na-ekwe nkwa na-nti nke na-ede.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}