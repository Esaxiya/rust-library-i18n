//! Ntinye Trait maka `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implements ịtụ nke ndido urụk.
///
/// Edere ụdọ [lexicographically](Ord#lexicographical-comparison) site na ụkpụrụ ụkpụrụ ha.
/// Nke a iwu Unicode code isi ihe dabeere na ọnọdụ ha na koodu chaatị dị iche iche.
/// Nke a adịchaghị otu "alphabetical" iji, nke dịgasị site asụsụ na anọkwaghị n'ógbè.
/// Orthazi eriri dị ka ụkpụrụ a nabatara nke ọdịbendị chọrọ data a kapịrị ọnụ nke mpaghara na-abụghị ụdị nke ụdị `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Na-eme ihe atụ iji rụọ ọrụ na eriri.
///
/// Urụk tụnyere [lexicographically](Ord#lexicographical-comparison) ha byte ụkpụrụ.
/// Nke a na-eji tụnyere Unicode koodu ihe dabeere na ọnọdụ ha na koodu chaatị dị iche iche.
/// Nke a adịchaghị otu "alphabetical" iji, nke dịgasị site asụsụ na anọkwaghị n'ógbè.
/// Atụnyere urụk dị ka ọdịbendị-anabata ụkpụrụ na-achọ anọkwaghị n'ógbè-kpọmkwem data na bụ n'èzí akporo nke `str` ụdị.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Achụ nta substring slicing na syntax `&self[..]` ma ọ bụ `&mut self[..]`.
///
/// Weghachi iberi nke eriri ahụ dum, ya bụ, laghachi `&self` ma ọ bụ `&mut self`.Ẹkot ka `&onwe [0 ..
/// len] 'ma ọ bụ'&mut onwe [0 ..
/// len]`.
/// N'adịghị ka arụmọrụ ndọtị ndị ọzọ, nke a enweghị ike panic.
///
/// Ọrụ a bụ *O*(1).
///
/// Tupu 1.20.0, ndị a indexing arụmọrụ ka nọ na-akwado site na kpọmkwem mmejuputa `Index` na `IndexMut`.
///
/// Ẹkot `&self[0 .. len]` ma ọ bụ `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Achụ nta substring slicing na syntax `&self[begin .. end]` ma ọ bụ `&mut self[begin .. end]`.
///
/// Alaghachi a iberi nke nyere eriri si byte nso ['begin`, `end`).
///
/// Ọrụ a bụ *O*(1).
///
/// Tupu 1.20.0, ndị a indexing arụmọrụ ka nọ na-akwado site na kpọmkwem mmejuputa `Index` na `IndexMut`.
///
/// # Panics
///
/// Panics ma ọ bụrụ na `begin` ma ọ bụ `end` adịghị ekwu na malite byte dechapụ nke a agwa (dị ka kọwaa site `is_char_boundary`), ma ọ bụrụ na `begin > end`, ma ọ bụ ma ọ bụrụ na `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ndị a ga-panic:
/// // baiti 2 dị n'ime `ö`:
/// // &s [2 ..3];
///
/// // byte 8 dị n'ime `老`&s [1 ..
/// // 8];
///
/// // byte 100 bụ n'èzí eriri&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // NCHEKWA: nnọọ enyocha na `start` na `end` bụ na a Ịsaka ókè,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            // Anyị na-enyocha Ịsaka ókè, otú a bụ nti UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: lere anya na `start` na `end` nọ na oke ọkụ.
            // Anyị maara na pointer pụrụ iche n'ihi na anyị nwetara ya site na `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // MGBE: onye na-akpọ oku na-ekwe nkwa na `self` dị na njedebe nke `slice`
        // nke afọ niile ọnọdụ n'ihi na `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: lee ihe maka `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary na-achọpụta na ndeksi ahụ dị na [0, .len()] enweghị ike iji ya mee ihe `get` dị ka ọ dị n'elu, n'ihi nsogbu NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // NCHEKWA: nnọọ enyocha na `start` na `end` bụ na a Ịsaka ókè,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Achụ nta substring slicing na syntax `&self[.. end]` ma ọ bụ `&mut self[.. end]`.
///
/// Alaghachi a iberi nke nyere eriri si byte nso ['0`, `end`).
/// Ẹkot `&self[0 .. end]` ma ọ bụ `&mut self[0 .. end]`.
///
/// Ọrụ a bụ *O*(1).
///
/// Tupu 1.20.0, ndị a indexing arụmọrụ ka nọ na-akwado site na kpọmkwem mmejuputa `Index` na `IndexMut`.
///
/// # Panics
///
/// Panics ma ọ bụrụ na `end` adịghị arụtụ aka na mbido mbido nke agwa (dịka `is_char_boundary` kọwara), ma ọ bụ ọ bụrụ `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // NCHEKWA: nnọọ enyocha na `end` bụ na a Ịsaka ókè,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // NCHEKWA: nnọọ enyocha na `end` bụ na a Ịsaka ókè,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // NCHEKWA: nnọọ enyocha na `end` bụ na a Ịsaka ókè,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Na-etinye ihe mmerụ ahụ na syntax `&self[begin ..]` ma ọ bụ `&mut self[begin ..]`.
///
/// Alaghachi a iberi nke nyere eriri si byte nso ['begin`, `len`).Ẹkot ka&&onwe [amalite ..
/// len] 'ma ọ bụ'&mut onwe [amalite ..
/// len]`.
///
/// Ọrụ a bụ *O*(1).
///
/// Tupu 1.20.0, ndị a indexing arụmọrụ ka nọ na-akwado site na kpọmkwem mmejuputa `Index` na `IndexMut`.
///
/// # Panics
///
/// Panics ma ọ bụrụ na `begin` adịghị ekwu na malite byte dechapụ nke a agwa (dị ka kọwaa site `is_char_boundary`), ma ọ bụ ma ọ bụrụ na `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: lere anya na `start` dị na oke ọkụ,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAFETY: lere anya na `start` dị na oke ọkụ,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // MGBE: onye na-akpọ oku na-ekwe nkwa na `self` dị na njedebe nke `slice`
        // nke afọ niile ọnọdụ n'ihi na `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // NCHEKWA: yiri `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAFETY: lere anya na `start` dị na oke ọkụ,
            // na anyị na-agafe na ntụpọ nchekwa, yabụ uru nloghachi ga-abụkwa otu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Na-etinye ihe mmerụ ahụ na syntax `&self[begin ..= end]` ma ọ bụ `&mut self[begin ..= end]`.
///
/// Weghachi a iberi nke nyere eriri si byte nso [`begin`, `end`].Dị ka `&self [begin .. end + 1]` ma ọ bụ `&mut self[begin .. end + 1]`, ewezuga ma ọ bụrụ na `end` nwere uru kachasị maka `usize`.
///
/// Ọrụ a bụ *O*(1).
///
/// # Panics
///
/// Panics ma ọ bụrụ na `begin` adịghị arụtụ aka na mbido mbido nke agwa (dịka `is_char_boundary` kọwara), ọ bụrụ na `end` anaghị arụtụ aka na njedebe njedebe nke agwa (`end + 1` bụ mbido mbido mbido ma ọ bụ hara `len`), ọ bụrụ na `begin > end`, ma ọ bụ ọ bụrụ `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Na-etinye ihe mmerụ ahụ na syntax `&self[..= end]` ma ọ bụ `&mut self[..= end]`.
///
/// Weghachi a iberi nke nyere eriri si byte nso [0, `end`].
/// Ẹkot `&self [0 .. end + 1]`, ma e wezụga ma ọ bụrụ na `end` nwere karịa uru maka `usize`.
///
/// Ọrụ a bụ *O*(1).
///
/// # Panics
///
/// Panics ma ọ bụrụ na `end` adịghị arụtụ aka na njedebe nke njedebe nke agwa (`end + 1` bụ ma ọ bụ mbido mbido mbido dịka `is_char_boundary` kọwara, ma ọ bụ hà `len`), ma ọ bụ ọ bụrụ `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Gwa otu uru site na eriri
///
/// A na-ejikarị usoro [`from_str`] nke FromStr`n'ụzọ zuru oke, site na usoro [`parse`] nke"'' str``.
/// Lee ['parse`]' s akwụkwọ maka ihe atụ.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` enweghị usoro ndụ niile, yabụ na ị nwere ike ịkọwa ụdị nke na-enweghị oke ndụ niile.
///
/// N'ikwu ya n'ụzọ ọzọ, ịnwere ike ịtụlee `i32` na `FromStr`, mana ọ bụghị `&i32`.
/// I nwere ike parse a struct na e dere ihe `i32`, ma ọ bụghị onye na-nwere ihe `&i32`.
///
/// # Examples
///
/// Ntọala nhazi nke `FromStr` na ụdị `Point` ụdị:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// The metụtara njehie nke nwere ike laghachi si parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parses a eriri `s` laghachi a uru nke ụdị.
    ///
    /// Ọ bụrụ ngbanwe nke ọma, weghachi uru dị na [`Ok`], ma ọ bụghị mgbe eriri ahụ adịghị arụ ọrụ na-eweghachi njehie akọwapụtara n'ime [`Err`].
    /// Thedị njehie ahụ bụ kpọmkwem maka mmejuputa nke trait.
    ///
    /// # Examples
    ///
    /// Basic ojiji na [`i32`], a ụdị na achụ nta `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Nyochaa `bool` site na eriri.
    ///
    /// Na-enweta `Result<bool, ParseBoolError>`, n'ihi na `s` nwere ike ọ gaghị enwe ezigbo ntụgharị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Cheta, na ọtụtụ mgbe, ndị `.parse()` usoro on `str` bụ ihe kwesịrị ekwesị.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}