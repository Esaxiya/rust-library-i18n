//! Eriri eriri.
//!
//! Maka nkọwa ndị ọzọ, lee modul [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. gabiga ókè
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. bido <=ọgwụgwụ
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. agwa mmadụ
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // chọta agwa
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ga-erughị ihe mgbazinye na ụdọ cha
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Laghachi ogologo `self`.
    ///
    /// Ogologo a dị na bytes, ọ bụghị [``char`] ma ọ bụ graphemes.
    /// N'ikwu ya n'ụzọ ọzọ, ọ nwere ike ọ gaghị abụ ihe mmadụ tụlere ogologo eriri ahụ.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Laghachi `true` ma ọ bụrụ na `self` nwere ogologo nke bytes efu.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Akwụkwọ ndọrọ ego na 'index`-nke byte bụ nke mbụ byte na a UTF-8 koodu mgbe usoro ma ọ bụ ọgwụgwụ nke eriri.
    ///
    ///
    /// Mmalite na njedebe nke eriri (mgbe a na-ewere `` ndeksi== self.len()`) dị ka oke.
    ///
    /// Alaghachi `false` ma ọ bụrụ na `index` ukwuu `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // mmalite nke `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // nke abuo nke `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // nke atọ nke `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 na len dị mma mgbe niile.
        // Nwalee maka 0 n`ụzọ doro anya ka ọ nwee ike bulite nlele ahụ ọfụma ma mafee ịgụ eriri data maka ikpe ahụ.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Nke a bụ anwansi bit yiri: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Tọghaa eriri iberi ka a byte iberi.
    /// Iji gbanwee byte iberi azụ n'ime eriri iberi, jiri [`from_utf8`] ọrụ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: const ụda n'ihi na anyị transmute ụdị abụọ na otu okirikiri nhọrọ ukwuu
        unsafe { mem::transmute(self) }
    }

    /// Na-atụgharị iberi eriri mpempe ihe ntụgharị na mpempe akwụkwọ ntụgharị.
    ///
    /// # Safety
    ///
    /// The bere ga-hụ na ọdịnaya nke iberi bụ nti UTF-8 tupu Borrow nsọtụ na-apụtaghị ìhè na `str` na-eji.
    ///
    ///
    /// Ojiji nke `str` nke ihe ya adighi nma UTF-8 bu agwa akparaghị ókè.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // MGBE: ihe nkedo sitere na `&str` na `&[u8]` dị mma kemgbe `str`
        // nwere otu layout ka `&[u8]` (naanị libstd nwere ike ime ka a nkwa).
        // The pointer dereference bụ nchebe ebe ọ bụ na ọ na-abịa site a mutable akwụkwọ nke na-ekwe nkwa na-nti nke na-ede.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Atọghata a eriri iberi ka a raw pointer.
    ///
    /// Dị ka eriri Mpekere bụ a iberi nke bytes, ọnyá ọhụrụ pointer isi ka a [`u8`].
    /// Nke a pointer ga-atụ aka nke mbụ byte nke eriri iberi.
    ///
    /// Onye na-akpọ oku ga-ahụrịrị na edebeghị ederede pointer ahụ.
    /// Ọ bụrụ na ị chọrọ ka mutate ọdịnaya nke eriri iberi, iji [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Na-atụgharị mpe mpe mpe akwa na akara pointer.
    ///
    /// Dị ka eriri Mpekere bụ a iberi nke bytes, ọnyá ọhụrụ pointer isi ka a [`u8`].
    /// Nke a pointer ga-atụ aka nke mbụ byte nke eriri iberi.
    ///
    /// Ọ bụ ọrụ gị iji hụ na eriri iberibe naanị gbanwere n'ụzọ ọ ga-adịgide UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Alaghachi a subslice nke `str`.
    ///
    /// Nke a bụ egwu ọzọ na-enweghị ụjọ iji zoo `str`.
    /// Weghachi [`None`] mgbe obula oru ndekota gha panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indices bụghị na UTF-8 usoro ókè
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // gabiga ókè
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Weghachite ndepụta mbugharị nke `str`.
    ///
    /// Nke a bụ egwu ọzọ na-enweghị ụjọ iji zoo `str`.
    /// Weghachi [`None`] mgbe obula oru ndekota gha panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ogologo ogologo
    /// assert!(v.get_mut(0..5).is_some());
    /// // gabiga ókè
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Alaghachi ihe kpacharaghị subslice nke `str`.
    ///
    /// Nke a bu uzo ozo achoghi anya iji choputa `str`.
    ///
    /// # Safety
    ///
    /// Listi ọkpọ oku nke ọrụ a na-eme ka ndị a na preconditions nwere afọ ojuju:
    ///
    /// * Nhazi mmalite agaghị agabiga na njedebe ngwụcha;
    /// * Index ga-agabiga oke oke nke ihe mbido;
    /// * Index ga-agharịrị na mpaghara UTF-8.
    ///
    /// Na-eme nke ahụ, eriri iberibe azụ nwere ike ịkọwa ebe nchekwa na-enweghị isi ma ọ bụ mebie ndị enweghị ike nke ụdị `str` kọọrọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // NCHEKWA: nke bere ga-akwado nchekwa nkwekọrịta maka `get_unchecked`;
        // iberi bụ dereferencable n'ihi `self` bụ nchebe akwụkwọ.
        // Pointer ahụ laghachiri dị mma n'ihi na ntụgharị nke `SliceIndex` ga-ekwenye na ọ bụ.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Weghachi ndepụta nke `str` nke nwere ike ịgbanwe agbanwe, nke a na-enyochaghị.
    ///
    /// Nke a bu uzo ozo achoghi anya iji choputa `str`.
    ///
    /// # Safety
    ///
    /// Listi ọkpọ oku nke ọrụ a na-eme ka ndị a na preconditions nwere afọ ojuju:
    ///
    /// * Nhazi mmalite agaghị agabiga na njedebe ngwụcha;
    /// * Index ga-agabiga oke oke nke ihe mbido;
    /// * Index ga-agharịrị na mpaghara UTF-8.
    ///
    /// Na-eme nke ahụ, eriri iberibe azụ nwere ike ịkọwa ebe nchekwa na-enweghị isi ma ọ bụ mebie ndị enweghị ike nke ụdị `str` kọọrọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `get_unchecked_mut`;
        // iberi bụ dereferencable n'ihi `self` bụ nchebe akwụkwọ.
        // Pointer ahụ laghachiri dị mma n'ihi na ntụgharị nke `SliceIndex` ga-ekwenye na ọ bụ.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Emepụta a eriri iberi si ọzọ eriri iberi, gafere nchekwa akwụkwọ ndenye ego.
    ///
    /// Nke a n'ozuzu adịghị atụ aro ya, jiri nlezianya mee ihe!Maka nchekwa ọzọ lee [`str`] na [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Mpempe ohuru a si `begin` gaa `end`, tinyere `begin` mana ewepu `end`.
    ///
    /// Iji nweta iberi eriri mpempe ntụgharị kama, lee usoro [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Ndị na-akpọ ọrụ a bụ ọrụ afọ ojuju atọ:
    ///
    /// * `begin` gafere `end`.
    /// * `begin` na `end` ga-byte ọnọdụ n'ime eriri iberi.
    /// * `begin` na `end` ga-edina na UTF-8 usoro ókè.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // NCHEKWA: nke bere ga-akwado nchekwa nkwekọrịta maka `get_unchecked`;
        // iberi bụ dereferencable n'ihi `self` bụ nchebe akwụkwọ.
        // Pointer ahụ laghachiri dị mma n'ihi na ntụgharị nke `SliceIndex` ga-ekwenye na ọ bụ.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Emepụta a eriri iberi si ọzọ eriri iberi, gafere nchekwa akwụkwọ ndenye ego.
    /// A naghị atụ aro nke a n'ozuzu ya, jiri nlezianya mee ihe!Maka nchekwa ọzọ lee [`str`] na [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Mpempe ohuru a si `begin` gaa `end`, tinyere `begin` mana ewepu `end`.
    ///
    /// Iji nweta eriri a na-agaghị agbanwe agbanwe, pịa ụzọ [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Ndị na-akpọ ọrụ a bụ ọrụ afọ ojuju atọ:
    ///
    /// * `begin` gafere `end`.
    /// * `begin` na `end` ga-byte ọnọdụ n'ime eriri iberi.
    /// * `begin` na `end` ga-edina na UTF-8 usoro ókè.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // MGBE: onye na-akpọ oku ga-akwado nkwekọrịta nchekwa maka `get_unchecked_mut`;
        // iberi bụ dereferencable n'ihi `self` bụ nchebe akwụkwọ.
        // Pointer ahụ laghachiri dị mma n'ihi na ntụgharị nke `SliceIndex` ga-ekwenye na ọ bụ.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Kewaa otu eriri iberi abụọ na ihe index.
    ///
    /// Mkparịta ụka ahụ, `mid`, kwesịrị ịbụ mmezi byte site na mmalite nke eriri.
    /// Ọ ga-abụ na ókè nke a UTF-8 koodu ebe.
    ///
    /// The Mpekere abụọ lọta laa site na mmalite nke eriri iberi na `mid`, na site na `mid` na njedebe nke eriri iberi.
    ///
    /// Iji nweta mpekere eriri mpekere kama, lee usoro [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `mid` adịghị na oke akara koodu UTF-8, maọbụ ọ bụrụ na ọ gafere njedebe nke akara koodu ikpeazụ nke eriri iberi.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary-achọpụtazi na index dị na [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: lere anya na `mid` dị na oke ọkụ.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Kewaa otu mutable eriri ibe ya abuo na ndeksi.
    ///
    /// Mkparịta ụka ahụ, `mid`, kwesịrị ịbụ mmezi byte site na mmalite nke eriri.
    /// Ọ ga-abụ na ókè nke a UTF-8 koodu ebe.
    ///
    /// The Mpekere abụọ lọta laa site na mmalite nke eriri iberi na `mid`, na site na `mid` na njedebe nke eriri iberi.
    ///
    /// Iji nweta mpempe eriri a na-apụghị ịgbanwe agbanwe kama, lee usoro [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `mid` adịghị na oke akara koodu UTF-8, maọbụ ọ bụrụ na ọ gafere njedebe nke akara koodu ikpeazụ nke eriri iberi.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary-achọpụtazi na index dị na [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: lere anya na `mid` dị na oke ọkụ.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Weghachite onye na-eme ihe n 'ebubo sel eriri.
    ///
    /// Dika eriri iberibe nwere UTF-8 ziri ezi, anyi puru iji uzo [`char`] wepu ya.
    /// Usoro a na-alaghachi dị otú ahụ iterator.
    ///
    /// Ọ dị mkpa icheta na [`char`] na-anọchi anya Unicode Scalar Value, ọ nwere ike ọ gaghị adaba n'echiche gị banyere ihe 'character' bụ.
    ///
    /// Iteration n'elu grapheme ụyọkọ nwere ike ihe ị na-chọrọ.
    /// Enweghi arụmọrụ a site n'ọbá akwụkwọ ọkọlọtọ Rust, lelee crates.io kama.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Cheta, [``char`] nwere ike ọ gaghị adabara gị na nghọta gị banyere mkpụrụedemede:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ọ bụghị 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Weghachite onye na-ekwu okwu n`elu [`char`] s iberi eriri, na ọnọdụ ha.
    ///
    /// Dika eriri iberibe nwere UTF-8 ziri ezi, anyi puru iji uzo [`char`] wepu ya.
    /// Nke a na usoro na-alaghachikwuru ihe iterator nke ma ndị a ['char`] s, nakwa dị ka ha byte ọnọdụ.
    ///
    /// Onye iterator amịrị tuples.The ọnọdụ bụ na mbụ, [`char`] bụ abụọ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Cheta, [``char`] nwere ike ọ gaghị adabara gị na nghọta gị banyere mkpụrụedemede:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // abụghị (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // lee 3 ebe a, nke ikpeazụ agwa wee abụọ bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Onye na-ede ihe karịrị otu ụzọ eriri eriri.
    ///
    /// Dị ka eriri iberi mejupụtara usoro nke bytes, anyị nwere ike itutu site na eriri iberi byte.
    /// Usoro a na-alaghachi dị otú ahụ iterator.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// E kewara eriri iberibe site na ọcha.
    ///
    /// The iterator laghachi ga-alaghachi eriri Mpekere na-sub-Mpekere nke mbụ eriri iberi, iche site na ihe ọ bụla ego nke whitespace.
    ///
    ///
    /// 'Whitespace' akọwapụtara dịka usoro nke Unicode si enweta ihe onwunwe `White_Space`.
    /// Ọ bụrụ na ịchọrọ naanị kewaa na ebe nchekwa ASCII, jiri [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// A na-atụle ụdị ebe ọcha niile:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Ikewaputara eriri uzo site na ocha uzo ASCII.
    ///
    /// Onye edemede ahụ laghachiri ga-eweghachi mpempe mpempe akwụkwọ nke bụ obere mpekere nke eriri eriri mbụ, nkewapụrụ site na ebe ọ bụla ASCII.
    ///
    ///
    /// Iji kewaa site na Unicode `Whitespace` kama, jiri [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// A na-atụle ụdị ebe ọcha ọ bụla nke ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// An iterator n'elu chọpụtara nke a eriri, dị ka eriri Mpekere.
    ///
    /// Lines na-biri na-ma a newline (`\n`) ma ọ bụ a ajụjụ laghachi na a akara oriri (`\r\n`).
    ///
    /// Usoro njedebe ikpeazụ bụ nhọrọ.
    /// Eriri na-ejedebe akara ikpeazụ ga-alọghachite otu ahịrị ndị ahụ yiri otu na-enweghị akara ikpeazụ na-agwụ.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Achọghị njedebe ikpeazụ:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Onye na-ede ihe karịrị ahịrị eriri.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Weghachite iterator nke `u16` n'elu eriri etinyere dịka UTF-16.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Laghachi `true` ma ọ bụrụ na ụkpụrụ ahụ dabara na obere iberi nke eriri a.
    ///
    /// Laghachi `false` ma ọ bụrụ na ọ naghị.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Weghachi `true` ma ọ bụrụ na ndị ụkpụrụ kwekọrọ a nganiihu nke a eriri iberi.
    ///
    /// Laghachi `false` ma ọ bụrụ na ọ naghị.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Alaghachi `true` ma ọ bụrụ na e nyere ụkpụrụ ọkụ a suffix a eriri iberi.
    ///
    /// Laghachi `false` ma ọ bụrụ na ọ naghị.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// - Alaghachi na byte index nke mbụ agwa a eriri iberi na ọkụ ụkpụrụ.
    ///
    /// Laghachi [`None`] ma ọ bụrụ na ụkpụrụ ahụ adabaghị.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Complexkpụrụ ndị dị mgbagwoju anya site na iji ụdị enweghị oghere na mmechi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Findingchọghị ụkpụrụ ahụ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// - Alaghachi na byte index nke mbụ agwa nke rightmost egwuregwu nke ihe nlereanya na nke eriri iberi.
    ///
    /// Laghachi [`None`] ma ọ bụrụ na ụkpụrụ ahụ adabaghị.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Complexkpụrụ ndị dị mgbagwoju anya na mmechi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Findingchọghị ụkpụrụ ahụ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Otu onye na-ede ihe n`okpuru eriri eriri a, kewapụrụ site na mkpụrụ edemede dabara na ụkpụrụ.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// Onye na-edeghachi azụ ga-abụ [`DoubleEndedIterator`] ma ọ bụrụ na ụkpụrụ ahụ na-enye ohere nchọgharị na nyocha forward/reverse na-amịpụta otu ihe ahụ.
    /// Nke a bụ eziokwu n'ihi na, eg, [`char`], ma ọ bụghị n'ihi na `&str`.
    ///
    /// Ọ bụrụ na ụkpụrụ ahụ na-enye ohere ọchụchọ ntụgharị mana nsonaazụ ya nwere ike ịdị iche na ọchụchọ na-aga n'ihu, enwere ike iji usoro [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ọ bụrụ na ụkpụrụ bụ a iberi nke chars, kewaa na onye ọ bụla omume nke ọ bụla nke na-agụ akụkọ:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Complexkpụrụ dị mgbagwoju anya karị, na-eji mmechi:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ọ bụrụ na a eriri nwere multiple contiguous separators, ị ga-ejedebe na efu ndido urụk ke mmepụta:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// A na-ekewa ndị na-ekewapụta ndị na-ese okwu site na eriri efu.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Ndị na-ekewapụ iche na mbido ma ọ bụ na njedebe nke eriri na-agbachi gburugburu eriri efu.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Mgbe efu eriri eji dị a separator, ọ ekewapụ ọ bụla agwa na eriri, tinyere mmalite na ọgwụgwụ nke eriri.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Ndị na-ekewa okwu na-akpata nsogbu nwere ike ibute omume ịtụnanya mgbe ejiri ohere dị ka onye nkewa.Koodu a ziri ezi:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ọ _not_-enye gị:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Jiri [`split_whitespace`] maka omume a.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Otu onye na-ede ihe n`okpuru eriri eriri a, kewapụrụ site na mkpụrụ edemede dabara na ụkpụrụ.
    /// Si dị nnọọ iche na iterator emepụta site `split` na na `split_inclusive` doo adịkwa akụkụ dị ka terminator nke substring.
    ///
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ọ bụrụ na ejiri ihe ikpeazụ nke eriri ahụ dakọtara, a ga-atụle ihe ahụ ka ọ bụrụ onye njedebe nke eriri ụzọ.
    /// Na substring ga-abụ onye ikpeazụ item laghachi site iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Otu onye na-edegharị akwụkwọ n'okpuru mkpụrụ osisi nke akara eriri enyere, nkewapụrụ site na mkpụrụedemede dabara na ụkpụrụ ma wepụta usoro ntụgharị.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// The laghachi iterator na-achọ ka ụkpụrụ na-akwado a reverse search, na ọ ga-abụ a [`DoubleEndedIterator`] ma ọ bụrụ na a forward/reverse search amịrị otu ọcha.
    ///
    ///
    /// Maka iterating site na ihu, usoro [`split`] nwere ike iji.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Complexkpụrụ dị mgbagwoju anya karị, na-eji mmechi:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Otu onye na-ede ihe n`okpuru mkpụrụ nke eriri e nyere, nkewapụrụ site na mkpụrụ edemede dabara na ụkpụrụ.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ẹkot [`split`], ma e wezụga na trailing substring na-ọsọsọp ma ọ bụrụ na efu.
    ///
    /// [`split`]: str::split
    ///
    /// Enwere ike iji usoro a maka data eriri bụ _terminated_, karịa _separated_ site n'ụkpụrụ.
    ///
    /// # Omume omume
    ///
    /// Onye na-edeghachi azụ ga-abụ [`DoubleEndedIterator`] ma ọ bụrụ na ụkpụrụ ahụ na-enye ohere nchọgharị na nyocha forward/reverse na-amịpụta otu ihe ahụ.
    /// Nke a bụ eziokwu n'ihi na, eg, [`char`], ma ọ bụghị n'ihi na `&str`.
    ///
    /// Ọ bụrụ na ụkpụrụ na-enye ohere a reverse search ma na ya pụta nwere ike si dị iche na a na-atụ search, na [`rsplit_terminator`] usoro ike ga-eji.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Otu onye na-ede ihe karịrị mkpụrụedemede nke `self`, nkewapụrụ site na mkpụrụedemede dabara adaba ma wepụta usoro iji gbanwee.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ẹkot [`split`], ma e wezụga na trailing substring na-ọsọsọp ma ọ bụrụ na efu.
    ///
    /// [`split`]: str::split
    ///
    /// Enwere ike iji usoro a maka data eriri bụ _terminated_, karịa _separated_ site n'ụkpụrụ.
    ///
    /// # Omume omume
    ///
    /// Onye nyochaghachiri azụ chọrọ ka ụkpụrụ ahụ kwado nchọta ntụgharị, ọ ga-ejikwa okpukpu abụọ kwụsị ma ọ bụrụ na ọchụchọ forward/reverse na-eweta otu ihe ahụ.
    ///
    ///
    /// Maka iterating site na ihu, usoro [`split_terminator`] nwere ike iji.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// An iterator n'elu substrings nke nyere eriri iberi, iche site na a ụkpụrụ, nanị na-alọta na kasị `n` ihe.
    ///
    /// Ọ bụrụ na eweghachite mkpụrụ edemede `n`, mkpụrụ nke ikpeazụ (nke bụ ``n`th substring) '' ga-enwe ihe fọdụrụnụ.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// Ihe omumu eweghachitere agaghi abu uzo abuo, n'ihi na odighi oru ikwado.
    ///
    /// Ọ bụrụ na ụkpụrụ ahụ na-enye ohere ọchụchọ ntụgharị, enwere ike iji usoro [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Complexkpụrụ dị mgbagwoju anya karị, na-eji mmechi:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// An iterator n'elu substrings a eriri iberi, iche site na a ụkpụrụ, malite na ọgwụgwụ nke eriri, nanị na-alọta na kasị `n` ihe.
    ///
    ///
    /// Ọ bụrụ na eweghachite mkpụrụ edemede `n`, mkpụrụ nke ikpeazụ (nke bụ ``n`th substring) '' ga-enwe ihe fọdụrụnụ.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// Ihe omumu eweghachitere agaghi abu uzo abuo, n'ihi na odighi oru ikwado.
    ///
    /// Maka nkewa site n'ihu, enwere ike iji usoro [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Complexkpụrụ dị mgbagwoju anya karị, na-eji mmechi:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Gbawara eriri ke akpa omume nke ahụ kwuru kpọmkwem delimiter na-alaghachi nganiihu n'ihu delimiter na suffix mgbe delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Kewaa eriri na njedebe ikpeazụ nke akara aka akọwapụtara wee laghachi prefix tupu deimitị na suffix mgbe emechara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// An iterator n'elu disjoint ọkụ nke a ụkpụrụ n'ime nyere eriri iberi.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// Onye na-edeghachi azụ ga-abụ [`DoubleEndedIterator`] ma ọ bụrụ na ụkpụrụ ahụ na-enye ohere nchọgharị na nyocha forward/reverse na-amịpụta otu ihe ahụ.
    /// Nke a bụ eziokwu n'ihi na, eg, [`char`], ma ọ bụghị n'ihi na `&str`.
    ///
    /// Ọ bụrụ na ụkpụrụ na-enye ohere a reverse search ma na ya pụta nwere ike si dị iche na a na-atụ search, na [`rmatches`] usoro ike ga-eji.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Otu onye na-edekọ ihe banyere akara egwuregwu nke ụkpụrụ dị na mpempe eriri a, na-enye iwu ka ọ gbanwee.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// The laghachi iterator na-achọ ka ụkpụrụ na-akwado a reverse search, na ọ ga-abụ a [`DoubleEndedIterator`] ma ọ bụrụ na a forward/reverse search amịrị otu ọcha.
    ///
    ///
    /// Maka iterating site na ihu, usoro [`matches`] nwere ike iji.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Otu iterator over disjoint matches of a pattern within this string slice as well as the index that the match starts at.
    ///
    /// N'ihi na ọkụ nke `pat` n'ime `self` na yitewere, naanị indices kwekọrọ na mbụ egwuregwu na-laghachi.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// Onye na-edeghachi azụ ga-abụ [`DoubleEndedIterator`] ma ọ bụrụ na ụkpụrụ ahụ na-enye ohere nchọgharị na nyocha forward/reverse na-amịpụta otu ihe ahụ.
    /// Nke a bụ eziokwu n'ihi na, eg, [`char`], ma ọ bụghị n'ihi na `&str`.
    ///
    /// Ọ bụrụ na ụkpụrụ ahụ na-enye ohere nchọta azụ mana nsonaazụ ya nwere ike ịdị iche na ọchụchọ na-aga n'ihu, enwere ike iji usoro [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // naanị `aba` mbụ
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Otu onye na-ede ihe banyere ihe egwuregwu na-adịghị na ya nke dị na `self`, wepụtara usoro ntụgharị yana ntụgharị egwuregwu ahụ.
    ///
    /// Maka ihe ndozi nke `pat` n'ime `self` nke jikọtara, naanị indices kwekọrọ na egwuregwu ikpeazụ ka eweghachiri.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Omume omume
    ///
    /// The laghachi iterator na-achọ ka ụkpụrụ na-akwado a reverse search, na ọ ga-abụ a [`DoubleEndedIterator`] ma ọ bụrụ na a forward/reverse search amịrị otu ọcha.
    ///
    ///
    /// N'ihi iterating si n'ihu, ndị [`match_indices`] usoro ike ga-eji.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // naanị `aba` ikpeazụ
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Weghachite eriri iberi na ewepu ebe na-acha ọcha na trailing wepụrụ.
    ///
    /// 'Whitespace' akọwapụtara dịka usoro nke Unicode si enweta ihe onwunwe `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Weghachite eriri iberibe ewepu ebe ọcha na-ewepụ.
    ///
    /// 'Whitespace' akọwapụtara dịka usoro nke Unicode si enweta ihe onwunwe `White_Space`.
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// `start` na a na-ekwu pụtara mbụ ọnọdụ nke na byte eriri;maka asụsụ ekpe-gaa-akanri dị ka Bekee ma ọ bụ Russian, nke a ga-abụ aka ekpe, yana asụsụ akanri-gaa-aka ekpe dị ka Arabic ma ọ bụ Hibru, nke a ga-abụ aka nri.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Alaghachi a eriri iberi na trailing whitespace wepụrụ.
    ///
    /// 'Whitespace' akọwapụtara dịka usoro nke Unicode si enweta ihe onwunwe `White_Space`.
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// `end` na a na-ekwu pụtara ikpeazụ ọnọdụ nke na byte eriri;maka a ekpe-to-nri asụsụ dị ka English ma ọ bụ Russian, a ga-abụ nri n'akụkụ, na maka nri na-ekpe asụsụ dị ka Arabic ma ọ bụ Hibru, nke a ga-ekpe.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Weghachite eriri iberibe ewepu ebe ọcha na-ewepụ.
    ///
    /// 'Whitespace' akọwapụtara dịka usoro nke Unicode si enweta ihe onwunwe `White_Space`.
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// 'Left' na a na-ekwu pụtara mbụ ọnọdụ nke na byte eriri;maka asụsụ dika Arabic ma obu Hibru nke bu 'aka nri gaa aka ekpe' karia 'aka ekpe gaa aka nri', nke a gabu akuku _right_, obughi aka ekpe.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Alaghachi a eriri iberi na trailing whitespace wepụrụ.
    ///
    /// 'Whitespace' akọwapụtara dịka usoro nke Unicode si enweta ihe onwunwe `White_Space`.
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// 'Right' na a na-ekwu pụtara ikpeazụ ọnọdụ nke na byte eriri;maka a asụsụ dị ka Arabic ma ọ bụ Hebrew nke bụ 'ikike ekpe' kama 'ekpe gaa n'aka nri', a ga-enwe _left_ akụkụ, ọ bụghị nri.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Weghachi eriri iberi na prefixes niile na suffixes dakọtara na usoro ewepụrụ ugboro ugboro.
    ///
    /// [pattern] nwere ike ịbụ [`char`], mpekere nke `` char '' s, ma ọ bụ ọrụ ma ọ bụ mmechi nke na-ekpebi ma njirimara ya dakọtara.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Complexkpụrụ dị mgbagwoju anya karị, na-eji mmechi:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Cheta egwuregwu mbu ama, mezie ya n'okpuru ma
            // egwuregwu ikpeazụ dị iche
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: A maara `Searcher` ka ọ laghachite ndenye ziri ezi.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Alaghachi a eriri iberi na niile prefixes nke dakọtara a ụkpụrụ ugboro ugboro wepụrụ.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// `start` na a na-ekwu pụtara mbụ ọnọdụ nke na byte eriri;maka asụsụ ekpe-gaa-akanri dị ka Bekee ma ọ bụ Russian, nke a ga-abụ aka ekpe, yana asụsụ akanri-gaa-aka ekpe dị ka Arabic ma ọ bụ Hibru, nke a ga-abụ aka nri.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: A maara `Searcher` ka ọ laghachite ndenye ziri ezi.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Weghachi otu iberi eriri ewepụrụ prefix.
    ///
    /// Ọ bụrụ na eriri na-amalite na ụkpụrụ `prefix`, alaghachi substring mgbe nganiihu, ọbọp ke `Some`.
    /// N`adịghị ka `trim_start_matches`, usoro a na-ewepu prefix ahụ otu oge.
    ///
    /// Ọ bụrụ na eriri ahụ amaliteghị na `prefix`, laghachi `None`.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Alaghachi a eriri iberi na suffix wepụrụ.
    ///
    /// Ọ bụrụ na eriri nsọtụ na ụkpụrụ `suffix`, laghachi na substring tupu suffix, ọbọp ke `Some`.
    /// N`adịghị ka `trim_end_matches`, usoro a na-ewepu suffix ahụ ozugbo.
    ///
    /// Ọ bụrụ na eriri adịghị akwụsị na `suffix`, laghachi `None`.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Weghachite otu iberi eriri na njiriri niile dabara na usoro ewepụrụ ugboro ugboro.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// `end` na a na-ekwu pụtara ikpeazụ ọnọdụ nke na byte eriri;maka a ekpe-to-nri asụsụ dị ka English ma ọ bụ Russian, a ga-abụ nri n'akụkụ, na maka nri na-ekpe asụsụ dị ka Arabic ma ọ bụ Hibru, nke a ga-ekpe.
    ///
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Complexkpụrụ dị mgbagwoju anya karị, na-eji mmechi:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: A maara `Searcher` ka ọ laghachite ndenye ziri ezi.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Alaghachi a eriri iberi na niile prefixes nke dakọtara a ụkpụrụ ugboro ugboro wepụrụ.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// 'Left' na a na-ekwu pụtara mbụ ọnọdụ nke na byte eriri;maka asụsụ dika Arabic ma obu Hibru nke bu 'aka nri gaa aka ekpe' karia 'aka ekpe gaa aka nri', nke a gabu akuku _right_, obughi aka ekpe.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Weghachite otu iberi eriri na njiriri niile dabara na usoro ewepụrụ ugboro ugboro.
    ///
    /// The [pattern] nwere ike ịbụ a `&str`, [`char`], a iberi nke ['char`] s, ma ọ bụ a ọrụ ma ọ bụ mmechi na-ekpebi ma ọ bụrụ na a agwa ọkụ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Ntuziaka ederede
    ///
    /// Eriri bụ usoro nke bytes.
    /// 'Right' na a na-ekwu pụtara ikpeazụ ọnọdụ nke na byte eriri;maka a asụsụ dị ka Arabic ma ọ bụ Hebrew nke bụ 'ikike ekpe' kama 'ekpe gaa n'aka nri', a ga-enwe _left_ akụkụ, ọ bụghị nri.
    ///
    ///
    /// # Examples
    ///
    /// Patternskpụrụ dị mfe:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Complexkpụrụ dị mgbagwoju anya karị, na-eji mmechi:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses a eriri iberi n'ime ọzọ ụdị.
    ///
    /// N'ihi `parse` bụ otú ofụri ofụri, ọ nwere ike ime ka nsogbu na ụdị inference.
    /// Dịka, `parse` bụ otu n'ime oge ole na ole ị ga-ahụ syntax a maara nke ọma dịka 'turbofish': `::<>`.
    ///
    /// Nke a na-enyere algorithm aka ịghọta ụdị ụdị ị na-achọ ịkọwa.
    ///
    /// `parse` nwere ike parse n'ime ụdị ọ bụla na implements na [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Ga-alaghachi [`Err`] ma ọ bụrụ na ọ gaghị ekwe omume ịkpụgharị eriri a n'ime ụdị achọrọ.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Njiji ojiji
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Iji 'turbofish' mee ihe kama ịkọwapụta `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Ghara ịtụle:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Nyochaa ma ọ bụrụ na mkpụrụ edemede niile dị na eriri a dị na ọkwa ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Anyị nwere ike ịgwọ ọ bụla byte dị ka agwa ebe a: ihe odide multibyte niile na-amalite site na byte na-adịghị na nso nso, yabụ anyị ga-akwụsị ebe ahụ.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Nyochaa na eriri abụọ bụ egwuregwu ASCII na-enweghị isi.
    ///
    /// Otu dị ka `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, mana na-enweghị ekenye na ịdegharị oge.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Atọghariri eriri a na ebe ASCII nke dị elu dị na ya.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'a' na 'z' na 'A' na 'Z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Ka ịlaghachi na a ọhụrụ uppercased uru enweghị modifying ẹdude otu, na-eji [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // NCHEKWA: mma n'ihi na anyị transmute abụọ na ụdị na otu nhọrọ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Atọghara eriri a na ASCII obere okwu ya na ya.
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'A' na 'Z' na 'a' na 'z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Ka ịlaghachi na a ọhụrụ lowercased uru enweghị modifying ẹdude otu, na-eji [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // NCHEKWA: mma n'ihi na anyị transmute abụọ na ụdị na otu nhọrọ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Weghachite onye nyocha nke gbanahụ cha cha ọ bụla na `self` na [`char::escape_debug`].
    ///
    ///
    /// Note: ọ bụ naanị ogologo eserese grapheme na-amalite eriri ga-agbanahụ.
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Laghachi ihe iterator na ndibọhọ bụla Ịsaka na `self` na [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Weghachite onye na-ekwu okwu nke gbanahụrụ char ọ bụla na `self` na [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Dị ka ihe iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Iji `println!` ozugbo:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ha abụọ kwekọrọ na:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Iji `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Emepụta efu str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Emepụta efu mutable str
    #[inline]
    fn default() -> Self {
        // SAFETY: eriri efu dị irè UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Namedị aha, aha njirimara fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAFETY: adịghị nchebe
        unsafe { from_utf8_unchecked(bytes) }
    };
}