//! Valueskpụrụ nhọrọ.
//!
//! Pịnye [`Option`] na-anọchite anya ọnụọgụ nhọrọ: [`Option`] ọ bụla bụ [`Some`] ma nwee uru, ma ọ bụ [`None`], ma ọ bụghị.
//! [`Option`] ụdị dị iche iche na koodu Rust, dịka ha nwere ọtụtụ ojiji:
//!
//! * Valueskpụrụ mbụ
//! * Weghachite ụkpụrụ maka ọrụ a na-akọwaghị n'ofe ntinye ha niile (ọrụ ele mmadụ anya n'ihu)
//! * Weghachite uru maka ịkọghị njehie dị mfe, ebe [`None`] laghachiri na njehie
//! * Nhọrọ struct ubi
//! * Ugbo ala nwere ike ịgbazinye ma ọ bụ "taken"
//! * Arụmụka ọrụ arụmụka
//! * Nullable pointers
//! * Wagbanwe ihe si n'ọnọdụ ndị siri ike
//!
//! A na-ejikọkarị '' Option`] na usoro dabara adaba iji jụọ ọnụnọ nke uru ma mee ihe, na-aza ajụjụ maka [`None`] mgbe niile.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Nloghachi nke ọrụ bụ nhọrọ
//! let result = divide(2.0, 3.0);
//!
//! // Patkpụrụ egwuregwu iji weghachite uru
//! match result {
//!     // Nkewa ahụ ziri ezi
//!     Some(x) => println!("Result: {}", x),
//!     // Nkewa ahụ abaghị uru
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Gosi otu esi eji `Option` eme ihe na otutu uzo
//
//! # Nhọrọ na ntụpọ ("nullable" pointers)
//!
//! Rust si pointer ụdị ga-mgbe na-ezo aka a nti ebe;enweghi ndenye ederede "null".Kama nke ahụ, Rust nwere akara ngosi *nhọrọ*, dịka igbe nwere nhọrọ, [``Nhọrọ\] '' <`[``Box<T>`` ''>>.
//!
//! Ihe atụ na-esote iji [`Option`] mepụta igbe nhọrọ nke [`i32`].
//! Rịba ama na iji jiri uru [`i32`] dị n'ime ya mee ihe mbụ, ọrụ `check_optional` kwesịrị iji usoro dabara iji chọpụta ma igbe ahụ ọ nwere uru (yabụ, ọ bụ [`Some(...)`][`Some`]) ma ọ bụ ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust emesi na-ebuli ndị na-esonụ ụdị `T` dị otú ahụ na [`Option<T>`] nwere otu size dị ka `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` na-achịkwa otu n'ime ụdị dị na ndepụta a.
//!
//! A na-ekwekwu ya nkwa na, maka ikpe ndị dị n'elu, mmadụ nwere ike [`mem::transmute`] site na ụkpụrụ niile dị mma nke `T` na `Option<T>` yana site na `Some::<T>(_)` ruo `T` (mana ịfegharị `None::<T>` ka `T` bụ agwa akọwaghị).
//!
//! # Examples
//!
//! Basic ụkpụrụ kenha na [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // Were okwu banyere eriri dị
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Wepu eriri dị na ya, na-ebibi nhọrọ ahụ
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Ebido nsonaazụ maka [`None`] tupu akaghị:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Ndepụta data iji chọọ.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Anyị ga-achọ aha anụmanụ kachasị ukwuu, mana ịmalite na anyị nwetara `None`.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Ugbu a, anyị ahụla aha nnukwu anụmanụ ụfọdụ
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// The `Option` ụdị.Hụ [the module level documentation](self) maka ihe ndị ọzọ.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Enweghị uru
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Valuefọdụ bara uru `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Pịnye mmejuputa
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Na-ajụ ụkpụrụ ndị dị na ya
    /////////////////////////////////////////////////////////////////////////

    /// Laghachi `true` ma ọ bụrụ na nhọrọ bụ uru [`Some`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Alaghachi `true` ma ọ bụrụ na nhọrọ bụ a [`None`] uru.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Laghachi `true` ma ọ bụrụ na nhọrọ ahụ bụ uru [`Some`] nwere uru enyere.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ihe nkwụnye maka ịrụ ọrụ na ntụaka
    /////////////////////////////////////////////////////////////////////////

    /// Na-esi na `&Option<T>` gaa `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Atọghata ihe 'nhọrọ <' ['String`]'> 'n'ime ihe' nhọrọ <'[' usize`] '>', na-echebekwa ndị mbụ.
    /// Usoro [`map`] na-ewere `self` esemokwu site na uru, na-eri nke mbụ, yabụ usoro a jiri `as_ref` buru ụzọ were `Option` ka ọ kọwaa uru dị na mbụ.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Nke mbu, gbanye `Option<String>` na `Option<&String>` na `as_ref`, wee rie *nke ahụ* na `map`, hapụ `text` na nchịkọta.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Na-esi na `&mut Option<T>` gaa `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Atọgharị site na [`Pin`]`<&Nhọrọ<T>> 'Na' nhọrọ <'[' Pin`] '<&T>>'.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // SAFETY: `x` na-ekwe nkwa na-pinned n'ihi na ọ na-abịa site `self`
        // nke a tụdoro.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Atọgharị site na [`Pin`]`<&mut Option<T>> to`` Nhọrọ <'' (``Pin`] '' <&mut T>> ``.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // ANYET: `get_unchecked_mut` anaghị eji `Option` mee ihe n'ime `self`.
        // `x` na-ekwe nkwa na-pinned n'ihi na ọ na-abịa site `self` nke pinned.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Inweta ụkpụrụ ndị dị na ya
    /////////////////////////////////////////////////////////////////////////

    /// Weghachite uru [`Some`] dị, na-eri uru `self`.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru bụ [`None`] na ozi panic omenala nke `msg` nyere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Weghachite uru [`Some`] dị, na-eri uru `self`.
    ///
    /// N'ihi na ọrụ a nwere ike panic, a naghị egbochi iji ya eme ihe.
    /// Kama nke ahụ, na-ahọrọ iji ụkpụrụ kenha na-eme nke [`None`] ikpe n'ụzọ doro anya, ma ọ bụ na-akpọ [`unwrap_or`], [`unwrap_or_else`], ma ọ bụ [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru onwe ya ruru [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Weghachite uru [`Some`] dị ma ọ bụ ndabara enyere.
    ///
    /// A na-eji esemokwu arụmụka arụ ọrụ na `unwrap_or`;ọ bụrụ na ị na-agafe nsonaazụ nke oku ọrụ, a na-atụ aro ka ị jiri [`unwrap_or_else`], nke a na-enyocha umengwụ.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Weghachite uru [`Some`] dị ma ọ bụ gbakọọ ya site na mmechi.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Weghachi uru [`Some`] dị, na-eri uru `self`, na-enweghị ịlele na uru ahụ abụghị [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Kpọ usoro a na [`None`] bụ *[omume a na-akọwaghị]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Undefined omume!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // MGBE: a ga-akwado nkwekọrịta nchekwa site n'aka onye na-akpọ oku.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Gbanwe nwere ụkpụrụ
    /////////////////////////////////////////////////////////////////////////

    /// Map ihe `Option<T>` ka `Option<U>` site n'itinye a ọrụ na-a nwere uru.
    ///
    /// # Examples
    ///
    /// Na-agbanwe ``nhọrọ <'' (`` String`] ''>`` na nhọrọ '', `` na-eri ihe mbụ:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` ewe onwe *site uru*, ewe `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Na-etinye ọrụ na uru dị (ma ọ bụrụ na ọ bụla), ma ọ bụ weghachite ndabara enyere (ma ọ bụrụ na ọ bụghị).
    ///
    /// A na-eji esemokwu arụmụka arụ ọrụ na `map_or`;ọ bụrụ na ị na-agafe nsonaazụ nke oku ọrụ, a na-atụ aro ka ị jiri [`map_or_else`], nke a na-enyocha umengwụ.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Na-etinye ọrụ na uru dị (ma ọ bụrụ na ọ bụla), ma ọ bụ na-agbakọta ndabara (ma ọ bụrụ na ọ bụghị).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Agbanwe ndị `Option<T>` n'ime a [`Result<T, E>`], nkewa [`Some(v)`] ka [`Ok(v)`] na [`None`] ka [`Err(err)`].
    ///
    /// Arụmụka arụmụka ndị nyefere na `ok_or` ji ịnụ ọkụ n'obi nyochaa;ọ bụrụ na ị na-agafe nsonaazụ nke oku ọrụ, a na-atụ aro ka ị jiri [`ok_or_else`], nke a na-enyocha umengwụ.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// Gbanwee `Option<T>` ka ọ bụrụ [`Result<T, E>`], maapụ [`Some(v)`] ka [`Ok(v)`] na [`None`] gaa [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Inserts `value` n'ime nhọrọ mgbe laghachi a mutable banyere ya.
    ///
    /// Ọ bụrụ na nhọrọ ahụ nwere uru, uru ochie ga-adaba.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // SAFETY: koodu dị n'elu dị nnọọ jupụta nhọrọ
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ndị na-arụ ọrụ Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Weghachite onye na-ede akwụkwọ maka uru enwere.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Laghachi a mutable iterator ihe nwere ike ịbụ nwere uru.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ọrụ Boolean na ụkpụrụ, ịnụ ọkụ n'obi na umengwụ
    /////////////////////////////////////////////////////////////////////////

    /// Weghachi [`None`] ma ọ bụrụ na nhọrọ ahụ bụ [`None`], ma ọ laghachite `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Weghachi [`None`] ma ọ bụrụ na nhọrọ ahụ bụ [`None`], ma ọ bụghị `f` na-akpọ ya na uru ejiri ma kee nsonaazụ.
    ///
    ///
    /// Languagesfọdụ asụsụ na-akpọ ọrụ a flatmap.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Laghachi [`None`] ma ọ bụrụ na nhọrọ ahụ bụ [`None`], ma ọ bụghị `predicate` na-akpọ ya na uru ekpuchi ma laghachi:
    ///
    ///
    /// - [`Some(t)`] ọ bụrụ na `predicate` laghachiri `true` (ebe `t` bụ uru a fụchiri), na
    /// - [`None`] ọ bụrụ na `predicate` laghachiri `false`.
    ///
    /// Ọrụ a na-arụ ọrụ dịka [`Iterator::filter()`].
    /// Nwere ike iche n`echiche nke `Option<T>` bụ onye na-emegharị otu ihe ma ọ bụ ihe efu.
    /// `filter()` na-ahapụ gị ikpebi ihe ndị ị ga-edebe.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Weghachite nhọrọ ma ọ bụrụ na ọ nwere uru, ma ọ laghachi na `optb`.
    ///
    /// Arụmụka arụmụka ndị nyefere na `or` ji ịnụ ọkụ n'obi nyochaa;ma ọ bụrụ na ị na-agafe n'ihi nke a ọrụ oku, ọ na-atụ aro iji [`or_else`], nke a na lazily inyocha.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// - Alaghachi na nhọrọ ma ọ bụrụ na ọ nwere a bara uru, ma ọ bụghị na-akpọ `f` na-alaghachikwuru N'ihi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Weghachi [`Some`] ma ọ bụrụ na otu nke `self`, `optb` bụ [`Some`], ma ọ bụghị laghachi [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ntinye-dị ka arụmọrụ iji tinye ma ọ bụrụ na Ọ dịghị onye ma weghachite ntinye aka
    /////////////////////////////////////////////////////////////////////////

    /// Ntinye `value` n'ime nhọrọ ma ọ bụrụ na ọ bụ [`None`], wee weghachite ntụgharị ntụgharị maka uru dị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Inser ndabara uru n'ime nhọrọ ma ọ bụrụ na ọ bụ [`None`], wee laghachi a mutable akwụkwọ na ẹdude uru.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Ntinye uru agbakọtara site na `f` n'ime nhọrọ ahụ ma ọ bụrụ na ọ bụ [`None`], wee weghachite ntụgharị ntụgharị maka uru dị.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // Nchedo: ụdị `None` maka `self` ka `Some` ga-anọchi ya
            // variant na koodu n'elu.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Nara uru site na nhọrọ ahụ, na-ahapụ [`None`] n'ọnọdụ ya.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Anọchie Anya n'ezie uru na nhọrọ site uru e nyere na oke, na-alọta ochie uru ma ọ bụrụ ugbu a, na-ahapụ a [`Some`] ya ebe na-enweghị deinitializing ma otu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Zips `self` na `Option` ọzọ.
    ///
    /// Ọ bụrụ na `self` bụ `Some(s)` na `other` bụ `Some(o)`, usoro a ga-alaghachi `Some((s, o))`.
    /// Ma ọ bụghị ya, `None` laghachiri.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zips `self` na `Option` ọzọ nwere `f` ọrụ.
    ///
    /// Ọ bụrụ na `self` bụ `Some(s)` na `other` bụ `Some(o)`, usoro a ga-alaghachi `Some(f(s, o))`.
    /// Ma ọ bụghị ya, `None` laghachiri.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Maapụ `Option<&T>` na `Option<T>` site na i copomi ọdịnaya nke nhọrọ ahụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Maapụ `Option<&mut T>` na `Option<T>` site na i copomi ọdịnaya nke nhọrọ ahụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Maapụ `Option<&T>` na `Option<T>` site na cloning ọdịnaya nke nhọrọ ahụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Maapụ `Option<&mut T>` na `Option<T>` site na cloning ọdịnaya nke nhọrọ ahụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Na-eri `self` mgbe ị na-atụ anya [`None`] ma weghachite ihe ọ bụla.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru bụ [`Some`], yana ozi panic tinyere ozi a gafere, yana ọdịnaya nke [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Nke a agaghị panic, ebe igodo niile bụ ihe pụrụ iche.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Na-eri `self` mgbe ị na-atụ anya [`None`] ma weghachite ihe ọ bụla.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na uru ahụ bụ [`Some`], yana ozi panic omenala nyere site na uru [``Some`].
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Nke a agaghị panic, ebe igodo niile bụ ihe pụrụ iche.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Weghachi uru [`Some`] dị ma ọ bụ ndabara
    ///
    /// Na-eri arụmụka `self` mgbe ahụ, ọ bụrụ na [`Some`], weghachite uru dị, ma ọ bụrụ na [`None`], weghachite [default value] maka ụdị ahụ.
    ///
    ///
    /// # Examples
    ///
    /// Na-atụgharị eriri na ọnụ ọgụgụ, na-atụgharị ụdọ emezighituri n'ime 0 (uru ndabara maka ọnụ ọgụgụ).
    /// [`parse`] na-atụgharị eriri na ụdị ọ bụla ọzọ nke na-etinye [`FromStr`] n'ọrụ, na-alọghachi [`None`] na njehie.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Na-esi na `Option<T>` (ma ọ bụ `&Option<T>`) gaa `Option<&T::Target>`.
    ///
    /// Na-ahapụ nhọrọ mbụ na ebe, na-ekepụta ihe ọhụrụ na-ezo aka na nke mbụ, na-agbakwunye ọdịnaya site na [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Na-esi na `Option<T>` (ma ọ bụ `&mut Option<T>`) gaa `Option<&mut T::Target>`.
    ///
    /// Na-ahapụ `Option` mbụ na-ebe, na-ekepụta ihe ọhụrụ nke nwere ntụgharị ntụgharị maka ụdị `Deref::Target` dị n'ime.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// Na-ebugharị `Option` nke [`Result`] na [`Result`] nke `Option`.
    ///
    /// [`None`] ga-egosi na (``Ok`] '' (`` Ọ dịghị onye]] ''.
    /// (``Some`] '' (``(`` Ok`] '' (_)) '' na (`` Some`] '' (`` (``Err`] '' (_)) ga-abanye na '[' Some`] '(_))' na ['Err`]' (_) '.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Nke a bụ ọrụ dị iche iche iji belata ogo koodu nke .expect() n'onwe ya.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Nke a bụ a dị iche iche ọrụ iji belata code size of .expect_none() onwe ya.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Mmejuputa Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Laghachi [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// O weghachitere onye na-eri ihe na-eri ihe.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Detuo `val` n'ime `Some` ohuru.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Na-esi na `&Option<T>` gaa `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Atọghata ihe 'nhọrọ <' ['String`]'> 'n'ime ihe' nhọrọ <'[' usize`] '>', na-echebekwa ndị mbụ.
    /// Usoro [`map`] na-ewere `self` esemokwu site na uru, na-eri nke mbụ, yabụ usoro a jiri `as_ref` buru ụzọ were `Option` ka ọ kọwaa uru dị na mbụ.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Atọghata si `&mut Option<T>` ka `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// The nhọrọ Iterators
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Otu iterator banyere ihe [`Some`] di iche nke [`Option`].
///
/// The iterator amịrị otu uru ma ọ bụrụ na [`Option`] bụ a [`Some`], ma ọ bụghị onye ọ bụla.
///
/// Emebere `struct` a site na ọrụ [`Option::iter`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Otu onye na-ede ihe karịrị ihe ntụgharị [`Some`] nke [`Option`].
///
/// The iterator amịrị otu uru ma ọ bụrụ na [`Option`] bụ a [`Some`], ma ọ bụghị onye ọ bụla.
///
/// Emebere `struct` a site na ọrụ [`Option::iter_mut`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// An iterator n'elu uru [`Some`] variant nke ihe [`Option`].
///
/// The iterator amịrị otu uru ma ọ bụrụ na [`Option`] bụ a [`Some`], ma ọ bụghị onye ọ bụla.
///
/// Emebere `struct` a site na ọrụ [`Option::into_iter`].
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Were ihe ọ bụla na [`Iterator`]: ọ bụrụ na ọ bụ [`None`][Option::None], a naghị ewepụta ihe ndị ọzọ, na [`None`][Option::None] eweghachitere.
    /// Ekwesighi [`None`][Option::None] ime, a na-eweghachi akpa nwere ụkpụrụ nke [`Option`] ọ bụla.
    ///
    /// # Examples
    ///
    /// Nke a bụ ihe atụ nke na-agbakwunye integer ọ bụla na vector.
    /// Anyị na-eji ụdị dị iche iche nke `add` nke na-alọghachi `None` mgbe ngụkọta oge ga-eme ka ọ jubiga ókè.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Dị ka ị pụrụ ịhụ, a ga-alaghachi na-atụ anya, irè ihe.
    ///
    /// Nke a bụ ihe atụ ọzọ nke na-anwa iwepu otu na ndepụta nke nọmba ndị ọzọ, oge a na-achọpụta maka mmiri:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Ebe ọ bụ na ihe ikpeazụ bụ efu, ọ ga-asọpụta.Ya mere, uru bara uru bụ `None`.
    ///
    /// Ebe a bụ a mgbanwe na aga atụ, na-egosi na ọ dịghị ihe ọzọ ihe na-e si `iter` mgbe mbụ `None`.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Ebe ọ bụ na ihe nke atọ mere ka mmiri ghara ịda, anaghị ewere ihe ọzọ, yabụ uru ikpeazụ nke `shared` bụ 6 (= `3 + 2 + 1`), ọ bụghị 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Enwere ike iji Iterator::scan dochie ihe a mgbe emechiri arụmọrụ a.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// Dị njehie nke na-esite na itinye (`?`) ọrụ na-anwale ọrụ na uru `None`.
/// Ọ bụrụ n`ịchọrọ ikwe ka `x?` (ebe `x` bụ `Option<T>`) ka a gbanwee ya banye n`ụdị njehie gị, ịnwere ike itinye `impl From<NoneError>` maka `YourErrorType`.
///
/// N'okwu ahụ, `x?` n'ime ọrụ na-alọghachi `Result<_, YourErrorType>` ga-atụgharị uru `None` na nsonaazụ `Err`.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Na-esi na `Option<Option<T>>` gaa `Option<T>`
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Abadaba naanị ewepu otu larịị nke nesting na a oge:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}