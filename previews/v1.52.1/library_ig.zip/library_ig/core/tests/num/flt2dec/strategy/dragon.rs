use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri dị oke nwayọ
fn exact_sanity_test() {
    // Ule a na-agwụ ihe m nwere ike iche na ọ bụ ụfọdụ akụkụ-ish banyere ọrụ ọbá akwụkwọ `exp2`, akọwapụtara na oge C ọ bụla anyị na-eji.
    // Na VS 2013, ọrụ a nwere ahụhụ dịka ule a na-ada ada mgbe ejikọtara ya, mana VS 2015 ahụhụ ahụ gosipụtara dịka ule ahụ na-aga nke ọma.
    //
    // The ebe o yiri ka a dị iche na nloghachi uru nke `exp2(-1057)`, ebe ke VS 2013 ọ laghachi a abụọ na bit ụkpụrụ 0x2 na VS 2015 na ọ na-alaghachikwuru 0x20000.
    //
    //
    // N'ihi na ugbu a dị nnọọ eleghara a ule kpamkpam na MSVC dị ka ọ na-anwale n'ebe ọzọ na agbanyeghị na anyị na-adịghị super nwere mmasi na-anwale kwa n'elu ikpo okwu na-exp2 mmejuputa.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}