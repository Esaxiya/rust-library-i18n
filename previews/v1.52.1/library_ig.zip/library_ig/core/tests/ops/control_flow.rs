use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Nke a abụghị anụ n'elu ebe, ma na-enyere aka nọgide na-`?` ọnụ ala n'etiti ha, ọbụna ma ọ bụrụ LLVM nwere ike ọ bụghị mgbe niile na-uru nke ya ugbu a.
    //
    // (Nsonaazụ na Nhọrọ adịghị agbanwe agbanwe, yabụ ControlFlow enweghị ike ijikọ ha abụọ.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}