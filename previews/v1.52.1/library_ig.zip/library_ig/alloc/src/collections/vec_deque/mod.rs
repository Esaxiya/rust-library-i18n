//! A kwụ n'ahịrị na-akwụsị na-etinyere na a na-eto eto na-echekwa mgbanaka.
//!
//! Nke a kwụ n'ahịrị nwere *O*(1) amortized inserts na mwepụ si na nsọtụ abụọ nke akpa.
//! O nwekwara ndenye aha *O*(1) dịka vector.
//! Achọghị ka ihe ndị dị na ya bụrụ ndị a ga-atụgharị, na a ga-eziga kwụ n'ahịrị ma ọ bụrụ na ụdị dị na ya bụ nke ezigara.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Ike kachasị dị ike nke abụọ

/// A kwụ n'ahịrị na-akwụsị na-etinyere na a na-eto eto na-echekwa mgbanaka.
///
/// Ojiji "default" nke ụdị a dị ka kwụ n'ahịrị bụ iji [`push_back`] gbakwunye na kwụ n'ahịrị, yana [`pop_front`] wepu na kwụ n'ahịrị.
///
/// [`extend`] na [`append`] na-agbanye azụ n'azụ n'ụzọ a, na ịgagharị `VecDeque` na-aga n'ihu azụ.
///
/// Ebe ọ bụ na `VecDeque` bụ ihe mgbanaka mgbanaka, ihe ndị dị na ya adịchaghị na nchekwa.
/// Ọ bụrụ na ịchọrọ ịnweta ihe ndị ahụ dịka otu iberi, dịka maka nhazi nke ọma, ịnwere ike iji [`make_contiguous`].
/// Ọ na-atụgharị `VecDeque` ka ihe ya wee ghara kechie, wee weghachite iberibe ihe ntụgharị na usoro mmewere ugbu a.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // ọdụ na isi bụ ntụaka n'ime nchekwa.
    // Tail na-egosi mgbe niile ihe mbụ enwere ike ịgụ, Isi na-arụtụ aka ebe aga-ede data.
    //
    // Ọ bụrụ na ọdụ==buru ebe nchekwa na-efu.A kọwara ogologo nke ringbuffer dị ka ebe dị anya n'etiti abụọ.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Onye na-ebibi ihe niile na-agba ọsọ mgbe ọ dabara (mgbe niile ma ọ bụ n'oge ịhapụ ya).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // jiri dobe maka [T]
            ptr::drop_in_place(front);
        }
        // RawVec na-edozi nkwekọrịta
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Mepụta `VecDeque<T>` efu.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Mara oke adaba
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Mara oke adaba
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Maka ụdị ụdị efu, anyị na-enwekarị ikike kachasị
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Gbanye ptr ka iberi
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Gbanye ptr ka ọ bụrụ mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Na-eme ka mmewere site na nchekwa ahụ
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Na-ede ihe mmewere n'ime nchekwa, na-ebugharị ya.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Laghachi `true` ma ọ bụrụ na nchekwa ahụ zuru oke.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// O weghachitere ndeksi na ihe nkpuchi di n'okpuru maka ihe omuma ihe ezi uche di na ya.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Weghachite ndeksi na ihe nchekwa maka ihe enyere maka ndenye ihe ezi uche dị na ya + tinye.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// O weghachitere ndeksi na ihe nkpuchi di n'okpuru maka ihe omuma ihe ezi uche di na ya, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Detuo ihe ngọngọ nke nchekwa nke sitere na src ruo dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Detuo ihe ngọngọ nke nchekwa nke sitere na src ruo dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Detuo ihe nwere ike imechi ebe nchekwa echere ogologo oge site na src ruo ebe.
    /// (abs(dst - src) + len) aghaghi ibu karịa cap() (Ọ ga-abụrịrị na otu mpaghara na-aga n'ihu na-agagharị n'etiti src na njedebe).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src anaghị ekechi, dst anaghị ekechi
                //
                //        S..
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst tupu src, src anaghị ekechi, dst eyiri
                //
                //
                //    S..
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src tupu dst, src anaghị ekechi, dst eyiri
                //
                //
                //              S..
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst tupu src, src eyiri, dst anaghị ekechi
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src tupu dst, src eyiri, dst anaghị ekechi
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst tupu src, src eyiri, dst eyiri
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src tupu dst, src na-ekpuchi, dst eyiri
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs isi na ọdụ n'akụkụ gburugburu aka eziokwu na anyị dị reallocated.
    /// Enweghị nchedo n'ihi na ọ tụkwasịrị old_capacity obi.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Bugharịa ihe kachasị dị mkpirikpi nke mgbanaka mgbanaka TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Mepụta `VecDeque` efu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Mepụta `VecDeque` efu na oghere maka opekata mpe `capacity` ihe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 ebe ọ bụ na ringbuffer na-ahapụ otu oghere mgbe niile
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Na-enye ntụaka maka mmewere na ndeksi enyere.
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Na-enye ntụgharị ntụgharị okwu banyere mmewere na ndeksi edere.
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Ihe ntụgharị Swaps na indices `i` na `j`.
    ///
    /// `i` na `j` nwere ike ịha nha.
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ndekota abuo n`ime oke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Weghachi ọnụọgụ nke ihe `VecDeque` nwere ike ijide na-enweghị mmegharị ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Echebe ikike opekempe maka kpọmkwem `additional` ihe ndị ọzọ ka etinyere na `VecDeque` enyere.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// Rịba ama na onye na-ekenye ya nwere ike inye nchịkọta ahụ ohere karịa ka ọ chọrọ.
    /// Ya mere ikike-apụghị ịdabere na-abụ kpomkwem ntakiri.
    /// Na-ahọrọ [`reserve`] ma ọ bụrụ na a na-atụ anya ntinye ntinye future.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ikike ohuru ejuputa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Echebe ikike maka opekata mpe `additional` ihe ndị ọzọ ka etinyere na `VecDeque` enyere.
    /// Nchịkọta ahụ nwere ike idowe ohere dị ukwuu iji zere ịmegharị ọtụtụ oge.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ikike ohuru ejuputa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Gbalịa idowe ikike opekempe maka kpọmkwem ihe `additional` a ga-etinye na ihe `VecDeque<T>` enyere.
    ///
    /// Mgbe akpọchara `try_reserve_exact`, ikike ga-adị ukwuu karịa ma ọ bụ hara nhata `self.len() + additional`.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// Rịba ama na onye na-ekenye ya nwere ike inye nchịkọta ahụ ohere karịa ka ọ chọrọ.
    /// Ya mere, ikike-apụghị ịdabere na-abụ kpomkwem ntakiri.
    /// Na-ahọrọ `reserve` ma ọ bụrụ na a na-atụ anya ntinye ntinye future.
    ///
    /// # Errors
    ///
    /// Ọ bụrụ na ikike ahụ tofere `usize`, ma ọ bụ onye na-ekenye ihe kọọrọ ọdịda, mgbe ahụ eweghachitere njehie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Debe ebe nchekwa ahụ, na-apụ ma ọ bụrụ na anyị enweghị ike
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ugbu a, anyị maara na nke a enweghị ike OOM(Out-Of-Memory) n'etiti ọrụ mgbagwoju anya anyị
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // dị mgbagwoju anya
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Gbalịa ịchekwa ikike maka opekata mpe `additional` ihe ndị ọzọ ka etinyere na `VecDeque<T>` enyere.
    /// Nchịkọta ahụ nwere ike idowe ohere dị ukwuu iji zere ịmegharị ọtụtụ oge.
    /// Mgbe akpọchara `try_reserve`, ikike ga-adị ukwuu karịa `self.len() + additional`.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// # Errors
    ///
    /// Ọ bụrụ na ikike ahụ tofere `usize`, ma ọ bụ onye na-ekenye ihe kọọrọ ọdịda, mgbe ahụ eweghachitere njehie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Debe ebe nchekwa ahụ, na-apụ ma ọ bụrụ na anyị enweghị ike
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ugbu a anyị maara na nke a enweghị ike OOM n`etiti ọrụ dị mgbagwoju anya anyị
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // dị mgbagwoju anya
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Ibelata ikike nke `VecDeque` dị ka o kwere mee.
    ///
    /// Ọ ga-agbadata dịka o kwere mee n'ogologo mana onye na-ekenye ya ka nwere ike ịgwa `VecDeque` na enwere ohere maka ihe ole na ole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Ibelata ikike nke `VecDeque` na obere ala.
    ///
    /// Ikike ahụ ga-adịgide ma ọ dịkarịa ala ka o buru ibu dị ka ogologo ma ogologo.
    ///
    ///
    /// Ọ bụrụ na ikike dị ugbu a dị obere karịa oke ala, nke a bụ enweghị op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Anyi ekwesighi ichegbu onwe anyi banyere oke dika `self.len()` ma obu `self.capacity()` abughi `usize::MAX`.
        // +1 dị ka ringbuffer mgbe niile na-ahapụ otu oghere efu.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Enwere mmasị atọ:
            //   Ihe niile n`adịghị oke chọrọ Ihe dị iche iche chọrọ, ma isi si n`ọdachi chọrọ. Elements bụ disquiguous, ọdụ adịghịkwa achọ
            //
            //
            // N'oge ndị ọzọ niile, anaghị emetụta ọnọdụ mmewere.
            //
            // Na-egosi na enwere ike imegharị ihe ndị dị n'isi ya.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Bugharịa ihe site na ókè achọrọ (ọnọdụ mgbe target_cap)
            if self.tail >= target_cap && head_outside {
                // Nke
                //   [. . . . . . . . o o o o o o o . ]
                //    Nke
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // Nke
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Na-ebelata `VecDeque`, na-edebe ihe mbụ `len` na idobe ndị ọzọ.
    ///
    ///
    /// Ọ bụrụ na `len` karịrị nke VecDeque` ugbu a, nke a enweghị mmetụta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Onye na-ebibi ihe niile na-agba ọsọ mgbe ọ dabara (mgbe niile ma ọ bụ n'oge ịhapụ ya).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Nchekwa n'ihi:
        //
        // * Mpempe ọ bụla enyere na `drop_in_place` dị irè;okwu nke abụọ nwere `len <= front.len()` ma laghachi na `len > self.len()` na-eme ka o doo anya `begin <= back.len()` na nke mbụ
        //
        // * Isi nke VecDeque kpaliri tupu ị kpọọ `drop_in_place`, yabụ enweghị uru ọ bụla dabara ugboro abụọ ma ọ bụrụ `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Gbalia ihu na agbadala nke abuo obuna mgbe nbibi n`ime nke mbu panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Weghachite ihu azụ na azụ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Weghachite nzaghachi ihu na azụ nke weghachite ntụgharị ntụgharị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SAFETY: Esịtidem `IterMut` nchekwa invariant na-guzobere n'ihi na
        // `ring` anyị ike bụ a dereferencable iberi maka ndụ '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Weghachite otu ụzọ Mpekere nke nwere, n'usoro, ọdịnaya nke `VecDeque`.
    ///
    /// Ọ bụrụ na akpọburu [`make_contiguous`], ihe niile nke `VecDeque` ga-adị na ibe mbu na nkebi nke abụọ ga-efu.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Weghachite otu ụzọ Mpekere nke nwere, n'usoro, ọdịnaya nke `VecDeque`.
    ///
    /// Ọ bụrụ na akpọburu [`make_contiguous`], ihe niile nke `VecDeque` ga-adị na ibe mbu na nkebi nke abụọ ga-efu.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Weghachite onu ogugu nke ihe na `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Laghachi `true` ma ọ bụrụ na `VecDeque` efu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Na-emepụta iterator nke na-ekpuchi ọkwa akọwapụtara na `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na mbido kariri njedebe ma obu ma ogwugwu ihe kariri ogologo vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ọnụ ọgụgụ zuru ezu na-ekpuchi ọdịnaya niile
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Ekekọrịta ederede anyị nwere na &self dị na '_ nke Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Na-emepụta iterator nke na-ekpuchi ụdị mgbanwe a kapịrị ọnụ na `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na mbido kariri njedebe ma obu ma ogwugwu ihe kariri ogologo vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ọnụ ọgụgụ zuru ezu na-ekpuchi ọdịnaya niile
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SAFETY: Esịtidem `IterMut` nchekwa invariant na-guzobere n'ihi na
        // `ring` anyị ike bụ a dereferencable iberi maka ndụ '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Na-emepụta onye na-agba mmiri na-ewepu ihe akọwapụtara na `VecDeque` ma na-amịpụta ihe ndị ewepụrụ.
    ///
    /// Rịba ama 1: A na-ewepụ ihe mmewere ọbụlagodi ma ọ bụrụ na anaghị egbuchapụta iterator ruo na njedebe.
    ///
    /// Rịba ama 2: Achọpụtabeghị ọtụtụ ihe na-ewepụ site na iwu ahụ, ma ọ bụrụ na uru `Drain` adịghị adaba, mana mgbazinye ego ọ na-ejedebe (dịka, n'ihi `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics ma oburu na mbido kariri njedebe ma obu ma ogwugwu ihe kariri ogologo vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Oke zuru oke na-ekpochapụ ọdịnaya niile
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Nchekwa ebe nchekwa
        //
        // Mgbe mbu emeputara Drain, isi iyi a na-eme ka ọ dị mkpụmkpụ iji jide n'aka na ọ nweghị ihe omuma ma ọ bụ na-esite na ihe ndị nwere ike ịnweta ma ọ bụrụ na onye mbibi Drain anaghị agba ọsọ.
        //
        //
        // Drain ga ptr::read wepụ ụkpụrụ iji wepu.
        // Mgbe emechara ya, a ga-edepụtaghachi data fọdụrụ iji kpuchie oghere ahụ, a ga-eweghachi ụkpụrụ head/tail n'ụzọ ziri ezi.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // E kewapụrụ ihe ndị ahụ ndị omekome na ngalaba atọ:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Anyị na-echekwa drain_tail dị ka self.head, na drain_head na self.head dị ka after_tail na after_head n'otu n'otu na Drain.
        // Nke a na-ebelata usoro dị irè nke na ọ bụrụ na Drain agbapụ, anyị echefuola maka ụkpụrụ ndị nwere ike ibugharị mgbe mmalite nke drain.
        //
        //
        //        Nke abu H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" banyere ụkpụrụ mgbe mmalite nke drain ruo mgbe drain zuru ezu na Drain nbibi na-agba ọsọ.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // N`ụzọ dị oke mkpa, naanị anyị na-ekepụta ntụnye aka sitere na `self` ebe a ma gụọ ya.
                // Anyị anaghị edegara `self` ma ọ bụ weghachite na ntụgharị ntụgharị.
                // N'ihi ya, pointer raw anyị kere n'elu, maka `deque`, ka dị irè.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Na-ekpochapụ `VecDeque`, na-ewepu ụkpụrụ niile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Laghachi `true` ma ọ bụrụ na `VecDeque` nwere mmewere hà na nke enyere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Na-enye ntụaka maka mmewere ihu, ma ọ bụ `None` ma ọ bụrụ na `VecDeque` bụ ihe efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Na-enye ntụgharị ihu maka ihu ihe n'ihu, ma ọ bụ `None` ma ọ bụrụ na `VecDeque` bụ ihe efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Na-enye aka maka akụkụ azụ, ma ọ bụ `None` ma ọ bụrụ na `VecDeque` bụ ihe efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Na-enye ntụgharị ntụgharị maka mmezu azụ, ma ọ bụ `None` ma ọ bụrụ na `VecDeque` bụ ihe efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Wepu ihe mbu ma weghachite ya, ma obu `None` ma oburu na `VecDeque` efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Wepu ihe ikpeazụ na `VecDeque` wee weghachite ya, ma ọ bụ `None` ọ bụrụ na ọ tọgbọ chakoo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Na-akwado ihe mmewere na `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Gbakwunye ihe mmewere na azụ nke `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Anyị kwesịrị ịtụle `head == 0` pụtara
        // na `self` bụ contiguous?
        self.tail <= self.head
    }

    /// Ewepu mmewere site na ebe ọ bụla na `VecDeque` wee weghachite ya, dochie ya na ihe mbido.
    ///
    ///
    /// Nke a anaghị echekwa ịtụ, mana ọ bụ *O*(1).
    ///
    /// Laghachi `None` ma ọ bụrụ na `index` gafere oke.
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Wepu mmewere site na ebe ọ bụla na `VecDeque` wee weghachite ya, dochie ya na mmewere ikpeazụ.
    ///
    ///
    /// Nke a anaghị echekwa ịtụ, mana ọ bụ *O*(1).
    ///
    /// Laghachi `None` ma ọ bụrụ na `index` gafere oke.
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Fanye ihe mmewere na `index` n'ime `VecDeque`, na-agbanwe ihe niile nwere indices karịrị ma ọ bụ hà `index` na azụ.
    ///
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `index` karịrị 'VecDeque' n'ogologo
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Bugharịa ihe kacha nta na ihe dị na nchekwa nchekwa ma tinye ihe enyere
        //
        // Na ọtụtụ len/2, 1 ọcha ga-akpali. O(min(n, n-i))
        //
        // Enwere ụzọ okwu atọ:
        //  Ihe dị iche iche
        //      - ikpe pụrụ iche mgbe ọdụ bụ 0 Elements bụ discontiguous na fanye dị na ọdụ ọdụ Elements are discontiguous and the insert is in the head section
        //
        //
        // Maka nke ọ bụla n'ime ha, e nwere ikpe abụọ ọzọ:
        //  Fanye dị nso na ọdụ Fanye dị nso n'isi
        //
        // Igodo: H, self.head
        //      T, self.tail o, Valid element I, Inserment element A, Ihe mmewere nke kwesiri ịbụ mgbe ntinye ntinye M, Na-egosi mmegharị kpaliri
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // contiguous, fanye nso na ọdụ:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           Nke
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // contiguous, fanye nso na ọdụ na ọdụ bụ 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Ugbua ebugharị ọdụ ahụ, yabụ anyị na-e copyomi ihe `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguous, fanye nso ka isi:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             Nke
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, fanye nso ọdụ, ọdụ ngalaba:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, fanye nso ka isi, ọdụ ngalaba:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // detuo ihe ruo n'isi ọhụrụ
                    self.copy(1, 0, self.head);

                    // Detuo ihe ikpeazụ n'ime oghere na ala nke nchekwa
                    self.copy(0, self.cap() - 1, 1);

                    // megharia ihe site na idx ka o ghaa n'ihu gaba tinyere ^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, fanye nso ọdụ, isi ngalaba, ma ọ bụ na ndeksi efu na esịtidem echekwa:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // Detuo ihe ruo ọdụ ọhụrụ
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // Detuo ihe ikpeazụ n'ime oghere na ala nke nchekwa
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, fanye nso na ọdụ, isi ngalaba:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // Detuo ihe ruo ọdụ ọhụrụ
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // Detuo ihe ikpeazụ n'ime oghere na ala nke nchekwa
                    self.copy(self.cap() - 1, 0, 1);

                    // megharia ihe site na idx-1 ka o kwusi n'ihu gunyeghi mmewere
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, fanye nso ka isi, isi ngalaba:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // O nwere ike ịbụ na a gbanwere ọdụ ka anyị kwesịrị ịgbakọ
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Wepu ma laghachi ihe mmewere na `index` site na `VecDeque`.
    /// Ihe ọ bụla nke dị nso na ebe mwepụ ga-akwaga iji nye ohere, a ga-akpali ihe ndị niile emetụtara na ọnọdụ ọhụrụ.
    ///
    /// Laghachi `None` ma ọ bụrụ na `index` gafere oke.
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Enwere ụzọ okwu atọ:
        //  Elements bụ contiguous Elements bụ discontiguous na mwepụ dị ọdụ ọdụ Elements bụ discontiguous na mwepụ dị n'isi ngalaba
        //
        //      - ikpe pụrụ iche mgbe ihe dị iche iche na-arụ ọrụ na teknụzụ, mana self.head =0
        //
        // Maka nke ọ bụla n'ime ha, e nwere ikpe abụọ ọzọ:
        //  Fanye dị nso na ọdụ Fanye dị nso n'isi
        //
        // Igodo: H, self.head
        //      T, self.tail o, Valid element x, Element akara maka iwepụ R, Na-egosi mmewere na-ewepụ M, Na-egosi mmewere kpaliri
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // agbagha, wepu nso na ọdụ:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               Nke
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // agbagha, wepu nso n'isi:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             Nke
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, wepu nso na ọdụ, ọdụ ọdụ:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // disquiguous, wepu nso n'isi, isi ngalaba:
                    //
                    //               Nkịtị
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // disquiguous, wepu nso n'isi, ọdụ aka:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // ma ọ bụ ihe na-enweghị atụ, wepu n'akụkụ isi, ngalaba ọdụ:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         Nke
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // see ihe di n`ime akuku odu
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Na-egbochi okpuru mmiri.
                    if self.head != 0 {
                        // detuo ihe izizi n'ime ebe tọgbọ chakoo
                        self.copy(self.cap() - 1, 0, 1);

                        // megharia ihe na isi na azu azu
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // disquiguous, wepu nso odu, isi ngalaba:
                    //
                    //           Nkịtị
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // see ihe rue idx
                    self.copy(1, 0, idx);

                    // Detuo ihe ikpeazụ n'ime ntụpọ efu
                    self.copy(0, self.cap() - 1, 1);

                    // megharia ihe site na ọdụ ka ọ gwụchaa, ewepu nke ikpeazụ
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Na-ekewa `VecDeque` ụzọ abụọ na ndeksi edere.
    ///
    /// Weghachite `VecDeque` ohuru.
    /// `self` nwere ihe `[0, at)`, na `VecDeque` laghachiri nwere ihe `[at, len)`.
    ///
    /// Rịba ama na ikike nke `self` anaghị agbanwe agbanwe.
    ///
    /// Element na ndekota 0 bụ n'ihu kwụ n'ahịrị.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` idu ke akpa ọkara.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // were naanị ọkara nke abụọ.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` idu na nkera nke abụọ, kwesịrị ịtụle ihe ndị anyị na-awụlị n'ọkara nke mbụ.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Nzacha na mkpocha ebe njedebe nke nchekwa dị
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Na-ebugharị ihe niile nke `other` n'ime `self`, na-ahapụ `other` efu.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ọnụ ọgụgụ ọhụrụ nke ihe ndị dị na onwe ya juputara `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // amaghi ihe
        self.extend(other.drain(..));
    }

    /// Na-ejigide naanị ihe ndị akọwapụtara akọwapụtara.
    ///
    /// Yabụ, wepụ ihe niile `e` dị ka `f(&e)` laghachi ụgha.
    /// Usoro a na-arụ ọrụ n'ime ya, na-eleta ihe ọ bụla n'otu oge n'otu usoro mbụ, ma na-echekwa usoro nke ihe ndị ahụ ejidere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Usoro ziri ezi nwere ike ịba uru maka ịchekwa ọnọdụ mpụga, dịka ndeksi.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Nke a nwere ike panic ma ọ bụ abort
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Ugboro abụọ nchekwa nchekwa.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Gbanwee `VecDeque` na-ebe nke mere na `len()` na `new_len` hà, ma ọ bụ site n'iwepụ ihe ndị dị oke azụ azụ ma ọ bụ site na itinye ihe ndị akpọrọ site na ịkpọ `generator` na azụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Rearranges esịtidem nchekwa nke iwu a ka ọ bụrụ otu iberibe olu, nke eweghachitere.
    ///
    /// Usoro a anaghị ekenye ma ọ naghị agbanwe usoro nke ihe ndị etinyere.Ka ọ na-eweghachi mpempe na-agbanwe agbanwe, enwere ike iji nke a dozie iwu.
    ///
    /// Ozugbo nchekwa dị n'ime nwere njikọ, usoro [`as_slices`] na [`as_mut_slices`] ga-eweghachite ọdịnaya niile nke `VecDeque` n'otu iberi.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Ortkesa ọdịnaya nke usoro.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // nhazi na Deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // Idozi ya na usoro ozo
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Inweta immutable ohere ka contiguous iberi.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // anyị nwere ike ijide n'aka na `slice` nwere ihe niile nke usoro ahụ, ebe ị ka nwere ohere ịbanye na `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // enwere ohere zuru oke iji detuo ọdụ ahụ n'otu oge, nke a pụtara na anyị na-ebufe isi isi azụ, wee detuo ọdụ ahụ n'ọnọdụ ziri ezi.
            //
            //
            // si: DEFGH .... ABC
            // ka: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Ugbu a anyị anaghị atụle .... ABCDEFGH
            // ga-agbagha n'ihi na `head` ga-abụ `0` na nke a.
            // Ọ bụ ezie na anyị nwere ike ịgbanwe nke a, ọ bụghị obere ihe dị ka ebe ole na ole na-atụ anya `is_contiguous` ịpụta na anyị nwere ike ibelata iji `buf[tail..head]`.
            //
            //

            // enwere ohere zuru oke iji detuo isi n'otu oge, nke a pụtara na anyị na-ebu ụzọ gbanwee ọdụ ahụ n'ihu, wee detuo isi ahụ n'ọnọdụ ziri ezi.
            //
            //
            // si: FGH .... ABCDE
            // ka: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // n'efu dị obere karịa isi na ọdụ, nke a pụtara na anyị ga-eji nwayọ nwayọ "swap" ọdụ na isi.
            //
            //
            // site: EFGHI ... ABCD ma ọ bụ HIJK.ABCDEFG
            // ka: ABCDEFGHI ... ma obu ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Nsogbu izugbe dị ka nke a GHIJKLM ... ABCDEF, tupu swaps ọ bụla ABCDEFM ... GHIJKL, mgbe 1 gafere swaps ABCDEFGHIJM ... KL, gbanwee ruo mgbe edge aka ekpe rutere n'ụlọ ahịa temp
                //                  - wee malitegharịa algorithm na ụlọ ahịa (smaller) ọhụrụ Mgbe ụfọdụ, a na-enweta ụlọ ahịa temp mgbe edge ziri ezi dị na njedebe nke nchekwa ahụ, nke a pụtara na anyị ejiri swaps pere mpe merie usoro ziri ezi!
                //
                // E.g
                // EF..ABCD ABCDEF .., mgbe anọ naanị swaps anyị mechara
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Na-emegharị kwụ n'ahịrị abụọ `mid` n'akụkụ aka ekpe.
    ///
    /// Equivalently,
    /// - Rotates ihe `mid` n'ime ọnọdụ mbụ.
    /// - Pops ihe mbụ `mid` na-akpali ha na njedebe.
    /// - Rotates `len() - mid` ebe aka nri.
    ///
    /// # Panics
    ///
    /// Ọ bụrụ na `mid` karịrị `len()`.
    /// Rịba ama na `mid == len()` na-eme _not_ panic na ọ bụ ntụgharị na-enweghị opi.
    ///
    /// # Complexity
    ///
    /// Were oge `*O*(min(mid, len() - mid))` na enweghị ohere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Na-emegharị kwụ n'ahịrị abụọ `k` n'akụkụ aka nri.
    ///
    /// Equivalently,
    /// - Na-agbanwe ihe mbụ n`ime ọnọdụ `k`.
    /// - Na-egosipụta ihe ikpeazụ `k` ma kpoo ha n'ihu.
    /// - Rotates `len() - k` ebe aka ekpe.
    ///
    /// # Panics
    ///
    /// Ọ bụrụ na `k` karịrị `len()`.
    /// Rịba ama na `k == len()` na-eme _not_ panic na ọ bụ ntụgharị na-enweghị opi.
    ///
    /// # Complexity
    ///
    /// Were oge `*O*(min(k, len() - k))` na enweghị ohere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // NCHEKWA: abụọ na-esonụ ụzọ na-achọ ka adiana ego
    // - eru ihe na-erughị ọkara n'ogologo nke deque.
    //
    // `wrap_copy` chọrọ na `min(x, cap() - x) + copy_len <= cap()`, mana karịa `min` enweghị ihe karịrị ọkara ikike, n'agbanyeghị x, yabụ na ọ dị mma ịkpọ ebe a n'ihi na anyị na-akpọ ihe na-erughị ọkara ogologo, nke na-adịtụghị ọkara ikike.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Ọnụọgụ abụọ na-enyocha ụdị `VecDeque` a maka ihe enyere.
    ///
    /// Ọ bụrụ na achọtara uru ahụ wee laghachi [`Result::Ok`], nwere ndeksi nke ihe ndabara.
    /// Ọ bụrụ na enwere ọtụtụ egwuregwu, mgbe ahụ enwere ike iweghachite egwuregwu ọ bụla.
    /// Ọ bụrụ na ịchọtaghị uru ahụ wee laghachi [`Result::Err`], nwere ndeksi ebe enwere ike ịtinye ihe kwekọrọ na ya ka ọ na-edozi usoro nhazi.
    ///
    ///
    /// # Examples
    ///
    /// Na-achọ ihe anọ.
    /// A na-achọta nke mbụ, jiri ọnọdụ pụrụ iche kpebie;nke abụọ na nke atọ ahụghị;nke anọ nwere ike ịkwado ọnọdụ ọ bụla na `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Ọ bụrụ n'ịchọrọ ịtinye ihe na `VecDeque` ota, mgbe ị na-edobe usoro dị iche iche:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Ọnụọgụ abụọ na-enyocha ụdị `VecDeque` a na ọrụ comparator.
    ///
    /// Ọrụ comparator kwesịrị itinye usoro na usoro nke `VecDeque` dị n'okpuru, weghachite koodu na-egosi ma arụmụka ya bụ `Less`, `Equal` ma ọ bụ `Greater` karịa ebumnuche achọrọ.
    ///
    ///
    /// Ọ bụrụ na uru a na-hụrụ mgbe [`Result::Ok`] na-laghachi, nke nwere index nke kenha mmewere.Ọ bụrụ na enwere ọtụtụ egwuregwu, mgbe ahụ enwere ike iweghachite egwuregwu ọ bụla.
    /// Ọ bụrụ na ịchọtaghị uru ahụ wee laghachi [`Result::Err`], nwere ndeksi ebe enwere ike ịtinye ihe kwekọrọ na ya ka ọ na-edozi usoro nhazi.
    ///
    /// # Examples
    ///
    /// Na-achọ ihe anọ.A na-achọta nke mbụ, jiri ọnọdụ pụrụ iche kpebie;nke abụọ na nke atọ ahụghị;nke anọ nwere ike ịkwado ọnọdụ ọ bụla na `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Ọnụọgụ abụọ na-enyocha ụdị `VecDeque` a na-arụ ọrụ na ntinye isi.
    ///
    /// Na-eche na isi ihe na-edozi `VecDeque`, dịka ọmụmaatụ na [`make_contiguous().sort_by_key()`](#method.make_contiguous) na-eji otu ụzọ mwepu isi.
    ///
    ///
    /// Ọ bụrụ na achọtara uru ahụ wee laghachi [`Result::Ok`], nwere ndeksi nke ihe ndabara.
    /// Ọ bụrụ na enwere ọtụtụ egwuregwu, mgbe ahụ enwere ike iweghachite egwuregwu ọ bụla.
    /// Ọ bụrụ na ịchọtaghị uru ahụ wee laghachi [`Result::Err`], nwere ndeksi ebe enwere ike ịtinye ihe kwekọrọ na ya ka ọ na-edozi usoro nhazi.
    ///
    /// # Examples
    ///
    /// Na-ele anya na usoro ihe anọ dị na mpempe abụọ nke abụọ.
    /// A na-achọta nke mbụ, jiri ọnọdụ pụrụ iche kpebie;nke abụọ na nke atọ ahụghị;nke anọ nwere ike ịkwado ọnọdụ ọ bụla na `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Na-agbanwe `VecDeque` na-ebe ka `len()` bụrụ new_len, ma ọ bụ site n'iwepụ ihe ndị dị oke azụ ma ọ bụ site na itinye clones nke `value` na azụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// O weghachitere ndeksi na ihe nkpuchi di n'okpuru maka ihe omuma ihe ezi uche di na ya.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // size bụ mgbe ike nke 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Gbakọọ nọmba nke ihe ndị fọdụrụ ka a gụọ na nchekwa
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // size bụ mgbe ike nke 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Mgbe enwere ike ịkewaa na ngalaba atọ, dịka ọmụmaatụ: onwe: [a b c|d e f] ọzọ: [0 1 2 3|4 5] ihu=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Enweghị ike iji Hash::hash_slice na mpekere nke usoro as_slices laghachiri n'ihi na ogologo ha nwere ike ịdị iche na nke ọzọ.
        //
        //
        // Hasher na-ekwe nkwa nha anya maka otu otu oku a na-akpọ ya.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Na-eri `VecDeque` n`ime ihu-na-azụ iterator na-ekwenye ekwenye site na uru.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ọrụ a kwesiri ịbụ ihe omume:
        //
        //      maka ihe na iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Gbanwee [`Vec<T>`] ka ọ bụrụ [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Nke a na-egbochi ịtọgharị ebe ọ bụla enwere ike, mana ọnọdụ maka nke ahụ siri ike, ma nwee ike ịgbanwe, yabụ ekwesịghị ịtụkwasị obi belụsọ na `Vec<T>` sitere na `From<VecDeque<T>>` ma enwetabeghị ebe ọzọ.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Enweghi oke maka ZST iji chegbuo ikike, mana `VecDeque` enweghị ike ijikwa ogologo dịka `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Anyị kwesịrị imegharị ma ọ bụrụ na ikike abụghị ike nke abụọ, oke pere mpe ma ọ bụ enweghị obere opekata mpe.
            // Anyị na-eme nke a mgbe ọ ka nọ na `Vec` ka ihe ndị ahụ wee daa na panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Gbanwee [`VecDeque<T>`] ka ọ bụrụ [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Nke a ekwesighi ịhazi ọzọ, mana ọ kwesiri ịmegharị data *O*(*n*) ma ọ bụrụ na echekwa okirikiri agaghị adị na mbido oke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Nke a bụ *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Nke a chọrọ nhazigharị data.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}