//! Ndepụta ejikọtara nke nwere njikọ.
//!
//! `LinkedList` na-enye ohere ịkwanye na ịmepụta ihe na njedebe ọ bụla na oge mgbe niile.
//!
//! NOTE: Ọ fọrọ nke nta ka ọ dị mma iji [`Vec`] ma ọ bụ [`VecDeque`] n'ihi na ihe ndị e kere eke na-adịkarị ngwa ngwa, na-arụ ọrụ ncheta nke ọma, ma na-eji CPU cache mma.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Ndepụta ejikọtara nke nwere njikọ.
///
/// `LinkedList` na-enye ohere ịkwanye na ịmepụta ihe na njedebe ọ bụla na oge mgbe niile.
///
/// NOTE: Ọ fọrọ nke nta ka ọ dị mma iji `Vec` ma ọ bụ `VecDeque` n'ihi na ihe ndị e kere eke na-adịkarị ngwa ngwa, na-arụ ọrụ ncheta nke ọma, ma na-eji CPU cache mma.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Otu iteratororer ihe nke `LinkedList`.
///
/// `struct` a ka [`LinkedList::iter()`] kere.
/// Lee akwukwo ya maka ihe ndi ozo.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Wepụ na ihu ọma nke `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Onye na-agbanwe agbanwe banyere ihe `LinkedList`.
///
/// `struct` a ka [`LinkedList::iter_mut()`] kere.
/// Lee akwukwo ya maka ihe ndi ozo.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Anyị anaghị * nwere naanị ndepụta niile ebe a, edepụtara aka na `element` ọnụ site n'aka onye nyocha ahụ!Ya mere kpachara anya mgbe ị na-eji nke a;ụzọ ndị akpọrọ kwesịrị ịmara na enwere ike ịnwe ntụpọ ịtụnye aha na `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Onye na-ekwu okwu banyere ihe `LinkedList`.
///
/// Emebere `struct` a site na usoro [`into_iter`] na [`LinkedList`] (nke `IntoIterator` trait nyere).
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// ụzọ nzuzo
impl<T> LinkedList<T> {
    /// Na-agbakwunye ọnụ nyere ya n'ihu ndepụta ahụ.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Usoro a na-elezi anya ka ị ghara ịmepụta ihe ntụgharị ederede maka ọnụ, iji kwado njirimara nke ndị na-ede aha ha n'ime `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Emeghi ihe edere ederede (unique!) ohuru nwere ike ijikwa `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Wepu ma weghachite ọnụ na ihu ndepụta ahụ.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Usoro a na-elezi anya ka ị ghara ịmepụta ihe ntụgharị ederede maka ọnụ, iji kwado njirimara nke ndị na-ede aha ha n'ime `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Emeghi ihe edere ederede (unique!) ohuru nwere ike ijikwa `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Na-agbakwunye ọnụ ọgụgụ nyere na azụ nke ndepụta ahụ.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Usoro a na-elezi anya ka ị ghara ịmepụta ihe ntụgharị ederede maka ọnụ, iji kwado njirimara nke ndị na-ede aha ha n'ime `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Emeghi ihe edere ederede (unique!) ohuru nwere ike ijikwa `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Wepu ma weghachite ọnụ na azụ nke ndepụta ahụ.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Usoro a na-elezi anya ka ị ghara ịmepụta ihe ntụgharị ederede maka ọnụ, iji kwado njirimara nke ndị na-ede aha ha n'ime `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Emeghi ihe edere ederede (unique!) ohuru nwere ike ijikwa `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Unlinks kwuru kpọmkwem ọnụ site na nke ugbu a ndepụta.
    ///
    /// Dọ aka na ntị: nke a agaghị achọpụta na ọnụnọ enyere bụ nke ndepụta dị ugbu a.
    ///
    /// Usoro a na-elezi anya ka ị ghara ịmepụta ihe ntụgharị asụsụ nke `element`, iji kwado njirimara nke ndị na-ede aha ha.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // nke a bụ nke anyị ugbu a, anyị nwere ike ịmepụta &mut.

        // Emeghi ihe edere ederede (unique!) ohuru nwere ike ijikwa `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // ọnụ a bụ isi ọnụ
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // ọnụ a bụ ọdụ ọdụ
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Splices a ọnụ nke ọnụ n'etiti abụọ ẹdude ọnụ.
    ///
    /// Dọ aka na ntị: nke a agaghị achọpụta na ọnụnọ enyere dịịrị ndepụta abụọ dị adị.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Usoro a na-elezi anya ka ị ghara ịmepụta ọtụtụ ntụgharị ederede na mpaghara niile n'otu oge ahụ, iji kwado njirimara nke ndị na-ede aha ha n'ime `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Na-ewepụ ọnụ ọnụ site na listi jikọtara ọnụ dị ka usoro ọnụ.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Ekewa ekewa bụ isi ọhụrụ nke akụkụ nke abụọ
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Mezie isi ptr nke akụkụ nke abụọ
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Ekewa ekewa bụ eriri ọdụ ọhụrụ nke akụkụ mbụ ma nwee isi nke akụkụ nke abụọ.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Dozie ọdụ ptr nke akụkụ mbụ
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Mepụta `LinkedList<T>` efu.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Mepụta `LinkedList` efu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Na-ebugharị ihe niile site na `other` na njedebe nke ndepụta ahụ.
    ///
    /// Nke a na-ejigharị ọnụ ọnụ niile site na `other` wee mee ka ọ banye na `self`.
    /// Mgbe ọrụ a gasịrị, `other` na-aghọ ihe efu.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na *O*(1) oge na *O*(1) ebe nchekwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` dịkwa mma ebe a n'ihi na anyị nwere ohere zuru oke na ndepụta abụọ.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Na-ebugharị ihe niile site na `other` na mmalite nke ndepụta ahụ.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` dịkwa mma ebe a n'ihi na anyị nwere ohere zuru oke na ndepụta abụọ.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Na-enye onye na-aga n'ihu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Na-enye onye na-ede akwụkwọ ntụgharị na ntụgharị ntụgharị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Na-enye ihe nlele na ihe dị n'ihu.
    ///
    /// Ihe nlele ahu na arutu aka na ihe ndi "ghost" abughi mmewere ma oburu na ndepụta adighi efu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// - Enye cursor na edezi arụmọrụ na n'ihu mmewere.
    ///
    /// Ihe nlele ahu na arutu aka na ihe ndi "ghost" abughi mmewere ma oburu na ndepụta adighi efu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Na-enye cursor na azụ mmewere.
    ///
    /// Ihe nlele ahu na arutu aka na ihe ndi "ghost" abughi mmewere ma oburu na ndepụta adighi efu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// - Enye cursor na edezi arụmọrụ na azụ mmewere.
    ///
    /// Ihe nlele ahu na arutu aka na ihe ndi "ghost" abughi mmewere ma oburu na ndepụta adighi efu.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Laghachi `true` ma ọ bụrụ na `LinkedList` efu.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na *O*(1) oge.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Laghachi ogologo `LinkedList`.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na *O*(1) oge.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ewepu ihe niile sitere na `LinkedList`.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na oge *O*(*n*).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Laghachi `true` ma ọ bụrụ na `LinkedList` nwere mmewere hà na nke enyere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Na-enye aka maka ihe dị n'ihu, ma ọ bụ `None` ma ọ bụrụ na ndepụta ahụ adịghị efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Na-enye ntụgharị ihu maka ihu ihe n'ihu, ma ọ bụ `None` ma ọ bụrụ na ndepụta ahụ adịghị efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Na-enye aka na ihe ndabere, ma ọ bụ `None` ma ọ bụrụ na ndepụta ahụ adịghị efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Na-enye ihe ntụgharị ntụgharị okwu banyere ihe azụ, ma ọ bụ `None` ma ọ bụrụ na ndepụta ahụ adịghị efu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Na-agbakwunye mmewere mbụ na ndepụta.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na *O*(1) oge.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Wepu ihe mbu ma weghachite ya, ma ọ bụ `None` ma ọ bụrụ na ndepụta ahụ enweghị ihe ọ bụla.
    ///
    ///
    /// Ọrụ a kwesịrị ịgbakọ na *O*(1) oge.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Gbakwunye mmewere na azụ ndepụta.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na *O*(1) oge.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Wepu mmezi ikpeazụ na ndepụta wee weghachite ya, ma ọ bụ `None` ọ bụrụ na ọ tọgbọ chakoo.
    ///
    ///
    /// Ọrụ a kwesịrị ịgbakọ na *O*(1) oge.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Kewara ndepụta ahụ ụzọ abụọ na ndeksi edere.
    /// Weghachite ihe niile mgbe edepụtara ya, gụnyere ndeksi.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na oge *O*(*n*).
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // N'okpuru, anyị na-agagharị na ọnụ 'i-1`th, ma site na mbido ma ọ bụ njedebe, dabere na nke ga-abụ ngwa ngwa.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // kama ịmasị iji .skip() (nke na-emepụta ihe ọhụụ), anyị na-awụ aka aka ka anyị wee nwee ike ịnweta mpaghara isi na-enweghị dabere na nkọwa ntinye nke Skip
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // ọ ka mma ịmalite na njedebe
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Na-ewepu mmewere na ndenye ederede ma weghachite ya.
    ///
    /// Ọrụ a kwesịrị ịgbakọ na oge *O*(*n*).
    ///
    /// # Panics
    /// Panics ma ọ bụrụ na>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // N'okpuru, anyị na-agagharị na ọnụ na ndepụta ahụ enyere, ma site na mbido ma ọ bụ njedebe, dabere na nke ga-abụ ngwa ngwa.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Na-emepụta iterator nke na-eji mmechi eme ihe iji chọpụta ma ewepụ ihe mmewere.
    ///
    /// Ọ bụrụ na mmechi ahụ laghachiri n'eziokwu, mgbe ahụ, ewepụrụ ihe ahụ wee mee ya.
    /// Ọ bụrụ na mmechi ahụ ghaghachitere ụgha, mmewere ga-anọgide na ndepụta ahụ ma agaghị enye ya site na iterator.
    ///
    /// Rịba ama na `drain_filter` na-enye gị ohere ịgbanwe ihe ọ bụla na mmechi nzacha, n'agbanyeghị ma ị họrọ idebe ma ọ bụ wepu ya.
    ///
    ///
    /// # Examples
    ///
    /// Na-ekewa ndepụta n'ime nsogbu na nsogbu, na-ejigharị ndepụta mbụ:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // zere mbipụta nsogbu.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Gaa n'ihu otu loop anyị na-eme n'okpuru.Naanị nke a na-agba ọsọ mgbe ụjọ bibiri onye ọ bụla.
                // Ọ bụrụ na onye ọzọ panics nke a ga-ete ime.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Chọrọ ndụ a na-ebughị ebibi iji nweta 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Chọrọ ndụ a na-ebughị ebibi iji nweta 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Chọrọ ndụ a na-ebughị ebibi iji nweta 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Chọrọ ndụ a na-ebughị ebibi iji nweta 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Ihe nkedo n'elu `LinkedList`.
///
/// `Cursor` dị ka onye na-eme ite, belụsọ na ọ nwere ike ịchọ ịchọgharị na n'ihu.
///
/// Cursors mgbe niile na-ezu ike n'etiti abụọ ọcha na ndepụta, na ndeksi n'ụzọ ezi uche dị na okirikiri ụzọ.
/// Iji nabata nke a, enwere "ghost" na-enweghị mmewere nke na-amịpụta `None` n'etiti isi na ọdụ nke ndepụta ahụ.
///
///
/// Mgbe emepụtara, ndị cursors na-amalite n'ihu ndepụta ahụ, ma ọ bụ "ghost" na-enweghị mmewere ma ọ bụrụ na ndepụta ahụ adịghị efu.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// A cursor n'elu a `LinkedList` na edezi arụmọrụ.
///
/// A `Cursor` dị ka iterator, belụsọ na ọ nwere ike ịchọ nchigharị na-aga n'ihu, ma nwee ike ịgbanwe ndepụta ahụ kpamkpam n'oge iteration.
/// Nke a bụ n'ihi na ndụ niile nke mkpụrụ akwụkwọ ya nyere aka jikọtara ya na ndụ ya, kama ịbụ naanị ndepụta ndị bụ isi.
/// Nke a pụtara ndị cursors enweghị ike ịnye ọtụtụ ihe n'otu oge.
///
/// Cursors mgbe niile na-ezu ike n'etiti abụọ ọcha na ndepụta, na ndeksi n'ụzọ ezi uche dị na okirikiri ụzọ.
/// Iji nabata nke a, enwere "ghost" na-enweghị mmewere nke na-amịpụta `None` n'etiti isi na ọdụ nke ndepụta ahụ.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Weghachite ndetu ọnọdụ cursor n'ime `LinkedList`.
    ///
    /// Nke a laghachi `None` ma ọ bụrụ na cursor na-atụzi aka na "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Eme ka cursor na ihe ozo nke `LinkedList`.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị nke a ga-ebugharị ya na ihe mbụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mmezi ikpeazụ nke `LinkedList` mgbe ahụ nke a ga-ebugharị ya na "ghost" na-enweghị mmewere.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Anyị enweghị ihe dị ugbu a;cursor nọ ọdụ na mmalite ọnọdụ Isi mmewere kwesịrị ịbụ isi nke ndepụta ahụ
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Anyị nwere mmewere gara aga, yabụ ka anyị gaa na nke ọzọ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Emegharia cursor na ihe mbu nke `LinkedList`.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị nke a ga-akpali ya na mmewere ikpeazụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mbido mbụ nke `LinkedList` mgbe ahụ nke a ga-ebugharị ya na "ghost" na-enweghị mmewere.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ọ dịghị ugbu a.Anyị nọ na mmalite nke ndepụta ahụ.Ekweghi Onwe ya na-awụlikwa elu na njedebe.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Nwee prev.Ekwee ya na-aga aga mmewere.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Alaghachi a kwuru banyere mmewere na cursor na-ugbu a na-atụ aka.
    ///
    /// Nke a laghachi `None` ma ọ bụrụ na cursor na-atụzi aka na "ghost" non-element.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Laghachi a na-esote mmewere.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị nke a laghachiri ihe mbụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mmezi ikpeazụ nke `LinkedList` mgbe ahụ ihe a laghachiri `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Laghachiri na mbụ aga mmewere.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" na-enweghị mmewere mgbe ahụ nke a ga-eweghachi ihe ikpeazụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mbido mbụ nke `LinkedList` mgbe ahụ ihe a laghachiri `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Weghachite ndetu ọnọdụ cursor n'ime `LinkedList`.
    ///
    /// Nke a laghachi `None` ma ọ bụrụ na cursor na-atụzi aka na "ghost" non-element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Eme ka cursor na ihe ozo nke `LinkedList`.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị nke a ga-ebugharị ya na ihe mbụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mmezi ikpeazụ nke `LinkedList` mgbe ahụ nke a ga-ebugharị ya na "ghost" na-enweghị mmewere.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Anyị enweghị ihe dị ugbu a;cursor nọ ọdụ na mmalite ọnọdụ Isi mmewere kwesịrị ịbụ isi nke ndepụta ahụ
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Anyị nwere mmewere gara aga, yabụ ka anyị gaa na nke ọzọ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Emegharia cursor na ihe mbu nke `LinkedList`.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị nke a ga-akpali ya na mmewere ikpeazụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mbido mbụ nke `LinkedList` mgbe ahụ nke a ga-ebugharị ya na "ghost" na-enweghị mmewere.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ọ dịghị ugbu a.Anyị nọ na mmalite nke ndepụta ahụ.Ekweghi Onwe ya na-awụlikwa elu na njedebe.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Nwee prev.Ekwee ya na-aga aga mmewere.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Alaghachi a kwuru banyere mmewere na cursor na-ugbu a na-atụ aka.
    ///
    /// Nke a laghachi `None` ma ọ bụrụ na cursor na-atụzi aka na "ghost" non-element.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Laghachi a na-esote mmewere.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị nke a laghachiri ihe mbụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mmezi ikpeazụ nke `LinkedList` mgbe ahụ ihe a laghachiri `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Laghachiri na mbụ aga mmewere.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" na-enweghị mmewere mgbe ahụ nke a ga-eweghachi ihe ikpeazụ nke `LinkedList`.
    /// Ọ bụrụ na ọ na-atụ aka na mbido mbụ nke `LinkedList` mgbe ahụ ihe a laghachiri `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Laghachi cursor a guru na-arutu aka n'ihe di ugbu a.
    ///
    /// Oge ndụ nke `Cursor` laghachiri ga-adabere na nke `CursorMut`, nke pụtara na ọ gaghị enwe ike ịdị ndụ karịa `CursorMut` ahụ nakwa na `CursorMut` oyi kpọnwụrụ maka oge nke `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Ugbu a ndepụta edezi arụmọrụ

impl<'a, T> CursorMut<'a, T> {
    /// Tinye ihe ọhụrụ n'ime `LinkedList` mgbe nke ugbu a gasịrị.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịrị ihe ọhụrụ ahụ ka etinyere n'ihu `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Ntuziaka na-enweghị mmewere nke "ghost" agbanweela.
                self.index = self.list.len;
            }
        }
    }

    /// Tinye ihe ọhụrụ n'ime `LinkedList` tupu nke ugbu a.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị ihe ọhụrụ ahụ ka etinyere na njedebe nke `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Ewepu ihe dị ugbu a na `LinkedList`.
    ///
    /// E weghachitere mmewere nke ewepụrụ, na cursor ahụ ka ọ rụtụ aka na nke ọzọ na `LinkedList`.
    ///
    ///
    /// Ọ bụrụ na cursor na-atụzi aka na "ghost" na-enweghị mmewere mgbe ahụ ewepụghị mmewere yana `None` eweghachitere.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Wepu mmewere dị ugbu a na `LinkedList` na-enweghị nkpọgharị ọnụ na ndepụta.
    ///
    /// A na-eweghachi ọnụ ọnụ ewepụrụ dị ka `LinkedList` ọhụrụ nwere naanị ọnụ ọgụgụ a.
    /// A na-akpali cursor iji tụọ ihe ọzọ na `LinkedList` dị ugbu a.
    ///
    /// Ọ bụrụ na cursor na-atụzi aka na "ghost" na-enweghị mmewere mgbe ahụ ewepụghị mmewere yana `None` eweghachitere.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Tinye ihe ndị si na `LinkedList` nyere mgbe nke ugbu a gasịrị.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị etinyere ihe ọhụrụ ahụ na mmalite nke `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Ntuziaka na-enweghị mmewere nke "ghost" agbanweela.
                self.index = self.list.len;
            }
        }
    }

    /// Tinye ihe ndị si na `LinkedList` nyere tupu nke ugbu a.
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" non-elementrịị etinyere ihe ọhụụ ọhụrụ na njedebe nke `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Kewara ndepụta abụọ n'ime nke ugbu a.
    /// Nke a ga-alọghachite ndepụta ọhụrụ gụnyere ihe niile mgbe cursor ahụ, yana ndepụta izizi na-ejigide ihe niile n`iru.
    ///
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" na-abụghị mmewere mgbe ahụ ọdịnaya niile nke `LinkedList` na-akpali.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" na-enweghị mmewere agbanweela 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Kewara ndepụta abụọ tupu nke ugbu a.
    /// Nke a ga-alọghachite ndepụta ọhụrụ nke gunyere ihe niile tupu cursor ahụ, yana ndepụta izizi na-ejigide ihe niile.
    ///
    ///
    /// Ọ bụrụ na cursor na-atụ aka na "ghost" na-abụghị mmewere mgbe ahụ ọdịnaya niile nke `LinkedList` na-akpali.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Otu iterator mepụtara site na ịkpọ `drain_filter` na LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` dịkwa mma na ịkpọtụrụ aha `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Erepịakwa ndepụta n'ime ite ite na-ekwenye ekwenye site uru.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Gbaa mbọ hụ na `LinkedList` na ndị na-agụ ya naanị ndị na-agụ ya na-agbanwe agbanwe n`ụdị ha.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}