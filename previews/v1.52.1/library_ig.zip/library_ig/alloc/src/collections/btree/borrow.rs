use core::marker::PhantomData;
use core::ptr::NonNull;

/// Dị a reborrow nke ụfọdụ pụrụ iche akwụkwọ, mgbe ị maara na reborrow na mkpụrụ ya niile (ya bụ, ihe niile ntụaka na zoro aka na-ewepụtara ya) agaghị eji ọzọ ọ bụla na oge ụfọdụ, mgbe nke ahụ ị chọrọ iji mbụ pụrụ iche akwụkwọ ọzọ .
///
///
/// Onye na-agbaziri ego na-ejikarị ejiri nke a maka gị, mana ụfọdụ njikwa na-aga nke na-emezu nchịkọta a dị oke mgbagwoju anya maka nchịkọta ahụ.
/// `DormantMutRef` na-enye gị ohere ịlele ịgbazinye onwe gị, ebe ị ka na-ekwupụta ọdịdị ya, yana encapsulating raw pointer code chọrọ iji mee nke a na-enweghị akparaghị ókè omume.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Were nnabata na-enweghị atụ, ma weghachite ya ozugbo.
    /// Maka onye nchikota, ndu nke ihe omuma ohuru dika ihe omuma nke mbu, ma gi promise iji ya mee obere oge.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: we jide mgbazinye ego 'a site na `_marker`, anyị na-ekpughekwa
        // naanị akwụkwọ a, ya mere ọ pụrụ iche.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Biaghachi na mgbazinye ego pụrụ iche ejiri na mbụ.
    ///
    /// # Safety
    ///
    /// Ọghachịrị ga-agwụrịrị, ya bụ, ntụnyeghachi nke `new` weghachite na ntụnye na ntụnye niile sitere na ya, agaghị eji ya ọzọ.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // Nchekwa: ọnọdụ nchekwa nke anyị na-egosi na nrụtụ aka a abụghị ihe ọzọ pụrụ iche.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;