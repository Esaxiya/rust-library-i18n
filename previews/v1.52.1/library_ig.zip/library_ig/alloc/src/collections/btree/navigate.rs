use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Nwa oge weputara ozo, nke apughi igbanwe nke otu uzo.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Chọta akwukwo akwukwo di iche iche nke choputara uzo di iche na osisi.
    /// Alaghachite ma obu uzo di iche iche na otu osisi ma obu uzo efu.
    ///
    /// # Safety
    ///
    /// Ọ gwụla ma `BorrowType` bụ `Immut`, ejirila ụzọ abụọ iji gaa otu KV ugboro abụọ.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ẹkot `(root1.first_leaf_edge(), root2.last_leaf_edge())` mana ọ ka rụọ ọrụ nke ọma.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Chọta ụzọ mpempe akwụkwọ na-akọwapụta otu akụkụ dị iche na osisi.
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi nyere iwu site na igodo, dị ka osisi dị na `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SAFETY: ụdị ego anyị ji agbazinye ebibi agaghị agbanwe agbanwe.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Chọta ụzọ mpempe akwụkwọ na-agbanwe otu osisi dum.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Na-agbawa a pụrụ iche akwụkwọ n'ime a ụzọ nke akwukwo n'ọnụ delimiting a kapịrị ọnụ nso.
    /// Nsonaazụ bụ ntụaka na-enweghị atụ na-enye ohere mgbanwe (some), nke a ga-eji nke ọma.
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi nyere iwu site na igodo, dị ka osisi dị na `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Ejila ihe eji eme ihe iji gaa otu KV ugboro abụọ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Na-ekewa ntụpọ pụrụ iche na mpempe akwụkwọ mpempe akwụkwọ na-akọwa oke nke osisi ahụ.
    /// Nsonaazụ bụ ntụaka na-enweghị atụ na-enye ohere mgbanwe (nke naanị ụkpụrụ), yabụ a ga-eji nlezianya jiri ya.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Anyị na-eme ka mgbọrọgwụ NodeRef dị ebe a-anyị agaghị eleta otu KV ugboro abụọ, na anyị agaghị ejedebe na ntụnye uru bara ụba.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Na-ekewa ntụpọ pụrụ iche na mpempe akwụkwọ mpempe akwụkwọ na-akọwa oke nke osisi ahụ.
    /// Nsonaazụ bụ ntụaka na-enweghị atụ na-enye mmụba mbibi nke ukwuu, ya mere, a ga-eji nlezianya kachasị mkpa.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Anyị na-eme ka mgbọrọgwụ NodeRef dị ebe a-anyị agaghị enweta ya n'ụzọ gafere akwụkwọ ntinye aka sitere na mgbọrọgwụ.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Nyere akwukwo akwukwo edge, laghachi [`Result::Ok`] ya na aka ya na KV agbata obi ya n`aka nri, nke di na akwukwo akwukwo ma obu na ndi nna ochie.
    ///
    /// Ọ bụrụ na akwụkwọ edge bụ nke ikpeazụ n'ime osisi ahụ, laghachi [`Result::Err`] na ọnụ mgbọrọgwụ.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Nyere akwukwo akwukwo edge, laghachi [`Result::Ok`] ya na aka ya na KV agbata obi ya na aka ekpe, nke di na akwukwo akwukwo ma obu na ndi nna ochie.
    ///
    /// Ọ bụrụ na akwụkwọ edge bụ nke mbụ n'ime osisi ahụ, laghachi [`Result::Err`] na ọnụ mgbọrọgwụ.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// N'inye aka edge dị n'ime, laghachi [`Result::Ok`] na njikwa na KV agbata obi ya n'akụkụ aka nri, nke dị n'otu ọnụ ma ọ bụ na ọnụ ụlọ nna ochie.
    ///
    /// Ọ bụrụ na edge dị n'ime ya bụ nke ikpeazụ n'ime osisi ahụ, laghachi [`Result::Err`] na ọnụ mgbọrọgwụ.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Nyere akwukwo akwukwo edge aka ya na osisi na-anwu anwu, weghachite akwukwo ozo edge n`akuku aka nri, ya na uzo di iche-iche di n`etiti, nke bu n`otu akwukwo, na uzo ndi nna ochie, ma obu na odighi.
    ///
    ///
    /// Usoro a na-agbakwụnye node(s) ọ bụla ọ ruru na njedebe nke.
    /// Nke a na-egosi na ọ bụrụ na ọnweghị ọnụọgụ abụọ dị oke ọnụ, a ga-ekewapụta mkpụrụ osisi fọdụrụnụ na ọ nweghị ihe fọdụrụ ịlaghachi.
    ///
    /// # Safety
    /// edge enyegoroghi na onye ozo `deallocating_next_back` weghachitere ya.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Nyere akwukwo edge aka ya n`ime osisi na-anwu anwu, weghachite akwukwo ozo edge na akuku aka ekpe, ya na uzo di iche-iche di n`etiti, nke di n`otu akwukwo, na uzo ndi nna ochie, ma obu na odighi.
    ///
    ///
    /// Usoro a na-agbakwụnye node(s) ọ bụla ọ ruru na njedebe nke.
    /// Nke a na-egosi na ọ bụrụ na ọnweghị ọnụọgụ abụọ dị oke ọnụ, a ga-ekewapụta mkpụrụ osisi fọdụrụnụ na ọ nweghị ihe fọdụrụ ịlaghachi.
    ///
    /// # Safety
    /// edge enyegoroghi na onye ozo `deallocating_next` weghachitere ya.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates a ikpo nke ọnụ site na akwukwo ruo mgbọrọgwụ.
    /// Nke a bụ naanị ụzọ iji dozie akụkụ nke fọdụrụ n'osisi mgbe `deallocating_next` na `deallocating_next_back` nọ na-agba agba n'akụkụ abụọ nke osisi ahụ, wee kụọ otu edge.
    /// Dika ebubere ya ka akpọọ ya mgbe emeghachitere igodo na ụkpụrụ niile, enweghị nhicha ọ bụla na igodo ma ọ bụ ụkpụrụ ọ bụla.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Na-emegharị akwụkwọ edge ahụ gaa na akwukwo nke ọzọ edge wee weghachi aka na isi na uru dị n'etiti.
    ///
    ///
    /// # Safety
    /// A ga-enwerịrị KV ọzọ na ntụziaka ahụ gara.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Na-emegharị akwụkwọ edge ahụ na akwukwo edge gara aga ma weghachite ntụaka maka isi na uru dị n'etiti.
    ///
    ///
    /// # Safety
    /// A ga-enwerịrị KV ọzọ na ntụziaka ahụ gara.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Na-emegharị akwụkwọ edge ahụ gaa na akwukwo nke ọzọ edge wee weghachi aka na isi na uru dị n'etiti.
    ///
    ///
    /// # Safety
    /// A ga-enwerịrị KV ọzọ na ntụziaka ahụ gara.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ime nke a ikpeazụ bụ ngwa ngwa, dị ka benchmarks.
        kv.into_kv_valmut()
    }

    /// Na-emegharị akwụkwọ edge ahụ na akwukwo gara aga ma weghachite aka maka isi na uru dị n'etiti.
    ///
    ///
    /// # Safety
    /// A ga-enwerịrị KV ọzọ na ntụziaka ahụ gara.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ime nke a ikpeazụ bụ ngwa ngwa, dị ka benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Na-eme ka ahịhịa edge ahụ gaa na akwukwo nke ọzọ edge wee weghachite igodo na uru n'etiti, na-ekenye ọ bụla ọnụ ahapụ mgbe ịhapụ edge kwekọrọ na ọnụ nne na nna ya na-atụgharị.
    ///
    /// # Safety
    /// - A ga-enwerịrị KV ọzọ na ntụziaka ahụ gara.
    /// - Na KV alọghachighị ya na onye nnọchi anya `next_back_unchecked` na akwụkwọ ọ bụla ejiri ejiri ya gafee osisi ahụ.
    ///
    /// Nanị ụzọ dị mma iji gaa na emelite emelitere bụ iji tụnyere ya, dobe ya, kpọọ usoro a ọzọ n'okpuru ọnọdụ nchekwa ya, ma ọ bụ kpọọ ibe `next_back_unchecked` dabere na ọnọdụ nchekwa ya.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Na-eme ka akwụkwọ edge ahụ gaa na akwụkwọ edge gara aga ma weghachite isi na uru dị n'etiti, na-ekenye ọnụ ọ bụla a hapụrụ mgbe ịhapụ edge kwekọrọ na ọnụ nne na nna ya na-atụgharị.
    ///
    /// # Safety
    /// - A ga-enwerịrị KV ọzọ na ntụziaka ahụ gara.
    /// - Akwụkwọ `next_unchecked` ahụ eweghachighị akwụkwọ ahụ edge na akwụkwọ ọ bụla ejiri ejiri ya gafee osisi ahụ.
    ///
    /// Nanị ụzọ dị mma iji gaa na emelite emelitere bụ iji tụnyere ya, dobe ya, kpọọ usoro a ọzọ n'okpuru ọnọdụ nchekwa ya, ma ọ bụ kpọọ ibe `next_unchecked` dabere na ọnọdụ nchekwa ya.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Alaghachi edge nke fọrọ aka ekpe na n'okpuru ma ọ bụ n'okpuru ọnụ, yabụ, edge ịchọrọ izizi mgbe ị na-aga n'ihu (ma ọ bụ nke ikpeazụ mgbe ị na-agagharị n'azụ).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Alaghachi edge nke dịkarịsịrị mma ma ọ bụ n'okpuru ọnụ, yabụ, edge ịchọrọ nke ikpeazụ mgbe ị na-agagharị (ma ọ bụ izizi mgbe ị na-agagharị n'azụ).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Nleta akwukwo akwukwo na ndi KV n'ime ka igodo igo, ma na eleta onu di n'ime ya n'uzo zuru oke, nke putara na onu di n'ime ha na-ebute KV ha na nwa ha.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Na-agụta ọnụ ọgụgụ nke ihe dị na osisi (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Laghachi akwukwo edge nke kachakarịrị KV maka igodo nsoroụzọ.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Laghachi akwukwo edge nke kachasi KV nso maka igodo azu.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}