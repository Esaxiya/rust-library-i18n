use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Ihe jikotara anya ichota, dika `Bound::Included(T)`.
    Included(T),
    /// Naanị ịchọrọ ịchọta, dị ka `Bound::Excluded(T)`.
    Excluded(T),
    /// Ihe agbakwunyere na-enweghị atụ, dịka `Bound::Unbounded`.
    AllIncluded,
    /// Ekebere na-enweghị njedebe.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Na-ele anya na igodo a nyere na osisi (sub) nke isi ya na-aga, na-agagharị.
    /// Laghachi `Found` na njikwa nke KV dabara, ọ bụrụ na ọ bụla.
    /// Ma ọ bụghị ya, laghachi `GoDown` na njikwa nke akwukwo edge ebe igodo bụ.
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi nyere iwu site na igodo, dị ka osisi dị na `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Gbadara n`ebe dị nso ebe edge dabara na mpaghara ala dị iche na edge dabara na akara elu, yabụ, ọnụ nọ nso nke nwere opekata mpe otu igodo dị na mpaghara ahụ.
    ///
    ///
    /// Ọ bụrụ na achọta, laghachi na `Ok` na ọnụ ahụ, ụzọ abụọ edge na-egosi oke, yana ụzọ kwekọrọ maka ịga n'ihu na nchọta na ọnụ nwa ahụ, ọ bụrụ na ọnụ ahụ dị n'ime.
    ///
    /// Ọ bụrụ na ahụghị ya, laghachi `Err` na akwụkwọ edge dabara na usoro ahụ dum.
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi na-enye iwu site na igodo.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Idebanye mgbanwe ndị a kwesịrị izere.
        // Anyị chere na oke nke `range` kọọrọ ka bụ otu, mana mmejuputa mmegide nwere ike gbanwee n'etiti oku (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Chọta edge na ọnụ na-ekekọta mpaghara ala nke usoro.
    /// Weghachite obere agbụ iji mee maka ịga n'ihu na nyocha na nwa ọnụ, ma ọ bụrụ na `self` bụ ọnụ.
    ///
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi na-enye iwu site na igodo.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Mmepụta oyiri nke `find_lower_bound_edge` maka eriri elu.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Na-ele anya na igodo e nyere na ọnụ, na-enweghị nlọghachite.
    /// Laghachi `Found` na njikwa nke KV dabara, ọ bụrụ na ọ bụla.
    /// Ma ọ bụghị ya, laghachi `GoDown` na njikwa nke edge ebe enwere ike ịchọta igodo ahụ (ọ bụrụ na ọnụ ahụ dị n'ime) ma ọ bụ ebe enwere ike ịtinye igodo ahụ.
    ///
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi nyere iwu site na igodo, dị ka osisi dị na `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Weghachite ma ntaneti KV na uzo nke igodo ya (ma obu ihe ya na ya di), ma obu ntaneti edge ebe igodo bu.
    ///
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi nyere iwu site na igodo, dị ka osisi dị na `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Chọta ndekpọ edge na ọnụ na-akpara ókè ala nke nso.
    /// Weghachite obere agbụ iji mee maka ịga n'ihu na nyocha na nwa ọnụ, ma ọ bụrụ na `self` bụ ọnụ.
    ///
    ///
    /// Nsonaazụ a bara uru naanị ma ọ bụrụ na osisi na-enye iwu site na igodo.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Mmepụta oyiri nke `find_lower_bound_index` maka eriri elu.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}