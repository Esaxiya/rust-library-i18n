// Nke a bụ nnwale na mmejuputa iwu na-eso ezigbo
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Ebe ọ bụ na Rust enweghị ụdị ndị dabere na nlọghachị polymorphic, anyị na-eme ọtụtụ enweghị nchekwa.
//

// Ihe mgbaru ọsọ bụ isi nke modulu a bụ izere mgbagwoju anya site n'imeso osisi ahụ dị ka akpa (ma ọ bụrụ na ọ dị oke) ma zere ịmekọrịta ọtụtụ ndị na-agbanwe osisi B-Tree.
//
// Ka o siri dị, modul a achọghị ịma ma etinyere ndenye ahụ, nke ọnụ nwere ike ịbụ nke zuru oke, ma ọ bụ ọbụlagodi ihe ntụgharị pụtara.Agbanyeghị, anyị na-adabere na mmadụ ole na ole na-adịghị agbanwe agbanwe:
//
// - Osisi aghaghi inwe edo edo depth/height.Nke a pụtara na ụzọ ọ bụla ruo na akwukwo site na ọnụ enyere nwere otu ogologo ahụ.
// - Otu ọnụ ogologo `n` nwere igodo `n`, ụkpụrụ `n`, na `n + 1` n'ọnụ.
//   Nke a pụtara na ọbụlagodi ọnụ efu nwere opekata mpe otu edge.
//   Maka ọnụ akwụkwọ, "having an edge" pụtara naanị na anyị nwere ike ịchọpụta ọnọdụ dị na ọnụ ahụ, ebe ọ bụ na mpempe akwụkwọ enweghị ihe ọ bụla na-achọghị nnochite data.
// N'ime ọnụ ọnụ, edge abụọ na-achọpụta ọnọdụ ma nwee pointer na ọnụ nwata.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Ihe mgbakwasị ụkwụ na-anọchi anya nke ahịhịa akwụkwọ na akụkụ nke nnọchi anya nke ọnụ dị n'ime.
struct LeafNode<K, V> {
    /// Anyị chọrọ ịbụ covariant na `K` na `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Nkọwapụta ọnụ ọgụgụ nke ọnụ ọgụgụ a n'ime usoro `edges` nke nne na nna.
    /// `*node.parent.edges[node.parent_idx]` kwesiri ibu otu ihe dika `node`.
    /// Emere nke a naanị ka amalite ya mgbe `parent` abụghị ihe efu.
    parent_idx: MaybeUninit<u16>,

    /// Ọnụ ọgụgụ nke igodo na ụkpụrụ ọnụ ahịa echekwara.
    len: u16,

    /// Array na-echekwa data nke ọnụ ọnụ.
    /// Naanị ihe `len` mbụ nke usoro ọ bụla ka ebidoro ma dị irè.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Na-amalite ihe ọhụrụ `LeafNode`.
    unsafe fn init(this: *mut Self) {
        // Dịka usoro iwu zuru oke, anyị na-ahapụ ubi amaghị na ọ bụrụ na ha nwere ike ịbụ, n'ihi na nke a kwesịrị ịbụ obere ọsọ ọsọ na mfe iji soro na Valgrind.
        //
        unsafe {
            // parent_idx, igodo, na vals niile bu MayUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Emeputa `LeafNode` igbe ohuru.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ihe nnọchiteanya na-anọchi anya nke eriri dị n'ime.Dị ka ``LeafNode`s, ndị a ga-ezo n'azụ '' BoxedNode`s iji gbochie idobe igodo na enweghị ụkpụrụ.
/// Enwere ike ịtinye pointer ọ bụla na `InternalNode` na pointer na ngalaba `LeafNode` dị n'okpuru nke ọnụ, na-enye ohere ka koodu rụọ ọrụ na mpempe akwụkwọ na akụkụ dị n'ime na-enweghị ịlele onye nke abụọ a na-atụ aka na-atụ aka.
///
/// Ejiri `repr(C)` mee ihe a.
///
#[repr(C)]
// gdb_providers.py na-eji ụdị aha a maka introspection.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ihe na-arutu aka n`ebe umu a no.
    /// `len + 1` ndị a na-ahụta bidoro ma dị ire, belụsọ na na njedebe, ebe ana-ejide osisi ahụ site n'ụdị nbinye ụdị `Dying`, ụfọdụ n'ime ihe atụ ndị a na-agbapụ.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Emeputa `InternalNode` igbe ohuru.
    ///
    /// # Safety
    /// Ihe na-agbanwe agbanwe na-arụ ọrụ n'ime ụlọ bụ na ha nwere opekata mpe otu edge nke izizi ma dị ire.
    /// Ọrụ a anaghị edozi edge dị otú ahụ.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Naanị anyị chọrọ ibido data ahụ;n'ọnụ ya bụ MayUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Nchịkọta na-enweghị isi na-enweghị isi na ọnụ.Nke a bụ maịlị pointer nwere na `LeafNode<K, V>` ma ọ bụ ihe nwere pointer nwere na `InternalNode<K, V>`.
///
/// Agbanyeghị, `BoxedNode` enweghị ozi gbasara ụdị nke ụdị abụọ ọ nwere n'ezie, yana, na akụkụ ụfọdụ n'ihi enweghị ozi a, abụghị ụdị dị iche na enweghị onye nbibi.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ndidi nke osisi nwere.
///
/// Rịba ama na nke a enweghị onye nbibi, ọ ga-ehicha ya na aka.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Alaghachiri osisi ohuru nke nwere nke ya nke bu ihe efu na mbido.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` agaghị abụ efu.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Na-agbazinye ego gbanwere ọnụ ya.
    /// N'adịghị ka `reborrow_mut`, nke a dị mma n'ihi na enweghị ike iji uru nloghachi bibie mgbọrọgwụ ahụ, enweghịkwa ike ịzo aka ọzọ na osisi ahụ.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Jiri nwayọ mutụ gbazinye ọnụ ya.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Apụghị ịgbanwe agbanwe gaa na ntụgharị aka nke na-enye ohere ịgafe ma na-enye usoro mbibi na obere ihe ọzọ.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Na-agbakwunye ọnụ ụlọ ọhụrụ nke nwere otu edge na-atụ aka na mgbọrọgwụ mgbọrọgwụ gara aga, mee ọnụ ọhụrụ ahụ mgbọrọgwụ ọnụ, ma weghachite ya.
    /// Nke a na-eme ka ogo ya dịkwuo elu site na 1 ma ọ bụ na-abụghị `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ma e wezụga na anyị chefuru na anyị dị n'ime ugbu a:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Na-ewepu ọnụ mgbọrọgwụ nke ime, jiri nwa mbụ ya dị ka ọnụ ụzọ mgbọrọgwụ ọhụrụ.
    /// Dika ebubere ya naanị ka akpọ ya mgbe ọnụ mgbọrọgwụ nwere naanị otu nwa, enweghị nhicha ọ bụla na igodo, ụkpụrụ na ụmụaka ndị ọzọ.
    ///
    /// Nke a na-ebelata elu site na 1 ma ọ bụ na-abụghị nke `push_internal_level`.
    ///
    /// Na-achọ ohere naanị na ihe `Root` mana ọ bụghị isi ọnụ;
    /// ọ gaghi emezi njikwa ọzọ ma ọ bụ ntụnye aka na ọnụ mgbọrọgwụ.
    ///
    /// Panics ọ bụrụ na enweghị ọkwa dị n`ime, yabụ, ọ bụrụ na ọnụ mgbọrọgwụ ahụ bụ akwụkwọ.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SAFETY: anyi kwuru na anyi di n'ime.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SAFETY: anyi gbaziri `self` naanị ya na udi nzipu ya bu nani.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SAFETY: edge izizi na-ebido.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` na-agbanwe agbanwe na `K` na `V`, ọbụlagodi mgbe `BorrowType` bụ `Mut`.
// Nke a ezighi ezi na teknụzụ, mana enweghị ike ibute enweghị nchekwa ọ bụla n'ihi iji `NodeRef` mee ihe n'ihi na anyị na-anọkarị na `K` na `V`.
//
// Agbanyeghị, mgbe ọ bụla ụdị ọha na eze eyiri `NodeRef`, gbaa mbọ hụ na ọ nwere ọdịiche dị mma.
//
/// Akwụkwọ maka ọnụ.
///
/// Typedị a nwere ọtụtụ oke nke na-achịkwa otu o si eme:
/// - `BorrowType`: Dumdị zuru oke nke na-akọwa ụdị mgbazinye ego ma na-eburu ndụ gị niile.
///    - Mgbe nke a bụ `Immut<'a>`, `NodeRef` na-arụ ọrụ dịka `&'a Node`.
///    - Mgbe nke a bụ `ValMut<'a>`, `NodeRef` na-eme ihe dịka `&'a Node` n'ihe gbasara igodo na usoro osisi, mana na-enyekwa ọtụtụ ntụnye mkpụrụedemede nwere ike ịtụle ụkpụrụ niile dị n'osisi ahụ ka ha bi.
///    - Mgbe nke a bụ `Mut<'a>`, `NodeRef` na-eme ihe dịka `&'a mut Node`, agbanyeghị na ntinye ụzọ na-eme ka pointer na-agbanwe agbanwe wee nwekwa ike ibikọ ọnụ.
///    - Mgbe nke a bụ `Owned`, `NodeRef` na-eme ihe dịka `Box<Node>`, mana ọ nweghị mbibi, ma jiri aka ya hichaa ya.
///    - Mgbe nke a bụ `Dying`, `NodeRef` ka na-eme ihe dị ka `Box<Node>`, mana o nwere ụzọ iji bibie osisi ahụ ntakịrị, na ụzọ ndị nkịtị, ọ bụ ezie na akpọghị ya dị ka ọnweghị nsogbu ịkpọ, nwere ike ịkpọ UB ma ọ bụrụ na akpọghị ya.
///
///   Ebe ọ bụ na `NodeRef` ọ bụla na-enye ohere ịgagharị na osisi ahụ, `BorrowType` metụtara osisi ahụ dum, ọ bụghị naanị ọnụ n'onwe ya.
/// - `K` na `V`: Ndị a bụ ụdị igodo na ụkpụrụ echekwara na ọnụ.
/// - `Type`: Nke a nwere ike ịbụ `Leaf`, `Internal`, ma ọ bụ `LeafOrInternal`.
/// Mgbe nke a bụ `Leaf`, `NodeRef` na-atụtụ ọnụ, mgbe nke a bụ `Internal`, `NodeRef` na-atụ aka na ọnụ ime, yana nke a bụ `LeafOrInternal`, `NodeRef` nwere ike na-atụ aka na ụdị ọnụ.
///   `Type` akpọrọ `NodeType` mgbe ejiri ya na mpụga `NodeRef`.
///
/// Ma `BorrowType` na `NodeType` machibidoro usoro ndị anyị na-etinye, iji na-erigbu ụdị nchekwa.Enwere mmachi na ụzọ anyị nwere ike isi tinye ụdị mgbochi ndị a:
/// - Maka ụdị ụdị ọ bụla, naanị anyị nwere ike ịkọwapụta otu ụzọ ma ọ bụ maka otu ụdị.
/// Dịka ọmụmaatụ, anyị enweghị ike ịkọwapụta usoro dị ka `into_kv` maka ihe niile maka `BorrowType` niile, ma ọ bụ otu ugboro maka ụdị niile na-adị ndụ, n'ihi na anyị chọrọ ka ọ weghachite amaokwu `&'a`.
///   Ya mere, anyị na-akọwa ya naanị maka obere ụdị `Immut<'a>`.
/// - Anyị enweghị ike ị nweta mmanye sitere na `Mut<'a>` ka `Immut<'a>`.
///   Ya mere, anyị ga-akpọ `reborrow` n'ụzọ doro anya na `NodeRef` dị ike karị iji ruo usoro dịka `into_kv`.
///
/// Methodszọ niile dị na `NodeRef` nke weghachitere ụfọdụ ụdị nrụtụ aka:
/// - Were `self` site na uru, weghachite oge ndụ nke `BorrowType` buuru.
///   Mgbe ụfọdụ, ịkpọ ụdịrị usoro a, anyị kwesịrị ịkpọ `reborrow_mut`.
/// - Were `self` na ntụnyere, na (implicitly) weghachitere oge nrụtụ aka ahụ na ndụ niile, karịa ndụ niile `BorrowType` buuru.
/// N'ụzọ ahụ, onye na-agbaziri agbaziri agbaziri na-ekwe nkwa na `NodeRef` ka ga-agbaziri ma ọ bụrụhaala na ejiri nloghachi azụ.
///   Methodszọ ndị na-akwado ntinye na-ehulata iwu a site na ịlaghachi pointer raw, ya bụ, ntụgharị na-enweghị ndụ ọ bụla.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Onu ogugu di iche iche nke onu na akwukwo ya di iche, ihe na-agbanwe agbanwe nke enweghi ike ikwuputa ya site na `Type`, na onwe ya adighi echekwa ya.
    /// Naanị anyị kwesịrị ịchekwa elu nke ọnụ mgbọrọgwụ ahụ, ma nweta ọnụ ọnụ ọnụ nke ọ bụla site na ya.
    /// Ga-abụrịrị zero ma ọ bụrụ na `Type` bụ `Leaf` na ndị na-abụghị efu ma ọ bụrụ na `Type` bụ `Internal`.
    ///
    ///
    height: usize,
    /// The pointer ka akwukwo ma ọ bụ esịtidem ọnụ.
    /// Nkọwa nke `InternalNode` na-eme ka o doo anya na pointer ahụ dị irè.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Mepee ederede ederede nke juru n'ọnụ dị ka `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Na-ekpughe data nke eriri dị n'ime.
    ///
    /// Weghachite ptr raw zere ka o zere mmezigharị ihe ndị ọzọ banyere ọnụ ọnụ a.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // Nche: ụdị ọnụ ọgụgụ ọnụọgụ bụ `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Na-ewepu naanị ịnweta data nke ọnụ n'ime.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Na-achọpụta ogologo ọnụ.Nke a bụ ọnụ ọgụgụ nke igodo ma ọ bụ ụkpụrụ.
    /// Ọnụ ọgụgụ nke n'ọnụ bụ `len() + 1`.
    /// Rịba ama na, n'agbanyeghị na ọ dị mma, ịkpọ ọrụ a nwere ike ịnwe mmetụta na-adịghị mma nke nrụtụ aka na-agbanwe agbanwe nke koodu na-adịghị emerụ emerụ kere.
    ///
    pub fn len(&self) -> usize {
        // N'ụzọ dị oke mkpa, anyị na-enweta ohere `len` ebe a.
        // Ọ bụrụ na BorrowType bụ marker::ValMut, enwere ike ịpụta ntụgharị pụrụ iche banyere ụkpụrụ ndị anyị na-agaghị ewepụ.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Laghachi ọnụ ọgụgụ nke ọkwa ndị ọnụ na epupụta dị iche.
    /// Ogologo ogo pụtara na ọnụ bụ akwụkwọ n'onwe ya.
    /// Ọ bụrụ na ị see osisi nwere mgbọrọgwụ n`elu, nọmba ahụ na-ekwu ebe elu ọnụ ọnụ ọnụ ya dị.
    /// Ọ bụrụ na ị see osisi nwere akwụkwọ n`elu ya, ọnụọgụgụ ahụ na-ekwu ka elu osisi ahụ si gbatịkwuo ọnụ ahụ.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Nwa oge weputara ihe ozo, nke anagh agbanwe agbanwe banyere otu uzo.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Na-ekpughe akụkụ akwụkwọ nke akwụkwọ ọ bụla ma ọ bụ ọnụ ọgụgụ dị n'ime.
    ///
    /// Weghachite ptr raw zere ka o zere mmezigharị ihe ndị ọzọ banyere ọnụ ọnụ a.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Ọnụ ahụ ga-adị ire ma ọ dịkarịa ala akụkụ LeafNode.
        // Nke a abụghị ntụnye aka na ụdị NodeRef n'ihi na anyị amaghị ma ọ kwesịrị ịdị iche ma ọ bụ kekọrịta.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Chọta nne na nna nke ọnụnọ ugbu a.
    /// Laghachi `Ok(handle)` ma ọ bụrụ na ọnụ ọgụgụ dị ugbu a enwee nne na nna n'ezie, ebe `handle` na-atụ aka na edge nke nne na nna na-arụtụ aka ọnụ nke ugbu a.
    ///
    /// Laghachi `Err(self)` ma ọ bụrụ na ọnụ ọgụgụ dị ugbu a enweghị nne na nna, na-enyeghachi `NodeRef` mbụ.
    ///
    /// Aha usoro a na-ewere gị foto osisi nwere ọnụ mgbọrọgwụ n'elu.
    ///
    /// `edge.descend().ascend().unwrap()` na `node.ascend().unwrap().descend()` kwesịrị ma, na-aga nke ọma, emela ihe ọ bụla.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Anyị kwesịrị iji akara nrịbama na ọnụ maka n'ihi na, ọ bụrụ na BorrowType bụ marker::ValMut, enwere ike ịpụta ntụgharị pụrụ iche banyere ụkpụrụ ndị anyị na-agaghị emerụ.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Rịba ama na `self` ga-abụ ihe efu.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Rịba ama na `self` ga-abụ ihe efu.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Na-ekpughe akụkụ akwukwo nke akwukwo ọ bụla ma ọ bụ ọnụ nke dị n'ime osisi na-adịghị agbanwe agbanwe.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAFETY: Enweghị ike ịkọwapụta mkpụrụ osisi n'ime osisi a gbaziri dị ka `Immut`.
        unsafe { &*ptr }
    }

    /// Na-ewepụ echiche n'ime igodo ndị echekwara na ọnụ.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Yiri `ascend`, na-ezo aka na ọnụ nne na nna ọnụ, mana na-ekenye ọnụ ebe dị ugbu a na usoro ahụ.
    /// Nke a enweghị nchekwa n'ihi na ọnụnọ dị ugbu a ka ga-enweta ya n'agbanyeghị na agbanwere ya.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// N`adighi obi ike na-ekwuputa onye nchikota ihe omuma di iche na node a bu `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// N`adighi obi ike na-ekwuputa onye nchikota ihe omuma di iche na node a bu `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nwa oge weputa ihe ozo, mgbanwe a na-ekwu maka otu uzo.Kpachara anya, dịka usoro a dị oke egwu, enwere ya abụọ ebe ọ nwere ike ọ gaghị apụta iyi egwu.
    ///
    /// Ebe ọ bụ na ndị na-atụgharị ihe ntụgharị nwere ike ịgagharị ebe ọ bụla gburugburu osisi ahụ, enwere ike iji ntụpọ azụghachiri iji mee ka pointer mbụ ahụ na-atụgharị, na-enweghị oke, ma ọ bụ na-abaghị uru n'okpuru iwu mgbazinye ego.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) tụlee ịgbakwunye ụdị ụdị ọzọ na `NodeRef` nke na-egbochi iji usoro ụzọ igodo ụzọ na ntụpọ azụtagharị, na-egbochi nchekwa a.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Naanị ohere ịnweta akụkụ akwụkwọ nke akwụkwọ ọ bụla ma ọ bụ ọnụ ọgụgụ dị n'ime.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAFETY: Anyị nwere ohere zuru oke na ọnụ ọgụgụ niile.
        unsafe { &mut *ptr }
    }

    /// Enyele nanị ohere ka akwukwo akwukwo nke ọ bụla akwukwo ma ọ bụ esịtidem ọnụ.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAFETY: Anyị nwere ohere zuru oke na ọnụ ọgụgụ niile.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Na-ewepụta naanị ohere maka mmewere nke ebe nchekwa igodo.
    ///
    /// # Safety
    /// `index` dị na njedebe nke 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // MGBE: onye na-akpọ oku agaghị enwe ike ịkpọ usoro ndị ọzọ na onwe ya
        // ruo mgbe igodo iberi kwuru, n'ihi na anyị nwere ohere pụrụ iche maka mgbazinye ego nke oge ahụ.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Na-ewepu ohere zuru oke na ihe mmewere ma ọ bụ iberi nke ebe nchekwa ọnụ ọnụ ọnụ.
    ///
    /// # Safety
    /// `index` dị na njedebe nke 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // MGBE: onye na-akpọ oku agaghị enwe ike ịkpọ usoro ndị ọzọ na onwe ya
        // ruo mgbe bara uru iberi akwụkwọ kwuru okwu, ka anyị nwere ohere pụrụ iche maka ịgbazinye ego maka ndụ anyị niile.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Na-ewepu ohere zuru oke na ihe mmewere ma ọ bụ iberibe nke ebe nchekwa ọnụ maka ọdịnaya edge.
    ///
    /// # Safety
    /// `index` dị na njedebe nke 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // MGBE: onye na-akpọ oku agaghị enwe ike ịkpọ usoro ndị ọzọ na onwe ya
        // rue mgbe edere iberibe edge adaba, ebe anyi nwere ohere puru iche n`oge mgbazinye ego.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Ọnụ ahụ nwere ihe karịrị ihe `idx` bidoro.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Naanị anyị na-emepụta ntụaka maka otu ihe anyị nwere mmasị na ya, iji zere ịkpọ aha ya n'ụzọ pụtara ìhè banyere ihe ndị ọzọ, ọkachasị, ndị ahụ laghachiri na onye na-akpọ oku n'oge gara aga.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Anyị ga-amanye ndị na-enweghị ntụpọ edepụtara n'ihi okwu Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Na-ewebata ohere naanị ogologo nke ọnụ.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Debe njikọ ọnụ ya na nne na nna ya edge, na-enweghị mmebi ntụaka ndị ọzọ banyere ọnụ.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Na-ehichapụ njikọ nke mgbọrọgwụ na nne na nna ya edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Na-agbakwụnye igodo-uru abụọ na njedebe nke ọnụ.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ihe ọ bụla azụtara site na `range` bụ ndenye edge ziri ezi maka ọnụ.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Na-agbakwunye otu ụzọ bara uru, yana edge iji gaa n'aka nri nke ụzọ ahụ, ruo na njedebe nke ọnụ.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Na-enyocha ma ọnụ bụ ọnụ `Internal` ma ọ bụ ọnụ `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Akwụkwọ maka otu isi-uru ma ọ bụ edge dị n`otu ọnụ.
/// Ntọala `Node` ga-abụ `NodeRef`, ebe `Type` nwere ike bụrụ `KV` (na-egosi njide na ụzọ dị mkpa) ma ọ bụ `Edge` (na-egosi njikwa na edge).
///
/// Rịba ama na ọbụna ọnụ `Leaf` nwere ike ịnwe njikwa `Edge`.
/// Kama ịnọchite anya pointer maka ọnụ nwa, ndị a na-anọchite oghere ndị ụmụaka na-atụgharị ga-aga n'etiti ụzọ abụọ bara uru.
/// Dịka ọmụmaatụ, na ọnụ ọnụ na ogologo 2, a ga-enwe ọnọdụ edge 3 nwere ike, otu n'aka ekpe nke ọnụ, otu n'etiti ụzọ abụọ ahụ, na otu n'aka nri nke ọnụ.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Anyị achọghị mkpa zuru ezu nke `#[derive(Clone)]`, n'ihi na naanị oge `Node` ga-abụ ``Clone`able bụ mgbe ọ bụ ntụpọ na-adịghị agbanwe agbanwe yana ya mere `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Na-ewepụta ọnụ nke nwere edge ma ọ bụ ụzọ bara uru ụzọ njikwa a na-ezo aka.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Laghachi ọnọdụ nke njikwa a na ọnụ.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Na-emepụta njikwa ọhụrụ na ọnụọgụ abụọ bara uru na `node`.
    /// Enweghị nchedo n'ihi na onye na-akpọ oku ga-ahụrịrị na `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Nwere ike ịbụ mmezu nke ọha na eze nke PartialEq, mana ejiri ya na modul a.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Nwa oge weputa ozo, nke a na-agaghi agbanwe agbanwe n'otu ebe.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Anyị enweghị ike iji Handle::new_kv ma ọ bụ Handle::new_edge n'ihi na anyị amaghị ụdị anyị
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// N`ekwesighi nchekwube na-ekwuputa onye nchikota ihe omuma nke doro anya na onu aka bu `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Nwa oge na-ewepụta ihe ọzọ, na-agbanwe agbanwe na otu ọnọdụ ahụ.
    /// Kpachara anya, dịka usoro a dị oke egwu, enwere ya abụọ ebe ọ nwere ike ọ gaghị apụta iyi egwu.
    ///
    ///
    /// Maka nkọwa zuru ezu, lee `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Anyị enweghị ike iji Handle::new_kv ma ọ bụ Handle::new_edge n'ihi na anyị amaghị ụdị anyị
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Mepụta njikwa ọhụrụ na edge na `node`.
    /// Enweghị nchedo n'ihi na onye na-akpọ oku ga-ahụrịrị na `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Nyere ederede edge ebe anyị chọrọ itinye n'ime ọnụ jupụtara na ikike, na-agbakọta ndepụta KV nwere ezi uche nke ebe gbawara agbawa na ebe a ga-esi tinye ya.
///
/// Ebumnuche nke isi nkewa bụ maka isi ya na uru ya na njedebe nne na nna;
/// igodo, ụkpụrụ na nsọtụ dị n`aka ekpe nke ebe gbawara agbawa ghọrọ nwa aka ekpe;
/// igodo, ụkpụrụ na akuku aka nri nke ebe gbawara agbawa ghọrọ nwa kwesịrị ekwesị.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust mbipụta #74834 na-agba mbọ ịkọwa iwu ndị a.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserts ọhụrụ isi-uru ụzọ n'etiti isi-uru abụọ na nri na ekpe nke a edge.
    /// Usoro a na-eburu na enwere oghere zuru oke na ọnụ maka ụzọ ọhụrụ iji dabaa.
    ///
    /// Pointer ahụ laghachiri na-atụnye uru ịtinye.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserts ọhụrụ isi-uru ụzọ n'etiti isi-uru abụọ na nri na ekpe nke a edge.
    /// Usoro a na-ekewa ọnụ ma ọ bụrụ na ezughị ezu.
    ///
    /// Pointer ahụ laghachiri na-atụnye uru ịtinye.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fixes ndị nne na nna pointer na ndeksi na nwa ọnụ na a edge njikọ.
    /// Nke a bara uru mgbe a gbanwere iwu ịtụ,
    fn correct_parent_link(self) {
        // Mepụta backpoter na-enweghị mmebi ọzọ ndị e zoro aka na ọnụ.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fanye igodo ohuru bara uru abuo na edge nke gha agha n`aka nri nke uzo ohuru a di n`etiti edge na uzo uzo di nma n`aka nri nke edge a.
    /// Usoro a na-eburu na enwere oghere zuru oke na ọnụ maka ụzọ ọhụrụ iji dabaa.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Fanye igodo ohuru bara uru abuo na edge nke gha agha n`aka nri nke uzo ohuru a di n`etiti edge na uzo uzo di nma n`aka nri nke edge a.
    /// Usoro a na-ekewa ọnụ ma ọ bụrụ na ezughị ezu.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserts ọhụrụ isi-uru ụzọ n'etiti isi-uru abụọ na nri na ekpe nke a edge.
    /// Usoro a na-ekewa ọnụ ma ọ bụrụ na ezughị ezu, ma gbalịa itinye akụkụ ahụ gbawara n'ime ọnụ nne na nna na-agagharị, ruo mgbe mgbọrọgwụ ahụ ruru.
    ///
    ///
    /// Ọ bụrụ na nsonaazụ azụ bụ `Fit`, ọnụ njikwa ya nwere ike ịbụ ọnụ edge ma ọ bụ nna nna ya.
    /// Ọ bụrụ na nsonaazụ laghachiri bụ `Split`, mpaghara `left` ga-abụ ọnụ mgbọrọgwụ.
    /// Pointer ahụ laghachiri na-atụnye uru ịtinye.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Chọta ọnụ ahụ nke edge a gosipụtara.
    ///
    /// Aha usoro a na-ewere gị foto osisi nwere ọnụ mgbọrọgwụ n'elu.
    ///
    /// `edge.descend().ascend().unwrap()` na `node.ascend().unwrap().descend()` kwesịrị ma, na-aga nke ọma, emela ihe ọ bụla.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Anyị kwesịrị iji akara nrịbama na ọnụ maka n'ihi na, ọ bụrụ na BorrowType bụ marker::ValMut, enwere ike ịpụta ntụgharị pụrụ iche banyere ụkpụrụ ndị anyị na-agaghị emerụ.
        // Enweghị nchekasị ịnweta ohere dị elu n'ihi na a na-edepụtaghachi uru ahụ.
        // Kpachara anya na, ozugbo edere ntụpọ ọnụ ahụ, anyị na-enweta akụkụ dị n'akụkụ ya na ntụaka (Rust mbipụta #73987) wee mebie aha ndị ọzọ na-enweghị ma ọ bụ n'ime usoro ahụ, kwesịrị ka ndị ọzọ nọrọ.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Anyị enweghị ike ịkpọ usoro dị iche iche na ụzọ bara uru, n'ihi na ịkpọ nke abụọ na-eme ka nrụtụ aka nke izizi ghara ịdị.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Dochie isi na uru nke aka KV na-ezo aka.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Na-enyere aka na ntinye nke `split` maka otu `NodeType`, site na ilekọta data akwukwo.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Kewara isi okwu ahụ ụzọ atọ:
    ///
    /// - A na-ebelata ọnụ ahụ ka ọ bụrụ naanị iji ụzọ abụọ bara uru n`aka ekpe nke aka a.
    /// - Igodo na uru nke aka a gosipụtara.
    /// - A na-etinye ụzọ abụọ dị oke ọnụ ahịa n'aka nri nke njikwa a n'ime oghere ekenyela ọhụrụ.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Na-ewepu ụzọ isi ihe bara uru nke aka a rụtụrụ aka wee weghachite ya, yana edge nke ụzọ ụzọ uru ahụ dabara.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Kewara isi okwu ahụ ụzọ atọ:
    ///
    /// - A na-ebelata ọnụ ahụ ka ọ bụrụ naanị nwere ọnụ ya na ụzọ abụọ bara uru n`aka ekpe nke aka a.
    /// - Igodo na uru nke aka a gosipụtara.
    /// - All n'ọnụ ọnụ na isi-uru abụọ na nri nke a njikwa na-etinye n'ime ọhụrụ ekenyela ọnụ.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Na-anọchi anya oge maka ịtụle na ịrụ ọrụ guzozie gburugburu otu ụzọ dị mkpa dị n'ime.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Na-ahọrọ ọnọdụ nhazi nke metụtara ọnụ dị ka nwatakịrị, si otú a n'etiti KV ozugbo gaa n'aka ekpe ma ọ bụ aka nri na ọnụ nne na nna.
    /// Laghachi na `Err` ma ọ bụrụ na enweghị nne ma ọ bụ nna.
    /// Panics ma ọ bụrụ na nne na nna efu.
    ///
    /// Na-ahọrọ akụkụ aka ekpe, ka ọ bụrụ nke kachasị mma ma ọ bụrụ na ọnụnọ a na-enye ya bụ n'ụzọ zuru oke, nke pụtara ebe a naanị na o nwere ihe ole na ole karịa nwanne aka ekpe ya na karịa nwanne ya ziri ezi, ma ọ bụrụ na ha dị.
    /// N'okwu ahụ, ịjikọ ọnụ na nwanne aka ekpe dị ngwa karịa, ebe ọ bụ naanị na anyị kwesịrị ịkwaga ihe N, ọnụ, kama ịtụgharị ya n'aka nri wee gaa karịa ihe N n'ihu.
    /// Alingzu ohi site n'aka nwanne aka ekpe dịkwakarị ọsọ ọsọ, ebe ọ bụ naanị na anyị kwesịrị ịgbanwere ihe N nke ọnụ ahụ n'aka nri, kama ịgbanwere ma ọ dịkarịa ala N nke nwanne ahụ n'aka ekpe.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Alaghachi azụ ma njikọta ọ ga-ekwe omume, yabụ, ma enwere ụlọ zuru oke na ọnụ ọnụ iji jikọta Central KV yana akụkụ nwa dị n'akụkụ ya.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Na-arụ ọrụ jikọrọ ọnụ wee na-eme ka mmechi kpebie ihe ị ga-alaghachi.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAFETY: Ogo nke ọnụ a na-ejikọta ọnụ dị n'okpuru elu
                // nke ọnụ nke edge a, si otú a dị n'elu efu, n'ihi ya ha dị n'ime.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Jikọtara ọnụ ụzọ nne na nna ahụ bara uru ma jikọtara nwa ọnụ n'akụkụ aka ekpe nwa wee laghachi ọnụ nne na nna ahụ.
    ///
    ///
    /// Panics belụsọ anyị `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Jikọtara ọnụ ụzọ nne na nna ahụ bara uru ma jikọtara nwa ọnụ n'akụkụ aka ekpe nwa ahụ wee laghachi ọnụ nwa ahụ.
    ///
    ///
    /// Panics belụsọ anyị `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Jikọtara ọnụ ụzọ nne na nna ahụ bara uru ma jikọtara nwa ọnụ n'akụkụ aka ekpe nwa ahụ wee weghachite njikwa edge na ọnụ nwa ahụ ebe nwa ahụ edge esororo biri,
    ///
    ///
    /// Panics belụsọ anyị `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Wepu otu ụzọ bara uru site na nwa aka ekpe wee debe ya na nchekwa nke isi nke nne na nna, ka ị na-amanye nne na nna ochie na-aba uru n'ime nwa aka nri.
    ///
    /// Weghachi aka na edge na aka nri ya bụ nke kwekọrọ na ebe edge mbụ nke `track_right_edge_idx` kwuru.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Wepu otu ụzọ bara uru site n'aka nwa ziri ezi wee debe ya na nchekwa nchekwa nke nne na nna, na-agbanye nne na nna ochie nne na nna-uru na nwa aka ekpe.
    ///
    /// Weghachi aka na edge na nwa aka ekpe nke `track_left_edge_idx` kwuru, nke na agaghi imeghari.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Nke a na-ezu ohi yiri `steal_left` mana na-ezu ohi ọtụtụ ihe n'otu oge.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Jide n'aka na anyị nwere ike izu ohi n'enweghị nsogbu.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Bugharịa akwukwo akwukwo.
            {
                // Nye ohere maka ihe ezuru ezu na nwa kwesịrị ekwesị.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Bugharịa ihe site n`aka ekpe n`aka ekpe gaa n`aka nri.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Bugharịa ihe ndị kacha bụrụ aka ekpe n`aka nne na nna ahụ.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Bugharịa isi ihe bara uru nke nne na nna gaa n`aka nri.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Nye ohere maka akụkụ ezuru ezu.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Zuru n'ọnụ ya.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Ihe omuma nke ihe omuma nke `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Jide n'aka na anyị nwere ike izu ohi n'enweghị nsogbu.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Bugharịa akwukwo akwukwo.
            {
                // Bugharịa ụzọ kacha zuo ohi n`aka nne na nna.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Bugharịa isi ihe bara uru nke nne na nna n`aka nwa aka ekpe.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Bugharịa ihe site n`aka nri gaa n`aka ekpe.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Dejupụta oghere ebe ihe ndị ezuru ezu.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Zuru n'ọnụ ya.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Dejupụta oghere ebe ndị ezuru ohi na-adịbu.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Wepu ozi ọ bụla dị iche iche na-egosi na ọnụ ọnụ a bụ ọnụ `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Wepu ozi ọ bụla dị iche iche na-egosi na ọnụ ọnụ a bụ ọnụ `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Na-enyocha ma ọnụnọ ya bụ ọnụ `Internal` ma ọ bụ ọnụ `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Bugharịa suffix mgbe `self` si n'otu ọnụ gaa na nke ọzọ.`right` ga-atọgbọrọ chakoo.
    /// edge izizi nke `right` agbanwebeghị.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Nsonaazụ nke ntinye, mgbe achọrọ ọnụ gbasaa karịa ike ya.
pub struct SplitResult<'a, K, V, NodeType> {
    // Gbanwee ọnụ n'ime osisi dị ugbu a nwere ihe na akụkụ dị n'akụkụ aka ekpe nke `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Keyfọdụ igodo na uru kewara, ka etinyere ha ebe ọzọ.
    pub kv: (K, V),
    // Nwepu, nke ejikọtaghị, ọnụ ọhụụ ọhụụ nwere ihe na akụkụ dị n'akụkụ aka nri nke `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ma ederede ọnụ nke ụdị agbaziri nke a na-ekwe ka ịgafe n'akụkụ ndị ọzọ na osisi ahụ.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal adịghị mkpa, ọ na-eme site na nsonaazụ nke `borrow_mut`.
        // Site na iwepu ngagharị, yana naanị imepụta ntụzịaka ọhụrụ na mgbọrọgwụ, anyị maara na ntụnye ọ bụla nke ụdị `Owned` bụ na ọnụ mgbọrọgwụ.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Fanye a uru n'ime iberi nke initialized ọcha sochiri otu uninitialized mmewere.
///
/// # Safety
/// Mberi nwere ihe karịrị `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Na-ewepu ma weghachite uru site na iberibe ihe niile ebido, na-ahapụ otu ihe na-eme ka ọ ghara ịmalite.
///
///
/// # Safety
/// Mberi nwere ihe karịrị `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Na-agbanwe ihe ndị dị na ọnọdụ `distance` iberi n'aka ekpe.
///
/// # Safety
/// Mberi ahụ nwere ma ọ dịkarịa ala ihe `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Na-agbanwe ihe ndị dị na ọnọdụ `distance` iberi n'aka nri.
///
/// # Safety
/// Mberi ahụ nwere ma ọ dịkarịa ala ihe `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Na-eme ka ụkpụrụ niile dị na iberibe ihe ndị amalitebere gaa na mpekere nke ihe ndị na-amaghị ihe, na-ahapụ `src` dị ka ndị niile amaghị ihe.
///
/// Na-arụ ọrụ dịka `dst.copy_from_slice(src)` mana ọ chọghị `T` ka ọ bụrụ `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;