use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Bkpụrụ nke ugbo ala na-enyocha oge dum na-enyocha ihe omume ụfọdụ.
/// Enwere ike ịhazi ụfọdụ oge na panic n'oge ụfọdụ.
/// Ihe omume bụ `clone`, `drop` ma ọ bụ ụfọdụ `query` na-amaghị aha.
///
/// Achọpụtara ihe ndị a na-akpọ Crash ma na-enye iwu site na id, yabụ enwere ike iji ha dị ka igodo na BTreeMap.
/// Mmejuputa ihe a na-eji aka eme ihe adighi adabere na ihe obula akowara na crate, ewezuga `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Mepụta a okuku ule dummy imewe.`id` na-ekpebi usoro na nha anya nke ihe.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Na--emepụta ihe atụ nke nnwale nnwale na-edetu ihe omume ọ nwetara na ma họrọ panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Alaghachi ugboro ole mgbe nke dummy na-cloned.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Alaghachi ugboro ole ufodu nke dummy ka adabala.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Laghachi ugboro ole nke dummy ka akpọrọ onye `query` ha.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Qufọdụ ajụjụ na-enweghị aha, enyerela nsonaazụ ya.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}