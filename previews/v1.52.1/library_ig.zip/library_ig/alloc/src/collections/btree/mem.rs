use core::intrinsics;
use core::mem;
use core::ptr;

/// Nke a na-anọchi uru dị n`azụ `v` pụrụ iche site na ịkpọ ọrụ dị mkpa.
///
///
/// Ọ bụrụ na panic pụtara na mmechi `change`, a ga-ete ime usoro ahụ dum.
#[allow(dead_code)] // debe dị ka ihe atụ na maka iji future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Nke a dochiri uru dị n`azụ akwụkwọ pụrụ iche nke `v` site na ịkpọ ọrụ dị mkpa, wee weghachite nsonaazụ enwetara n`okporo ụzọ.
///
///
/// Ọ bụrụ na panic pụtara na mmechi `change`, a ga-ete ime usoro ahụ dum.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}