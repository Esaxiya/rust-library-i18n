//! A mkpa kwụ n'ahịrị emejuputa atumatu na a ọnụọgụ abụọ kpokọtara.
//!
//! Ntinye na ịmalite ihe kachasị ukwuu nwere oge *O*(log(*n*)).
//! Ckinglele ihe kachasị bu *O*(1).Vertụgharị vector ka ọ bụrụ ebe a na-emepụta ọnụọgụ abụọ enwere ike ịme na-ebe, ma nwee mgbagwoju anya *O*(*n*).
//! Enwere ike ịtụgharị mkpọmkpọ ebe na vector dị iche iche edobe ya, na-ekwe ka ejiri ya maka ebe a na-ekpo ekpo *O*(*n*\*log(* n*)).
//!
//! # Examples
//!
//! Nke a bụ ihe atụ buru ibu nke na-etinye [Dijkstra's algorithm][dijkstra] n'ọrụ iji dozie [shortest path problem][sssp] na [directed graph][dir_graph].
//!
//! O gosiputara otu esi eji [`BinaryHeap`] ya na udiri omenala.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Ihu kwụ n'ahịrị na-adabere na `Ord`.
//! // Mejuputa trait n'ụzọ doro anya ka ahịrị ahụ wee bụrụ mkpọmkpọ ebe karịa oke-ikpo.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Rịba ama na anyị tụgharịa ịtụ na-akwụ ụgwọ.
//!         // N'ihe banyere agbụ anyị na-atụle ọnọdụ, usoro a dị mkpa iji mejuputa mmejuputa nke `PartialEq` na `Ord` na-agbanwe agbanwe.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` kwesịrị itinye ya n'ọrụ.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // A na-anọchite ọnụ ọ bụla dị ka `usize`, maka ntinye dị mkpirikpi.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra kacha nso ụzọ algorithm.
//!
//! // Bido na `start` ma jiri `dist` soro ụzọ kacha nso dị ugbu a na ọnụ ọgụgụ ọ bụla.Mmejuputa iwu a abughi oru nchekwa dika o nwere ike hapu uzo di iche na akwukwo.
//! //
//! // Ọ na-ejikwa `usize::MAX` dị ka uru ezipụ, maka mmejuputa dị mfe.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=ụzọ kacha nso dị ugbu a site na `start` ruo `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Anyị nọ na `start`, na efu efu
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Nyochaa ókèala na ọnụ ọnụ ọnụ ala mbụ (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // N'aka nke ọzọ anyị gaara enwe ike ịga n'ihu chọta ụzọ niile dịkarịsịrị nso
//!         if position == goal { return Some(cost); }
//!
//!         // Dị mkpa dị ka anyị nwere ike ịchọtaworị ụzọ ka mma
//!         if cost > dist[position] { continue; }
//!
//!         // Maka ọnụ nke ọ bụla anyị nwere ike iru, lee ma anyị ga-ahụ ụzọ nwere ọnụ ala dị ala gafere ọnụ ọnụ a
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ọ bụrụ otu a, tinye ya n`ókè ma gaa n`ihu
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Izu ike, anyị achọtala ụzọ ka mma
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Ebumnuche agaghị emezu
//!     None
//! }
//!
//! fn main() {
//!     // Nke a bụ ihe eserese a na-eduzi anyị ga-eji.
//!     // Nọmba ọnụ ahụ kwekọrọ na steeti dị iche iche, ibu edge na-anọchi anya ụgwọ isi na-esi n`otu ọnụ gaa na nke ọzọ.
//!     //
//!     // Rịba ama na n'ọnụ ya bụ otu ụzọ.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // A na-anọchite eserese a dị ka ndepụta adjacency ebe ndepụta ọ bụla, nke kwekọrọ na ọnụ ọnụ ọnụ, nwere ndepụta nke akụkụ na-apụ apụ.
//!     // Họọrọ maka arụmọrụ ya.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nọmba 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Igodo 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Igodo 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nọmba 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Igodo 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// A mkpa kwụ n'ahịrị emejuputa atumatu na a ọnụọgụ abụọ kpokọtara.
///
/// Nke a ga-abụ oke-ikpo.
///
/// Ọ bụ njehie ezi uche maka ihe a ga-agbanwe n'ụzọ ọ bụla na ihe ihe ahụ na-enye iwu maka ihe ọ bụla ọzọ, dị ka `Ord` trait kpebiri, gbanwere mgbe ọ nọ na ikpo.
///
/// Nke a ga-ekwe omume naanị site na `Cell`, `RefCell`, steeti ụwa, I/O, ma ọ bụ koodu enweghị nchekwa.
/// Akọwapụtaghị akparamagwa nke ụdị mmehie ahụ, mana ọ gaghị ebute agwa anaghị akọwacha ya.
/// Nke a nwere ike ịgụnye panics, nsonaazụ na-ezighi ezi, ịwepụ afọ ime, nkwụsị ebe nchekwa, na enweghị nkwụsị.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Indị ntinye aka na-ahapụ anyị ịhapụ ụdị mbinye aka doro anya (nke ga-abụ `BinaryHeap<i32>` na ihe atụ a).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Anyị nwere ike iji peek lee ihe na-esote n`akpo.
/// // N'okwu a, enweghị ihe ọ bụla n'ime ebe ahụ mana anyị enwetaghị Ọdịdị.
/// assert_eq!(heap.peek(), None);
///
/// // Ka anyị tinye ụfọdụ akara ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Ugbu a peek na-egosi ihe kachasị mkpa na kpokọtara.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Anyị nwere ike ịlele ogologo ikpo.
/// assert_eq!(heap.len(), 3);
///
/// // Anyị nwere ike ịgabiga ihe ndị ahụ na kpokọtara, ọ bụ ezie na a na-eweghachi ha n'usoro.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Y'oburu na anyi mee akara ndia, ha gha aghaghachi n'usoro.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Anyị nwere ike ikpochasị ihe niile fọrọ afọ.
/// heap.clear();
///
/// // Okpokoro kwesịrị ịtọgbọ chakoo ugbu a.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Enwere ike iji `std::cmp::Reverse` ma ọ bụ mmemme `Ord` mee ihe iji mee `BinaryHeap` min-heap.
/// Nke a na-eme `heap.pop()` ịlaghachi obere uru karịa nke kachasị.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Kechie ụkpụrụ na `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ọ bụrụ na anyị pụta akara ndị a ugbu a, ha kwesịrị ịlaghachi na usoro ntụgharị.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Oge mgbagwoju anya
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Uru maka `push` bụ ego a tụrụ anya ya;usoro usoro na-enye nyocha zuru ezu karị.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Ebumnuche na-etinye aka na ihe kachasị ukwuu na `BinaryHeap`.
///
///
/// Emebere `struct` a site na usoro [`peek_mut`] na [`BinaryHeap`].
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SAFETY: PeekMut bụ naanị instantiated maka na-abụghị efu obo.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut bụ naanị instantiated maka na-abụghị efu obo
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut bụ naanị instantiated maka na-abụghị efu obo
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Ewepu peeked uru si na kpokọtara wee laghachi ya.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Mepụta `BinaryHeap<T>` efu.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Mepụta `BinaryHeap` efu dị ka oke ikpo.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Mepụta `BinaryHeap` efu na ikike a kapịrị ọnụ.
    /// Nke a na-ebute ebe nchekwa zuru ezu maka ihe `capacity`, nke mere na `BinaryHeap` ekwesighi ịhazigharị ya ruo mgbe ọ nwere opekata mpe ọtụtụ ụkpụrụ.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Laghachi a mutable akwụkwọ na ihe kasị ukwuu na ọnụọgụ abụọ kpokọtara, ma ọ bụ `None` ma ọ bụrụ na ọ bụ ihe efu.
    ///
    /// Note: Ọ bụrụ na ọnụọgụ `PeekMut` bara ụba, ikpo ahụ nwere ike ịbụ ọnọdụ na-ekwekọghị ekwekọ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Oge mgbagwoju anya
    ///
    /// Ọ bụrụ na agbanwere ihe ahụ, oge kachasị njọ oge dị mgbagwoju anya bụ *O*(log(*n*)), ma ọ bụghị ya *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Wepu ihe kachasị ukwuu na ọnụọgụ ọnụọgụ abụọ ma weghachite ya, ma ọ bụ `None` ma ọ bụrụ na ọ tọgbọ chakoo.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Oge mgbagwoju anya
    ///
    /// Ọnụ ego kachasị njọ nke `pop` na kpokọtara nwere *n* ihe bụ *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SAFETY: !self.is_empty() pụtara na self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Pushes ihe n'elu ọnụọgụ abụọ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Oge mgbagwoju anya
    ///
    /// Ego a na-atụ anya nke `push`, a na-akwụ ụgwọ maka usoro ọ bụla nke ihe ndị a na-agbanye, yana ọnụ ọgụgụ buru ibu nke ntinye, bụ *O*(1).
    ///
    /// Nke a bụ ọnụọgụ ego kachasị baa uru mgbe ị na-agbanye ihe ndị na-abụghị * ọ bụla n'ụkpụrụ ọ bụla.
    ///
    /// Oge mgbagwoju anya na-eweda ala ma ọ bụrụ na ihe dị iche iche na-arị elu n'usoro.
    /// N'ọnọdụ kachasị njọ, a na-agbanye ihe dị iche iche na-arịgo elu na ọnụ ahịa amortized kwa nkwụsị bụ *O*(log(*n*)) megide kpokọtara nwere *n*.
    ///
    /// Ọnọdụ kachasị njọ nke otu *oku* na-akpọ `push` bụ *O*(*n*).Ihe kachasị njọ na-eme mgbe ike gwụrụ ma chọọ nha.
    /// Egogo ego a na-akwụghachi na ọnụ ọgụgụ ndị gara aga.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SAFETY: Ebe anyi tufuru ihe ohuru o putara na
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Na-eri `BinaryHeap` ma weghachite vector na usoro (ascending) iche.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAFETY: `end` si na `self.len() - 1` gaa 1 (ha abuo),
            //  n'ihi ya, ọ bụ mgbe niile a nti ndeksi iji nweta.
            //  Ọ dị mma ịnweta ndeksi 0 (ntụgharị `ptr`), n'ihi na
            //  1 <=ọgwụgwụ <self.len(), nke pụtara self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAFETY: `end` si na `self.len() - 1` gaa 1 (ha abuo) ya mere:
            //  0 <1 <=njedebe <= self.len(), 1 <self.len() Nke pụtara 0 <nkwụsị na njedebe <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Mmejuputa nke sift_up na sift_down jiri nghota echedoro iji wepu mmewere na vector (na-ahapu oghere), gbanwee ndi ozo ma megharia ihe ewepuru weghachiri na vector na ebe ikpeazu nke oghere.
    //
    // A na-eji ụdị `Hole` eme ihe iji gosipụta nke a, ma gbaa mbọ hụ na oghere ahụ juputara na njedebe nke akụkụ ya, ọbụlagodi na panic.
    // Iji oghere mee ihe na-ebelata ihe na-adịgide adịgide ma e jiri ya tụnyere iji swaps, nke gụnyere okpukpu abụọ ka ọ na-agagharị.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Onye na-akpọ oku ga-ekwenye na `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Wepụ uru na `pos` wee mepụta oghere.
        // SAFETY: Onye na-akpọ oku na-ekwe nkwa pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // Nchedo: hole.pos()> bido>=0, nke putara hole.pos()> 0
            //  ya mere hole.pos(), 1 enweghi ike igba mmiri.
            //  Nke a na-ekwe nkwa na nne na nna <hole.pos() yabụ ọ bụ ezigbo ndeksi yana kwa!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAFETY: Otu dị n'elu
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Were mmewere na `pos` ma bugharịa ya n`ala, ebe ụmụ ya ka ibu.
    ///
    ///
    /// # Safety
    ///
    /// Onye na-akpọ oku ga-ekwenye na `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // MGBE: Onye na-akpọ oku na-ekwe nkwa na pos <ọgwụgwụ <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop anaghị agbanwe agbanwe: nwa==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // jiri ya tụnyere nke ka ukwuu n'ime ụmụ abụọ ahụ SAFETY: nwa <end, 1 <self.len() and child + 1 <end <= self.len(), yabụ ha bụ ezigbo ederede.
            //
            //  nwa==2 *hole.pos() + 1!= hole.pos() na nwata + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ma ọ bụ 2* hole.pos() + 2 nwere ike iju ma ọ bụrụ na T bụ ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ọ bụrụ na anyị adịworị n'usoro, kwụsị.
            // MGBE AH child: nwatakịrị bụla agadi ma ọ bụ agadi nwa + 1
            //  Anyị egosiworị na ha abụọ bụ <self.len() na!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAFETY: same as above.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAFETY: &&circuit circuit, nke pụtara na
        //  ọnọdụ nke abụọ ọ bụla eziokwu na nwa ahụ==njedebe, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAFETY: Nwa egosila na ọ bụ ezigbo ndeksi na
            //  nwata==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Onye na-akpọ oku ga-ekwenye na `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAFETY: pos <len bụ nkwa nke onye na-akpọ oku na
        //  doro anya len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Were ihe mmewere na `pos` ma kpalie ya niile n`oche ahụ, wepụchaa ya n`ọnọdụ ya.
    ///
    ///
    /// Note: Nke a na-eme ngwa ngwa ngwa ngwa karịa ka ihe mmewere mara buru ibu/kwesịrị ịbịaru nso na ala.
    ///
    /// # Safety
    ///
    /// Onye na-akpọ oku ga-ekwenye na `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAFETY: Onye na-akpọ oku na-ekwe nkwa pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop anaghị agbanwe agbanwe: nwa==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SAFETY: nwa <end, 1 <self.len() and
            //  nwa + 1 <ọgwụgwụ <= self.len(), yabụ ha bụ ezigbo ederede.
            //  nwa==2 *hole.pos() + 1!= hole.pos() na nwata + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ma ọ bụ 2* hole.pos() + 2 nwere ike iju ma ọ bụrụ na T bụ ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAFETY: Otu dị n'elu
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAFETY: child==end, 1 <self.len(), ya mere odi nkenke
            //  na nwa==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // Nchekwa: pos bụ ọnọdụ dị n'ime oghere ma gosipụta ya
        //  ka ọ bụrụ ndeksi ziri ezi.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAFETY: n na-ebido na self.len()/2 wee gbadaa na 0.
            //  Naanị ikpe mgbe! (N <self.len()) bụ ma ọ bụrụ self.len() ==0, mana ọ na-achịkwa ya site na ọnọdụ akaghị.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Na-ebugharị ihe niile nke `other` n'ime `self`, na-ahapụ `other` efu.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` na-ewere ọrụ O(len1 + len2) na ihe gbasara 2 *(len1 + len2) na-atụnyere n'ọnọdụ kachasị njọ ebe `extend` na-ewere arụmọrụ O(len2* log(len1)) yana ihe atụ 1 *len2* log_2(len1) na nke kachasị njọ, na-ewere len1>= len2.
        // Maka nnukwu ikpo, isi ihe gafere esoro echiche a wee kpebisie ike.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Ologhachi ite iterie na-eweghachite ihe dị na mkpo.
    /// A na-ewepụ ihe ndị ahụ weghachite na mkpo ahụ.
    /// A ga-ewepụ ihe ndị fọdụrụ na nkpokọ na mkpo.
    ///
    /// Note:
    /// * `.drain_sorted()` bụ *O*(*n*\*log(* n*)); dị nwayọ nwayọ karịa `.drain()`.
    ///   Kwesịrị iji nke ikpeazụ maka ọtụtụ okwu.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // na-ewepu ihe niile n`usoro ikpo
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Na-ejigide naanị ihe ndị akọwapụtara akọwapụtara.
    ///
    /// Yabụ, wepụ ihe niile `e` dị ka `f(&e)` laghachiri `false`.
    /// A na-eleta ihe ndị ahụ na-enweghị usoro (na akọwapụtaghị).
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // naanị debekwa ọnụọgụ
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Laghachiri otu iterator na-eleta ụkpụrụ niile dị n'okpuru vector, n'usoro aka ike.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Bipute 1, 2, 3, 4 n'usoro aka ike
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Ologhachi ite iterie na-eweghachite ihe dị na mkpo.
    /// Usoro a na-erepịa ihe mbụ ahụ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Weghachite nnukwu ihe na ọnụọgụ abụọ, ma ọ bụ `None` ma ọ bụrụ na ọ tọgbọ chakoo.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Oge mgbagwoju anya
    ///
    /// Efu bụ *O*(1) n'ọnọdụ kacha njọ.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Alaghachiri ọnụ ọgụgụ nke ihe ọnụọgụ abụọ kpokọtara nwere ike ijide na-enweghị reallocating.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Echebe ikike opekempe maka kpọmkwem `additional` ihe ndị ọzọ ka etinyere na `BinaryHeap` enyere.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// Rịba ama na onye na-ekenye ya nwere ike inye nchịkọta ahụ ohere karịa ka ọ chọrọ.
    /// Ya mere ikike-apụghị ịdabere na-abụ kpomkwem ntakiri.
    /// Na-ahọrọ [`reserve`] ma ọ bụrụ na a na-atụ anya ntinye ntinye future.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ikike ohuru ejuputa `usize`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Echebe ikike maka opekata mpe `additional` ihe ndị ọzọ ka etinyere na `BinaryHeap`.
    /// Nchịkọta ahụ nwere ike idowe ohere dị ukwuu iji zere ịmegharị ọtụtụ oge.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ikike ohuru ejuputa `usize`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Chọpụta ikike dị ka o kwere mee.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Discards ikike nwere obere agbụ.
    ///
    /// Ikike ahụ ga-adịgide ma ọ dịkarịa ala ka o buru ibu dị ka ogologo ma ogologo.
    ///
    ///
    /// Ọ bụrụ na ikike dị ugbu a dị obere karịa oke ala, nke a bụ enweghị op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Na-eri `BinaryHeap` ma weghachite vector na-akpata ya na usoro aka ike.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Ga-ebipụta na ụfọdụ iji
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Laghachi ogologo nke ọnụọgụ abụọ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Na-achọpụta ma ọ bụrụ na ọnụọgụ abụọ abaghị uru.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Na-ekpocha ọnụọgụ abụọ, weghachite onye na-edegharị ihe maka ihe ndị ewepụrụ.
    ///
    /// A na-ewepụ ihe ndị ahụ n'usoro aka ike.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Dọrọ ihe niile na ọnụọgụ abụọ.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Oghere na-anọchi anya oghere na iberi ntụgharị ntụgharị, ndeksi na-enweghị ezigbo uru (n'ihi na a na-esite na ya ma ọ bụ mepụta ya).
///
/// Na dobe, `Hole` ga-eweghachi iberi ahụ site na ijupụta oghere oghere na uru nke ewepụrụ na mbụ.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Mepụta `Hole` ọhụrụ na ndeksi `pos`.
    ///
    /// Enweghị nchedo n'ihi na pos ga-adị n'ime iberi data.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // OZI: pos kwesịrị ịdị n'ime iberi ahụ
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Laghachiri ederede maka mmewere wepụrụ.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Weghachite ntụnye aka na mmewere na `index`.
    ///
    /// Enweghị nchedo n'ihi na ndepụta ga-adị n'ime iberi data ma hara nha pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Bugharịa oghere na ọnọdụ ọhụrụ
    ///
    /// Enweghị nchedo n'ihi na ndepụta ga-adị n'ime iberi data ma hara nha pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // jupụta olulu ahụ ọzọ
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Otu iteratororer ihe nke `BinaryHeap`.
///
/// `struct` a ka [`BinaryHeap::iter()`] kere.
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Wepụ na ihu ọma nke `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Onye na-ekwu okwu banyere ihe `BinaryHeap`.
///
/// `struct` a ka [`BinaryHeap::into_iter()`] kere (nke `IntoIterator` trait nyere).
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Onye na-agba mmiri na-agba mmiri gbasara `BinaryHeap`.
///
/// `struct` a ka [`BinaryHeap::drain()`] kere.
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Onye na-agba mmiri na-agba mmiri gbasara `BinaryHeap`.
///
/// `struct` a ka [`BinaryHeap::drain_sorted()`] kere.
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Ewepu kpokọtara ke kpokọtara iji.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Gbanwee `Vec<T>` ka ọ bụrụ `BinaryHeap<T>`.
    ///
    /// Ntughari a na-eme n'ime ebe, ma nwee mgbagwoju anya *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Gbanwee `BinaryHeap<T>` ka ọ bụrụ `Vec<T>`.
    ///
    /// Ntughari a choghi mmeghari data ma obu nhazi, ma nwee oge mgbagwoju anya.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Na-emepụta onye na-eri ihe, ya bụ, nke na-eme ka uru ọ bụla pụọ na ikpo ọnụọgụ abụọ na usoro iwu aka ike.
    /// Enweghị ike iji ikpo ọnụọgụ abụọ kpọọ nke a.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Bipute 1, 2, 3, 4 n'usoro aka ike
    /// for x in heap.into_iter() {
    ///     // x nwere ụdị i32, ọ bụghị &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}