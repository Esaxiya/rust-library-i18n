//! A UTF-8 - koodu, na-eto eto.
//!
//! Modul a nwere ụdị [`String`], [`ToString`] trait maka ịtụgharị na eriri, yana ọtụtụ ụdị njehie nke nwere ike ịpụta na-arụ ọrụ na [``String`] s.
//!
//!
//! # Examples
//!
//! Enwere ọtụtụ ụzọ iji mepụta [`String`] ọhụrụ site na eriri nkịtị:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Nwere ike ịmepụta [`String`] ọhụrụ site na nke dị ugbu a site na ịmekọrịta na
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ọ bụrụ na ị nwere vector nke UTF-8 bytes ziri ezi, ị nwere ike ime [`String`] na ya.I nwere ike ime agbara kwa.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Anyị maara na bytes ndị a dị mma, yabụ anyị ga-eji `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// A UTF-8 - koodu, na-eto eto.
///
/// Xdị `String` bụ ụdị ụdọ kachasị dịkarịsịrị nke nwere ihe karịrị nke ọdịnaya eriri ahụ.O nwere mmekorita chiri anya ya na ndi ya na ya biiri, nke ochie [`str`].
///
/// # Examples
///
/// Nwere ike ịmepụta `String` si [a literal string][`str`] na [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// I nwere ike gbakwunyere a [`char`] ka a `String` na [`push`] usoro, na gbakwunyere a [`&str`] na [`push_str`] usoro:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ọ bụrụ na ị nwere vector nke UTF-8 bytes, ị nwere ike ịmepụta `String` site na ya na usoro [`from_utf8`]:
///
/// ```
/// // ụfọdụ bytes, na a vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Anyị maara na bytes ndị a dị mma, yabụ anyị ga-eji `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// String`s na-adị irè UTF-8.Nke a nwere mmetụta ole na ole, nke mbụ bụ na ọ bụrụ na ịchọrọ eriri na-abụghị UTF-8, tụlee [`OsString`].O yiri nke a, ma enweghi nsogbu nke UTF-8.Ihe nke abuo bu na igaghi edebanye na `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Ebupụtara Indexing ka ọ bụrụ ọrụ oge niile, mana koodu UTF-8 anaghị enye anyị ohere ime nke a.Ọzọkwa, o doghị anya ụdị ihe ndepụta ahụ kwesịrị ịlaghachi: a byte, a codepoint, ma ọ bụ ụyọkọ grapheme.
/// Xzọ [`bytes`] na [`chars`] weghachitere ndị na-emegharị ihe na nke mbụ na nke abụọ.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Mejuputa String`s [`` Deref`] ''<Target=str>``, na wee ketara ụzọ niile '' (str`).Na mgbakwunye, nke a pụtara na ị nwere ike ịgafe `String` na ọrụ nke na-ewere [`&str`] site na iji ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Nke a ga-emepụta [`&str`] site na `String` ma nyefee ya. Ntugharị a dị ọnụ ala, yabụ n'ozuzu, ọrụ ga-anabata [`&str`] dị ka arụmụka belụsọ na ha chọrọ `String` maka ụfọdụ ihe kpatara ya.
///
/// N'ọnọdụ ụfọdụ Rust enweghị ozi zuru oke iji mee ntụgharị a, nke a maara dịka mmanye [`Deref`].Na atụ na-esonụ a eriri iberi [`&'a str`][`&str`] implements na trait `TraitExample`, na ndị ọrụ `example_func` ewe ihe ọ bụla na achụ nta ndị trait.
/// N'okwu a Rust ga-achọ ịme mgbanwe abụọ pụtara ìhè, nke Rust enweghị ụzọ ọ ga-esi mee.
/// N'ihi nke a, ihe atụ na-esonụ agaghị achịkọta.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Enwere nhọrọ abụọ ga-arụ ọrụ.Nke mbu bu igbanwe uzo `example_func(&example_string);` ka `example_func(example_string.as_str());`, jiri usoro [`as_str()`] weputa nkpuru ahihia nke nwere eriri.
/// Secondzọ nke abụọ gbanwere `example_func(&example_string);` na `example_func(&*example_string);`.
/// Na nke a, anyị na-edegharị `String` na [`str`][`&str`], wee dezie [`str`][`&str`] na [`&str`].
/// Thezọ nke abụọ bụ nzuzu, agbanyeghị ha abụọ na-arụ ọrụ iji gbanwee ntụgharị ahụ n'ụzọ doro anya kama ịdabere na ntụgharị ntụgharị ahụ.
///
/// # Representation
///
/// Ejiri ihe atọ mejuputara `String`: ihe na-egosi ihe ụfọdụ, ogologo, na ike.Ntuziaka na-arụtụ aka na nchekwa `String` dị n'ime ya iji chekwaa data ya.Ogologo bụ ọnụọgụ nke bytes dị ugbu a na nchekwa, na ikike bụ nha nchekwa nke bytes.
///
/// Dịka, ogologo ga-adịkarị ala ma ọ bụ hara nha.
///
/// A na-echekwa ebe a mgbe niile.
///
/// Nwere ike ilelee ihe ndị a na usoro [`as_ptr`], [`len`], na [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Melite nke a mgbe akwadoro vec_into_raw_parts.
/// // Gbochie itinye data String na-akpaghị aka
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // akụkọ nwere iri na itoolu bytes
/// assert_eq!(19, len);
///
/// // Anyị nwere ike iwughachi eriri na ptr, ntinye, na ikike.
/// // Ihe a niile adịghị mma n'ihi na anyị bụ ọrụ maka ijide n'aka na ihe ndị ahụ bara uru:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ọ bụrụ na `String` nwere ikike zuru ezu, ịtinye ihe na ya agaghị ekenye ọzọ.Iji maa atụ, tụlee mmemme a:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Nke a ga-ewepụta ihe ndị a:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Na mbụ, anyị na-enweghị ebe nchekwa ekenyela mgbe nile, ma dị ka anyị na-gbakwunyere eriri, ọ enwekwu ya ike n'ụzọ kwesịrị ekwesị.Ọ bụrụ na anyị ejiri usoro [`with_capacity`] wepụta ikike ziri ezi na mbido:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Anyị na-ejedebe na mmepụta dị iche:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// N'ebe a, ọ dịghị mkpa ịtọkwuo ebe nchekwa n'ime akaghị.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Njehie enwere ike ị nweta mgbe ị gbanwere `String` site na UTF-8 byte vector.
///
/// Dị a bụ ụdị njehie maka usoro [`from_utf8`] na [`String`].
/// Ezubere ya n'ụzọ dị otú a iji jiri nlezianya zere reallocations: usoro [`into_bytes`] ga-enyeghachi baiti vector nke ejiri ya na nnwale ntụgharị.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Xdị [`Utf8Error`] nke [`std::str`] nyere na-anọchi anya mmejọ nke nwere ike ime mgbe ị na-atụgharị iberi nke [`u8`] s ka [`&str`].
/// N'echiche a, ọ bụ ihe analogia na `FromUtf8Error`, ịnwere ike ịnweta otu site na `FromUtf8Error` site na usoro [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// // ụfọdụ abaghị uru, na vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Njehie enwere ike ị nweta mgbe ị na-agbanwe `String` site na iberi UTF-16 byte.
///
/// Dị a bụ ụdị njehie maka usoro [`from_utf16`] na [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Mepụta `String` efu ọhụrụ.
    ///
    /// Nyere na `String` bụ ihe efu, nke a agaghị ekenye akpa nchekwa ọ bụla.Ọ bụ ezie na nke ahụ pụtara na ọrụ mbụ a adịghị ọnụ, ọ nwere ike ibute oke oke mgbe emechara data.
    ///
    /// Ọ bụrụ na ị nwere echiche banyere data ole `String` ga-ejide, tụlee usoro [`with_capacity`] iji gbochie ịkefe oke.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Emeputa `String` ohuru ohuru nwere ikike.
    ///
    /// String`s nwere esịtidem echekwa jide ha data.
    /// Ikike bụ ogologo nke nchekwa ahụ, a ga-ajụkwa ya na usoro [`capacity`].
    /// Usoro a na-emepụta `String` efu, mana nke nwere nchekwa mbụ nwere ike ijide `capacity` bytes.
    /// Nke a bara uru mgbe ị nwere ike itinye ụyọkọ data na `String`, na-ebelata ọnụ ọgụgụ reallocations ọ kwesịrị ime.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ọ bụrụ na ikike enyere bụ `0`, enweghị oke ga-eme, usoro a na usoro [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Eriri enweghị chars, n'agbanyeghị na ọ nwere ike karịa
    /// assert_eq!(s.len(), 0);
    ///
    /// // Emere ha niile n`enweghi ebe ozo ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... mana nke a nwere ike ime ka eriri ahụ nwee ezigbo ọnọdụ
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): na cfg(test) usoro `[T]::to_vec` pụta ụwa, nke achọrọ maka nkọwapụta usoro a, adịghị.
    // Ebe ọ bụ na anyị achọghị usoro a maka ebumnuche nyocha, aga m agbachi ya NB lee usoro slice::hack na slice.rs maka ozi ndị ọzọ
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Tugharia vector nke bytes rue `String`.
    ///
    /// Eriri ([`String`]) bụ bytes ([`u8`]) bụ nke ([`String`]), yana vector nke bytes ([`Vec<u8>`]) bụ nke bytes, yabụ na ọrụ a na-agbanwe n'etiti ha abụọ.
    /// Ọbụghị mpekere byte niile bụ ezigbo ``String`s, agbanyeghị: `String` chọrọ ka ọ dị irè UTF-8.
    /// `from_utf8()` nlele iji hụ na bytes dị adị UTF-8, wee gbanwee ya.
    ///
    /// Ọ bụrụ na ị kwenyesiri ike na byte iberi ahụ dị UTF-8, na ịchọghị ibute ebe nyocha nke ndaba ahụ, enwere ụdị ọrụ a na-adịghị echekwa echekwa, [`from_utf8_unchecked`], nke nwere otu omume mana ọ na-eleghara nlele ahụ.
    ///
    ///
    /// Usoro a ga-elezi anya ka ị ghara idetu vector ahụ, maka arụmọrụ.
    ///
    /// Ọ bụrụ na ịchọrọ [`&str`] kama `String`, tụlee [`str::from_utf8`].
    ///
    /// Ntughari nke usoro a bu [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Laghachi [`Err`] ma ọ bụrụ na iberi bụghị UTF-8 na a nkọwa mere na-enye bytes abụghị UTF-8.A na-esonyekwa vector ị banyere na ya.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // ụfọdụ bytes, na a vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Anyị maara na bytes ndị a dị mma, yabụ anyị ga-eji `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Ezigbo bytes:
    ///
    /// ```
    /// // ụfọdụ abaghị uru, na vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Hụ docs maka [`FromUtf8Error`] maka nkọwa ndị ọzọ gbasara ihe ị nwere ike ime na njehie a.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Atughari iberi nke bytes ka udiri eriri, tinyere odide adighi nma.
    ///
    /// Ejiri eriri ([`u8`]) mee eriri, na iberibe nke bytes ([`&[u8]`][byteslice]) bụ nke bytes, ya mere, ọrụ a na-agbanwe n'etiti ha abụọ.Ọ bụghị mkpụrụ osisi byte niile bụ eriri dị mma, agbanyeghị: achọrọ eriri iji bụrụ UTF-8 ziri ezi.
    /// N'oge ntụgharị a, `from_utf8_lossy()` ga-eji [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] dochie usoro UTF-8 na-enweghị isi, nke dị ka nke a:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ọ bụrụ na ị kwenyesiri ike na byte iberi bụ UTF-8 dị mma, ma ị chọghị ibute ntụgharị nke ntụgharị ahụ, enwere ụdị ọrụ a na-adịghị ize ndụ, [`from_utf8_unchecked`], nke nwere otu omume ahụ mana ọ na-eleghara ndenye ego anya.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ọrụ a laghachiri [`Cow<'a, str>`].Ọ bụrụ na mpempe akwụkwọ mbugharị anyị bụ UTF-8 abaghị uru, mgbe ahụ anyị kwesịrị itinye mkpụrụedemede nnọchi, nke ga-agbanwe nha eriri ahụ, yabụ chọrọ `String`.
    /// Mana ọ bụrụ na ọ dịlarị UTF-8, anyị achọghị oke ọhụrụ.
    /// Returndị nloghachi a na-enye anyị ohere ịnagide ikpe abụọ ahụ.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // ụfọdụ bytes, na a vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Ezigbo bytes:
    ///
    /// ```
    /// // ụfọdụ abaghị uru bytes
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Ntughari vector `v` nke UTF-16 gbanwere n`ime `String`, weghachite [`Err`] ma ọ bụrụ na `v` nwere data na-enweghị isi.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Emeghi nke a site na ịnakọta: : <Result<_, _>> () maka arụmọrụ.
        // FIXME: enwere ike ime ka oru di nfe ozo mgbe emechiri #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Ntughari uzo `v` UTF-16 enwetara n`ime `String`, jiri [the replacement character (`U+FFFD`)][U+FFFD] dochie data adighi nma.
    ///
    /// N'adịghị ka [`from_utf8_lossy`] nke laghachiri [`Cow<'a, str>`], `from_utf16_lossy` laghachiri `String` ebe ọ bụ na ntụgharị UTF-16 na UTF-8 chọrọ oke nchekwa.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Decomposes a `String` n'ime ya raw mmiri.
    ///
    /// Weghachite pointer raw na ihe kpatara data, ogologo nke eriri (na bytes), na ikike ekenyela nke data (na bytes).
    /// Ndị a bụ otu arụmụka n'otu usoro okwu esemokwu dị na [`from_raw_parts`].
    ///
    /// Mgbe ọ kpọchara ọrụ a, onye na-akpọ oku bụ ọrụ maka ebe nchekwa nke `String` jibu.
    /// Nanị ụzọ ị ga-esi mee nke a bụ ịtụgharị pointer raw, ogologo, na ikike laghachi na `String` site na ọrụ [`from_raw_parts`], na-ekwe ka onye mbibi ahụ mee mkpocha.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Mepụta `String` ọhụrụ site na ogologo, ike, na pointer.
    ///
    /// # Safety
    ///
    /// Nke a enweghị oke nchekwa, n'ihi ọnụọgụ ndị na-anaghị agbanwe agbanwe anaghị enyocha:
    ///
    /// * Ebe nchekwa dị na `buf` kwesiri ka ebunye ya ụzọ site n'aka otu onye na-ekenye ọbá akwụkwọ ọkọlọtọ na-eji, yana nhazi nke chọrọ 1.
    /// * `length` kwesịrị ịdị obere ma ọ bụ hara ka `capacity`.
    /// * `capacity` kwesịrị ịbụ ezigbo ọnụ ahịa.
    /// * Xdị `length` izizi na `buf` kwesịrị ịdị irè UTF-8.
    ///
    /// Imebi ihe ndị a nwere ike ịkpata nsogbu dị ka imebi usoro nkewapụta ihe nkewapụta ngwa ngwa nke onye na-ekenye ego
    ///
    /// A na-ebufe ikike nke `buf` na `String` nke nwere ike ịmegharị, kesaa ma ọ bụ gbanwee ọdịnaya nke ebe nchekwa nke aka na-atụ aka na akara aka.
    /// Gbaa mbọ hụ na ọ dịghị ihe ọzọ na-eji pointer mgbe akpọchara ọrụ a.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Melite nke a mgbe akwadoro vec_into_raw_parts.
    ///     // Gbochie itinye data String na-akpaghị aka
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Na-agbanwe vector nke bytes na `String` na-enweghị ịlele na eriri nwere UTF-8 dị mma.
    ///
    /// Hụ ụdị nchekwa, [`from_utf8`], maka nkọwa ndị ọzọ.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchedo n'ihi na ọ naghị achọpụta na bytes gafere ya bụ ezigbo UTF-8.
    /// Ọ bụrụ na emebi iwu a, ọ nwere ike ibute nsogbu enweghị ncheta na ndị ọrụ future nke `String`, ebe ọ bụ na ụlọ akwụkwọ ndị ọzọ dị na ọkọlọtọ na-eche na 'String`s dị mma UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // ụfọdụ bytes, na a vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Atọgharị `String` ka a byte vector.
    ///
    /// Nke a na-erepịa `String`, yabụ na anyị ekwesighi idetu ọdịnaya ya.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Na-ewepụta eriri iberibe nwere `String` niile.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Atọghata a `String` n'ime a mutable eriri iberi.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Gbakwunye eriri ederede enyere na njedebe nke `String` a.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Laghachi ikike a 'String`, na bytes.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Gbaa mbọ hụ na ikike nke String a nwere opekata mpe `additional` bytes karịa ogologo ya.
    ///
    /// Enwere ike ịbawanye ikike karịa `additional` bytes ma ọ bụrụ na ọ họrọ, iji gbochie mmegharị oge.
    ///
    ///
    /// Ọ bụrụ na ịchọghị omume "at least" a, lee usoro [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ikike ohuru ejuputa [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Nke a nwere ike ọ gaghị eme ka ikike ahụ dịkwuo elu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ugbu a nwere ogologo nke 2 na ikike nke 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ebe ọ bụ na anyị nwere ikike 8 ọzọ, na-akpọ nke a ...
    /// s.reserve(8);
    ///
    /// // ... adịghị abawanye n'ezie.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Gbaa mbọ hụ na ikike nke `` String '' a bụ `additional` bytes karịa ogologo ya.
    ///
    /// Tụlee iji usoro [`reserve`] belụsọ ma ị matara nke ọma karịa onye nyefere ya ọrụ.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ikike ohuru ejuputa `usize`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Nke a nwere ike ọ gaghị eme ka ikike ahụ dịkwuo elu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ugbu a nwere ogologo nke 2 na ikike nke 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ebe ọ bụ na anyị nwere ikike 8 ọzọ, na-akpọ nke a ...
    /// s.reserve_exact(8);
    ///
    /// // ... adịghị abawanye n'ezie.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Gbalịa ịchekwa ikike maka opekata mpe `additional` ihe ndị ọzọ ka etinyere na `String` enyere.
    /// Nchịkọta ahụ nwere ike idowe ohere dị ukwuu iji zere ịmegharị ọtụtụ oge.
    /// Mgbe akpọchara `reserve`, ikike ga-adị ukwuu karịa ma ọ bụ hara nhata `self.len() + additional`.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// # Errors
    ///
    /// Ọ bụrụ na ikike tojubiga, ma ọ bụ onye na-ekenye ihe na-akọ ọdịda, mgbe ahụ eweghachitere njehie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Debe ebe nchekwa ahụ, na-apụ ma ọ bụrụ na anyị enweghị ike
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ugbu a anyị maara na nke a enweghị ike OOM n`etiti ọrụ dị mgbagwoju anya anyị
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Gbalịa idowe ikike opekempe maka kpọmkwem ihe `additional` a ga-etinye na ihe `String` enyere.
    ///
    /// Mgbe akpọchara `reserve_exact`, ikike ga-adị ukwuu karịa ma ọ bụ hara nhata `self.len() + additional`.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// Rịba ama na onye na-ekenye ya nwere ike inye nchịkọta ahụ ohere karịa ka ọ chọrọ.
    /// Ya mere, ikike-apụghị ịdabere na-abụ kpomkwem ntakiri.
    /// Na-ahọrọ `reserve` ma ọ bụrụ na a na-atụ anya ntinye ntinye future.
    ///
    /// # Errors
    ///
    /// Ọ bụrụ na ikike tojubiga, ma ọ bụ onye na-ekenye ihe na-akọ ọdịda, mgbe ahụ eweghachitere njehie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Debe ebe nchekwa ahụ, na-apụ ma ọ bụrụ na anyị enweghị ike
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ugbu a anyị maara na nke a enweghị ike OOM n`etiti ọrụ dị mgbagwoju anya anyị
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Ibelata ikike nke `String` a iji kwekọọ n'ogologo ya.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Ibelata ikike nke `String` a na obere ala.
    ///
    /// Ikike ahụ ga-adịgide ma ọ dịkarịa ala ka o buru ibu dị ka ogologo ma ogologo.
    ///
    ///
    /// Ọ bụrụ na ikike dị ugbu a dị obere karịa oke ala, nke a bụ enweghị op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Gbakwunye [`char`] nyere na njedebe nke `String` a.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Weghachite otu baiti nke ọdịnaya a.
    ///
    /// Ntughari nke usoro a bu [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Shortens a `String` ka kpọmkwem ogologo.
    ///
    /// Ọ bụrụ na `new_len` karịrị ogologo ugbu a eriri, nke a enweghị mmetụta.
    ///
    ///
    /// Rịba ama na usoro a enweghị mmetụta na ikike ekenyeworo nke eriri
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `new_len` anaghị agha na oke [`char`].
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Ewepu agwa ikpeazu na eriri nchekwa ma weghachite ya.
    ///
    /// Laghachi [`None`] ma ọ bụrụ na `String` a dị efu.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Wepu [`char`] na `String` a na ọnọdụ byte wee weghachi ya.
    ///
    /// Nke a bụ ọrụ *O*(*n*), ebe ọ na-achọ i copomi ihe niile dị na nchekwa.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `idx` ka ibu ma ọ bụ hà nhata ogologo 'String`, ma ọ bụ ọ bụrụ na ọ dinaghị na oke [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Wepu egwuregwu niile nke ụkpụrụ `pat` na `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// A ga-achọpụta ma wepu egwuregwu na-arụ ọrụ, yabụ na ọnọdụ ebe usoro gafere, ọ bụ naanị ụkpụrụ izizi ka a ga-ewepụ:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SAFETY: mmalite na njedebe ga-adị na utf8 byte ókè kwa
        // ndị Ọchụchọ docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Na-ejigide naanị mkpụrụ edemede ndị akọwapụtara akọwapụtara.
    ///
    /// N'aka ozo, wepu ihe odide nile `c` dika `f(c)` laghachiri `false`.
    /// Usoro a na-arụ ọrụ n'ime ya, na-eleta agwa ọ bụla otu oge na usoro mbụ, ma na-echekwa usoro nke mkpụrụedemede ejidere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Usoro ziri ezi nwere ike ịba uru maka ịchekwa ọnọdụ mpụga, dịka ndeksi.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Detuo idx na char na-esote
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Fanye agwa n`ime `String` a na ọnọdụ byte.
    ///
    /// Nke a bụ ọrụ *O*(*n*) ka ọ na-achọ iyingomi ihe niile dị na nchekwa.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `idx` ka ogologo karịa ogologo 'String`, ma ọ bụ ọ bụrụ na ọ dinaghị na oke [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Fanye eriri iberi n'ime `String` a na ọnọdụ byte.
    ///
    /// Nke a bụ ọrụ *O*(*n*) ka ọ na-achọ iyingomi ihe niile dị na nchekwa.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `idx` ka ogologo karịa ogologo 'String`, ma ọ bụ ọ bụrụ na ọ dinaghị na oke [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Weghachitere ihu ederede na ọdịnaya nke `String` a.
    ///
    /// # Safety
    ///
    /// Ọrụ a enweghị nchedo n'ihi na ọ naghị achọpụta na bytes gafere ya bụ ezigbo UTF-8.
    /// Ọ bụrụ na emebi iwu a, ọ nwere ike ibute nsogbu enweghị ncheta na ndị ọrụ future nke `String`, ebe ọ bụ na ụlọ akwụkwọ ndị ọzọ dị na ọkọlọtọ na-eche na 'String`s dị mma UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Laghachiri ogologo nke `String` a, na bytes, ọ bụghị [`` char '' ma ọ bụ graphemes.
    /// N'ikwu ya n'ụzọ ọzọ, ọ nwere ike ọ gaghị abụ ihe mmadụ tụlere ogologo eriri ahụ.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Laghachi `true` ma ọ bụrụ na `String` a nwere ogologo efu, na `false` ma ọ bụghị.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Na-agbaji eriri ahụ ụzọ abụọ na ndeksi byte nyere.
    ///
    /// Weghachite `String` ohuru.
    /// `self` nwere bytes `[0, at)`, na `String` laghachiri nwere bytes `[at, len)`.
    /// `at` aghaghi idi na oke uzo koodu UTF-8.
    ///
    /// Rịba ama na ikike nke `self` anaghị agbanwe agbanwe.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `at` adịghị na oke akara koodu `UTF-8`, maọbụ ọ bụrụ na ọ gafere akara koodu ikpeazụ nke eriri ahụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncates `String` a, wepu ọdịnaya niile.
    ///
    /// Ọ bụ ezie na nke a pụtara na `String` ga-enwe ogologo efu, ọ naghị emetụ ikike ya.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Na-emepụta onye na-agba mmiri na-ewepu ihe akọwapụtara na `String` ma na-amịpụta `chars` wepụrụ.
    ///
    ///
    /// Note: A na-ewepụ ihe mmewere ọbụlagodi ma ọ bụrụ na anaghị egbu iterator ruo mgbe ọgwụgwụ.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na mmalite ma ọ bụ isi njedebe anaghị agha na oke [`char`], maọbụ ọ bụrụ na ha gafere oke.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Wepu ihe di elu rue β site na eriri
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ihe zuru oke na-ekpochapụ eriri ahụ
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Nchekwa ebe nchekwa
        //
        // Versiondị String nke Drain enweghị nsogbu nchekwa nchekwa nke ụdị vector.
        // Ihe data ahu bu ihe doro anya.
        // N'ihi na nso mwepụ na-eme na dobe, ma ọ bụrụ na Drain iterator na-leaked, iwepụ agaghị eme.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Wepụta mgbazinye ego abụọ.
        // Agaghị enweta &mut String ruo mgbe iteration gafere, na Drop.
        let self_ptr = self as *mut _;
        // NCHEKWA: `slice::range` na `is_char_boundary` ime ihe kwesịrị ekwesị ókè akwụkwọ ndenye ego.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Na-ewepu usoro akọwapụtara na eriri, ma dochie ya na eriri enyere.
    /// E nyere eriri ekwesighi ka ọ dị ka ogologo ahụ.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na mmalite ma ọ bụ isi njedebe anaghị agha na oke [`char`], maọbụ ọ bụrụ na ha gafere oke.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Dochie nso ruo β si eriri
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Nchekwa ebe nchekwa
        //
        // Replace_range enweghị nsogbu nchekwa nchekwa nke vector Splice.
        // nke mbipute vector.Ihe data ahu bu ihe doro anya.

        // WARDỌ AKA NA NT: : liningdepụta mgbanwe a ga-abụ (#81138) adịghị mma
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // WARDỌ AKA NA NT: : liningdepụta mgbanwe a ga-abụ (#81138) adịghị mma
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Iji `range` mee ihe ọzọ ga-abụ ihe (#81138) na-enweghị nsogbu Anyị chere na oke nke `range` kọọrọ ka bụ otu, mana mmejuputa mmegide nwere ike gbanwee n'etiti oku
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Atọgharị `String` a n'ime [``Box`] '' <`[` str`]`>>.
    ///
    /// Nke a ga-dobe ọ bụla ngafe ikike.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Weghachite iberi nke [`u8`] s nke anwa ịtụgharị na `String`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // ụfọdụ abaghị uru, na vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Laghachi oke na ọnwụnwa a nwara iji tọghata `String`.
    ///
    /// Ejiri nlezianya rụọ usoro a iji zere oke.
    /// Ọ ga-eri njehie ahụ, na-ebupụ ọfụfụ, nke mere na otu okike adịghị mkpa ịme.
    ///
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // ụfọdụ abaghị uru, na vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Weta a `Utf8Error` iji nweta nkọwa ndị ọzọ gbasara ntụgharị ntụgharị.
    ///
    /// Xdị [`Utf8Error`] nke [`std::str`] nyere na-anọchi anya mmejọ nke nwere ike ime mgbe ị na-atụgharị iberi nke [`u8`] s ka [`&str`].
    /// N'echiche a, ọ bụ ihe analogue maka `FromUtf8Error`.
    /// Hụ akwụkwọ ya maka nkọwa ndị ọzọ gbasara iji ya.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// // ụfọdụ abaghị uru, na vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // akpa byte abaghị uru ebe a
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // N'ihi na anyị na-emegharị n'elu 'String`s, anyị nwere ike izere ọ dịkarịa ala otu oke site na-akpa eriri si iterator na itinye ya niile ụdi ndido urụk.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // N'ihi na anyị na-agagharị na CoWs, anyị nwere ike (potentially) zere opekata mpe otu oke site n'inweta ihe mbụ ma tinye ya ihe niile sochirinụ.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Ihe dị mma nke na-egosi na a na-etinye aka maka `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Mepụta `String` efu.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Na-eme onye ọrụ `+` maka ijikọ ụdọ abụọ.
///
/// Nke a na-erepịa `String` n'akụkụ aka ekpe wee jiri ya mee ihe (na-eto ya ma ọ bụrụ na ọ dị mkpa).
/// Emere nke a iji zere ịwepụta `String` ọhụrụ na ịdegharị ọdịnaya niile na arụmọrụ ọ bụla, nke ga-eduga na *O*(*n*^ 2) oge na-agba ọsọ mgbe ị na-ewu eriri *n*-byte site na ịmekọrịta ugboro ugboro.
///
///
/// A na-agbaziri eriri dị n'akụkụ aka nri;depụtaghachiri ọdịnaya ya n'ime `String` laghachiri.
///
/// # Examples
///
/// Concatenating abụọ ``String`s na-ewe nke mbụ site na uru ma binye nke abụọ:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` kpaliri ma enwekwaghị ike iji ya ebe a.
/// ```
///
/// Ọ bụrụ n'ịchọrọ ịnọgide na-eji `String` mbụ, ịnwere ike iyiri ya ma tinye ya na mmepụta oyiri kama:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ka dị irè ebe a.
/// ```
///
/// Enwere ike ịmekọrịta Mpekere `&str` site na ịtụgharị nke mbụ na `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Na-eme onye ọrụ `+=` maka itinye aka na `String`.
///
/// Nke a nwere otu omume dị ka ndị [`push_str`][String::push_str] usoro.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Typedị aha maka [`Infallible`].
///
/// Nkọwa aha a dị maka ndakọrịta azụ, wee nwee ike mebie.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait maka ịtụgharị uru na `String`.
///
/// trait a na-etinye aka na akpaghị aka maka ụdị ọ bụla nke na-etinye [`Display`] trait n'ọrụ.
/// Dika odi, ekwesighi itinye `ToString` ozugbo:
/// [`Display`] ekwesịrị itinye n'ọrụ kama, ị ga-enweta `ToString` mmejuputa n'efu.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Gbanwee uru enyere na `String`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Na mmejuputa a, usoro `to_string` panics ma oburu na ihe `Display` weghachitere njehie.
/// Nke a na-egosi na mmezigharị `Display` ezighi ezi ebe ọ bụ na `fmt::Write for String` anaghị alaghachi njehie n'onwe ya.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Commonkpụrụ nduzi a na-ahụkarị abụghị ime ka ọrụ ndị a pụta ìhè.
    // Agbanyeghị, iwepu `#[inline]` na usoro a na-ebute regressions na-enweghị isi.
    // Hụ <https://github.com/rust-lang/rust/pull/74852>, nnwale ikpeazụ iji gbalịa wepu ya.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Gbanwee `&mut str` ka ọ bụrụ `String`.
    ///
    /// E kewapụtara ihe na kpokọtara.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ule akwusila na libstd, nke na-akpata njehie ebe a
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Gbanwee mpempe akwụkwọ `str` igbe nyere na `String`.
    /// Ọ bụ ihe ama ama na enwere ihe `str`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Na-atụgharị `String` nyere na mpempe `str` igbe nwere ya.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Na-atụgharị eriri iberi n'ime ụdị agbagha.
    /// Enweghị oke oke a na-eme, na eriri adịghị depụtaghachi.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Gbanwee eriri n'ime ihe dị iche.
    /// Enweghị oke oke a na-eme, na eriri adịghị depụtaghachi.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Na-agbanwe ntụgharị eriri n'ime ụdị agbagha.
    /// Enweghị oke oke a na-eme, na eriri adịghị depụtaghachi.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Gbanwee `String` nyere ka ọ bụrụ vector `Vec` nke na-ejide ụkpụrụ nke ụdị `u8`.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Onye na-agba mmiri maka `String`.
///
/// Emebere usoro a site na usoro [`drain`] na [`String`].
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Ga-eji dị ka&'a mut Eriri na mbibi
    string: *mut String,
    /// Mmalite nke akụkụ wepụ
    start: usize,
    /// Ọgwụgwụ nke akụkụ wepụ
    end: usize,
    /// Ugbu a fọdụrụ iche iji wepu
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Jiri Vec::drain.
            // "Reaffirm" ókè na-achọpụtazi iji zere koodu panic ka etinyere ya ọzọ.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Weghachite eriri fọdụrụ (sub) nke ite ite a.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: Enweghị nchekasị AsRef na-etinye n'okpuru mgbe ị na-edozi.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Obi erughị ala mgbe ị na-eme ka `string_drain_as_str` kwụsie ike.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>maka Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> maka Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}