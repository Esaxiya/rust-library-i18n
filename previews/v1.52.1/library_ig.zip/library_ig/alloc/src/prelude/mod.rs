//! The ekenye Prelude
//!
//! Ebumnuche nke usoro a bụ iji belata mbubata nke ihe ndị a na-ejikarị nke `alloc` crate site na ịgbakwunye mbubata ụwa n'elu nke modulu ahụ:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;