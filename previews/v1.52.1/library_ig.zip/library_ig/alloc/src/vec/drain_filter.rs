use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// An iterator nke na-eji a mmechi iji chọpụta ma ọ bụrụ na ihe mmewere ga-ewepụ.
///
/// Nke a tọrọ ntọala site [`Vec::drain_filter`].
/// Lee akwukwo ya maka ihe ndi ozo.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Ndenye nke ihe a ga-enyocha site na oku na-esote na `next`.
    pub(super) idx: usize,
    /// The ọnụ ọgụgụ nke ihe ndị na e drained (removed) ka ọ dị ugbu.
    pub(super) del: usize,
    /// Ogologo mbu nke `vec` tupu igbapu.
    pub(super) old_len: usize,
    /// Ihe nlele nyocha ahụ.
    pub(super) pred: F,
    /// Ọkọlọtọ nke na-egosi panic emeela na nyocha nyocha nyocha.
    /// A na-eji nke a dị ka ihe ngosi na ntinye dobe iji gbochie oriri nke ihe fọdụrụ na `DrainFilter`.
    /// Ihe ọ bụla anaghị edozi ya ga-agbanwegharị na `vec`, mana ọ nweghị ihe ọzọ ga-adaba ma ọ bụ nwalee site na nhazi nyocha.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Alaghachi a na-ezo aka n'okpuru allocator.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Melite ndeksi *mgbe* a na-akpọ akara aha.
                // Ọ bụrụ na ndọtị na-emelite tupu na prefectate panics, mmewere na a index ga-leaked.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Nke a bụ ezigbo ọchịchị ọgbaghara, ọ nweghịkwa ezigbo ihe ime.
                        // Anyị achọghị ịnọgide na-anwa igbu `pred`, yabụ anyị na-eweghachi ihe niile anaghị arụ ọrụ ma gwa ndị vec na ha ka dị.
                        //
                        // Achọrọ azụ azụ iji gbochie okpukpu abụọ nke ihe ikpeazụ mechara kpochapụ nke ọma tupu panic na amụma ahụ.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Attgbalị iri ihe ọ bụla fọdụrụnụ ma ọ bụrụ na ihe nzacha ahụ amabeghị jijiji.
        // Anyị ga-agbanwe ihe ọ bụla fọdụrụnụ ma anyị atụla ụjọ ma ọ bụrụ na oriri ebe a bụ panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}