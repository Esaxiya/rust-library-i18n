use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Ihe iche iche trait maka Vec::from_iter dị mkpa iji aka gị dozie ihe ndị ọkachamara na-atụghị anya na-ahụ [`SpecFromIter`](super::SpecFromIter) maka nkọwa.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Wepu mmiri nke mbụ, dị ka vector ga-agbasawanye na ite a n'okwu ọ bụla mgbe ịpụpụghị efu, mana akaghị na extend_desugared() agaghị ahụ vector ka ọ jupụta na obere ite loop ite.
        //
        // Ya mere, anyị na-mma branch amụma.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // ga-ekenye spec_extend() ebe ọ bụ na extend() n'onwe ya na-anọchite anya spec_from maka Vecs efu
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // ga-ekenye spec_extend() ebe ọ bụ na extend() n'onwe ya na-anọchite anya spec_from maka Vecs efu
        //
        vector.spec_extend(iterator);
        vector
    }
}