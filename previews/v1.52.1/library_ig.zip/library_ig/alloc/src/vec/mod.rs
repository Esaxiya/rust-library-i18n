//! Typedị ụdị ahịhịa na-eto eto nke nwere ihe ọkụkọ, edepụtara `Vec<T>`.
//!
//! Vectors nwere ntinye `O(1)`, amortized `O(1)` push (na njedebe) na `O(1)` pop (site na njedebe).
//!
//!
//! Vectors hụ na ha anaghị ekenye karịa `isize::MAX` bytes.
//!
//! # Examples
//!
//! Nwere ike ịmepụta [`Vec`] n'ụzọ doro anya na [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ma ọ bụ site na iji [`vec!`] nnukwu:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // iri iri
//! ```
//!
//! Nwere ike [`push`] ụkpụrụ na njedebe nke vector (nke ga-eto vector dị ka achọrọ):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Kpụrụ popping na-arụ ọrụ n'otu ụzọ ahụ:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors na-akwado ndenye aha (site na [`Index`] na [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Contdị ụdị agbasawanye agbasawanye, nke edere dị ka `Vec<T>` ma kpọọ 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// A na-enye igwe macro [`vec!`] iji mee ka mbido dịkwuo mfe:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// O nwekwara ike ibido ihe ọ bụla nke `Vec<T>` na uru enyere.
/// Nke a nwere ike ịrụ ọrụ karịa ịrụ oke na mbido na usoro dị iche iche, ọkachasị mgbe ị na-ebido vector nke efu:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ihe ndị a bụ otu, ma nwee nwayọ:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Maka ozi ndị ọzọ, lee [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Jiri `Vec<T>` dị ka nchịkọta dị mma:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Mbipụta 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Xdị `Vec` na-enye ohere ịnweta ụkpụrụ site na ndeksi, n'ihi na ọ na-etinye [`Index`] trait n'ọrụ.Otu ihe atụ ga-apụta ìhè karị:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ọ ga-egosipụta '2'
/// ```
///
/// Agbanyeghị, kpachara anya: ọ bụrụ na ịnwale ịnweta ndeksi na `Vec` adịghị, sọftụwia gị ga-panic!Ị nwere ike ime nke a:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Jiri [`get`] na [`get_mut`] ma ọ bụrụ na ịchọrọ ịlele ma ndeksi ahụ ọ dị na `Vec`.
///
/// # Slicing
///
/// A `Vec` nwere ike ịbụ mutable.N'aka nke ọzọ, mpekere bụ naanị ihe a na-agụ.
/// Iji nweta [slice][prim@slice], jiri [`&`].Ihe Nlereanya:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... na nke ahụ niile!
/// // ị nwekwara ike na-eme ya dị ka nke a:
/// let u: &[usize] = &v;
/// // ma ọ bụ dị ka nke a:
/// let u: &[_] = &v;
/// ```
///
/// Na Rust, ọ bụ ihe a na-ahụkarị ịhapụ mpekere dị ka arụmụka karịa vectors mgbe ịchọrọ ị nweta ohere ịgụ.Otu ihe ahụ na-aga [`String`] na [`&str`].
///
/// # Ike na reallocation
///
/// Ike nke vector bụ oke ohere etinyere maka ihe ọ bụla future a ga-atụkwasị na vector.Agaghị agbagha nke a na *ogologo* nke vector, nke na-akọwapụta ọnụ ọgụgụ nke ihe ndị mejupụtara n'ime vector.
/// Ọ bụrụ na ogologo vector karịrị ike ya, ikike ya ga-abawanye na-akpaghị aka, mana a ga-ewezigharị ihe ya.
///
/// Dịka ọmụmaatụ, vector nwere ikike 10 na ogologo 0 ga-abụ vector efu na ohere maka 10 ihe ndị ọzọ.Pushing 10 ma ọ bụ ole na ole ọcha n'elu vector agaghị agbanwe ya ike ma ọ bụ na-akpata reallocation ime.
/// Agbanyeghị, ọ bụrụ na ogologo vector ruo 11, ọ ga-etinyegharị ebe ọzọ, nke nwere ike ịdị nwayọ.N'ihi nke a, a na-atụ aro ka ị jiri [`Vec::with_capacity`] mgbe ọ bụla enwere ike ịkọwapụta etu vector buru ibu ga-esi nweta.
///
/// # Guarantees
///
/// N'ihi ọdịdị dị oke egwu, `Vec` na-eme ọtụtụ nkwa maka imewe ya.Nke a na-eme ka o doo anya na ọ dị ka isi ala dị ka o kwere mee n'ozuzu ya, enwere ike iji ya mee ihe n'ụzọ ziri ezi site na koodu nchekwa.Rịba ama na nkwa ndị a na-ezo aka na `Vec<T>` erughị eru.
/// Ọ bụrụ na ndị ọzọ ụdị parameters na-kwukwara (eg, na-akwado omenala allocators), overriding ha defaults nwere ike ịgbanwe omume.
///
/// `Vec` kachasị dị mkpa, na-abụkarị (pointer, ikike, ogologo) okpukpu atọ.Mba ọzọ, ọ dịghị ihe ọzọ.Achọpụtaghị usoro nke mpaghara ndị a kpamkpam, ị kwesịrị iji usoro kwesịrị ekwesị iji gbanwee ihe ndị a.
/// Ihe nkenke a na-agaghị enwe isi, ya mere ụdị a bụ ihe null-pointer-kachasị.
///
/// Agbanyeghị, pointer nwere ike ọ gaghị arụtụ aka na ebe nchekwa e kenyere.
/// Karịsịa, ọ bụrụ na ị wuo `Vec` nwere ikike 0 site na [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], ma ọ bụ site na ịkpọ [`shrink_to_fit`] na Vec efu, ọ gaghị ekenye ebe nchekwa.N'otu aka ahụ, ọ bụrụ na ị na-echekwa efu-sized ụdị n'ime a `Vec`, ọ ga-igbunye ohere maka ha.
/// *Rịba ama na na nke a `Vec` nwere ike ọ gaghị akọ [`capacity`] nke 0*.
/// `Vec` ga-ekenye ma ọ bụrụ na ọ bụrụ na [`mem: : size_of::<T>`` () * capacity()> 0`.
/// Na mkpokọta, nkọwa nkọwa nke Vec bụ nke aghụghọ-ọ bụrụ na ị bu n'obi itinye ebe nchekwa site na iji `Vec` ma jiri ya maka ihe ọzọ (ma ọ bụ ịgafe koodu na-adịghị ize ndụ, ma ọ bụ iji wuo nchịkọta nke nchekwa gị), jide n'aka iji kewaa ebe nchekwa a site na iji `from_raw_parts` iji weghachite `Vec` wee tinye ya.
///
/// Ọ bụrụ na `Vec` * ekenyela ebe nchekwa, mgbe ahụ ebe nchekwa ọ na-ezo aka bụ na kpokọtara (dị ka akọwapụtara site na nkenye Rust iji rụọ ọrụ na ndabara), na ntụpọ ya na-ezo aka na [`len`] bidoro, ihe dị iche iche ga-adị (ihe ị ga-achọ lee ma ị manyere ya na iberibe), sotere ya ``ikike ''``, '' (``len`] ezi uche adịghị na ya, ihe ndị na-adabara.
///
///
/// Enwere ike iji vector nwere ihe `'a'` na `'b'` nwere ikike 4 dị ka okpuru.Akụkụ dị elu bụ `Vec` struct, ọ nwere pointer na isi nke oke na ikpo, ogologo na ikike.
/// Akụkụ bụ oke na kpokọtara, ngọngọ ebe nchekwa dị
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **iwepu** na-anọchite anya ebe nchekwa na-abụghị nke amaliteghị, lee [`MaybeUninit`].
/// - Note: ABI anaghị akwụsi ike na `Vec` enweghị mmesi obi ike gbasara nhazi ebe nchekwa ya (gụnyere usoro nke ubi).
///
/// `Vec` agaghị eme "small optimization" ebe a na-echekwa ihe dị iche iche na nchịkọta maka ihe abụọ:
///
/// * Ọ ga-eme ka o sikwuoro koodu na-adịghị ize ndụ ike ịhazi `Vec` n'ụzọ ziri ezi.Ihe dị na `Vec` agaghị enwe adres nwere ike ọ bụrụ naanị ibugharịa ya, ọ ga-esikwa ike ịchọpụta ma `Vec` ekenyela ebe nchekwa.
///
/// * Ọ ga-ata ahụhụ ikpe ahụ niile, na-eweta branch ọzọ na ohere ọ bụla.
///
/// `Vec` agaghị akpachapụ ọnụ n`onwe ya, ọbụnadị na ọ tọgbọ chakoo.A ana achi achi dịghị enweghị isi allocations ma ọ bụ deallocations ime.Ibufu `Vec` wee dejupụta ya ruo na [`len`] ahụ ekwesịghị ịkpọbata onye na-ekenye ya oku.Ọ bụrụ n`ịchọrọ ịhapụ ebe nchekwa anaghị eji, jiri [`shrink_to_fit`] ma ọ bụ [`shrink_to`].
///
/// [`push`] na [`insert`] ga-(re) igbunye ma ọ bụrụ na ndị kọrọ ike bụ zuru ezu.[`push`] na [`insert`]*ga*(re) igbunye ma ọ bụrụ na ``len`] ''==``('' ikike`].Nke ahụ bụ, ikike a kọọrọ zuru oke, enwere ike ịdabere na ya.Enwere ike iji ya iji aka ya ịhapụ ebe nchekwa nke `Vec` kenyere ma ọ bụrụ na achọrọ.
/// Usoro ntinye ọtụtụ *nwere ike* ịhazigharị, ọbụlagodi mgbe ọ na-adịghị mkpa.
///
/// `Vec` anaghị ekwe nkwa usoro ọ bụla ga-eto eto ma ọ bụrụ na-ekenye ya mgbe ọ jupụtara, ma ọ bụ mgbe akpọrọ [`reserve`].Atụmatụ dị ugbu a bụ isi ma ọ nwere ike bụrụ ihe na-achọsi ike iji ihe na-eto eto na-adịghị agbanwe agbanwe.Usoro ọ bụla eji mee ihe ga-ekwe nkwa *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, na [`Vec::with_capacity(n)`][`Vec::with_capacity`], ha nile ga emeputa `Vec` nwere ikike a choro.
/// Ọ bụrụ na [``len`]]==`[` `ikike`]], (dị ka ọ dị maka [`vec!`] nnukwu), mgbe ahụ `Vec<T>` nwere ike ịtụgharị na site na [`Box<[T]>`][owned slice] na-enweghị ịhazigharị ma ọ bụ imegharị ihe ndị ahụ.
///
/// `Vec` agaghị edegharị data ọ bụla ewepụrụ na ya, mana ọ gaghị echekwa ya.Ya uninitialized ebe nchekwa bụ ọkọ ohere na ọ nwere ike iji ọ bụla ọ chọrọ.Ọ ga-n'ozuzu dị nnọọ eme ihe ọ bụla bụ ihe kasị oru oma ma ọ bụ n'ụzọ dị mfe iji mejuputa.Adaberela na wepu data ewepu ma kpochapụ ebumnuche nche.
/// Ọbụna ma ọ bụrụ na idobe `Vec`, enwere ike iji ya ọzọ `Vec` mee ihe echekwa ya.
/// Ọbụna ma ọ bụrụ na ị na-efu a 'Vec` ncheta mbụ, nke ahụ nwere ike agaghị eme n'ihi na optimizer anaghị atụle nke a a n'akụkụ-mmetụta na-aghaghị ichekwa.
/// Enwere otu ikpe nke anyị agaghị agbaji, agbanyeghị: iji koodu `unsafe` iji dee ike karịrị akarị, wee bulie ogologo iji kwekọọ, dị ire mgbe niile.
///
/// Ka ọ dị ugbu a, `Vec` anaghị ekwe nkwa usoro nke ihe atụrụ.
/// Iwu ahụ agbanweela n'oge gara aga ma nwee ike ịgbanwe ọzọ.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Zọ ebumpụta ụwa
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Na-ewuli `Vec<T>` ohuru, efu.
    ///
    /// vector agaghị ekenye ruo mgbe etinyere ihe na ya.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Na-ewuli `Vec<T>` ohuru, efu na ikike akọwapụtara.
    ///
    /// vector ga-enwe ike ijide ihe `capacity` n`ejighi iwegharị.
    /// Ọ bụrụ na `capacity` bụ 0, vector agaghị ekenye.
    ///
    /// Ọ dị mkpa iburu n'uche na ọ bụ ezie na vector laghachiri nwere *ikike* akọwapụtara, vector ga-enwe efu *ogologo*.
    ///
    /// Maka nkọwa nke ọdịiche dị n'etiti ogologo na ikike, lee *[Ike na ịhazigharị]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector enweghị ihe ọ bụla, n'agbanyeghị na o nwere ikike maka ndị ọzọ
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Emere ha niile n`enweghi ebe ozo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... mana nke a nwere ike ime ka vector bụrụ ezigbo ọnọdụ
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Emepụta a `Vec<T>` kpọmkwem site raw mmiri nke ọzọ vector.
    ///
    /// # Safety
    ///
    /// Nke a enweghị oke nchekwa, n'ihi ọnụọgụ ndị na-anaghị agbanwe agbanwe anaghị enyocha:
    ///
    /// * `ptr` mkpa na a na mbụ ekenyela via ['String`]/' Vec<T>`` (ọbụlagodi, ọ ga-abụ na ọ ga-ezighi ezi ma ọ bụrụ na ọ bụghị).
    /// * `T` kwesiri inwe oke nha anya na nkwekorita dika ihe enyere `ptr`.
    ///   (`T` ịnwe nkwekọrịta na-esighi ike ezughi ezu, nhazi ahụ kwesịrị ka nha anya iji mezuo [`dealloc`] chọrọ na a ga-ekenye ebe nchekwa ma kesaa ya na otu nhazi.)
    ///
    /// * `length` kwesịrị ịdị obere ma ọ bụ hara ka `capacity`.
    /// * `capacity` kwesiri ibu ikike nke enyere pointer ya.
    ///
    /// Imebi ihe ndị a nwere ike ịkpata nsogbu dị ka imebi usoro nkewapụta ihe nkewapụta ngwa ngwa nke onye na-ekenye ihe.Dịka ọmụmaatụ, ọ bụghị ** adịghị mma iji wuo `Vec<u8>` site na pointer na usoro C `char` na ogologo `size_t`.
    /// Ọ dịkwa mma iji wuo otu site na `Vec<u16>` na ogologo ya, n'ihi na onye na-ekenye ya na-eche banyere nhazi ahụ, ụdị abụọ a nwere usoro dị iche iche.
    /// E kenyere nchekwa ahụ na ntinye 2 (maka `u16`), mana mgbe ọ tụgharịrị ya na `Vec<u8>`, a ga-ekenye ya na ntinye 1.
    ///
    /// The nwe nke `ptr` n'ụzọ dị irè kpọfere `Vec<T>` nke nwere ike mgbe ahụ deallocate, reallocate ma ọ bụ ịgbanwe ọdịnaya nke ebe nchekwa kwuru site pointer na uche.
    /// Gbaa mbọ hụ na ọ dịghị ihe ọzọ na-eji pointer mgbe akpọchara ọrụ a.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Melite nke a mgbe akwadoro vec_into_raw_parts.
    ///     // Gbochie nbibi nke onye na-ebibi ya ka anyị wee nwee ike ịchịkwa oke.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Wepu ihe omuma di nkpa banyere `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Jiri 4, 5, 6 mechie ebe nchekwa
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Tinye ihe niile azụ n'ime Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Na-ewuli `Vec<T, A>` ohuru, efu.
    ///
    /// vector agaghị ekenye ruo mgbe etinyere ihe na ya.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Na-ewuli `Vec<T, A>` ohuru, efu na ikike a kapịrị ọnụ na onye na-ekenye ihe.
    ///
    /// vector ga-enwe ike ijide ihe `capacity` n`ejighi iwegharị.
    /// Ọ bụrụ na `capacity` bụ 0, vector agaghị ekenye.
    ///
    /// Ọ dị mkpa iburu n'uche na ọ bụ ezie na vector laghachiri nwere *ikike* akọwapụtara, vector ga-enwe efu *ogologo*.
    ///
    /// Maka nkọwa nke ọdịiche dị n'etiti ogologo na ikike, lee *[Ike na ịhazigharị]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector enweghị ihe ọ bụla, n'agbanyeghị na o nwere ikike maka ndị ọzọ
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Emere ha niile n`enweghi ebe ozo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... mana nke a nwere ike ime ka vector bụrụ ezigbo ọnọdụ
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Emepụta a `Vec<T, A>` kpọmkwem site raw mmiri nke ọzọ vector.
    ///
    /// # Safety
    ///
    /// Nke a enweghị oke nchekwa, n'ihi ọnụọgụ ndị na-anaghị agbanwe agbanwe anaghị enyocha:
    ///
    /// * `ptr` mkpa na a na mbụ ekenyela via ['String`]/' Vec<T>`` (ọbụlagodi, ọ ga-abụ na ọ ga-ezighi ezi ma ọ bụrụ na ọ bụghị).
    /// * `T` kwesiri inwe oke nha anya na nkwekorita dika ihe enyere `ptr`.
    ///   (`T` ịnwe nkwekọrịta na-esighi ike ezughi ezu, nhazi ahụ kwesịrị ka nha anya iji mezuo [`dealloc`] chọrọ na a ga-ekenye ebe nchekwa ma kesaa ya na otu nhazi.)
    ///
    /// * `length` kwesịrị ịdị obere ma ọ bụ hara ka `capacity`.
    /// * `capacity` kwesiri ibu ikike nke enyere pointer ya.
    ///
    /// Imebi ihe ndị a nwere ike ịkpata nsogbu dị ka imebi usoro nkewapụta ihe nkewapụta ngwa ngwa nke onye na-ekenye ihe.Dịka ọmụmaatụ, ọ bụghị ** adịghị mma iji wuo `Vec<u8>` site na pointer na usoro C `char` na ogologo `size_t`.
    /// Ọ dịkwa mma iji wuo otu site na `Vec<u16>` na ogologo ya, n'ihi na onye na-ekenye ya na-eche banyere nhazi ahụ, ụdị abụọ a nwere usoro dị iche iche.
    /// E kenyere nchekwa ahụ na ntinye 2 (maka `u16`), mana mgbe ọ tụgharịrị ya na `Vec<u8>`, a ga-ekenye ya na ntinye 1.
    ///
    /// The nwe nke `ptr` n'ụzọ dị irè kpọfere `Vec<T>` nke nwere ike mgbe ahụ deallocate, reallocate ma ọ bụ ịgbanwe ọdịnaya nke ebe nchekwa kwuru site pointer na uche.
    /// Gbaa mbọ hụ na ọ dịghị ihe ọzọ na-eji pointer mgbe akpọchara ọrụ a.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Melite nke a mgbe akwadoro vec_into_raw_parts.
    ///     // Gbochie nbibi nke onye na-ebibi ya ka anyị wee nwee ike ịchịkwa oke.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Wepu ihe omuma di nkpa banyere `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Jiri 4, 5, 6 mechie ebe nchekwa
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Tinye ihe niile azụ n'ime Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Decomposes a `Vec<T>` n'ime ya raw mmiri.
    ///
    /// Weghachite pointer raw na ihe kpatara data, ogologo nke vector (na ihe ndị ọzọ), na ikike ekenyela nke data (na ihe).
    /// Ndị a bụ otu arụmụka n'otu usoro okwu esemokwu dị na [`from_raw_parts`].
    ///
    /// Mgbe ọ kpọchara ọrụ a, onye na-akpọ oku bụ ọrụ maka ebe nchekwa nke `Vec` jibu.
    /// Nanị ụzọ ị ga-esi mee nke a bụ ịtụgharị pointer raw, ogologo, na ikike laghachi na `Vec` site na ọrụ [`from_raw_parts`], na-ekwe ka onye mbibi ahụ mee mkpocha.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Anyị nwere ike ime mgbanwe ugbu a na ihe ndị mejupụtara ya, dị ka ịtụgharị pointer raw na ụdị dakọtara.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Decomposes a `Vec<T>` n'ime ya raw mmiri.
    ///
    /// Alaghachi na raw pointer na-apụtaghị ìhè na data, na ogologo nke vector (na ọcha), na ekenyela ike nke data (na ọcha), na allocator.
    /// Ndị a bụ otu arụmụka n'otu usoro okwu esemokwu dị na [`from_raw_parts_in`].
    ///
    /// Mgbe ọ kpọchara ọrụ a, onye na-akpọ oku bụ ọrụ maka ebe nchekwa nke `Vec` jibu.
    /// Nanị ụzọ ị ga-esi mee nke a bụ ịtụgharị pointer raw, ogologo, na ikike laghachi na `Vec` site na ọrụ [`from_raw_parts_in`], na-ekwe ka onye mbibi ahụ mee mkpocha.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Anyị nwere ike ime mgbanwe ugbu a na ihe ndị mejupụtara ya, dị ka ịtụgharị pointer raw na ụdị dakọtara.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Weghachi ọnụọgụ nke ihe vector nwere ike ijide na-enweghị mmegharị ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Echebe ikike maka opekata mpe `additional` ihe ndị ọzọ ka etinyere na `Vec<T>` enyere.
    /// Nchịkọta ahụ nwere ike idowe ohere dị ukwuu iji zere ịmegharị ọtụtụ oge.
    /// Mgbe akpọchara `reserve`, ikike ga-adị ukwuu karịa ma ọ bụ hara nhata `self.len() + additional`.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ikike ọhụrụ karịa `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Echebe ikike opekempe maka kpọmkwem `additional` ihe ndị ọzọ ka etinyere na `Vec<T>` enyere.
    ///
    /// Mgbe akpọchara `reserve_exact`, ikike ga-adị ukwuu karịa ma ọ bụ hara nhata `self.len() + additional`.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// Rịba ama na onye na-ekenye ya nwere ike inye nchịkọta ahụ ohere karịa ka ọ chọrọ.
    /// Ya mere, ikike-apụghị ịdabere na-abụ kpomkwem ntakiri.
    /// Na-ahọrọ `reserve` ma ọ bụrụ na a na-atụ anya ntinye ntinye future.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na ikike ohuru ejuputa `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Gbalịa ịchekwa ikike maka opekata mpe `additional` ihe ndị ọzọ ka etinyere na `Vec<T>` enyere.
    /// Nchịkọta ahụ nwere ike idowe ohere dị ukwuu iji zere ịmegharị ọtụtụ oge.
    /// Mgbe akpọchara `try_reserve`, ikike ga-adị ukwuu karịa `self.len() + additional`.
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// # Errors
    ///
    /// Ọ bụrụ na ikike tojubiga, ma ọ bụ onye na-ekenye ihe na-akọ ọdịda, mgbe ahụ eweghachitere njehie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Debe ebe nchekwa ahụ, na-apụ ma ọ bụrụ na anyị enweghị ike
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ugbu a anyị maara na nke a enweghị ike OOM n`etiti ọrụ dị mgbagwoju anya anyị
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // dị mgbagwoju anya
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Gbalịa idowe ikike opekempe maka kpọmkwem ihe `additional` a ga-etinye na `Vec<T>` enyere.
    /// Mgbe akpọchara `try_reserve_exact`, ikike ga-adị ukwuu karịa ma ọ bụ hara nhata `self.len() + additional` ma ọ bụrụ na ọ laghachiri `Ok(())`.
    ///
    /// Adighi eme ihe obula ma oburu na ikike ezuola.
    ///
    /// Rịba ama na onye na-ekenye ya nwere ike inye nchịkọta ahụ ohere karịa ka ọ chọrọ.
    /// Ya mere, ikike-apụghị ịdabere na-abụ kpomkwem ntakiri.
    /// Na-ahọrọ `reserve` ma ọ bụrụ na a na-atụ anya ntinye ntinye future.
    ///
    /// # Errors
    ///
    /// Ọ bụrụ na ikike tojubiga, ma ọ bụ onye na-ekenye ihe na-akọ ọdịda, mgbe ahụ eweghachitere njehie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Debe ebe nchekwa ahụ, na-apụ ma ọ bụrụ na anyị enweghị ike
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ugbu a anyị maara na nke a enweghị ike OOM n`etiti ọrụ dị mgbagwoju anya anyị
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // dị mgbagwoju anya
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Ibelata ikike nke vector dị ka o kwere mee.
    ///
    /// Ọ ga-agbadata dịka o kwere mee n'ogologo mana onye na-ekenye ya ka nwere ike ịgwa vector na enwere ohere maka ihe ole na ole.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // The ike bụ mgbe ihe na-erughị ogologo, na ọ dịghị ihe na-eme mgbe ha hà, otú ahụ ka anyị nwere ike izere panic bụrụ na `RawVec::shrink_to_fit` site naanị akpọ ya na a ukwuu ikike.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Ibelata ikike nke vector nwere obere agbụ.
    ///
    /// Ikike ahụ ga-adịgide ma ọ dịkarịa ala ka o buru ibu dị ka ogologo ma ogologo.
    ///
    ///
    /// Ọ bụrụ na ikike dị ugbu a dị obere karịa oke ala, nke a bụ enweghị op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Gbanwee vector ka ọ bụrụ [`Box<[T]>`][owned slice].
    ///
    /// Rịba ama na nke a ga-adalata ikike ọ bụla karịrị akarị.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Enwere ike iwepu ikike ọ bụla:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Na-eme ka vector dị mkpụmkpụ, na-edebe ihe mbụ `len` ma na-ahapụ ihe ndị ọzọ.
    ///
    /// Ọ bụrụ na `len` karịrị vector dị ugbu a karịa, nke a enweghị mmetụta.
    ///
    /// Usoro [`drain`] nwere ike iulateomi `truncate`, mana ọ na-akpata iweghachite ihe ndị ọzọ karịa ịhapụ ya.
    ///
    ///
    /// Rịba ama na usoro a enweghị mmetụta na ikike ekenyela nke vector.
    ///
    /// # Examples
    ///
    /// Truncating ihe ise vector na ihe abụọ:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Enweghị nkwụsịtụ ọ bụla na-eme mgbe `len` karịrị vector dị ugbu a:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating mgbe `len == 0` dị ka ịkpọ usoro [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Nke a dị mma n'ihi na:
        //
        // * iberi ahụ gafere `drop_in_place` dị irè;ikpe `len > self.len` na-ezere ịmepụta iberi na-abaghị uru, yana
        // * `len` nke vector na-agbada tupu akpọ `drop_in_place`, nke mere na ọ nweghị uru ọ ga-adaba ugboro abụọ ma ọ bụrụ na `drop_in_place` ga-panic otu ugboro (ọ bụrụ panics ugboro abụọ, mmemme ahụ ga-agbada).
        //
        //
        //
        unsafe {
            // Note: Ọ bụ ebumnuche na nke a bụ `>` na ọ bụghị `>=`.
            //       Gbanwe ya na `>=` nwere mmetụta arụmọrụ na-adịghị mma na ụfọdụ.
            //       Lee #78884 maka ihe.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ewepụtara iberi nke nwere vector niile.
    ///
    /// Ẹkot `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Extracts a mutable slice of dum vector.
    ///
    /// Ẹkot `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Weghachite pointer rawị na nchekwa vector.
    ///
    /// Onye na-akpọ oku ga-ekwusi ike na vector gafere akara na ọrụ a laghachi, ma ọ bụ na ọ ga-akwụsị na-atụba ihe mkpofu.
    /// Gbanwe vector nwere ike ime ka ebugharị ya, nke ga-emekwa ka akara ngosi ọ bụla ghara ịdị irè.
    ///
    /// Onye na-akpọ oku ga-ekwenyekwa na ncheta ihe (non-transitively) pointer na-atụtụghị ede (ma e wezụga n'ime `UnsafeCell`) na-eji pointer a ma ọ bụ ihe ọ bụla na-esite na ya.
    /// Ọ bụrụ n`ịchọrọ ịtụgharị ọdịnaya nke iberi ahụ, jiri [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Anyị na-ese onyinyo usoro iberibe nke otu aha iji zere ịgafe `deref`, nke na-emepụta ntụgharị okwu etiti.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Weghachite pointer a na-ejighi n'aka nchekwa na nchekwa vector.
    ///
    /// Onye na-akpọ oku ga-ekwusi ike na vector gafere akara na ọrụ a laghachi, ma ọ bụ na ọ ga-akwụsị na-atụba ihe mkpofu.
    ///
    /// Gbanwe vector nwere ike ime ka ebugharị ya, nke ga-emekwa ka akara ngosi ọ bụla ghara ịdị irè.
    ///
    /// # Examples
    ///
    /// ```
    /// // Kewaa vector buru oke ibu maka ihe 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Bido ihe ederede site na pointer raw raw dere, wee dezie ogologo.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Anyị na-ese onyinyo usoro iberibe nke otu aha iji zere ịgafe `deref_mut`, nke na-emepụta ntụgharị okwu etiti.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Alaghachi a na-ezo aka n'okpuru allocator.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Na-amanye ogologo vector na `new_len`.
    ///
    /// Nke a bụ ọrụ dị larịị nke na-ejigide onye ọ bụla na-adịghị agbanwe agbanwe nke ụdị ahụ.
    /// A na-agbanwe agbanwe nke vector n'ogologo site na iji otu n'ime arụmọrụ dị mma kama, dị ka [`truncate`], [`resize`], [`extend`], ma ọ bụ [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` ga-erughị ma ọ bụ hara ka [`capacity()`].
    /// - A ghaghị ịmalite ihe ndị dị na `old_len..new_len`.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Usoro a nwere ike ịba uru maka ọnọdụ nke vector na-eje ozi dị ka nchekwa maka koodu ndị ọzọ, ọkachasị FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Nke a bụ nanị a kacha nta ọkpụkpụ maka doc atụ;
    /// # // ejikwala nke a bụrụ mmalite maka ezigbo ọba akwụkwọ.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Kwa usoro FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SAFETY: Mgbe `deflateGetDictionary` laghachiri `Z_OK`, o kwuru na:
    ///     // 1. `dict_length` ebidola ihe dị iche iche.
    ///     // 2.
    ///     // `dict_length` <=ikike (32_768) nke na-eme `set_len` nchebe ịkpọ.
    ///     unsafe {
    ///         // Kpọọ oku FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ma melite ogologo ihe ebido.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Ọ bụ ezie na ihe atụ na-esonụ dị mma, enwere ncheta ebe ọ bụ na vectors dị n'ime adịghị atọhapụ tupu oku `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` bụ ihe efu ka ọ nweghị ihe dị mkpa ịmalite.
    /// // 2. `0 <= capacity` na-ejide `capacity` ọ bụla.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Nọmalị, ebe a, otu ga-eji [`clear`] kama iji dobe ọdịnaya ahụ n'ụzọ ziri ezi wee si otú ahụ ghara ịchefu ebe nchekwa.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Ewepu mmewere site na vector wee weghachite ya.
    ///
    /// Ejiri ihe ikpeazụ nke vector dochie ihe ewepụrụ.
    ///
    /// Nke a adịghị chebe ịtụ ihe, ma bụ O(1).
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `index` enweghị oke.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Anyị na-edochi onwe [ndeksi] na mmewere ikpeazụ.
            // Rịba ama na ọ bụrụ na oke ego elele anya na-aga nke ọma, a ga-enwerịrị ihe mmezi (nke nwere ike ịbụ onwe ya [index] n'onwe ya).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Fanye ihe mmewere na ọnọdụ `index` n'ime vector, na-agbanwe ihe niile mgbe ọ gasịrị aka nri.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // oghere maka ihe ọhụrụ
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // adighi agha agha Ihe ntụpọ itinye uru ọhụrụ
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Gbanwee ihe niile iji mee ohere.
                // (Duplicating ndị 'index`th mmewere abụọ consecutive ebe.)
                ptr::copy(p, p.offset(1), len - index);
                // Dee ya na, overwriting akpa akwụkwọ nke ``index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Wepu ma weghachite mmewere na ọnọdụ `index` n'ime vector, na-agbanwe ihe niile mgbe ọ gasịrị n'aka ekpe.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na `index` enweghị oke.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // ebe anyi na ewere.
                let ptr = self.as_mut_ptr().add(index);
                // detuo ya, n'enweghi nchekwa nke nwere oyiri nke uru di na ya na vector n`otu oge.
                //
                ret = ptr::read(ptr);

                // Gbanwee ihe niile iji mejupụta ebe ahụ.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Na-ejigide naanị ihe ndị akọwapụtara akọwapụtara.
    ///
    /// Yabụ, wepụ ihe niile `e` dị ka `f(&e)` laghachiri `false`.
    /// Usoro a na-arụ ọrụ n'ime ya, na-eleta ihe ọ bụla n'otu oge n'otu usoro mbụ, ma na-echekwa usoro nke ihe ndị ahụ ejidere.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Ebe ọ bụ na a na-eleta ihe ndị ahụ kpọmkwem otu ugboro na usoro izizi, enwere ike iji ọnọdụ mpụga iji chọpụta nke ihe ga-edobe.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Zere ịdaba okpukpu abụọ ma ọ bụrụ na anaghị egbu onye nche ndọrọndọrọ, ebe anyị nwere ike ịme oghere ụfọdụ n'oge usoro ahụ.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-hazie len-> |-na-esote ịlele
        //                  | <-ehichapụ cnt-> |
        //      | <-original_len-> |Wee: Ihe nke predicate alaghachi ezi on.
        //
        // Oghere: Ebugharị ma ọ bụ oghere oghere mejupụtara.
        // Unchecked: Unchecked nti ọcha.
        //
        // A ga-akpọ ndị nche nche a mgbe nsogbu ma ọ bụ `drop` nke ụjọ tụrụ.
        // Ọ na-agbanwe ihe ndị a na-ejighị n'aka kpuchie oghere na `set_len` ruo ogologo ziri ezi.
        // Na mgbe mgbe predicate na `drop` mgbe panick, ọ ga-kachasị pụta.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // NCHEKWA: trailing kpacharaghị ihe ga-nti kemgbe anyị na mgbe na-emetụ ha.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SAFETY: Mgbe i juputara oghere, ihe niile dị na ebe nchekwa.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SAFETY: Unchecked element ga-adị ire.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // N'aga n'ihu n'oge iji zere nkwụsị abụọ ma ọ bụrụ na ụjọ jidere `drop_in_place`.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SAFETY: Anyị anaghị emetụ ihe a aka ọzọ mgbe anyị kwụsịrị.
                unsafe { ptr::drop_in_place(cur) };
                // Anyị ebula ụzọ bughaa.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0, ya mere oghere oghere ekwesịghị ijikọ na mmewere dị ugbu a.
                // Anyị na-eji detuo maka ịgagharị, ma emetụkwa ihe a aka ọzọ.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // A na-edozi ihe niile.Nke a nwere ike kachasị ka `set_len` site LLVM.
        drop(g);
    }

    /// Na-ewepu ihe niile ma nke mbụ nke ihe ndị ọzọ na vector na-ekpebi otu igodo ahụ.
    ///
    ///
    /// Ọ bụrụ na edozi vector, nke a na-ewepu oyiri niile.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Wepu ihe niile ma nke mbụ nke ihe ndị ọzọ na-esote na vector na-enye afọ ojuju mmekọrịta e nyere.
    ///
    /// Ejiri `same_bucket` rụọ ọrụ zoro aka na ihe abụọ sitere na vector ma ga-ekpebi ma ihe ndị ahụ tụnyere nha.
    /// A na-agafe ihe ndị ahụ na usoro ha na nhazi ha, yabụ ọ bụrụ na `same_bucket(a, b)` laghachiri `true`, ewepụrụ `a`.
    ///
    ///
    /// Ọ bụrụ na edozi vector, nke a na-ewepu oyiri niile.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Gbakwunye ihe mmezi na azu mkpokọta.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ikike ọhụrụ karịa `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Nke a ga-panic ma ọ bụ wepụ ọ bụrụ na anyị ga-ekenye> isize::MAX bytes ma ọ bụ ọ bụrụ na mmụba ogologo ga-ejupụta maka ụdị nha efu.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Wepu ihe ikpeazụ si na vector wee weghachite ya, ma ọ bụ [`None`] ọ bụrụ na ọ tọgbọ chakoo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Na-ebugharị ihe niile nke `other` n'ime `Self`, na-ahapụ `other` efu.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ọnụ ọgụgụ nke ihe ndị dị na vector gafere `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Gbakwunye ihe na `Self` site na nchekwa ndị ọzọ.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Na-emepụta onye na-agba mmiri na-ewepu ihe akọwapụtara na vector ma mepụta ihe ndị ewepụrụ.
    ///
    /// Mgbe ite ite ** na-ada, ihe niile dị na nso a na-ewepụ site na vector, ọbụlagodi ma ọ bụrụ na e mechaghị iterator.
    /// Ọ bụrụ na ite ite **na-adịghị** ama esịn (ya na [`mem::forget`] dịka ọmụmaatụ), a maghị etu esi ewepụ ọtụtụ ihe.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na mbido kariri njedebe ma obu ma ogwugwu ihe kariri ogologo vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Ogologo zuru oke na-ekpochapụ vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Nchekwa ebe nchekwa
        //
        // Mgbe mbu emepụtara Drain, ọ na-ebelata ogologo oge vector dị mkpụmkpụ iji jide n'aka na enweghị nghọta ma ọ bụ akwagharị-sitere na ihe niile ga-enweta ma ọ bụrụ na onye mbibi Drain anaghị agba ọsọ.
        //
        //
        // Drain ga ptr::read wepụ ụkpụrụ iji wepu.
        // Mgbe emechara ya, a na-edegharị ọdụ ọdụ nke vec ahụ azụ iji kpuchie oghere ahụ, ma weghachite ogologo vector na ogologo ọhụụ ahụ.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // setịpụ self.vec ogologo ka ịmalite, ka ọ dị mma ma ọ bụrụ na Drain agbapụ
            self.set_len(start);
            // Jiri mgbazinye ego na IterMut iji gosipụta omume ịgbaziri agbazite nke Drain dum (dịka &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Na-ekpochapụ vector, na-ewepu ụkpụrụ niile.
    ///
    /// Rịba ama na usoro a enweghị mmetụta na ikike ekenyela nke vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Alaghachi ọnụ ọgụgụ nke ndị ọcha na vector, nakwa kwuru na dị ka ya 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Laghachi `true` ma ọ bụrụ na vector enweghị ihe ọ bụla.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kewara mkpokọta ahụ ụzọ abụọ na ndeksi edere.
    ///
    /// Laghachitere vector ohuru ohuru nke nwere ihe ndi di na `[at, len)`.
    /// Mgbe oku ahụ gasịrị, vector mbụ ga-ahapụ nwere ihe `[0, at)` na ikike ya gara aga agbanweghị.
    ///
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // ihe ohuru vector nwere ike weghachite ihe nchekwa mbu ma zere oyiri
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Ezighi ezi `set_len` ma detuo ihe na `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Mee ka `Vec` dị na ebe ka `len` na `new_len` hara.
    ///
    /// Ọ bụrụ na `new_len` karịrị `len`, `Vec` na-agbatị site na ọdịiche ahụ, oghere ọ bụla ọzọ jupụtara na nsonaazụ ịkpọ mmechi `f`.
    ///
    /// Kpụrụ nloghachi site na `f` ga-ejedebe na `Vec` n'usoro e mepụtara ha.
    ///
    /// Ọ bụrụ na `new_len` pere mpe `len`, `Vec` pere mpe.
    ///
    /// Usoro a na-eji mmechi mepụta ụkpụrụ ọhụrụ na ntinye ọ bụla.Ọ bụrụ na ịchọrọ [`Clone`] bara uru, jiri [`Vec::resize`].
    /// Ọ bụrụ n`ịchọrọ iji [`Default`] trait kenye ụkpụrụ, ịnwere ike ịgafe [`Default::default`] dị ka arụmụka nke abụọ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Erepịakwa ma leaks `Vec`, weghachite ntụgharị ntụgharị banyere ọdịnaya, `&'a mut [T]`.
    /// Mara na ụdị `T` ga-adị ndụ karịa ndụ niile ahọpụtara `'a`.
    /// Ọ bụrụ na ụdị ahụ nwere naanị ntụpọ static, ma ọ bụ enweghị ma ọlị, mgbe ahụ enwere ike ịhọrọ nke a ịbụ `'static`.
    ///
    /// Ọrụ a yiri ọrụ [`leak`][Box::leak] na [`Box`] belụsọ na enweghị ụzọ isi nwetaghachi ebe nchekwa ahụ.
    ///
    ///
    /// Ọrụ a bara uru maka data na-adị ndụ nke oge ndụ mmemme a.
    /// Tọpu akwụkwọ nlọghachi ga-eme ka ncheta ncheta.
    ///
    /// # Examples
    ///
    /// Ojiji dị mfe:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Weghachite ike fọdụrụnụ nke vector dị ka iberibe `MaybeUninit<T>`.
    ///
    /// Enwere ike iji iberibe azụ wee mejupụta vector na data (dịka
    /// site na ịgụ site na faịlụ) tupu akara data ahụ dị ka ebido site na iji usoro [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Kee vector buru oke ibu maka ihe 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Dejupụta ihe atọ mbụ ahụ.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Kanye akara n`ihe atọ izizi nke vector dị ka ihe bidoro.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Emejuputa usoro a na usoro nke `split_at_spare_mut`, iji gbochie mmebi iwu nke ihe na-echekwa.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Weghachite ọdịnaya vector dị ka iberibe `T`, ya na ikike fọdụrụnụ nke vector dị ka iberibe `MaybeUninit<T>`.
    ///
    /// Enwere ike iji iberibe ikike iberibe mejupụta vector na data (dịka site n'ịgụ site na faịlụ) tupu akara data ahụ dị ka ebido site na iji usoro [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Cheta na nke a bụ a ala-larịị API, nke a ga-eji na-elekọta njikarịcha nzube.
    /// Ọ bụrụ na ị chọrọ gbakwunyere data ka a `Vec` i nwere ike iji [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ma ọ bụ [`resize_with`], dabere na gị kpọmkwem mkpa.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Debe oghere ndị ọzọ buru ibu maka ihe 10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Dejupụta ihe anọ na-esote.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Kaa akara ihe anọ nke vector dị ka ebido.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len leghaara ma gbanwee agbanweghi
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Nchedo: na-agbanwe agbanwe laghachi .2 (&mut usize) a na-ewere dị ka ịkpọ `.set_len(_)`.
    ///
    /// A na-eji usoro a iji nweta ohere pụrụ iche na akụkụ vec niile n'otu oge na `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ekwe nkwa na ọ ga-adaba maka ihe `len`
        // - `spare_ptr` na-atụ aka otu mmewere gafee ebe nchekwa ahụ, yabụ na ọ naghị ekpuchi `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Mee ka `Vec` dị na ebe ka `len` na `new_len` hara.
    ///
    /// Ọ bụrụ na `new_len` karịrị `len`, a na-agbatị `Vec` site na ọdịiche ahụ, oghere ọ bụla ọzọ jupụtara na `value`.
    ///
    /// Ọ bụrụ na `new_len` pere mpe `len`, `Vec` pere mpe.
    ///
    /// Usoro a choro `T` iji mejuputa [`Clone`], iji nwee ike itinye oyiri nke uru a gafere.
    /// Ọ bụrụ na ịchọrọ ngbanwe karịa (ma ọ bụ chọọ ịdabere na [`Default`] kama [`Clone`]), jiri [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones na appends niile ọcha na a iberi na `Vec`.
    ///
    /// Iterates n'elu iberi `other`, clones ọ bụla mmewere, na mgbe ahụ tinye ya na a `Vec`.
    /// `other` vector na-agafe n'usoro.
    ///
    /// Rịba ama na ọrụ a bụ otu dị ka [`extend`] ma e wezụga na ọ na-pụrụ iche na-arụ ọrụ na Mpekere kama.
    ///
    /// Ọ bụrụ na mgbe Rust na-enweta iche iche, ọrụ a nwere ike belata (mana ọ ka dị).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Detuo ihe sitere na `src` ruo na njedebe nke vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` na-ekwe nkwa na usoro enyere dị irè maka ịkọwapụta onwe gị
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Koodu a na-achịkọta `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Gbasaa ụkpụrụ vector site na ụkpụrụ `n`, jiri jenerato nyere.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Jiri SetLenOnDrop rụọ ọrụ na ahụhụ ebe ebe nchịkọta nwere ike ọ gaghị achọpụta ụlọ ahịa site na `ptr` site na self.set_len() emela aha.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Dee ihe niile ma e wezụga nke ikpeazụ
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Mee ka ogologo dị na usoro ọ bụla ma ọ bụrụ na next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Anyị nwere ike dee ihe mmewere ozugbo na enweghị mkpokọta na-enweghị isi
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // nyere aka site na nche
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Na-ewepu ihe ndị emegharịrị akpọghachi na vector dị ka ntinye [`PartialEq`] trait.
    ///
    ///
    /// Ọ bụrụ na edozi vector, nke a na-ewepu oyiri niile.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Usoro na ọrụ dị n'ime
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` kwesịrị ịbụ nti index
    /// - `self.capacity() - self.len()` ga-abụ `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len na-ụba nanị mgbe initializing ọcha
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - ndị na-akpọ oku na src bụ ndaba ziri ezi
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element Element mere naanị site na `MaybeUninit::write`, yabụ ọ dị mma ịba ụba
            // - len na-abawanye mgbe ihe ọ bụla iji gbochie nkwụsị (lee mbipụta #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - ndị nlekọta na-akpọ oku na `src` bụ ndenye ziri ezi
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Emepụtara ihe nrịba ama abụọ a site na ntụnye akụkụ iberibe pụrụ iche (`&mut [_]` `) yabụ na ha bara uru ma ghara ịfefe.
            //
            // - Ọcha bụ: Copy n'ihi ya, ọ si OK ka iṅomi ha, na-enweghị eme ihe ọ bụla na mbụ ụkpụrụ
            // - `count` O ha ka len nke `source`, yabụ isi mmalite dị maka `count` agụ
            // - `.reserve(count)` na-ekwe nkwa na `spare.len() >= count` ya mere nkwụnye ego dị irè maka `count` na-ede
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - `copy_nonoverlapping` malitere ihe ndị ahụ
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Mmezu trait nkịtị maka Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): na cfg(test) usoro `[T]::to_vec` pụta ụwa, nke achọrọ maka nkọwapụta usoro a, adịghị.
    // Kama iji `slice::to_vec` arụ ọrụ naanị nke dị na cfg(test) NB lee usoro slice::hack na slice.rs maka ozi ndị ọzọ
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // idebe ihe ọ bụla a na-agaghị edegharị
        self.truncate(other.len());

        // self.len <= other.len n'ihi na truncate dị n'elu, ya mere, mpekere ebe a na-abụkarị oke.
        //
        let (init, tail) = other.split_at(self.len());

        // jigharịa ụkpụrụ dị allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Mepụta ihe na-eri ihe, ya bụ, nke na-akpali uru ọ bụla na vector (site na mbido ruo na njedebe).
    /// Enweghị ike iji vector kpọọ nke a.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s nwere ụdị eriri, bụghị &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // usoro akwukwo nke ihe omuma SpecFrom/SpecExtend di iche iche na-enyefe mgbe ha na-enweghi ihe ndi ozo ha ga-etinye
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Nke a bụ ikpe maka onye na-ede akwụkwọ n'ozuzu ya.
        //
        // Ọrụ a kwesiri ịbụ ihe omume:
        //
        //      maka ihe na ite ite {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB enweghị ike ịba ụba kemgbe anyị ga-ekenye oghere adreesị
                self.set_len(len + 1);
            }
        }
    }

    /// Na--emepụta onye na-emegharị ihe na-anọchi ebe a kapịrị ọnụ na vector na onye ọrụ `replace_with` enyere wee wepụta ihe ewepụrụ.
    ///
    /// `replace_with` ọ dịghị mkpa ka ọ bụrụ otu ogologo dịka `range`.
    ///
    /// `range` ewepụ ọbụlagodi ma ọ bụrụ na ekpochaghị onye na-ede ya rue mgbe ọgwụgwụ.
    ///
    /// Achọpụtaghị ọtụtụ ihe ewepụrụ na vector ma ọ bụrụ na ọnụọgụ `Splice` agbaala.
    ///
    /// Ihe ntinye ihe ntinye `replace_with` na-eri mgbe ihe `Splice` bara uru.
    ///
    /// Nke a kachasị mma ma ọ bụrụ:
    ///
    /// * Ọdụ (ihe dị na vector mgbe `range`) tọgbọ chakoo,
    /// * ma ọ bụ `replace_with` na-eweta ihe pere mpe ma ọ bụ hà karịa ogologo 'nso'
    /// * ma ọ bụ eriri ala nke `size_hint()` ya bụ eziokwu.
    ///
    /// Ma ọ bụghị ya, a na-ekenye vector nwa oge na ọdụ na-ebugharị ugboro abụọ.
    ///
    /// # Panics
    ///
    /// Panics ma oburu na mbido kariri njedebe ma obu ma ogwugwu ihe kariri ogologo vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Na-emepụta iterator nke na-eji mmechi eme ihe iji chọpụta ma ewepụ ihe mmewere.
    ///
    /// Ọ bụrụ na mmechi ahụ laghachiri n'eziokwu, mgbe ahụ, ewepụrụ ihe ahụ wee mee ya.
    /// Ọ bụrụ na mmechi ahụ ghaghachitere ụgha, mmewere ga-anọgide na vector ma agaghị anabata ya site na iterator.
    ///
    /// Iji usoro a eme ihe yiri koodu a:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // koodu gi ebe a
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Mana `drain_filter` dị mfe iji.
    /// `drain_filter` dịkwa mma ịrụ ọrụ nke ọma, n'ihi na ọ nwere ike ịla azụ ihe ndị mejupụtara n'usoro n'ọtụtụ.
    ///
    /// Rịba ama na `drain_filter` na-enyekwa gị ohere ịgbanwe ihe ọ bụla na mmechi nzacha, n'agbanyeghị ma ị họrọ idebe ma ọ bụ wepu ya.
    ///
    ///
    /// # Examples
    ///
    /// Na-ekewa otu usoro n'ime nsogbu na nsogbu, na-ejigharị nke mbụ
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Chebe ka anyị ghara leaked (ihihi amplification)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Gbasaa mmejuputa nke na-edepụta ihe site na ntụzịaka tupu ịmanye ha na Vec.
///
/// Mmejuputa iwu a bu ndi amara maka ndi na-eme ya, ebe o jiri [`copy_from_slice`] tinye ihe nile n`otu oge.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Nlekọta ihe atụ nke vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// - Imepụta ihe nke vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // jiri ndapu maka [T] jiri iberibe uzo mee ihe maka vector dika udiri adighi ike;
            //
            // nwere ike zere ajụjụ nke ịbụ ezigbo ya n'okwu ụfọdụ
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec na-edozi nkwekọrịta
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Mepụta `Vec<T>` efu.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: ule akwusila na libstd, nke na-akpata njehie ebe a
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: ule akwusila na libstd, nke na-akpata njehie ebe a
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Na-enweta ihe niile dị na `Vec<T>` dị ka usoro, ọ bụrụ na nha ya kwekọrọ na nke usoro ahụ achọrọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ọ bụrụ na ogologo ahụ adabaghị, ntinye na-abịaghachi na `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ọ bụrụ na ị dị mma na ịnweta prefix nke `Vec<T>`, ị nwere ike ibu ụzọ kpọọ [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SAFETY: `.set_len(0)` na-ada ụda mgbe niile.
        unsafe { vec.set_len(0) };

        // SAFETY: A pointer nke ``Vec` '' na-agbakọ mgbe niile n'ụzọ kwesịrị ekwesị, yana
        // Ndọtị usoro a chọrọ bụ otu ihe ahụ.
        // Anyị enyochaburu na anyị nwere ihe zuru ezu.
        // Ihe ndị ahụ agaghị ada okpukpu abụọ dị ka `set_len` gwara `Vec` ka ọ ghara idobekwa ha.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}