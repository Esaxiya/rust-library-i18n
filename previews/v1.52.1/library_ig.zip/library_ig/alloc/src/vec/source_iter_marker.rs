use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Ihe akara ngosi dị iche iche maka ịnakọta pipeline iterator n'ime Vec ka ị na-ejigharị isi mmalite, ntụgharị
/// na-eme pipeline na ebe.
///
/// Isi nne na nna trait dị mkpa maka ọrụ ọkachamara maka ịnweta oke nke a ga-ejigharị.
/// Mana ezughi oke maka icheiche dị iche iche.
/// Hụ oke ókè na mbugharị.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-esịtidem SourceIter/InPlaceIterable traits na-emejuputa site na agbụ nke nkwụnye ọkụ <Adapter<Adapter<IntoIter>>> (ihe nile bu core/std).
// Agbakwunye agbakwunyere na mmejuputa ihe nkwụnye (karịa `impl<I: Trait> Trait for Adapter<I>`) na-adabere na traits ndị ọzọ akararịrị dị ka iche iche traits (Detuo, TrustedRandomAccess, FusedIterator).
//
// I.e. ihe nrịbama ahụ adabereghị n'oge ndụ nke ụdị ndị ọrụ nyere.Modulo Detuo oghere, nke ọtụtụ ọkachamara ndị ọzọ dabereworị na ya.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Ihe ndi ozo choro nke apughi igosiputa site na trait bounds.Anyị na-adabere na eval kama:
        // a) enweghị ZSTs dịka enweghi ike ekenye ya ka ị ga-ejigharị ya na ịkọwapụta ihe ga-panic b) nha otu egwuregwu Alloc chọrọ c) nghazi egwuregwu dịka iwu Alloc chọrọ
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ịghaghachi azụ na mmejuputa iwu
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // were gbalịa-anọghị n'ozi kemgbe
        // - ọ vectorizes mma n'ihi na ụfọdụ iterator nkwụnye
        // - N'adịghị ka ọtụtụ usoro ịkọwapụta n'ime, ọ na-ewe naanị &mut
        // - o na eme anyi ka anyi tinye ihe anyi dere ede na ihe ndi ozo ma weghachite ya n'ikpeazụ
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration gara nke ọma, adapụla isi
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // ịlele ma ọ bụrụ na SourceIter nkwekọrịta e kwadoro caveat: ma ọ bụrụ na ha abụghị anyị nwere ike ghara ọbụna mee ka ọ a
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // lelee nkwekọrịta InPlaceIterable.Nke a ga-ekwe omume naanị ma ọ bụrụ na onye nyocha ahụ mere ka pointer isi iyi pụta.
        // Ọ bụrụ na ọ na-eji ohere anaghị enyocha ya site na TrustedRandomAccess mgbe ahụ isi mmalite pointer ga-anọ n'ọnọdụ mbụ ya ma anyị enweghị ike iji ya dị ka akwụkwọ
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // dobe ụkpụrụ ọ bụla fọdụrụ na ọdụ nke isi iyi ahụ mana gbochie nkwụsị nke oke onwe ya ozugbo IntoIter gafere ma ọ bụrụ na dobe panics mgbe ahụ, anyị na-atụpụkwa ihe ọ bụla anakọtara n'ime dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable enwere ike ghara ikwenye nkwekọrịta a ebe ọ bụ na try_fold nwere naanị ntụpọ maka isi mmalite pointer niile anyị nwere ike ime bụ ịlele ma ọ bụrụ na ọ ka dị
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}