use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Nlekọta trait eji Vec::from_iter
///
/// ## Ndị nnọchiteanya ahụ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Okwu a na-ahụkarị na-agafe vector na ọrụ nke na-achịkọta ozugbo na vector.
        // Anyị nwere ike ịme mkpụmkpụ nke a ma ọ bụrụ na IntoIter enwebeghị ọganihu ma ọlị.
        // Mgbe emegoro ya Anyi nwekwara ike jighachi ebe nchekwa ma megharia data na iru.
        // Mana anyị na-eme ya naanị mgbe Vec na-apụta agaghị enwe ikike a na-ejighi ya karịa ịmepụta ya site na ntinye akwụkwọ SiteIterator.
        //
        // Mmachi ahụ adịchaghị mkpa dị ka omume nnyefe nke Vec bụ nke amachaghị nke ọma.
        // Ma ọ bụ mgbanwe mgbanwe.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // ga-ekenye spec_extend() ebe ọ bụ na extend() n'onwe ya na-anọchite anya spec_from maka Vecs efu
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Nke a na-eji `iterator.as_slice().to_vec()` eme ihe ebe ọ bụ na spec_extend ga-emekwu ihe iji tụlee ikike ikpeazụ + wee rụkwuo ọrụ.
// `to_vec()` ozugbo na-ekenye ego ziri ezi ma jupụta ya kpọmkwem.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): na cfg(test) usoro `[T]::to_vec` pụta ụwa, nke achọrọ maka nkọwapụta usoro a, adịghị.
    // Kama iji `slice::to_vec` arụ ọrụ naanị nke dị na cfg(test) NB lee usoro slice::hack na slice.rs maka ozi ndị ọzọ
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}