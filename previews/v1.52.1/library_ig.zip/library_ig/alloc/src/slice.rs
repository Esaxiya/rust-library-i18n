//! Echiche dị iche iche na-agbanwe agbanwe, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Mpekere bụ echiche n'ime ngọngọ nke ebe nchekwa nọchiri anya ya dị ka pointer na ogologo.
//!
//! ```
//! // na-egbutu Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // na-eme ka otu ụdị dị iche iche
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Mpekere na-agbanwe ma ọ bụ na-ekekọrịta.
//! Dị ụdị iberibe bụ `&[T]`, ebe ụdị mpempe mpempe akwụkwọ bụ `&mut [T]`, ebe `T` na-anọchite ụdị mmewere.
//! Iji maa atụ, ịnwere ike ịgbanwe ebe nchekwa ebe ihe ọkụkụ na-atụgharị na-atụ aka:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Lee ụfọdụ n'ime ihe modulu a:
//!
//! ## Structs
//!
//! Enwere ọtụtụ stru nke bara uru maka mpekere, dịka [`Iter`], nke na-anọchite anya iteration n'elu iberi.
//!
//! ## Mmezi Trait
//!
//! Enwere ọtụtụ ntinye nke traits nkịtị maka mpekere.Fọdụ ihe atụ gụnyere:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], maka Mpekere nke ụdị mmewere ya bụ [`Eq`] ma ọ bụ [`Ord`].
//! * [`Hash`] - maka Mpekere nke ụdị mmewere ya bụ [`Hash`].
//!
//! ## Iteration
//!
//! Mpekere mejuputara `IntoIterator`.The iterator amịpụta zoro iberi ọcha.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Mpempe akwụkwọ a na-agbanwe agbanwe na-eweta ntụaka ntụgharị maka ihe ndị ahụ:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Nke a iterator amịpụta mutable zoro iberi si ọcha, n'ihi ya, mgbe mmewere ụdị nke iberi bụ `i32`, mmewere ụdị nke iterator bụ `&mut i32`.
//!
//!
//! * [`.iter`] na [`.iter_mut`] bu uzo doro anya iji weghachite ndabara iterators.
//! * Methodszọ ndị ọzọ na-eweghachi ndị na-emegharị ya bụ [`.split`], [`.splitn`], [`.chunks`], [`.windows`] na ndị ọzọ.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// A na-eji ọtụtụ ihe eji arụ ọrụ na modul a na nhazi nnwale.
// Ọ dị ọcha karịa iji gbanyụọ ịdọ aka ná ntị na-adịghị eji eme ihe karịa idozi ha.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Basic iberi ndọtị ụzọ
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) achọrọ maka ntinye nke `vec!` nnukwu oge ule NB, lee usoro `hack` na faịlụ a maka nkọwa ndị ọzọ.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) achọrọ maka ntinye nke `Vec::clone` n'oge nyocha NB, lee usoro `hack` na faịlụ a maka nkọwa ndị ọzọ.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Na cfg(test) `impl [T]` adịghị, ọrụ atọ ndị a bụ n'ezie ụzọ dị na `impl [T]` mana ọ bụghị na `core::slice::SliceExt`, anyị kwesịrị ịnye ọrụ ndị a maka ule `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Anyị ekwesịghị ịgbakwunye àgwà inline na nke a ebe ọ bụ na ejiri nke a na `vec!` macro nke kachasị ma na-akpata iweghachi mmụọ.
    // Hụ #71204 maka mkparịta ụka na nsonaazụ perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Ihe akara akara bidoro na akaghị okpuru
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) dị mkpa maka LLVM iji wepu nlele ego ma nwee codegen ka mma karịa zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // a na-ekenye vec ahụ ma malite n'elu ya ma ọ dịkarịa ala ogologo a.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // ekenyela elu ya na ikike nke `s`, ma bido na `s.len()` na ptr::copy_to_non_overlapping n'okpuru.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Na-ahọrọ iberi.
    ///
    /// Sortdị a kwụsiri ike (ntụgharị, anaghị edozigharị ihe ndị ọzọ) na *O*(*n*\*log(* n*)) kasị njọ.
    ///
    /// Mgbe ọdabara, ejighị n'aka sorting na-ahọrọ n'ihi na ọ bụ n'ozuzu ọsọ karịa anụ sorting na ọ dịghị ekenyela inyeaka ebe nchekwa.
    /// Hụ [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a bụ ụdị mgbanwe na-agbanwe agbanwe, na-agbanwe agbanwe nke sitere na [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Emere ya ka ọ dị oke ọsọ na ọnọdụ ebe ọ fọrọ nke nta ka iberibe ahihia ahụ, ma ọ bụ mejupụta usoro abụọ ma ọ bụ karịa nke edochara otu ọzọ.
    ///
    ///
    /// Ọzọkwa, ọ na-ekenye ọkara nchekwa nke ọkara nke `self`, mana maka mkpụmkpụ mkpụmkpụ a na-eji ụdị ntinye ntinye na-abụghị nke.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ụdị iberi na a comparator ọrụ.
    ///
    /// Sortdị a kwụsiri ike (ntụgharị, anaghị edozigharị ihe ndị ọzọ) na *O*(*n*\*log(* n*)) kasị njọ.
    ///
    /// Ọrụ nchịkọta ga-akọwapụta usoro iwu maka ihe ndị dị na iberi ahụ.Ọ bụrụ na ịtụghị ya bụ mkpokọta, usoro nke ihe ndị ahụ bụ kọwaghị.
    /// Usoro bụ usoro zuru ezu ma ọ bụrụ (ọ bụ maka `a`, `b` na `c`):
    ///
    /// * ngụkọta na antisymmetric: kpọmkwem otu nke `a < b`, `a == b` ma ọ bụ `a > b` bụ eziokwu, na
    /// * transitive, `a < b` na `b < c` pụtara `a < c`.Otu ga-ejide maka `==` na `>`.
    ///
    /// Iji maa atụ, ebe [`f64`] anaghị etinye [`Ord`] maka `NaN != NaN`, anyị nwere ike iji `partial_cmp` dịka ụdị ọrụ anyị mgbe anyị matara na iberi ahụ enweghị `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Mgbe ọdabara, ejighị n'aka sorting na-ahọrọ n'ihi na ọ bụ n'ozuzu ọsọ karịa anụ sorting na ọ dịghị ekenyela inyeaka ebe nchekwa.
    /// Hụ [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a bụ ụdị mgbanwe na-agbanwe agbanwe, na-agbanwe agbanwe nke sitere na [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Emere ya ka ọ dị oke ọsọ na ọnọdụ ebe ọ fọrọ nke nta ka iberibe ahihia ahụ, ma ọ bụ mejupụta usoro abụọ ma ọ bụ karịa nke edochara otu ọzọ.
    ///
    /// Ọzọkwa, ọ na-ekenye ọkara nchekwa nke ọkara nke `self`, mana maka mkpụmkpụ mkpụmkpụ a na-eji ụdị ntinye ntinye na-abụghị nke.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // reverse sorting
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Dichaa iberi na arụ ọrụ igodo.
    ///
    /// Dị a kwụsiri ike (ntụgharị, anaghị edozigharị ihe ndị ọzọ) yana *O*(*m*\* * n *\* log(*n*)) kasị njọ, ebe ọrụ igodo bụ *O*(*m*).
    ///
    /// Maka ọrụ igodo ọnụ (dịka ọmụmaatụ
    /// ọrụ ndị na-adịghị mfe ịnweta ịnweta ma ọ bụ arụmọrụ arụmọrụ), [`sort_by_cached_key`](slice::sort_by_cached_key) nwere ike ịdị ọsọ ọsọ karị, ebe ọ naghị akwụghachi igodo mmeghe.
    ///
    ///
    /// Mgbe ọdabara, ejighị n'aka sorting na-ahọrọ n'ihi na ọ bụ n'ozuzu ọsọ karịa anụ sorting na ọ dịghị ekenyela inyeaka ebe nchekwa.
    /// Hụ [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a bụ ụdị mgbanwe na-agbanwe agbanwe, na-agbanwe agbanwe nke sitere na [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Emere ya ka ọ dị oke ọsọ na ọnọdụ ebe ọ fọrọ nke nta ka iberibe ahihia ahụ, ma ọ bụ mejupụta usoro abụọ ma ọ bụ karịa nke edochara otu ọzọ.
    ///
    /// Ọzọkwa, ọ na-ekenye ọkara nchekwa nke ọkara nke `self`, mana maka mkpụmkpụ mkpụmkpụ a na-eji ụdị ntinye ntinye na-abụghị nke.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Dichaa iberi na arụ ọrụ igodo.
    ///
    /// N'oge nhazi, a na-akpọ ọrụ dị mkpa naanị otu ugboro n'otu mmewere.
    ///
    /// Dị a kwụsiri ike (ntụgharị, anaghị edozigharị ihe ndị ọzọ) na *O*(*m*\* * n *+* n *\* log(*n*)) kasị njọ, ebe ọrụ igodo bụ *O*(*m*) .
    ///
    /// Maka ọrụ igodo dị mfe (dịka, ọrụ nke na-enweta ihe onwunwe ma ọ bụ arụmọrụ nke ọma), [`sort_by_key`](slice::sort_by_key) nwere ike ịdị ọsọ ọsọ.
    ///
    /// # Ntinye ugbu a
    ///
    /// Algọridim dị ugbu a dabere na [pattern-defeating quicksort][pdqsort] site n'aka Orson Peters, nke na-agwakọta ngwa ngwa ngwa ngwa nke usoro ihe omuma na usoro kachasị ngwa ngwa, ebe ị na-enweta oge usoro na mpekere na ụfọdụ usoro.
    /// Ọ na-eji ụfọdụ aghara iji zere ikpe na-adịghị njọ, mana ya na seed edozi iji nye omume mgbe niile.
    ///
    /// N'okwu kacha njọ, algorithm na-ekenye nchekwa nchekwa nwa oge na `Vec<(K, usize)>` ogologo nke iberi ahụ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Enyemaka nnukwu maka ịkọwapụta vector anyị site n'ụdị pere mpe pere mpe, iji belata oke.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Ihe `indices` dị iche iche, dịka edepụtara ha, yabụ ụdị ọ bụla ga-akwụsi ike n'ihe gbasara mpempe mbụ.
                // Anyị na-eji `sort_unstable` ebe a n'ihi na ọ chọrọ obere inyefe ebe nchekwa.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Detuo `self` n'ime `Vec` ohuru.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Ebe a, `s` na `x` nwere ike ju onwe ha.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Detuo `self` n'ime `Vec` ohuru na onye na-ekenye ihe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Ebe a, `s` na `x` nwere ike ju onwe ha.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, lee usoro `hack` na faịlị a maka nkọwa ndị ọzọ.
        hack::to_vec(self, alloc)
    }

    /// Tọghata `self` n'ime vector na-enweghị clones ma ọ bụ oke.
    ///
    /// Enwere ike ịgbanye vector n'ime igbe site na `` Vec<T>Usoro `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` enweghị ike iji ya ọzọ maka na agbanweela ya na `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, lee usoro `hack` na faịlị a maka nkọwa ndị ọzọ.
        hack::into_vec(self)
    }

    /// Mepụta vector site na ikwugharị oge `n`.
    ///
    /// # Panics
    ///
    /// Ọrụ a ga-panic ma ọ bụrụ na ikike ga-erubiga ókè.
    ///
    /// # Examples
    ///
    /// Njiji ojiji:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic zuru oke:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ọ bụrụ na `n` buru ibu karịa efu, enwere ike kewaa ya dịka `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` bụ ọnụọgụ nke '1' kachasị aka ekpe nke `n`, na `rem` bụ akụkụ fọdụrụ na `n`.
        //
        //

        // Iji `Vec` iji nweta `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` a na-eme ugboro ugboro site ugboro abụọ `buf` ``expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ọ bụrụ na `m > 0`, enwere ọnụọgụ ndị fọdụrụ na '1' aka ekpe.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` nwere ikike nke `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` ('=n, 2' expn`) a na-emegharị ugboro ugboro site na iyingomi ugboro ugboro mbụ `rem` site na `buf` n'onwe ya.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ihe a anaghị ekpuchi ekpuchi kemgbe `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` nhata `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Na-eme ka iberibe `T` n'ime otu `Self::Output` bara uru.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens iberi nke `T` n'ime otu uru `Self::Output`, na-etinye onye nkewa nyere n'etiti nke ọ bụla.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens iberi nke `T` n'ime otu uru `Self::Output`, na-etinye onye nkewa nyere n'etiti nke ọ bụla.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Weghachite a vector nwere otu mpempe mpempe a ebe a na-edebe ihe ọ bụla na ASCII nke dị elu.
    ///
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'a' na 'z' na 'A' na 'Z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Iji ịba uru na ebe, jiri [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Laghachi vector nke nwere otu mpempe akwụkwọ a ebe a na-edepụta ihe ọ bụla na ASCII obere okwu ya na ya.
    ///
    ///
    /// A na-edepụta mkpụrụedemede ASCII 'A' na 'Z' na 'a' na 'z', mana mkpụrụedemede ndị na-abụghị ASCII anaghị agbanwe agbanwe.
    ///
    /// Iji wedata uru dị na ebe, jiri [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Mgbatị traits maka iberi ihe karịrị ụdị data dị iche iche
////////////////////////////////////////////////////////////////////////////////

/// Inyeaka trait maka [`[T]: : concat`](iberi::concat).
///
/// Note: ejighi ụdị ụdị `Item` mee ihe na trait a, mana ọ na-enye ohere ịme ka ọnụọgụ karịa.
/// Na-enweghị ya, anyị na-enweta njehie a:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Nke a bụ n'ihi na enwere ike ịnwe ụdị `V` nwere ọtụtụ ihe `Borrow<[_]>` pụtara, nke bụ na ọtụtụ ụdị `T` ga-emetụta:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ihe ụdị mgbe concatenation
    type Output;

    /// Mmejuputa iwu nke ``[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Inyeaka trait maka [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ihe ụdị mgbe concatenation
    type Output;

    /// Mmejuputa iwu nke [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Mmezu nke trait maka Mpekere
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // idebe ihe ọ bụla na lekwasịrị anya na-agaghị overwritten
        target.truncate(self.len());

        // target.len <= self.len n'ihi na truncate dị n'elu, ya mere, mpekere ebe a na-abụkarị oke.
        //
        let (init, tail) = self.split_at(target.len());

        // jigharịa ụkpụrụ dị allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Ntinye `v[0]` n'ime usoro nhazi ụzọ `v[1..]` nke mere na `v[..]` dum na-edozi.
///
/// Nke a bụ ụdị ntinye dị mkpa.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // E nwere ụzọ atọ iji mejuputa ntinye ebe a:
            //
            // 1. Gbanye ihe ndị dị n'akụkụ ruo mgbe nke mbụ rutere ebe njedebe ya.
            //    Agbanyeghị, otu a anyị na-e copyomi data karịa ihe dị mkpa.
            //    Ọ bụrụ na ihe dị iche iche bụ nnukwu ụlọ (dị oke ọnụ iji depụta), usoro a ga-adị nwayọ
            //
            // 2. Ghichaa ya ruo mgbe achọtara ebe dị mma maka ihe izizi.
            // Mgbe ahụ gbanwee ihe ndị na-esote ya iji nye ohere maka ya ma mechaa tinye ya n'ime oghere fọdụrụ.
            // Nke a bụ ezigbo usoro.
            //
            // 3. Detuo ihe mbu n'ime mgbanwe nwa oge.Iterate ruo mgbe achọrọ ya.
            // Ka anyị na-aga, detuo ihe ọ bụla agagharị n'ime oghere dị n'ihu ya.
            // N'ikpeazụ, detuo data site na nwa oge agbanwe n'ime oghere fọdụrụ.
            // Usoro a dị mma nke ukwuu.
            // Benchmarks gosipụtara arụmọrụ ka mma karịa nke usoro 2.
            //
            // Edebere usoro niile, nke atọ gosipụtara nsonaazụ kacha mma.Ya mere, anyị họọrọ nke ahụ.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // `hole` na-enyocha ala ọ bụla nke usoro ntinye, nke na-arụ ọrụ abụọ:
            // 1. Chebe iguzosi ike n'ezi ihe nke `v` site na panics na `is_less`.
            // 2. Jupụta oghere fọdụrụ na `v` na njedebe.
            //
            // Panic nchekwa:
            //
            // Ọ bụrụ na `is_less` panics n'oge ọ bụla n'oge usoro ahụ, `hole` ga-adaba ma jupụta oghere na `v` na `tmp`, si otú a hụ na `v` ka na-ejide ihe ọ bụla ọ malitere na mbụ otu oge.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` na-adaba ma si otú a depụta `tmp` n'ime oghere fọdụrụ na `v`.
        }
    }

    // Mgbe a dara ya, mbipụta sitere na `src` n'ime `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Jikọrọ ọnụ na-agbadata agbaghị ọsọ `v[..mid]` na `v[mid..]` n'iji `buf` dị ka nchekwa nwa oge, ma na-echekwa nsonaazụ ahụ na `v[..]`.
///
/// # Safety
///
/// Mpekere abụọ ahụ ga-abụrịrị ihe na-enweghị isi na `mid` ga-abụrịrị oke.
/// Echekwa `buf` ga-ezu iji jide otu nke mkpumkpu iberi.
/// Ọzọkwa, `T` agaghị abụ ụdị ụdị efu.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Usoro njikọ jikọrọ nke mbụ ụzọ dị mkpirikpi ruo `buf`.
    // Mgbe ahụ ọ na-achọpụta ọsọ ọsọ e depụtaghachiri na nke toro ogologo na-aga n'ihu (ma ọ bụ azụ), na-atụnyere ihe ndị ọzọ ha na-echeghị echegharị ma na-eyingomi obere (ma ọ bụ karịa) n'ime `v`.
    //
    // Ozugbo ọsọ ọsọ dị mkpụmkpụ zuru oke, a na-eme usoro ahụ.Ọ bụrụ na ọ ga-ebu ụzọ buru ụzọ gbaa ọsọ, mgbe ahụ anyị ga-edetu ihe ọ bụla fọdụrụ na obere ọsọ n'ime oghere fọdụrụ na `v`.
    //
    // `hole` na-enyochakarị usoro nke usoro a, nke na-arụ ọrụ abụọ:
    // 1. Chebe iguzosi ike n'ezi ihe nke `v` site na panics na `is_less`.
    // 2. Na-ejupụta oghere fọdụrụ na `v` ma ọ bụrụ na ọ ga-ebu ụzọ gbasaa ogologo oge.
    //
    // Panic nchekwa:
    //
    // Ọ bụrụ na `is_less` panics n'oge ọ bụla n'oge usoro a, `hole` ga-adaba wee jupụta oghere na `v` na mpaghara a na-echeghị echekwa na `buf`, wee hụ na `v` ka na-ejide ihe ọ bụla ọ malitere na mbụ otu oge.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ọsọ aka ekpe dị mkpụmkpụ.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Na mbu, ihe ntughari aka na mmalite nke uzo ha.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Na-eri obere akụkụ.
            // Ọ bụrụ na ọ hà nhata, họrọ agba aka ekpe iji kwado nkwụsi ike.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Nri agba ọsọ dị mkpumkpu.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Na mbu, ihe ntughari a na-egosi njedebe nke uzo ha.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Were akụkụ ka ukwuu.
            // Ọ bụrụ na ọ hà nhata, họrọ ọsọ ziri ezi iji kwado nkwụsi ike.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // N'ikpeazụ, `hole` na-adaba.
    // Ọ bụrụ na emeghị mkpụmkpụ dị mkpụmkpụ karịa, ihe ọ bụla fọdụrụ na ya ugbu a ka a ga-edegharị ya n'ime oghere na `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Mgbe a dara ya, detuo ihe `start..end` dị na `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` abụghị ụdị nke ụdị efu, yabụ ọ dị mma ịkekọrịta site nha ya.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Dị a jikọtara ụfọdụ (ma ọ bụghị ihe niile) echiche sitere na TimSort, nke akọwara n'ụzọ zuru ezu [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algọridim ahụ na-achọpụta agbadata na-agbadaghị agbadata, nke akpọrọ eke na-agba ọsọ.Onwere ihe na-echere ugbua ka agwota.
/// A na-agbanye ọsọ ọsọ ọhụụ ọ bụla na nchịkọta ahụ, mgbe ahụ, otu ụzọ abụọ nke na-esote ọsọ na-agbakọta ruo mgbe afọ abụọ ndị a nwere afọ ojuju:
///
/// 1. maka `i` ọ bụla na `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. maka `i` ọ bụla na `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Ndị na-enweghị atụ na-agba mbọ hụ na ngụkọta oge ịgba ọsọ bụ *O*(*n*\*log(* n*)) kasị njọ.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Mpekere nke ruo a n'ogologo esi ota iji ntinye ụdị.
    const MAX_INSERTION: usize = 20;
    // A na-agbatị ọsọ ọsọ dị mkpirikpi site na iji ụdị ntinye iji dịkarịa ala ma ọ dịkarịa ala ọtụtụ ihe a.
    const MIN_RUN: usize = 10;

    // Sorting enweghị omume bara uru na ụdị nha efu.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Short arrays na-edozi n'ụdị site na ntinye ntinye iji zere oke.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Kewapụta ebe nchekwa iji jiri dị ka ebe nchekwa ọkọ.Anyị na-edebe ogologo 0 ka anyị wee nwee ike idobe ya n'ime mbipụta ndị na-emighị emi nke ọdịnaya nke `v` na-enweghị ihe ize ndụ ndị dtors na-agba na mbipụta ma ọ bụrụ `is_less` panics.
    //
    // Mgbe ị na-ejikọta ọsọ ọsọ abụọ, nchekwa a na-ejide otu ọsọ dị mkpirikpi, nke ga-enwe ogologo oge n'ọtụtụ `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Iji mata nke ọma sitere na `v`, anyị na-agagharị na ya azụ.
    // Nke ahụ nwere ike ịdị ka mkpebi dị ịtụnanya, mana tụlee eziokwu ahụ bụ na njikọta ọnụ na-agakarị na-abụghị ụzọ (forwards).
    // Dabere na ntụle, ijikọ ihu na ihu ọsọ ọsọ ọsọ karịa ijikọ azụ.
    // Ikwubi, ịmata na-agbaba site agafe azu azu mma arụmọrụ.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Choo oso ozo nke ozo, ma megharia ya ma oburu na o gha agbadata.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Fanye ụfọdụ ihe ndị ọzọ na-agba ọsọ ma ọ bụrụ na ọ dị mkpụmkpụ.
        // Dị ntinye bụ ngwa ngwa karịa ụdị jikọrọ na obere usoro, yabụ nke a mere ka arụmọrụ ka mma.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Na-agbanye ọsọ a na nchịkọta.
        runs.push(Run { start, len: end - start });
        end = start;

        // Jikota ụfọdụ ụzọ abụọ dị n'akụkụ na-agba ọsọ iji mejuo ndị na-adịghị agbanwe agbanwe.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // N'ikpeazụ, otu ịgba ọsọ ga-anọgide na nchịkọta.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Na-enyocha nchịkọta nke ọsọ ma chọpụta ụzọ agba abụọ na-esote iji jikọta.
    // Karịsịa, ọ bụrụ na a laghachiri `Some(r)`, nke ahụ pụtara `runs[r]` na `runs[r + 1]` ga-agbakọta ọzọ.
    // Ọ bụrụ na algọridim ga na-ewu a ọhụrụ ọsọ kama, `None` na-laghachi.
    //
    // TimSort bụ aha ọjọọ maka itinye n'ọrụ ya, dị ka akọwara ebe a:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Isi okwu nke akụkọ a bụ: anyị kwesịrị ịmanye ndị na-enweghị ntụkwasị obi na elu anọ na-agba ọsọ na nchịkọta.
    // Ịmanye ha na dị nnọọ elu atọ bụ zuru ezu iji hụ na invariants ka ga-jide maka *niile* agbaba na tojupụtara.
    //
    // Ọrụ a na-enyocha ndị enweghị mgbanwe maka ụzọ anọ dị elu.
    // Tụkwasị na nke a, ọ bụrụ na ọsọ ọsọ dị elu na-amalite na ndeksi 0, ọ ga-achọ ka ọrụ jikota ruo mgbe nchịkọta ahụ ga-ada kpamkpam, iji mezue ụdị ahụ.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}