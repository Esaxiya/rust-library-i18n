#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Ihe omuma nke ncheta ohuru bu ihe omuma.
    Uninitialized,
    /// Ebe nchekwa ohuru kwesiri nkwa.
    Zeroed,
}

/// Ulo oru di ala maka otutu ergonomically na-ekenye, na-ebughari ya, ma na-etinye ebe nchekwa nke ebe nchekwa ahu n'enweghi nsogbu banyere nsogbu ndi ozo.
///
/// Typedị a magburu onwe ya maka iwulite usoro data gị dịka Vec na VecDeque.
/// Ọ kachasị:
///
/// * Na-emepụta `Unique::dangling()` n'ụdị nha efu.
/// * Na-emepụta `Unique::dangling()` na oke oke ogologo.
/// * Na-ezere ịhapụ `Unique::dangling()`.
/// * Na-ejide ihe niile juputara na ngụkọta ikike (na-akwalite ha na "capacity overflow" panics).
/// * Ndị nche megide sistemụ 32-bit na-ekenye karịa isize::MAX bytes.
/// * Ndị na-eche nche megide ịba ụba ogologo gị.
/// * Kpọọ `handle_alloc_error` maka oke ọdịda.
/// * Nwere `ptr::Unique` ma si otú a nye onye ọrụ uru niile metụtara ya.
/// * Na-eji ngafe eweghachiri site na ekenye iji nnukwu ikike dịnụ.
///
/// Typedị a anaghị agbanye ebe nchekwa ọ na-achịkwa.Mgbe ọ dara, ọ ga-eme ka ncheta ya ghara ịdị, ma ọ gaghị anwa * ịhapụ ihe dị n'ime ya.
/// Ọ bụ onye ọrụ nke `RawVec` ka ọ ga-ejikwa ihe ndị ahụ echekwara * n'ime `RawVec`.
///
/// Rịba ama na ngafe nke ụdị ụdị efu anaghị enwe enweghi ngwụcha, yabụ `capacity()` na-alaghachi `usize::MAX`.
/// Nke a pụtara na ịkwesịrị ịkpachara anya mgbe ị na-atụgharị ụdị a na `Box<[T]>`, ebe ọ bụ na `capacity()` agaghị enye ogologo.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Nke a dị n'ihi na `#[unstable]` ``const fn`s ekwesịghị ịgbaso `min_const_fn` ma yabụ enweghị ike ịkpọ ha na '' min_const_fn`s ma.
    ///
    /// Ọ bụrụ n`ịgbanwee `RawVec<T>::new` ma ọ bụ ndị dabere na ya, biko kpachara anya ka ị ghara iwebata ihe ọ bụla ga-emebi `min_const_fn`
    ///
    /// NOTE: Anyị nwere ike izere mbanye anataghị ikike a wee chọpụta ụfọdụ njirimara `#[rustc_force_min_const_fn]` nke chọrọ nkwekọrịta na `min_const_fn` mana anaghị enye ohere ịkpọ ya na `stable(...) const fn`/koodu njirimara anaghị enyere `foo` aka mgbe `#[rustc_const_unstable(feature = "foo", issue = "01234")]` dị.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Mepụta `RawVec` kachasị ukwuu (na nchịkọta usoro) na-enweghị ekenye.
    /// Ọ bụrụ na `T` nwere oke dị mma, mgbe ahụ nke a na-eme `RawVec` nwere ikike `0`.
    /// Ọ bụrụ na `T` bụ nha efu, mgbe ahụ ọ na-eme `RawVec` nwere ikike `usize::MAX`.
    /// Ọ bara uru maka itinye n'ọrụ oge egbu oge.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Mepụta `RawVec` (na nchịkọta usoro) nwere oke ikike na nhazi maka `[T; capacity]`.
    /// Nke a yiri ịkpọ `RawVec::new` mgbe `capacity` bụ `0` ma ọ bụ `T` bụ nha efu.
    /// Rịba ama na ọ bụrụ na `T` enweghị nha nke a pụtara na ị gaghị * nweta `RawVec` na ikike achọrọ.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ikike achọrọ karịrị `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Bubata na OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Dị ka `with_capacity`, ma na-ekwe nkwa na echekwa na-efu.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstitutes a `RawVec` site na pointer na ikike.
    ///
    /// # Safety
    ///
    /// A ga-ekenye `ptr` (na nchịkọta usoro), yana `capacity` enyere.
    /// `capacity` enweghị ike ịgafe `isize::MAX` maka ụdị nha.(naanị nchegbu na sistemụ 32-bit).
    /// ZST vectors nwere ike ịnwe ikike ruo `usize::MAX`.
    /// Ọ bụrụ na `ptr` na `capacity` sitere na `RawVec`, mgbe ahụ emeziri nke a.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Obere Vecs bụ ogbi.Gaa na:
    // - 8 ma ọ bụrụ na mmewere size bụ 1, n'ihi na ihe ọ bụla kpokọtara allocators nwere ike imechi elu a arịrịọ nke na-erughị 8 bytes dịkarịa ala 8 bytes.
    //
    // - 4 ma ọ bụrụ na ihe dị oke oke (<=1 KiB).
    // - 1 ma ọ bụghị, iji zere imefusị ohere maka Vecs dị mkpirikpi.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Dị ka `new`, mana etinyebere aka na nhọrọ nke ekenyela maka `RawVec` laghachiri.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` pụtara "unallocated".a na-eleghara ụdị nha efu anya.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Dị ka `with_capacity`, mana etinyebere aka na nhọrọ nke ekenyela maka `RawVec` laghachiri.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Dị ka `with_capacity_zeroed`, mana etinyebere aka na nhọrọ nke ekenyela maka `RawVec` laghachiri.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Gbanwee `Box<[T]>` ka ọ bụrụ `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Na-agbanwe nchekwa niile na `Box<[MaybeUninit<T>]>` na `len` akọwapụtara.
    ///
    /// Rịba ama na nke a ga-eweghachite mgbanwe `cap` ọ bụla enwere ike ịrụ.(Lee nkọwa nke ụdị maka nkọwa.)
    ///
    /// # Safety
    ///
    /// * `len` aghaghi ibu kariri ma obu karie ikike a choro n'oge na-adịbeghị anya, ma
    /// * `len` ga-erughị ma ọ bụ hara ka `self.capacity()`.
    ///
    /// Rịba ama, na ikike a rịọrọ na `self.capacity()` nwere ike ịdị iche, dịka onye na-ekenye ihe nwere ike ịgbasa ma weghachite ebe nchekwa ka ukwuu karịa ka a rịọrọ.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-lelee ọkara ọkara nke nchekwa achọrọ (anyị enweghị ike ịlele ọkara ọzọ).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Anyị na-ezere `unwrap_or_else` ebe a n'ihi na ọ na-egbochi ego nke LLVM IR mepụtara.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Reconstitutes a `RawVec` si a pointer, ikike, na allocator.
    ///
    /// # Safety
    ///
    /// A ga-ekenye `ptr` (site na ekenye ihe nhazi `alloc`), yana `capacity` enyere.
    /// `capacity` enweghị ike ịgafe `isize::MAX` maka ụdị nha.
    /// (naanị nchegbu na sistemụ 32-bit).
    /// ZST vectors nwere ike ịnwe ikike ruo `usize::MAX`.
    /// Ọ bụrụ na `ptr` na `capacity` sitere na `RawVec` kere site na `alloc`, mgbe ahụ emeziri nke a.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Na-enweta pointer raw na mmalite nke oke.
    /// Mara na nke a bụ `Unique::dangling()` ma ọ bụrụ na `capacity == 0` ma ọ bụ `T` bụ nha efu.
    /// N'okwu mbụ, ị ga-akpachara anya.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Alụta ike nke oke.
    ///
    /// Nke a ga-abụ `usize::MAX` mgbe niile ma ọ bụrụ na `T` enweghị nha.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Alaghachi a na-akọrọ banyere allocator akwado a `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Anyi nwere ebe nchekwa anyi, ya mere anyi nwere ike igbanwe ego ndenye ego iji nweta nhazi anyi ugbu a.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Gbaa mbọ hụ na nchekwa ahụ nwere opekata mpe ohere iji jide ihe `len + additional`.
    /// Ọ bụrụ na o nwebeghị ikike zuru oke, ga-emezigharị ohere zuru oke yana nke ọma ịdị umengwụ iji nweta agwa *O*(1).
    ///
    /// Ga-ejedebe omume a ma ọ bụrụ na ọ ga-akpata onwe ya na panic.
    ///
    /// Ọ bụrụ na `len` karịrị `self.capacity()`, nke a nwere ike ọ gaghị ekenye oghere achọrọ.
    /// Nke a adịchaghị mma, mana koodu nchekwa *ị* dere na-adabere na omume nke ọrụ a nwere ike imebi.
    ///
    /// Nke a dị mma maka itinye nnukwu ọrụ dị ka `extend`.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ikike ọhụrụ karịa `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Bubata na OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ndoputa ga-ewepu ma ọ bụ maa jijiji ma ọ bụrụ na ntinye ahụ gafere `isize::MAX` yabụ na ọ dị mma ịmepụghị ugbu a.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Otu ihe ahụ dị ka `reserve`, mana ịlaghachi na njehie kama ịtụ ụjọ ma ọ bụ iwepụ afọ ime.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Gbaa mbọ hụ na nchekwa ahụ nwere opekata mpe ohere iji jide ihe `len + additional`.
    /// Ọ bụrụ na ọ maghị, ọ ga-eme ka ọnụọgụ nchekwa kacha nta dị mkpa.
    /// N'ozuzu nke a ga-abụ ọnụ ọgụgụ nke ebe nchekwa dị mkpa, mana n'ụkpụrụ onye na-ekenye ya nwere ikike ịnyeghachi karịa ka anyị rịọrọ.
    ///
    ///
    /// Ọ bụrụ na `len` karịrị `self.capacity()`, nke a nwere ike ọ gaghị ekenye oghere achọrọ.
    /// Nke a adịchaghị mma, mana koodu nchekwa *ị* dere na-adabere na omume nke ọrụ a nwere ike imebi.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ikike ọhụrụ karịa `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Bubata na OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Otu ihe ahụ dị ka `reserve_exact`, mana ịlaghachi na njehie kama ịtụ ụjọ ma ọ bụ iwepụ afọ ime.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Ibelata oke ruo kpọmkwem ego.
    /// Ọ bụrụ na ego enyere bụ 0, n'ezie na-ekewapụ kpamkpam.
    ///
    /// # Panics
    ///
    /// Panics ma ọ bụrụ na ego enyere bụ *ibu* karịa ikike ugbu a.
    ///
    /// # Aborts
    ///
    /// Bubata na OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Alaghachi ma ọ bụrụ na echekwa kwesịrị itolite iji mezuo ikike achọrọ ọzọ.
    /// Karịsịa iji mee ka ndenye ndenye oku ga-ekwe omume na-enweghị ntinye `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Nke a na usoro a na-emekarị instantiated ọtụtụ ugboro.Ya mere anyi choro ka o pere mpe dika o kwere mee, ka igbalite oge ichikota.
    // Mana anyi choro ka otutu ihe di n`ime ya gha aputa onu ahia dika o kwere mee, ime ka koodu emeputara na oso.
    // Ya mere, edere usoro a nke ọma ka koodu niile dabere na `T` dị n'ime ya, ebe ọtụtụ koodu na-adabereghị na `T` dị ka o kwere mee nọ na ọrụ ndị na-abụghị ọnụọgụ karịa `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Emere nke a site na ọnọdụ ọkpụkpọ.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ebe ọ bụ na anyị laghachi ikike nke `usize::MAX` mgbe `elem_size` bụ
            // 0, ibute ebe a putara na `RawVec` karịrị akarị.
            return Err(CapacityOverflow);
        }

        // Onweghị ihe anyị nwere ike ime gbasara nlele ndị a, ọ dị nwute.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Nke a na-ekwe nkwa ịba ụba.
        // Ugboro abụọ enweghị ike ịfefe n'ihi na `cap <= isize::MAX` na ụdị `cap` bụ `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` bụ ihe na-abụghị ọnụọgụ karịa `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Mgbochi ndị dị na usoro a bụ otu ihe ahụ dị ka ndị dị na `grow_amortized`, mana usoro a na-abụkarị nke a na-etinyekarị oge ọ bụla n'ihi ya ọ naghị adị oke egwu.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ebe ọ bụ na anyị laghachiri ikike nke `usize::MAX` mgbe ụdị nha bụ
            // 0, ibute ebe a putara na `RawVec` karịrị akarị.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` bụ ihe na-abụghị ọnụọgụ karịa `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ọrụ a dị na mpụga `RawVec` iji belata oge mkpokọta.Hụ nkọwa dị n'elu `RawVec::grow_amortized` maka nkọwa.
// (Ntọala `A` abụghị ihe dị mkpa, n'ihi na ọnụọgụ nke ụdị `A` dị iche iche a hụrụ na omume pere mpe karịa nọmba nke ụdị `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Lelee maka njehie ebe a iji belata nha `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Onye na ekenye ego na-achọpụta maka ịha nhatanha
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Na-ewepụta ebe nchekwa nke `RawVec`*na-enweghị* ịnwa idobe ọdịnaya ya.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Central ọrụ maka idobere njehie njikwa.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Anyị kwesịrị ịkwado ihe ndị a:
// * Anyị anaghị ekenye ihe ọ bụla `> isize::MAX`.
// * Anyị anaghị ejupụta `usize::MAX` ma wepụta obere obere.
//
// Na 64-bit ọ dị anyị mkpa ịlele maka njupụta ebe ọ bụ na ịnwa ịwapụta `> isize::MAX` bytes ga-ada.
// Na 32-bit na 16-bit anyị kwesịrị ịgbakwunye onye nche maka nke a ma ọ bụrụ na anyị na-agba ọsọ n'elu ikpo okwu nke nwere ike iji 4GB niile na oghere onye ọrụ, dịka, PAE ma ọ bụ x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Otu ọrụ dị mkpa maka ịkọ akụkọ ikike gafere.
// Nke a ga-agba mbọ hụ na ọgbụgba koodu metụtara panics ndị a pere mpe ebe enwere naanị otu ebe panics karịa ụyọkọ usoro ahụ.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}