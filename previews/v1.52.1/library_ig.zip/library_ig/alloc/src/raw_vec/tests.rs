use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Ide ederede nke njikọta n'etiti ndị na-ekenye ndị ọzọ na `RawVec` bụ ntakịrị aghụghọ n'ihi na `RawVec` API anaghị ekpughe ụzọ ndị a ga-esi mee nke ọma, yabụ anyị enweghị ike ịlele ihe na-eme mgbe ike gwụchara onye na-ekenye gị (karịa ịchọpụta panic).
    //
    //
    // Kama, nke a na-achọpụta na usoro `RawVec` na-agafe ma ọ dịkarịa ala gafere API Allocator mgbe ọ debere nchekwa.
    //
    //
    //
    //
    //

    // Onye na-ekwu okwu dara ogbi na-erepịa mmanụ mmanụ tupu oke mbọ amalite ọdịda.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (na-akpata realloc, si otú a na-eji 50 + 150=200 nkeji mmanụ)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Nke mbu, `reserve` na-ekenye dika `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 karịrị okpukpu abụọ karịa 7, ya mere `reserve` kwesịrị ịrụ ọrụ dị ka `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 dị ihe na-erughị ọkara nke 12, yabụ `reserve` ga-etolite n'ike n'ike.
        // N'oge edere ule a na-eto eto bụ 2, yabụ ikike ọhụrụ bụ 24, agbanyeghị, uto nke 1.5 dịkwa mma.
        //
        // N'ihi ya `>= 18` na-ekwu.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}