/// Ejiri [`Vec`] nwere arụmụka.
///
/// `vec!` na-enye ohere ``Vec`s ka akọwara ya na otu syntax ka usoro okwu.
/// Macdị igwe abụọ a dị:
///
/// - Mepụta [`Vec`] nke nwere ndepụta nke ihe ndị enyere:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Mepụta [`Vec`] site na ihe enyere na ogo:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Rịba ama na n'adịghị ka usoro okwu usoro a, njikọ a na-akwado ihe niile na-emejuputa [`Clone`] na ọnụọgụ nke ihe anaghị agbanwe agbanwe.
///
/// Nke a ga-eji `clone` mee oyiri okwu, yabụ mmadụ kwesịrị ịkpachara anya site na iji nke a na ụdị nwere ụdị mmejuputa `Clone`.
/// Dịka ọmụmaatụ, `vec![Rc::new(1);5] ga-ekeputa vector nke ise e zoro aka na otu uru ọnụ ọgụgụ akpọrọ aha, ọ bụghị ntụaka ise na-atụ aka na nọmba ndị ọzọ akpọrọ igbe.
///
///
/// Ọzọkwa, rịba ama na a hapụrụ `vec![expr; 0]`, ma na-emepụta vector efu.
/// Nke a ka ga-enyocha `expr`, agbanyeghị, ọ ga-adaba uru ọ bara ozugbo, yabụ buru n'uche mmetụta ndị ọzọ.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): na cfg(test) usoro `[T]::into_vec` bu pụta ụwa, nke achọrọ maka nkọwapụta macro a, adịghị.
// Kama iji `slice::into_vec` arụ ọrụ nke nwere naanị cfg(test) NB lee slice::hack modul na slice.rs maka ozi ndị ọzọ
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Mepụta `String` n'iji interpolation nke okwu oge.
///
/// Mkparịta ụka mbụ `format!` na-enweta bụ eriri usoro.Nke a ga-abụrịrị eriri nkịtị.Ike nke eriri formatting dị na `` {} '' ndị dị n'ime ya.
///
/// Ihe ntinye ndị ọzọ gafere `format!` dochie `` {} '' n'ime eriri usoro na usoro enyere ọ gwụla ma ejiri aha ma ọ bụ ọnọdụ ọnọdụ;lee [`std::fmt`] maka inweta ihe omuma.
///
///
/// Ihe eji eme ihe maka `format!` bu nkwekorita na nkwekorita nke eriri.
/// Otu mgbakọ ahụ ka ejiri ya na [`print!`] na [`write!`] macros, dabere na ebumnuche ebumnuche nke eriri.
///
/// Iji gbanwee otu uru na eriri, jiri usoro [`to_string`].Nke a ga-eji [`Display`] ịhazi trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics ma oburu na nhazi ihe trait weghachitere njehie.
/// Nke a na-egosi mmezigharị ezighi ezi ebe ọ bụ na `fmt::Write for String` anaghị alaghachi njehie n'onwe ya.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Mee AST ọnụ iji kwupụta nyocha iji melite nyocha na ọnọdụ ụkpụrụ.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}