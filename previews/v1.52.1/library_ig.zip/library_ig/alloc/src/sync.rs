#![stable(feature = "rust1", since = "1.0.0")]

//! Eriri nchekwa-ntughari ihe na-agụta.
//!
//! Hụ akwụkwọ [`Arc<T>`][Arc] maka nkọwa ndị ọzọ.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Nkwụsị dị nro na ọnụego nke ederede nke enwere ike ime `Arc`.
///
/// Gafe oke a ga-ewepụ mmemme gị (ọ bụ ezie na ọ bụchaghị) na ntụpọ _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer anaghị akwado ebe nchekwa.
// Iji zere ụgha mma akụkọ na Arc/adịghị ike mmejuputa iwu iji atọmịk ibu maka mmekọrịta kama.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Ihe na-eme ka ihe ghara ịgụnye eri.'Arc' na-anọchite anya 'Atomically Reference Count'.
///
/// Xdị `Arc<T>` na-enye nnwere oke nke ụdị nke ụdị `T`, ekenyela na kpokọtara.Vkpọ [`clone`][clone] na `Arc` na-emepụta ihe ọhụrụ `Arc`, nke na-arụtụ aka n'otu oke na ikpo dị ka isi mmalite `Arc`, ebe ị na-abawanye ọnụ ọgụgụ.
/// Mgbe akara aka `Arc` nke ikpeazụ na oke ekenyela, uru echekwara na oke ahụ (nke ana-akpọkarị "inner value") na-agbadata.
///
/// Nnwekọrịta edere na Rust disallow mutation ndabara, na `Arc` sokwa: i nwere ike n'ozuzu nweta a mutable banyere ihe dị n'ime ihe `Arc`.Ọ bụrụ na ịchọrọ ịgbanwe site na `Arc`, jiri [`Mutex`][mutex], [`RwLock`][rwlock], ma ọ bụ otu n'ime ụdị [`Atomic`][atomic].
///
/// ## Nchedo Nzuzo
///
/// N'adịghị ka [`Rc<T>`], `Arc<T>` na-eji arụmọrụ atom arụ ọrụ maka ịgụpụta ya.Nke a pụtara na ọ bụ eri-safe.Ihe ọghọm ya bụ na arụ ọrụ atomiki dị oke ọnụ karịa nnweta ebe nchekwa dị ala.Ọ bụrụ n `ị naghị ekekọrịta oke e kenyere e kenyere n`etiti eri, tụlee iji [`Rc<T>`] maka obere efegharị n`elu.
/// [`Rc<T>`] bụ a mma ndabere, n'ihi na compiler ga-enwetaghị ọ bụla iji zipu [`Rc<T>`] n'etiti eri.
/// Agbanyeghị, ọbá akwụkwọ nwere ike ịhọrọ `Arc<T>` iji nye ndị na-azụ ọbá akwụkwọ ohere mgbanwe karịa.
///
/// `Arc<T>` ga-etinye [`Send`] na [`Sync`] ka oge `T` na-eme [`Send`] na [`Sync`].
/// Kedu ihe kpatara na ịnweghị ike itinye ụdị `T` na-enweghị eri na `Arc<T>` iji mee ya nchekwa-nchekwa?Nke a nwere ike ịbụ ntakịrị nghọta na mbụ: ka emechara, ọ bụghị isi nke `Arc<T>` nchekwa nchekwa?Isi ihe bụ nke a: `Arc<T>` na-eme ka ọ ghara ịnwe ọtụtụ data ma ọ nweghi ike itinye ya na data ya.
///
/// Tụlee ``Arc <'' (`` RefCell<T>`` ''>>.
/// [`RefCell<T>`] abụghị [`Sync`], na ọ bụrụ na `Arc<T>` mgbe niile [`Send`], 'Arc <' ['RefCell<T>``>>`` ga-adị mma.
/// Mana mgbe ahụ anyị ga-enwe nsogbu:
/// [`RefCell<T>`] na-eri mma;ọ na-edobe usoro ịgbaziri agbaziri site na iji arụmọrụ na-abụghị atọmịk.
///
/// Na njedebe, nke a pụtara na ịnwere ike ijikọ `Arc<T>` yana ụdị [`std::sync`] ụfọdụ, na-abụkarị [`Mutex<T>`][mutex].
///
/// ## Akinggbaji cycles na `Weak`
///
/// Enwere ike iji usoro [`downgrade`][downgrade] mepụta pointer [`Weak`] na-enweghị nke ya.Nchịkọta [`Weak`] nwere ike ịbụ [``kwalite`][nweta nkwalite] d na `Arc`, mana nke a ga-alaghachi [`None`] ma ọ bụrụ na uru echekwara na oke ahụ adaala.
/// Yabụ, `Weak` pointers anaghị edebe uru dị n`ime oke ahụ dị ndụ;agbanyeghị, ha * na-eme ka oke (ụlọ ahịa na-akwado ihe bara uru) dị ndụ.
///
/// Agaghị emegharị n'etiti usoro `Arc` pointers.
/// Maka nke a, eji [`Weak`] agbaji okirikiri.Dịka ọmụmaatụ, osisi nwere ike ịnwe ihe ngosi `Arc` siri ike site na nne na nna nye ụmụaka, yana [`Weak`] na-atụ aka sitere na ụmụaka laghachi na nne na nna ha.
///
/// # Ntughari cloning
///
/// Mepụta ederede ọhụrụ site na pointer dị ugbu a-agụpụtara ejiri `Clone` trait emejuputa maka [`Arc<T>`][Arc] na [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Usoro syntax abụọ a dị n'okpuru bụ otu.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, na foo bu ndi Arks na-arutu aka n`otu ebe ebe nchekwa di
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` na-akpaghị aka idegharị na `T` (site na [`Deref`][deref] trait), yabụ ị nwere ike ịkpọ usoro T`na uru nke ụdị `Arc<T>`.Iji zere esemokwu aha na usoro T`, usoro nke `Arc<T>` n'onwe ya bụ ọrụ metụtara, akpọrọ iji [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `` Akara<T>Ihe mmezu nke traits dika `Clone` nwekwara ike ịkpọ site na iji syntax zuru oke.
/// Fọdụ ndị na-ahọrọ iji syntax zuru oke nke ọma, ebe ndị ọzọ na-ahọrọ iji syntax-akpọ syntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Usoro-akpọ syntax
/// let arc2 = arc.clone();
/// // Okwu mmeghe zuru ezu
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] adighi edebanye aha na `T`, n'ihi na enwere ike beendata uru dị n'ime ya.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Kesa ụfọdụ immutable data n`etiti eri:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Rịba ama na anyị **anaghị** agba ule ndị a ebe a.
// Ndị na-ewu windows enweghị nnukwu obi ụtọ ma ọ bụrụ na eri gafere isi eriri wee pụọ n'otu oge ahụ (ihe na-egbochi) n'ihi ya anyị na-ezere nke a kpamkpam site na ịghara ịgba ule ndị a.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Kekọrịta [`AtomicUsize`] nwere ike ịgbanwe:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Hụ [`rc` documentation][rc_examples] maka ihe atụ ndị ọzọ maka ịgụ ọnụ n'ozuzu.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` bụ ụdị nke [`Arc`] nke na-ejide aka na-enweghị aka nke oke ekenyela.
/// Enweta oke a site na ịkpọ [`upgrade`] na pointer `Weak`, nke weghachitere [``Nhọrọ '' '' <`['' Arc`] ''<T>>.
///
/// Ebe ọ bụ na ederede `Weak` anaghị agụta onye nwe ya, ọ gaghị egbochi uru echekwara na oke ahụ ka ọ daa, na `Weak` n'onwe ya anaghị ekwe nkwa maka uru ọ ka dị.
///
/// N'ihi ya, ọ nwere ike ịlaghachi [`None`] mgbe [``upgrade`] d.
/// Rịba ama na ntinye `Weak`* ** na-egbochi oke onwe ya (ụlọ ahịa na-akwado ya) ka ewepụ ya.
///
/// Nchịkọta `Weak` bara uru maka ịdebe oge nwa oge maka oke nke [`Arc`] jisiri ike na-enweghị igbochi uru dị n'ime ya ka ọ daa.
/// A na-ejikwa ya iji gbochie ntụaka okirikiri n'etiti ihe atụ [`Arc`], ebe ọ bụ na inwe ntụnye aka agaghị ekwe ka a hapụ [`Arc`].
/// Dịka ọmụmaatụ, osisi nwere ike ịnwe ihe ngosi [`Arc`] siri ike site na nne na nna gaa ụmụaka, yana `Weak` egosi ụmụaka site na azụ ndị mụrụ ha.
///
/// Zọ kachasị esi nweta pointer `Weak` bụ ịkpọ [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Nke a bụ `NonNull` iji kwe ka ịhapụta ụdị nke a na enum, mana ọ bụchaghị ezigbo akara aka.
    //
    // `Weak::new` setịpụrụ nke a na `usize::MAX` ka ọ ghara ịkpa oke ohere na mkpo.
    // Nke a abaghị uru ezigbo pointer ga-enwe n'ihi na RcBox nwere nhazi opekata mpe 2.
    // Nke a ga-ekwe omume mgbe `T: Sized`;unsized `T` never dangle.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Nke a bụ repr(C) na future-proof megide oghachighachi ubi, nke ga-egbochi [into|from]_raw() dị mma nke ụdị dị n'ime.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // uru usize::MAX na-arụ ọrụ dị ka onye nche maka nwa oge "locking" ikike iji kwalite ntụpọ na-adịghị ike ma ọ bụ wedata ndị siri ike;a na-eji ihe a zere agbụrụ na `make_mut` na `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Na-ewuli `Arc<T>` ọhụrụ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Malite na-adịghị ike pointer ọnụ dị ka 1 nke bụ adịghị ike pointer nke ahụ na-ẹkenịmde niile ike pointers (kinda), hụ std/rc.rs maka ihe Ama
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Na-ewu `Arc<T>` ọhụrụ site na iji ntụpọ na-adịghị ike na ya.
    /// Attgbalị ịkwalite akwụkwọ na-adịghị ike tupu ọrụ a alaghachi ga-eme ka ọnụọgụ `None`.
    /// Agbanyeghị, ederede na-esighi ike nwere ike kụọ ya kpamkpam ma chekwaa ya maka oge ọzọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Wupụta n'ime n'ime "uninitialized" steeti site na iji otu ntụpọ na-adịghị ike.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ọ dị mkpa na anyị anaghị ahapụ ịnwe ikike nke onye na-esighi ike, ma ọ bụghị ya, enwere ike ịtọhapụ ebe nchekwa ahụ oge `data_fn` ga-alaghachi.
        // Ọ bụrụ na anyị chọrọ ịgafe ikike, anyị nwere ike ịmepụta pointer adịghị ike ọzọ maka onwe anyị, mana nke a ga-eme ka mmelite ndị ọzọ na ngụkọta ntụpọ na-esighi ike nke nwere ike ọ gaghị adị mkpa ma ọ bụghị.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ugbu a, anyị nwere ike ibido nkewa dị n`ime ya nke ọma wee mee ka ntụzị aka anyị na-adịghị ike gaa ntụaka siri ike.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ihe edere n'elu ga-abanye na data data ga-ahụrịrị eriri ọ bụla nke na-ahụ ọnụ ọgụgụ na-abụghị efu.
            // Yabụ, anyị chọrọ opekata mpe "Release" iji mekọrịta na `compare_exchange_weak` na `Weak::upgrade`.
            //
            // "Acquire" ịtụ bụghị chọrọ.
            // Mgbe ị na-atụle omume omume nke `data_fn` anyị kwesịrị ileba anya n'ihe ọ nwere ike ime site na ịkọwa `Weak` na-enweghị ike ịkwalite:
            //
            // - Ọ nwere ike *mmepụta okike*`Weak`, na-abawanye ọnụ ọgụgụ na-adịghị ike.
            // - O nwere ike idebe clones ndị ahụ, na-ebelata ọnụ ọgụgụ na-adịghị ike (ma ọ gaghị adị efu).
            //
            // Mmetụta ndị a adịghị emetụta anyị n'ụzọ ọ bụla, ọ nweghịkwa mmetụta ndị ọzọ ga-ekwe omume na koodu nchekwa naanị.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Ntuziaka siri ike kwesiri ijikọ aka na-adighi ike, ya mere adighi agba oso agha maka akwukwo ochie anyi.
        //
        mem::forget(weak);
        strong
    }

    /// Na-ewuli `Arc` ọhụrụ na ọdịnaya ndị na-enweghị ncheta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ebubere mmalite:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Na-ewuli `Arc` ọhụrụ na ọdịnaya ndị na-enweghị ihe ọmụma, ebe nchekwa ahụ jupụtara `0` bytes.
    ///
    ///
    /// Hụ [`MaybeUninit::zeroed`][zeroed] maka ihe atụ nke iji usoro a nke ọma na ezighi ezi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Na-ewuli `Pin<Arc<T>>` ọhụrụ.
    /// Ọ bụrụ na `T` adịghị etinye `Unpin` n'ọrụ, mgbe ahụ `data` ga-atụnye na ebe nchekwa ma ghara inwe ike imegharị.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Na-ewuli `Arc<T>` ọhụrụ, weghachite njehie ma ọ bụrụ na oke adaa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Malite na-adịghị ike pointer ọnụ dị ka 1 nke bụ adịghị ike pointer nke ahụ na-ẹkenịmde niile ike pointers (kinda), hụ std/rc.rs maka ihe Ama
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Na-ewuli `Arc` ọhụrụ na ọdịnaya ndị na-enweghị uche, weghachite njehie ma ọ bụrụ na oke adaa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ebubere mmalite:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Na-ewu `Arc` ọhụrụ na ọdịnaya ndị na-enweghị ihe ọmụma, ebe nchekwa ahụ jupụtara na `0` bytes, weghachite njehie ma ọ bụrụ na oke adaa.
    ///
    ///
    /// Hụ [`MaybeUninit::zeroed`][zeroed] maka ihe atụ nke iji usoro a nke ọma na ezighi ezi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Weghachite uru dị n'ime, ma ọ bụrụ na `Arc` nwere otu ntụpọ siri ike.
    ///
    /// Ma ọ bụghị ya, a laghachiri [`Err`] na otu `Arc` ahụ agafere.
    ///
    ///
    /// Nke a ga-aga nke ọma ọbụlagodi na enwere ntụpọ pụtara ìhè.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Mee pointer na-esighi ike iji kpochapụ ihe ederede siri ike
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Chepụtara a ọhụrụ atomically akwụkwọ-gua iberi na uninitialized ọdịnaya.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ebubere mmalite:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Na-ewuli mpempe akwụkwọ atomụl akpọrọ akpọrọ nke nwere ọdịnaya dị iche iche, ebe nchekwa juputara na `0` bytes.
    ///
    ///
    /// Hụ [`MaybeUninit::zeroed`][zeroed] maka ihe atụ nke iji usoro a nke ọma na ezighi ezi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Na-atụgharị na `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Dị ka ọ dị na [`MaybeUninit::assume_init`], ọ bụ onye na-akpọ oku ka o kwere nkwa na uru dị n'ime dị na steeti amalitela.
    ///
    /// Kpọ nke a mgbe amabeghị ọdịnaya zuru oke na-ebute omume anaghị akọwagha ozugbo.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ebubere mmalite:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Na-atụgharị na `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Dị ka ọ dị na [`MaybeUninit::assume_init`], ọ bụ onye na-akpọ oku ka o kwere nkwa na uru dị n'ime dị na steeti amalitela.
    ///
    /// Kpọ nke a mgbe amabeghị ọdịnaya zuru oke na-ebute omume anaghị akọwagha ozugbo.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ebubere mmalite:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Na-eri `Arc`, na-eweghachi pointer ọbọp.
    ///
    /// Iji zere ebe nchekwa na-egosi pointer ga-agbanwe ya laghachi na `Arc` site na iji [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Na-enye pointer raw na data ahụ.
    ///
    /// Anaghị emetụta ọnụ ọgụgụ ahụ n'ụzọ ọ bụla na `Arc` anaghị eri ya.
    /// Ihe pointer ahụ dị irè ma ọ bụrụhaala na ọnụọgụ siri ike na `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: Nke a enweghị ike ịgafe Deref::deref ma ọ bụ RcBoxPtr::inner n'ihi
        // nke a choro ka ijigide ihe ngosi raw/mut dika eg
        // `get_mut` nwere ike ide site na pointer mgbe Rc natara site `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Na-ewu `Arc<T>` site na pointer raw.
    ///
    /// Ekwesịrị ịghachitelarị pointer raw ahụ site na oku na [`Arc<U>::into_raw`][into_raw] ebe `U` ga-enwerịrị nha na ntinye dị ka `T`.
    /// Nke a bụ eziokwu ma ọ bụrụ na `U` bụ `T`.
    /// Rịba ama na ọ bụrụ na `U` abụghị `T` mana ọ nwere otu nha na ntinye, nke a bụ isi dị ka ntụgharị ntụgharị nke ụdị dị iche iche.
    /// Lee [`mem::transmute`][transmute] maka inweta ihe omuma banyere ihe mgbochi di na nke a.
    ///
    /// Onye ọrụ nke `from_raw` ga-ahụrịrị na otu uru `T` bara otu ugboro.
    ///
    /// Ọrụ a adịghị mma n'ihi na iji ya eme ihe n'ụzọ na-ezighi ezi nwere ike ibute nchekwa na nchekwa, ọbụlagodi na enweghị ike ịnweta `Arc<T>` laghachiri.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Gbanwee azụ na `Arc` iji gbochie ihihi ahụ.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Callskpọ oku na `Arc::from_raw(x_ptr)` agaghị abụ ihe ncheta.
    /// }
    ///
    /// // Enwere ncheta mgbe `x` gafere n'elu, yabụ `x_ptr` na-agba ugbu a!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Gbanwee mmebi ahụ ịchọta ArcInner mbụ.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Mepụta pointer [`Weak`] ọhụrụ na oke a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Ezumike a dị mma n'ihi na anyị na-enyocha uru na CAS n'okpuru.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // lelee ma ọ bụrụ na ndị na-adịghị ike counter bụ ugbu a "locked";ọ bụrụ otú ahụ, atụ ogho.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: koodu a ugbu a na-eleghara ohere iji jubiga ókè
            // n'ime usize::MAX;na mkpokọta ma Rc na Arc chọrọ ka emeziwanye iji mejupụta oke.
            //

            // N'adịghị ka Clone(), anyị kwesịrị ka nke a bụrụ Acquire agụ iji gakọrịta na edemede na-abịa site na `is_unique`, nke mere na ihe ndị mere tupu edemede ahụ na-eme tupu agụ a.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Gbaa mbọ hụ na anyị ekeghị Egwu na-adịghị ike
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Nweta nọmba nke [`Weak`] ntụpọ na oke a.
    ///
    /// # Safety
    ///
    /// Usoro a n'onwe ya dị mma, mana iji ya n'ụzọ ziri ezi chọrọ nlekọta ọzọ.
    /// Threadzọ ọzọ nwere ike ịgbanwe ọnụọgụ na-adịghị ike n'oge ọ bụla, gụnyere nke nwere ike ịdị n'etiti ịkpọ usoro a ma rụọ ọrụ na nsonaazụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Nkwupụta a bụ mkpebi n'ihi na anyị ekebeghị `Arc` ma ọ bụ `Weak` n'etiti eri.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ọ bụrụ na ọnụ ọgụgụ na-adịghị ike ka akpọchiri ugbu a, uru ọnụ ọgụgụ ahụ bụ 0 tupu ewere mkpọchi ahụ.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Na-enweta ọnụọgụ nke (`Arc`) siri ike na oke a.
    ///
    /// # Safety
    ///
    /// Usoro a n'onwe ya dị mma, mana iji ya n'ụzọ ziri ezi chọrọ nlekọta ọzọ.
    /// Threadzọ ọzọ nwere ike ịgbanwe ọnụọgụ siri ike n'oge ọ bụla, gụnyere nke nwere ike ịdị n'etiti ịkpọ usoro a ma rụọ ọrụ na nsonaazụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Nkwupụta a bụ mkpebi n'ihi na anyị ekebeghị `Arc` n'etiti eri.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Nsonaazụ nkwado siri ike na `Arc<T>` metụtara pointer enyere site na otu.
    ///
    /// # Safety
    ///
    /// A gha enwetara pointer ahụ site na `Arc::into_raw`, na ihe atụ `Arc` metụtara metụtara ga-adị ire (ntụgharị
    /// ike ọnụ ga-dịkarịa ala 1) maka oge nke usoro a.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Nkwupụta a bụ mkpebi n'ihi na anyị ekebeghị `Arc` n'etiti eri.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Na-ejigide Arc, ma emetụla nkwụghachi site na itinye na ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Ugbu a mụbaa nkwụghachi, mana agbadakwa nkwụghachi ọhụrụ ma
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Mkpebi nlebara anya siri ike na `Arc<T>` jikọtara ya na pointer nyere site na otu.
    ///
    /// # Safety
    ///
    /// A gha enwetara pointer ahụ site na `Arc::into_raw`, na ihe atụ `Arc` metụtara metụtara ga-adị ire (ntụgharị
    /// ọnụ ọgụgụ siri ike ga-abụ opekata mpe 1) mgbe ị na-akpọ usoro a.
    /// Enwere ike iji usoro a hapụ `Arc` ikpeazụ na nchekwa nchekwa, mana **ekwesighi** ịkpọ ya mgbe ahapụchara `Arc` ikpeazụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Nkwupụta ndị ahụ bụ mkpebi siri ike n'ihi na anyị ekebeghị `Arc` n'etiti eri.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Nchekwa a adịchaghị mma n'ihi na ọ bụ ezie na akụ a dị ndụ, anyị jidere ya na pointer dị n'ime dị irè.
        // Ọzọkwa, anyị maara na usoro `ArcInner` n'onwe ya bụ `Sync` n'ihi na data dị n'ime ya bụ `Sync` yana ya, yabụ anyị na-agbazinye ihe na-enweghị atụ na ọdịnaya ndị a.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Ngalaba na-adịghị edebanye aha na `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Bibie data n'oge a, ọ bụ ezie na anyị nwere ike ịhapụ ịhapụ oke igbe n'onwe ya (enwere ike ịnwe akara ngosi na-esighi ike dina).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Dobe ihe na-esighi ike nke ederede niile siri ike
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Alaghachi `true` ma ọ bụrụ na abụọ 'Arc`s mgbe otu oke (na a akwara yiri [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Na-ekenye `ArcInner<T>` na ohere zuru oke maka uru dị n'ime a na-enweghị ike ịkọwapụta ebe ọnụahịa bara uru.
    ///
    /// A na-akpọ `mem_to_arcinner` arụ ọrụ na pointer data ma ghaghachitere onye na-egosi ihe maka `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Gbakọọ nhazi site na iji nhazi uru enyere.
        // Na mbu, a gbakọọ nhazi na okwu `&*(ptr as* const ArcInner<T>)`, mana nke a mepụtara ntụzigharị ezighi ezi (lee #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Allocates ihe `ArcInner<T>` zuru ezu ohere maka a ikekwe-unsized n'ime uru ebe uru nwere layout nyere, na-alọta njehie ma ọ bụrụ na oke ada ada.
    ///
    ///
    /// A na-akpọ `mem_to_arcinner` arụ ọrụ na pointer data ma ghaghachitere onye na-egosi ihe maka `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Gbakọọ nhazi site na iji nhazi uru enyere.
        // Na mbu, a gbakọọ nhazi na okwu `&*(ptr as* const ArcInner<T>)`, mana nke a mepụtara ntụzigharị ezighi ezi (lee #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Bido ArcInner ahụ
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Na-ekenye `ArcInner<T>` na ohere zuru oke maka uru dị n'ime ya.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Nkesa maka `ArcInner<T>` site na iji uru enyere.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Detuo uru dika bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Hapụ oke ahụ na-ahapụ ịhapụ ọdịnaya ya
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Na-ekenye `ArcInner<[T]>` na ogologo enyere.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Detuo ihe site na iberibe n'ime Arc ekenyela ọhụrụ <\[T\]>
    ///
    /// Enweghị nchedo n'ihi na onye na-akpọ oku ga-enwerịrị onye nwe ya ma ọ bụ kee `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Na-ewuli `Arc<[T]>` site na ite ite mara na o nwere otu nha.
    ///
    /// Akọwapụtaghị akparamagwa ma oke nha ahụ ezighi ezi.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic nche mgbe cloning T ọcha.
        // Na ihe omume nke a panic, ọcha na e dere n'ime ọhụrụ ArcInner ga-ama esịn, mgbe ahụ, na ebe nchekwa tọhapụrụ.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Nkọwapụta nke mbụ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Nile doro anya.Chefuo onye nche ka o ghara idoputa ArcInner ohuru.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Nlekọta trait eji `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Na-eme ka a mmepụta oyiri nke `Arc` pointer.
    ///
    /// Nke a na-eme otu pointer ọzọ n`otu oke, na-eme ka ọnụ ọgụgụ dị ike siri ike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Iji ịtụ jụụ ịtụnye ọnụ bụ ọfụma ebe a, ebe ịmara mbido mbụ na-egbochi eri ndị ọzọ iji ihie ụzọ ihichapụ ihe ahụ.
        //
        // Dị ka akọwara na [Boost documentation][1], asing bawanye mpempe akwụkwọ nrụtụ aka nwere ike ime mgbe niile na memory_order_relaxed: Ntughari ọhụụ maka ihe nwere ike ịmebe site na ntụle dị ugbu a, na ịnyefe ihe ederede dị na otu eri gaa na nke ọzọ ga-enyerịrị mmekọrịta ọ bụla achọrọ.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Agbanyeghị ọ dị anyị mkpa ịchekwa nchedo nnukwu ego ọ bụrụ na mmadụ bụ 'mem: : echefula Arcs.
        // Ọ bụrụ na anyị emeghị nke a, ọnụọgụ nwere ike ịjupụta na ndị ọrụ ga-eji-n'efu.
        // Anyị na-eche na `isize::MAX` na-eche na anyị enweghị ~2 ijeri eri na-agbakwunye ọnụ ọgụgụ otu oge.
        //
        // Agaghị ewere branch a na mmemme ọ bụla.
        //
        // Anyị na-ete ime n'ihi na mmemme dị otu a dara njọ, anyị achọghị ịma ịkwado ya.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Na-eme ka ntụgharị okwu ntụgharị n'ime `Arc` enyere.
    ///
    /// Ọ bụrụ na enwere ihe ngosi `Arc` ma ọ bụ [`Weak`] ndị ọzọ na otu oke, mgbe ahụ `make_mut` ga-emepụta oke ọhụụ wee kpọọ [`clone`][clone] na uru dị n'ime iji hụ na enwere ikike pụrụ iche.
    /// A na-akpọkwa nke a dị ka clone-on-dee.
    ///
    /// Rịba ama na nke a dị iche na omume nke [`Rc::make_mut`] nke na-ekewapụ akara ngosi `Weak` ọ bụla fọdụrụnụ.
    ///
    /// Hụkwa [`get_mut`][get_mut], nke ga-ada ada karịa cloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Agaghị mmepụta oyiri ihe ọ bụla
    /// let mut other_data = Arc::clone(&data); // Agaghị mmepụta oyiri data dị n'ime
    /// *Arc::make_mut(&mut data) += 1;         // Clones n'ime data
    /// *Arc::make_mut(&mut data) += 1;         // Agaghị mmepụta oyiri ihe ọ bụla
    /// *Arc::make_mut(&mut other_data) *= 2;   // Agaghị mmepụta oyiri ihe ọ bụla
    ///
    /// // Ugbu a `data` na `other_data` ebe dị iche iche allocations.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Rịba ama na anyị jidere ma nkọwa siri ike ma akwụkwọ na-esighi ike.
        // Yabụ, ịhapụ nkọwapụta siri ike anyị naanị agaghị eme ka icheta ebe nchekwa ahụ n'onwe anyị.
        //
        // Jiri Nweta iji jide n'aka na anyị na-ahụ ihe ọ bụla edere na `weak` nke na-eme tupu ịhapụ ntọhapụ (ntụgharị, mbelata) na `strong`.
        // Ebe ọ bụ na anyị ejideghị ọnụ ọgụgụ na-esighi ike, enweghị ohere ArcInner n'onwe ya nwere ike ịhazi ya.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Ọzọ pointer siri ike dị, n'ihi ya, anyị ga-mmepụta oyiri.
            // - Ebu ụzọ nye ebe nchekwa na-ekwe ka ide na cloned uru ozugbo.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Izu ike zuru ezu na nke a dị n'elu n'ihi na nke a bụ njikarịcha njikarịcha: anyị na-agba ọsọ mgbe niile na-adọtaghị ike.
            // Kasị njọ ikpe, anyị ejedebe ekenyela a Arc ọhụrụ.
            //

            // Anyị wepụrụ Ref siri ike ikpeazụ, mana enwere ike ịda mba ndị ọzọ esighi ike.
            // Anyị ga-akpali ọdịnaya ka a ọhụrụ Arc, na-abaghị uru na ndị ọzọ na-adịghị ike refs.
            //

            // Rịba ama na ọ gaghị ekwe omume ịgụ nke `weak` iji nye usize::MAX (ya bụ, ekpochi), ebe ọ bụ na ọnụ ọgụgụ na-adịghị ike nwere ike imechi naanị site na eri nwere ntụaka siri ike.
            //
            //

            // Mee ka njirimara nke anyị adịghị ike, nke mere na ọ nwere ike ihicha ArcInner dị ka ọ dị mkpa.
            //
            let _weak = Weak { ptr: this.ptr };

            // Nwere ike zuo data ahụ, naanị ihe fọdụrụ bụ Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Naanị anyị bụ ụdị akwụkwọ ọ bụla;mụta azụ azụ siri ike gụọ agụ.
            //
            this.inner().strong.store(1, Release);
        }

        // Dị ka ọ dị na `get_mut()`, enweghị nchekwa dị mma n'ihi na ntụnye aka anyị bụ nke pụrụ iche ịmalite, ma ọ bụ bụrụ otu na-emechi ọdịnaya.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Weghachite ntụgharị ederede na `Arc` enyere, ma ọ bụrụ na enweghị ụzọ ọzọ `Arc` ma ọ bụ [`Weak`] na otu oke.
    ///
    ///
    /// Weghachite [`None`] ma ọ bụghị, n'ihi na ọ naghị adị mma ịtụgharị uru okekọrịta.
    ///
    /// Hụkwa [`make_mut`][make_mut], nke ga-[`clone`][clone] uru dị n'ime mgbe enwere ntụpọ ndị ọzọ.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Enweghị nchekwa a dị mma n'ihi na anyị ekwela nkwa na pointer laghachiri bụ naanị * pointer a ga-alaghachi na T.
            // E kwuru na ọnụ ọgụgụ anyị ga-abụ 1 ugbu a, anyị chọrọ ka Arc n'onwe ya bụrụ `mut`, yabụ anyị na-eweghachite naanị ntụpọ dị na data dị n'ime.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Weghachite ntụgharị ederede na `Arc` enyere, na-enweghị nyocha ọ bụla.
    ///
    /// Hụkwa [`get_mut`], nke dị nchebe ma na-eme nlele kwesịrị ekwesị.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ihe x00XXXXXXXXXXXXXXXXX ma ọ bụ [`Weak`] ndị ọzọ na-ekenye n'otu nhazi ahụ agaghị edebanye aha maka oge nlọghachi azụ.
    ///
    /// Nke a bụ ihe enweghị isi ma ọ bụrụ na enweghị ụdị ntụpọ ndị a, dịka ọmụmaatụ ozugbo `Arc::new` gasịrị.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Anyị na-akpachapụ anya ka *ghara* mepụta ntụaka na-ekpuchi mpaghara "count", n'ihi na nke a ga-eme ka aha ya nweta ohere ịkọwapụta ọnụ ọgụgụ (eg
        // nke `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Kpebisie ike ma nke a bụ ihe pụrụ iche akwụkwọ (gụnyere adịghị ike refs) na-akpata data.
    ///
    ///
    /// Rịba ama na nke a chọrọ ịkpọchi ọnụ ọgụgụ na-adịghị ike.
    fn is_unique(&mut self) -> bool {
        // igbachi pointer count adịghị ike ma ọ bụrụ na anyị egosi na ọ bụ naanị onye na-ejide ike pointer.
        //
        // Inweta akara ebe a na-eme ka mmekorita tupu mmekọrịta gị na onye ọ bụla na-edegara `strong` (ọkachasị na `Weak::upgrade`) tupu mbelata nke ọnụ ọgụgụ `weak` (site na `Weak::drop`, nke jiri ntọhapụ).
        // Ọ bụrụ na adalata nkwalite adịghị ike dara, CAS ebe a ga-ada ada ka anyị ghara ileghara ịmekọrịta.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Nke a kwesịrị ịbụ `Acquire` iji mekọrịta na mbelata nke `strong` counter na `drop`-naanị nnweta nke na-eme mgbe ọ bụla mana ederede ikpeazụ na-ada.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ntọhapụ edepụtara ebe a na-agakọ na `downgrade`, na-egbochi nke a agụ nke `strong` dị n'elu na-eme mgbe edere ya.
            //
            //
            self.inner().weak.store(1, Release); // hapụ mkpọchi ahụ
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Dobe `Arc`.
    ///
    /// Nke a ga-ebelata ọnụ ọgụgụ siri ike.
    /// Ọ bụrụ na ọnụ ọgụgụ siri ike gụrụ ruru zero mgbe naanị ntụnye ndị ọzọ (ma ọ bụrụ na ọ bụla) bụ [`Weak`], yabụ anyị `drop` uru dị n'ime.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Adighi ebiputa ihe obula
    /// drop(foo2);   // Mbipụta "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Ebe ọ bụ na `fetch_sub` bụ atomiki ugbua, anyị ekwesighi ị mekọrịta na eri ndị ọzọ belụsọ na anyị ga-ehichapụ ihe ahụ.
        // Otu echiche a metụtara `fetch_sub` dị n'okpuru na ọnụọgụ `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Achọrọ ogige a iji gbochie ịhazigharị ojiji nke data na nhichapụ nke data.
        // N'ihi na akara ya `Release`, mbelata nke akara ntụaka na-arụkọ ọrụ na ngere `Acquire` a.
        // Nke a pụtara na iji data eme ihe tupu ibelata ọnụ ọgụgụ, nke na-eme tupu ngere a, nke na-eme tupu nhichapụ data ahụ.
        //
        // Dị ka akọwara na [Boost documentation][1],
        //
        // > Ọ dị mkpa iji mezuo ohere ọ bụla enwere ike ịnweta ihe na otu
        // > eri (site na ederede dị) ka *mee tupu* ehichapụ
        // > ihe di na threadi ozo.Emere nke a site na "release"
        // > ịrụ ọrụ mgbe ị tụpụtụrụ akwụkwọ (ohere ọ bụla na ihe ahụ
        // > site na nke a akwụkwọ ga-doro anya na mere tupu), na ihe
        // > "acquire" ime ihe tupu ihichapu ihe.
        //
        // Karịsịa, ebe ọdịnaya nke Arc anaghị agbanwe agbanwe, ọ ga-ekwe omume inwe ederede dị n'ime Mutex<T>.
        // Ebe ọ bụ na enwetaghị Mutex mgbe ehichapụ ya, anyị enweghị ike ịdabere na mgbakọrịta mmekọrịta ya iji dee ihe na eri A na-ahụ maka mbibi na-agba ọsọ na eri B.
        //
        //
        // Mara kwa na Nweta nsu ebe a nwere ike iji ihe nnweta dochie ya, nke nwere ike melite arụmọrụ na ọnọdụ ndị esiri ike.Hụ [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Gbalịa ịkụda `Arc<dyn Any + Send + Sync>` n'ụdị ihe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Na-ewuli `Weak<T>` ọhụrụ, na-enweghị ekenye ebe nchekwa ọ bụla.
    /// Xkpọ [`upgrade`] na nloghachi uru na-enye [`None`] mgbe niile.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Heldị inyeaka iji nye ohere ịnweta ntụgharị ọnụ na-enweghị ikwu okwu ọ bụla gbasara mpaghara data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Weghachite pointer raw na ihe `T` nke `Weak<T>` a kwuru.
    ///
    /// The pointer bụ nti naanị ma ọ bụrụ na e nwere ụfọdụ siri ike zoro aka.
    /// The pointer nwere ike na-atụgharị, unaligned ma ọ bụ ọbụna [`null`] ma ọ bụghị.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ha abụọ na-arụtụ aka n`otu ihe
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ike ebe a na-eme ka ọ dị ndụ, ya mere anyị ka nwere ike ịnweta ihe ahụ.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ma ọ bụghị ọzọ.
    /// // Anyị nwere ike ime weak.as_ptr(), mana ịnweta pointer ga-eduga na akparaghị ókè omume.
    /// // assert_eq! ("hello", echefughi {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ọ bụrụ na pointer na-agbanye, anyị na-eweghachi onye nche ahụ ozugbo.
            // Nke a enweghị ike ịbụ adreesị nkwụnye ụgwọ dị mma, ebe ọ bụ na nkwụnye ụgwọ dịkarịa ala ka o kwekọrịtara ka ArcInner (usize).
            ptr as *const T
        } else {
            // SAFETY: if is_dangling Return ụgha, mgbe ahụ pointer na-dereferencable.
            // Enwere ike ịkwụsị ụgwọ a n'oge a, anyị ga-enwerịrị ihe ngosi, yabụ jiri njikwa pointer.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Erepịakwa `Weak<T>` na-eme ka ọ ghọọ a raw pointer.
    ///
    /// Nke a na-agbanwe pointer na-esighi ike ka ọ bụrụ onye na-arụ ọrụ dị elu, ma ka na-echekwa ikike nke otu akwụkwọ na-adịghị ike (ọnụ ọgụgụ ndị na-adịghị ike adịghị arụ ọrụ a).
    /// Enwere ike ịgbanye ya na `Weak<T>` ya na [`from_raw`].
    ///
    /// Otu mmachi nke ịnweta ihe mgbaru ọsọ nke pointer dị ka [`as_ptr`] tinye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Na-atụgharị pointer raw raw nke [`into_raw`] mepụtara na `Weak<T>`.
    ///
    /// Enwere ike iji nke a iji nweta ederede siri ike (site na ịkpọ [`upgrade`] mgbe e mesịrị) ma ọ bụ iji dozie ọnụ ọgụgụ na-adịghị ike site na ịhapụ `Weak<T>`.
    ///
    /// Ọ na-ewere ikike nke otu ntụpọ na-adịghị ike (ma e wezụga ntụnye aka nke [`new`] kere, ebe ndị a enweghị nke ọ bụla; usoro a ka na-arụ ọrụ na ha).
    ///
    /// # Safety
    ///
    /// Ihe doro anya ga-esite na [`into_raw`] wee ka nwee akara aka ya na-adịghị ike.
    ///
    /// A na-ahapụ ya ka ọnụọgụ siri ike bụrụ 0 n'oge a na-akpọ nke a.
    /// Ka o sina dị, nke a na-ewe nke otu ntụpọ na-adịghị ike nke ugbu a na-anọchi anya dị ka pointer raw (adịghị ike ọnụ adịghị agbanwe site na ọrụ a) yabụ na a ga-ejikọ ya na oku gara aga na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Mbelata nke ikpeazụ adịghị ike ọnụ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Hụ Weak::as_ptr maka onodu otu esi enweta pointer pointer.

        let ptr = if is_dangling(ptr as *mut T) {
            // Nke a bụ dangling adịghị ike.
            ptr as *mut ArcInner<T>
        } else {
            // Ma ọ bụghị ya, anyị ji n'aka na pointer sitere na adịghị ike adịghị ike.
            // OZI: data_offset dị mma ịkpọ, dịka ptr zoro aka na ezigbo (nke nwere ike ịdaba) T.
            let offset = unsafe { data_offset(ptr) };
            // Yabụ, anyị na-agbanwe ntụpọ iji nweta RcBox niile.
            // EGO: pointer sitere na adịghị ike, yabụ na njedebe a dị mma.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: Ugbu a, anyị enwetaghachila pointer mbụ adịghị ike, yabụ nwere ike ịmepụta ndị na-adịghị ike.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Mgbalị iji kwalite pointer `Weak` na [`Arc`], na-egbu oge ịkwụsị nke uru dị n'ime ma ọ bụrụ na ịga nke ọma.
    ///
    ///
    /// Weghachite [`None`] ma ọ bụrụ na agbanyela uru dị n'ime ya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Bibie ihe niile siri ike.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Anyị na-eji loop CAS iji tinye ọnụ ọgụgụ siri ike karịa fetch_add n'ihi na ọrụ a agaghị ewere ọnụ ọgụgụ ntụgharị site na efu gaa na otu.
        //
        //
        let inner = self.inner()?;

        // Ezumike dị jụụ n'ihi na ihe ọ bụla edere banyere 0 na anyị nwere ike ileba anya na-ahapụ ubi ahụ na steeti efu (yabụ "stale" nke 0 dị mma), yana uru ọ bụla ọzọ gosipụtara site na CAS n'okpuru.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Lee echiche na `Arc::clone` maka ihe kpatara anyị ji eme nke a (maka `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Ezumike dị mma maka ikpe ọdịda n'ihi na anyị enweghị atụmanya ọ bụla gbasara steeti ọhụrụ.
            // Nweta dị mkpa maka ihe ịga nke ọma iji mekọrịta na `Arc::new_cyclic`, mgbe enwere ike ịmalite uru dị n'ime mgbe emechara amaokwu `Weak`.
            // N'okwu ahụ, anyị na-atụ anya ịlele uru mbido zuru oke.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // efu anabataghị n`elu
                Err(old) => n = old,
            }
        }
    }

    /// Alụta ọnụ ọgụgụ nke ike (`Arc`) pointers atụ aka a oke.
    ///
    /// Ọ bụrụ na ejiri [`Weak::new`] kee `self`, nke a ga-alaghachi 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Nweta ihe ruru ọnụọgụ `Weak` na-atụ aka na oke a.
    ///
    /// Ọ bụrụ na ejiri [`Weak::new`] kee `self`, maọbụ ọ bụrụ na enweghị ntụpọ siri ike fọdụrụ, nke a ga-alaghachi 0.
    ///
    /// # Accuracy
    ///
    /// N'ihi nkọwa mmejuputa, uru eleghachitere nwere ike gbanyụọ site na 1 na ụzọ ọ bụla mgbe eri ndị ọzọ na-eme ihe ọ bụla Arc ma ọ bụ `` adịghị ike '' na-atụ aka na oke ahụ.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Ebe ọ bụ na anyị chọpụtara na ọ dịkarịa ala otu onye siri ike mgbe anyị gụsịrị ọnụ ọgụgụ na-adịghị ike, anyị maara na ntụpọ na-adịghị ike (na-egosi mgbe ọ bụla amaokwu siri ike dị ndụ) ka dị mgbe anyị hụrụ ọnụọgụ adịghị ike, ya mere enwere ike iwepu ya n'enweghị nsogbu.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Laghachi `None` mgbe pointer na-atụgharị atụgharị na enweghị `ArcInner` ekenyela, (yabụ, mgbe `Weak` a `Weak` kere).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Anyị na-akpachara anya ka anyị ghara * mepụta ederede na-ekpuchi mpaghara "data", n'ihi na enwere ike ịgbanwe mpaghara ahụ n'otu oge (dịka ọmụmaatụ, ọ bụrụ na a kwụsịrị `Arc` ikpeazụ, a ga-atụba mpaghara data na ebe).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Laghachi `true` ma ọ bụrụ na `` adịghị ike '' abụọ na-arụtụ aka n'otu oke (nke yiri [`ptr::eq`]), ma ọ bụ ọ bụrụ na ha abụọ atụtụghị oke aka ọ bụla (n'ihi na ejiri `Weak::new()`) kee ha.
    ///
    ///
    /// # Notes
    ///
    /// Ebe ọ bụ na nke a na-atụle ntụaka ọ pụtara na `Weak::new()` ga-agbakọrịtara ibe ha, agbanyeghị na ha atụtụghị oke ọ bụla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Na-atụle `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Na-eme ka mmepụta oyiri nke `Weak` pointer na-arụtụ aka n'otu oke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Hụ ihe dị na Arc::clone() maka ihe kpatara nke a ji nọrọ jụụ.
        // Nke a nwere ike iji fetch_add (na-eleghara mkpọchi ahụ) n'ihi na ọnụ ọgụgụ na-adịghị ike na-ekpochi naanị ebe * enweghị akara ngosi na-adịghị ike ọzọ.
        //
        // (Yabụ anyị enweghị ike ịgba koodu a n'ọnọdụ ahụ).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Lee echiche na Arc::clone() maka ihe kpatara anyị ji eme nke a (maka mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Na-ewuli `Weak<T>` ọhụrụ, na-enweghị ekenye ebe nchekwa.
    /// Xkpọ [`upgrade`] na nloghachi uru na-enye [`None`] mgbe niile.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Dobe ihe ngosi `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Adighi ebiputa ihe obula
    /// drop(foo);        // Mbipụta "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ọ bụrụ na anyị achọpụta na anyị bụ ndị ikpeazụ na-adịghị ike pointer, mgbe ahụ, ya oge ka deallocate ndị data kpamkpam.Hụ mkparịta ụka na Arc::drop() banyere usoro nchekwa
        //
        // Ọ dịghị mkpa ịlele maka steeti akpọchiri ebe a, n'ihi na enwere ike ịkpọchi ọnụ ọgụgụ na-adịghị ike ma ọ bụrụ na enwere otu nzaghachi na-adịghị ike, nke pụtara na dobe nwere ike na-esote na-agba ọsọ na ike ahụ fọdụrụ na-adịghị ike, nke nwere ike ịme mgbe emechiri mkpọchi ahụ.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Anyị na-eme ọpụrụiche a ebe a, ọ bụghị dị ka njikarịcha njikarịcha na `&T`, n'ihi na ọ ga-agbakwunye ụgwọ maka nyocha nha anya niile na refs.
/// Anyị na-eche na a na-eji ``Arc` '' echekwa nnukwu ụkpụrụ, nke na-adịghị ngwa oyiri, mana ọ dịkwa arọ iji lelee nha anya, na-eme ka ọnụ ahịa a kwụọ ụgwọ karịa.
///
/// O yikarịrị ka ị ga-enwe clones `Arc` abụọ, nke na-ezo aka n'otu uru ahụ, karịa abụọ&T`s.
///
/// Anyị nwere ike ịme nke a naanị mgbe `T: Eq` dị ka `PartialEq` nwere ike bụrụ ụma ghara agbanwe agbanwe.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Nha anya maka abụọ ``Arc`s.
    ///
    /// Abụọ Arc`s hà nhata ma ọ bụrụ na ụkpụrụ dị n'ime ha hà, ọ bụrụgodi na echekwara ha na oke oke.
    ///
    /// Ọ bụrụ na `T` na-etinyekwa `Eq` (nke na-egosi ntụgharị nha anya), abụọ 'Arc`s na-atụ aka n'otu oke ahụ ha nhata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ahaghị nhata maka abụọ ``Arc`s.
    ///
    /// Abụọ ``Arc`s enweghị aha ma ọ bụrụ na ha n'ime ụkpụrụ na-ahaghị.
    ///
    /// Ọ bụrụ na `T` na-etinyekwa `Eq` (nke na-egosi ntụgharị nha anya), abụọ ``Arc`s na-atụ aka n'otu uru ahụ ahaghị nhata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Nkọwa nke anya maka abụọ ``Arc`s.
    ///
    /// The abụọ na-tụnyere site akpọ `partial_cmp()` na ha n'ime ụkpụrụ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Naa-tụnyere nke abụọ ``Arc`s.
    ///
    /// Ejiri ha abụọ site na ịkpọ `<` na ụkpụrụ ha dị n'ime.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Ihe na-erughị ma ọ bụ hà nhata' maka ntụpọ abụọ 'Arc`s.
    ///
    /// Ejiri ha abụọ site na ịkpọ `<=` na ụkpụrụ ha dị n'ime.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Nkọwa dị ukwuu karịa Arc`s.
    ///
    /// Ejiri ha abụọ site na ịkpọ `>` na ụkpụrụ ha dị n'ime.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Ukwuu karịa ma ọ bụ hara ka' ntụnyere maka 'Arc`s abụọ.
    ///
    /// Ejiri ha abụọ site na ịkpọ `>=` na ụkpụrụ ha dị n'ime.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Tụnyere ihe abụọ ``Arc`s.
    ///
    /// Ejiri ha abụọ site na ịkpọ `cmp()` na ụkpụrụ ha dị n'ime.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Mepụta `Arc<T>` ọhụrụ, yana uru `Default` maka `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Kewapụta mpempe akwụkwọ a na-agụ maka akwụkwọ ma mejupụta ya site na kpụrụ akpụ nke v.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Kewaa `str` edeputara ma detuo `v` n'ime ya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Kewaa `str` edeputara ma detuo `v` n'ime ya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Bugharịa ihe igbe igbe na nke ọhụrụ, nke a na-agụ agụ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Kewaa otu mpempe akwụkwọ a na-agụ ma bufee ihe ndị dị na ya.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Kwe ka Vec hapụ ebe nchekwa ya, mana iwepụtaghị ọdịnaya ya
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Were mmewere nke ọ bụla na `Iterator` wee chịkọta ya n'ime `Arc<[T]>`.
    ///
    /// # Njirimara arụmọrụ
    ///
    /// ## Ikpe izugbe
    ///
    /// Na nchịkọta n'ozuzu, ịnakọta n'ime `Arc<[T]>` ka a na-eme site na ịchịkọta ihe n'ime `Vec<T>`.Nke ahụ bụ, mgbe ị na-ede ihe ndị a:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// nke a na-akpa agwa dịka anyị dere, sị:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ntọala izizi izizi na-eme ebe a.
    ///     .into(); // Nkeji nke abụọ maka `Arc<[T]>` na-eme ebe a.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Nke a ga-ekenye ugboro ole achọrọ maka iwu `Vec<T>` ma ọ ga-ekenye otu oge maka ịtụgharị `Vec<T>` na `Arc<[T]>`.
    ///
    ///
    /// ## Iterators nke mara ogologo
    ///
    /// Mgbe `Iterator` gị na-etinye `TrustedLen` n'ọrụ ma nwee nha ọ bụla, a ga-eme otu oke maka `Arc<[T]>`.Ọmụmaatụ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Naanị otu oke na-eme ebe a.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialization trait ejiri maka ịnakọta n'ime `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Nke a bụ ikpe maka `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Anyi kwesiri igba mbo hu na onye na-ese okwu nwere ogologo ya na anyi.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Daghachi na mmejuputa iwu nkịtị.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Nweta mmebi n'ime `ArcInner` maka ịkwụ ụgwọ n'azụ pointer.
///
/// # Safety
///
/// Nkọwa ga-arụtụ aka (ma nwee ezigbo metadata maka) ihe atụ izizi nke T, mana T na-ahapụ ka ahapụ ya.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Dezie uru a na-erughị na njedebe nke ArcInner.
    // N'ihi na RcBox bụ repr(C), ọ ga-abụ ubi ikpeazụ na ebe nchekwa.
    // SAFETY: ebe ọ bụ naanị ụdị dị iche iche ga-ekwe omume bụ Mpekere, ihe trait,
    // na ụdị mpụga, ihe nchekwa nchekwa chọrọ dị ugbu a iji mejuo ihe ndị achọrọ align_of_val_raw;nke a bụ nkọwa nke mmejuputa asụsụ nke enweghị ike ịdabere na mpụga std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}