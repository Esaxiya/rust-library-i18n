//! Akụrụngwa maka nhazi na ibipụta ``String`s.
//!
//! Modul a nwere nkwado oge ojiri maka ndọtị njikọ [`format!`].
//! A na-etinye macro a na compiler iji kpọpụta oku na usoro a iji hazie arụmụka n'oge oge n'ime eriri.
//!
//! # Usage
//!
//! Ejiri [`format!`] macro mara ndị na-abịa site na ọrụ C's `printf`/`fprintf` ma ọ bụ ọrụ Python's `str.format`.
//!
//! Fọdụ ihe atụ nke mgbatị [`format!`] bụ:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" na-eduga efu
//! ```
//!
//! Site na ndị a, ị ga-ahụ na esemokwu izizi bụ eriri usoro.Achọrọ ya site na nchịkọta ya maka nke a ka ọ bụrụ eriri nkịtị;ọ nwere ike ọ gaghị agbanwe agbanwe gafere (iji rụọ ọrụ nyocha).
//! Onye nchịkọta ahụ ga-emezi usoro eriri ahụ wee chọpụta ma ndepụta nke arụmụka ekwesịrị iji nyefee usoro a.
//!
//! Iji gbanwee otu uru na eriri, jiri usoro [`to_string`].Nke a ga-eji [`Display`] ịhazi trait.
//!
//! ## Ọnọdụ ọnọdụ
//!
//! A na-ahapụ arụmụka usoro nhazi ọ bụla ịkọwapụta esemokwu bara uru ọ na-ezo aka, ma ọ bụrụ na-ahapụ ya, ọ ga-abụ "the next argument".
//! Dịka ọmụmaatụ, eriri `{} {} {}` ga-ewere usoro atọ, a ga-ahazi ha n'otu usoro ahụ enyere ha.
//! Usoro nhazi `{2} {1} {0}`, ga-ahazi arụmụka iji gbanwee usoro.
//!
//! Ihe nwere ike ịdị ntakịrị ntakịrị ozugbo ịmalite ịmekọrịta ụdị nkọwa abụọ nke ọnọdụ.The "next argument" specifier nwere ike chere na nke dị ka ihe iterator n'elu okwu.
//! Oge obula ahuru onye nyocha "next argument", onye edemede a n`iru.Nke a na-eduga n'omume dị ka nke a:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Ntughari ederede n'ime esemokwu ahụ enwebeghị ọganihu site na oge mbụ `{}` hụrụ, yabụ ọ na-ebipụta esemokwu mbụ.Mgbe ahụ ruru `{}` nke abụọ, onye na-ede akwụkwọ ahụ agafeela na esemokwu nke abụọ.
//! N'ikpeazụ, akụkụ ndị na-akpọ aha arụmụka ha aha adịghị emetụta ọnụọgụ ndị na-anaghị akpọ esemokwu na usoro nke nkọwapụta ọkwa.
//!
//! Achọrọ usoro iji jiri arụmụka ya niile, ma ọ bụghị ya, ọ bụ mkpokọta oge.Nwere ike zoo aka n'otu esemokwu ahụ karịa otu mgbe na usoro eriri.
//!
//! ## Ejiri mpaghara
//!
//! Rust n'onwe ya enweghị Python dị ka nke aha aha ya na ọrụ, mana [`format!`] macro bụ ntinye mgbakwunye nke na-enye ya ohere itinye aha ya aha ya.
//! Edere akụkụ akpọrọ aha na njedebe nke ndepụta esemokwu ma nwee syntax ahụ:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Dịka ọmụmaatụ, okwu [`format!`] ndị na-esonụ na-eji arụmụka akpọrọ:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ọ baghị uru itinye ọnọdụ ọnọdụ (ndị na-enweghị aha) mgbe arụmụka nwere aha.Dị ka ọkwá njigide ọnọdụ ya, ọ baghị uru ịnye ntọala aha ya bụ nke anaghị eji eriri eriri.
//!
//! # Nhazi usoro
//!
//! Enwere ike gbanwee esemokwu ọ bụla ka edepụtara site na ọtụtụ usoro nhazi (nke kwekọrọ na `format_spec` na [the syntax](#syntax)). Ntọala ndị a na-emetụta akara ngosi eriri nke ihe a na-emezi.
//!
//! ## Width
//!
//! ```
//! // Ihe mbipụta a niile "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Nke a bụ oke maka "minimum width" nke usoro ga-ewere.
//! Ọ bụrụ na eriri ọnụọgụ anaghị ejupụta ọtụtụ mkpụrụedemede a, mgbe ahụ, padding nke fill/alignment kwuru ga-eji ohere dị mkpa (lee anya n'okpuru).
//!
//! Enwere ike ịnye uru maka obosara ahụ dị ka [`usize`] na ndepụta nke oke site na ịgbakwunye `$` postfix, na-egosi na esemokwu nke abụọ bụ [`usize`] na-akọwa obosara.
//!
//! Na-ezo aka n'arụmụka na syntax dollar anaghị emetụta ọnụọgụ "next argument", yabụ ọ bụ ihe dị mma iji zoo arụmụka site n'ọkwá, ma ọ bụ jiri arụmụka akpọrọ aha.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! A na-enye njirimara juputara na nhazi na nhazi na [`width`](#width) oke.A ghaghị ịkọwa ya tupu `width`, ozugbo `:` gasịrị.
//! Nke a na-egosi na ọ bụrụ na uru ahaziri ahazi dị obere karịa `width`, a ga-ebipụta mkpụrụedemede ndị ọzọ gburugburu ya.
//! Na-ejuputa na-abịa n'ụdị dị iche iche dị iche iche:
//!
//! * `[fill]<` - A na-ekpezi esemokwu ahụ na kọlụm `width`
//! * `[fill]^` - arụmụka ahụ dị n'etiti etiti na `width` ogidi
//! * `[fill]>` - arụmụka ahụ dabara na ogidi `width`
//!
//! Ndabara [fill/alignment](#fillalignment) maka ọnụọgụ ọnụọgụ abụghị oghere ma kwekọọ na aka ekpe.Ndabara maka ọnụọgụ ọnụọgụ bụkwa oghere gbasara oghere mana njigide aka nri.
//! Ọ bụrụ na akọwapụtara ọkọlọtọ `0` (lee anya n'okpuru) maka akara ọnụọgụ, mgbe ahụ njirimara njirimara zuru ezu bụ `0`.
//!
//! Rịba ama na nhazi nwere ike ọ gaghị arụ ọrụ site n'ụdị ụfọdụ.Karịsịa, anaghị etinye ya n'ozuzu maka `Debug` trait.
//! Goodzọ dị mma iji hụ na etinye padding bụ ịhazi ntinye gị, wee kpoo eriri a na-akpata iji nweta mmepụta gị:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Ndewo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ndị a niile bụ ọkọlọtọ na-agbanwe omume nke nhazi.
//!
//! * `+` - Emere nke a maka ụdị ọnụọgụ ma gosipụta na a ga-ebipụta ihe ịrịba ama ahụ mgbe niile.A naghị ebipụta akara ngosi dị mma site na ndabara, na akara ngosi na-ezighi ezi bụ nke ndabara maka `Signed` trait.
//! Ọkọlọtọ a na-egosi na akara ngosi ziri ezi (`+` ma ọ bụ `-`) ga-ebipụta mgbe niile.
//! * `-` - Ugbu a anaghị eji
//! * `#` - Ọkọlọtọ a na-egosi na ụdị mbipụta "alternate" kwesịrị iji.Formsdị ndị ọzọ bụ:
//!     * `#?` - mara mma-bipụta [`Debug`] nhazi
//!     * `#x` - eburu esemokwu na `0x`
//!     * `#X` - eburu esemokwu na `0x`
//!     * `#b` - eburu esemokwu na `0b`
//!     * `#o` - eburu esemokwu na `0o`
//! * `0` - A na-eji nke a iji gosi maka usoro ntinye aha na ihe ntinye na `width` kwesiri ka eme ya na agwa `0` yana ịmara-ama.
//! Usoro dị ka `{:08}` ga-enye `00000001` maka `1` ntanetị, ebe otu usoro ahụ ga-enye `-0000001` maka ihe ntanetị `-1`.
//! Rịba ama na nsụgharị na-adịghị mma nwere obere ole na ole karịa nke dị mma.
//!         Rịba ama na a na-etinye efu efu mgbe ihe ịrịba ama (ma ọ bụrụ na ọ bụla) na n'ihu ọnụọgụ.Mgbe e jikọtara ya na ọkọlọtọ `#`, iwu yiri nke a metụtara: a na-etinye zeros na-ekpuchi mgbe prefix ma tupu ọnụọgụ.
//!         A gụnyere prefix ahụ n`obosara niile.
//!
//! ## Precision
//!
//! Maka ụdị na-abụghị ọnụọgụ, enwere ike iwere nke a dị ka "maximum width".
//! Ọ bụrụ na eriri na-akpata dị ogologo karịa obosara a, mgbe ahụ, a ga-egbutu ya na ọtụtụ mkpụrụedemede a ma jiri `fill`, `alignment` na `width` kwesịrị ekwesị ma ọ bụrụ na etinyere usoro ndị ahụ.
//!
//! Maka ụdị dị iche iche, a na-eleghara nke a anya.
//!
//! Maka ụdị mmiri na-ese n'elu mmiri, nke a na-egosi ọnụọgụ ole mgbe akara ntụpọ kwesịrị ibipụta.
//!
//! Enwere ụzọ atọ dị mkpa iji kọwaa ihe `precision` achọrọ:
//!
//! 1. Ihe `.N` integer:
//!
//!    integer `N` n'onwe ya bu nkenke.
//!
//! 2. Ihe integer ma obu aha tinyere akara dollar `.N$`:
//!
//!    jiri usoro *arụmụka*`N` (nke ga-abụ `usize`) dị ka nkenke.
//!
//! 3. Akara mmuke `.*`:
//!
//!    `.*` pụtara na `{...}` a jikọtara ya na ntinye ntinye * * abụọ karịa otu: ntinye mbu na-ejide `usize` nkenke, nke abụọ jide uru ibipụta.
//!    Rịba ama na n'okwu a, ọ bụrụ na mmadụ ejiri eriri `{<arg>:<spec>.*}` usoro, mgbe ahụ akụkụ `<arg>` na-ezo aka* uru * iji bipụta, na `precision` ga-abata na ntinye bu ụzọ `<arg>`.
//!
//! Dịka ọmụmaatụ, oku ndị a niile na-ebipụta otu ihe ahụ `Hello x is 0.01000`:
//!
//! ```
//! // Ndewo {arg 0 ("x")} bụ {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Ndewo {arg 1 ("x")} bụ {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Ndewo {arg 0 ("x")} bụ {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Ndewo {next arg ("x")} bụ {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} bụ {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Ndewo {next arg ("x")} bụ {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Mgbe ndị a:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! bipụta ihe atọ dị iche iche:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! N'asụsụ ụfọdụ mmemme, akparamagwa nke ịkpụzi eriri na-adabere na ntọala mpaghara sistemụ.
//! Ọrụ usoro nke ọbá akwụkwọ ọkọlọtọ Rust nyere enweghị echiche ọ bụla nke mpaghara ma rụpụta otu nsonaazụ na sistemụ niile n'agbanyeghị agbanye ọrụ nhazi.
//!
//! Dịka ọmụmaatụ, koodu na-esonụ ga-ebipụta `1.5` mgbe niile ọbụlagodi na mpaghara mpaghara na-eji akara ngosi ntụpọ ndị ọzọ karịa ntụpọ.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! A na-etinye ihe odide nkịtị `{` na `}` na eriri site na iji otu agwa ahụ bu ha ụzọ.Dịka ọmụmaatụ, agwa `{` gbanahụrụ `{{` na agwa `}` gbanahụrụ `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Ichikota, ebe a i nwere ike ichota ụtọ asụsụ zuru oke nke usoro ndido urụk.
//! A na-esite n'asụsụ ndị ọzọ edepụta syntaks maka asụsụ formatting nke a, yabụ na ọ gaghị abụ onye ọbịa.Ejiri esemokwu na-eji arụmụka Python arụ ụka, nke pụtara na esemokwu gbara `{}` gburugburu karịa C-dị ka `%`.
//! Asụsụ ụtọ asụsụ maka ịhazi usoro bụ:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Na ụtọ asụsụ dị n`elu, `text` nwere ike ọ gaghị enwe mkpụrụedemede `'{'` ma ọ bụ `'}'`.
//!
//! # Mathazi traits
//!
//! Mgbe ị na-arịọ ka esemokwu rụọ ọrụ na otu ụdị, ị na-arịọ n'ezie ka esemokwu dabere na otu trait.
//! Nke a na-enye ọtụtụ ụdị ụdị aka ịhazi ya site na `{:x}` (dika [`i8`] yana [`isize`]).Ihe osise dị ugbu a nke ụdị na traits bụ:
//!
//! * *ọ dịghị ihe* ⇒ [`Display`]
//! * `?` [`Debug`]
//! * `x?` ⇒ [`Debug`] na obere-hexadecimal ọnụ ọgụgụ
//! * `X?` ⇒ [`Debug`] na onu ogugu hexadecimal di elu
//! * `o` [`Octal`]
//! * `x` [`LowerHex`]
//! * `X` [`UpperHex`]
//! * `p` [`Pointer`]
//! * `b` [`Binary`]
//! * `e` [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ihe nke a pụtara bụ na ụdị esemokwu ọ bụla nke na-etinye [`fmt::Binary`][`Binary`] trait ahụ nwere ike ịhazi ya na `{:b}`.A na-etinye usoro ntinye maka traits ndị a maka ọtụtụ ụdị oge ochie site n'ọbá akwụkwọ ọkọlọtọ.
//!
//! Ọ bụrụ na enweghị usoro akọwapụtara (dịka na `{}` ma ọ bụ `{:6}`), mgbe ahụ usoro trait ejiri bụ [`Display`] trait.
//!
//! Mgbe ị na-etinye usoro trait maka ụdị nke gị, ị ga-etinye usoro mbinye aka:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // anyị omenala ụdị
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! A ga-ebufe ụdị gị dị ka `self` site na ntinye aka, wee rụọ ọrụ ahụ kwesịrị ịpupụta npụta na iyi `f.buf`.Ọ dị n'ụdị usoro trait nke ọ bụla iji rube isi n'ụzọ ziri ezi na usoro nhazi usoro achọrọ.
//! A ga-edepụta ụkpụrụ nke ihe ndị a na mpaghara nke [`Formatter`].Iji nyere aka na nke a, [`Formatter`] struct na-enyekwa ụfọdụ ụzọ inyeaka.
//!
//! Ọzọkwa, uru nloghachi nke ọrụ a bụ [`fmt::Result`] nke bụ ụdị aha nke ``Result`] '' <(), ``(`` std: : fmt::Error`] ''>``.
//! Nhazi mmemme kwesịrị ijide n'aka na ha na-agbasa njehie site na [`Formatter`] (dịka, mgbe ị na-akpọ [`write!`]).
//! Agbanyeghị, ha ekwesịghị iweghachi mmejọ n'amaghị ama.
//! Nke ahụ bụ, ntinye nhazi ga-enwe ike weghachite njehie ma ọ bụrụ na [`Formatter`] gafere ga-eweghachi njehie.
//! Nke a bụ n'ihi na, megidere ihe mbinye aka ọrụ nwere ike ịtụ, usoro ịdepụta eriri bụ ọrụ na-adịghị agha agha.
//! Ọrụ a na-eweghachitere nsonaazụ n'ihi na idere mmiri iyi ahụ nwere ike ịda ma ọ gha inye ụzọ isi gbasaa eziokwu ahụ na njehie emeela na nchịkọta ahụ.
//!
//! Otu ihe atụ nke mmejuputa usoro formatting traits ga-adị ka:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` uru na-etinye `Write` trait n'ọrụ, nke bụ ihe dee!nnukwu na-atụ anya.
//!         // Rịba ama na nhazi a na-eleghara ọkọlọtọ dị iche iche enyere iji dezie ụdọ.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits dị iche iche na-enye ụdị ụdị mmepụta nke ụdị.
//! // Ihe usoro a pụtara bụ ibipụta ịdị ukwuu nke vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Na-asọpụrụ ọkọlọtọ nhazi site na iji usoro inyeaka `pad_integral` na ihe Formatter.
//!         // Hụ akwụkwọ usoro maka nkọwa, na ọrụ `pad` enwere ike iji ya kpaa ụdọ.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Usoro traits abụọ a nwere ebumnuche dị iche:
//!
//! - [`fmt::Display`][`Display`] mmejuputa iwu na-ekwusi ike na udiri ihe a nwere ike iji ikwesị ntụkwasị obi gosipụta dị ka eriri UTF-8 n'oge niile.Ọ bụ **adịghị** tụrụ anya na ụdị niile mejuputa [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] mmejuputa iwu kwesiri itinye aka maka **niile** ụdị oha.
//!   Mmepụta ga-a na-anọchi anya esịtidem ala dị ka ikwesị ntụkwasị obi dị ka o kwere.
//!   Ebumnuche nke [`Debug`] trait bụ iji kwado mbupu koodu Rust.Ọtụtụ oge, iji `#[derive(Debug)]` ezuola ma kwado ya.
//!
//! Ihe omuma atu nke mmeputa sitere na traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # njikọ macros
//!
//! Enwere otutu macros metụtara na ezinụlọ [`format!`].Ndị nke etinyere ugbu a bụ:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Nke a na [`writeln!`] bụ macros abụọ ejiri rụọ ọrụ iji wepụta usoro nhazi na iyi akọwapụtara.A na-eji nke a iji gbochie oke oke nke usoro ụdọ na kama ozugbo dee mmepụta.
//! N'okpuru mkpuchi, ọrụ a na-akpọku [`write_fmt`] ọrụ akọwapụtara na [`std::io::Write`] trait.
//! Ihe Nlereanya bụ:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Nke a na [`println!`] na-ewepụta ihe ha rụpụtara na stdout.N'otu aka ahụ na nnukwu [`write!`], ebumnuche nke nnukwu ihe ndị a bụ iji zere oke etiti mgbe ị na-ebipụta akwụkwọ.Ihe Nlereanya bụ:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Mkpokọta [`eprint!`] na [`eprintln!`] yiri [`print!`] na [`println!`] n'otu n'otu, belụsọ na ha wepụtara ihe ha rụpụtara na stderr.
//!
//! ### `format_args!`
//!
//! Nke a bụ nnukwu macro eji agabiga ihe opaque na-akọwa usoro eriri.Ihe a achoghi oke ikpo ihe iji meputa, ya na zoo aka na nkowa.
//! N'okpuru mkpuchi, a na-etinye macros metụtara ya na usoro nke a.
//! Akpa, ụfọdụ ihe eji eme ihe bụ:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Nsonaazụ nke [`format_args!`] nnukwu bụ uru nke ụdị [`fmt::Arguments`].
//! Enwere ike ịfefe usoro a na ọrụ [`write`] na [`format`] n'ime usoro a iji hazie usoro nhazi.
//! Ebumnuche nke nnukwu ihe a bụ iji gbochie oke inyefe ego mgbe ị na-emeso usoro ịhazi.
//!
//! Dịka ọmụmaatụ, ọbá akwụkwọ na-egbu osisi nwere ike iji syntax ọkọlọtọ ọkọlọtọ, mana ọ ga-agafe n'ime usoro a ruo mgbe ekpebiri ebe nrụpụta ga-aga.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Ọrụ `format` na-ewe ihe [`Arguments`] ma weghachite eriri edepụtara.
///
///
/// Enwere ike iji [`format_args!`] nnukwu mee ihe atụ [`Arguments`].
///
/// # Examples
///
/// Njiji ojiji:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Biko mara na iji [`format!`] nwere ike ịka mma.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}