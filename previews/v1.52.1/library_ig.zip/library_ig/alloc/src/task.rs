#![stable(feature = "wake_trait", since = "1.51.0")]
//! Pesdị na Traits maka ịrụ ọrụ na ọrụ asynchronous.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Mmejuputa nke aza ọrụ na onye na-eme ihe.
///
/// Enwere ike iji trait a mepụta [`Waker`].
/// Onye na-eme ihe nwere ike kọwaa mmejuputa nke trait a, ma jiri ya rụọ Waker ka ọ gabiga ọrụ ndị a na-egbu onye ahụ.
///
/// trait a bụ ihe nchekwa nchekwa na ergonomic ọzọ iji wuo [`RawWaker`].
/// Ọ na-akwado ndị na-eme ihe eji eme ihe na-eme nke data ejiri eteta ọrụ na-echekwa na [`Arc`].
/// Fọdụ ndị na-eme ihe (ọkachasị ndị maka sistemụ agbakwunyere) enweghị ike iji API a, ọ bụ ya mere [`RawWaker`] ji dị ka ihe ọzọ maka sistemụ ndị ahụ.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Ọrụ `block_on` bụ isi nke na-ewere future ma na-agba ya ka ọ gwụchaa na eriri dị ugbu a.
///
/// **Note:** Ihe atụ a na-eme ka ọ dị mfe.
/// Iji gbochie mmechi mmechi, mmejuputa atumatu nke imeputa ihe gha achokwa ijikwa oku di n'etiti na `thread::unpark` tinyere nkpu.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Onye na-eteta ụra na-akpọte eriri nke ugbu a mgbe akpọrọ ya.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Gbaa future ka emecha ya na eriri dị ugbu a.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Choo future ka o wee nwee ike iju ya anya.
///     let mut fut = Box::pin(fut);
///
///     // Mepụta ihe omuma ohuru iji nyefee ya na future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Gbaa future na mmecha.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Bilie ọrụ a.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Weta ọrụ a na-eripịaghị onye edemede.
    ///
    /// Ọ bụrụ na onye na-eme ihe na-akwado ụzọ dị ọnụ ala karịa ịmụrụ anya na-eripughi onye na-eteta ụra, o kwesịrị ịgabiga usoro a.
    /// Site na ndabara, ọ na-akpọ [`Arc`] ma na-akpọ [`wake`] na mmepụta oyiri.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SAFETY: Nke a di nchebe n'ihi na raw_waker na-arụ ọfụma
        // a RawWaker si Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: A na-eji ọrụ nzuzo a maka iwu RawWaker, karịa
// na-etinye nke a n'ime `From<Arc<W>> for RawWaker` impl, iji hụ na nchekwa nke `From<Arc<W>> for Waker` anaghị adabere na izipu trait ziri ezi, kama ha abụọ na-akpọ ọrụ a ozugbo na n'ụzọ doro anya.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Increbawanye ọnụ ọgụgụ nke arc iji mepụta ya.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Teta site na uru, na-ebugharị Arc n'ime ọrụ Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Teta na ndetu, kechie onye na-eme mkpọtụ na ManuallyDrop iji zere idobe ya
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Mbelata ọnụ ọgụgụ nke Arc na dobe
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}