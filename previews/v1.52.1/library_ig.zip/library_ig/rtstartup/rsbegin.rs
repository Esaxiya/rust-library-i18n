// rsbegin.o na rsend.o bụ ndị a na-akpọ "compiler runtime startup objects".
// Ha na-ebu koodu mkpa n'ụzọ ziri ezi initialize na compiler Oge ojiri gaa.
//
// Mgbe ihe executable ma ọ bụ dylib image na-jikọrọ, niile ọrụ koodu na ọba akwụkwọ bụ "sandwiched" n'etiti abụọ ndị a ihe faịlụ, otú koodu ma ọ bụ data site na rsbegin.o ndị mbụ na nwoke ngalaba nke image, ebe koodu na data si rsend.o bụrụ ndị ikpeazụ ga.
// Enwere ike iji mmetụta a tinye akara na mbido ma ọ bụ na njedebe nke ngalaba, yana ịtinye isi ọ bụla ma ọ bụ ụkwụ ọ bụla achọrọ.
//
// Rịba ama na isi ntinye ntinye nke dị na ihe mmalite mmalite nke C (nke a na-akpọ `crtX.o`), nke na-akpọ oku mbido mbido nke ihe ndị ọzọ na-agba ọsọ (edebanye aha site na mpaghara ọzọ oyiyi pụrụ iche).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marks mmalite nke tojupụtara etiti tụsaratụ ngalaba ngalaba
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Kọ ohere maka unwinder si esịtidem akwụkwọ-Idebe.
    // A kọwara nke a dị ka `struct object` na $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Mepee usoro ihe omume registration/deregistration.
    // Hụ akwụkwọ nke libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // denye aha ihe omuma na nbido modul
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // edebanye aha na nkwụsị
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-init/uninit aha kpọmkwem na ndebanye aha
    pub mod mingw_init {
        // Ihe mmalite nke MinGW (crt0.o/dllcrt0.o) ga-akpọ ndị nrụpụta ụwa na ngalaba .ctors na .dtors na mbido na ụzọ ọpụpụ.
        // N'ihe gbasara DLL, a na-eme nke a mgbe eburu DLL ma budata ya.
        //
        // Njikọ ahụ ga-edozi ngalaba ahụ, nke na-eme ka o doo anya na oku anyị na-akpọ na njedebe nke ndepụta ahụ.
        // Ebe ọ bụ na constructors na-agba ọsọ na agbara iji, nke a ana achi achi na anyị callbacks bụ ndị mbụ na ndị ikpeazụ gburu.
        //
        //

        #[link_section = ".ctors.65535"] // Ndị na-eme ihe nkiri. *: C mmalite oku
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C ịkwụsị oku
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}