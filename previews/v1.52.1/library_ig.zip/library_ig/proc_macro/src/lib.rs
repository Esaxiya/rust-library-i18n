//! Ọbá akwụkwọ nkwado maka ndị ode akwụkwọ macro mgbe ị na-akọwa macros ọhụrụ.
//!
//! Nke a Ọbá akwụkwọ, nyere site ọkọlọtọ nkesa, na-enye ụdị iwesa ke ihu nke procedurally kọwaa nnukwu nkọwa ndị dị otú ahụ dị ka ọrụ-dị ka macros `#[proc_macro]`, nnukwu àgwà `#[proc_macro_attribute]` na omenala na-erite attributes`#[proc_macro_derive] '.
//!
//!
//! Hụ [the book] maka ndị ọzọ.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Na-ekpebi ma e meela proc_macro maka mmemme a na-aga ugbu a.
///
/// The proc_macro crate bụ nanị maka iji n'ime mmejuputa iwu macros.All ọrụ a na crate panic ma ọ bụrụ na kpọkuru si n'èzí nke a usoro nnukwu, dị ka site na a Mee script ma ọ bụ unit ule ma ọ bụ nkịtị Rust ọnụọgụ abụọ.
///
/// Na echiche Rust ọba akwụkwọ na-iji na-akwado ma na nnukwu na-abụghị nnukwu ojiji mgbe, `proc_macro::is_available()` enye a na-abụghị panicking ụzọ chọpụta ma akụrụngwa chọrọ iji API nke proc_macro ugbu dị.
/// Alaghachi ezi ma ọ bụrụ na kpọkuru si n'ime nke a usoro nnukwu, ụgha ma ọ bụrụ na kpọkuru ọ bụla ọzọ ọnụọgụ abụọ.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Typedị isi nke crate a na-enye, na-anọchi anya mmiri iyi nke tokens, ma ọ bụ, karịa kpọmkwem, usoro nke osisi token.
/// Dị ahụ na-enye ohere maka ịgbagharị n'elu osisi token ndị ahụ na, ọzọ, na-achịkọta ọtụtụ osisi token n'otu iyi.
///
///
/// Nke a bụ ntinye na ntinye nke nkọwapụta `#[proc_macro]`, `#[proc_macro_attribute]` na `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Njehie si na `TokenStream::from_str` laghachi.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Alaghachi ihe efu `TokenStream` nwere dịghị token osisi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Akwụkwọ ndọrọ ego ma ọ bụrụ na a `TokenStream` bụ ihe efu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Mgbalị agbaji eriri n'ime tokens na parse ndị tokens n'ime a token iyi.
/// Ka ida maka a ọtụtụ ihe, n'ihi na ihe atụ, ọ bụrụ na eriri nwere ekwesịghị delimiters ma ọ bụ na-agụ akụkọ na-ẹdude na asụsụ.
///
/// All tokens na mmiri iyi na-enweta `Span::call_site()` spans.
///
/// NOTE: ụfọdụ njehie nwere ike ibute panics kama ịlaghachi `LexError`.Anyị debere ikike ịgbanwe njehie ndị a n'ime ``LexError`s ka emechara.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, mmiri ahụ na-enye `to_string` naanị, mejuputa `fmt::Display` dabere na ya (ntụgharị nke mmekọrịta na-adịbu n'etiti abụọ ahụ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Mbipụta na token iyi dị ka a eriri na kwesịrị ịbụ losslessly kọnvatịbụl azụ n'ime otu token stream (modulo jikọrọ abụọ abụọ), ma e wezụga n'ihi ikekwe 'TokenTree: : Group`s na `Delimiter::None` delimiters na-adịghị mma ọnụọgụ literals.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Mbipụta token n'ụdị adaba maka nbugharị.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Emepụta mmiri token nwere otu osisi token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Na-anakọta ọtụtụ osisi token n'otu iyi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Ọrụ "flattening" na iyi token, na-achịkọta osisi token site n'ọtụtụ iyi token n'otu iyi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Jiri ntinye kachasị nke ọma if/when enwere ike.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Public mmejuputa iwu nkọwa maka `TokenStream` ụdị, dị ka iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// An iterator n'elu 'TokenStream`si' TokenTree`s.
    /// Ntughari a bu "shallow", dika, onye ochicho a naghi aloghachi n`ime uzo ndi akasiri ike, ma weghachi otu nile dika osisi token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` na-anabata tokens na-enweghị isi ma gbasaa n'ime `TokenStream` na-akọwa ntinye.
/// Iji maa atụ, `quote!(a + b)` ga-ewepụta okwu, na, mgbe enyochachara, wuru `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// A na-emepu imebi na `$`, wee rụọ ọrụ site na iji otu njirimara na-esote dị ka okwu enweghị atụ.
/// Iji kwuo `$` n'onwe ya, jiri `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// A n'ógbè iyi koodu, tinyere nnukwu mgbasa ozi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Emepụta ọhụrụ `Diagnostic` na nyere `message` na ihe ji `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// A na-adịru na ekwurịta na nnukwu definition saịtị.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Ogologo nke ịrịọ arịrịọ nke nnukwu usoro dị ugbu a.
    /// A ga-edozi ndị na-achọpụta ihe ejiri oge a dị ka a ga-asị na edere ha ozugbo na ọnọdụ oku oku (ịdị ọcha na saịtị) na koodu ndị ọzọ na saịtị oku nnukwu ga-enwe ike ịkọwa ha.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// A na-adịru na-anọchite anya `macro_rules` ọcha, na mgbe ụfọdụ ekwurịta na nnukwu definition saịtị (obodo variables, kpọọ, `$crate`) na mgbe ụfọdụ na nnukwu oku na saịtị (ihe ọ bụla ọzọ).
    ///
    /// A na-agbatị ọnọdụ ọnọdụ site na saịtị oku.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Ihe mbụ faịlụ isi na nke a na-atụ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` maka tokens na mkpokọta nnukwu macro nke sitere na `self` sitere, ma ọ bụrụ na ọ bụla.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// The na-adịru maka mbido iyi koodu na `self` e site si.
    /// Ọ bụrụ na nke a `Span` e site si ọzọ nnukwu expansions mgbe nloghachi uru bụ otu ihe ahụ dị ka `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Nweta line/column na faịlụ isi maka oge a.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Nweta line/column ngwụcha na isi iyi faịlụ maka oge a.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Emepụta ọhụrụ na-adịru asị `self` na `other`.
    ///
    /// Alaghachi `None` ma ọ bụrụ na `self` na `other` si dị iche iche faịlụ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Emepụta ọhụrụ na-adịru na otu line/column ọmụma dị ka `self` ma na ekwurịta akara dị ka asị na ọ bụ na `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Emepụta ọhụrụ na-adịru na otu aha mkpebi omume dị ka `self` ma na line/column ọmụma nke `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Jiri ya tụnyere oge iji hụ ma ha hà.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Alaghachi isi iyi ederede n'azụ a na-adịru.
    /// Nke a na-echekwa koodu nke mbụ, gụnyere oghere na nkọwa.
    /// Ọ na-alaghachi a ma ọ bụrụ na ndị na-adịru kwekọrọ n'ezie iyi koodu.
    ///
    /// Note: Nsonaazụ a na-ahụ anya nke nnukwu ga-adabere na tokens ọ bụghị na ederede isi mmalite a.
    ///
    /// Nsonaazụ nke ọrụ a bụ mbọ kachasị mma iji naanị maka nyocha.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Mbipụta a na-adịru na a ụdị adaba n'ihi debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Otu eriri kọlụm na-anọchite mmalite ma ọ bụ njedebe nke `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Usoro 1-edepụtara na faịlụ isi iyi nke oge na-amalite ma ọ bụ mechie (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Ogidi 0-indexed (na UTF-8 odide) na isi iyi faịlụ nke oge ahụ na-amalite ma ọ bụ mechie (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Isi faịlụ nke `Span` nyere.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ọkọkpọhi ụzọ isi iyi a file.
    ///
    /// ### Note
    /// Ọ bụrụ na ọnụọgụ koodu ejiri na `SourceFile` a mepụtara site na mpụga nnukwu, macro a, nke a nwere ike ọ gaghị abụ ezigbo ụzọ na sistemụ faịlụ.
    /// Jiri [`is_real`] iji lelee.
    ///
    /// Rịba ama na ọbụlagodi na `is_real` laghachiri `true`, ọ bụrụ na agafefere `--remap-path-prefix` na ahịrị iwu ahụ, ụzọ enyere dị ka ọ nwere ike ọ gaghị adị ire.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Alaghachi `true` ma ọ bụrụ na isi iyi a file bụ ezigbo isi iyi faịlụ, na bụghị site na mpụga nnukwu si mgbasa.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Nke a bụ a hack ruo mgbe intercrate jikọrọ abụọ abụọ na-emejuputa atumatu na anyị nwere ike isi iyi bụ faịlụ maka jikọrọ abụọ abụọ site na mpụga macros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// A otu token ma ọ bụ a delimited usoro nke token osisi (eg, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Iyi token gbara ndị delimiter gburugburu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// An nchọpụta.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Otu njirimara akara (`` + '', `,`, `$`, wdg).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Akara njirimara (`'a'`), eriri (`"hello"`), nọmba (`2.3`), wdg.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Alaghachi ihe ji nke osisi a, n'ikenye na `span` usoro nke nwere token ma ọ bụ a delimited iyi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Na-ahazi ogologo oge maka *naanị token* a.
    ///
    /// Cheta na ọ bụrụ na a token bụ a `Group` mgbe usoro a ga-hazi ji nke ọ bụla nke esịtidem tokens, a ga-enyefe ndị na-`set_span` usoro nke ọ bụla variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Mbipụta osisi token n'ụdị dị mma maka nbugharị.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Onye ọ bụla n'ime ndị a nwere aha na struct ụdị na ewepụtara debug, n'ihi ya, anaghị inye nsogbu na ihe mmezi oyi akwa nke indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, mmiri ahụ na-enye `to_string` naanị, mejuputa `fmt::Display` dabere na ya (ntụgharị nke mmekọrịta na-adịbu n'etiti abụọ ahụ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Mbipụta na token osisi dị ka a eriri na kwesịrị ịbụ losslessly kọnvatịbụl azụ n'ime otu token osisi (modulo jikọrọ abụọ abụọ), ma e wezụga n'ihi ikekwe 'TokenTree: : Group`s na `Delimiter::None` delimiters na-adịghị mma ọnụọgụ literals.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// A delimited token iyi.
///
/// A `Group` internally nwere a `TokenStream` nke gbara 'Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Na-akọwa otú a usoro nke token osisi na-delimited.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Onye na-akọwapụta ihe doro anya, nke nwere ike, dịka ọmụmaatụ, ga-egosi gburugburu tokens na-abịa site na "macro variable" `$var`.
    /// Ọ dị mkpa iji chekwaa ndị ọrụ na-ebute ụzọ n'ihe dịka `$var * 3` ebe `$var` bụ `1 + 2`.
    /// Ndị na-akọwapụta oke nwere ike ọ gaghị adị ndụ n'akụkụ iyi nke iyi token site na eriri.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Ejiri `Group` ohuru na uzo enyere ya na iyi token.
    ///
    /// Onye na-ewu ụlọ a ga-edozi oge maka otu a na `Span::call_site()`.
    /// Iji gbanwee oge ị nwere ike iji usoro `set_span` n'okpuru.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// O weghachitere njedebe nke `Group` a
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Weghachi `TokenStream` nke tokens nke akatakwara na `Group` a.
    ///
    /// Note na laghachi token stream adịghị agụnye ndị delimiter laghachi n'elu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Laghachi oge maka njedebe nke iyi token a, na-emetụta `Group` niile.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Laghachi ogologo oge na-ezo aka na njedebe njedebe nke otu a.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Laghachi ogologo oge na-ezo aka njedebe njedebe nke otu a.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Na-ahazi oge maka ngalaba a, mana ọ bụghị tokens nke ya.
    ///
    /// Usoro a ga-**bụghị** setịpụrụ ihe ji nke niile esịtidem tokens spanned site otu a, kama ọ ga na-emekwa ihe ji nke delimiter tokens n'ogo nke `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, mmiri ahụ na-enye `to_string` naanị, mejuputa `fmt::Display` dabere na ya (ntụgharị nke mmekọrịta na-adịbu n'etiti abụọ ahụ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mbipụta na otu dị ka a eriri na kwesịrị losslessly kọnvatịbụl azụ n'ime otu ìgwè (modulo jikọrọ abụọ abụọ), ma e wezụga n'ihi ikekwe 'TokenTree: : Group`s na `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// An `Punct` bụ otu akara edemede agwa ka `+`, `-` ma ọ bụ `#`.
///
/// A na-anọchi anya ndị na-eme ọtụtụ agwa dị ka `+=` dị ka ihe atụ abụọ nke `Punct` nwere ụdị `Spacing` dị iche iche laghachiri.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ma onye `Punct`-agbaso ozugbo site ọzọ `Punct` ma ọ bụ soro ọzọ token ma ọ bụ whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ịmaatụ, `+` bụ `Alone` na `+ =`, `+ident` ma ọ bụ `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ịmaatụ, `+` bụ `Joint` na `+=` ma ọ bụ `'#`.
    /// Ọzọkwa, otu quote `'` pụrụ isonyere na nchọpụta ka ụdị ndụ `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Mepụta `Punct` ọhụrụ site na njirimara enyere na oghere.
    /// The `ch` esemokwu ga-a nti akara edemede agwa kwere asụsụ ahụ, ma ọ bụghị ọrụ ga panic.
    ///
    /// The laghachi `Punct` ga ndabara na-adịru nke `Span::call_site()` nke ike-n'ihu ahazi na `set_span` usoro n'okpuru.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Alaghachi uru nke a akara edemede agwa ka `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Weghachi ohere nke akara edemede a, na-egosi ma ọ bụ `Punct` ọzọ na-eso ya ozugbo na iyi token, yabụ enwere ike ijikọta ha na onye ọrụ nwere ọtụtụ agwa (`Joint`), ma ọ bụ na ndị ọzọ token ma ọ bụ oghere (`Alone`) na-esote ya ka onye ọrụ ahụ nwee n'ezie biri.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Weghachi ohere a maka akara edemede a.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Hazie ogologo oge maka agwa akara edemede a.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, mmiri ahụ na-enye `to_string` naanị, mejuputa `fmt::Display` dabere na ya (ntụgharị nke mmekọrịta na-adịbu n'etiti abụọ ahụ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mbipụta akara edemede agwa dị ka a eriri na kwesịrị losslessly kọnvatịbụl azụ n'ime otu agwa.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Ihe njirimara (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Emepụta ọhụrụ `Ident` na nyere `string` nakwa dị ka kpọmkwem `span`.
    /// The `string` esemokwu ga-a nti nchọpụta kwere asụsụ (gụnyere Keywords, eg `self` ma ọ bụ `fn`).Ma ọ bụghị ya, ọrụ ahụ ga-panic.
    ///
    /// Rịba ama na `span`, ugbu a na rustc, configures na ọcha ọmụma a nchọpụta.
    ///
    /// Ka ọ dị ugbu a, `Span::call_site()` gosipụtara n'ụzọ doro anya na "call-site" ịdị ọcha nke pụtara na a ga-edozi ihe nchọpụta ejiri oge a dị ka a ga-asị na edere ha ozugbo na ọnọdụ oku oku, koodu ndị ọzọ na saịtị oku oku ga-enwe ike izo aka ha kwa.
    ///
    ///
    /// Oge gafere ka `Span::def_site()` ga-enye ohere ịbanye na "definition-site" ịdị ọcha na-apụta na ihe nchọpụta e kere site na oge a ga-edozi na ọnọdụ nke nkọwapụta macro yana koodu ndị ọzọ na saịtị oku nnukwu agaghị enwe ike izo aka na ha.
    ///
    /// N'ihi na ugbu a dị mkpa nke idi ocha nke a Constructor, n'adịghị ka ndị ọzọ tokens, na-achọ a `Span` ka kpọmkwem na-ewu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Otu dị ka `Ident::new`, ma na-emepụta a raw nchọpụta (`r#ident`).
    /// The `string` esemokwu na-a nti nchọpụta kwere asụsụ (gụnyere Keywords, eg `fn`).
    /// Keywords nke bụ usable na ụzọ agba (eg
    /// `self`, 'Super`) na-anaghị akwado, na ga-eme ka a panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Laghachi oge nke `Ident` a, na-emetụta ụdọ niile nke [`to_string`](Self::to_string) weghachitere.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Na-ahazi oge nke `Ident` a, ikekwe gbanwee ọnọdụ ịdị ọcha ya.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, mmiri ahụ na-enye `to_string` naanị, mejuputa `fmt::Display` dabere na ya (ntụgharị nke mmekọrịta na-adịbu n'etiti abụọ ahụ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Mbipụta nchọpụta dị ka a eriri na kwesịrị losslessly kọnvatịbụl azụ n'ime otu nchọpụta.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// A nkịtị eriri (`"hello"`), byte eriri (`b"hello"`), agwa (`'a'`), byte agwa (`b'a'`), ihe integer ma ọ bụ sere n'elu ebe ọnụ ọgụgụ na ma ọ bụ enweghị a suffix ('1`, `1u8`, `2.3`, `2.3f32`).
///
/// Akwụkwọ Boolean dị ka `true` na `false` anọghị ebe a, ha bụ `` njirimara ''.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Emepụta ọhụrụ suffixed integer nkịtị na kpọmkwem uru.
        ///
        /// Ọrụ a ga-emepụta ihe ntanetị dị ka `1u32` ebe ọnụahịa ọnụ ọgụgụ akọwapụtara bụ akụkụ mbụ nke token na akụkụ ahụ na-agbakwunye na njedebe.
        /// Edere ederede sitere na nọmba na-adịghị mma nwere ike ọ gaghị adị ndụ site na `TokenStream` ma ọ bụ eriri ma nwee ike gbajie abụọ tokens (`-` na ezigbo nkịtị).
        ///
        ///
        /// Ederede edepụtara site na usoro a nwere `Span::call_site()` span na ndabara, enwere ike ịhazi ya na usoro `set_span` dị n'okpuru.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Emepụta ọhụrụ unsuffixed integer nkịtị na kpọmkwem uru.
        ///
        /// Ọrụ a ga-emepụta ihe ntanetị dị ka `1` ebe ọnụ ọgụgụ integer akọwapụtara bụ akụkụ mbụ nke token.
        /// Ọ dịghị suffix na-kpọmkwem na a token, nke pụtara na invocations ka `Literal::i8_unsuffixed(1)` bụ Ẹkot `Literal::u32_unsuffixed(1)`.
        /// Literals kere si na-adịghị mma na nọmba nwere ike ịda rountrips site `TokenStream` ma ọ bụ ndido urụk na ike-agbaji abụọ tokens (`-` na mma nkịtị).
        ///
        ///
        /// Ederede edepụtara site na usoro a nwere `Span::call_site()` span na ndabara, enwere ike ịhazi ya na usoro `set_span` dị n'okpuru.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Emepụta ọhụrụ unsuffixed sere n'elu-ebe nkịtị.
    ///
    /// Nke a Constructor bụ ndị yiri ndị dị ka `Literal::i8_unsuffixed` ebe ise n'elu si uru-enwupụta kpọmkwem n'ime token ma ọ dịghị suffix na-eji, n'ihi ya, ọ nwere ike inferred na-a `f64` mgbe e mesịrị na compiler.
    ///
    /// Literals kere si na-adịghị mma na nọmba nwere ike ịda rountrips site `TokenStream` ma ọ bụ ndido urụk na ike-agbaji abụọ tokens (`-` na mma nkịtị).
    ///
    /// # Panics
    ///
    /// Ọrụ a na-achọ ka ahụ kwuru kpọmkwem n'elu mmiri bụ oke, n'ihi na ihe atụ ma ọ bụrụ na ọ bụ na-enweghị nsọtụ ma ọ bụ Nan ọrụ a ga-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Emeputa ihe ohuru ohuru na-ese n'elu mmiri.
    ///
    /// Onye nrụpụta ihe a ga-emepụta ihe dị ka `1.0f32` ebe uru a kapịrị ọnụ bụ akụkụ bu ụzọ nke token na `f32` bụ nsụgharị nke token.
    /// Nke a token ga-inferred ịbụ onye na-`f32` na compiler.
    /// Literals kere si na-adịghị mma na nọmba nwere ike ịda rountrips site `TokenStream` ma ọ bụ ndido urụk na ike-agbaji abụọ tokens (`-` na mma nkịtị).
    ///
    ///
    /// # Panics
    ///
    /// Ọrụ a na-achọ ka ahụ kwuru kpọmkwem n'elu mmiri bụ oke, n'ihi na ihe atụ ma ọ bụrụ na ọ bụ na-enweghị nsọtụ ma ọ bụ Nan ọrụ a ga-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Emepụta ọhụrụ unsuffixed sere n'elu-ebe nkịtị.
    ///
    /// Nke a Constructor bụ ndị yiri ndị dị ka `Literal::i8_unsuffixed` ebe ise n'elu si uru-enwupụta kpọmkwem n'ime token ma ọ dịghị suffix na-eji, n'ihi ya, ọ nwere ike inferred na-a `f64` mgbe e mesịrị na compiler.
    ///
    /// Literals kere si na-adịghị mma na nọmba nwere ike ịda rountrips site `TokenStream` ma ọ bụ ndido urụk na ike-agbaji abụọ tokens (`-` na mma nkịtị).
    ///
    /// # Panics
    ///
    /// Ọrụ a na-achọ ka ahụ kwuru kpọmkwem n'elu mmiri bụ oke, n'ihi na ihe atụ ma ọ bụrụ na ọ bụ na-enweghị nsọtụ ma ọ bụ Nan ọrụ a ga-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Emeputa ihe ohuru ohuru na-ese n'elu mmiri.
    ///
    /// Nke a Constructor ga-ike a nkịtị dị ka `1.0f64` ebe uru kpọmkwem bụ ndị bu ụzọ nke token na `f64` bụ suffix nke token.
    /// Ihe token a ka ga-abụ onye `f64` na nchịkọta.
    /// Literals kere si na-adịghị mma na nọmba nwere ike ịda rountrips site `TokenStream` ma ọ bụ ndido urụk na ike-agbaji abụọ tokens (`-` na mma nkịtị).
    ///
    ///
    /// # Panics
    ///
    /// Ọrụ a na-achọ ka ahụ kwuru kpọmkwem n'elu mmiri bụ oke, n'ihi na ihe atụ ma ọ bụrụ na ọ bụ na-enweghị nsọtụ ma ọ bụ Nan ọrụ a ga-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Eriri nkịtị.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Agwa nkịtị.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte eriri nkịtị.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Alaghachi ihe ji asị a nkịtị.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Na-ahazi ogologo oge maka nke a.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Alaghachi a `Span` na bụ a subset nke `self.span()` nwere naanị isi iyi bytes nọ nso `range`.
    /// Alaghachi `None` ma ọ bụrụ na ndị na-trimmed na-adị n'èzí ókè nke `self`.
    ///
    // FIXME(SergioBenitez): lelee na uzo ozo malitere ma mechie na oke UTF-8 nke isi iyi.
    // ma, ọ bụ eleghị anya na a panic ga-eme n'ebe ọzọ mgbe isi iyi ederede-e biri ebi.
    // FIXME(SergioBenitez): enweghị ụzọ onye ọrụ ga-esi mara ihe `self.span()` na-egosi n'ezie, yabụ enwere ike ịkpọ usoro a ugbu a n'amaghị ama.
    // Iji maa atụ, `to_string()` maka agwa 'c' laghachi "'\u{63}'";ọ dịghị ụzọ n'ihi na onye ọrụ mara ma isi iyi ederede bụ 'c' ma ọ bụ ma ọ bụ '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) ihe akin ka `Option::cloned`, ma n'ihi `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, mmiri ahụ na-enye `to_string` naanị, mejuputa `fmt::Display` dabere na ya (ntụgharị nke mmekọrịta na-adịbu n'etiti abụọ ahụ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Na-ebipụta ihe nkịtị dịka ụdọ nke kwesịrị ịgbanwe na-agbanwe agbanwe n'otu ụdị ahụ (belụsọ maka ntụgharị ntụgharị maka isi ihe na-ese n'elu mmiri).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Na-enyocha ohere mgbanwe gburugburu ebe obibi.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Weghachite gburugburu ebe agbanwe ma tinye ya na-ewu dependency Ama.
    /// Mee usoro na-eme ihe nchịkọta ahụ ga-amata na a na-enweta mgbanwe ahụ n'oge nchịkọta, ma nwee ike iweghachi ụlọ ahụ mgbe uru nke agbanwe agbanwe gbanwere.
    ///
    /// E wezụga ịdabere na ịdabere na ọrụ a kwesịrị ka `env::var` si na ọbá akwụkwọ ọkọlọtọ, belụsọ na esemokwu ahụ ga-abụ UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}