//! Mmejuputa iwu nke panics site na ikpochapu ihe
//!
//! crate a bụ mmejuputa nke panics na Rust n'iji "most native" tojupụtara na-emeghe usoro nke ikpo okwu a na-achịkọta.
//! Nke a nnoo ego n'anya categorized n'ime atọ na bọket ugbu a:
//!
//! 1. Ebumnuche MSVC na-eji SEH na faịlụ `seh.rs`.
//! 2. Emscripten eji C++ wezụga na `emcc.rs` file.
//! 3. Ebumnuche ndị ọzọ niile na-eji libunwind/libgcc na faịlụ `gcc.rs`.
//!
//! Enwere ike ịchọta akwụkwọ ndị ọzọ gbasara mmejuputa nke ọ bụla na usoro nke ọ bụla.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ejighi ya na Miri, yabụ dọọ ịdọ aka ná ntị.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Oge mmalite nke Rust dabere na akara ndị a, ya mere mee ka ha bụrụ ọha na eze.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ebumnuche ndị na-akwado ịkwado.
        // - arch=wasm32
        // - os=ọ dịghị onye ("bare metal" lekwasịrị)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Jiri Miri Oge ojiri gaa.
        // Ka dị anyị mkpa na-Ibu Ibu nkịtị Oge ojiri gaa n'elu, dị ka rustc na-atụ anya ihe ụfọdụ lang ihe si n'ebe ahụ ike kọwaa.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Jiri ezigbo oge.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler na libstd akpọ mgbe a panic ihe na-ama esịn na mpụga nke `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler na libstd a na-akpọ mgbe mba ọzọ ma e jidere.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Ntinye ntinye maka ịwelite otu, naanị ndị nnọchi anya na mmejuputa usoro.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}