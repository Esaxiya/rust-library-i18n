//! Mmejuputa panics kụziri site libgcc/libunwind (na ụdị ụfọdụ).
//!
//! Maka nzụlite na njikwa njikwa na ikpochapu biko lee "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) na dọkụmentị jikọtara na ya.
//! Ndị a dịkwa mma agụ:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Nchịkọta dị nkenke
//!
//! Wezụga njikwa eme na abụọ n'ụzọ: a search na-adọ na a nzacha na mkpocha na-adọ.
//!
//! Ma n'ụzọ na unwinder ejegharị tojupụtara osisi si n'elu na ala site na iji ozi si na tojupụtara etiti tụsaratụ ngalaba nke ugbu a usoro nke modul ("module" ebe a na-ezo aka ihe OS modul, ie, ihe executable ma ọ bụ a na-akpa ike n'ọbá akwụkwọ).
//!
//!
//! N'ihi na onye ọ bụla tojupụtara etiti, ọ invokes Associated "personality routine", onye adreesị a na-echekwara na tụsaratụ info ngalaba.
//!
//! N'ime oge ọchụchọ ahụ, ọrụ nke omume mmadụ bụ inyocha ihe a na-atụghị ya na-atụba, yana ikpebi ma a ga-ejide ya na ebe a.Ozugbo handler etiti e kwuru, nzacha na mkpocha na-adọ amalite.
//!
//! Na usoro mkpocha, onye na-achọghị ịhapụ ihe omume ọ bụla ọzọ.
//! Oge a ọ na-ekpebi nke (ma ọ bụrụ na ọ bụla) koodu mkpocha kwesịrị ịgba ọsọ maka okpokoro ugbu a.Ọ bụrụ otú ahụ, a na-ebufe njikwa na branch pụrụ iche na arụ ọrụ, "landing pad", nke na-akpọ ndị mbibi, na-eme ka ncheta, wdg.
//! Ná ngwụsị nke mpempe akwụkwọ ọdịda ahụ, a na-ebugharị njikwa azụ na nkwụsịtụ na nkwụsịtụ.
//!
//! Ozugbo etinyere ngwongwo na ọkwa nke njikwa, nkwụsịtụ nkwụsị na omume mmadụ ikpeazụ na-enyefe njikwa na ngọngọ gbutere.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust si wezụga klas nchọpụta.
// Nke a na-eji usoro omume mmadụ iji chọpụta ma ewezuga oge ha wepụrụ ya.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-onye ahia, asụsụ
    0x4d4f5a_00_52555354
}

// Deba aha NJ na-weliri si LLVM si TargetLowering::getExceptionPointerRegister() na TargetLowering::getExceptionSelectorRegister() bụla ije, mgbe mapped na ntakịrị ihe aha na nọmba site na aha definition tebụl (a<arch>RegisterInfo.td, chọọ "DwarfRegNum").
//
// Leekwa http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Koodu na-adabere na omume GCC nke C na C++ .N'ihi na akwụkwọ, na-ahụ:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Omume EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS na-eji ndabara eme kama ebe ọ na-eji SjLj unwinding.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces on ARM ga-akpọ àgwà na-eme na ala==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // N'okwu ndị ahụ, anyị chọrọ ịga n'ihu na-atọpụ nchịkọta ahụ, ma ọ bụghị ya, ihe niile anyị ga-eme na __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Ihe nkwụsị nke DWARF na-ewere na_Unwind_Context na-ejide ihe dịka ọrụ ahụ na ntụpọ LSDA, agbanyeghị ARM EHABI na-etinye ha n'ime ihe ọzọ.
            // Iji chekwaa ntinye aka nke ọrụ dị ka _Unwind_GetLanguageSpecificData(), nke na-ewere naanị pointer, ihe omume GCC na-eme ka onye na-arụ ọrụ dị iche iche wepụta ihe ọ bụla, na-eji ọnọdụ edebere maka "scratch register" (r12) nke ARM
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // Azọ ga-agbaso ụkpụrụ ga-abụ ịnye nkọwa zuru ezu nke ARM's_Unwind_Context na njikọta njikọ nke libunwind anyị ma nweta data achọrọ site na ya ozugbo, gafere ọrụ ndakọrịta DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI achọ àgwà eme imelite SP uru nke mgbochi cache nke na wezụga ihe.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // On ARM EHABI àgwà na-eme bụ maka n'ezie unwinding a otu tojupụtara etiti tupu ya alọghachi (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // akọwapụtara na libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Omume ebumpụta ụwa, nke ejiri na ọtụtụ ebumnuche na n'ụzọ na-enweghị isi na Windows x86_64 site na SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Na ebumnuche x86_64 MinGW, usoro ịmeghe ihe bụ SEH agbanyeghị nnabata data njikwa (aka LSDA) jiri koodu GCC dakọtara.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Omume omume maka ọtụtụ n'ime ihe anyị chọrọ.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Adreesị nlọghachi na-ekwu 1 byte gara aga nkuzi oku, nke nwere ike ịbụ na nso IP ọzọ na tebụl LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Etinye unwind Ama ndebanye
//
// Onye ọ bụla modul mbiet nwere a etiti tụsaratụ info ngalaba (na-emekarị ".eh_frame").Mgbe modulu bụ loaded/unloaded n'ime usoro a, agaghi-agwa onye na-achọghị ihe gbasara ọnọdụ nke ngalaba a na ebe nchekwa.The ụzọ ọbọ ahụ ịdị iche site n'elu ikpo okwu.
// Na ụfọdụ (dịka, Linux), onye na-achọghị ike nwere ike ịchọpụta ihe izube ozi nke aka ya (site na iji ọnụ ọgụgụ nke modulu a na-ebuzi ugbu a site na dl_iterate_phdr() API and finding their ".eh_frame" sections); ndị ọzọ, dị ka Windows, chọrọ modulu iji debanye aha ihe ọmụma ha na-atụghị anya site na API achọghị.
//
//
// Mọdụl a na-akọwa akara abụọ nke edepụtara ma kpọọ site na rsbegin.rs iji denye ozi anyị na oge GCC.
// Mmejuputa tojupụtara unwinding bụ (maka ugbu a) deferred ka libgcc_eh, Otú ọ dị Rust crates iji ndị a Rust-kpọmkwem ntinye ihe zere nwere clashes na bụla GCC Oge ojiri gaa.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}