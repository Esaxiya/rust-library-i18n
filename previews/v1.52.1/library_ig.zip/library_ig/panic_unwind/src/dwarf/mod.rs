//! Utilities maka parsing ntakịrị-koodu data iyi.
//! Hụ ọkọlọtọ <http://www.dwarfstd.org>, DWARF-4, Nkebi nke 7, "Data Representation"
//!

// Nke a modul na-eji nanị site x86_64-pc-windows-gnu n'ihi na ugbu a, ma anyị na-chikota ya n'ebe nile ezere regressions.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Ntakịrị iyi na-juru n'ọnụ, otú eg, a u32 ga bụchaghị ike kwekọọ na a 4-byte ókè.
    // Nke a nwere ike ịkpata nsogbu na nyiwe yana nghazi chọrọ.
    // Site wrapping data na a "packed" struct, anyị na-agwa ndị backend n'ịwa "misalignment-safe" koodu.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 na SLEB128 kwado na-kọwaa ná Nkebi 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}