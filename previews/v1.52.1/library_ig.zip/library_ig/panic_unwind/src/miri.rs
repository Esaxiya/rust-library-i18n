//! Unwinding panics maka Miri.
use alloc::boxed::Box;
use core::any::Any;

// The ụdị nke payload na Miri engine propagates site unwinding maka anyị.
// Ga-abụ pointer-sized.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-nyere extern ọrụ na-amalite unwind.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // The payload anyị laara `miri_start_panic` ga-aha nnọọ ka arụmụka ahụ anyị na-enweta na `cleanup` n'okpuru.
    // Ya mere, anyị dị nnọọ igbe ya otu ugboro, na-ihe pointer-sized.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Naghachi `Box` isi.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}