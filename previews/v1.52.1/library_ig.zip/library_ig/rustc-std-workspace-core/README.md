# Ihe `rustc-std-workspace-core` crate

crate a bụ crate na-enweghị ihe ọ bụla ma bụrụ ihe efu nke dabere na `libcore` ma weghachite ọdịnaya ya niile.
The crate bụ n'isi sekpụ ntị na-enye ike ọkọlọtọ n'ọbá akwụkwọ na-adabere na crates si crates.io

Crates na crates.io na ọbá akwụkwọ ọkọlọtọ dabere na mkpa ịdabere na `rustc-std-workspace-core` crate site na crates.io, nke tọgbọ chakoo.

Anyị na-eji `[patch]` iji kpochapụ ya na crate a na nchekwa a.
N'ihi ya, crates on crates.io ga-abịarukwa a dependency edge ka `libcore`, na version kọwaa nke a repository.
Nke ahụ kwesịrị ịdọrọ n'akụkụ ndabere niile iji hụ na Cargo na-ewuli crates nke ọma!

Rịba ama na crates na crates.io kwesịrị ịdabere na crate a na aha `core` maka ihe niile iji rụọ ọrụ nke ọma.Ime na ha nwere ike iji:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Site n'iji nke `package` isi na crate na-renamed na `core`, pụtara ọ ga-ele anya dị ka

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

mgbe Cargo na-arịọ ndị nchịkọta ahụ, na-emeju iwu nke `extern crate core` pụtara nke onye nchịkọta ahụ gbara.




