//! Nkwado maka akara ngosi site na iji `gimli` crate na crates.io
//!
//! Nke a bụ ndabere symbolication mmejuputa iwu maka Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Ndụ nke oge niile bụ ụgha iji kwụsị enweghị nkwado maka mkparịta ụka onwe onye.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Tọghatara 'oge ọrịre ebe akara ngosi ga-ebinye `map` na `stash` naanị na anyị na-echekwa ha n'okpuru.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Maka ibuputa ọba akwụkwọ dị na Windows, lee ụfọdụ mkparịta ụka na rust-lang/rust#71060 maka usoro dị iche iche ebe a.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW ọba akwụkwọ adịghị akwado ASLR (rust-lang/rust#16514) ugbu a, mana DLL ka nwere ike ịbagharị ọzọ na oghere adreesị.
            // Ọ dị ka adreesị na nkọwa nbipu dị ka ọ bụrụ na ebupụrụ ọbá akwụkwọ a na "image base" ya, nke bụ ubi na isi faịlụ COFF ya.
            // Ebe ọ bụ na nke a bụ ihe debuginfo yiri ka ọ na-edepụta, anyị na-enyocha tebụl akara na adreesị ụlọ ahịa dị ka a ga-asị na ọbá akwụkwọ buru ibu na "image base".
            //
            // Enwere ike ghara ibudata ọbá akwụkwọ ahụ na "image base", agbanyeghị.
            // (enwere ike iburu ihe ọzọ ebe ahụ?) Nke a bụ ebe ebe `bias` na-abanye, anyị kwesịrị ịchọpụta uru `bias` bara ebe a.Dị mwute ikwu na ọ bụ ezie na ọ bụghị doro anya otú iji nweta a si a loaded modul.
            // Ihe anyị nwere, agbanyeghị, bụ adreesị ibu (`modBaseAddr`).
            //
            // Dị ka ntakịrị nke cop-maka ugbu a anyị mmap faịlụ ahụ, gụọ ozi nkụnye eji isi mee, wee daa mmap ahụ.Nke a lara n`iyi n`ihi na anyị nwere ike mepee mmap emesịa, mana nke a ga-arụ ọrụ nke ọma ugbu a.
            //
            // Ozugbo anyị nwere `image_base` (ebe a chọrọ) na `base_addr` (ebe a na-ebu ibu) anyị nwere ike jupụta `bias` (ọdịiche dị n'etiti ihe dị adị na nke achọrọ) wee dezie adreesị ekwupụta nke ọ bụla bụ `image_base` ebe ọ bụ ihe faịlụ ahụ kwuru.
            //
            //
            // Maka ugbu a ọ dị ka n'adịghị ka ELF/MachO anyị nwere ike ime otu akụkụ n'otu ọba akwụkwọ, jiri `modBaseSize` dị ka ogo niile.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS na-eji usoro faịlụ Mach-O ma jiri DYLD-API doro anya iji kwado ndepụta nke ụlọ akwụkwọ ọbá akwụkwọ nke bụ akụkụ nke ngwa ahụ.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Ozi kpọtara aha nke a n'ọbá akwụkwọ nke kwekọrọ na ụzọ nke ebe mara ya.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Ibu Ibu image nkụnye eji isi mee nke a Ọbá akwụkwọ na nyefere ndị na `object` ka parse niile ibu iwu ka anyị nwere ike chepụta niile agba aka ebe a.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterate n'elu agba na aha mara na mpaghara maka agba na anyị na-ahụ.
            // Tụkwasị na nke a ederede ederede ederede maka nhazi mgbe e mesịrị, lee ihe n'okpuru.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Kpebisie ike na "slide" maka ọbá akwụkwọ a nke mechara bụrụ ajọ mbunobi anyị na-eji achọpụta ebe a na-ebu ihe nchekwa.
            // Nke a bụ ntakịrị ihe mgbakọ dị egwu ma ọ bụ nsonaazụ nke ịnwale ihe ole na ole n'ime anụ ọhịa ma hụ ihe na-adịgide.
            //
            // Echiche zuru ezu bụ na `bias` gbakwunyere `stated_virtual_memory_address` nke akụkụ ga-abụ ebe n'ime oghere adreesị nke akụkụ ahụ bi.
            // Ihe ozo anyi tukwasiri obi na ya bu na ezi adreesị wepu `bias` bu ndeksi ka ichota na tebulu akara na debuginfo.
            //
            // Ọ amama, ọ bụ ezie na, na maka usoro kwajuru ọba akwụkwọ ndị a mgbawa na-ekwesịghị ịdị.Maka ndị isi obodo, ọ dị ka ọ dị mma.
            // Na-eweli ụfọdụ mgbagha sitere na isi LLDB, o nwere ụfọdụ casing pụrụ iche maka ngalaba `__TEXT` izizi bujuru site na faịlị mebiri 0 na nha nonzero.
            // Maka ebumnuche ọ bụla mgbe nke a dị, ọ dị ka ọ pụtara na okpokoro akara ahụ metụtara naanị vmaddr slide maka ọba akwụkwọ.
            // Ọ bụrụ na ọ bụ *bụghị* ugbu mgbe akara table bụ ikwu na ndị vmaddr slide gbakwunyere na nke nke kwuru okwu.
            //
            // Iji mee ihe banyere ọnọdụ a ma ọ bụrụ na anyị * achọtaghị akụkụ ederede na faịlị na-akwụ ụgwọ efu, mgbe ahụ anyị na-eme ka enweghị isi site na adreesị ederede izizi wee belata adreesị niile ekwuru site na ego ahụ.
            //
            // N'ụzọ dị otú ahụ na akara table bụ mgbe egosi ikwu na ọbá akwụkwọ echiche ọjọọ ego.
            // Nke a na-egosi na ndị nwere ikike na-arụpụta maka anọchi via akara table.
            //
            // N'ikwu eziokwu, amachaghị m ma nke a ọ ziri ezi ma ọ bụ na ọ nwere ihe ọzọ kwesịrị igosi etu esi eme nke a.
            // Maka ugbu a ọ bụ ezie na nke a yiri ka ọ na-arụ ọrụ nke ọma (?) ma anyị ga-enwe ike ịmegharị oge a ọ bụrụ na ọ dị mkpa.
            //
            // N'ihi na ụfọdụ ozi ọzọ ahụ #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Ndị ọzọ Unix (dịka
        // Linux) nyiwe iji Elf dị ka ihe file format na a na mejuputa ihe API akpọ `dl_iterate_phdr` Ibu Ibu nwa afọ ọba akwụkwọ.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` kwesịrị ịbụ ntụpọ ziri ezi.
        // `vec` kwesịrị a nti pointer ka a `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 anaghị natively akwado debug Ama, ma Mee usoro ga-edebe debug info na ụzọ `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Ihe ndi ozo kwesiri iji ELF, mana amaghi otu esi ebu akwukwo ndi akwukwo.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// All mara òkè ọba akwụkwọ na ebụgoro.
    libraries: Vec<Library>,

    /// Mappings cache ebe anyi jigidere ihe omuma ihe omuma.
    ///
    /// Ndepụta a nwere ikike ofu maka oge mbuli elu ya nke na-anaghị abawanye.
    /// Ihe `usize` nke ọ bụla bụ ihe ndeksi n'ime `libraries` n'elu ebe `usize::max_value()` na-anọchite anya ugbu a.
    ///
    /// `Mapping` kwekọrọ na ozi dwarf.
    ///
    /// Cheta na nke a bụ isi ihe LRU cache na anyị ga-agbanwe ihe gburugburu na ebe a ka anyị na-anọchi anya adreesị.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Akụkụ nke ọbá akwụkwọ a abanye n'ime ebe nchekwa, na ebe etinyere ha.
    segments: Vec<LibrarySegment>,
    /// "bias" nke oba akwukwo a, dika ebe etinye ya n'ime ebe nchekwa.
    /// Nke a bara uru na-agbakwunye na nkebi ọ bụla kwuru adreesị iji nweta ezigbo mebere ebe nchekwa adreesị nke nke a na-ebu n'ime.
    /// Ọzọkwa a echiche ọjọọ na-subtracted si ezigbo virtual ebe nchekwa adreesị na index n'ime debuginfo na akara table.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// The kwuru okwu a nke na ihe file.
    /// Nke a abụghị n'ezie ebe agbajuru akụkụ ahụ, kama kama adreesị a yana `bias` nke nwere ọbá akwụkwọ bụ ebe ịchọta ya.
    ///
    stated_virtual_memory_address: usize,
    /// Nha nke ths nke na ebe nchekwa.
    len: usize,
}

// enweghị nchedo n'ihi na achọrọ ka emekọrịta ya na mpụga
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // enweghị nchedo n'ihi na achọrọ ka emekọrịta ya na mpụga
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // A nnọọ obere, dị nnọọ mfe LRU cache maka debug info mappings.
        //
        // Ọnụ ọgụgụ kụrụ afọ kwesịrị ịdị elu nke ukwuu, ebe ọ bụ na ụdị nchịkọta adịghị agafe n'etiti ọtụtụ ọba akwụkwọ.
        //
        // Ihe owuwu `addr2line::Context` mara oke mma imepụta.
        // A na-atụ anya ka ọnụ ahịa ya megharịa ya site na ajụjụ `locate` na-esote, nke na-eme ka ihe owuwu ndị e wuru mgbe ha na-ewu ``addr2line: : Context`s iji nweta ọmarịcha ọsọ ọsọ.
        //
        // Ọ bụrụ na anyị na-enweghị ihe a cache, na amortization gaghị eme, na symbolicating backtraces ga-ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Akpa ọtọ, ule ma ọ bụrụ na a `lib` nwere ọ bụla nke nwere `addr` (ejizi ngafe).Ọ bụrụ na nlele a gafere, anyị nwere ike ịga n'ihu n'okpuru ma sụgharịa adreesị.
                //
                // Cheta na anyị na-eji `wrapping_add` ebe a iji zere ejupụta akwụkwọ ndenye ego.Ọ na-e hụrụ na anụ ọhịa na SVMA + echiche ọjọọ mgbakọ ọtọde.
                // O yiri ka ọ dị ntakịrị na ọ ga-eme mana enweghị nnukwu ego anyị nwere ike ime maka ya karịa karịa ị ga-eleghara ngalaba ndị ahụ anya ebe ọ bụ na ha nwere ike ịpụ na mbara igwe.
                //
                // Nke a malitere na rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Ugbu a na anyị matara na `lib` nwere `addr`, anyị nwere ike wezuga obi ọjọọ iji chọpụta adreesị ebe nchekwa dị mma.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: mgbe a nhazi completes enweghị n'oge na-alọta
        // site na njehie, ntinye oghere maka ụzọ a dị na ndeksi 0.

        if let Some(idx) = idx {
            // Mgbe nkewa bụ ugbua na cache, akpali ya n'ihu.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Mgbe nkewa ahụ na-adịghị n'ime oghere, mepụta nkewa ọhụrụ, tinye ya n'ihu ebe nchekwa ahụ, wee chụpụ oghere cache kacha ochie ma ọ bụrụ na ọ dị mkpa.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // adịghị ihihi na `'static` ndụ, na-eme ka n'aka na ọ na-scoped nnọọ onwe anyị
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Gbatịa ndụ nke `sym` ruo `'static` ebe ọ bụ na ọ dị mwute ikwu na achọrọ anyị ebe a, mana ọ na-apụ apụ maka ntụnye ya mere na enweghị ntụnyere ya ga-esi ọnwụ karịa ya.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Na mmechi, nweta eserese echekwara ma ọ bụ mepụta maapụ ọhụrụ maka faịlụ a, ma nyochaa ozi DWARF iji chọta file/line/name maka adreesị a.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Anyị nwere ike ịchọta ozi etiti maka akara a, yana tinyer2line`'s etiti nwere nkọwapụta nitty gritty niile.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Enweghị ike ịchọta ozi debug, mana anyị chọtara ya na tebụl akara nke elf executable.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}