//! Atụmatụ ihe atụ site na iji koodu DWARF na-enyocha na libbacktrace.
//!
//! Ọbá akwụkwọ libbacktrace C, nke a na-ekesa na gcc, na-akwado ọ bụghị naanị na ị na-ewepụta azụ azụ (nke anyị na-anaghị eji ya eme ihe) mana na-egosipụtakwa backtrace na njikwa dugf debug information about things like inlined frames and whatnot.
//!
//!
//! Nke a dịtụ mgbagwoju anya n'ihi ọtụtụ nchegbu dị iche iche ebe a, mana echiche bụ isi bụ:
//!
//! * First anyị na-akpọ `backtrace_syminfo`.Nke a na-akawanye akara ọmụma si na-akpa ike akara table ma ọ bụrụ na anyị nwere ike.
//! * Ọzọ anyị na-akpọ `backtrace_pcinfo`.Nke a ga-parse debuginfo tebụl ma ọ bụrụ na ha na-dị na-ekwe ka anyị inwetaghachi ihe ọmụma banyere inline okpokolo agba, filenames, akara nọmba, wdg
//!
//! Enwere otutu aghụghọ banyere ị nweta tebụl dị iche iche na libbacktrace, mana olile anya na ọ bụghị njedebe nke ụwa ma doo anya nke ọma mgbe ị na-agụ n'okpuru.
//!
//! Nke a bụ usoro ndabara usoro ihe atụ maka nyiwe na-abụghị MSVC na nyiwe na-abụghị OSX.Na libstd ọ bụ ezie na nke a bụ atụmatụ ndabara maka OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ọ bụrụ na ọ ga-ekwe omume họrọ aha `function` nke sitere na debuginfo ma nwee ike bụrụ ihe ziri ezi maka okpokoro agba dịka ọmụmaatụ.
                // Ọ bụrụ na nke na-adịghị ugbu ezie ọdịda azụ akara table aha kpọmkwem ke `symname`.
                //
                // Cheta na mgbe ụfọdụ `function` nwere ike dịtụ obere ezi, n'ihi na ihe atụ a na-edepụtara dị ka `try<i32,closure>` isntead nke `std::panicking::try::do_call`.
                //
                // Ọ na-adịghị n'ezie ikpochapụ mere, ma n'ozuzu na `function` aha yiri ihe ezi.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // emela ihe ọ bụla ugbu a
}

/// Pịnye nke `data` pointer ebe n'ime `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Ozugbo akpọrọ oku a na `backtrace_syminfo` mgbe anyị malitere idozi ya, anyị ga-aga n'ihu ịkpọ `backtrace_pcinfo`.
    // `backtrace_pcinfo` ọrụ ga-eleba anya debug ọmụma na-agbali tto ime ihe ndị dị ka naghachi file/line ozi nakwa dị ka inlined okpokolo agba.
    // Note ezie na `backtrace_pcinfo` nwere ike ida ma ọ bụ na-eme ihe ma ọ bụrụ na e nwere ihe bụghị debug Ama, ọ bụrụ na nke ahụ mere na anyị na-n'aka na-akpọ ndị na callback na ọ dịkarịa ala otu akara si `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Ofdị nke pointer `data` gafere na `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace na-akwado imepụta steeti, mana ọ kwadoghi ibibi steeti.
// Mụ onwe m na-ewere nke a ịpụta na steeti pụtara ka e kee ya wee dịrị ndụ ruo mgbe ebighị ebi.
//
// Ọ ga-amasị m ịdebanye aha onye na-ahụ maka at_exit() nke na-eme ka steeti a dị ọcha, mana libbacktrace enweghị ụzọ isi mee ya.
//
// Na ndị a mgbochi, ọrụ a nwere a statically echekwa steeti na-gbakọọ oge mbụ a na-arịọ.
//
// Cheta na backtracing nile na-eme serially (onye zuru ụwa ọnụ mkpọchi).
//
// Rịba ama na enweghị mmekọrịta ebe a bụ n'ihi na na chọrọ na `resolve` na-externally synchronized.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ekwela egosipụta threadsafe ike nke libbacktrace ebe anyị na-mgbe niile na-akpọ ya na a synchronized ejiji.
        //
        0,
        error_cb,
        ptr::null_mut(), // enweghị data ọzọ
    );

    return STATE;

    // Rịba ama na n'ihi na libbacktrace iji rụọ ọrụ mgbe niile na ọ chọrọ ka ahụ ntakịrị debug info maka ugbu a executable.Ọ a na-eme na via a ọnụ ọgụgụ nke usoro gụnyere, ma-ejedebeghị na:
    //
    // * /proc/self/exe na nyiwe akwado
    // * The filename gafere na n'ụzọ doro anya na mgbe na-eke ala
    //
    // The libbacktrace n'ọbá akwụkwọ bụ a nnukwu wad of C koodu.Nke a ndammana pụtara na ọ na-nwetara ebe nchekwa na nchekwa ọma, karịsịa mgbe na-ejizi malformed debuginfo.
    // Libstd agbaala ọtụtụ n'ime akụkọ ihe mere eme.
    //
    // Ọ bụrụ na /proc/self/exe a na-eji mgbe ahụ anyị nwere ike a na-eleghara ndị a ka anyị na-eche na libbacktrace bụ "mostly correct" na n'ụzọ ndị ọzọ na-adịghị eme weird ihe na "attempted to be correct" Dwarf debug Ama.
    //
    //
    // Ọ bụrụ na anyị gafere na a filename Otú ọ dị, mgbe ahụ na ọ bụ omume na ụfọdụ nyiwe (dị ka BSDs) ebe a obi omee nwere ike ime ka ihe aka ike file-enịm na na ọnọdụ.
    // Nke a pụtara na ọ bụrụ na anyị na-agwa libbacktrace banyere a filename o nwere ike ịbụ na-eji ihe aka ike file, ikekwe na-eme ka segfaults.
    // Ọ bụrụ na anyị anaghị agwa libbacktrace ihe ọ bụla n'agbanyeghị na ọ gaghị eme ihe ọ bụla na nyiwe ndị na-adịghị akwado ụzọ dịka /proc/self/exe!
    //
    // Nyere niile na anyị na-agbalị ka ike dị ka o kwere omume *bụghị* ngafe na a filename, ma anyị ga na nyiwe na-adịghị akwado /proc/self/exe na niile.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Rịba ama na anyị ga-eji `std::env::current_exe`, mana anyị enweghị ike ịchọ `std` ebe a.
            //
            // Iji `_NSGetExecutablePath` iji mara na ugbu a executable ụzọ n'ime a static ebe (nke ma ọ bụrụ na ọ dị oke obere nnọọ inye elu).
            //
            //
            // Rịba ama na anyị na-atụkwasị obi na ebe a ka anyị ghara ịnwụ na ndị rụrụ arụ, mana ọ na-eme ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows nwere ọnọdụ imeghe faịlụ ebe ọ meghere enweghị ike ihichapụ ya.
            // Nke ahụ bụ ihe niile anyị chọrọ ebe a n'ihi na anyị chọrọ ijide n'aka na ndị anyị nwere ike ịgbanwe agbanwe n'okpuru anyị mgbe anyị nyefere ya na libbacktrace, na-atụ anya na mbelata ikike ịfefe data na-ezighi ezi n'ime libbacktrace (nke nwere ike ịhazi ya).
            //
            //
            // Nyere na anyị na-eme a bit nke a na-agba egwú a na-anwa na-a ụdị mkpọchi na anyị onwe anyị oyiyi:
            //
            // * Nweta a handle nke ugbu a usoro, mara ya filename.
            // * Mepee faịlụ na aha njirimara ahụ na akara aka nri.
            // * Bugharịa aha aha ugbu a, na-ejide n'aka na ọ bụ otu
            //
            // Ọ bụrụ na ihe niile gafere anyị na tiori emepeela faịlụ usoro anyị n'ezie ma anyị kwere gị nkwa na ọ gaghị agbanwe.FWIW ụyọkọ nke a na-edepụtaghachi site na libstd n'akụkọ ihe mere eme, ya mere na nke a bụ nkọwa m kachasị mma banyere ihe na-eme.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Nke a bi na static ebe nchekwa ka anyị wee weghachi ya ..
                static mut BUF: [i8; N] = [0; N];
                // ... na a ndụ na tojupụtara ebe ọ bụ ruo nwa oge
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ụma ihihi `handle` ebe a n'ihi na-enwe na-emeghe ga chebe anyị mkpọchi a faịlụ aha.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Anyị chọrọ ịlaghachi iberi nke nul-kwụsị, yabụ ọ bụrụ na ihe niile ejupụta na ya na ngụkọta ogologo wee hara na ọdịda.
                //
                //
                // Ma ọ bụghị mgbe alọta ọma anam n'aka na nul byte a gụnyere ke iberi.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace njehie na-ugbu a na-ekpochapụ n'okpuru rog
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Kpọọ `backtrace_syminfo` API nke (site n'ịgụ koodu ahụ) kwesịrị ịkpọ `syminfo_cb` otu oge (ma ọ bụ daa na njehie enwere ike).
    // Anyị na-ahụzi karịa n'ime `syminfo_cb`.
    //
    // Cheta na anyị na-eme nke a kemgbe `syminfo` ga ịkpọ ihe nnọchianya table, na-achọta akara aha ọbụna ma ọ bụrụ na e nweghị debug ozi ke ọnụọgụ abụọ.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}