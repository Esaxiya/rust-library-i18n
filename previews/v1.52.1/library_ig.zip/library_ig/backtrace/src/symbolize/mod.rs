use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Dozie okwu ka a akara, na-agafe akara na kwuru kpọmkwem mmechi.
///
/// Ọrụ a ga-eleba anya na adreesị e nyere na mpaghara dịka tebụl akara ngosi mpaghara, tebụl akara ngosi dị ike, ma ọ bụ DWARF debug info (dabere na ntinye n'ọrụ) iji chọta akara iji nye.
///
///
/// Enweghi ike ịkpọ mmechi ahụ ma ọ bụrụ na enweghị ike ịme mkpebi, enwere ike ịkpọ ya karịa otu oge n'ihe banyere ọrụ ndị arụpụtara.
///
/// Ihe ngosi doro anya na-anọchite anya ogbugbu na `addr` ahụ akọwapụtara, na-alọta file/line ụzọ abụọ maka adreesị ahụ (ọ bụrụ na ọ dị).
///
/// Cheta na ọ bụrụ na ị nwere a `Frame` mgbe ọ na-atụ aro iji ndị `resolve_frame` ọrụ kama nke a.
///
/// # Ihe ndị achọrọ
///
/// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
///
/// # Panics
///
/// Ọrụ a na-agba mbọ ka ọ ghara panic, mana ọ bụrụ na `cb` nyere panics mgbe ahụ ụfọdụ nyiwe ga-amanye panic abụọ iji belata usoro ahụ.
/// Platformsfọdụ nyiwe na-eji ọba akwụkwọ C nke na-eji oku na-eme ihe nke na-enweghị ike ịkọwapụta ya, yabụ ịtụ ụjọ na `cb` nwere ike ịkpalite usoro ịwepụ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // naanị anya na n'elu etiti
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Dozie a na mbụ weghara etiti a akara, na-agafe akara na kwuru kpọmkwem mmechi.
///
/// Nke a functin arụ otu ọrụ dị ka `resolve` ma e wezụga na ọ na-ewe a `Frame` ka esemokwu kama adreesị.
/// Nke a nwere ike ikwe ka ụfọdụ ntinye nke ikpo okwu iji weghachite ozi akara ngosi ma ọ bụ ozi gbasara okpokoro agba dịka ọmụmaatụ.
///
/// A na-atụ aro ka ị jiri nke a ma ọ bụrụ na ị nwere ike.
///
/// # Ihe ndị achọrọ
///
/// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
///
/// # Panics
///
/// Ọrụ a na-agba mbọ ka ọ ghara panic, mana ọ bụrụ na `cb` nyere panics mgbe ahụ ụfọdụ nyiwe ga-amanye panic abụọ iji belata usoro ahụ.
/// Platformsfọdụ nyiwe na-eji ọba akwụkwọ C nke na-eji oku na-eme ihe nke na-enweghị ike ịkọwapụta ya, yabụ ịtụ ụjọ na `cb` nwere ike ịkpalite usoro ịwepụ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // naanị anya na n'elu etiti
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP ụkpụrụ si tojupụtara okpokolo agba bụ a (always?) ntụziaka *mgbe* oku na nke ahụ bụ kpọmkwem tojupụtara Chọpụta.
// Iji gosipụta nke a na-eme ka nọmba filename/line bụrụ nke dị n'ihu ma eleghị anya n'ime ihe efu ma ọ bụrụ na ọ dị nso na njedebe ọrụ ahụ.
//
// Nke a dị ka ihu ọma na nyiwe niile, yabụ anyị na-ewepu otu site na ip kpebiri iji dozie ya na nkuzi oku gara aga kama ịzigharị ntụziaka ahụ.
//
//
// O doro anya na anyị agaghị eme nke a.
// N'eziokwu, anyị ga-achọ listi ọkpọ oku nke `resolve` APIs ebe a na-aka eme nke -1 na na akaụntụ na ha chọrọ ozi ọnọdụ maka *gara aga* ntụziaka, ọ bụghị ugbu a.
// O doro anya na anyị ga-ekpughekwa na `Frame` ma ọ bụrụ na anyị bụ n'ezie adreesị nke nkuzi na-esote ma ọ bụ nke ugbu a.
//
// Maka ugbu a ọ bụ ezie na nke a bụ nlezianya mara mma nke mere na anyị na-ewepụkarị otu.
// Ndị ahịa kwesịrị ịnọgide na-arụ ọrụ ma na-arụpụta ezigbo nsonaazụ, yabụ anyị kwesịrị izu oke.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Otu dị ka `resolve`, naanị nwedịrị ike ịta ụta ka a naghị edozi ya.
///
/// Ọrụ a enweghị mmekọrịta ndị gosipụtara mana ọ dị mgbe enweghị mkpokọta atụmatụ `std` nke crate a.
/// Lee `resolve` ọrụ ọzọ akwụkwọ na ihe atụ.
///
/// # Panics
///
/// Lee ozi na `resolve` maka caveats on `cb` panicking.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Otu dị ka `resolve_frame`, naanị nwedịrị ike ịta dị ka ọ bụ unsynchronized.
///
/// Ọrụ a enweghị mmekọrịta ndị gosipụtara mana ọ dị mgbe enweghị mkpokọta atụmatụ `std` nke crate a.
/// Lee `resolve_frame` ọrụ ọzọ akwụkwọ na ihe atụ.
///
/// # Panics
///
/// Hụ ozi na `resolve_frame` maka ọgba egwu na egwu `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait na-anọchite mkpebi nke akara na faịlụ.
///
/// Nke a trait na-amịghịkwa ka a trait ihe na mmechi nyere `backtrace::resolve` ọrụ, na ọ na-fọrọ nke nta ka zipụrụ ka ọ amaghi nke mmejuputa iwu-bụ n'azụ ya.
///
///
/// Ihe nnọchianya nwere ike inye ihe omuma banyere otu ọrụ, dịka ọmụmaatụ aha, aha njirimara, akara akara, adreesị ziri ezi, wdg.
/// Ọ bụghị ihe niile ọmụma bụ mgbe dị na a na akara, Otú ọ dị, ya mere, ihe niile ụzọ laghachi ihe `Option`.
///
///
pub struct Symbol {
    // TODO: Ogologo oge a kwesiri ka ekwenye na `Symbol`,
    // ma nke ahụ bụ mgbanwe mgbanwe ugbu a.
    // Maka ugbu a, ọ dị mma ebe ọ bụ na ana-enyefe `Symbol` naanị na nrụtụ aka na-enweghị ike ịme ya.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Alaghachi aha ọrụ a.
    ///
    /// The laghachi Ọdịdị pụrụ iji ajụjụ dị iche iche Njirimara banyere ihe nnọchianya aha:
    ///
    ///
    /// * The `Display` mmejuputa ga bipụta na demangled akara.
    /// * Enwere ike ịnweta uru `str` nke akara ahụ (ma ọ bụrụ na ọ dị utf-8).
    /// * Enwere ike ịnweta bytes raw maka aha akara.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// - Alaghachi na-amalite ikwu okwu nke ọrụ a.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Weghachite raw filename dị ka iberi.
    /// Nke a bụ uru bara uru maka gburugburu `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Weghachite nọmba kọlụm maka ebe akara a na-arụ ugbu a.
    ///
    /// Naanị gimli ugbu a na-enye uru ebe a na ọbụlagodi ma ọ bụrụ na `filename` laghachiri `Some`, yabụ na ọ ga-esi na ya pụta n'okpuru nnabata ndị yiri ya.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Alaghachi akara nọmba maka ebe a na akara a ugbu a ekpede.
    ///
    /// Nloghachi a na-abụkarị `Some` ma ọ bụrụ na `filename` laghachiri `Some`, ma bụrụkwa nke a n'okpuru isiokwu ndị yiri ya.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Laghachi aha faịlụ ahụ ebe akọwapụtara ọrụ a.
    ///
    /// Nke a dị ugbu a naanị mgbe a na-eji libbacktrace ma ọ bụ gimli (dịka
    /// unix nyiwe ndị ọzọ) na mgbe ejiri ọnụọgụ ọnụọgụ na debuginfo.
    /// Ọ bụrụ na otu n'ime ọnọdụ ndị a ezute, nke a nwere ike ịlaghachi `None`.
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Ma eleghị anya, a parsed C++ akara, ma ọ bụrụ na parsing na mangled akara dị ka Rust okpu.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Jide n'aka na-a efu-sized, nke mere na `cpp_demangle` feature nwere ọ na-eri mgbe nkwarụ.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Ihe mkpuchi gburugburu aha akara iji nye ndị na-enweta ergonomic na aha demangled, raw bytes, raw raw, wdg.
///
// Ekwe ka ndị nwụrụ anwụ koodu maka mgbe `cpp_demangle` atụmatụ na-adịghị nyeere.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Emeputa aha akara ohuru site na bytes.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Weghachite aha akara ngosi (mangled) dị ka `str` ma ọ bụrụ na akara ngosi ahụ dị utf-8.
    ///
    /// Jiri ntinye `Display` ma ọ bụrụ na ịchọrọ ụdị mbipute ahụ.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Laghachi aha akara ngosi dị ka ndepụta nke bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Nke a nwere ike na-ebipụta ma ọ bụrụ na ndị demangled akara bụ n'ezie irè, ka aka njehie ebe a ùgwù site yiri ya outwards.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Agbali iji gbapụta na juru ebe nchekwa na-eji symbolicate adreesị.
///
/// Usoro a ga-agbali ịhapụ ụdị data data ọ bụla nke echekwara na ụwa ma ọ bụ na eri nke na-anọchite anya ozi DWARF ma ọ bụ nke yiri ya.
///
///
/// # Caveats
///
/// Mgbe ọrụ a bụ mgbe niile dị ọ na-adịghị n'ezie ime ihe ọ bụla na ọtụtụ implementations.
/// Ọba akwụkwọ dị ka dbghelp ma ọ bụ libbacktrace anaghị enye akụrụngwa iji dozie steeti ma jikwaa ebe nchekwa ahụ.
/// N'ihi na ugbu a na `gimli-symbolize` atụmatụ a crate bụ naanị mma ebe ọrụ a nwere mmetụta ọ bụla.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}