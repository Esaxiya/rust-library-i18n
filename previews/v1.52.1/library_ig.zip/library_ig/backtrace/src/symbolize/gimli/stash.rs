// na-eji naanị na Linux ugbu a, yabụ hapụ koodu ndị nwụrụ anwụ n`ebe ọzọ
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Onye na-ekepụta ebe egwuregwu dị mfe maka ebe nchekwa dị.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Allocates a echekwa nke kwuru kpọmkwem size na-alaghachi a mutable banyere ya.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: Nke a bụ naanị ọrụ na-ewuli elu
        // zoo aka na `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: anyi anaghi ewepu ihe site na `self.buffers`, ya mere onye na-ekwu okwu
        // na data n'ime bụla echekwa ga ogologo ndụ dị ka `self` eme.
        &mut buffers[i]
    }
}