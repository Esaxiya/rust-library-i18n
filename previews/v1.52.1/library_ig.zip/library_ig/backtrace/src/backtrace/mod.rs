use core::ffi::c_void;
use core::fmt;

/// Na-enyocha nyocha ọkpụkpọ dị ugbu a, na-agafe osisi niile na-arụ ọrụ n'ime mmechi enyere iji gbakọọ nchịkọta nchịkọta.
///
/// Ọrụ a bụ ọrụ nke ọba akwụkwọ a na ịgbakọ usoro nchịkọta maka mmemme.The nyere mmechi `cb` na-amịghịkwa ihe nke a `Frame` nke na-anọchi anya ihe ọmụma banyere na oku na-aga etiti na tojupụtara.
/// Emechiela mmechi ahụ maka osisi n`elu-elu (nke akpọrọ ọrụ na nso nso a).
///
/// Uru mmechi mmechi ahụ bụ ihe na-egosi ma ọ ga-aga n'ihu azụ azụ.Nloghachi nke `false` ga-akwụsị azụ azụ wee laghachi ozugbo.
///
/// Ozugbo enwetara `Frame`, o yikarịrị ka ị ga-achọ ịkpọ `backtrace::resolve` iji tọghata `ip` (ntụpọ ntụziaka) ma ọ bụ adreesị akara ngosi na `Symbol` site na nke a ga-esi mụta aha na/ma ọ bụ filename/akara nọmba.
///
///
/// Cheta na nke a bụ a dịtụ ala-larịị ọrụ ma ọ bụrụ na ị ga-amasị, n'ihi na ihe atụ, weghara a backtrace ka nyochara mgbe e mesịrị, mgbe ahụ `Backtrace` ụdị nwere ike ịbụ ihe kwesịrị ekwesị.
///
/// # Ihe ndị achọrọ
///
/// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
///
/// # Panics
///
/// Ọrụ a na-agba mbọ ka ọ ghara panic, mana ọ bụrụ na `cb` nyere panics mgbe ahụ ụfọdụ nyiwe ga-amanye panic abụọ iji belata usoro ahụ.
/// Platformsfọdụ nyiwe na-eji ọba akwụkwọ C nke na-eji oku na-eme ihe nke na-enweghị ike ịkọwapụta ya, yabụ ịtụ ụjọ na `cb` nwere ike ịkpalite usoro ịwepụ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // gaa n'ihu azụ azụ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Otu dị ka `trace`, naanị nwedịrị ike ịta ụta ka a naghị edozi ya.
///
/// Ọrụ a enweghị mmekọrịta ndị gosipụtara mana ọ dị mgbe enweghị mkpokọta atụmatụ `std` nke crate a.
/// Hụ ọrụ `trace` maka ederede na ihe atụ ndị ọzọ.
///
/// # Panics
///
/// Hụ ozi na `trace` maka ọgba egwu na egwu `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait na-anọchite anya otu etiti nke azụ azụ, nyefere ọrụ `trace` nke crate a.
///
/// A ga-enyefe mmechi arụ ọrụ nchọta ihe, a na-ezipụkwa etiti ahụ ka ọ bụrụ na amabeghị mmejuputa iwu ahụ oge niile.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Laghachi ugbu a ntuziaka pointer nke etiti a.
    ///
    /// Nke a bụ ntụziaka na-esote ị ga-eme na etiti ahụ, mana ọ bụghị ihe niile mejupụtara nke a na 100% ziri ezi (mana ọ dịkarịsịrị nso).
    ///
    ///
    /// A na-atụ aro ka ịfefe uru a na `backtrace::resolve` ka ọ gbanwee ya na aha njirimara.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Alaghachi pointer ugbu a nke etiti a.
    ///
    /// Ọ bụrụ na nkwado azụ enweghị ike ịgbake nchịkọta pointer maka etiti a, a na-eweghachi ihe null pointer.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Alaghachi amalite akara adreesị nke etiti nke ọrụ a.
    ///
    /// Nke a ga-anwa iweghachite ntuziaka ntuziaka nke `ip` laghachiri na mmalite nke ọrụ ahụ, weghachite uru ahụ.
    ///
    /// N'ọnọdụ ụfọdụ, agbanyeghị, nkwado azụ ga-alọghachi `ip` na ọrụ a.
    ///
    /// The laghachi uru nwere ike mgbe ụfọdụ a ga-eji ma ọ bụrụ na `backtrace::resolve` okpu na `ip` nyere n'elu.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Alaghachite adreesị ntọala nke modulu nke etiti ahụ bụ.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Nke a kwesịrị ibute ụzọ, iji hụ na Miri na-ebute ụzọ karịa ikpo okwu ndị ọbịa
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // naanị eji dbghelp sere
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}