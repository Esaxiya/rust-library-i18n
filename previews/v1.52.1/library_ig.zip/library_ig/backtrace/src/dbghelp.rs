//! Modulu iji nyere aka na ijikwa dbghelp njikọ na Windows
//!
//! Azụ azụ azụ na Windows (ma ọ dịkarịa ala maka MSVC) na-agbanye ike site na `dbghelp.dll` na ọrụ dị iche iche dị na ya.
//! Ọrụ ndị a na-ugbu a kwajuru *dynamically* kama ejikọ `dbghelp.dll` statically.
//! Nke a na-eme ugbu a site na ọkọlọtọ ọkọlọtọ (ma ọ bụ na tiori achọrọ ebe ahụ), mana ọ bụ mbọ iji nyere aka belata nkwado nke dll nke ọbá akwụkwọ ebe ọ bụ na azụghachi azụ bụ nhọrọ nhọrọ.
//!
//! N'ikwu ya, `dbghelp.dll` na-ebuwanye ibu na Windows mgbe niile.
//!
//! Rịba ama na ebe ọ bụ na anyị na-akwado nkwado a niile nke ukwuu, anyị enweghị ike iji nkọwapụta nkọwa na `winapi`, mana kama anyị kwesịrị ịkọwapụta ụdị pointer ọrụ ahụ n'onwe anyị ma jiri ya.
//! Anyị achọghị n'ezie ịnọ na azụmaahịa nke ịmegharị winapi, yabụ na anyị nwere atụmatụ Cargo nke `verify-winapi` nke na-ekwusi ike na njikọ niile kwekọrọ na winapi na arụ ọrụ a na CI.
//!
//! N'ikpeazụ, ị ga-achọpụta ebe a na dlll maka `dbghelp.dll` anaghị ebutu, nke ahụ dịkwa ụma ugbu a.
//! Echiche bụ na anyị nwere ike ịchekwa ụwa niile ma jiri ya n'etiti oku na API, na-ezere loads/unloads dị oke ọnụ.
//! Ọ bụrụ na nke a bụ nsogbu maka ndị na-ekpuchi mmiri ma ọ bụ ihe yiri nke a, anyị nwere ike ịgafe mmiri ahụ mgbe anyị ruru ebe ahụ.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Na-arụ ọrụ na `SymGetOptions` na `SymSetOptions` anaghị anọ na winapi n'onwe ya.
// Ma ọ bụghị ya, a na-eji ya naanị mgbe anyị na-enyocha ụdị abụọ megide winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Akọwapụtaghị ya na winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Nke a na-akọwa na winapi, ma ọ bụ na-ekwesịghị ịdị (FIXME winapi-td#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Akọwapụtaghị ya na winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// A na-eji igwe a akọwa kọwaa ihe `Dbghelp` nke dị n'ime ya nwere ihe ntụzi ọrụ niile anyị nwere ike ibu.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL a kwụrụ maka `dbghelp.dll`
            dll: HMODULE,

            // Nkọwapụta ọrụ ọ bụla maka ọrụ ọ bụla anyị nwere ike iji
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Na mbu anyi ebutabeghi DLL
            dll: 0 as *mut _,
            // Na mbu, atọrọ ọrụ niile na efu ka ha kwuo na ọ dị mkpa ibugharị ha.
            //
            $($name: 0,)*
        };

        // Mma typedef ọ bụla ọrụ ụdị.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Mgbalị ịmeghe `dbghelp.dll`.
            /// Laghachi ọganiihu ma ọ bụrụ na arụ ọrụ ma ọ bụ mperi ma ọ bụrụ na `LoadLibraryW` ada ada
            ///
            /// Panics ma ọ bụrụ na etinyelarị ọbá akwụkwọ.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Ọrụ maka usoro ọ bụla anyị chọrọ iji.
            // Mgbe a na-akpọ ya ga-agụ ma ọ bụ echekwa ọrụ pointer ma ọ bụ mara ya na weghachite na kwajuru uru.
            // A na-ekwupụta ibu dị iche iche iji nwee ihe ịga nke ọma.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy adaba iji kpochapu mkpọchi iji zoo ọrụ dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialize niile support mkpa iji ohere `dbghelp` API ọrụ site na nke a crate.
///
///
/// Cheta na ọrụ a bụ **mma**, ọ internally nwere ya mmekọrịta.
/// Marakwa na ọ dị mma ịkpọ ọrụ a ọtụtụ oge recursively.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Ihe mbụ anyị kwesịrị ime bụ gakọrịta ọrụ a.Enwere ike ịkpọ nke a n'otu oge site na eri ndị ọzọ ma ọ bụ recursively n'ime otu eri.
        // Rịba ama na ọ dị aghụghọ karịa nke ahụ n'ihi na ihe anyị na-eji ebe a, `dbghelp`,*kwa* kwesịrị ka emekọrịta ya na ndị ọzọ na-akpọ `dbghelp` na usoro a.
        //
        // Otutu enweghi otutu oku na `dbghelp` n'ime otu usoro a ma anyi nwere ike iche na anyi bu ndi na enweta ya.
        // Otú ọ dị, enwere onye ọrụ ndị ọzọ bụ isi anyị ga-echegbu onwe anyị banyere nke bụ onwe anyị, mana n'ọbá akwụkwọ ọkọlọtọ.
        // Ọbá akwụkwọ ọkọlọtọ Rust dabere na crate a maka nkwado backtrace, na crate a dịkwa na crates.io.
        // Nke a pụtara na ọ bụrụ na ọba akwụkwọ ọkọlọtọ na-ebipụta azụ panic ọ nwere ike ịgba ọsọ na crate a sitere na crates.io, na-akpata segfaults.
        //
        // Iji nyere aka dozie nsogbu mmekọrịta a, anyị jiri usoro aghụghọ Windows ebe a (ọ bụ, mgbe niile, mmachi Windows doro anya maka mmekọrịta).
        // Anyị mepụtara *nnọkọ-mpaghara* aha ya bụ mutex iji kpuchido oku a.
        // Ebumnuche ebe a bụ na ọbá akwụkwọ ọkọlọtọ na crate a enweghị ike ịkekọrịta Rust-larịị API iji mekọrịta ebe a mana enwere ike ịrụ ọrụ n'azụ usoro iji hụ na ha na-emekọrịta ihe.
        //
        // N'ụzọ ahụ mgbe akpọrọ ọrụ a site n'ọbá akwụkwọ ọkọlọtọ ma ọ bụ site na crates.io anyị nwere ike ijide n'aka na a na-enweta otu mutex ahụ.
        //
        // Yabụ na nke ahụ bụ ịsị na ihe mbụ anyị na-eme ebe a bụ na anyị mepụtara `HANDLE` nke bụ aha mutex na Windows.
        // Anyị mekọrịta a bit na ndị ọzọ eri na-ekere òkè ọrụ a kpọmkwem ma hụ na ọ bụ nanị otu ahụ na-kere kwa atụ nke ọrụ a.
        // Rịba ama na njikwa anaghị emechi emechi ozugbo ọ na-echekwa ya na ụwa.
        //
        // Anyị gachaa mkpọchi, anyị ga-enweta ya, ihe `Init` anyị nyefere ga-abụ ọrụ maka ịhapụ ya n'ikpeazụ.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Ugbu a anyị niile na-arụ ọrụ n'udo, ka anyị bido ịhazi ihe niile.
        // Nke mbu anyi kwesiri ijide n'aka na etinyegoro `dbghelp.dll` na usoro a.
        // Anyị na-eme nke a iji wee zere ịdabere kpamkpam.
        // Nke a mere eme e mere na-arụ ọrụ na gburugburu weird ojiji mbipụta na na-aduak na-eme Binaries a bit ọzọ obere ebe a bụ n'ụzọ dị ukwuu dị nnọọ a debugging mmekọ.
        //
        //
        // Ozugbo anyị meghere `dbghelp.dll`, anyị kwesịrị ịkpọ ụfọdụ ọrụ mmalite n'ime ya, nke ahụ zuru ezu karịa n'okpuru.
        // Naanị anyị na-eme nke a otu ugboro, yabụ na anyị nwere akwụkwọ ozi zuru ụwa ọnụ na-egosi ma anyị emezuola ma ọ bụ na anyị emebeghị.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Gbaa mbọ hụ na `SYMOPT_DEFERRED_LOADS` ọkọlọtọ atọrọ, n'ihi na dị ka MSVC onwe Docs banyere nke a: "This is the fastest, most efficient way to use the symbol handler.", ya mere, ka anyị na-eme nke ahụ!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // N'ezie ibido akara na MSVC.Rịba ama na nke a nwere ike ịda, mana anyị na-eleghara ya anya.
        // Enweghi otutu nka tupu nka a, ma LLVM dị n'ime ka oleghara anya nloghachi uru a ma otu n'ime ulo akwukwo ndi ozo na LLVM na-ebiputa ịdọ aka ná ntị na-atụ egwu ma ọ bụrụ na nke a ada ada kama ọ na-eleghara ya anya n'ikpeazụ.
        //
        //
        // Otu ihe nke a na-abịa ọtụtụ maka Rust bụ na ọbá akwụkwọ ọkọlọtọ na crate a na crates.io abụọ chọrọ ịsọ mpi maka `SymInitializeW`.
        // Ọbá akwụkwọ ọkọlọtọ ahụ chọrọ na mbido mgbe niile nhicha ahụ, mana ugbu a ọ na-eji crate a, ọ pụtara na mmadụ ga-ebu ụzọ bido onye nke ọzọ wee bulie mbido ahụ.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}