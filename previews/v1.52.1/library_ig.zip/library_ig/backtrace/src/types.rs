//! Dependentdị dabere na nyiwe.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Ihe ikpo okwu nke onwe nke uzo.
/// Mgbe ị na-arụ ọrụ na `std` nyeere ọ na-atụ aro ya ka mma ụzọ iji nye mgbanwe na ụdị `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Iberi, nke a na-enyekarị na nyiwe Unix.
    Bytes(&'a [u8]),
    /// Wide eriri na-esite na Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy na-atụgharị na `Cow<str>`, ga-ekenye ma ọ bụrụ na `Bytes` anaghị arụ ọrụ UTF-8 ma ọ bụ na `BytesOrWideString` bụ `Wide`.
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Enye a `Path` nnọchiteanya nke `BytesOrWideString`.
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}