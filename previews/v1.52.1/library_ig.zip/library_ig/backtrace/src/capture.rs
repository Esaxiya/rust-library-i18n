use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Nnọchi anya nke azụ azụ nwere na nke onwe.
///
/// Enwere ike iji usoro a weghachite azụ dị iche iche na mmemme ma mesịa jiri ya nyochaa ihe azụ ahụ dị n'oge ahụ.
///
///
/// `Backtrace` na-akwado ibipụta ọmarịcha azụ azụ site na ntinye `Debug` ya.
///
/// # Ihe ndị achọrọ
///
/// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Edepụtara okpokolo agba ebe a site n`elu ruo n`ala nke nchịkọta
    frames: Vec<BacktraceFrame>,
    // Ndenye ederede anyị kwenyere bụ mmalite nke azụ azụ, na-ewepụ osisi dị ka `Backtrace::new` na `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Ejiri ụdị osisi dị na azụ azụ.
///
/// Returneddị a laghachiri dị ka ndepụta site na `Backtrace::frames` ma na-anọchite anya otu okpokolo agba na azụ azụ azụ.
///
/// # Ihe ndị achọrọ
///
/// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Edere nsụgharị nke akara na azụ azụ.
///
/// Returneddị a laghachiri dị ka ndepụta site na `BacktraceFrame::symbols` ma na-anọchite anya metadata maka akara na azụ azụ.
///
/// # Ihe ndị achọrọ
///
/// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Na-ejide azụ azụ na oku a na-akpọ nke ọrụ a, weghachite ihe nnọchi anya enwere.
    ///
    /// Ọrụ a bara uru maka ịnọchite azụ azụ dị ka ihe na Rust.Enwere ike izipu uru a weghachitere gafee eri ma bipụta ya ebe ọzọ, ebumnuche nke uru a bụ ka enwere onwe ya kpamkpam.
    ///
    /// Rịba ama na na nyiwe ụfọdụ iji nweta nkwado zuru ezu ma dozie ya nwere ike ịbụ oke ọnụ.
    /// Ọ bụrụ na ọnụ ahịa dị ukwuu maka ngwa gị, a na-atụ aro ka ị jiri `Backtrace::new_unresolved()` nke na-ezere mkpebi mkpebi akara (nke na-ewekarị ogologo) ma na-enye ohere ịdebe ya na ụbọchị ọzọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // Achọrọ iji jide n'aka na e nwere ihe a etiti ebe wepụ
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Yiri `new` ewezuga na nke a anaghị edozi akara ọ bụla, nke a na-eweghachite azụ azụ dị ka ndepụta nke adreesị.
    ///
    /// Mgbe oge gachara enwere ike ịkpọ `resolve` ọrụ iji dozie akara ngosi azụ a na aha ndị agụrụ.
    /// Ọrụ a dị n'ihi na usoro mkpebi nwere ike were oge dị oke mkpa oge ụfọdụ ebe ọ bụla enwere ike ibipụta ọ bụla azụ azụ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // enweghị aha akara
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // aha akara ugbu a
    /// ```
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    ///
    #[inline(never)] // Achọrọ iji jide n'aka na e nwere ihe a etiti ebe wepụ
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Weghachite okpokolo agba site na mgbe enwetara azụ azụ a.
    ///
    /// Ntinye mbụ nke iberi a nwere ike ịbụ ọrụ `Backtrace::new`, na etiti ikpeazụ nwere ike ịbụ ihe gbasara etu eri a ma ọ bụ isi ọrụ si malite.
    ///
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Ọ bụrụ na e mepụtara azụ azụ a site na `new_unresolved` mgbe ahụ ọrụ a ga-edozi adreesị niile dị na azụ azụ na aha aha ha.
    ///
    ///
    /// Ọ bụrụ na edozila azụ azụ a ma ọ bụ mepụta ya site na `new`, ọrụ a anaghị eme ihe ọ bụla.
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Otu dika `Frame::ip`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Otu dị ka `Frame::symbol_address`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Otu dika `Frame::module_base_address`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Laghachi ndepụta akara nke etiti a kwekọrọ.
    ///
    /// Nọmalị enwere naanị otu akara na etiti ọ bụla, mana oge ụfọdụ ọ bụrụ na edepụtara ọtụtụ ọrụ n'ime otu etiti, ọtụtụ akara ga-alọghachite.
    /// Ihe akara mbu edeputara bu "innermost function", ebe akara nke ikpeazu bu nke di na azu (onye na agba oku ikpeazu).
    ///
    /// Rịba ama na ọ bụrụ na etiti a sitere na azụ azụ a na-edozighi ya, nke a ga-eweghachite ndepụta efu.
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Otu dika `Symbol::name`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Otu dika `Symbol::addr`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Otu dika `Symbol::filename`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Otu dika `Symbol::lineno`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Otu dika `Symbol::colno`
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Mgbe ị na-ebipụta ụzọ, anyị na-anwa iwepụ cwd ma ọ bụrụ na ọ dị, ma ọ bụghị na anyị bipụta ụzọ ahụ ka ọ dị.
        // Rịba ama na anyị na-eme nke a naanị maka usoro dị mkpirikpi, n'ihi na ọ bụrụ na ọ jupụtara, anyị ga-achọ ibipụta ihe niile.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}