#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Nhazi maka backtraces.
///
/// Typedị a nwere ike iji bipụta otu azụ azụ n'agbanyeghị agbanyeghị azụ azụ ahụ n'onwe ya.
/// Ọ bụrụ na ị nwere ụdị `Backtrace` mgbe ahụ mmejuputa `Debug` ya ejirila usoro mbipụta akwụkwọ a.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Stylesdị obibi akwụkwọ anyị nwere ike ibipụta
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Mbipụta a terser backtrace nke kwesịrị naanị nwere mkpa na ozi
    Short,
    /// Mbipụta a backtrace nke nwere ozi niile enwere ike
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Mepụta `BacktraceFmt` ọhụrụ nke ga-edepụta mmepụta na `fmt` enyere.
    ///
    /// Mkparịta ụka `format` ga-achịkwa ụdị a na-ebipụta azụ azụ, a ga-eji arụmụka `print_path` bipụta akwụkwọ `BytesOrWideString` nke filenames.
    /// Nke a na ụdị onwe ya adịghị eme ihe ọ bụla obibi akwụkwọ nke filenames, ma a na callback a chọrọ ime otú ahụ.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Mbipụta okwu mmalite maka azụ azụ nke a na-ebipụta.
    ///
    /// A choro nke a na ụfọdụ nyiwe maka azụ azụ iji gosipụta n'ụzọ zuru ezu ma emechaa, ma ọ bụghị nke a kwesịrị ịbụ usoro izizi ị na-akpọ mgbe ị mepụtara `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Na-agbakwụnye etiti na mbido azụ azụ.
    ///
    /// Nkwekorita a weghachitere ihe omuma nke RAII nke `BacktraceFrameFmt` nke enwere ike iji biputa ugbua, ma na nbibi o gha agbakwunye ogwe osisi.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Mezue mbuputa azu azu.
    ///
    /// Nke a bụ ugbu a na-a dịghị-op ma na-kwukwara maka future ndakọrịta na backtrace formats.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Ugbu a enweghi ihe-tinyere hook a iji nye ohere maka mgbakwunye future.
        Ok(())
    }
}

/// A formatter n'ihi na dị nnọọ otu etiti nke a backtrace.
///
/// Createddị `BacktraceFmt::frame` a na-emepụta ụdị a.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Mbipụta a `BacktraceFrame` na a etiti formatter.
    ///
    /// Nke a ga-ewepụta oge `BacktraceSymbol` niile n'ime `BacktraceFrame`.
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Mbipụta `BacktraceSymbol` n'ime `BacktraceFrame`.
    ///
    /// # Ihe ndị achọrọ
    ///
    /// Ọrụ a chọrọ ka enwee ihe `std` nke `backtrace` crate iji rụọ ọrụ, a na-enyekwa atụmatụ `std` na ndabara.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: nke a abụghị nnukwu ihe na anyị anaghị akwụsị ibipụta ihe ọ bụla
            // ya na aha ndi n` adighi utf8.
            // Obi dị m ụtọ na ihe niile bụ utf8 yabụ na nke a ekwesịghị ịdị oke njọ.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Mbipụta a raw chọpụtara `Frame` na `Symbol`, Elezie si n'ime raw callbacks nke a crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Na-agbakwunye a raw etiti na backtrace mmepụta.
    ///
    /// Usoro a, n'adịghị ka nke gara aga, na-ewe arụmụka enweghị isi ma ọ bụrụ na ha sitere na ọnọdụ dị iche iche.
    /// Mara na enwere ike ịkpọ ihe a ọtụtụ oge maka otu etiti.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Na-agbakwụnye, a raw etiti na backtrace mmepụta, gụnyere kọlụm ọmụma.
    ///
    /// Usoro a, dịka nke gara aga, na-ewe arụmụka enweghị isi ma ọ bụrụ na ha sitere na ọnọdụ dị iche iche.
    /// Mara na enwere ike ịkpọ ihe a ọtụtụ oge maka otu etiti.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia enweghị ike ịpụta n'ime usoro ya mere ọ nwere usoro pụrụ iche nke enwere ike iji gosipụta ma emesịa.
        // Bipute na kama ibi akwụkwọ adreesị anyị onwe anyị format ebe a.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ọ dịghị mkpa ka na-ebipụta "null" okpokolo agba, ya ihu ọma dị nnọọ pụtara na usoro backtrace bụ a bit ọkụ n'obi Chọpụta azụ super anya.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Iji belata ogo TCB na Sgx enclave, anyị achọghị itinye arụmọrụ mkpebi akara.
        // Kama nke ahụ, anyị nwere ike ibipụta mmebi nke adreesị ebe a, nke enwere ike ịde mapụ iji mezie ọrụ.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Bipụta ndeksi nke etiti yana ntuziaka ntuzi aka nke okpoko ahụ.
        // Ọ bụrụ na anyị na-na-na na n'ofè mbụ nnọchiteanya nke a etiti bụ ezie na anyị dị nnọọ ibipụta kwesịrị ekwesị whitespace.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Na-esote dee aha akara, jiri usoro ọzọ maka ozi ndị ọzọ ma ọ bụrụ na anyị bụ backtrace zuru ezu.
        // N'ebe a, anyị na-ejikwa akara ngosi ndị na-enweghị aha,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Na ikpeazu, bipụta nọmba filename/line ma ọ bụrụ na ha dị.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line na-e biri ebi na edoghi n'okpuru akara aha, ya mere, na-ebipụta ụfọdụ kwesịrị ekwesị whitespace idozi nke nri-mmezi onwe anyị.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // - Enyefe ndị anyị esịtidem callback ibipụta filename wee bipụta akara nọmba.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Tinye kọlụm nọmba, ma ọ dị.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Anyị na-eche naanị maka akara ngosi nke etiti
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}