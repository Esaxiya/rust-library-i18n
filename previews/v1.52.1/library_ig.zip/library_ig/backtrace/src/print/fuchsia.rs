use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr na-ewe oku na-akpọ oku nke ga-anata pointer dl_phdr_info maka DSO ọ bụla ejikọtara n'ime usoro ahụ.
    // dl_iterate_phdr na-emekwa ka o doo anya na akpọchiri onye na-agbanwe agbanwe site na mmalite ruo n'isi nke iteration.
    // Ọ bụrụ na oku na-akpọghachi azụghachi uru na-abụghị efu, iteration na-akwụsị n'isi.
    // 'data' ga-agafe dị ka arụmụka nke atọ na callback na oku ọ bụla.
    // 'size' na-enye nha dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Anyị kwesịrị ịkọwapụta ID ID na ụfọdụ isi usoro isi data nke pụtara na anyị chọrọ ntakịrị ihe si na ELF spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ugbu a, anyị ga-emegharị, ntakịrị maka ntakịrị, nhazi nke ụdị dl_phdr_info nke fuchsia na-arụ ọrụ ugbu a.
// Chromium nwekwara oke ABI a yana okpokoro.
// O doro anya na anyị ga-achọ ịkwaga ikpe ndị a iji jiri elf-search mana anyị ga-achọ ịnye ya na SDK ma emebeghị nke ahụ.
//
// N'ihi ya, anyị (na ha) na-rapaara na-enwe iji usoro a nke akpọ onye ahụ a uko njikọ na Fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Anyị enweghị ụzọ ịmara maka ịlele ma ọ bụrụ na e_phoff na e_phnum dị irè.
    // libc kwesiri ijide n'aka nke a maka anyi, ya mere o di mma iberi ebe a.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr na-anọchi anya isi ihe omume ELF 64-bit na atụmatụ nke ụlọ ọrụ ezubere iche.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr na-anọchite anya isi ihe omume ELF na ọdịnaya ya.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Anyị enweghị ụzọ ịlele ma ọ bụrụ na p_addr ma ọ bụ p_memsz dị irè.
    // Fuchsia si libc parses ndetu mbụ Otú ọ dị otú ahụ site n'onye ahụ nke na ịbụ ebe a ndị a nkụnye ndị eji isi mee ga-nti.
    //
    // Rịba ama na-achọghị ka data ahụ dị mkpa iji rụọ ọrụ mana ọ chọrọ ka ókè ga-adị ire.
    // Anyị tụkwasịrị obi na libc ahụ hụrụ na nke a bụ ikpe maka anyị ebe a.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Notedị ihe edeturu maka NJ ID.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr na-anọchi anya isi ihe ederede ELF na endianness nke lekwasịrị anya.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Rịba ama na-anọchi anya ihe ederede ELF (isi + ọdịnaya).
// Aha ahụ dị ka iberi u8 n'ihi na ọ bụghị mgbe niile ka ọ na-abaghị uru na-akwụsị ma rust na-eme ka ọ dị mfe iji lelee na bytes dakọtara na agbanyeghị.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter na-ahapụ gị ọfụma iterate na ihe edeturu nke.
// Ọ kwụsị dị ka anya dị ka njehie emee ma ọ bụ na e nweghị ndị ọzọ ndetu.
// Ọ bụrụ n `ị na-agabiga data na-abaghị uru ọ ga-arụ ọrụ dịka a ga-asị na enweghị ndekọ ọ bụla achọtara.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ọ bụ ihe na-agbanwe agbanwe nke ọrụ na ihe nrụpụta na nha enyere na-egosi oke mbido nke enwere ike ịgụ.
    // Ọdịnaya nke a bytes nwere ike ịbụ ihe ọ bụla ma nso ga-abụ nti maka nke a na-mma.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' ka 'to'-byte itinye n'ọnọdụ anya isi 'to' bụ a ike nke 2.
// Nke a na-agbaso ụkpụrụ ọkọlọtọ na C/C ++ ELF parsing code ebe (x + to, 1)&-to.
// Rust anaghị ekwe ka ị ghara iji ya mee ihe m ga-eji
// Ntughari nke 2 iji megharia nke ahu.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 na-erepịakwa num bytes si iberi (ma ọ bụrụ na ugbu a) na Ọzọkwa ana achi achi na ikpeazụ iberi na-n'ụzọ zuru ezu kwekọọ.
// Ọ bụrụ na ọnụọgụ abụọ nke bytes rịọrọ buru oke ibu ma ọ bụ na enweghị ike ịhazi ya ma emesịa n'ihi enweghị izu nke fọdụrụnụ, ọnweghị onye eweghachitere na ọnaghị edezi.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ọrụ a enweghi ezigbo ndị na-akpọ oku ga-akwadoo ọzọ karịa ikekwe na 'bytes' kwesịrị ịhazi maka arụmọrụ (yana ụfọdụ ụkpụrụ ụlọ).
// Valueskpụrụ dị na mpaghara Elf_Nhdr nwere ike ịbụ ihe nzuzu mana ọrụ a anaghị ekwenye ụdị ihe ahụ.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Nke a dị mma ma ọ bụrụhaala na enwere ohere zuru oke ma anyị gosipụtara na ọ bụrụ na nkwupụta a dị n'elu, nke a ekwesịghị ịbụ ihe na-adịghị mma.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Rịba ama na sice_of: :<Elf_Nhdr>() mgbe niile 4-byte kwekọọ.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Lelee ma ọ bụrụ na anyị eruola ọgwụgwụ.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Anyị na-agbanwe nhdr mana anyị ji nlezianya tụlee nsonaazụ ahụ.
        // Anyị na-adịghị atụkwasị obi namesz ma ọ bụ descsz na anyị na-eme ọ dịghị nwedịrị ike ịta mkpebi ndị dabeere na ụdị.
        //
        // Yabụ ọbụlagodi na anyị ga-esipụta mkpofu zuru oke anyị ga-anọrịrị na nchekwa.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Gosiputa na otu nke wu.
const PERM_X: u32 = 0b00000001;
/// Gosiputa na enwere ike ideputa otu nke ederede.
const PERM_W: u32 = 0b00000010;
/// Na-egosi na otu nke ogugu.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Na-anọchi anya akụkụ ELF n'oge oge.
struct Segment {
    /// Na-enye Oge ojigoro mebere adreesị nke a nke ọdịnaya.
    addr: usize,
    /// Na-enye ebe nchekwa nke akụkụ a.
    size: usize,
    /// Na-enye modul mebere adres nke akụkụ a na faịlụ ELF.
    mod_rel_addr: usize,
    /// Na-enye ikikere dị na faịlụ ELF.
    /// Ikikere ndị a abughi ikikere ndị enyere n'oge oge.
    flags: Perm,
}

/// Na-ahapụ onye weghachite ngalaba site na DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Na-anọchi anya ELF DSO (Ebumnuche Ekekọrịta Dynamic).
/// Typedị a na-ezo aka na data echekwara na DSO n'ezie karịa ịme nke ya.
struct Dso<'a> {
    /// Ihe njikọ dị omimi na-enye anyị aha mgbe niile, ọbụlagodi na aha ya bụ ihe efu.
    /// N'ihe banyere ndị isi aha ya ga-abụ ihe efu.
    /// Na ikpe nke a na-akọrọ ihe ọ ga-abụ soname (lee DT_SONAME).
    name: &'a str,
    /// Na Fuchsia fọrọ nke nta ka ọ bụrụ ọnụọgụ abụọ niile nwere NJ NJ mana nke a abụghị ihe nkwụghachi ụgwọ siri ike.
    /// Enweghị ụzọ iji kwekọọ ozi DSO na ezigbo ELF faịlụ ma ọ bụrụ na enweghị mgbidi_id ka anyị wee chọọ ka DSO ọ bụla nwee ebe a.
    ///
    /// DSO si enweghị a build_id na-eleghara anya.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Weghachite onye na-ede akwụkwọ ihe gbasara ngalaba na DSO a.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Njehie ndị a encode mbipụta na ibilite mgbe parsing ọmụma banyere onye ọ bụla DSO.
///
enum Error {
    /// NameError n'aka na njehie mere mgbe n'ịtụgharị a C style eriri n'ime a rust eriri.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError pụtara na anyị ahụghị a Mee ID.
    /// Nke a nwere ike ịbụ n'ihi na DSO enweghị iwu ID ma ọ bụ n'ihi na akụkụ nke nwere ID ID adịghịzi mma.
    ///
    BuildIDError,
}

/// Kpọọ ma 'dso' ma ọ bụ 'error' maka DSO ọ bụla jikọtara n'ime usoro ahụ site na njikọ njikọ dị ike.
///
///
/// # Arguments
///
/// * `visitor` - A DsoPrinter nke ga-enwe otu n'ime nri eri akpọrọ foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ana achi achi na info.name ga-arutu aka n`ebe di nma.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ọrụ a na-ebipụta akara akara Fuchsia maka ozi niile dị na DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}