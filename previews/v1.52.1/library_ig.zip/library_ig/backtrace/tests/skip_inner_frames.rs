use backtrace::Backtrace;

// Nnwale a na-arụ ọrụ naanị na nyiwe nke nwere ọrụ `symbol_address` na-arụ ọrụ maka okpokolo agba nke na-akọ akụkọ mmalite nke akara.
// N'ihi ya, ọ bụ naanị enyere ya aka na ntanetị ole na ole.
//
const ENABLED: bool = cfg!(all(
    // Windows anwalebeghị nke ọma, OSX anaghị akwado ịchọta ụlọ mkpuchi, gbanyụọ nke a
    //
    target_os = "linux",
    // On ARM ịchọta gbaa ọrụ a bụ naanị na-alọta na ip onwe ya.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}