# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Ọbá akwụkwọ iji nweta azụ azụ n'oge na-agba ọsọ maka Rust.
Ọbá akwụkwọ a na-achọ ịkwalite nkwado nke ọbá akwụkwọ ọkọlọtọ site na ịnye usoro mmemme iji rụọ ọrụ, mana ọ na-akwadokwa nfe nke ugbu a dị ka libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Iji nanị weghara a backtrace na ibuti emeso ya ruo mgbe a gasịrị oge, i nwere ike iji n'elu-larịị `Backtrace` ụdị.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Agbanyeghị, ọ bụrụ n'ịchọrọ ị nweta nnweta nweta ọrụ nsụgharị n'ezie, ịnwere ike iji ọrụ `trace` na `resolve` ozugbo.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Edozi ntuziaka a maka akara ngosi
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // na-aga na-esote eku
    });
}
```

# License

A na-enye ikikere oru a n'okpuru nke obula

 * Apache License, Versiondị 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ma ọ bụ http://www.apache.org/licenses/LICENSE-2.0)
 * MIT ikike ([LICENSE-MIT](LICENSE-MIT) ma ọ bụ http://opensource.org/licenses/MIT)

na nhọrọ gị.

### Contribution

Ọ gwụla ma ị kwupụtara n'ụzọ doro anya, onyinye ọ bụla ebumnuche wepụtara maka itinye na azụ azụ-site n'aka gị, dị ka akọwapụtara na ikikere Apache-2.0, ga-enwe ikikere abụọ dị ka nke dị n'elu, na-enweghị usoro ma ọ bụ ọnọdụ ọ bụla ọzọ.







