#![feature(no_core)]
#![no_core]

// Hụ rustc-std-workspace-core maka ihe kpatara eji chọọ crate a.

// Kpọgharia aha na crate iji zere esemokwu na modul e kenyere na liballoc.
extern crate alloc as foo;

pub use foo::*;