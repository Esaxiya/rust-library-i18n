# Na-enye aka na stdarch

The `stdarch` crate bụ karịa njikere ịnakwere onyinye!Nke mbu ị nwere ike ịchọ ịchọpụta ebe nchekwa ahụ ma gbaa mbọ hụ na ule gafere gị:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Ebe `<your-target-arch>` bu uzo ato dika `rustup` jiri, dika `x86_x64-unknown-linux-gnu` (n`enweghi `nightly-` ma obu ihe yiri ya).
Chetakwa na ebe nchekwa a chọrọ ọwa abalị nke Rust!
Ule ndị a dị n'elu na-achọ n'ezie rust kwa abalị ka ọ bụrụ ndabara na sistemụ gị, iji setịpụ jiri `rustup default nightly` (yana `rustup default stable` ịlaghachite).

Ọ bụrụ na nke ọ bụla n'ime usoro ndị dị n'elu anaghị arụ ọrụ, [please let us know][new]!

Na-esote ị nwere ike [find an issue][issues] iji nyere aka, anyị ahọrọla ole na ole na mkpado [`help wanted`][help] na [`impl-period`][impl] nke nwere ike iji ụfọdụ enyemaka. 
Nwere ike inwe mmasị na [#40][vendor], na-emejuputa ihe niile na-ere na x86.Okwu a nwere ezigbo akara aka ebe aga-amalite!

Ọ bụrụ n`inwee ajụjụ izugbe gbasara [join us on gitter][gitter] ma jụọ ajụjụ!Enwere ike ị ping ma@BurntSushi ma ọ bụ@alexcrichton nwere ajụjụ.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Olee otú dee ihe atụ maka stdarch intrinsics

E nwere ihe ole na ole a ga-nyeere n'ihi nyere intrinsic arụ ọrụ kwesịrị ekwesị na ihe atụ ga na-agba ọsọ site `cargo test --doc` mgbe mma a na-akwado site na CPU.

N'ihi ya, ndabara `fn main` na-eme site `rustdoc` ga-arụ ọrụ (na ọtụtụ ikpe).
Tụlee eji ndị na-esonụ dị ka ihe nduzi iji hụ na gị atụ ọrụ dị ka na-atụ anya.

```rust
/// # // Anyị chọrọ cfg_target_feature iji hụ na ihe atụ ahụ bụ naanị
/// # // na-agba ọsọ site `cargo test --doc` mgbe CPU na-akwado atụmatụ ahụ
/// # #![feature(cfg_target_feature)]
/// # // Anyị kwesịrị target_feature maka intrinsic na-arụ ọrụ
/// # #![feature(target_feature)]
/// #
/// # // rustdoc jiri ndabara jiri `extern crate stdarch`, mana anyi choro
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Ezigbo ọrụ
/// # fn main() {
/// #     // Naanị mee nke a ma ọ bụrụ na akwado `<target feature>`
/// #     ma ọ bụrụ na cfg_feature_enabled! (""<target feature>"){
/// #         // Mepụta ọrụ `worker` nke ga-agba naanị ma ọ bụrụ na atụmatụ ahụ echere
/// #         // na-akwado ma hụ na enyere `target_feature` aka maka onye ọrụ gị
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         eche nche fn worker() {
/// // Dee ihe atụ gị ebe a.Njirimara akọwapụtara ga-arụ ọrụ ebe a!Gaa n'ọhịa!
///
/// #         }
///
/// #         echekwabara { worker(); }
/// #     }
/// # }
```

Ọ bụrụ na ụfọdụ n'ime n'elu syntax adịghị anya maara, ndị [Documentation as tests] ngalaba nke [Rust Book] akọwa `rustdoc` syntax nnọọ nke ọma.
Dị ka mgbe niile, na-eche free ka [join us on gitter][gitter] na-ajụ anyị ma ọ bụrụ na ị kụrụ ọ bụla snags, na-ekele gị maka inyere ka mma na akwụkwọ nke `stdarch`!

# Ntuziaka Ule ozo

Ọ na-adịkarị na-atụ aro na ị na-eji `ci/run.sh` na-agba ọsọ ule.
Agbanyeghị nke a nwere ike ọ gaghị arụ ọrụ maka gị, dịka ọ bụrụ na ịnọ na Windows.

N'okwu ahụ, ị nwere ike ịlaghachi na-agba ọsọ `cargo +nightly test` na `cargo +nightly test --release -p core_arch` maka ịnwale ọgbọ koodu.
Cheta na ndị a na-achọ ndị nightly toolchain na-arụnyere na `rustc` mara banyere gị iche atọ na ya CPU.
Karịsịa ị chọrọ ka ndị `TARGET` gburugburu ebe obibi agbanwe ka ị ga-maka `ci/run.sh`.
Na mgbakwunye na ị chọrọ ka `RUSTCFLAGS` (mkpa na `C`) na-egosi iche atụmatụ, eg `RUSTCFLAGS="-C -target-features=+avx2"`.
I nwekwara ike ịtọ `-C -target-cpu=native` ma ọ bụrụ na ị na-"just" emepe emepe megide CPU gị dị ugbu a.

Ike dọrọ aka ná ntị na mgbe ị na-eji ndị a ọzọ ntuziaka, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], eg
Ntụle ọgbọ nkuzi nwere ike ịda n'ihi na onye ọkpọ ahụ kpọbara ha aha dị iche, dịka ọmụmaatụ
ọ nwere ike n'ịwa `vaesenc` kama `aesenc` ntụziaka n'agbanyeghị ha ime otu ihe ahụ.
Ntuziaka ndị a na-eme obere ule karịa ka a ga-eme, ya atụla ya n'anya na mgbe ị mechara rịọ-rịọ ụfọdụ njehie nwere ike igosi maka ule anaghị ekpuchi ebe a.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






