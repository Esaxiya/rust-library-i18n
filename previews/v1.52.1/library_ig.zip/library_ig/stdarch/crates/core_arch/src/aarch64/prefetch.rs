#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Hụ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Hụ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Hụ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Hụ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Hụ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Hụ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Ozi kpọtara ndị cache akara na e dere okwu `p` iji nyere `rw` na `locality`.
///
/// `rw` ga-abụrịrị otu n'ime:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): prefetch na-akwado maka ọgụgụ.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): na prefetch na-akwadebe maka a dee.
///
/// `locality` ga-abụrịrị otu n'ime:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Gụgharia ma ọ bụ na-abụghị anụ ahụ prefetch, maka data ejiri mee naanị otu oge.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Bata n'ime ọkwa 3.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Bata n'ime ọkwa 2 cache.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Bata n'ime ọkwa 1 cache.
///
/// Ntuziaka ncheta prefetch na-egosi na usoro nchekwa nke ebe nchekwa na-enweta site na adreesị a kapịrị ọnụ nwere ike ime na nso future.
/// The ebe nchekwa usoro nwere ike ikwu site na-ewere omume na-atụ anya na-adị n'elu ebe nchekwa ohere mgbe ha na-eme, dị ka preloading na kwuru kpọmkwem adreesị n'ime otu ma ọ bụ karịa caches.
///
/// N'ihi na ndị a n'ókè bụ naanị mma, ọ bụ irè n'ihi na a akpan akpan CPU na-emeso ọ bụla ma ọ bụ niile prefetch ntuziaka ka a NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Anyị na-eji `llvm.prefetch` instrinsic nwere `cache type` =1 (nchekwa data).
    // `rw` na `strategy` na-adabere na njirimara ọrụ.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}