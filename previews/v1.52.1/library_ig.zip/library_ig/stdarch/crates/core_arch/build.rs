use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Na-agwa anyị `#[assert_instr]` annotations na niile simd intrinsics dị nwalee ha codegen, ebe ụfọdụ na-gbara n'azụ ihe mmezi `-Ctarget-feature=+unimplemented-simd128` nke na-enweghị ihe ọ bụla Ẹkot na `#[target_feature]` ugbu a.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}