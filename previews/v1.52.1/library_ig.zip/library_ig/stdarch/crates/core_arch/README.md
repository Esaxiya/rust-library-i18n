`core::arch` - Rust bụ isi ọbá akwụkwọ na-arụ ọrụ n'ime ụlọ
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

The `core::arch` modul achụ nta ije-dabere intrinsics (eg SIMD).

# Usage 

`core::arch` dị dị ka akụkụ nke `libcore` na ọ na-ebupụ ya ọzọ site `libstd`.Ahọrọ iji ya via `core::arch` ma ọ bụ `std::arch` karịa via a crate.
Ejighị n'aka ndị na-emekarị dị na nightly Rust site na `feature(stdsimd)`.

Iji `core::arch` site na crate a chọrọ Rust abalị, ọ nwere ike (ma mee) gbajie oge.The naanị mgbe na nke ị na kwesịrị ịtụle iji ya site na nke a crate bụ:

* ma ọ bụrụ na ị chọrọ re-chịkọtara `core::arch` onwe gị, wdg., akpan akpan lekwasịrị-atụmatụ nyeere na-adịghị nyeere maka `libcore`/`libstd`.
Note: ma ọ bụrụ na ị chọrọ re-ide ya maka a abụghị ọkọlọtọ iche, biko na-ahọrọ iji `xargo` na re-chikota `libcore`/`libstd` dị ka ihe kwesịrị ekwesị kama iji nke a crate.
  
* iji ụfọdụ ndị na-nwere ike ọgaghị ọbụna n'azụ ejighị n'aka Rust atụmatụ.Anyị na-agbalị mee ka ihe a ka a kacha nta.
Ọ bụrụ na ị chọrọ iji ụfọdụ atụmatụ ndị a, biko na-emeghe otu ihe iseokwu nke mere na anyị nwere ike itinye ha na nightly Rust na ị nwere ike iji ha n'ebe ahụ.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` A na-ekesa n'ụzọ dị n'okpuru usoro nke ma ikike MIT na Apache License (Version 2.0), yana akụkụ nke akwụkwọ ikike BSD dị iche iche kpuchiri.

Lee LICENSE-APACHE, yana LICENSE-MIT maka nkọwa.

# Contribution

Ọ bụrụ na gị n'ụzọ doro anya obodo ma, ọ bụla onyinye ụma osụk n'ihi na Nsonye na `core_arch` site na gị, dị ka a kọwara ya n'ime Apache-2.0 ikike, ga-sọrọ ikikere dị ka n'elu, enweghị ihe ọ bụla ọzọ na okwu ma ọ bụ ọnọdụ.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












