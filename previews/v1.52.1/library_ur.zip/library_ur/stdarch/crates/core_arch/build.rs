use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // ہمارے `#[assert_instr]` تشریحات کو یہ بتانے کے لئے استعمال کیا جاتا ہے کہ ان کے کوڈجن کو جانچنے کے لئے تمام سم انڈنسکس دستیاب ہیں ، کیوں کہ کچھ ایک اضافی `-Ctarget-feature=+unimplemented-simd128` کے پیچھے تیار ہیں جس کا ابھی `#[target_feature]` میں کوئی مساوی نہیں ہے۔
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}