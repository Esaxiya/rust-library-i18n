`core::arch` - Rust کی بنیادی لائبریری فن تعمیر سے متعلق مخصوص داخلیات
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` ماڈیول فن تعمیر پر منحصر انٹنکس (جیسے سمڈ) کا اطلاق کرتا ہے۔

# Usage 

`core::arch` `libcore` کے حصے کے طور پر دستیاب ہے اور `libstd` کے ذریعہ اسے دوبارہ برآمد کیا جاتا ہے۔اس crate کے بجائے `core::arch` یا `std::arch` کے ذریعے اسے استعمال کرنے کو ترجیح دیں۔
غیر مستحکم خصوصیات اکثر رات کے Rust میں `feature(stdsimd)` کے ذریعہ دستیاب ہوتی ہیں۔

اس crate کے توسط سے `core::arch` کا استعمال کرنے کے لئے رات کے وقت Rust کی ضرورت ہوتی ہے ، اور یہ اکثر (اور کرتا ہے) ٹوٹ سکتا ہے۔واحد معاملات جن میں آپ کو اس crate کے توسط سے استعمال کرنے پر غور کرنا چاہئے:

* اگر آپ کو خود `core::arch` دوبارہ مرتب کرنے کی ضرورت ہے ، مثلا، ، خاص اہداف کی خصوصیات کے ساتھ جو `libcore`/`libstd` کے لئے اہل نہیں ہیں۔
Note: اگر آپ کو اسے غیر معیاری ہدف کے لئے دوبارہ مرتب کرنے کی ضرورت ہے تو ، براہ کرم اس crate کو استعمال کرنے کے بجائے `xargo` اور `libcore`/`libstd` کو دوبارہ مرتب کرنے کو ترجیح دیں۔
  
* کچھ ایسی خصوصیات کا استعمال کرنا جو شاید غیر مستحکم Rust خصوصیات کے پیچھے بھی دستیاب نہ ہوں۔ہم ان کو کم سے کم رکھنے کی کوشش کرتے ہیں۔
اگر آپ کو ان میں سے کچھ خصوصیات کو استعمال کرنے کی ضرورت ہے تو ، براہ کرم کوئی مسئلہ کھولیں تاکہ ہم انہیں رات کے Rust میں بے نقاب کرسکیں اور آپ انہیں وہاں سے استعمال کرسکیں۔

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` بنیادی طور پر ایم آئی ٹی لائسنس اور Apache لائسنس (ورژن 2.0) دونوں کی شرائط کے تحت تقسیم کیا جاتا ہے ، جس میں بی ایس ڈی جیسے لائسنسوں کے کچھ حصے شامل ہیں۔

تفصیلات کے لئے لائسنس۔ APachE ، اور لائسنس MIT دیکھیں۔

# Contribution

جب تک کہ آپ واضح طور پر بیان نہیں کرتے ہیں ، آپ کی طرف سے `core_arch` میں شمولیت کے لئے جان بوجھ کر پیش کی جانے والی کوئی بھی شراکت ، جیسا کہ Apache-2.0 لائسنس میں بیان کیا گیا ہے ، بغیر کسی اضافی شرائط و ضوابط کے ، اوپر کی طرح دوہری لائسنس یافتہ ہوگا۔


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












