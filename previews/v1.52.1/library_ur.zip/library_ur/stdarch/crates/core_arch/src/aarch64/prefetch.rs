#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) دیکھیں۔
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) دیکھیں۔
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) دیکھیں۔
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) دیکھیں۔
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) دیکھیں۔
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) دیکھیں۔
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// کیچ لائن حاصل کریں جس میں دیئے گئے `rw` اور `locality` کا استعمال کرکے پتہ `p` ہو۔
///
/// `rw` میں سے ایک ہونا ضروری ہے:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): پریفیکچ پڑھنے کی تیاری کر رہا ہے۔
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): پریفیکچ لکھنے کی تیاری کر رہا ہے۔
///
/// `locality` میں سے ایک ہونا ضروری ہے:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): صرف ایک بار استعمال ہونے والے ڈیٹا کے ل St ، سلسلہ بندی یا غیر دنیاوی پریفیکیچ۔
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): سطح 3 کیشے میں لائیں۔
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): سطح 2 کیشے میں لائیں۔
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): سطح 1 کیشے میں لائیں۔
///
/// پریفٹچ میموری ہدایات میموری سسٹم کی طرف اشارہ کرتی ہیں کہ کسی مخصوص پتے سے میموری تک رسائی ممکنہ طور پر زیڈ فیوچر0 زیڈ میں واقع ہوجاتی ہے۔
/// میموری سسٹم ان اقدامات کے ذریعہ ردعمل دے سکتا ہے جس کی توقع کی جاتی ہے کہ جب وہ رونما ہوتے ہیں تو میموری تک رسائی میں تیزی آجاتی ہے ، جیسے ایک یا زیادہ کیچوں میں مخصوص ایڈریس کو پہلے سے لوڈ کرنا۔
///
/// چونکہ یہ اشارے صرف اشارے ہیں ، لہذا یہ کسی خاص سی پی یو کے لئے کسی بھی یا تمام پیشگی ہدایات کو بطور این او پی سلوک کرنا درست ہے۔
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // ہم `llvm.prefetch` ایکس 1 (ڈیٹا کیشے) کے ساتھ `llvm.prefetch` انسٹرسنک کا استعمال کرتے ہیں۔
    // `rw` اور `strategy` فنکشن پیرامیٹرز پر مبنی ہیں۔
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}