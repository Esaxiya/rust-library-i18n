# stdarch میں شراکت

`stdarch` crate شراکت کو قبول کرنے کے لئے تیار سے زیادہ ہے!پہلے آپ غالبا the ذخیرے کو چیک کرنا چاہتے ہیں اور اس بات کو یقینی بنانا چاہتے ہیں کہ آپ کے پاس ٹیسٹ گزرے:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

جہاں `<your-target-arch>` ہدف ٹرپل ہے جیسے `rustup` استعمال کیا جاتا ہے ، جیسے `x86_x64-unknown-linux-gnu` (بغیر کسی سابقہ `nightly-` یا اس جیسے) کے۔
یہ بھی یاد رکھیں کہ اس ذخیرے میں Rust کے رات کے چینل کی ضرورت ہے!
مندرجہ بالا ٹیسٹ درحقیقت رات کے rust کو آپ کے سسٹم میں پہلے سے طے شدہ بننے کی ضرورت ہوتی ہے ، اس کو سیٹ کرنے کے لئے کہ `rustup default nightly` (اور `rustup default stable` کو واپس لائیں)۔

اگر مذکورہ بالا اقدامات میں سے کوئی بھی کام نہیں کرتا ہے تو ، [please let us know][new]!

اگلے میں آپ [find an issue][issues] پر مدد کرسکیں ، ہم نے [`help wanted`][help] اور [`impl-period`][impl] ٹیگز کے ساتھ کچھ منتخب کیے ہیں جو خاص طور پر کچھ مدد استعمال کرسکتے ہیں۔ 
آپ [#40][vendor] میں سب سے زیادہ دلچسپی رکھتے ہوسکتے ہیں ، x86 پر تمام وینڈر انٹرنس کو لاگو کرتے ہیں۔اس مسئلے کو کچھ اچھ poinا اشارہ مل گیا ہے جہاں سے شروعات کی جا!!

اگر آپ کے پاس عمومی سوالات آزادانہ طور پر [join us on gitter][gitter] پر ہیں اور آس پاس سے پوچھتے ہیں!سوالات کے ساتھ یا تو@برنٹ سوشی یاalexcrichton کو پنگ کرنے کے لئے آزاد محسوس کریں۔

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# اسٹارڈارک داخلیات کے ل examples مثال کیسے لکھیں

کچھ خصوصیات ہیں جن کو دیئے ہوئے اندرونی کام کو مناسب طریقے سے کام کرنے کے ل enabled فعال ہونا چاہئے اور مثال کے طور پر صرف `cargo test --doc` کے ذریعہ چلانی چاہئے جب اس خصوصیت کو سی پی یو کے ذریعہ سپورٹ کیا گیا ہو۔

نتیجے کے طور پر ، `rustdoc` کے ذریعہ تیار کردہ ڈیفالٹ `fn main` کام نہیں کرے گا (زیادہ تر معاملات میں)۔
توقع کے مطابق اپنی مثال کے کام کرنے کو یقینی بنانے کے لئے مندرجہ ذیل رہنما کو بطور رہنما استعمال کرنے پر غور کریں۔

```rust
/// # // ہمیں cfg_target_feचर کی ضرورت ہے تاکہ یہ یقینی ہو کہ مثال صرف ہے
/// # // `cargo test --doc` کے ذریعہ چلائیں جب سی پی یو خصوصیت کی حمایت کرتا ہے
/// # #![feature(cfg_target_feature)]
/// # // ہمیں کام کرنے کے لئے اندرونی اہداف کی ضرورت ہے
/// # #![feature(target_feature)]
/// #
/// # // بذریعہ rustdoc `extern crate stdarch` استعمال کرتا ہے ، لیکن ہمیں اس کی ضرورت ہے
/// # // `#[macro_use]`
/// # # [میکرو_یوز] بیرونی crate stdarch؛
/// #
/// # // اصل مرکزی تقریب
/// # fn main() {
/// #     // صرف اس صورت میں چلائیں اگر `<target feature>` کی سہولت حاصل ہو
/// #     اگر cfg_feature_enabled! ("<target feature>"){
/// #         // ایک `worker` فنکشن بنائیں جو صرف اس صورت میں چلائے جائیں گے جب ہدف کی خصوصیت ہو
/// #         // تعاون یافتہ ہے اور یہ یقینی بناتا ہے کہ آپ کے کارکن کے لئے `target_feature` فعال ہے
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         غیر محفوظ FN worker() {
/// // اپنی مثال یہاں لکھیں۔خصوصیت کی مخصوص انٹرنس یہاں کام کرے گی!جنگلی جاؤ!
///
/// #         }
///
/// #         غیر محفوظ { worker(); }
/// #     }
/// # }
```

اگر مذکورہ بالا ترکیب میں سے کچھ واقف نظر نہیں آتا ہے تو ، [Rust Book] کا [Documentation as tests] سیکشن `rustdoc` نحو کو کافی اچھی طرح سے بیان کرتا ہے۔
ہمیشہ کی طرح ، [join us on gitter][gitter] کے بارے میں آزاد محسوس کریں اور ہم سے پوچھیں کہ کیا آپ نے کوئی چھینٹا مارا ہے ، اور `stdarch` کی دستاویزات کو بہتر بنانے میں مدد کرنے کے لئے آپ کا شکریہ!

# متبادل جانچ کی ہدایات

عام طور پر یہ تجویز کی جاتی ہے کہ آپ ٹیسٹ چلانے کے لئے `ci/run.sh` استعمال کریں۔
تاہم ، یہ آپ کے ل work کام نہیں کرے گا ، مثال کے طور پر اگر آپ Windows پر ہیں۔

اس صورت میں آپ کوڈ جنریشن کی جانچ کے لئے `cargo +nightly test` اور `cargo +nightly test --release -p core_arch` چلانے میں واپس آسکتے ہیں۔
نوٹ کریں کہ اس کے لئے آپ کو رات کے ٹولچین کو انسٹال کرنا ہوتا ہے اور `rustc` کو آپ کے ہدف ٹرپل اور اس کے سی پی یو کے بارے میں جاننا ہو گا۔
خاص طور پر آپ کو `TARGET` ماحول متغیر ترتیب دینے کی ضرورت ہے جیسا کہ آپ `ci/run.sh` کے لئے کرتے ہو۔
اس کے علاوہ آپ کو اہداف کی خصوصیات کی نشاندہی کرنے کے لئے `RUSTCFLAGS` (`C` کی ضرورت ہے) بھی ترتیب دینے کی ضرورت ہے ، جیسے `RUSTCFLAGS="-C -target-features=+avx2"`.
اگر آپ اپنے موجودہ CPU کے خلاف "just" تیار کررہے ہیں تو آپ `-C -target-cpu=native` بھی مرتب کرسکتے ہیں۔

خبردار کیا جائے کہ جب آپ یہ متبادل ہدایات استعمال کرتے ہیں تو ، [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] ، جیسے
انسٹرکشن جنریشن ٹیسٹ ناکام ہوسکتے ہیں کیونکہ جدا کرنے والے نے ان کا نام مختلف رکھا ہے ، جیسے
یہ ایک جیسے سلوک کرنے کے باوجود `vaesenc` ہدایات کی بجائے `vaesenc` تیار کرسکتا ہے۔
نیز یہ ہدایات عام طور پر کیے جانے والے ٹیسٹ کے مقابلے میں کم تجربات انجام دیتی ہیں ، لہذا حیرت نہ کریں کہ جب آپ بالآخر پل-گذارش کریں گے تو یہاں کچھ احاطہ نہیں کیے گئے ٹیسٹوں کے ل some کچھ غلطیاں ظاہر ہوسکتی ہیں۔

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






