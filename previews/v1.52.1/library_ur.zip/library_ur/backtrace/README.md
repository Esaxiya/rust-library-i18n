# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust کیلئے رن ٹائم کے وقت بیکٹریس حاصل کرنے کے لئے ایک لائبریری۔
اس لائبریری کا مقصد ہے کہ اس کے ساتھ کام کرنے کے لئے ایک پروگرامی انٹرفیس فراہم کرکے معیاری لائبریری کی مدد کو بڑھانا ، لیکن اس کی مدد سے آسانی سے موجودہ بیک ٹریس کو آسانی سے چھپانا بھی پڑتا ہے جیسے لیبسٹڈ کے زیڈ 0 پیانکس0 زیڈ۔

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

کسی بیک ٹریس پر قبضہ کرنے اور بعد میں آنے تک اس سے نمٹنے کیلئے موخر کرنے کے ل you ، آپ اعلی درجے کی `Backtrace` ٹائپ استعمال کرسکتے ہیں۔

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

اگر ، تاہم ، آپ کو ٹریسنگ کی اصل فعالیت تک زیادہ خام رسائی حاصل کرنا چاہتے ہیں تو ، آپ `trace` اور `resolve` افعال کو براہ راست استعمال کرسکتے ہیں۔

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // اس ہدایت نامہ کو کسی علامت کے نام پر حل کریں
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // اگلے فریم میں جاتے رہیں
    });
}
```

# License

اس منصوبے میں سے کسی ایک کے تحت لائسنس ہے

 * Apache لائسنس ، ورژن 2.0 ، ([LICENSE-APACHE](LICENSE-APACHE) یا http://www.apache.org/licenses/LICENSE-2.0)
 * MIT لائسنس ([LICENSE-MIT](LICENSE-MIT) یا http://opensource.org/licenses/MIT)

آپ کے اختیار پر

### Contribution

جب تک آپ واضح طور پر بیان نہیں کرتے ہیں ، Apache-2.0 لائسنس میں بیان کردہ ، آپ کے ذریعہ بیک ٹریس آر ایس میں شمولیت کے لئے جان بوجھ کر پیش کی جانے والی کوئی بھی شراکت ، بغیر کسی اضافی شرائط و ضوابط کے ، اوپر کی طرح دوہری لائسنس یافتہ ہوگی۔







