//! libbacktrace میں DWARF-parsing کوڈ کا استعمال کرتے ہوئے علامتی حکمت عملی۔
//!
//! لب بیکٹریس سی لائبریری ، عام طور پر زیڈ جی سی سی 0 زیڈ کے ساتھ تقسیم کی گئی ہے ، نہ صرف بیکٹریس پیدا کرنے کی حمایت کرتی ہے (جسے ہم اصل میں استعمال نہیں کرتے ہیں) بلکہ بیکٹریس کی علامت ہیں اور مابعد والے فریموں اور واٹ ناٹ جیسی چیزوں کے بارے میں بونے ڈیبگ کی معلومات کو سنبھالتے ہیں۔
//!
//!
//! یہ یہاں بہت سارے مختلف خدشات کی وجہ سے نسبتا complicated پیچیدہ ہے ، لیکن بنیادی خیال یہ ہے:
//!
//! * پہلے ہم `backtrace_syminfo` کہتے ہیں۔اگر ہم کر سکے تو اس سے متحرک سمبل ٹیبل سے علامت سے متعلق معلومات مل جاتی ہیں۔
//! * اگلا ہم `backtrace_pcinfo` کہتے ہیں۔اگر وہ دستیاب ہوں تو یہ ڈیبگ انفو جدولوں کا تجزیہ کرے گا اور ہمیں ان لائن فریموں ، فائلوں کے ناموں ، لائن نمبروں ، وغیرہ کے بارے میں معلومات بازیافت کرنے کی اجازت دیتا ہے۔
//!
//! بونے کی میزیں لِب بیک ٹریس میں لینے کے بارے میں بہت ساری دھوکہ دہی ہے ، لیکن امید ہے کہ یہ دنیا کا خاتمہ نہیں ہے اور ذیل میں پڑھتے وقت کافی واضح ہے۔
//!
//! یہ نان ایم ایس وی سی اور نان او ایس ایکس پلیٹ فارم کے لئے علامت کی طے شدہ طے شدہ حکمت عملی ہے۔اگرچہ یہ OSX کے لئے پہلے سے طے شدہ حکمت عملی ہے۔
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // اگر ممکن ہو تو `function` نام کو ترجیح دیں جو ڈیبگ انفو سے آتا ہے اور عام طور پر ان لائن فریموں کے ل more زیادہ درست ہوسکتا ہے مثال کے طور پر۔
                // اگر یہ موجود نہیں ہے تو بھی `symname` میں مخصوص کردہ علامت ٹیبل کے نام پر واپس آجائیں۔
                //
                // نوٹ کریں کہ بعض اوقات `function` کسی حد تک کم درست محسوس کرسکتا ہے ، مثال کے طور پر `std::panicking::try::do_call` کی `try<i32,closure>` استناد کی حیثیت سے درج کیا جارہا ہے۔
                //
                // یہ واقعی واضح نہیں ہے کہ کیوں ، لیکن مجموعی طور پر `function` نام زیادہ درست معلوم ہوتا ہے۔
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ابھی کچھ نہیں کرنا
}

/// `data` پوائنٹر کی قسم `syminfo_cb` میں گزر گئی
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // ایک بار جب یہ کال بیک `backtrace_syminfo` سے شروع ہوجاتا ہے جب ہم حل کرنا شروع کردیتے ہیں تو ہم `backtrace_pcinfo` پر کال کرنے کے لئے مزید آگے جاتے ہیں۔
    // `backtrace_pcinfo` فنکشن ڈیبگ انفارمیشن سے مشورہ کرے گا اور file/line کی بازیافت کے ساتھ ساتھ مابعدد فریم جیسے کام کرنے کی کوشش کرے گا۔
    // اگرچہ نوٹ کریں کہ اگر ڈیبگ کی معلومات نہیں ہے تو `backtrace_pcinfo` ناکام یا زیادہ کام کرسکتا ہے ، لہذا اگر ایسا ہوتا ہے تو ہمیں `syminfo_cb` سے کم سے کم ایک علامت کے ساتھ کال بیک کال کرنے کا یقین ہے۔
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` پوائنٹر کی قسم `pcinfo_cb` میں گزر گئی
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API ریاست بنانے کی حمایت کرتا ہے ، لیکن یہ کسی ریاست کو تباہ کرنے کی حمایت نہیں کرتا ہے۔
// میں ذاتی طور پر اس کا مطلب یہ لیتا ہوں کہ ایک ریاست کی تشکیل اور پھر ہمیشہ کے لئے زندہ رہنا ہے۔
//
// میں ایک at_exit() ہینڈلر کو رجسٹر کرنا چاہوں گا جو اس حالت کو صاف کرتا ہے ، لیکن لب بیک ٹریس ایسا کرنے کا کوئی طریقہ فراہم نہیں کرتا ہے۔
//
// ان رکاوٹوں کے ساتھ ، اس فنکشن میں ایک مستحکم کیچ کی حالت ہوتی ہے جس کے حساب سے پہلی بار اس کی درخواست کی جاتی ہے۔
//
// یاد رکھیں کہ تمام چیزوں کو پیچھے چھوڑنا سیرلی (ایک عالمی مقفل) ہوتا ہے۔
//
// نوٹ کریں کہ یہاں مطابقت پذیری کی کمی اس ضرورت کی وجہ سے ہے کہ `resolve` بیرونی طور پر ہم آہنگی پذیر ہے۔
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // لب بیکٹریس کی تھریڈ سیف صلاحیتوں کو استعمال نہ کریں کیونکہ ہم اسے ہم وقت ساز انداز میں کہتے ہیں۔
        //
        0,
        error_cb,
        ptr::null_mut(), // کوئی اضافی ڈیٹا نہیں ہے
    );

    return STATE;

    // نوٹ کریں کہ لِب بیک ٹریس کو بالکل کام کرنے کے ل exec موجودہ عملدرآمد کے ل the ڈیورف ڈیبگ کی معلومات تلاش کرنے کی ضرورت ہے۔یہ عام طور پر یہ کرتا ہے کہ متعدد میکانزم کے ذریعہ ، لیکن اس تک محدود نہیں:
    //
    // * /proc/self/exe تائید شدہ پلیٹ فارمز پر
    // * جب ریاست بناتے وقت فائل کا نام واضح طور پر گزر گیا
    //
    // libbacktrace لائبریری C کوڈ کا ایک بڑا واڈ ہے۔قدرتی طور پر اس کا مطلب یہ ہے کہ میموری کی حفاظت سے متعلق کمزوریوں کو مل گیا ہے ، خاص طور پر جب خرابی والے ڈیبگ انفو کو سنبھالنے سے۔
    // تاریخی اعتبار سے لیبسٹڈی ان میں سے کافی تعداد میں چلا گیا ہے۔
    //
    // اگر /proc/self/exe استعمال کیا جاتا ہے تو ہم عام طور پر ان کو نظرانداز کر سکتے ہیں کیونکہ ہم یہ فرض کرتے ہیں کہ لیب بیک ٹریس "mostly correct" ہے اور بصورت دیگر "attempted to be correct" بونے ڈیبگ کی معلومات کے ساتھ عجیب و غریب حرکتیں نہیں کرتے ہیں۔
    //
    //
    // اگر ہم کسی فائل نام سے گزر جاتے ہیں ، تو پھر ، یہ کچھ پلیٹ فارمز (جیسے BSDs) پر ممکن ہے جہاں ایک بدنیتی پر مبنی اداکار اس مقام پر کسی صوابدیدی فائل کو ڈالنے کا سبب بن سکتا ہے۔
    // اس کا مطلب یہ ہے کہ اگر ہم کسی فائل نام کے بارے میں لب بٹ ٹریس بتاتے ہیں تو یہ صوابدیدی فائل استعمال کرسکتا ہے ، ممکنہ طور پر سیگفالٹس کا سبب بنتا ہے۔
    // اگر ہم لائب بیک ٹریک کو کچھ نہیں بتاتے ہیں تو پھر یہ پلیٹ فارم پر کچھ نہیں کرے گا جو ایکس00 ایکس جیسے راستوں کی حمایت نہیں کرتا ہے!
    //
    // ہم نے ہر ممکن کوشش کی کہ فائل نام میں * پاس نہ کریں ، لیکن ہمیں ایسے پلیٹ فارم پر ہونا چاہئے جو /proc/self/exe کو بالکل بھی سپورٹ نہیں کرتے ہیں۔
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // نوٹ کریں کہ مثالی طور پر ہم `std::env::current_exe` استعمال کریں گے ، لیکن ہمیں یہاں `std` کی ضرورت نہیں ہوسکتی ہے۔
            //
            // کسی قابل عمل راستے کو کسی مستحکم علاقے میں لوڈ کرنے کے لئے `_NSGetExecutablePath` کا استعمال کریں (جو اگر یہ بہت چھوٹا ہے تو چھوڑ دیں)۔
            //
            //
            // نوٹ کریں کہ ہم یہاں سنجیدگی سے کرپٹ اراکین کی ہلاکت کے ل not لائبریکٹریس پر بھروسہ کررہے ہیں ، لیکن یہ یقینی طور پر ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows فائلوں کو کھولنے کا ایک موڈ ہے جہاں کھولنے کے بعد اسے حذف نہیں کیا جاسکتا۔
            // یہ عام طور پر ہم یہاں چاہتے ہیں کیوں کہ ہم اس بات کو یقینی بنانا چاہتے ہیں کہ جب ہمارے ذریعہ لائبریکٹریس کے حوالے کرنے کے بعد ہمارے عملدرآمد کو تبدیل نہیں کیا جا، ، توقع ہے کہ منمانے والے اعداد و شمار کو لیب بیک ٹریک میں منتقل کرنے کی صلاحیت کو کم کرنا (جس کی غلط بیانی ہوسکتی ہے)۔
            //
            //
            // یہ دیکھتے ہوئے کہ ہم یہاں اپنی تصویر پر ایک طرح کا لاک حاصل کرنے کی کوشش کرنے کے لئے تھوڑا سا رقص کرتے ہیں:
            //
            // * موجودہ عمل کو سنبھال لیں ، اس کے فائل کا نام لوڈ کریں۔
            // * دائیں جھنڈوں سے اس فائل کے نام پر ایک فائل کھولیں۔
            // * موجودہ عمل کے فائل کا نام دوبارہ لوڈ کریں ، یہ یقینی بناتے ہوئے کہ یہ ایک جیسی ہے
            //
            // اگر یہ سب گزر جاتا ہے تو ہم نے حقیقت میں ہمارے عمل کی فائل کھول دی ہے اور ہمیں ضمانت دی گئی ہے کہ یہ تبدیل نہیں ہوگی۔اس کا ایک مجموعہ FWIW کو تاریخی اعتبار سے آزادانہ نقل سے نقل کیا گیا ہے ، لہذا یہ میری سب سے اچھی ترجمانی ہے جو ہو رہا تھا۔
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // یہ جامد میموری میں رہتا ہے تاکہ ہم اسے واپس کر سکیں ..
                static mut BUF: [i8; N] = [0; N];
                // ... اور یہ اسٹیک پر زندہ ہے جب سے یہ عارضی ہے
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // جان بوجھ کر `handle` کو یہاں لیک کریں کیوں کہ اس فائل کے نام پر ہمارے تالے کو کھلا رکھنا چاہئے۔
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // ہم ایک سلائس واپس کرنا چاہتے ہیں جو منسوخ شدہ ہو ، لہذا اگر ہر چیز پُر کی گئی ہو اور اس کی مجموعی لمبائی برابر ہو تو اس کو ناکامی کے برابر بنائیں۔
                //
                //
                // ورنہ کامیابی واپس کرتے وقت اس بات کو یقینی بنائیں کہ نول بائٹ سلائس میں شامل ہے۔
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // بیکٹریس غلطیاں اس وقت قالین کے نیچے بہہ گئیں
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API کال کریں جس (کوڈ کو پڑھنے سے) `syminfo_cb` پر بالکل ایک بار کال کرے (یا شاید کسی غلطی سے ناکام ہوجائے)۔
    // اس کے بعد ہم `syminfo_cb` کے اندر مزید کام لیتے ہیں۔
    //
    // نوٹ کریں کہ ہم ایسا کرتے ہیں کیونکہ `syminfo` علامت کی میز سے مشورہ کرے گا ، علامت کے نام تلاش کرے گا یہاں تک کہ اگر بائنری میں ڈیبگ کی کوئی معلومات نہیں ہے۔
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}