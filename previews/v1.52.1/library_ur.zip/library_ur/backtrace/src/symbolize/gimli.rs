//! X001 پر `gimli` crate استعمال کرتے ہوئے علامت کی حمایت کریں
//!
//! یہ Rust کیلئے ڈیفالٹ علامت عمل ہے۔

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'مستحکم طرز زندگی خود حوالہ جاتی تدابیر کی حمایت میں کمی کے ارد گرد ہیک کرنا جھوٹ ہے۔
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 'مستحکم زندگی بھر میں تبدیل کریں چونکہ علامتوں میں صرف `map` اور `stash` لینا چاہئے اور ہم ان کو نیچے محفوظ کر رہے ہیں۔
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows پر مقامی لائبریریوں کو لوڈ کرنے کے ل For ، یہاں کی مختلف حکمت عملیوں کے لئے rust-lang/rust#71060 پر کچھ گفتگو دیکھیں۔
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // منگ ڈبلیو لائبریریاں فی الحال ASLR (rust-lang/rust#16514) کی حمایت نہیں کرتی ہیں ، لیکن DLL اب بھی ایڈریس اسپیس میں آس پاس منتقل ہوسکتی ہیں۔
            // ایسا معلوم ہوتا ہے کہ ڈیبگ انفارمیشن میں پتے سبھی ایسے ہی ہیں جیسے کہ یہ لائبریری اپنے "image base" پر بھری ہوئی تھی ، جو اس کے COFF فائل ہیڈر میں ایک فیلڈ ہے۔
            // چونکہ ڈیبگ انفو کی فہرست میں ایسا لگتا ہے کہ ہم علامت ٹیبل اور اسٹور پتوں کی تجزیہ کرتے ہیں گویا لائبریری بھی "image base" پر بھری ہوئی ہے۔
            //
            // تاہم ، لائبریری کو "image base" پر لوڈ نہیں کیا جاسکتا ہے۔
            // (شاید وہاں کوئی اور چیز لاد دی جا؟؟) یہ وہ جگہ ہے جہاں `bias` فیلڈ کھیل میں آتا ہے ، اور ہمیں یہاں `bias` کی قدر معلوم کرنے کی ضرورت ہے۔بدقسمتی سے اگرچہ یہ بات واضح نہیں ہے کہ بھری ہوئی ماڈیول سے اسے کیسے حاصل کیا جائے۔
            // ہمارے پاس جو کچھ ہے ، وہ ہے ، اصل بوجھ کا پتہ (`modBaseAddr`)۔
            //
            // ابھی کچھ وقت میں ہم فائل کو ایم ایم اےپ کرتے ہیں ، فائل ہیڈر کی معلومات پڑھتے ہیں ، اور پھر ایم ایم اے پی کو ڈراپ کرتے ہیں۔یہ فضول ہے کیوں کہ ہم شاید بعد میں ایم ایم پی کو دوبارہ کھولیں گے ، لیکن اس کے لئے ابھی کافی کام کرنا چاہئے۔
            //
            // ایک بار ہمارے پاس `image_base` (مطلوبہ بوجھ کا مقام) اور `base_addr` (اصل بوجھ کا محل وقوع) ہم `bias` (اصل اور مطلوبہ کے درمیان فرق) کو پُر کرسکتے ہیں اور پھر ہر طبقہ کا بیان کردہ پتہ `image_base` ہے کیونکہ فائل یہی کہتی ہے۔
            //
            //
            // ابھی ایسا معلوم ہوتا ہے کہ ELF/MachO کے برعکس ہم لائبریری کے ایک حصے کے ساتھ ، `modBaseSize` کو پورے سائز کے طور پر استعمال کرسکتے ہیں۔
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS مچ او فائل فائل کا استعمال کرتا ہے اور مقامی لائبریریوں کی فہرست کو لوڈ کرنے کے لئے DYLD-مخصوص API کا استعمال کرتا ہے جو ایپلی کیشن کا حصہ ہیں۔
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // اس لائبریری کا نام لائیں جو اس راستے سے مساوی ہے جہاں اسے بھی لوڈ کرنا ہے۔
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // اس لائبریری کے امیج ہیڈر لوڈ کریں اور تمام بوجھ کمانڈوں کی تجزیہ کرنے کے لئے `object` کو ڈیلیٹ کریں تاکہ ہم یہاں موجود تمام طبقات کا پتہ لگاسکیں۔
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // طبقات کی جانچ پڑتال کریں اور ان حصوں کے لئے مشہور علاقوں کو رجسٹر کریں جو ہمیں ملتے ہیں۔
            // اضافی طور پر بعد میں پروسیسنگ کے لئے متن والے حصوں میں معلومات درج کریں ، ذیل میں تبصرے دیکھیں۔
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // اس لائبریری کے لئے "slide" کا تعی .ن کریں جو تعصب ختم ہوجاتا ہے جس کا پتہ لگانے کے ل use ہم استعمال کرتے ہیں کہ میموری میں کہاں سامان لادا جاتا ہے۔
            // اگرچہ یہ جنگل میں کچھ چیزوں کی کوشش کرنے اور کیا لاٹھی دیکھ رہا ہے اس کا نتیجہ ہے۔
            //
            // عام خیال یہ ہے کہ `bias` پلس ایک طبقہ کا `stated_virtual_memory_address` ایسا ہی ہونے والا ہے جہاں اصل پتے کی جگہ میں یہ طبقہ رہتا ہے۔
            // دوسری چیز جس پر ہم انحصار کرتے ہیں وہ یہ ہے کہ `bias` کا اصل پتہ مائنس علامت ٹیبل اور ڈیبگ انفو میں دیکھنے کے ل the انڈیکس ہے۔
            //
            // یہ پتہ چلتا ہے ، اگرچہ ، نظام سے بھری ہوئی لائبریریوں کے لئے یہ حساب کتاب غلط ہے۔مقامی پھانسی کے لئے ، تاہم ، یہ درست معلوم ہوتا ہے۔
            // ایل ایل ڈی بی کے ماخذ سے کچھ منطق اٹھانا اس میں نانزرو سائز کے ساتھ فائل آفسیٹ 0 سے بھری ہوئی پہلی `__TEXT` سیکشن کے لئے کچھ خاص سانچے ہیں۔
            // کسی بھی وجہ سے جب یہ موجود ہے تو اس کا مطلب یہ ظاہر ہوتا ہے کہ علامت کی میز لائبریری کے لئے صرف vmaddr سلائیڈ سے متعلق ہے۔
            // اگر یہ *موجود نہیں* ہے تو پھر علامت کی میز vmaddr سلائیڈ کے علاوہ اس حصے کے بیان کردہ پتے سے متعلق ہے۔
            //
            // اس صورتحال کو نپٹانے کے ل if اگر ہمیں فائل آفسیٹ صفر میں کوئی ٹیکسٹ سیکشن نہیں ملتا ہے تو پھر ہم پہلے ٹیکسٹ سیکشن کے بیان کردہ ایڈریس کے ذریعہ تعصب بڑھاتے ہیں اور اس رقم سے تمام بیان کردہ پتوں کو بھی کم کردیتے ہیں۔
            //
            // اس طرح علامت جدول ہمیشہ لائبریری کے تعصب کی رقم کے مطابق ظاہر ہوتا ہے۔
            // ایسا لگتا ہے کہ اس کی علامت ٹیبل کے ذریعہ علامت کے صحیح نتائج ہیں۔
            //
            // سچ میں مجھے پوری طرح سے یقین نہیں ہے کہ آیا یہ صحیح ہے یا کوئی اور بات ہے جو اس کی نشاندہی کرنی چاہئے۔
            // ابھی اگرچہ ایسا لگتا ہے کہ یہ کافی حد تک (?) پر کام کر رہا ہے اور اگر ضروری ہو تو ہمیں ہمیشہ وقت کے ساتھ اس میں موافقت کرنے کے قابل ہونا چاہئے۔
            //
            // کچھ مزید معلومات کے لئے دیکھیں #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // دوسرے Unix (جیسے
        // لینکس) پلیٹ فارم ELF کو آبجیکٹ فائل کی شکل کے طور پر استعمال کرتے ہیں اور عام طور پر مقامی لائبریریوں کو لوڈ کرنے کے لئے ایک API کو `dl_iterate_phdr` کہتے ہیں۔
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ایک درست پوائنٹر ہونا چاہئے۔
        // `vec` `std::Vec` کا درست پوائنٹر ہونا چاہئے۔
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 آبائی طور پر ڈیبگ انفارمیشن کی حمایت نہیں کرتا ہے ، لیکن بلڈ سسٹم ڈیبگ انفارمیشن کو راہ `romfs:/debug_info.elf` پر رکھیں گے۔
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // باقی ہر چیز کو ELF کا استعمال کرنا چاہئے ، لیکن مقامی لائبریریوں کو لوڈ کرنے کا طریقہ نہیں جانتے ہیں۔
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// تمام معروف مشترکہ لائبریرییں جو بھری ہوئی ہیں۔
    libraries: Vec<Library>,

    /// میپنگز کیشے جہاں ہم تصریف شدہ بونے کی معلومات کو برقرار رکھتے ہیں۔
    ///
    /// اس فہرست میں اس کے پورے زندگی کے لئے ایک مستقل گنجائش ہے جو کبھی نہیں بڑھتی ہے۔
    /// ہر جوڑے کا `usize` عنصر اوپر `libraries` میں ایک انڈیکس ہے جہاں `usize::max_value()` موجودہ عملدرآمد کی نمائندگی کرتا ہے۔
    ///
    /// `Mapping` اسی طرح کی تجزیہ شدہ بونے کی معلومات ہے۔
    ///
    /// نوٹ کریں کہ یہ بنیادی طور پر LRU کیش ہے اور جب ہم پتے کی علامت ہیں تو ہم چیزوں کو ادھر ادھر منتقل کرتے رہیں گے۔
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// اس لائبریری کے کچھ حصے میموری میں بھری ہوئی ہیں ، اور جہاں انہیں بھری ہوئی ہے۔
    segments: Vec<LibrarySegment>,
    /// اس لائبریری کا "bias" ، عام طور پر جہاں یہ میموری میں لاد جاتا ہے۔
    /// اس قدر کو ہر طبقہ کے بیان کردہ پتے میں شامل کیا جاتا ہے تاکہ حقیقی ورچوئل میموری ایڈریس حاصل کیا جاسکے جس میں طبقہ بھری ہوئی ہے۔
    /// اضافی طور پر یہ تعصب اصلی مجازی میموری پتوں سے ڈیبگ انفو اور علامتی جدول میں انڈیکس میں گھٹا جاتا ہے۔
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// آبجیکٹ فائل میں اس طبقہ کا بیان کردہ پتہ۔
    /// یہ دراصل وہ جگہ نہیں ہے جہاں طبقہ بھری ہوئی ہے ، بلکہ اس پتے کے ساتھ مشتمل لائبریری کا `bias` بھی ہے جہاں اسے ڈھونڈنا ہے۔
    ///
    stated_virtual_memory_address: usize,
    /// میموری میں ths طبقے کا سائز۔
    len: usize,
}

// غیر محفوظ ہے کیونکہ اس کی بیرونی سطح پر ہم آہنگی کرنے کی ضرورت ہے
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // غیر محفوظ ہے کیونکہ اس کی بیرونی سطح پر ہم آہنگی کرنے کی ضرورت ہے
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ڈیبگ انفارمیشن میپنگس کیلئے ایک بہت ہی چھوٹا ، بہت آسان LRU کیشے۔
        //
        // ہٹ کی شرح بہت زیادہ ہونی چاہئے ، کیونکہ عام مشترکہ کتب خانوں کے مابین عام اسٹیک عبور نہیں کرتا ہے۔
        //
        // `addr2line::Context` ڈھانچے تخلیق کرنے کے لئے کافی مہنگے ہیں۔
        // توقع کی جاتی ہے کہ اس کی لاگت کے بعد کے `locate` سوالات کے ذریعہ ، جس نے عمدہ اسپیڈ اپ حاصل کرنے کے ل` r addr2line: : سیاق و سباق کی تعمیر کرتے وقت تعمیر شدہ ڈھانچے کا فائدہ اٹھایا ہو گا۔
        //
        // اگر ہمارے پاس یہ کیش نہ ہوتا ، تو وہ ایمورٹائزیشن کبھی نہیں ہوگی ، اور بیک ٹریس کی علامت کرنا ssssllllooooowwww ہوگا۔
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // پہلے ، جانچ کریں کہ آیا اس `lib` میں کوئی ایسا طبقہ ہے جس میں `addr` (ہینڈلنگ نقل مکانی) ہے۔اگر یہ چیک گزر جاتا ہے تو ہم نیچے جاری رکھ سکتے ہیں اور اصل میں ایڈریس کا ترجمہ کرسکتے ہیں۔
                //
                // نوٹ کریں کہ ہم اوور فلو چیکوں سے بچنے کے لئے یہاں `wrapping_add` استعمال کر رہے ہیں۔یہ جنگل میں دیکھا گیا ہے کہ SVMA + تعصب کا حساب اتنا زیادہ بہہ جاتا ہے۔
                // یہ تھوڑا سا عجیب سا لگتا ہے کہ ایسا ہوگا لیکن اس میں کوئی بہت بڑی رقم نہیں ہے جو ہم اس کے بارے میں کچھ اور کرسکتے ہیں اس کے علاوہ شاید ان حصوں کو نظر انداز کردیں کیوں کہ وہ خلا میں اشارہ کررہے ہیں۔
                //
                // یہ اصل میں rust-lang/backtrace-rs#329 میں سامنے آیا ہے۔
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // اب جب ہم جانتے ہیں کہ `lib` پر مشتمل ہے `addr` ، ہم بیان کردہ وائرل میموری کا پتہ تلاش کرنے کے لئے تعصب کے ساتھ آفسیٹ کرسکتے ہیں۔
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // ناگوار: یہ مشروط جلد واپس آنے کے بغیر مکمل ہوجانے کے بعد
        // کسی غلطی سے ، اس راہ کے لئے کیشے کا اندراج 0 انڈیکس پر ہے۔

        if let Some(idx) = idx {
            // جب نقشہ سازی پہلے سے ہی کیشے میں ہے ، تو اسے سامنے کی طرف بڑھیں۔
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // جب میپنگ کیشے میں نہیں ہے تو ، ایک نیا نقشہ سازی بنائیں ، اسے کیشے کے سامنے والے حصے میں داخل کریں ، اور اگر ضرورت ہو تو سب سے قدیم ترین کیشے کو داخل کریں۔
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` زندگی بھر کو نہ لیک ، اس بات کو یقینی بنائیں کہ یہ صرف اپنی ذات تک ہے
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // `sym` کی زندگی میں `'static` تک توسیع کریں کیوں کہ ہمارے یہاں بدقسمتی سے ضرورت ہے ، لیکن یہ کبھی بھی ایک حوالہ کے طور پر سامنے نہیں آرہا ہے لہذا اس کا کوئی حوالہ بہرحال اس فریم سے آگے نہیں رہنا چاہئے۔
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // آخر میں ، کیشڈ میپنگ حاصل کریں یا اس فائل کے ل a ایک نئی میپنگ بنائیں ، اور اس پتے کے لئے file/line/name تلاش کرنے کے لئے ڈیورف معلومات کا اندازہ کریں۔
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// ہم اس علامت کے ل frame فریم سے متعلق معلومات تلاش کرنے میں کامیاب تھے ، اور `addr2line` کے فریم میں داخلی طور پر تمام نرخوں کی تفصیل موجود ہے۔
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ڈیبگ کی معلومات نہیں مل سکی ، لیکن ہمیں اسے عملی اعضاء کی علامت ٹیبل میں مل گیا۔
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}