use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// کسی علامت کا پتہ حل کریں ، علامت کو مخصوص بندش پر منتقل کریں۔
///
/// یہ فنکشن دیئے گئے پتے کو ایسے علاقوں میں تلاش کرے گا جیسے مقامی علامت کی میز ، متحرک سمبل ٹیبل ، یا ڈیور ایف ڈیبگ انفارمیشن (چالو عملدرآمد پر منحصر ہے) پیدا کرنے کے لئے نشانات تلاش کریں۔
///
///
/// اگر قرارداد کو انجام نہیں دیا جاسکتا تو بندش کو بلایا نہیں جاسکتا ہے ، اور مابعد افعال کی صورت میں اسے ایک سے زیادہ مرتبہ بھی کہا جاسکتا ہے۔
///
/// حاصل کردہ علامتیں مخصوص `addr` پر عملدرآمد کی نمائندگی کرتی ہیں ، اس پتے کے لئے file/line جوڑے کو واپس کرتے ہیں (اگر دستیاب ہو)۔
///
/// نوٹ کریں کہ اگر آپ کے پاس `Frame` ہے تو پھر اس کی بجائے `resolve_frame` فنکشن کو استعمال کرنے کی تجویز کی گئی ہے۔
///
/// # مطلوبہ خصوصیات
///
/// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
///
/// # Panics
///
/// یہ فنکشن کبھی بھی panic کی کوشش نہیں کرتا ، لیکن اگر `cb` نے panics فراہم کیا تو کچھ پلیٹ فارمز ڈبل panic کو اس عمل کو ختم کرنے پر مجبور کردیں گے۔
/// کچھ پلیٹ فارمز سی لائبریری کا استعمال کرتے ہیں جو داخلی طور پر کال بیکس کا استعمال کرتے ہیں جس کے ذریعہ اس کو ختم نہیں کیا جاسکتا ہے ، لہذا `cb` سے گھبرا کر عمل ختم ہونا شروع ہوسکتا ہے۔
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // صرف اوپر والے فریم کو دیکھیں
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// پچھلے کیپچر فریم کو کسی علامت میں حل کریں ، علامت کو مخصوص بندش پر منتقل کریں۔
///
/// یہ فنکٹن `resolve` جیسا ہی فنکشن انجام دیتا ہے سوائے اس کے کہ یہ پتے کی بجائے `Frame` کو بطور دلیل لیتا ہے۔
/// اس سے بیک ٹریکنگ کے کچھ پلیٹ فارم پر عمل درآمد کی علامت کی صحیح معلومات یا ان لائن فریموں کے بارے میں معلومات فراہم کی جاسکتی ہے۔
///
/// اگر آپ یہ کرسکتے ہو تو اسے استعمال کرنے کی سفارش کی جاتی ہے۔
///
/// # مطلوبہ خصوصیات
///
/// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
///
/// # Panics
///
/// یہ فنکشن کبھی بھی panic کی کوشش نہیں کرتا ، لیکن اگر `cb` نے panics فراہم کیا تو کچھ پلیٹ فارمز ڈبل panic کو اس عمل کو ختم کرنے پر مجبور کردیں گے۔
/// کچھ پلیٹ فارمز سی لائبریری کا استعمال کرتے ہیں جو داخلی طور پر کال بیکس کا استعمال کرتے ہیں جس کے ذریعہ اس کو ختم نہیں کیا جاسکتا ہے ، لہذا `cb` سے گھبرا کر عمل ختم ہونا شروع ہوسکتا ہے۔
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // صرف اوپر والے فریم کو دیکھیں
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// اسٹیک فریموں سے IP کی اقدار عام طور پر (always?) کی ہدایت *کال کے بعد* ہیں جو اصل اسٹیک ٹریس ہے۔
// اس کی علامت کی وجہ سے filename/line کا نمبر آگے ہونے کا سبب بنتا ہے اور شاید یہ فعل کے اختتام کے قریب ہو تو باطل میں ہوجاتا ہے۔
//
// یہ بنیادی طور پر ہمیشہ تمام پلیٹ فارمز پر ہی ہوتا دکھائی دیتا ہے ، لہذا ہم ہمیشہ کسی حل شدہ آئی پی سے ایک کو گھٹا دیتے ہیں تاکہ اسے واپس کرنے کے بجائے پچھلی کال انسٹرکشن پر حل کیا جائے۔
//
//
// مثالی طور پر ہم یہ نہیں کریں گے۔
// مثالی طور پر ہم یہاں `resolve` APIs کے کال کرنے والوں سے دستی طور پر -1 کرنے کی ضرورت کریں گے اور یہ محاسبہ کریں کہ وہ *سابقہ* ہدایت کے لئے مقام کی معلومات چاہتے ہیں ، موجودہ نہیں۔
// اگر ہم واقعی اگلی ہدایت یا موجودہ کا پتہ ہیں تو ہم مثالی طور پر ہم `Frame` پر بھی ایکسپوز کریں گے۔
//
// اگرچہ ابھی یہ ایک خاص طاق کی بات ہے لہذا ہم صرف داخلی طور پر ہی ایک کو گھٹاتے ہیں۔
// صارفین کو کام کرتے رہنا چاہئے اور بہت اچھے نتائج ملنے چاہئیں ، لہذا ہمیں کافی اچھ beا ہونا چاہئے۔
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` کی طرح ، صرف غیر محفوظ ہے کیونکہ یہ غیر منظم ہے۔
///
/// اس فنکشن میں ہم وقت سازی کی گارنٹیاں نہیں ہیں لیکن اس وقت دستیاب ہے جب اس crate کی `std` خصوصیت مرتب نہیں کی گئی ہے۔
/// مزید دستاویزات اور مثالوں کے لئے `resolve` فنکشن دیکھیں۔
///
/// # Panics
///
/// گھبرانے والی `cb` سے متعلق انتباہات کے لئے `resolve` پر معلومات دیکھیں۔
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` کی طرح ، صرف غیر محفوظ ہے کیونکہ یہ غیر منظم ہے۔
///
/// اس فنکشن میں ہم وقت سازی کی گارنٹیاں نہیں ہیں لیکن اس وقت دستیاب ہے جب اس crate کی `std` خصوصیت مرتب نہیں کی گئی ہے۔
/// مزید دستاویزات اور مثالوں کے لئے `resolve_frame` فنکشن دیکھیں۔
///
/// # Panics
///
/// گھبرانے والی `cb` سے متعلق انتباہات کے لئے `resolve_frame` پر معلومات دیکھیں۔
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ایک trait ایک فائل میں علامت کی قرارداد کی نمائندگی کرتا ہے۔
///
/// یہ trait `backtrace::resolve` فنکشن کو دیئے گئے بندش پر trait آبجیکٹ کے طور پر نکلا ہے ، اور اسے عملی طور پر روانہ کردیا گیا ہے کیونکہ یہ نامعلوم ہے کہ اس کے پیچھے کون سا عمل درآمد ہے۔
///
///
/// علامت کسی فنکشن کے بارے میں متعلقہ معلومات دے سکتی ہے ، مثلا the نام ، فائل کا نام ، لائن نمبر ، عین مطابق پتہ وغیرہ۔
/// تمام معلومات ہمیشہ کسی علامت میں دستیاب نہیں ہوتی ہیں ، تاہم ، تمام طریقوں سے `Option` واپس آجاتا ہے۔
///
///
pub struct Symbol {
    // TODO: اس زندگی کے پابند کو آخر کار `Symbol` تک برقرار رکھنے کی ضرورت ہے ،
    // لیکن یہ فی الحال ایک بریک تبدیلی ہے۔
    // ابھی کے لئے یہ محفوظ ہے کیوں کہ `Symbol` کو ہمیشہ حوالہ کے ذریعہ دیا جاتا ہے اور اسے کلون نہیں کیا جاسکتا ہے۔
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// اس فنکشن کا نام لوٹاتا ہے۔
    ///
    /// لوٹی ہوئی ساخت کا استعمال علامت نام کے بارے میں مختلف خصوصیات سے استفسار کرنے کے لئے کیا جاسکتا ہے:
    ///
    ///
    /// * `Display` نفاذ Demangled علامت کو پرنٹ کرے گا۔
    /// * علامت کی خام `str` قیمت تک رسائی حاصل کی جاسکتی ہے (اگر یہ درست utf-8 ہے)۔
    /// * علامت نام کے خام بائٹس تک رسائی حاصل کی جاسکتی ہے۔
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// اس فنکشن کا ابتدائی پتہ لوٹاتا ہے۔
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// خام فائل کا نام ایک ٹکڑا کے طور پر لوٹاتا ہے۔
    /// یہ بنیادی طور پر `no_std` ماحولیات کے لئے مفید ہے۔
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// کالم نمبر واپس کرتا ہے جہاں کے لئے یہ علامت فی الحال کام کررہی ہے۔
    ///
    /// صرف جیملی یہاں فی الحال ایک اہمیت فراہم کرتا ہے اور پھر بھی اس صورت میں اگر `filename` نے `Some` کو واپس کیا ، اور اس کے نتیجے میں یہ اسی طرح کی انتباہات کے تابع ہے۔
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// وہ لائن نمبر لوٹاتا ہے جہاں اس علامت پر فی الحال عمل درآمد ہو رہا ہے۔
    ///
    /// واپسی کی یہ قیمت عام طور پر `Some` ہے اگر `filename` نے `Some` کو واپس کیا ، اور اس کے نتیجے میں اسی طرح کی انتباہات کے تابع ہیں۔
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// فائل کا نام لوٹاتا ہے جہاں اس فنکشن کی تعریف کی گئی تھی۔
    ///
    /// فی الحال یہ صرف تب دستیاب ہے جب لب بیکٹریس یا جملی استعمال ہو رہی ہو (جیسے
    /// unix دوسرے پلیٹ فارم) اور جب بائنری ڈیبگ انفو کے ساتھ مرتب کی جاتی ہے۔
    /// اگر ان میں سے کسی بھی شرائط کو پورا نہیں کیا جاتا ہے تو یہ ممکنہ طور پر `None` کو لوٹائے گا۔
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ہوسکتا ہے کہ اگر تجویز کردہ C++ علامت ، اگر Rust کی حیثیت سے منگلے ہوئے علامت کو پارس کرنا ناکام ہے۔
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // اس صفر کے سائز کو یقینی بنائیں ، تاکہ جب غیر فعال ہوجائے تو `cpp_demangle` خصوصیت کی کوئی قیمت نہ ہو۔
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// اسمبل نام ، خام بائٹس ، خام تار وغیرہ کو ایرگونومک رسس مہیا کرنے کے لئے کسی علامت نام کے چاروں طرف کا ایک لپیٹا۔
///
// جب `cpp_demangle` خصوصیت فعال نہیں ہے اس کیلئے ڈیڈ کوڈ کی اجازت دیں۔
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// خام انڈلائننگ بائٹس سے علامت کا ایک نیا نام بناتا ہے۔
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// خام (mangled) علامت کا نام بطور `str` واپس کرتا ہے اگر علامت درست utf-8 ہے۔
    ///
    /// اگر آپ Demangled ورژن چاہتے ہیں تو `Display` نفاذ کا استعمال کریں۔
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// بائٹس کی فہرست کے طور پر خام علامت کا نام لوٹاتا ہے
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // یہ پرنٹ کرنے کے لئے ہوسکتا ہے کہ اگر منحرف علامت دراصل درست نہ ہو ، تو غلطی کو یہاں پر باہر تک پھیلاتے ہوئے احسن طریقے سے سنبھال لیں۔
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// دوبارہ دعوی کرنے کی کوشش کی کہ کیچڈ میموری میموری کے پتے کی علامت ہوتی تھی۔
///
/// یہ طریقہ کسی بھی عالمی اعداد و شمار کے ڈھانچے کو جاری کرنے کی کوشش کرے گا جو عالمی سطح پر یا اس دھاگے میں محفوظ کیا گیا ہے جو عام طور پر تجزیہ شدہ DWARF معلومات یا اسی طرح کی نمائندگی کرتا ہے۔
///
///
/// # Caveats
///
/// اگرچہ یہ فنکشن ہمیشہ دستیاب ہوتا ہے لیکن یہ حقیقت میں زیادہ تر عمل آوریوں پر کچھ نہیں کرتا ہے۔
/// dbghelp یا libbacktrace جیسے لائبریریاں ریاست کو غیر منحصر کرنے اور مختص میموری کو منظم کرنے کے لئے سہولیات فراہم نہیں کرتی ہیں۔
/// ابھی کے لئے اس crate کی `gimli-symbolize` خصوصیت واحد خصوصیت ہے جہاں اس فعل کا کوئی اثر ہوتا ہے۔
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}