// صرف ابھی Linux پر استعمال ہوا ہے ، لہذا کہیں اور کوڈ کوڈ کی اجازت دیں
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// بائٹ بفرز کے لئے ایک سادہ میدان مختص کرنے والا۔
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// مخصوص سائز کا ایک بفر مختص کرتا ہے اور اس کا تبادلہ کرنے والا حوالہ دیتا ہے۔
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // سیکیورٹی: یہ واحد فنکشن ہے جو کبھی بھی بدلنے والا بناتا ہے
        // `self.buffers` کا حوالہ۔
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // محفوظ: ہم کبھی بھی `self.buffers` سے عناصر کو نہیں ہٹاتے ہیں ، لہذا ایک حوالہ
        // کسی بھی بفر کے اندر موجود ڈیٹا تک جب تک `self` نہیں زندہ رہے گا۔
        &mut buffers[i]
    }
}