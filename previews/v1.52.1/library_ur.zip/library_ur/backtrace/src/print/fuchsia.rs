use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ایک کال بیک لیتا ہے جو اس عمل میں جڑا ہوا ہر DSO کے لئے dl_phdr_info پوائنٹر وصول کرے گا۔
    // dl_iterate_phdr یہ بھی یقینی بناتا ہے کہ متحرک لنکر کو تکرار کے اختتام تک شروع سے بند کر دیا گیا ہے۔
    // اگر کال بیک نے ایک غیر صفر کی قیمت لوٹائی ہے تو دوبارہ عمل جلد ختم ہوجاتا ہے۔
    // 'data' ہر کال پر کال بیک کے لئے تیسری دلیل کے طور پر منظور کیا جائے گا۔
    // 'size' dl_phdr_info کا سائز دیتا ہے۔
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ہمیں بلڈ ID اور کچھ بنیادی پروگرام ہیڈر کے اعداد و شمار کی تجزیہ کرنے کی ضرورت ہے جس کا مطلب ہے کہ ہمیں بھی ELF رپورٹ سے تھوڑا سا سامان درکار ہے۔
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// اب ہمیں dl_phdr_info قسم کا ڈھانچہ تیار کرنا ہے جو فوچیا کے موجودہ متحرک لنکر کے ذریعہ استعمال کیا جاتا ہے۔
// کرومیم میں یہ ABI حدود نیز کریش پیڈ بھی ہے۔
// آخرکار ہم ان معاملات کو یلف سرچ استعمال کرنے کے ل move منتقل کرنا چاہتے ہیں لیکن ہمیں ایس ڈی کے میں یہ فراہم کرنے کی ضرورت ہوگی اور یہ ابھی تک نہیں ہوا ہے۔
//
// اس طرح ہم (اور وہ) اس طریقہ کار کو استعمال کرنے میں پھنس چکے ہیں جس میں فوچیا لبیک کے ساتھ سخت جوڑے پڑتے ہیں۔
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // ہمارے پاس جانچ پڑتال کے بارے میں جاننے کا کوئی طریقہ نہیں ہے کہ آیا e_phoff اور e_phnum درست ہے یا نہیں۔
    // libc کو ہمارے لئے یہ یقینی بنانا چاہئے لہذا یہاں ٹکڑا تشکیل دینا محفوظ ہے۔
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// ایلف پی ایچ ڈی آر ایک 64 بٹ ای ایل ایف پروگرام ہیڈر کی نمائندگی کرتا ہے جو ہدف فن تعمیر کے خاتمے میں ہے۔
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// پی ایچ ڈی آر ایک درست ELF پروگرام ہیڈر اور اس کے مندرجات کی نمائندگی کرتا ہے۔
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // ہمارے پاس چیک کرنے کا کوئی طریقہ نہیں ہے کہ p_addr یا p_memsz درست ہے یا نہیں۔
    // فوسیا کا libc پہلے نوٹوں کی تجزیہ کرتا ہے لیکن اس وجہ سے یہاں موجود ہونے کی وجہ سے یہ ہیڈر لازمی ہیں۔
    //
    // نوٹ آئٹر کو بنیادی ڈیٹا کو درست ہونے کی ضرورت نہیں ہوتی ہے لیکن اس کی ضرورت ہوتی ہے کہ حدود درست ہوں۔
    // ہمیں یقین ہے کہ لبیک نے اس بات کو یقینی بنایا ہے کہ ہمارے یہاں یہی معاملہ ہے۔
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// بلڈ IDs کے لئے نوٹ کی قسم
const NT_GNU_BUILD_ID: u32 = 3;

// ایلف_نھڈر ہدف کے خاتمے میں ایک ELF نوٹ ہیڈر کی نمائندگی کرتا ہے۔
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// نوٹ ایک ELF نوٹ (ہیڈر + مشمولات) کی نمائندگی کرتا ہے۔
// نام کو u8 سلائس کے طور پر چھوڑ دیا گیا ہے کیونکہ یہ ہمیشہ ختم نہیں ہوتا ہے اور rust یہ چیک کرنا اتنا آسان بنا دیتا ہے کہ بائٹس کسی بھی طرح سے میل کھاتے ہیں۔
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// نوٹ آئیٹر آپ کو نوٹ کے ایک حصے پر بحفاظت تکرار کرنے دیتا ہے۔
// جیسے ہی کوئی خرابی پیش آتی ہے یا مزید نوٹ نہیں ہوتے ہیں یہ ختم ہوجاتا ہے۔
// اگر آپ غلط اعداد و شمار پر تکرار کرتے ہیں تو یہ اس طرح کام کرے گا جیسے کوئی نوٹ نہیں ملا تھا۔
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // یہ فنکشن کا ناگزیر ہے کہ جو پوائنٹر اور سائز دیا گیا ہے اس سے بائٹس کی ایک درست حد ہوتی ہے جو سب پڑھ سکتے ہیں۔
    // ان بائٹس کے مندرجات کچھ بھی ہوسکتے ہیں لیکن اس کو محفوظ رکھنے کے لئے حد اطلاق لازمی ہے۔
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' کو 'to' بائٹ سیدھ میں لے کر 'to' کو 2 کی طاقت سمجھتے ہیں۔
// یہ C/C ++ ELF پارسنگ کوڈ میں ایک معیاری نمونہ کی پیروی کرتا ہے جہاں (x + to، 1) اور -to استعمال ہوتا ہے۔
// Rust آپ کو استعمال کرنے کی نفی کرنے نہیں دیتا ہے لہذا میں استعمال کرتا ہوں
// اس کو دوبارہ بنانے کے ل 2 2 کا تکمیل شدہ تبادلہ۔
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 سلائس سے نم بائٹس کھاتا ہے (اگر موجود ہو) اور اضافی طور پر یہ یقینی بناتا ہے کہ آخری سلائس مناسب طریقے سے منسلک ہے۔
// اگر کسی ایک میں درخواست کی گئی بائٹس کی تعداد بہت زیادہ ہے یا کافی بائٹس موجود نہ ہونے کی وجہ سے اس کے بعد اس کا شناخت نہیں کیا جاسکتا ہے تو ، کوئی بھی واپس نہیں کیا جاتا ہے اور سلائس میں ترمیم نہیں کی جاتی ہے۔
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// اس فنکشن میں کوئی حقیقی حملہ آور نہیں ہوتا ہے اس لئے کہ کال کرنے والے کو اس کے علاوہ دوسرے کو بھی برقرار رکھنا چاہئے کہ 'bytes' کو کارکردگی کے لئے جوڑا ہونا چاہئے (اور کچھ فن تعمیرات کی درستی پر)۔
// Elf_Nhdr فیلڈز کی قدریں بکواس ہوسکتی ہیں لیکن اس فنکشن سے اس طرح کی کوئی چیز یقینی نہیں ہوتی ہے۔
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // یہ اس وقت تک محفوظ ہے جب تک کہ کافی جگہ موجود نہ ہو اور ہم نے صرف تصدیق کی کہ مذکورہ بالا بیان میں یہ غیر محفوظ نہیں ہونا چاہئے۔
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // نوٹ کریں کہ sice_of: :<Elf_Nhdr>() ہمیشہ 4 بائٹ منسلک ہوتا ہے۔
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // چیک کریں کہ آیا ہم انجام کو پہنچ چکے ہیں۔
        if self.base.len() == 0 || self.error {
            return None;
        }
        // ہم ایک این ایچ ڈی آر کو منتقل کرتے ہیں لیکن ہم نتیجے کے ڈھانچے پر احتیاط سے غور کرتے ہیں۔
        // ہمیں نامز یا ڈیس سز پر اعتماد نہیں ہے اور ہم اس قسم کی بنیاد پر کوئی غیر محفوظ فیصلے نہیں کرتے ہیں۔
        //
        // لہذا یہاں تک کہ اگر ہم مکمل کوڑا کرکٹ باہر آجائیں تو بھی ہمیں محفوظ رہنا چاہئے۔
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// اشارہ کرتا ہے کہ ایک طبقہ قابل عمل ہے۔
const PERM_X: u32 = 0b00000001;
/// اشارہ کرتا ہے کہ ایک طبقہ قابل تحریر ہے۔
const PERM_W: u32 = 0b00000010;
/// اشارہ کرتا ہے کہ ایک طبقہ پڑھنے کے قابل ہے۔
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// رن ٹائم پر ELF طبقہ کی نمائندگی کرتا ہے۔
struct Segment {
    /// اس طبقہ کے مندرجات کا رن ٹائم مجازی پتہ دیتا ہے۔
    addr: usize,
    /// اس طبقہ کے مندرجات کی میموری سائز دیتا ہے۔
    size: usize,
    /// ELF فائل کے ساتھ اس طبقہ کا ماڈیول ورچوئل پتہ دیتا ہے۔
    mod_rel_addr: usize,
    /// ELF فائل میں پائی جانے والی اجازت دیتا ہے۔
    /// یہ اجازت نامے ضروری نہیں ہیں جو رن ٹائم پر موجود ہوں۔
    flags: Perm,
}

/// ڈی ایس او کے حصوں میں ایک اعادہ کرنے دیتا ہے۔
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ایک ELF DSO (متحرک مشترکہ آبجیکٹ) کی نمائندگی کرتا ہے۔
/// اس قسم نے اپنی کاپی بنانے کے بجائے اصل ڈی ایس او میں محفوظ کردہ ڈیٹا کا حوالہ دیا ہے۔
struct Dso<'a> {
    /// متحرک لنک کرنے والا ہمیشہ ہمیں ایک نام دیتا ہے ، چاہے نام خالی ہی کیوں نہ ہو۔
    /// مرکزی عملدرآمد کی صورت میں یہ نام خالی ہوگا۔
    /// مشترکہ شے کی صورت میں یہ سونم ہوگا (دیکھیں DT_SONAME)۔
    name: &'a str,
    /// فوسیا پر عملی طور پر تمام بائنریز کی شناختی شناخت ہوتی ہے لیکن یہ کوئی سخت ضرورت نہیں ہے۔
    /// اس کے بعد DSL کی معلومات کو ایک حقیقی ELF فائل سے مماثل کرنے کا کوئی راستہ نہیں ہے اگر وہاں کوئی build_id نہیں ہے تو ہمارا تقاضا ہے کہ ہر DSO کا یہاں موجود ہونا ضروری ہے۔
    ///
    /// DSO کو بغیر کسی build_id کو نظرانداز کردیا گیا ہے۔
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// اس DSO میں سیگمنٹ پر ایک ایٹریٹر لوٹاتا ہے۔
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// یہ غلطیاں ان DSO کو انکوڈ کرتی ہیں جو ہر DSO کے بارے میں معلومات کی تجزیہ کرتے ہوئے پیدا ہوتی ہیں۔
///
enum Error {
    /// نیوم ایور کا مطلب ہے کہ سی طرز کے اسٹرنگ کو rust تار میں تبدیل کرتے وقت ایک خرابی پیش آگئی۔
    ///
    NameError(core::str::Utf8Error),
    /// بلڈ آئڈر کا مطلب ہے کہ ہمیں کوئی بلڈ ID نہیں ملا۔
    /// یہ یا تو ہوسکتا ہے کیونکہ ڈی ایس او کی کوئی بلڈ آئی ڈی نہیں تھی یا اس وجہ سے کہ بلڈ ID پر مشتمل طبقہ خراب ہوا تھا۔
    ///
    BuildIDError,
}

/// متحرک لنکر کے ذریعہ عمل میں منسلک ہر DSO کے لئے یا تو 'dso' یا 'error' کال کریں۔
///
///
/// # Arguments
///
/// * `visitor` - ایک DsoPrinter جس میں کھانے کے طریقوں میں سے ایک پائے گا جس کو foreach DSO کہا جاتا ہے۔
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr اس بات کو یقینی بناتا ہے کہ info.name کسی درست جگہ کی طرف اشارہ کرے گا۔
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// یہ فنکشن DSO میں موجود تمام معلومات کے لئے فوچیا کے علامتی نشان کو پرنٹ کرتا ہے۔
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}