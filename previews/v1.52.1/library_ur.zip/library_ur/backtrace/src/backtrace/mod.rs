use core::ffi::c_void;
use core::fmt;

/// موجودہ کال اسٹیک کا معائنہ کرتا ہے ، اسٹیک ٹریس کا حساب کتاب کرنے کے لئے فراہم کردہ بندش میں تمام فعال فریموں کو منتقل کرتا ہے۔
///
/// یہ فنکشن اس لائبریری کا ایک ورک ہارس ہے جس میں کسی پروگرام کے اسٹیک کے نشانات کا حساب کتاب کیا جاتا ہے۔دی گئی بندش `cb` کو `Frame` کی مثال ملتی ہے جو اسٹیک پر اس کال فریم کے بارے میں معلومات کی نمائندگی کرتی ہے۔
/// بندش کو ٹاپ ڈاون فیشن (جس میں حال ہی میں پہلے افعال کو سب سے پہلے کہا جاتا ہے) میں فریم برآمد ہوتے ہیں۔
///
/// بندش کی واپسی کی قیمت اس بات کا اشارہ ہے کہ کیا بیک ٹریس جاری رہنی چاہئے۔`false` کی واپسی کی قیمت بیک ٹریس کو ختم کرے گی اور فوری طور پر واپس آئے گی۔
///
/// ایک بار جب `Frame` حاصل ہوجاتا ہے تو آپ `backtrace::resolve` پر `ip` (انسٹرکشن پوائنٹر) یا علامت ایڈریس کو `Symbol` میں تبدیل کرنے کے لئے فون کرنا چاہتے ہیں جس کے ذریعہ نام اور/یا فائل نام/لائن نمبر سیکھ سکتے ہیں۔
///
///
/// نوٹ کریں کہ یہ نسبتا low کم سطح کا فنکشن ہے اور اگر آپ ، مثال کے طور پر بعد میں معائنہ کرنے کے لئے بیک ٹریس پکڑنا چاہیں تو `Backtrace` ٹائپ زیادہ مناسب ہوسکتی ہے۔
///
/// # مطلوبہ خصوصیات
///
/// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
///
/// # Panics
///
/// یہ فنکشن کبھی بھی panic کی کوشش نہیں کرتا ، لیکن اگر `cb` نے panics فراہم کیا تو کچھ پلیٹ فارمز ڈبل panic کو اس عمل کو ختم کرنے پر مجبور کردیں گے۔
/// کچھ پلیٹ فارمز سی لائبریری کا استعمال کرتے ہیں جو داخلی طور پر کال بیکس کا استعمال کرتے ہیں جس کے ذریعہ اس کو ختم نہیں کیا جاسکتا ہے ، لہذا `cb` سے گھبرا کر عمل ختم ہونا شروع ہوسکتا ہے۔
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // backtrace جاری رکھیں
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` کی طرح ، صرف غیر محفوظ ہے کیونکہ یہ غیر منظم ہے۔
///
/// اس فنکشن میں ہم وقت سازی کی گارنٹیاں نہیں ہیں لیکن اس وقت دستیاب ہے جب اس crate کی `std` خصوصیت مرتب نہیں کی گئی ہے۔
/// مزید دستاویزات اور مثالوں کے لئے `trace` فنکشن دیکھیں۔
///
/// # Panics
///
/// گھبرانے والی `cb` سے متعلق انتباہات کے لئے `trace` پر معلومات دیکھیں۔
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// ایک trait ایک بیک ٹریس کے ایک فریم کی نمائندگی کرتا ہے ، اس crate کے `trace` فنکشن میں ملا۔
///
/// ٹریسنگ فنکشن کے بند ہونے سے فریم برآمد ہوں گے ، اور یہ فریم عملی طور پر روانہ کردی گئی ہے کیونکہ بنیادی عملدرآمد رن ٹائم تک ہمیشہ معلوم نہیں ہوتا ہے۔
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// اس فریم کا موجودہ انسٹرکشن پوائنٹر لوٹاتا ہے۔
    ///
    /// یہ عام طور پر فریم میں عمل کرنے کی اگلی ہدایت ہے ، لیکن تمام عمل درآمد 100 فیصد درستگی کے ساتھ اس کی فہرست نہیں لیتے ہیں (لیکن یہ عام طور پر بہت قریب ہے)۔
    ///
    ///
    /// اس کی قیمت کو `backtrace::resolve` پر منتقل کرنے کی تجویز کی جاتی ہے تاکہ اسے علامت کے نام میں تبدیل کیا جاسکے۔
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// اس فریم کا موجودہ اسٹیک پوائنٹر لوٹاتا ہے۔
    ///
    /// اس معاملے میں جب ایک پسدید اس فریم کے لئے اسٹیک پوائنٹر کو بازیافت نہیں کرسکتا ہے ، تو ایک کالا پوائنٹر واپس ہوجاتا ہے۔
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// اس فنکشن کے فریم کا ابتدائی علامت پتہ واپس کرتا ہے۔
    ///
    /// یہ `ip` کے ذریعہ فنکشن کے آغاز میں واپس ہونے والے انسٹرکشن پوائنٹر کو دوبارہ پلانے کی کوشش کرے گی ، اور اس قدر کو واپس کریں گے۔
    ///
    /// تاہم ، کچھ معاملات میں ، بیک فنڈز اس فنکشن سے `ip` صرف لوٹائیں گے۔
    ///
    /// اگر واپس دیئے گئے `ip` پر `backtrace::resolve` ناکام ہو تو واپس کی گئی قیمت کو کبھی کبھی استعمال کیا جاسکتا ہے۔
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// اس ماڈیول کا بنیادی پتہ واپس کرتا ہے جس سے فریم تعلق رکھتا ہے۔
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // اس بات کو یقینی بنانے کے ل first پہلے آنے کی ضرورت ہے کہ میزی میزبان پلیٹ فارم سے ماری کو ترجیح دیتی ہے
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // صرف dbghelp علامت میں استعمال کیا جاتا ہے
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}