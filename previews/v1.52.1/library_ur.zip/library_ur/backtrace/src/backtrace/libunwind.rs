//! libunwind/gcc_s/etc APIs کا استعمال کرتے ہوئے بیکٹریس سپورٹ۔
//!
//! اس ماڈیول میں لائبن ونڈ اسٹائل API کا استعمال کرتے ہوئے اسٹیک کو کھولنے کی صلاحیت موجود ہے۔
//! نوٹ کریں کہ لبنونڈ جیسے API کے پورے نفاذ کا ایک مجموعہ ہے ، اور یہ صرف چننے کی بجائے ان سب میں سے سب کے ساتھ ہم آہنگ ہونے کی کوشش کر رہا ہے۔
//!
//!
//! لبنونڈ API `_Unwind_Backtrace` کے ذریعہ تقویت یافتہ ہے اور عملی طور پر بیک ٹریس پیدا کرنے میں بہت قابل اعتماد ہے۔
//! یہ مکمل طور پر واضح نہیں ہے کہ یہ (فریم پوائنٹرز؟ ای_ فریم کی معلومات؟ دونوں؟) کیسے کام کرتا ہے لیکن ایسا لگتا ہے کہ یہ کام کرتا ہے!
//!
//! اس ماڈیول کی بیشتر پیچیدگیاں مختلف پلیٹ فارم اختلافات کو آزادانہ عمل کے نفاذ میں نمٹارہی ہیں۔
//! ورنہ یہ ایک بہت سیدھا سیدھا Rust ہے جو libunwind APIs کا پابند ہے۔
//!
//! فی الحال تمام غیر ونڈوز پلیٹ فارمز کے لئے یہ ڈیفالٹ غیر منسلک API ہے۔
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// کسی کچے لیبن ونڈ پوائنٹر کے ساتھ اسے صرف پڑھنے کے تھریڈ سیف فیشن میں ہی رسائی حاصل ہونی چاہئے ، لہذا یہ `Sync` ہے۔
// جب `Clone` کے ذریعے دوسرے دھاگوں کو بھیجتے وقت ہم ہمیشہ ایسے ورژن میں سوئچ کرتے ہیں جس میں داخلہ پوائنٹر برقرار نہیں ہوتا ہے ، لہذا ہمیں بھی `Send` ہونا چاہئے۔
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // ایسا لگتا ہے کہ OSX `_Windwind_FindEnclosingFunction` پر ایک پوائنٹر واپس کرتا ہے…جس میں کوئی بات واضح نہیں ہے۔
        // یہ یقینی طور پر ہمیشہ کسی بھی وجہ سے انکلوزنگ فنکشن نہیں ہوتا ہے۔
        // یہ مجھ پر مکمل طور پر واضح نہیں ہے کہ یہاں کیا ہورہا ہے ، لہذا اس کا ابھی ناراضگی کریں اور ہمیشہ آئی پی کو واپس کریں۔
        //
        // نوٹ کریں اس شق کی وجہ سے `skip_inner_frames.rs` ٹیسٹ OSX پر چھوڑ دیا گیا ہے ، اور اگر یہ طے ہوجاتا ہے کہ نظریہ میں ٹیسٹ OSX پر چلایا جاسکتا ہے!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// بیک ٹریس کے لئے استعمال شدہ لائبریری انٹرفیس کو کھولیں
///
/// نوٹ کریں کہ ڈیڈ کوڈ کی اجازت ہے کیونکہ یہاں صرف پابندیوں کی حیثیت سے iOS ان سب کو استعمال نہیں کرتا ہے لیکن زیادہ پلیٹ فارم سے متعلق کنفیگراف شامل کرنے سے کوڈ کو بہت زیادہ آلودہ کیا جاتا ہے
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // صرف آرمی EABI کے ذریعہ استعمال کیا جاتا ہے
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // آئی او ایس پر کوئی آبائی _Uwind_Backtrace نہیں ہے
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 کے بعد سے دستیاب ہے ، ہمارے مقصد کے لئے ٹھیک ہونا چاہئے
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // یہ فنکشن غلط فہمی ہے: اس فریم کا کینونیکل فریم ایڈریس (عرف کالر فریم کا ایس پی) حاصل کرنے کے بجائے یہ اس فریم کا ایس پی لوٹاتا ہے۔
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x ایک متعصب سی ایف اے قدر استعمال کرتی ہے ، لہذا ہمیں _ انونڈ_ گیٹ سی ایف اے پر انحصار کرنے کی بجائے اسٹیک پوائنٹر رجسٹر (%r15) حاصل کرنے کے لئے _ انونڈ_ گیٹجی آر استعمال کرنے کی ضرورت ہے۔
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android اور بازو پر ، فنکشن android اور دوسروں کا ایک گروپ میکرو ہیں ، لہذا ہم میکرو کی توسیع پر مشتمل افعال کی وضاحت کرتے ہیں۔
    //
    //
    // TODO: ہیڈر فائل سے لنک کریں جو ان میکروز کی وضاحت کرتی ہے ، اگر آپ اسے ڈھونڈ سکتے ہیں۔
    // (میں ، فٹ زین ، ہیڈر فائل نہیں پا سکتا جس میں سے کچھ میکرو توسیع اصل میں لیا گیا تھا۔)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 بازو پر اسٹیک پوائنٹر ہے۔
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // یہ فنکشن Android یا ARM/Linux پر بھی موجود نہیں ہے ، لہذا اسے کوئی آپٹ نہیں بنائیں۔
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}