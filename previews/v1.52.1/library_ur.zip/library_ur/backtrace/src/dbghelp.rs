//! Windows پر dbghelp پابندیوں کا انتظام کرنے میں مدد کرنے والا ایک ماڈیول
//!
//! Windows پر بیک ٹریس (کم از کم MSVC کے لئے) بڑے پیمانے پر `dbghelp.dll` اور اس میں شامل مختلف افعال کے ذریعے طاقت حاصل کی جاتی ہے۔
//! یہ افعال فی الحال `dbghelp.dll` کو جامد طور پر جوڑنے کے بجائے *متحرک* بھری ہوئی ہیں۔
//! یہ فی الحال معیاری لائبریری کے ذریعہ کیا جاتا ہے (اور وہاں نظریہ میں اس کی ضرورت ہوتی ہے) ، لیکن کسی لائبریری کے مستحکم dll انحصار کو کم کرنے میں مدد کرنے کی کوشش کی جارہی ہے کیونکہ عام طور پر بیکٹریس بہت ہی اختیاری ہیں۔
//!
//! یہ کہا جارہا ہے ، `dbghelp.dll` تقریبا ہمیشہ کامیابی کے ساتھ Windows پر بوجھ ڈالتا ہے۔
//!
//! اگرچہ نوٹ کریں کہ چونکہ ہم یہ ساری سپورٹ متحرک طور پر لوڈ کررہے ہیں ہم دراصل `winapi` میں خام تعریفیں استعمال نہیں کرسکتے ہیں ، بلکہ ہمیں فنکشن پوائنٹ پوائنٹر کی اقسام کو خود ہی بیان کرنے اور اسے استعمال کرنے کی ضرورت ہے۔
//! ہم واقعی ونپیپی کی جعل سازی کے کاروبار میں شامل نہیں ہونا چاہتے ہیں ، لہذا ہمارے پاس ایک Cargo کی خصوصیت `verify-winapi` ہے جو یہ دعوی کرتی ہے کہ تمام پابندیاں وناپی میں مماثل ہیں اور یہ خصوصیت CI پر اہل ہے۔
//!
//! آخر میں ، آپ یہاں نوٹ کریں گے کہ `dbghelp.dll` کے لئے ڈیل کبھی نہیں اتارا جاتا ہے ، اور یہ فی الحال جان بوجھ کر ہے۔
//! سوچ یہ ہے کہ ہم مہنگے loads/unloads سے گریز کرتے ہوئے اسے عالمی سطح پر کیش کرسکتے ہیں اور اسے API میں آنے والی کال کے درمیان استعمال کرسکتے ہیں۔
//! اگر یہ لیک ڈٹیکٹرس یا اس طرح کی کوئی چیز ہے تو جب ہم وہاں پہنچیں گے تو ہم پل کو عبور کرسکتے ہیں۔
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` اور `SymSetOptions` کے ارد گرد کام کرنا ونپی میں خود موجود نہیں ہے۔
// بصورت دیگر یہ تب استعمال ہوتا ہے جب ہم ونپی کے خلاف اقسام کی ڈبل جانچ پڑتال کرتے ہیں۔
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ابھی تک ونپی میں تعریف نہیں کی گئی ہے
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // اس کی تعریف وناپی میں کی گئی ہے ، لیکن یہ غلط ہے (FIXME winapi-##768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ابھی تک ونپی میں تعریف نہیں کی گئی ہے
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// یہ میکرو ایک `Dbghelp` ڈھانچے کی وضاحت کرنے کے لئے استعمال کیا جاتا ہے جس میں اندرونی طور پر وہ تمام فنکشن پوائنٹرز موجود ہوتے ہیں جن پر ہم لوڈ کرسکتے ہیں۔
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` کیلئے بھری ہوئی DLL
            dll: HMODULE,

            // ہر فنکشن کے لئے ہر فنکشن پوائنٹر جو ہم استعمال کرسکتے ہیں
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // ابتدا میں ہم نے DLL نہیں ڈالا
            dll: 0 as *mut _,
            // ابتدائی طور پر تمام افعال کو صفر پر سیٹ کیا جاتا ہے تاکہ یہ کہا جاسکے کہ انہیں متحرک طور پر لوڈ کرنے کی ضرورت ہے۔
            //
            $($name: 0,)*
        };

        // سہولت ٹائپف ہر کام کی قسم کے لئے۔
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` کھولنے کی کوششیں۔
            /// کامیابی ملتی ہے اگر یہ کام کرتا ہے یا غلطی ہوتی ہے اگر `LoadLibraryW` ناکام ہوجاتا ہے۔
            ///
            /// Panics اگر لائبریری پہلے ہی بھری ہوئی ہو۔
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // ہر ایک طریقہ کے لئے فنکشن جو ہم استعمال کرنا چاہتے ہیں۔
            // جب کہا جاتا ہے تو یہ کیشڈ فنکشن پوائنٹر کو پڑھے گا یا اسے لوڈ کرے گا اور بھری ہوئی قیمت کو واپس کرے گا۔
            // بوجھ کو کامیابی کے لئے زور دیا جاتا ہے۔
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // dbghelp کے افعال کے حوالے سے صفائی والے تالے استعمال کرنے کے لئے سہولت پراکسی۔
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// اس crate سے `dbghelp` API فنکشن تک رسائی کے لئے ضروری تمام سپورٹ کو شروع کریں۔
///
///
/// نوٹ کریں کہ یہ فنکشن **محفوظ** ہے ، اندرونی طور پر اس کی اپنی ہم آہنگی ہے۔
/// یہ بھی نوٹ کریں کہ اس فعل کو متعدد بار بار بار فون کرنا محفوظ ہے۔
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // اس کام کو ہم وقت ساز بنانا ہے ہمیں سب سے پہلے۔اسے دوسرے دھاگوں سے بیک وقت یا ایک دھاگے میں بار بار کہا جاسکتا ہے۔
        // نوٹ کریں کہ یہ اس سے بھی مشکل ہے حالانکہ جو ہم یہاں استعمال کررہے ہیں ، `dbghelp` ،*بھی* دوسرے سارے کال کرنے والوں کے ساتھ اس عمل میں `dbghelp` پر ہم آہنگ ہونے کی ضرورت ہے۔
        //
        // عام طور پر ایک ہی عمل میں واقعی نہیں ہے کہ `dbghelp` پر بہت سی کالیں ہیں اور ہم شاید محفوظ طور پر یہ فرض کر سکتے ہیں کہ ہم صرف اس تک رسائی حاصل کر رہے ہیں۔
        // تاہم ، ایک بنیادی دوسرا صارف ہے جس کے بارے میں ہمیں پریشانی کا سامنا کرنا پڑتا ہے جس کی ستم ظریفی یہ ہے کہ ہم خود ، لیکن معیاری لائبریری میں ہیں۔
        // Rust معیاری لائبریری اس crate پر انحصار کرتی ہے بیکٹریس سپورٹ کیلئے ، اور یہ crate بھی crates.io پر موجود ہے۔
        // اس کا مطلب یہ ہے کہ اگر معیاری لائبریری panic بیک ٹریس پرنٹ کر رہی ہے تو اس crate crates.io سے آنے والی دوڑ کے ساتھ مقابلہ کرسکتی ہے ، جس سے سیگفالٹس پیدا ہوتے ہیں۔
        //
        // اس ہم آہنگی کے مسئلے کو حل کرنے میں مدد کے ل we ہم یہاں ونڈوز کے مخصوص چال کو ملازمت دیتے ہیں (یہ ، ہم آہنگی کے بارے میں ونڈوز کے ساتھ مخصوص پابندی ہے)۔
        // ہم اس کال کی حفاظت کیلئے ایک *سیشن لوکل* نامی میٹیکس بناتے ہیں۔
        // یہاں مقصود یہ ہے کہ معیاری لائبریری اور اس crate کو یہاں مطابقت پذیر ہونے کے لئے Rust سطح کے APIs کا اشتراک نہیں کرنا پڑے گا لیکن اس کی بجائے یہ یقینی بنانے کے لئے کہ پردے کے پیچھے کام کرسکیں کہ وہ ایک دوسرے کے ساتھ ہم آہنگی پیدا کررہے ہیں۔
        //
        // اس طرح جب اس فنکشن کو معیاری لائبریری کے ذریعہ یا crates.io کے ذریعے بلایا جاتا ہے تو ہم یقین کر سکتے ہیں کہ اسی میٹیکس کو حاصل کیا جارہا ہے۔
        //
        // تو یہ سب کہنا ہے کہ سب سے پہلے جو کام ہم یہاں کرتے ہیں وہ یہ ہے کہ ہم جوہری طور پر ایک `HANDLE` تشکیل دیتے ہیں جو Windows پر ایک نامی گونگا ہے۔
        // ہم دوسرے دھاگوں کے ساتھ تھوڑا سا ہم وقت سازی کرتے ہیں جو خاص طور پر اس فنکشن کو شیئر کرتے ہیں اور اس بات کو یقینی بناتے ہیں کہ اس فنکشن کی مثال کے طور پر صرف ایک ہی ہینڈل تیار کیا جائے۔
        // نوٹ کریں کہ جب یہ عالمی سطح پر ذخیرہ ہوتا ہے تو اسے ہینڈل کبھی بھی بند نہیں کیا جاتا ہے۔
        //
        // حقیقت میں اس لاک کے جانے کے بعد ہم اسے آسانی سے حاصل کرتے ہیں ، اور ہم جو `Init` ہینڈل دیتے ہیں وہ اسے گرنے کا ذمہ دار ہوگا۔
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ٹھیک ہے ، بھائی!اب چونکہ ہم سب محفوظ طریقے سے ہم آہنگی اختیار کرچکے ہیں ، آئیے حقیقت میں ہر چیز پر کارروائی شروع کرتے ہیں۔
        // پہلے ہمیں یہ یقینی بنانا ہوگا کہ اس عمل میں `dbghelp.dll` دراصل بھری ہوئی ہے۔
        // ہم مستحکم انحصار سے بچنے کے لئے یہ متحرک طور پر کرتے ہیں۔
        // یہ تاریخی طور پر عجیب و غریب منسلک امور کے بارے میں کام کرنے کے لئے کیا گیا ہے اور اس کا مقصد بائنریز کو قدرے زیادہ پورٹیبل بنانا ہے کیونکہ یہ بڑی حد تک صرف ایک ٹھیک کرنے والی افادیت ہے۔
        //
        //
        // ایک بار جب ہم `dbghelp.dll` کھول چکے ہیں تو ہمیں اس میں کچھ ابتدائی کاموں کو کال کرنے کی ضرورت ہے ، اور اس کے بارے میں مزید تفصیل ذیل میں ہے۔
        // ہم صرف ایک بار ایسا کرتے ہیں ، اگرچہ ، لہذا ہمارے پاس ایک عالمی بولین ہے جس سے یہ معلوم ہوتا ہے کہ ہم ابھی تک ہوچکے ہیں یا نہیں۔
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // اس بات کو یقینی بنائیں کہ `SYMOPT_DEFERRED_LOADS` پرچم سیٹ ہے ، کیوں کہ اس بارے میں ایم ایس وی سی کے اپنے دستاویزات کے مطابق: "This is the fastest, most efficient way to use the symbol handler." ، لہذا آئیے ایسا کریں!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // دراصل ایم ایس وی سی کے ساتھ علامتوں کی ابتدا کریں۔نوٹ کریں کہ یہ ناکام ہوسکتا ہے ، لیکن ہم اسے نظرانداز کرتے ہیں۔
        // اس فی سیکنڈ کے لئے ایک ٹن پیشگی فن موجود نہیں ہے ، لیکن ایسا لگتا ہے کہ ایل ایل وی ایم اندرونی طور پر یہاں واپسی کی قیمت کو نظر انداز کرے گا اور ایل ایل وی ایم میں موجود ایک سینیٹائزر لائبریری خوفناک انتباہ پرنٹ کرتا ہے اگر یہ ناکام ہوجاتا ہے لیکن بنیادی طور پر طویل عرصے میں اس کو نظرانداز کرتا ہے۔
        //
        //
        // ایک معاملہ جو Rust کے لئے بہت زیادہ سامنے آتا ہے وہ ہے معیاری لائبریری اور crates.io پر یہ crate دونوں `SymInitializeW` کا مقابلہ کرنا چاہتے ہیں۔
        // تاریخی طور پر معیاری لائبریری زیادہ تر وقت پھر صفائی کرنا چاہتی تھی ، لیکن اب جب وہ یہ crate استعمال کررہا ہے تو اس کا مطلب یہ ہے کہ پہلے کسی کو ابتدائیہ ملے گا اور دوسرا ابتدائی آغاز کرے گا۔
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}