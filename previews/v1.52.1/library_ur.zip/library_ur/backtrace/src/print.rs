#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// بیکٹریس کے لئے ایک فارمیٹر۔
///
/// اس قسم کا بیکٹریس پرنٹ کرنے کے لئے استعمال کیا جاسکتا ہے اس سے قطع نظر کہ بیک ٹریس خود کہاں سے آیا ہے۔
/// اگر آپ کے پاس `Backtrace` قسم ہے تو پھر اس کا `Debug` نفاذ پہلے ہی اس پرنٹنگ کی شکل کو استعمال کرتا ہے۔
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// پرنٹنگ کے اسلوب جو ہم پرنٹ کرسکتے ہیں
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// ٹرسر بیکٹریس پرنٹ کرتا ہے جس میں صرف متعلقہ معلومات ہوتی ہے
    Short,
    /// ایک بیک ٹریس پرنٹ کریں جس میں تمام ممکنہ معلومات شامل ہوں
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// ایک نیا `BacktraceFmt` بنائیں جو فراہم کردہ `fmt` پر آؤٹ پٹ لکھے گا۔
    ///
    /// `format` دلیل اس انداز کو کنٹرول کرے گی جس میں بیک ٹریس طباعت کی گئی ہے ، اور `print_path` دلیل `BytesOrWideString` مثال کے طور پر فائل کے ناموں کو پرنٹ کرنے کے لئے استعمال کیا جائے گا۔
    /// اس قسم سے خود فائل ناموں کی کوئی پرنٹنگ نہیں ہوتی ہے ، لیکن ایسا کرنے کے لئے اس کال بیک کی ضرورت ہے۔
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// بیک ٹریس پرنٹ ہونے کے بارے میں ایک تجوید کی اشاعت کرتا ہے۔
    ///
    /// بیک ٹریس کے لئے کچھ پلیٹ فارمز پر بعد میں مکمل علامت ہونے کی ضرورت ہوتی ہے ، اور بصورت دیگر یہ `BacktraceFmt` بنانے کے بعد آپ کو پہلا طریقہ ہونا چاہئے۔
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// بیک ٹریس آؤٹ پٹ میں ایک فریم جوڑتا ہے۔
    ///
    /// اس کا ارتکاب ایک `BacktraceFrameFmt` کی RAII مثال دیتا ہے جس کو اصل میں کسی فریم کو پرنٹ کرنے کے لئے استعمال کیا جاسکتا ہے ، اور تباہی پر یہ فریم کاؤنٹر میں اضافہ کرے گا۔
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// بیک ٹریس آؤٹ پٹ کو مکمل کرتا ہے۔
    ///
    /// یہ فی الحال کوئی آپٹ نہیں ہے لیکن بیک ٹریس فارمیٹس کے ساتھ زیڈ فیوچر0 زیڈ مطابقت کے لئے شامل کیا گیا ہے۔
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // اس وقت fook اضافے کی اجازت دینے کے لئے اس hook سمیت کوئی آپشن نہیں ہے۔
        Ok(())
    }
}

/// بیکٹریس کے صرف ایک فریم کا فارمیٹر۔
///
/// اس قسم کو `BacktraceFmt::frame` فنکشن کے ذریعہ تخلیق کیا گیا ہے۔
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// اس فریم فارمیٹر کے ساتھ ایک `BacktraceFrame` پرنٹ کرتا ہے۔
    ///
    /// یہ `BacktraceFrame` کے اندر تمام `BacktraceSymbol` مثالوں کو بار بار پرنٹ کرے گا۔
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// ایک `BacktraceFrame` میں `BacktraceSymbol` پرنٹ کرتا ہے۔
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: یہ بہت اچھا نہیں ہے کہ ہم کسی بھی چیز کی طباعت ختم نہیں کرتے ہیں
            // غیر utf8 فائل ناموں کے ساتھ۔
            // شکر ہے کہ تقریبا everything ہر چیز utf8 ہے لہذا یہ زیادہ برا بھی نہیں ہونا چاہئے۔
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// عام طور پر اس crate کے خام کال بیکس کے اندر سے ، کسی خام ٹریس کردہ `Frame` اور `Symbol` پرنٹ کریں۔
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// بیک ٹریس آؤٹ پٹ میں خام فریم شامل کرتا ہے۔
    ///
    /// یہ طریقہ ، پچھلے کے برعکس ، خام دلائل کو لے لیتا ہے اگر وہ مختلف مقامات سے ماخذ ہوں۔
    /// نوٹ کریں کہ یہ ایک فریم کے لئے متعدد بار کہا جاسکتا ہے۔
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// بیک ٹریس آؤٹ پٹ میں خام فریم شامل کرتا ہے ، بشمول کالم کی معلومات۔
    ///
    /// یہ طریقہ ، پچھلے کی طرح ، خام دلائل کو لے لیتا ہے اگر وہ مختلف مقامات سے ماخذ ہوں۔
    /// نوٹ کریں کہ یہ ایک فریم کے لئے متعدد بار کہا جاسکتا ہے۔
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // فوچیا کسی عمل میں علامت بنانے سے قاصر ہے لہذا اس کی ایک خاص شکل ہے جسے بعد میں علامت بنانے کے لئے استعمال کیا جاسکتا ہے۔
        // ہمارے یہاں اپنی شکل میں پتے پرنٹنگ کے بجائے پرنٹ کریں۔
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" فریموں کو پرنٹ کرنے کی ضرورت نہیں ، اس کا بنیادی طور پر صرف یہ مطلب ہے کہ سسٹم بیکٹریس تھوڑا سا پیچھے تک سپر بیک کا سراغ لگانے کے لئے بے چین تھا۔
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // ایس جی ایکس انکلیو میں ٹی سی بی سائز کم کرنے کے ل To ، ہم علامت ریزولوشن کی فعالیت کو نافذ نہیں کرنا چاہتے ہیں۔
        // بلکہ ، ہم یہاں ایڈریس کے آفسیٹ پرنٹ کرسکتے ہیں ، جو بعد میں درستگی کے ساتھ نقش کو درست کرسکتے ہیں۔
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // فریم کے اشاریہ کے ساتھ ساتھ فریم کے اختیاری انسٹرکشن پوائنٹر پرنٹ کریں۔
        // اگر ہم اس فریم کی پہلی علامت سے پرے ہیں اگرچہ ہم صرف مناسب سفید فام جگہ پرنٹ کرتے ہیں۔
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // اگر ہم مکمل بیک ٹریک ہو تو مزید معلومات کے لئے متبادل فارمیٹنگ کا استعمال کرتے ہوئے اگلے سمبل کا نام لکھیں۔
        // یہاں ہم ان علامتوں کو بھی سنبھالتے ہیں جن کا نام نہیں ہے ،
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // اور آخری بات ، اگر دستیاب ہو تو filename/line نمبر پرنٹ کریں۔
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line علامت نام کے تحت لائنوں پر چھاپے جاتے ہیں ، لہذا خود کو سیدھے کرنے کے ل some کچھ مناسب وہائٹ اسپیس پرنٹ کریں۔
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // فائل نام کو پرنٹ کرنے کے لئے ہمارے داخلی کال بیک پر عمل کریں اور پھر لائن نمبر پرنٹ کریں۔
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // اگر دستیاب ہو تو کالم نمبر شامل کریں۔
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // ہم صرف کسی فریم کی پہلی علامت کی پرواہ کرتے ہیں
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}