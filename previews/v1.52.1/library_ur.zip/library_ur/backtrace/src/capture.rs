use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// ایک ملکیت اور خود موجود بیکٹریس کی نمائندگی۔
///
/// اس ڈھانچے کا استعمال پروگرام میں مختلف مقامات پر بیکٹریس پر قبضہ کرنے کے لئے کیا جاسکتا ہے اور بعد میں یہ معائنہ کیا جاسکتا تھا کہ اس وقت بیکٹریس کیا تھا۔
///
///
/// `Backtrace` اس کے `Debug` نفاذ کے ذریعے بیک ٹریس کی خوبصورت پرنٹنگ کی حمایت کرتا ہے۔
///
/// # مطلوبہ خصوصیات
///
/// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // یہاں فریم اسٹیک کے اوپر سے نیچے تک درج ہیں
    frames: Vec<BacktraceFrame>,
    // جس انڈیکس کو ہم سمجھتے ہیں وہ بیک ٹریس کی اصل شروعات ہے ، جیسے `Backtrace::new` اور `backtrace::trace` جیسے فریموں کو چھوڑنا۔
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// بیک ٹریس میں فریم کا قبضہ شدہ ورژن۔
///
/// اس قسم کو `Backtrace::frames` کی فہرست کے طور پر واپس کیا گیا ہے اور قبضہ شدہ بیکٹریس میں ایک اسٹیک فریم کی نمائندگی کرتا ہے۔
///
/// # مطلوبہ خصوصیات
///
/// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// بیکٹریس میں علامت کا قبضہ شدہ ورژن۔
///
/// اس قسم کو `BacktraceFrame::symbols` کی فہرست کے بطور لوٹا گیا ہے اور بیکٹریس میں کسی علامت کیلئے میٹا ڈیٹا کی نمائندگی کرتا ہے۔
///
/// # مطلوبہ خصوصیات
///
/// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// اس فنکشن کی کالائٹ پر بیک ٹریس پکڑتا ہے ، ملکیت کی نمائندگی لوٹاتا ہے۔
    ///
    /// یہ فنکشن Rust میں بیک ٹریس کی نمائندگی کے لئے کارآمد ہے۔یہ لوٹی گئی قیمت تھریڈز میں بھیجی جاسکتی ہے اور کہیں اور پرنٹ کی جاسکتی ہے ، اور اس قدر کا مقصد یہ ہے کہ اس میں پوری طرح سے خود کو شامل کیا جائے۔
    ///
    /// نوٹ کریں کہ کچھ پلیٹ فارمز پر مکمل بیکٹریس حاصل کرنا اور اسے حل کرنا انتہائی مہنگا پڑسکتا ہے۔
    /// اگر آپ کی درخواست کے لئے لاگت بہت زیادہ ہے تو اس کی بجائے `Backtrace::new_unresolved()` استعمال کرنے کی سفارش کی گئی ہے جو علامت کے حل کے اقدام سے گریز کرتا ہے (جو عام طور پر سب سے زیادہ وقت لگتا ہے) اور بعد میں اس کی تاریخ کو موخر کرنے کی اجازت دیتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // یہ یقینی بنانا چاہتے ہیں کہ یہاں ایک فریم ہٹانے کے لئے ہے
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` کی طرح ، سوائے اس کے کہ اس سے کوئی علامت حل نہیں ہوتا ہے ، یہ صرف پتے کی فہرست کے طور پر بیک ٹریس کو اپنی گرفت میں لے جاتا ہے۔
    ///
    /// بعد میں `resolve` فنکشن کو اس بیکٹریس کی علامتوں کو پڑھنے کے قابل ناموں میں حل کرنے کے لئے بلایا جاسکتا ہے۔
    /// یہ فنکشن موجود ہے کیوں کہ ریزولوشن پروسس میں بعض اوقات کافی حد تک وقت لگ سکتا ہے جبکہ کسی ایک بیک ٹریس کو شاذ و نادر ہی پرنٹ کیا جاسکتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // علامت نام نہیں
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // علامت نام اب موجود ہیں
    /// ```
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    ///
    ///
    #[inline(never)] // یہ یقینی بنانا چاہتے ہیں کہ یہاں ایک فریم ہٹانے کے لئے ہے
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// جب سے یہ بیک ٹریس پکڑا گیا تھا فریم واپس کرتا ہے۔
    ///
    /// اس سلائس کی پہلی اندراج ممکنہ طور پر فنکشن `Backtrace::new` ہے ، اور آخری فریم ممکنہ طور پر کچھ ہے کہ اس تھریڈ یا مرکزی فنکشن کا آغاز کیسے ہوا۔
    ///
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// اگر یہ بیک ٹریس `new_unresolved` سے بنایا گیا تھا تو پھر یہ فنکشن پچھلے خط میں موجود تمام پتوں کو ان کے علامتی ناموں تک حل کردے گا۔
    ///
    ///
    /// اگر یہ بیک ٹریس پہلے حل ہوچکی ہے یا `new` کے ذریعہ بنی تھی تو ، اس فنکشن سے کچھ نہیں ہوتا ہے۔
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// ان فریموں سے ملتی علامتوں کی فہرست لوٹاتا ہے۔
    ///
    /// عام طور پر فی فریم میں صرف ایک ہی علامت ہوتی ہے ، لیکن بعض اوقات اگر بہت سارے کام ایک ہی فریم میں لگائے جاتے ہیں تو ایک سے زیادہ علامتیں واپس کردی گئیں۔
    /// سب سے پہلے درج کردہ علامت "innermost function" ہے ، جبکہ آخری علامت بیرونی قریب (آخری کالر) ہے۔
    ///
    /// نوٹ کریں کہ اگر یہ فریم غیر حل شدہ بیک ٹریک سے آیا ہے تو پھر یہ خالی فہرست لوٹائے گا۔
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` کی طرح ہی
    ///
    /// # مطلوبہ خصوصیات
    ///
    /// اس فنکشن کے لئے `backtrace` crate کی `std` خصوصیت کو فعال کرنے کی ضرورت ہے ، اور `std` خصوصیت کو بطور ڈیفالٹ فعال کیا جاتا ہے۔
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // جب راستے پرنٹ کرتے ہیں تو ہم کوشش کرتے ہیں کہ اگر cwd موجود ہے ، تو ہم اسے ختم کردیں ، بصورت دیگر ہم صرف اس طرح کے راستے پرنٹ کرتے ہیں۔
        // نوٹ کریں کہ ہم یہ صرف مختصر فارمیٹ کے ل do کرتے ہیں ، کیونکہ اگر یہ مکمل ہو تو ہم شاید ہر چیز کو پرنٹ کرنا چاہتے ہیں۔
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}