use backtrace::Backtrace;

// 50-کردار ماڈیول نام
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-کردار کا نام
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// لمبی تقریب کے ناموں کو (MAX_SYM_NAME، 1) حروف تک چھوٹا ہونا چاہئے۔
// صرف اس ٹیسٹ کو ایم ایس وی سی کے لئے چلائیں ، کیونکہ gnu تمام فریموں کے لئے "<no info>" پرنٹ کرتا ہے۔
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // ڈھانچے کے نام کی 10 تکراریں ، لہذا مکمل طور پر اہل فنکشن کا نام کم از کم 10 *(50 + 50)* 2=2000 حرف لمبا ہے۔
    //
    // اس میں `::` ، `<>` اور موجودہ ماڈیول کا نام بھی شامل ہے کیونکہ یہ واقعی زیادہ لمبا ہے
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}