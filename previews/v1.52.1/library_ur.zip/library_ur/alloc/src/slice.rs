//! ایک متحرک انداز میں متحرک سائز کا نظارہ ، `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! سلائسس ایک نقطہ نظر کی حیثیت سے میموری کے ایک بلاک میں یہ ایک نظارہ ہے۔
//!
//! ```
//! // ایک Vec کاٹنا
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ایک سلائس پر ایک صف کو مجبور کرنا
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! سلائسیں یا تو تبدیل شدہ یا مشترکہ ہیں۔
//! مشترکہ سلائس کی قسم `&[T]` ہے ، جبکہ متغیر سلائس کی قسم `&mut [T]` ہے ، جہاں `T` عنصر کی قسم کی نمائندگی کرتا ہے۔
//! مثال کے طور پر ، آپ میموری کے اس بلاک کو تبدیل کرسکتے ہیں جس میں ایک تبدیل شدہ سلائس اشارہ کرتا ہے:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! اس ماڈیول میں شامل کچھ چیزیں یہ ہیں:
//!
//! ## Structs
//!
//! بہت ساری تدبیریں ہیں جو سلائس کے ل useful مفید ہیں ، جیسے [`Iter`] ، جو سلائس کے ذریعہ تکرار کی نمائندگی کرتا ہے۔
//!
//! ## Trait اطلاق
//!
//! سلائسین کے ل common عام traits کے متعدد نفاذ ہیں۔کچھ مثالوں میں شامل ہیں:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] ، ان ٹکڑوں کے لئے جن کی عنصر کی قسم [`Eq`] یا [`Ord`] ہے۔
//! * [`Hash`] - ان ٹکڑوں کے لئے جن کی عنصر کی قسم [`Hash`] ہے۔
//!
//! ## Iteration
//!
//! سلائسیں `IntoIterator` لاگو کرتی ہیں۔آئٹرٹر سلائس عناصر کا حوالہ پیش کرتا ہے۔
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! تغیر پزیر سلائس عناصر کے لئے متغیر حوالہ جات برآمد کرتا ہے:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! یہ تکرار کرنے والا سلائس کے عناصر کے لئے متغیر حوالہ جات پیش کرتا ہے ، لہذا جب کہ سلائس کی عنصر کی قسم `i32` ہے ، جبکہ دوبارہ کرنے والا عنصر کی قسم `&mut i32` ہے۔
//!
//!
//! * [`.iter`] اور [`.iter_mut`] صراحت والے طریق کار ہیں جو ڈیفالٹ ریڈیٹرس کو لوٹاتے ہیں۔
//! * اگراٹرس کو لوٹنے والے مزید طریقے [`.split`] ، [`.splitn`] ، [`.chunks`] ، [`.windows`] اور زیادہ ہیں۔
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// اس ماڈیول میں بہت سے استعمال صرف ٹیسٹ کی ترتیب میں استعمال ہوتے ہیں۔
// غیر استعمال شدہ وارداتوں کو درست کرنے کے بجائے انتباہی بند کرنا ہی صاف ہے۔
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// بنیادی سلائس توسیع کے طریقے
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB جانچ کے دوران `vec!` میکرو کے نفاذ کے لئے ضروری ہے ، مزید تفصیلات کے لئے اس فائل میں `vec!` X ماڈیول دیکھیں۔
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB جانچ کے دوران `Vec::clone` کے نفاذ کے لئے ضروری ہے ، مزید تفصیلات کے لئے اس فائل میں `Vec::clone` X ماڈیول دیکھیں۔
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` دستیاب نہیں ہے ، یہ تینوں افعال دراصل ایسے طریقے ہیں جو `impl [T]` میں ہیں لیکن `core::slice::SliceExt` میں نہیں ، ہمیں یہ افعال `test_permutations` ٹیسٹ کے لئے فراہم کرنے کی ضرورت ہے
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ہمیں اس میں ان لائن وصف شامل نہیں کرنا چاہئے کیونکہ یہ زیادہ تر `vec!` میکرو میں استعمال ہوتا ہے اور اس سے عل perf رجعت کا سبب بنتا ہے۔
    // بحث اور بہترین نتائج کے لئے #71204 دیکھیں۔
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // آئٹمز کو نیچے لوپ میں ابتدائی طور پر نشان زد کیا گیا تھا
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ایل ایل وی ایم کے لئے حدود کی جانچ پڑتال کو دور کرنا ضروری ہے اور اس میں زپ سے بہتر کوڈجن ہے۔
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // کم از کم اس لمبائی کے لئے وی سی کو مختص کیا گیا تھا اور اوپر شروع کیا گیا تھا۔
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` کی گنجائش کے ساتھ اوپر مختص ، اور نیچے ptr::copy_to_non_overlapping میں `s.len()` کا آغاز کریں۔
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// سلائس کو ترتیب دیتا ہے۔
    ///
    /// یہ ترتیب مستحکم ہے (جیسے ، مساوی عناصر کو دوبارہ ترتیب نہیں دیتا ہے) اور *O*(*n*\*log(* n*)) بدترین حالت)۔
    ///
    /// جب قابل اطلاق ہوتا ہے تو ، غیر مستحکم چھانٹائی کو ترجیح دی جاتی ہے کیونکہ یہ عام طور پر مستحکم چھانٹنے سے تیز تر ہوتا ہے اور اس سے متعلق معاون میموری مختص نہیں ہوتا ہے۔
    /// [`sort_unstable`](slice::sort_unstable) دیکھیں۔
    ///
    /// # موجودہ عمل درآمد
    ///
    /// موجودہ الگورتھم [timsort](https://en.wikipedia.org/wiki/Timsort) سے متاثر ہوکر ایک انکولی ، مکرر انضمام ترتیب ہے۔
    /// یہ ان معاملات میں بہت تیزی سے تیار کیا گیا ہے جہاں ٹکڑا تقریباorted ترتیب دیا گیا ہو ، یا دو یا دو سے زیادہ ترتیب والے سلسلوں پر مشتمل ہو جس کے بعد ایک کے بعد ایک دوسرے کے ساتھ اتفاق کیا گیا ہو۔
    ///
    ///
    /// نیز ، یہ `self` کے نصف سائز عارضی اسٹوریج کو مختص کرتا ہے ، لیکن مختصر سلائسوں کے بجائے اس میں اس کے بجائے غیر مختص کی جانے والی اضافے کا استعمال کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// موازنہ کی تقریب کے ساتھ سلائس کو ترتیب دیتا ہے۔
    ///
    /// یہ ترتیب مستحکم ہے (جیسے ، مساوی عناصر کو دوبارہ ترتیب نہیں دیتا ہے) اور *O*(*n*\*log(* n*)) بدترین حالت)۔
    ///
    /// موازنہ کرنے والا فنکشن سلائس میں موجود عناصر کے ل order مجموعی ترتیب کی وضاحت کرے۔اگر آرڈرنگ کل نہیں ہے تو ، عناصر کا آرڈر غیر متعینہ ہے۔
    /// آرڈر کل آرڈر ہے اگر یہ (تمام `a` ، `b` اور `c` کیلئے):
    ///
    /// * کل اور اینٹیسمیمٹرک: بالکل `a < b` ، `a == b` یا `a > b` میں سے ایک صحیح ہے ، اور
    /// * ٹرانزیوٹک ، `a < b` اور `b < c` کا مطلب `a < c` ہے۔`==` اور `>` دونوں کے ل The یکساں ہونا ضروری ہے۔
    ///
    /// مثال کے طور پر ، جبکہ [`f64`] [`Ord`] پر عمل درآمد نہیں کرتا ہے کیونکہ `NaN != NaN` ، جب ہم جانتے ہیں کہ سلائس میں `NaN` نہیں ہوتا ہے تو ہم `partial_cmp` کو اپنی طرح کے فنکشن کے طور پر استعمال کرسکتے ہیں۔
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// جب قابل اطلاق ہوتا ہے تو ، غیر مستحکم چھانٹائی کو ترجیح دی جاتی ہے کیونکہ یہ عام طور پر مستحکم چھانٹنے سے تیز تر ہوتا ہے اور اس سے متعلق معاون میموری مختص نہیں ہوتا ہے۔
    /// [`sort_unstable_by`](slice::sort_unstable_by) دیکھیں۔
    ///
    /// # موجودہ عمل درآمد
    ///
    /// موجودہ الگورتھم [timsort](https://en.wikipedia.org/wiki/Timsort) سے متاثر ہوکر ایک انکولی ، مکرر انضمام ترتیب ہے۔
    /// یہ ان معاملات میں بہت تیزی سے تیار کیا گیا ہے جہاں ٹکڑا تقریباorted ترتیب دیا گیا ہو ، یا دو یا دو سے زیادہ ترتیب والے سلسلوں پر مشتمل ہو جس کے بعد ایک کے بعد ایک دوسرے کے ساتھ اتفاق کیا گیا ہو۔
    ///
    /// نیز ، یہ `self` کے نصف سائز عارضی اسٹوریج کو مختص کرتا ہے ، لیکن مختصر سلائسوں کے بجائے اس میں اس کے بجائے غیر مختص کی جانے والی اضافے کا استعمال کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ریورس چھانٹ رہا ہے
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// کلید نکالنے کے فنکشن کے ساتھ سلائس کو ترتیب دیتا ہے۔
    ///
    /// یہ ترتیب مستحکم ہے (یعنی ، مساوی عنصر کو دوبارہ ترتیب نہیں دیتا ہے) اور *O*(*m*\* * n *\* log(*n*)) بدترین صورت ہے ، جہاں اہم کام *O*(*m*) ہے۔
    ///
    /// مہنگے اہم کاموں کیلئے (جیسے
    /// افعال جو عام جائیداد تک رسائ یا بنیادی کارروائی نہیں ہیں) ، [`sort_by_cached_key`](slice::sort_by_cached_key) ممکنہ طور پر تیز رفتار ہونے کا امکان ہے ، کیونکہ اس میں عنصر کی چابیاں کا مقابلہ نہیں ہوتا ہے۔
    ///
    ///
    /// جب قابل اطلاق ہوتا ہے تو ، غیر مستحکم چھانٹائی کو ترجیح دی جاتی ہے کیونکہ یہ عام طور پر مستحکم چھانٹنے سے تیز تر ہوتا ہے اور اس سے متعلق معاون میموری مختص نہیں ہوتا ہے۔
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) دیکھیں۔
    ///
    /// # موجودہ عمل درآمد
    ///
    /// موجودہ الگورتھم [timsort](https://en.wikipedia.org/wiki/Timsort) سے متاثر ہوکر ایک انکولی ، مکرر انضمام ترتیب ہے۔
    /// یہ ان معاملات میں بہت تیزی سے تیار کیا گیا ہے جہاں ٹکڑا تقریباorted ترتیب دیا گیا ہو ، یا دو یا دو سے زیادہ ترتیب والے سلسلوں پر مشتمل ہو جس کے بعد ایک کے بعد ایک دوسرے کے ساتھ اتفاق کیا گیا ہو۔
    ///
    /// نیز ، یہ `self` کے نصف سائز عارضی اسٹوریج کو مختص کرتا ہے ، لیکن مختصر سلائسوں کے بجائے اس میں اس کے بجائے غیر مختص کی جانے والی اضافے کا استعمال کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// کلید نکالنے کے فنکشن کے ساتھ سلائس کو ترتیب دیتا ہے۔
    ///
    /// چھنٹائی کے دوران ، کلیدی فعل کو فی عنصر میں صرف ایک بار کہا جاتا ہے۔
    ///
    /// یہ ترتیب مستحکم ہے (یعنی مساوی عناصر کو دوبارہ ترتیب نہیں دیتا ہے) اور *O*(*m*\* * n *+** **x00X بدترین معاملہ ہے ، جہاں کلیدی فعل* O *(* m *) ہے .
    ///
    /// آسان کلیدی افعال کے ل ((مثال کے طور پر ، وہ افعال جو پراپرٹی تک رسائ یا بنیادی کاروائی ہیں) ، [`sort_by_key`](slice::sort_by_key) کا تیز رفتار ہونے کا امکان ہے۔
    ///
    /// # موجودہ عمل درآمد
    ///
    /// موجودہ الگورتھم اورسن پیٹرز کے ذریعہ [pattern-defeating quicksort][pdqsort] پر مبنی ہے ، جو بے ترتیب کوئیکسورٹ کے تیز اوسط کیس کو ہیپس پورٹ کے تیز ترین بدترین معاملے سے جوڑتا ہے ، جبکہ کچھ نمونوں کے ساتھ سلائس پر لکیری ٹائم حاصل کرتے ہیں۔
    /// ایجاد کے معاملات سے بچنے کے ل rand یہ کچھ بے ترتیب کاری کا استعمال کرتا ہے ، لیکن ایک مستقل seed کے ساتھ ہمیشہ عصبی رویہ فراہم کرتا ہے۔
    ///
    /// بدترین صورت میں ، الگورتھم ایک `Vec<(K, usize)>` میں سلائس کی لمبائی میں عارضی اسٹوریج مختص کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // مختص کو کم کرنے کے لئے ، ہماری vector کو چھوٹی سے چھوٹی چھوٹی قسم سے ترتیب دینے کے لئے مددگار میکرو۔
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` کے عناصر انفرادیت رکھتے ہیں ، جیسا کہ ان کی ترتیب دی جاتی ہے ، لہذا اصلی ٹکڑے کے سلسلے میں کسی بھی طرح کا استحکام مستحکم ہوگا۔
                // ہم یہاں `sort_unstable` استعمال کرتے ہیں کیونکہ اس میں میموری کی کم رقم مختص کی ضرورت ہے۔
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` کو ایک نئے `Vec` میں کاپی کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // یہاں ، `s` اور `x` کو آزادانہ طور پر تبدیل کیا جاسکتا ہے۔
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` کو ایک نئے `Vec` میں مختص کرنے والے کے ساتھ کاپی کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // یہاں ، `s` اور `x` کو آزادانہ طور پر تبدیل کیا جاسکتا ہے۔
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB ، مزید تفصیلات کے ل this اس فائل میں `hack` ماڈیول دیکھیں۔
        hack::to_vec(self, alloc)
    }

    /// `self` کو کسی کلون یا مختص کے بغیر vector میں تبدیل کرتا ہے۔
    ///
    /// نتیجے میں vector کو box Vec کے ذریعہ دوبارہ باکس میں تبدیل کیا جاسکتا ہے<T>X کا `into_boxed_slice` طریقہ۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` اب اسے استعمال نہیں کیا جاسکتا کیونکہ اسے `x` میں تبدیل کردیا گیا ہے۔
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB ، مزید تفصیلات کے ل this اس فائل میں `hack` ماڈیول دیکھیں۔
        hack::into_vec(self)
    }

    /// ایک ٹکڑا `n` اوقات دہرا کر vector تخلیق کرتا ہے۔
    ///
    /// # Panics
    ///
    /// اگر یہ گنجائش اوور فلو ہوجائے گی تو یہ فنکشن panic کرے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ایک panic اتپرواہ پر:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // اگر `n` صفر سے بڑا ہے تو ، اسے `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` کے طور پر تقسیم کیا جاسکتا ہے۔
        // `2^expn` `n` کے بائیں بازو '1' بٹ کے ذریعہ نمائندگی کرنے والا نمبر ہے ، اور `n` X کا `n` کا باقی حصہ ہے۔
        //
        //

        // `set_len()` تک رسائی حاصل کرنے کے لئے `Vec` کا استعمال۔
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` تکرار `buf`-Expn` اوقات کو دوگنا کرکے کیا جاتا ہے۔
        buf.extend(self);
        {
            let mut m = n >> 1;
            // اگر `m > 0` ہے تو ، بائیں بازو کے '1' تک بٹس باقی ہیں۔
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` کی گنجائش ہے۔
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n، 2 ^ Expn`) تکرار `buf` ہی سے پہلے `rem` تکرار کاپی کرکے کیا جاتا ہے۔
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // یہ `2^expn > rem` کے بعد سے غیر اوور لیپنگ ہے۔
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`)) کے برابر ہے۔
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` کے ایک ٹکڑے کو ایک ہی قدر `Self::Output` میں فلیٹ کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// ہر ایک کے درمیان دیئے گئے جداکار کو رکھ کر ، `T` کے ایک ٹکڑے کو ایک ہی قدر `Self::Output` میں فلیٹ کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// ہر ایک کے درمیان دیئے گئے جداکار کو رکھ کر ، `T` کے ایک ٹکڑے کو ایک ہی قدر `Self::Output` میں فلیٹ کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// اس سلائس کی ایک کاپی پر مشتمل ایک vector واپس کرتا ہے جہاں ہر بائٹ کو اس کے ASCII اوپری کیس کے مساوی پر نقش کیا جاتا ہے۔
    ///
    ///
    /// 'a' سے 'z' تک ASCII حروف 'A' سے 'Z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// جگہ میں قدر کو بڑے کرنے کیلئے ، [`make_ascii_uppercase`] استعمال کریں۔
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// اس سلائس کی ایک کاپی پر مشتمل ایک vector واپس کرتا ہے جہاں ہر بائٹ کو اس کے ASCII لوئر کیس کے مساوی پر نقش کیا جاتا ہے۔
    ///
    ///
    /// 'A' سے 'Z' تک ASCII حروف 'a' سے 'z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// جگہ کو کم کرنے کے ل، ، [`make_ascii_lowercase`] استعمال کریں۔
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// مخصوص قسم کے ڈیٹا پر سلائسس کے ل Z traits میں توسیع
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](ٹکڑا::concat) کے لئے مددگار trait۔
///
/// Note: اس trait میں `Item` قسم کا پیرامیٹر استعمال نہیں کیا گیا ہے ، لیکن اس سے امپلس کو زیادہ عام ہونے دیا جاتا ہے۔
/// اس کے بغیر ، ہمیں یہ خرابی مل جاتی ہے:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// اس کی وجہ یہ ہے کہ ایک سے زیادہ `Borrow<[_]>` امپلس کے ساتھ `V` اقسام موجود ہوسکتے ہیں ، جیسے متعدد `T` اقسام لاگو ہوں گی:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// کنکریٹٹیشن کے بعد نتیجے میں آنے والی قسم
    type Output;

    /// [`[T]: : concat`](ٹکڑا::concat) کا نفاذ
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`](ٹکڑا::شامل ہونے) کے لئے مددگار trait
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// کنکریٹٹیشن کے بعد نتیجے میں آنے والی قسم
    type Output;

    /// [`[T]: : join`](ٹکڑا::شامل) کا نفاذ
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// سلائسین کے لئے معیاری trait لاگو
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ہدف میں ایسی کوئی بھی چیز ڈالیں جس کو ادلھائی نہیں جائے گی
        target.truncate(self.len());

        // target.len <= self.len اوپر چھوٹی چھوٹی وجہ سے ، لہذا یہاں کے سلائسس ہمیشہ ہی اندرونی حدود میں رہتے ہیں۔
        //
        let (init, tail) = self.split_at(target.len());

        // موجود اقدار allocations/resources کو دوبارہ استعمال کریں۔
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` کو پہلے سے ترتیب شدہ ترتیب `v[1..]` میں داخل کرتا ہے تاکہ پورا `v[..]` ترتیب ہوجائے۔
///
/// یہ اندراج کی ترتیب کا لازمی سبروٹائن ہے۔
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // اندراج کو نافذ کرنے کے لئے یہاں تین طریقے ہیں:
            //
            // 1. ملحقہ عناصر کو تبدیل کریں جب تک کہ پہلا اپنی آخری منزل تک نہ پہنچ جائے۔
            //    تاہم ، اس طرح ہم اعداد و شمار کو ضرورت سے زیادہ کاپی کرتے ہیں۔
            //    اگر عناصر بڑے ڈھانچے ہیں (کاپی کرنا مہنگا ہے) ، تو یہ طریقہ سست ہوگا۔
            //
            // 2. جب تک پہلا عنصر کے ل the صحیح جگہ نہ مل جائے تب تک Iterate کریں۔
            // پھر اس کے ل room جگہ بنانے کے ل succeed اس کے بعد آنے والے عناصر کو شفٹ کریں اور آخر کار اسے باقی سوراخ میں رکھیں۔
            // یہ ایک اچھا طریقہ ہے۔
            //
            // 3. پہلے عنصر کو عارضی متغیر میں کاپی کریں۔جب تک کہ اس کے لئے صحیح جگہ نہ مل جائے تب تک Iterate کریں۔
            // جب ہم آگے بڑھتے ہیں تو ، ہر پھٹے ہوئے عنصر سے پہلے والے سلاٹ میں کاپی کریں۔
            // آخر میں ، عارضی متغیر سے ڈیٹا کو باقی سوراخ میں کاپی کریں۔
            // یہ طریقہ بہت اچھا ہے۔
            // بینچ مارکس نے دوسرے طریقہ کی نسبت قدرے بہتر کارکردگی کا مظاہرہ کیا۔
            //
            // تمام طریقوں کو بینچ مارک کیا گیا ، اور تیسرے بہترین نتائج دکھائے۔تو ہم نے اس کا انتخاب کیا۔
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // داخل کرنے کے عمل کی انٹرمیڈیٹ حالت ہمیشہ `hole` کے ذریعہ حاصل کی جاتی ہے ، جو دو مقاصد میں کام کرتا ہے:
            // 1. `is_less` میں panics سے `v` کی سالمیت کی حفاظت کرتا ہے۔
            // 2. آخر میں `v` میں باقی سوراخ بھر دیتا ہے۔
            //
            // Panic حفاظت:
            //
            // اگر اس عمل کے دوران کسی بھی موقع پر `is_less` panics ، `hole` گرا دیا جائے گا اور `tmp` میں سوراخ کو `tmp` سے بھر جائے گا ، اس طرح یہ یقینی بناتا ہے کہ `v` اب بھی ہر اس شے کو رکھتا ہے جس کی ابتدا بالکل ٹھیک ایک بار کی گئی تھی۔
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` چھوڑ دیا جاتا ہے اور اس طرح `v` کو `v` کے باقی سوراخ میں کاپی کرتا ہے۔
        }
    }

    // جب گرا دیا جائے تو ، `src` سے `dest` میں کاپیاں۔
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `buf` کو عارضی اسٹوریج کے بطور `v[..mid]` اور `v[mid..]` کو غیر گھٹانے والی رنز کو ضم کرتا ہے ، اور نتیجہ کو `v[..]` میں اسٹور کرتا ہے۔
///
/// # Safety
///
/// دونوں ٹکڑے لازمی طور پر خالی نہ ہوں اور `mid` لازمی حد میں ہوں۔
/// چھوٹی سلائس کی ایک کاپی رکھنے کے لئے بفر `buf` طویل ہونا چاہئے۔
/// نیز ، `T` صفر سائز کی قسم کا نہیں ہونا چاہئے۔
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // انضمام کا عمل سب سے پہلے `buf` میں چھوٹی چھوٹی کاپی کرتا ہے۔
    // پھر یہ نئے کاپی شدہ رن اور طویل دوڑنے والے فارورڈس (یا پیچھے کی طرف) کا سراغ لگاتا ہے ، اپنے اگلے غیر پیشگی عناصر کا موازنہ کرتا ہے اور ایک سے کم (یا اس سے زیادہ) کاپی `v` میں کرتا ہے۔
    //
    // جیسے ہی مختصر رن مکمل طور پر کھا جاتا ہے ، عمل مکمل ہوجاتا ہے۔اگر لمبے عرصے سے پہلے کھا جاتا ہے تو ، پھر ہمیں `v` میں باقی سوراخ میں جو چھوٹا سا بچا ہے اسے کاپی کرنا ہوگا۔
    //
    // عمل کی انٹرمیڈیٹ حالت ہمیشہ `hole` کے ذریعہ حاصل کی جاتی ہے ، جو دو مقاصد میں کام کرتا ہے:
    // 1. `is_less` میں panics سے `v` کی سالمیت کی حفاظت کرتا ہے۔
    // 2. اگر طویل عرصے سے پہلے استعمال ہوجائے تو `v` میں بقیہ سوراخ پُر کریں۔
    //
    // Panic حفاظت:
    //
    // اگر اس عمل کے دوران کسی بھی موقع پر `is_less` panics ، `hole` گر جائے گا اور `buf` میں غیر متوقع رینج کے ساتھ X0X میں سوراخ کو بھر دے گا ، اس طرح یہ یقینی بناتا ہے کہ `v` اب بھی ہر اس شے کو رکھتا ہے جس کو ابتدا میں بالکل ایک بار رکھا تھا۔
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // بائیں بازو کم ہے۔
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // ابتدا میں ، یہ اشارے اپنی صفوں کی شروعات کی طرف اشارہ کرتے ہیں۔
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // کم پہلو استعمال کریں۔
            // اگر برابر ہے تو ، استحکام برقرار رکھنے کے لئے بائیں رن کو ترجیح دیں۔
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // دائیں رن کم ہیں۔
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // ابتدائی طور پر ، یہ اشارے اپنی صفوں کے آخر سے گذرتے ہیں۔
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // زیادہ سے زیادہ پہلو استعمال کریں۔
            // اگر برابر ہے تو ، استحکام برقرار رکھنے کے لئے صحیح رن کو ترجیح دیں۔
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // آخر میں ، `hole` ڈراپ ہوجاتا ہے۔
    // اگر چھوٹا رن مکمل طور پر استعمال نہیں کیا گیا تھا ، تو اس کی باقی چیزیں اب `v` میں سوراخ میں کاپی ہوجائیں گی۔

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // جب گرا دیا جائے تو ، `start..end` کی حد کو `dest..` میں کاپی کریں۔
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` صفر سائز کی قسم کی نہیں ہے ، لہذا اس کے سائز کے حساب سے تقسیم کرنا ٹھیک ہے۔
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// اس انضمام کی ترتیب سے ٹمسورٹ کے کچھ (لیکن سبھی نہیں) آئیڈیوں سے قرض لیا گیا ہے ، جس کی تفصیل [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) میں بیان کی گئی ہے۔
///
///
/// الگورتھم سختی سے اترتے ہوئے اور نزول ہوتے ہوئے آنے والے حصوں کی نشاندہی کرتا ہے ، جنہیں قدرتی رنز کہا جاتا ہے۔ابھی تک منتقلی رنز کا ایک ڈھیر ابھی باقی ہے۔
/// ہر نئے پائے جانے والے رن کو اسٹیک پر دھکیل دیا جاتا ہے ، اور پھر ملحقہ رنز کے کچھ جوڑے مل جاتے ہیں جب تک کہ یہ دونوں حملہ آور مطمئن نہ ہوں:
///
/// 1. `1..runs.len()` میں ہر `i` کیلئے: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` میں ہر `i` کیلئے: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// حملہ آور یقینی بناتے ہیں کہ کل چلانے کا وقت *O*(*n*\*log(* n*)) بدترین معاملہ) ہے۔
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // لمبائی تک کے ٹکڑوں کو اندراج کی ترتیب سے ترتیب دیا جاتا ہے۔
    const MAX_INSERTION: usize = 20;
    // کم سے کم اس کے بہت سے عناصر کو پھیلا دینے کے ل in انسرٹ سواری کا استعمال کرتے ہوئے بہت مختصر رنز بڑھا دیئے جاتے ہیں۔
    const MIN_RUN: usize = 10;

    // صفر سائز کی اقسام پر چھانٹنا کا کوئی معنی خیز رویہ نہیں ہے۔
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // مختص سے بچنے کے ل Short مختصر صفوں کو داخل کی ترتیب کے ذریعہ جگہ جگہ ترتیب دیا جاتا ہے۔
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // سکریچ میموری کے بطور استعمال کرنے کیلئے بفر مختص کریں۔ہم لمبائی 0 رکھتے ہیں لہذا ہم اس میں `v` کے مندرجات کی اتلی کاپیاں اپنے پاس رکھ سکتے ہیں اگر کاپیوں پر چلنے والے ڈٹروں کو خطرے میں ڈالے بغیر اگر `is_less` panics ہے۔
    //
    // جب دو طرح کے رن بنائے جاتے ہیں تو ، اس بفر کے پاس مختصر رن کی ایک کاپی ہوتی ہے ، جس کی لمبائی ہمیشہ زیادہ سے زیادہ `len / 2` میں ہوگی۔
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` میں قدرتی رنز کی نشاندہی کرنے کے ل we ، ہم اسے پیچھے کی طرف عبور کرتے ہیں۔
    // یہ ایک عجیب و غریب فیصلہ کی طرح لگتا ہے ، لیکن اس حقیقت پر غور کریں کہ زیادہ تر انضمام ہونے سے اکثر مخالف سمت میں جانا پڑتا ہے (forwards)۔
    // بینچ مارک کے مطابق ، فارورڈز کو ضم کرنا پیچھے کی طرف ضم ہونے سے قدرے تیز ہے۔
    // نتیجہ اخذ کرنے کے لئے ، پیچھے کی طرف ٹراؤن کرکے رنز کی نشاندہی کرنے سے کارکردگی بہتر ہوتی ہے۔
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // اگلا قدرتی رن ڈھونڈو ، اور اگر اس میں سختی سے اتر رہا ہو تو اسے معکوس کریں۔
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // اگر یہ بہت مختصر ہے تو کچھ اور عناصر کو رن میں داخل کریں۔
        // اضافے کی ترتیب مختصر ترتیب پر انضمام کی طرح تیز ہے ، لہذا اس سے کارکردگی میں نمایاں اضافہ ہوتا ہے۔
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // اس رن کو اسٹیک پر دبائیں۔
        runs.push(Run { start, len: end - start });
        end = start;

        // حملہ آوروں کو مطمئن کرنے کے لئے ملحقہ رنز کے کچھ جوڑے ضم کریں۔
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // آخر میں ، بالکل ایک رن اسٹیک میں ہی رہنا چاہئے۔
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // رنز کے ذخیرے کی جانچ پڑتال کرتی ہے اور انضمام کے لئے رنز کے اگلے جوڑے کی نشاندہی کرتی ہے۔
    // مزید خاص طور پر ، اگر `Some(r)` لوٹ گیا ہے ، اس کا مطلب ہے کہ اگلے میں `runs[r]` اور `runs[r + 1]` کو ضم کیا جانا چاہئے۔
    // اگر اس کے بجائے الگورتھم کو نیا رن بنانا جاری رکھنا چاہئے تو ، `None` لوٹ آئے گا۔
    //
    // ٹمسورٹ اپنی چھوٹی چھوٹی کاروائیوں کے لئے بدنام ہے ، جیسا کہ یہاں بیان کیا گیا ہے:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // کہانی کا خلاصہ یہ ہے کہ: ہمیں حملہ آوروں کو لاٹھی چاروں رنز پر لگانا چاہئے۔
    // انھیں صرف ٹاپ تھری پر نافذ کرنا اس بات کا یقین کرنے کے لئے کافی نہیں ہے کہ حملہ آور اب بھی اسٹیک میں *تمام* رنز کو روک سکتے ہیں۔
    //
    // یہ فنکشن چاروں رنز کے ل inv صحیح طریقے سے حملہ آوروں کی جانچ کرتا ہے۔
    // مزید برآں ، اگر ٹاپ رن انڈیکس 0 سے شروع ہوجاتا ہے تو ، اس ترتیب کو مکمل کرنے کے ل it ، یہ ہمیشہ انضمام کا مطالبہ کرے گا جب تک کہ اسٹیک مکمل طور پر ختم نہیں ہوجاتا۔
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}