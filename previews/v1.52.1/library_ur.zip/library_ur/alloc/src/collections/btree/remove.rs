use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// درخت سے کلیدی قدر کی جوڑی کو ہٹا دیتا ہے ، اور اس جوڑی کو واپس کرتا ہے ، نیز اس پچھلی جوڑی کے مطابق edge پتی بھی۔
    /// یہ ممکن ہے کہ یہ ایک جڑ نوڈ خالی کر دے جو اندرونی ہو ، جسے کال کرنے والے نے درخت کے نقشے سے پاپ ہونا چاہئے۔
    /// کال کرنے والے کو بھی نقشہ کی لمبائی کو کم کرنا چاہئے۔
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // ہمیں عارضی طور پر بچوں کی قسم کو فراموش کرنا ہوگا ، کیوں کہ پتے کے فوری والدین کے لئے کوئی الگ نوڈ قسم نہیں ہے۔
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // حفاظت: `new_pos` وہ پتی ہے جس کی ابتدا ہم نے کی ہے یا کوئی بہن بھائی۔
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // صرف اس صورت میں جب ہم ضم ہوجائیں ، والدین (اگر کوئی ہے) سکڑ گیا ہے ، لیکن مندرجہ ذیل اقدام کو چھوڑنا بصورت دیگر بینچ مارک میں معاوضہ نہیں دیتا ہے۔
            //
            // محفوظ کریں: ہم جہاں `pos` موجود ہیں وہاں پتی کو تباہ یا دوبارہ ترتیب نہیں دیں گے
            // اس کے والدین کو بار بار سنبھالنے سے؛بدترین طور پر ہم دادا والدین کے ذریعہ والدین کو تباہ یا دوبارہ ترتیب دیں گے ، اس طرح پتی کے اندر والدین سے لنک تبدیل کردیں گے۔
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // اس کے پتے سے ملحقہ کے وی کو ہٹا دیں اور پھر اسے عنصر کی جگہ واپس رکھیں جس سے ہمیں کہا گیا تھا کہ اسے ہٹائیں۔
        //
        // `choose_parent_kv` میں درج وجوہات کی بناء پر ، بائیں ملحقہ کے وی کو ترجیح دیں۔
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // ہوسکتا ہے کہ اندرونی نوڈ چوری ہوچکا ہو یا اس سے مل گیا ہو۔
        // اصل KV ختم ہوا کہاں معلوم کرنے کے لئے دائیں طرف واپس جائیں۔
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}