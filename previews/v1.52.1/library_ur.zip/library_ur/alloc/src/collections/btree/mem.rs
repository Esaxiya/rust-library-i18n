use core::intrinsics;
use core::mem;
use core::ptr;

/// یہ متعلقہ فنکشن کو کال کرکے `v` انفرادی حوالہ کے پیچھے والی قیمت کی جگہ لے لیتا ہے۔
///
///
/// اگر `change` بندش میں panic ہوتا ہے تو ، پورا عمل ختم کردیا جائے گا۔
#[allow(dead_code)] // مثال کے طور پر اور future استعمال کے ل keep رکھیں
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// اس سے متعلقہ فنکشن کو کال کرکے `v` انفرادی حوالہ کے پیچھے والی قیمت کی جگہ لیتی ہے ، اور راستے میں ملنے والا نتیجہ واپس آجاتا ہے۔
///
///
/// اگر `change` بندش میں panic ہوتا ہے تو ، پورا عمل ختم کردیا جائے گا۔
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}