use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// کسی بہن کے ساتھ ضم یا چوری کرکے ممکنہ طور پر انڈر فل فل نوڈ اسٹاک کریں۔
    /// اگر کامیاب لیکن والدین نوڈ کو سکڑانے کی قیمت پر ، تو پیرنٹ نوڈ سکڑ جاتا ہے۔
    /// اگر نوڈ خالی جڑ ہے تو ایک `Err` لوٹاتا ہے۔
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ممکنہ طور پر انڈر فل فل نوڈس کو اسٹاک کریں ، اور اگر اس سے اس کے والدین نوڈ سکڑ جاتے ہیں تو ، والدین کو بار بار ذخیرہ کرتے ہیں۔
    /// اگر اس نے درخت کو طے کیا ہے تو X01 ایکس لوٹاتا ہے ، `false` اگر یہ نہیں ہوسکتا ہے کیونکہ جڑ نوڈ خالی ہو گیا ہے۔
    ///
    /// یہ طریقہ توقع نہیں کرتا ہے کہ اگر خالی آباؤ اجداد کا سامنا ہوتا ہے تو ان کے باپ دادا کو پہلے ہی داخلے اور panics پر پہلے ہی زیرکفالت ہوجائے گا۔
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// اوپری حصے پر خالی سطح کو ہٹاتا ہے ، لیکن اگر پورا درخت خالی ہو تو خالی پتی رکھتا ہے۔
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// درخت کی دائیں سرحد پر کسی بھی زیر زمین نوڈس کو اسٹاک اپ یا انضمام کریں۔
    /// دوسرے نوڈس ، جو جڑ نہیں ہیں اور نہ ہی دائیں طرف edge ہیں ، ان میں پہلے ہی کم از کم MIN_LEN عناصر ہونے چاہئیں۔
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` کا ہم آہنگی کلون۔
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// درخت کی دائیں سرحد پر کسی بھی زیر زمین نوڈس کو اسٹاک کریں۔
    /// دوسرے نوڈس ، جو کہ جڑ نہیں ہیں اور نہ ہی بالکل edge ہیں ، ان کو MIN_LEN عناصر چوری کرنے کے ل. تیار رہنا چاہئے۔
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // چیک کریں کہ کیا دائیں طرف سب سے زیادہ بچہ زیرکفالت ہے۔
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // ہمیں چوری کرنے کی ضرورت ہے۔
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // مزید نیچے جاؤ۔
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// بائیں بچے کو ذخیرہ کرتے ہوئے ، یہ فرض کرتے ہوئے کہ دائیں بچہ زیریں نہیں ہے ، اور ایک اضافی عنصر کی فراہمی کرتا ہے تاکہ اپنے بچوں کو انڈرفول بنائے بغیر بدلے میں ضم کر دے۔
    ///
    /// بائیں بچے کو لوٹاتا ہے۔
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` اگر اگلی سطح پر انضمام ہوتا ہے تو ایڈجسٹمنٹ سے بچنے کے ل.۔
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// یہ خیال کرتے ہوئے کہ دائیں بچے کو ذخیرہ کرلیا گیا ہے ، یہ خیال کرتے ہوئے کہ بائیں بچے کو زیر اثر نہیں رکھا گیا ہے ، اور ایک اضافی عنصر فراہم کیا گیا ہے تاکہ وہ اپنے بچوں کو بغیر کسی ضبط کے انضمام کی اجازت دے۔
    ///
    /// جہاں بھی صحیح بچہ ختم ہوا واپس آجاتا ہے۔
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` اگر اگلی سطح پر انضمام ہوتا ہے تو ایڈجسٹمنٹ سے بچنے کے ل.۔
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}