// یہ ایک مثالی عمل کے نفاذ کی ایک کوشش ہے
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// چونکہ Rust میں درحقیقت منحصر اقسام اور کثیر الثقاتی تکرار نہیں ہوتی ہے ، لہذا ہم بہت سی بے عیبوں کے ساتھ کام کرتے ہیں۔
//

// اس ماڈیول کا ایک بڑا ہدف یہ ہے کہ درخت کو عام (اگر عجیب و غریب شکل کی شکل میں) کنٹینر سمجھا جائے اور بی بی کے زیادہ تر حملہ آوروں سے نمٹنے سے گریز کریں۔
//
// اس طرح ، اس ماڈیول کی پرواہ نہیں کرتی ہے کہ آیا اندراجات ترتیب دیئے گئے ہیں ، کون سے نوڈس زیر انتظام ہوسکتے ہیں ، یا یہاں تک کہ زیر اثر کا کیا مطلب ہے۔تاہم ، ہم کچھ حملہ آوروں پر بھروسہ کرتے ہیں۔
//
// - درختوں میں یکساں depth/height ہونا چاہئے۔اس کا مطلب یہ ہے کہ دیئے گئے نوڈ سے پتی تک ہر راستے کی لمبائی بالکل اتنی ہی ہے۔
// - لمبائی `n` کے نوڈ میں `n` کیز ، `n` ویلیوز اور `n + 1` ایجز ہیں۔
//   اس کا مطلب یہ ہے کہ یہاں تک کہ خالی نوڈ میں کم از کم ایک edge ہے۔
//   پتی کے نوڈ کے ل X ، "having an edge" کا صرف مطلب ہے کہ ہم نوڈ میں کسی پوزیشن کی شناخت کرسکتے ہیں ، کیونکہ پتی کے کنارے خالی ہیں اور اعداد و شمار کی نمائندگی کی ضرورت نہیں ہے۔
// اندرونی نوڈ میں ، ایک edge دونوں ایک جگہ کی نشاندہی کرتا ہے اور اس میں بچے کے نوڈ پر ایک پوائنٹر شامل ہوتا ہے۔
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// پتی کے نوڈس کی بنیادی نمائندگی اور داخلی نوڈس کی نمائندگی کا حصہ۔
struct LeafNode<K, V> {
    /// ہم `K` اور `V` میں ہمسر بننا چاہتے ہیں۔
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// پیرنٹ نوڈ کی `edges` سرنی میں اس نوڈ کا اشاریہ۔
    /// `*node.parent.edges[node.parent_idx]` `node` جیسا ہی ہونا چاہئے۔
    /// اس وقت صرف اس بات کی ضمانت دی جاتی ہے کہ جب `parent` غیر مستحکم ہو۔
    parent_idx: MaybeUninit<u16>,

    /// اس نوڈ اسٹورز کی چابی اور قدر کی تعداد۔
    len: u16,

    /// اشارے نوڈ کا اصل ڈیٹا اسٹور کرتے ہیں۔
    /// ہر صف کے صرف پہلے `len` عناصر کی ابتدا اور درست ہوتی ہے۔
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// جگہ پر ایک نیا `LeafNode` شروع کرتا ہے۔
    unsafe fn init(this: *mut Self) {
        // عام پالیسی کے طور پر ، اگر ہم کھیتوں کو غیر اعلانیہ طور پر چھوڑ دیتے ہیں تو وہ ہوسکتے ہیں ، کیوں کہ والگرینڈ میں ٹریک کرنے میں یہ قدرے تیز اور آسان بھی ہونا چاہئے۔
        //
        unsafe {
            // والدین_ڈیکس ، چابیاں ، اور والز سب میون انیٹ ہیں
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// ایک نیا باکسڈ `LeafNode` بناتا ہے۔
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// داخلی نوڈس کی بنیادی نمائندگی۔جیسا کہ N لیف نڈ، کی طرح ہے ، ان کو it BoxedNode behind کے پیچھے چھپا دینا چاہئے تاکہ بلاضرورت کلیدوں اور اقدار کو گرنے سے بچایا جاسکے۔
/// کسی `InternalNode` کی طرف کوئی بھی پوائنٹر براہ راست نوڈ کے بنیادی `LeafNode` حصے میں ایک پوائنٹر پر کاسٹ کیا جاسکتا ہے ، تاکہ کوڈ کو پتی اور اندرونی نوڈس پر عمومی طور پر کام کرنے کی اجازت دی جائے ، یہاں تک کہ یہ بھی چیک کیے بغیر کہ ان دونوں میں سے کون سا ایک طرف اشارہ کررہا ہے۔
///
/// یہ پراپرٹی `repr(C)` کے استعمال سے قابل عمل ہے۔
///
#[repr(C)]
// gdb_providers.py تشخیص کیلئے اس قسم کا نام استعمال کرتا ہے۔
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// اس نوڈ کے بچوں کی طرف اشارہ۔
    /// `len + 1` ان میں سے ابتداء اور جائز سمجھا جاتا ہے ، سوائے اس کے کہ قریب کے آخر میں ، جبکہ درخت ادھار `Dying` کے ذریعہ تھامے ہوئے ہوں ، ان میں سے کچھ اشارے کھٹک رہے ہیں۔
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// ایک نیا باکسڈ `InternalNode` بناتا ہے۔
    ///
    /// # Safety
    /// اندرونی نوڈس کا ایک جارح یہ ہے کہ ان کے پاس کم از کم ایک ابتدائی اور درست edge ہے۔
    /// یہ فنکشن اس طرح کا edge مرتب نہیں کرتا ہے۔
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // ہمیں صرف اعداد و شمار کو شروع کرنے کی ضرورت ہے۔کناروں شایدUninit ہیں.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ایک نوڈ کا انتظام شدہ ، نون الکول پوائنٹر۔یہ یا تو `LeafNode<K, V>` کا ملکیت کا پوائنٹر ہے یا `InternalNode<K, V>` کا ملکیت کا پوائنٹر ہے۔
///
/// تاہم ، `BoxedNode` میں اس بارے میں کوئی معلومات شامل نہیں ہے کہ اس میں دو قسم کے نوڈس میں سے کون سے ہے جو حقیقت میں ہے ، اور جزوی طور پر اس معلومات کی کمی کی وجہ سے ، یہ ایک الگ قسم نہیں ہے اور اس میں کوئی ڈسٹریکٹر نہیں ہے۔
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ملکیت والے درخت کا جڑ نوڈ۔
///
/// نوٹ کریں کہ اس میں کوئی ڈسیکٹر نہیں ہے ، اور اسے دستی طور پر صاف کرنا چاہئے۔
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ایک نیا ملکیت والا درخت لوٹاتا ہے ، اس کے اپنے جڑ نوڈ کے ساتھ جو ابتدا میں خالی ہے۔
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` صفر نہیں ہونا چاہئے۔
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// باہمی طور پر ملکیت والے جڑ نوڈ پر قرض لیتا ہے۔
    /// `reborrow_mut` کے برعکس ، یہ محفوظ ہے کیونکہ واپسی کی قیمت کو جڑ کو ختم کرنے کے لئے استعمال نہیں کیا جاسکتا ہے ، اور درخت سے متعلق دیگر حوالہ جات نہیں ہوسکتے ہیں۔
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// تھوڑا سا باہمی طور پر ملکیت والے جڑ نوڈ پر قرض لیتا ہے۔
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ناقابل تلافی طور پر کسی ایسے حوالہ پر منتقلی جو گزرنے کی اجازت دیتا ہے اور تباہ کن طریقے پیش کرتا ہے اور کچھ اور۔
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ایک ہی edge کے ساتھ ایک نیا داخلی نوڈ شامل کرتا ہے جس نے پچھلے جڑ نوڈ کی طرف اشارہ کیا ، اس نئے نوڈ کو جڑ نوڈ بنائیں ، اور اسے لوٹائیں۔
    /// اس سے اونچائی میں 1 اضافہ ہوتا ہے اور یہ `pop_internal_level` کے برعکس ہے۔
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, سوائے اس کے کہ ہم صرف یہ بھول گئے ہیں کہ ہم اب اندرونی ہیں:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// نئے جڑ نوڈ کے بطور اپنے پہلے بچے کا استعمال کرتے ہوئے ، اندرونی جڑ نوڈ کو ہٹا دیتا ہے۔
    /// چونکہ اس کا مقصد صرف اس وقت پکارنا ہے جب روٹ نوڈ میں صرف ایک بچہ ہوتا ہے ، کسی بھی چابی ، اقدار اور دوسرے بچوں پر صفائی نہیں کی جاتی ہے۔
    ///
    /// اس سے اونچائی 1 سے کم ہوجاتی ہے اور `push_internal_level` کے برعکس ہے۔
    ///
    /// `Root` آبجیکٹ تک خصوصی رسائی کی ضرورت ہے لیکن روٹ نوڈ تک نہیں۔
    /// اس سے دوسرے ہینڈلز یا جڑوں کے حوالہ جات کو باطل نہیں کیا جائے گا۔
    ///
    /// Panics اگر داخلی سطح نہیں ہے ، یعنی ، اگر جڑ نوڈ ایک پتی ہے۔
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // حفاظت: ہم نے داخلی ہونے پر زور دیا۔
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // محفوظ: ہم نے خصوصی طور پر `self` قرض لیا اور اس کے قرض لینے کی نوعیت خصوصی ہے۔
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // محفوظ: پہلا edge ہمیشہ شروع کیا جاتا ہے۔
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` `K` اور `V` میں ہمیشہ ہمسایہ ہوتا ہے ، یہاں تک کہ جب `BorrowType` `Mut` ہو۔
// یہ تکنیکی طور پر غلط ہے ، لیکن `NodeRef` کے داخلی استعمال کی وجہ سے کسی بھی طرح کے کسی نتیجے میں نہیں نکل سکتا کیونکہ ہم `K` اور `V` سے زیادہ عام رہتے ہیں۔
//
// تاہم ، جب بھی عوامی قسم نے `NodeRef` لپیٹ لیا ، اس بات کو یقینی بنائیں کہ اس میں صحیح تغیر ہے۔
//
/// نوڈ کا حوالہ
///
/// اس قسم کے متعدد پیرامیٹرز ہیں جو کنٹرول کرتے ہیں کہ یہ کس طرح کام کرتا ہے:
/// - `BorrowType`: ایک ڈمی قسم جو قرض کی قسم بیان کرتی ہے اور زندگی بھر چلتی ہے۔
///    - جب یہ `Immut<'a>` ہے تو ، `NodeRef` `&'a Node` کی طرح کام کرتا ہے۔
///    - جب یہ `ValMut<'a>` ہے تو ، `NodeRef` چابیاں اور درختوں کے ڈھانچے کے سلسلے میں `&'a Node` کی طرح کام کرتا ہے ، بلکہ درخت کے بہت سے اقدار کے بہت سے تغیر پذیر حوالوں کو ایک ساتھ رہنے کی اجازت دیتا ہے۔
///    - جب یہ `Mut<'a>` ہے تو ، `NodeRef` تقریبا `&'a mut Node` کی طرح کام کرتا ہے ، حالانکہ داخل کرنے کے طریقے آپس میں بدل پائے جانے والے پوائنٹر کی قیمت کو ایک ساتھ رہ سکتے ہیں۔
///    - جب یہ `Owned` ہے تو ، `NodeRef` تقریبا `Box<Node>` کی طرح کام کرتا ہے ، لیکن اس میں ڈسٹریکٹر نہیں ہے ، اور اسے دستی طور پر صاف کرنا چاہئے۔
///    - جب یہ `Dying` ہے ، تو `NodeRef` ابھی بھی `Box<Node>` کی طرح کام کرتا ہے ، لیکن اس کے ذریعہ درخت کو تھوڑا سا ختم کرنے کے طریقے ہیں ، اور عام طریقے ، جب کہ کال کرنا غیر محفوظ نہیں ہے ، اگر Ub کو غلط طور پر بلایا گیا تو وہ درخواست کرسکتی ہے۔
///
///   چونکہ کوئی بھی `BorrowType` درخت کے ذریعے گھومنے پھرنے کی اجازت دیتا ہے ، `BorrowType` مؤثر طریقے سے پورے درخت پر لاگو ہوتا ہے ، نہ کہ صرف نوڈ پر۔
/// - `K` اور `V`: یہ نوڈس میں محفوظ کی جانے والی چابیاں اور اقدار کی اقسام ہیں۔
/// - `Type`: یہ `Leaf` ، `Internal` ، یا `LeafOrInternal` ہوسکتا ہے۔
/// جب یہ `Leaf` ہے تو ، `NodeRef` کسی پتی کے نوڈ کی طرف اشارہ کرتا ہے ، جب یہ `Internal` ہوتا ہے تو `NodeRef` اندرونی نوڈ کی طرف اشارہ کرتا ہے ، اور جب یہ `LeafOrInternal` ہوتا ہے تو `NodeRef` کسی بھی طرح کے نوڈ کی طرف اشارہ کرسکتا ہے۔
///   `Type` جب `NodeRef` سے باہر استعمال ہوتا ہے تو اسے `NodeType` کا نام دیا جاتا ہے۔
///
/// جامد قسم کی حفاظت کا استحصال کرنے کے ل X ، `BorrowType` اور `BorrowType` دونوں ہی محدود کرتے ہیں کہ ہم کن طریقوں کو نافذ کرتے ہیں۔اس طرح کی پابندیاں جس طرح سے ہم استعمال کرسکتے ہیں ان میں کچھ حدود ہیں۔
/// - ہر قسم کے پیرامیٹر کے ل we ، ہم صرف کسی طریقہ کی وضاحت عام طور پر یا کسی خاص قسم کے لئے کر سکتے ہیں۔
/// مثال کے طور پر ، ہم `into_kv` جیسے طریقہ کار کی وضاحت ہر `BorrowType` کے لئے نہیں کرسکتے ہیں ، یا ایک بار زندگی میں چلنے والی تمام اقسام کے لئے ، کیوں کہ ہم چاہتے ہیں کہ یہ `&'a` حوالہ جات کو لوٹائے۔
///   لہذا ، ہم اسے صرف کم سے کم طاقتور قسم `Immut<'a>` کے لئے متعین کرتے ہیں۔
/// - ہم `Mut<'a>` سے `Immut<'a>` کہنے تک کوئی زبردستی جبر نہیں کرسکتے ہیں۔
///   لہذا ، `into_kv` جیسے طریقہ تک پہنچنے کے ل we ہمیں واضح طور پر زیادہ طاقتور `NodeRef` پر `reborrow` پر کال کرنا پڑے گی۔
///
/// `NodeRef` پر موجود تمام طریقے جو کسی قسم کا حوالہ واپس کرتے ہیں ، یا تو:
/// - `self` قدر کے حساب سے لیں ، اور `BorrowType` کے ذریعہ کی جانے والی زندگی بھر واپس کریں۔
///   بعض اوقات ، اس طرح کا طریقہ کار کرنے کے ل we ، ہمیں `reborrow_mut` پر کال کرنا ضروری ہے۔
/// - `self` حوالہ کے ذریعہ لیں ، اور `BorrowType` X کے ذریعہ کی جانے والی زندگی بھر کے بجائے ، اس حوالہ کی زندگی کو واپس کردیں۔
/// اس طرح ، قرض کا چیکر اس بات کی ضمانت دیتا ہے کہ جب تک لوٹا ہوا حوالہ استعمال کیا جاتا ہو تب تک `NodeRef` قرض لیا جاتا ہے۔
///   داخل کرنے میں مدد دینے والے طریقے اس اصول کو موڑ کر کچے پوائنٹر کو واپس کرتے ہیں ، یعنی بغیر کسی تاحیات کے حوالہ۔
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// جس سطح کی نوڈ اور پتیوں کی سطح الگ ہیں ، نوڈ کا ایک مستقل جو `Type` کے ذریعہ مکمل طور پر بیان نہیں کیا جاسکتا ہے ، اور یہ کہ نوڈ خود ذخیرہ نہیں کرتا ہے۔
    /// ہمیں صرف جڑ نوڈ کی اونچائی کو ذخیرہ کرنے کی ضرورت ہے ، اور اس سے ہر دوسرے نوڈ کی اونچائی حاصل کرنے کی ضرورت ہے۔
    /// `Type` `Leaf` ہے تو X صفر اور `Type` `Internal` ہے تو غیر صفر ہونا ضروری ہے۔
    ///
    ///
    height: usize,
    /// پتی یا اندرونی نوڈ کا اشارہ
    /// `InternalNode` کی تعریف یقینی بناتی ہے کہ اشارہ کسی بھی طرح درست ہے۔
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ایک نوڈ حوالہ کھولیں جو `NodeRef::parent` کے طور پر پیک کیا گیا تھا۔
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// اندرونی نوڈ کا ڈیٹا بے نقاب
    ///
    /// اس نوڈ کے دیگر حوالوں کو باطل کرنے سے بچنے کے لئے ایک کچی پی ٹی آر واپس کرتا ہے۔
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // محفوظ: جامد نوڈ کی قسم `Internal` ہے۔
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// اندرونی نوڈ کے ڈیٹا تک خصوصی رسائی حاصل کرتا ہے۔
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// نوڈ کی لمبائی ڈھونڈتا ہے۔یہ چابیاں یا قدروں کی تعداد ہے۔
    /// کناروں کی تعداد `len() + 1` ہے۔
    /// نوٹ کریں کہ ، محفوظ ہونے کے باوجود ، اس فنکشن کو کال کرنے سے غیر موزوں حوالوں کا باطل اثر پڑ سکتا ہے جو غیر محفوظ کوڈ نے تخلیق کیے ہیں۔
    ///
    pub fn len(&self) -> usize {
        // اہم طور پر ، ہم صرف یہاں `len` فیلڈ تک رسائی حاصل کرتے ہیں۔
        // اگر بورن ٹائپ marker::ValMut ہے تو ، ان اقدار کے بارے میں بقایا تغیر پذیر حوالہ ہوسکتا ہے جن کو ہمیں مسترد نہیں کرنا چاہئے۔
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// نوڈ اور پتے الگ ہونے کی سطح کی تعداد لوٹاتے ہیں۔
    /// زیرو اونچائی کا مطلب نوڈ خود ایک پتی ہے۔
    /// اگر آپ جڑوں کے ساتھ ساتھ درختوں کی تصویر کھینچتے ہیں تو ، نمبر بتاتا ہے کہ نوڈ کون سا بلندی پر ظاہر ہوتا ہے۔
    /// اگر آپ سب سے اوپر پتے والے درختوں کی تصویر لگاتے ہیں تو ، تعداد یہ کہتی ہے کہ درخت نوڈ کے اوپر کتنا اونچا ہے۔
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// عارضی طور پر اسی نوڈ کا دوسرا ، غیر منقولہ حوالہ لے جاتا ہے۔
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// کسی بھی پتی یا داخلی نوڈ کے پتے کے حص Expے کو بے نقاب کرتا ہے۔
    ///
    /// اس نوڈ کے دیگر حوالوں کو باطل کرنے سے بچنے کے لئے ایک کچی پی ٹی آر واپس کرتا ہے۔
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // نوڈ کم از کم لیف نڈ حصے کے لئے درست ہونا چاہئے۔
        // یہ نوڈریف قسم میں کوئی حوالہ نہیں ہے کیونکہ ہم نہیں جانتے کہ یہ انوکھا ہونا چاہئے یا مشترک ہونا چاہئے۔
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// موجودہ نوڈ کے والدین کو تلاش کرتا ہے۔
    /// اگر موجودہ نوڈ کے اصل میں والدین ہوں تو `Ok(handle)` لوٹاتا ہے ، جہاں موجودہ نوڈ کی طرف اشارہ کرنے والے والدین کے edge کی طرف `handle` اشارہ کرتا ہے۔
    ///
    /// اگر موجودہ نوڈ کا کوئی والدین نہیں ہے تو ، `Err(self)` واپس کرے گا ، اصل `NodeRef` واپس کردے گا۔
    ///
    /// طریقہ کار کا نام آپ کے اوپر جڑوں کے نوٹوں کے ساتھ درختوں کی تصویر لینے کا فرض کرتا ہے۔
    ///
    /// `edge.descend().ascend().unwrap()` اور `node.ascend().unwrap().descend()` دونوں کو ، کامیابی پر ، کچھ نہیں کرنا چاہئے۔
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ہمیں نوڈس کے لئے خام پوائنٹر استعمال کرنے کی ضرورت ہے کیونکہ ، اگر بورن ٹائپ marker::ValMut ہے تو ، ان اقدار کے بارے میں بقایا تغیر پذیر حوالہ مل سکتا ہے جنہیں ہمیں مسترد نہیں کرنا چاہئے۔
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// نوٹ کریں کہ `self` بے اثر ہونا چاہئے۔
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// نوٹ کریں کہ `self` بے اثر ہونا چاہئے۔
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// کسی بھی درخت میں کسی بھی پتی یا داخلی نوڈ کے پتے کے حص Expے کو بے نقاب کرتا ہے۔
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // سیکیورٹی: اس درخت میں کوئی تبادلہ خیال نہیں ہوسکتا جو `Immut` کے طور پر لیا گیا ہے۔
        unsafe { &*ptr }
    }

    /// نوڈ میں ذخیرہ کردہ چابیاں میں ایک نظارہ لیتے ہیں۔
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` کی طرح ، نوڈ کے والدین نوڈ کا حوالہ ملتا ہے ، لیکن اس عمل میں موجودہ نوڈ کو بھی خارج کردیتا ہے۔
    /// یہ غیر محفوظ ہے کیونکہ حالیہ نوڈ کی کمی کے باوجود بھی قابل رسا ہوگا۔
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// غیر محفوظ طور پر جامد معلومات کے مرتب کرنے پر زور دیتا ہے کہ یہ نوڈ ایک `Leaf` ہے۔
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// غیر محفوظ طور پر جامد معلومات کے مرتب کرنے پر زور دیتا ہے کہ یہ نوڈ ایک `Internal` ہے۔
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// عارضی طور پر اسی نوڈ کے ل another ایک اور ، متغیر حوالہ لے جاتا ہے۔ہوشیار ، چونکہ یہ طریقہ بہت ہی خطرناک ہے ، دوگنا اس لئے کہ یہ فوری طور پر خطرناک ظاہر نہیں ہوسکتا ہے۔
    ///
    /// چونکہ متغیر پوائنٹر درخت کے آس پاس کہیں بھی گھوم سکتے ہیں ، لہذا واپس شدہ پوائنٹر کو آسانی سے اصل پوائنٹر کو ڈینگلنگ کرنے ، حد سے باہر ، یا سجا دیئے گئے قرض کے قواعد کے تحت غلط بنانے کے لئے استعمال کیا جاسکتا ہے۔
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` میں ابھی تک ایک اور قسم کا پیرامیٹر شامل کرنے پر غور کریں جو پابند پوائنٹر پر نیویگیشن طریقوں کے استعمال پر پابندی لگائے ، اور اس عدم استحکام کو روکتا ہے۔
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// کسی بھی پتی یا داخلی نوڈ کے پتے کے حصے تک خصوصی رسائی حاصل کرتا ہے۔
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // محفوظ: ہمارے پاس پورے نوڈ تک خصوصی رسائی ہے۔
        unsafe { &mut *ptr }
    }

    /// کسی بھی پتی یا اندرونی نوڈ کے پتی کے حصے تک خصوصی رسائی کی پیش کش کرتی ہے۔
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // محفوظ: ہمارے پاس پورے نوڈ تک خصوصی رسائی ہے۔
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// کلیدی اسٹوریج ایریا کے کسی عنصر تک خصوصی رسائی حاصل کرتی ہے۔
    ///
    /// # Safety
    /// `index` 0. .CAPACITY کی حدود میں ہے
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // محفوظ: کال کرنے والا خود سے مزید طریقوں پر کال نہیں کر سکے گا
        // جب تک کلی سلائس ریفرنس نہیں چھوڑ دیا جاتا ، کیوں کہ ہمارے پاس قرض کے دوران زندگی بھر تک انوکھا رسائی حاصل ہے۔
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// نوڈ کے ویلیو اسٹوریج ایریا کے کسی عنصر یا ٹکڑے تک خصوصی رسائی لیتا ہے۔
    ///
    /// # Safety
    /// `index` 0. .CAPACITY کی حدود میں ہے
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // محفوظ: کال کرنے والا خود سے مزید طریقوں پر کال نہیں کر سکے گا
        // جب تک ویلیو سلائس ریفرنس نہیں چھوڑ دیا جاتا ، کیوں کہ ہمارے پاس قرض کے دوران زندگی بھر تک انوکھی رسائی ہوتی ہے۔
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge مشمولات کے ل the نوڈ کے اسٹوریج ایریا کے کسی عنصر یا ٹکڑے تک خصوصی رسائی حاصل کرتا ہے۔
    ///
    /// # Safety
    /// `index` 0. .Capacity + 1 کی حد میں ہے
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // محفوظ: کال کرنے والا خود سے مزید طریقوں پر کال نہیں کر سکے گا
        // جب تک کہ edge سلائس حوالہ نہیں چھوڑ دیا جاتا ، کیوں کہ ہمارے پاس قرض کی زندگی بھر کے لئے انفرادی رسائی ہے۔
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - نوڈ میں `idx` سے زیادہ ابتدائی عنصر ہیں۔
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // ہم صرف ایک ہی عنصر کا حوالہ بناتے ہیں جس میں ہم دلچسپی رکھتے ہیں ، تاکہ دوسرے عناصر کے ساتھ بقایا حوالوں سے علیحدگی اختیار نہ کریں ، خاص طور پر ، جو پہلے والے اعدادوشمار میں کال کرنے والے کو واپس آئے۔
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // ہمیں Rust مسئلے #74679 کی وجہ سے غیر منقسم صف کے اشارے پر مجبور کرنا چاہئے۔
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// نوڈ کی لمبائی تک خصوصی رسائی حاصل کرتا ہے۔
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// نوڈ کے دوسرے حوالوں کو باطل کرنے کے بغیر نوڈ کا لنک اس کے والدین edge پر سیٹ کرتا ہے۔
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// جڑ کا اس کے والدین edge سے لنک صاف کرتا ہے۔
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// نوڈ کے آخر میں ایک کلیدی ویلیو جوڑی جوڑتا ہے۔
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` کے ذریعہ لوٹا ہوا ہر آئٹم نوڈ کے لئے ایک درست edge انڈیکس ہے۔
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// نوڈ کے آخر تک اس جوڑی کے دائیں طرف جانے کے لئے ایک کلیدی ویلیو جوڑی ، اور edge جوڑتا ہے۔
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// چیک کرتا ہے کہ آیا نوڈ ایک `Internal` نوڈ ہے یا `Leaf` نوڈ ہے۔
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// ایک نوڈ کے اندر ایک خاص کلیدی قدر والی جوڑی یا edge کا حوالہ۔
/// `Node` پیرامیٹر `NodeRef` ہونا ضروری ہے ، جبکہ `Type` یا تو `KV` (ایک اہم قدر والے جوڑے پر ہینڈل کی نشاندہی کرنے والا) یا `Edge` (edge پر ہینڈل کی نشاندہی کرنے والا) ہوسکتا ہے۔
///
/// نوٹ کریں کہ یہاں تک کہ `Leaf` نوڈس میں `Edge` ہینڈل بھی ہوسکتے ہیں۔
/// چائلڈ نوڈ کی طرف کسی پوائنٹر کی نمائندگی کرنے کے بجا the ، یہ ان جگہوں کی نمائندگی کرتے ہیں جہاں چائلڈ پوائنٹر کلیدی ویلیو جوڑے کے مابین جاتے تھے۔
/// مثال کے طور پر ، لمبائی 2 والے نوڈ میں ، edge کی 3 ممکنہ جگہیں ہوں گی ، ایک نوڈ کے بائیں طرف ، دو جوڑیوں کے درمیان ایک ، اور نوڈ کے دائیں طرف۔
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// ہمیں `#[derive(Clone)]` کی پوری عام حیثیت کی ضرورت نہیں ہے ، کیونکہ صرف وقت `Node` ہوگا `کلون` ایبل اس وقت ہوگا جب یہ غیر منقولہ حوالہ ہو اور اسی وجہ سے `Copy`۔
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// اس نوڈ کو بازیافت کرتا ہے جس میں edge یا کلیدی قدر والی جوڑی ہوتی ہے جو اس ہینڈل کی طرف اشارہ کرتا ہے۔
    pub fn into_node(self) -> Node {
        self.node
    }

    /// نوڈ میں اس ہینڈل کی پوزیشن لوٹاتا ہے۔
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` میں کلیدی قدر والی جوڑی کیلئے ایک نیا ہینڈل تخلیق کرتا ہے۔
    /// غیر محفوظ ہے کیونکہ کال کرنے والے کو یہ یقینی بنانا ہوگا کہ `idx < node.len()`۔
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// جزویہق کو عوامی طور پر نافذ کیا جاسکتا ہے ، لیکن صرف اس ماڈیول میں استعمال ہوتا ہے۔
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// اسی جگہ پر عارضی طور پر دوسرا ، ناقابل تبدیلی ہینڈل نکالتا ہے۔
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // ہم Handle::new_kv یا Handle::new_edge استعمال نہیں کرسکتے ہیں کیونکہ ہم اپنی قسم نہیں جانتے ہیں
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// غیر محفوظ طور پر جامد معلومات کے مرتب کرنے پر زور دیتا ہے کہ ہینڈل کا نوڈ ایک `Leaf` ہے۔
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// عارضی طور پر اسی مقام پر دوسرا ، متغیر ہینڈل نکالتا ہے۔
    /// ہوشیار ، چونکہ یہ طریقہ بہت ہی خطرناک ہے ، دوگنا اس لئے کہ یہ فوری طور پر خطرناک ظاہر نہیں ہوسکتا ہے۔
    ///
    ///
    /// تفصیلات کے لئے ، دیکھیں `NodeRef::reborrow_mut`۔
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // ہم Handle::new_kv یا Handle::new_edge استعمال نہیں کرسکتے ہیں کیونکہ ہم اپنی قسم نہیں جانتے ہیں
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` میں edge کے لئے ایک نیا ہینڈل تخلیق کرتا ہے۔
    /// غیر محفوظ ہے کیونکہ کال کرنے والے کو یہ یقینی بنانا ہوگا کہ `idx <= node.len()`۔
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ایک edge انڈیکس دیا گیا جہاں ہم صلاحیت سے بھرے ہوئے نوڈ میں داخل کرنا چاہتے ہیں ، اسپلٹ پوائنٹ کے ایک سمجھدار KV انڈیکس کی گنتی کرتے ہیں اور کہاں اندراج کرنا ہے۔
///
/// اسپلٹ پوائنٹ کا ہدف اس کی کلید اور قدر کے لئے والدین کے نوڈ میں ختم ہونا ہوتا ہے۔
/// کلید ، اقدار اور کنارے تقسیم کے نقطہ کے بائیں طرف بائیں بچے بن جاتے ہیں۔
/// کلیدیں ، اقدار اور کنارے تقسیم شدہ نقطہ کے دائیں طرف صحیح بچہ بن جاتے ہیں۔
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust مسئلہ #74834 ان ہم آہنگی کے قواعد کو سمجھانے کی کوشش کرتا ہے۔
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// اس edge کے دائیں اور بائیں طرف کی کلید ویلیو جوڑوں کے بیچ نیا کلیدی ویلیو جوڑی داخل کرتا ہے۔
    /// یہ طریقہ فرض کرتا ہے کہ نوڈی جوڑی کے فٹ ہونے کے ل. نوڈ میں کافی جگہ ہے۔
    ///
    /// لوٹا ہوا پوائنٹر داخل کردہ قدر کی طرف اشارہ کرتا ہے۔
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// اس edge کے دائیں اور بائیں طرف کی کلید ویلیو جوڑوں کے بیچ نیا کلیدی ویلیو جوڑی داخل کرتا ہے۔
    /// اگر کافی جگہ نہیں ہے تو یہ طریقہ نوڈ کو الگ کرتا ہے۔
    ///
    /// لوٹا ہوا پوائنٹر داخل کردہ قدر کی طرف اشارہ کرتا ہے۔
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// چائلڈ نوڈ میں پیرنٹ پوائنٹر اور انڈیکس کو ٹھیک کرتا ہے جس سے یہ edge لنک کرتا ہے۔
    /// یہ مفید ہے جب کناروں کی ترتیب کو تبدیل کردیا گیا ہے ،
    fn correct_parent_link(self) {
        // نوڈ کے دیگر حوالوں کو باطل کرنے کے بغیر بیک پوائنٹر بنائیں۔
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ایک نیا کلیدی ویلیو جوڑی اور ایک edge داخل کرتا ہے جو اس edge اور اس edge کے دائیں طرف کی-ویلیو جوڑی کے بیچ اس نئی جوڑی کے دائیں طرف جائے گا۔
    /// یہ طریقہ فرض کرتا ہے کہ نوڈی جوڑی کے فٹ ہونے کے ل. نوڈ میں کافی جگہ ہے۔
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ایک نیا کلیدی ویلیو جوڑی اور ایک edge داخل کرتا ہے جو اس edge اور اس edge کے دائیں طرف کی-ویلیو جوڑی کے بیچ اس نئی جوڑی کے دائیں طرف جائے گا۔
    /// اگر کافی جگہ نہیں ہے تو یہ طریقہ نوڈ کو الگ کرتا ہے۔
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// اس edge کے دائیں اور بائیں طرف کی کلید ویلیو جوڑوں کے بیچ نیا کلیدی ویلیو جوڑی داخل کرتا ہے۔
    /// اگر یہ جگہ کافی جگہ نہیں ہے تو یہ طریقہ نوڈ کو الگ کرتا ہے ، اور جب تک کہ جڑ تک نہ پہنچ جاتا ہے اس کو والدین کے نوڈ میں اسپلٹ آف حصے کو داخل کرنے کی کوشش کرتا ہے۔
    ///
    ///
    /// اگر لوٹا ہوا نتیجہ `Fit` ہے تو ، اس کے ہینڈل کا نوڈ اس edge کا نوڈ یا باپ دادا ہوسکتا ہے۔
    /// اگر لوٹا ہوا نتیجہ `Split` ہے تو ، `left` فیلڈ روٹ نوڈ ہوگا۔
    /// لوٹا ہوا پوائنٹر داخل کردہ قدر کی طرف اشارہ کرتا ہے۔
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// اس edge کے ذریعہ نوڈ ملا۔
    ///
    /// طریقہ کار کا نام آپ کے اوپر جڑوں کے نوٹوں کے ساتھ درختوں کی تصویر لینے کا فرض کرتا ہے۔
    ///
    /// `edge.descend().ascend().unwrap()` اور `node.ascend().unwrap().descend()` دونوں کو ، کامیابی پر ، کچھ نہیں کرنا چاہئے۔
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ہمیں نوڈس کے لئے خام پوائنٹر استعمال کرنے کی ضرورت ہے کیونکہ ، اگر بورن ٹائپ marker::ValMut ہے تو ، ان اقدار کے بارے میں بقایا تغیر پذیر حوالہ مل سکتا ہے جنہیں ہمیں مسترد نہیں کرنا چاہئے۔
        // اونچائی والے فیلڈ تک رسائی میں کوئی پریشانی نہیں ہے کیونکہ اس قدر کی نقل کی گئی ہے۔
        // ہوشیار رہیں ، ایک بار نوڈ پوائنٹر کو حوالہ دینے کے بعد ، ہم ایک حوالہ (Rust مسئلہ #73987) کے ساتھ کناروں کے سرنی تک پہنچ جاتے ہیں اور صف کے اندر یا اس کے اندر کسی بھی دوسرے حوالوں کو باطل کردیتے ہیں۔
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // ہم علیحدہ کلید اور قدر کے طریقوں پر کال نہیں کرسکتے ہیں ، کیونکہ دوسرے کو کال کرنے سے پہلے کی طرف سے واپس آنے والے حوالہ کو باطل کردیا جاتا ہے۔
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV ہینڈل سے منسوب کلید اور قدر کی جگہ لیں۔
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// پتے کے اعداد و شمار کا خیال رکھتے ہوئے ، کسی خاص `NodeType` کے لئے `split` کے نفاذ میں مدد ملتی ہے۔
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// بنیادی نوڈ کو تین حصوں میں تقسیم کرتا ہے۔
    ///
    /// - اس ہینڈل کے بائیں طرف صرف اہم قدر والے جوڑے رکھنے کے ل The نوڈ چھوٹا ہے۔
    /// - اس ہینڈل کے ذریعہ اشارہ کی گئی کلید اور قدر کو نکالا جاتا ہے۔
    /// - اس ہینڈل کے دائیں طرف کے تمام کلیدی قدر کے جوڑے ایک نئے مختص نوڈ میں ڈالے گئے ہیں۔
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// اس ہینڈل کے ذریعہ اشارہ کردہ کلیدی قدر کی جوڑی کو ہٹاتا ہے اور edge کے ساتھ ساتھ ، کلیدی قدر کی جوڑی منہدم ہونے کے ساتھ اسے واپس کردیتا ہے۔
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// بنیادی نوڈ کو تین حصوں میں تقسیم کرتا ہے۔
    ///
    /// - اس ہینڈل کے بائیں طرف صرف کناروں اور کلیدی قدر کے جوڑے رکھنے کے ل The نوڈ چھوٹا ہے۔
    /// - اس ہینڈل کے ذریعہ اشارہ کی گئی کلید اور قدر کو نکالا جاتا ہے۔
    /// - اس ہینڈل کے دائیں طرف کے تمام کناروں اور کلیدی قدر کے جوڑے ایک نئے مختص نوڈ میں ڈالے گئے ہیں۔
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// اندرونی کلیدی قدر والی جوڑی کے آس پاس توازن آپریشن کا جائزہ لینے اور انجام دینے کے لئے سیشن کی نمائندگی کرتا ہے۔
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// بچپن میں نوڈ کو شامل کرنے والا متوازن سیاق و سباق کا انتخاب کرتا ہے ، اس طرح والدین کے نوڈ میں کے وی کے فورا between بعد بائیں یا دائیں طرف۔
    /// اگر کوئی والدین نہیں ہے تو ایک `Err` لوٹاتا ہے۔
    /// Panics اگر والدین خالی ہوں۔
    ///
    /// بائیں طرف کو ترجیح دیتی ہے ، اگر دیئے گئے نوڈ کسی حد تک زیریں ہوں تو ، یہاں صرف معنی یہ ہے کہ اس کے بائیں بہن بھائی اور اس کے دائیں بہن بھائی سے کہیں زیادہ عناصر موجود ہیں ، اگر وہ موجود ہوں۔
    /// اس صورت میں ، بائیں بہن بھائی کے ساتھ ضم ہوجانا تیز تر ہوتا ہے ، کیونکہ ہمیں صرف نوڈ کے این عناصر کو دائیں طرف منتقل کرنے اور N عناصر سے زیادہ آگے بڑھنے کے بجائے انہیں منتقل کرنے کی ضرورت ہوتی ہے۔
    /// بائیں بھائی سے چوری کرنا بھی عام طور پر تیز تر ہوتا ہے ، کیوں کہ ہمیں بہن بھائی کے عناصر میں سے کم سے کم این کو بائیں طرف منتقل کرنے کے بجائے نوڈ کے این عناصر کو دائیں طرف منتقل کرنے کی ضرورت ہے۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// واپسی چاہے انضمام ممکن ہے ، یعنی ، چاہے کسی نوڈ میں کافی کمرہ موجود ہو یا وسطی کے وی کو ملحقہ بچوں کے دونوں نوڈس کے ساتھ جوڑ دیں۔
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// انضمام کرتا ہے اور بند ہونے سے فیصلہ کرنے دیتا ہے کہ کیا لوٹنا ہے۔
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // سلامتی: نوڈس کو ملائے جانے کی اونچائی اونچائی سے نیچے ہے
                // اس edge کے نوڈ کا ، اس طرح صفر سے اوپر ہے ، لہذا وہ داخلی ہیں۔
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// والدین کی کلید ویلیو جوڑی اور دونوں ملحقہ بچے نوڈس کو بائیں بچے کے نوڈ میں ضم کرتا ہے اور سکڑ شدہ والدین نوڈ کو لوٹاتا ہے۔
    ///
    ///
    /// Panics جب تک ہم `.can_merge()` نہ ہوں۔
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// والدین کی کلید ویلیو جوڑی اور دونوں ملحقہ چائلڈ نوڈس کو بائیں بچے کے نوڈ میں ضم کرتا ہے اور اس بچے کے نوڈ کو لوٹاتا ہے۔
    ///
    ///
    /// Panics جب تک ہم `.can_merge()` نہ ہوں۔
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// والدین کی کلیدی قدر والی جوڑی اور دونوں ملحقہ بچے نوڈس کو بائیں بچے کے نوڈ میں ضم کرتا ہے اور اس چلڈرن نوڈ میں edge ہینڈل واپس کرتا ہے جہاں ٹریک شدہ بچہ edge ختم ہوتا ہے ،
    ///
    ///
    /// Panics جب تک ہم `.can_merge()` نہ ہوں۔
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// بوڑھے والدین سے کلیدی قدر والی جوڑی کو ہٹاتا ہے اور والدین کے کلیدی ویلیو اسٹوریج میں رکھتا ہے ، جبکہ پرانے والدین کی کلید ویلیو جوڑی کو دائیں بچے میں دھکیل دیتے ہیں۔
    ///
    /// دائیں بچے میں edge پر ایک ہینڈل واپس کرتا ہے جہاں `track_right_edge_idx` کے ذریعہ متعین کردہ اصل edge ختم ہوا تھا۔
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// دائیں بچے سے کلیدی قدر والی جوڑی کو ہٹاتا ہے اور والدین کے کلیدی ویلیو اسٹوریج میں رکھتا ہے ، جبکہ پرانے والدین کی کلید ویلیو جوڑی کو بائیں بچے کی طرف دھکیل دیتے ہیں۔
    ///
    /// `track_left_edge_idx` کے ذریعہ بتائے گئے بائیں بچے میں edge پر ایک ہینڈل واپس کرتا ہے ، جو حرکت نہیں کرتا ہے۔
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// یہ `steal_left` کی طرح کی چوری کرتا ہے لیکن ایک ہی بار میں متعدد عنصر چوری کرتا ہے۔
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // یقینی بنائیں کہ ہم محفوظ طریقے سے چوری کرسکتے ہیں۔
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // پتیوں کا ڈیٹا منتقل کریں۔
            {
                // صحیح بچے میں چوری شدہ عناصر کے ل room جگہ بنائیں۔
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // عناصر کو بائیں بچے سے دائیں میں منتقل کریں۔
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // سب سے زیادہ چوری ہونے والی جوڑی کو والدین کے پاس منتقل کریں۔
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // والدین کی کلیدی قدر والی جوڑی کو صحیح بچے میں منتقل کریں۔
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // چوری شدہ کناروں کے لئے جگہ بنائیں۔
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // کناروں چوری
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` کا ہم آہنگی کلون۔
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // یقینی بنائیں کہ ہم محفوظ طریقے سے چوری کرسکتے ہیں۔
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // پتیوں کا ڈیٹا منتقل کریں۔
            {
                // دائیں سب سے زیادہ چوری ہونے والی جوڑی کو والدین کے پاس منتقل کریں۔
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // والدین کی کلیدی قدر والی جوڑی کو بائیں بچے میں منتقل کریں۔
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // عناصر کو دائیں بچے سے بائیں میں منتقل کریں۔
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // خلا کو پُر کریں جہاں چوری ہونے والے عناصر ہوتے تھے۔
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // کناروں چوری
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // خلا کو پُر کریں جہاں چوری شدہ کنارے ہوتے تھے۔
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// کوئی مستحکم معلومات ہٹاتا ہے اور یہ کہتے ہوئے کہ یہ نوڈ `Leaf` نوڈ ہے۔
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// کوئی مستحکم معلومات ہٹاتا ہے اور یہ کہتے ہوئے کہ یہ نوڈ ایک `Internal` نوڈ ہے۔
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// جانچ پڑتال کرتا ہے کہ آیا بنیادی نوڈ `Internal` نوڈ ہے یا `Leaf` نوڈ ہے۔
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` کے بعد لاحقہ کو ایک نوڈ سے دوسرے میں منتقل کریں۔`right` خالی ہونا چاہئے۔
    /// `right` کا پہلا edge ابھی بھی بدلا ہوا ہے۔
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// اندراج کا نتیجہ ، جب نوڈ کو اپنی صلاحیت سے باہر بڑھنے کی ضرورت ہو۔
pub struct SplitResult<'a, K, V, NodeType> {
    // موجودہ درخت میں نوڈ کو تبدیل کیا گیا ہے جس میں عناصر اور کناروں ہیں جو `kv` کے بائیں طرف سے ہیں۔
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // کہیں اور داخل کرنے کے ل key ، کچھ کلید اور قدر تقسیم ہوجائیں۔
    pub kv: (K, V),
    // `kv` کے دائیں سے تعلق رکھنے والے عناصر اور کناروں کے ساتھ مالک ، غیر منسلک ، نیا نوڈ۔
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // چاہے اس قرض کے نوڈ کے حوالہ جات درخت کے دوسرے نوڈس تک جانے کی اجازت دیں۔
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ٹراورسل کی ضرورت نہیں ہے ، یہ `borrow_mut` کا نتیجہ استعمال کرکے ہوتا ہے۔
        // ٹراورسال کو غیر فعال کرکے ، اور صرف جڑوں کے لئے نئے حوالہ جات پیدا کرکے ، ہم جانتے ہیں کہ `Owned` قسم کا ہر حوالہ جڑ نوڈ پر ہوتا ہے۔
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// ابتدائی عناصر کی ایک ٹکڑی میں ایک قدر داخل کرتا ہے جس کے بعد ایک غیر متعل .ق عنصر ہوتا ہے۔
///
/// # Safety
/// سلائس میں `idx` سے زیادہ عنصر ہوتے ہیں۔
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// تمام ابتدائی عناصر کی ایک ٹکڑی سے ایک قدر کو ہٹاتا ہے اور واپس کرتا ہے ، ایک پیچھے پیچھے بننے والے عنصر کو چھوڑ کر۔
///
///
/// # Safety
/// سلائس میں `idx` سے زیادہ عنصر ہوتے ہیں۔
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// عناصر کو سلائس `distance` پوزیشن میں بائیں طرف منتقل کریں۔
///
/// # Safety
/// سلائس میں کم از کم `distance` عنصر ہوتے ہیں۔
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// عناصر کو سلائس `distance` پوزیشن میں دائیں طرف منتقل کریں۔
///
/// # Safety
/// سلائس میں کم از کم `distance` عنصر ہوتے ہیں۔
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// شروع کردہ عناصر کی ایک ٹکڑی سے تمام اقدار کو غیر بنائے ہوئے عناصر کے ٹکڑے میں منتقل کردیتا ہے ، اور `src` کو بیک وقت چھوڑ کر چھوڑ دیتا ہے۔
///
/// `dst.copy_from_slice(src)` کی طرح کام کرتا ہے لیکن `T` کو `Copy` ہونے کی ضرورت نہیں ہے۔
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;