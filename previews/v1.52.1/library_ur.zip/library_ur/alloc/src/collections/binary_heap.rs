//! بائنری ڈھیر کے ساتھ ترجیحی قطار نافذ کی گئی۔
//!
//! سب سے بڑے عنصر کو داخل اور پوپ کرنا *O*(log(*n*)) وقت کی پیچیدگی ہے۔
//! سب سے بڑے عنصر کی جانچ پڑتال *O*(1) ہے۔ایک vector کو بائنری ڈھیر میں تبدیل کرنا جگہ جگہ ہوسکتا ہے ، اور اس میں *O*(*n*) پیچیدگی ہے۔
//! ایک بائنری ڈھیر کو جگہ جگہ ترتیب شدہ vector میں بھی تبدیل کیا جاسکتا ہے ، جس سے اسے *O*(*n*\*log(* n*)) جگہ جگہ کے ہیپس اسٹورٹ) کے لئے استعمال کیا جاسکتا ہے۔
//!
//! # Examples
//!
//! یہ ایک بڑی مثال ہے جو [shortest path problem][sssp] کو [directed graph][dir_graph] پر حل کرنے کے لئے [Dijkstra's algorithm][dijkstra] لاگو کرتی ہے۔
//!
//! یہ ظاہر کرتا ہے کہ کس طرح کسٹم کی اقسام کے ساتھ [`BinaryHeap`] استعمال کریں۔
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ترجیحی قطار `Ord` پر منحصر ہے۔
//! // trait کو واضح طور پر نافذ کریں لہذا قطار زیادہ سے زیادہ ڈھیر کی بجائے منی ہیپ ہوجائے۔
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // نوٹ کریں کہ ہم اخراجات پر آرڈر کو پلٹائیں۔
//!         // ہم عہدوں کا موازنہ کرنے کی صورت میں ، `PartialEq` اور `Ord` کے نفاذ کو مستحکم کرنے کے لئے یہ اقدام ضروری ہے۔
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` اس پر بھی عمل درآمد کرنے کی ضرورت ہے۔
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ایک چھوٹے نفاذ کے ل Each ، ہر نوڈ کو `usize` کی نمائندگی کیا جاتا ہے۔
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ڈجک اسٹرا کا سب سے مختصر راستہ الگورتھم۔
//!
//! // `start` سے شروع کریں اور ہر نوڈ کے موجودہ مختصر فاصلے کو ٹریک کرنے کے لئے `dist` کا استعمال کریں۔یہ عمل میموری سے موثر نہیں ہے کیوں کہ یہ قطار میں ڈپلیکیٹ نوڈس چھوڑ سکتا ہے۔
//! //
//! // یہ آسان تر نفاذ کے ل X ، `usize::MAX` کو بطور مرسل قدر کی حیثیت سے بھی استعمال کرتا ہے۔
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [نوڈ]=موجودہ `start` سے `node` تک سب سے کم فاصلہ
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // ہم صفر لاگت کے ساتھ ، `start` پر ہیں
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // کم لاگت نوڈس والے پہلے (min-heap) کے ساتھ فرنٹیئر کا جائزہ لیں
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // متبادل کے طور پر ہم تمام مختصر راستے تلاش کرنا جاری رکھ سکتے تھے
//!         if position == goal { return Some(cost); }
//!
//!         // ضروری ہے کیونکہ ہم نے پہلے سے ہی کوئی بہتر راستہ تلاش کر لیا ہے
//!         if cost > dist[position] { continue; }
//!
//!         // ہر نوڈ کے ل we جہاں ہم پہنچ سکتے ہیں ، دیکھیں کہ کیا ہم اس نوڈ سے گزرنے والی کم لاگت کے ساتھ کوئی راستہ تلاش کرسکتے ہیں
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // اگر ایسا ہے تو ، اسے فرنٹیئر میں شامل کریں اور جاری رکھیں
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // آرام ، ہم نے اب ایک بہتر راستہ تلاش کر لیا ہے
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // مقصد قابل رسائ نہیں
//!     None
//! }
//!
//! fn main() {
//!     // یہ ہدایت کار گراف ہے جسے ہم استعمال کرنے جارہے ہیں۔
//!     // نوڈ کی تعداد مختلف ریاستوں کے مساوی ہے ، اور edge وزن ایک نوڈ سے دوسرے میں جانے کی قیمت کی علامت ہے۔
//!     //
//!     // نوٹ کریں کہ کنارے ایک طرفہ ہیں۔
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // گراف کو ملحقہ فہرست کے طور پر پیش کیا گیا ہے جہاں ہر اشاریہ ، ایک نوڈ ویلیو کے مطابق ہے ، باہر جانے والے کناروں کی ایک فہرست ہے۔
//!     // اس کی کارکردگی کے لئے منتخب کیا گیا ہے۔
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // نوڈ 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // نوڈ 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // نوڈ 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // نوڈ 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // نوڈ 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// بائنری ڈھیر کے ساتھ ترجیحی قطار نافذ کی گئی۔
///
/// یہ ایک زیادہ سے زیادہ ڈھیر ہوگا۔
///
/// کسی شے کو اس طرح تبدیل کرنا معقول غلطی ہے کہ `Ord` trait کے ذریعہ مقرر کردہ کسی اور شے کے مقابلے میں شے کے حکم کی ترتیب ، تبدیل ہوجاتی ہے۔
///
/// یہ عام طور پر صرف `Cell` ، `RefCell` ، عالمی ریاست ، I/O ، یا غیر محفوظ کوڈ کے ذریعہ ممکن ہے۔
/// اس طرح کی منطق کی غلطی کے نتیجے میں ہونے والا سلوک متعین نہیں ہے ، لیکن اس کا نتیجہ غیر وضاحتی رویے کا نتیجہ نہیں نکلے گا۔
/// اس میں panics ، غلط نتائج ، اسقاط ، میموری میموری اور غیر اختتامی شامل ہوسکتے ہیں۔
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // قسم کا اندازہ ہمیں ایک واضح قسم کے دستخط (جو اس مثال میں `BinaryHeap<i32>` ہوگا) کو ختم کرنے دیتا ہے۔
/////
/// let mut heap = BinaryHeap::new();
///
/// // ڈھیر میں اگلی آئٹم دیکھنے کے لek ہم جھانکنے کا استعمال کرسکتے ہیں۔
/// // اس معاملے میں ، ابھی تک وہاں کوئی آئٹم نہیں ہے لہذا ہمیں کوئی بھی نہیں ملتا ہے۔
/// assert_eq!(heap.peek(), None);
///
/// // آئیے کچھ اسکور شامل کریں ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // اب جھانکنا ڈھیر میں سب سے اہم شے کو دکھاتا ہے۔
/// assert_eq!(heap.peek(), Some(&5));
///
/// // ہم ڈھیر کی لمبائی کی جانچ کر سکتے ہیں۔
/// assert_eq!(heap.len(), 3);
///
/// // ہم ڈھیر میں موجود اشیاء پر اعادہ کرسکتے ہیں ، حالانکہ وہ بے ترتیب ترتیب میں واپس کردیئے گئے ہیں۔
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // اگر ہم ان اسکورز کو پاپ کردیں تو ، ان کو ترتیب میں واپس آنا چاہئے۔
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // ہم باقی کسی بھی چیز کا ڈھیر صاف کرسکتے ہیں۔
/// heap.clear();
///
/// // ڈھیر اب خالی ہونی چاہئے۔
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap` کو کم سے کم ڈھیر بنانے کے لئے یا تو `std::cmp::Reverse` یا ایک کسٹم `Ord` استعمال کیا جاسکتا ہے۔
/// اس سے `heap.pop()` سب سے بڑی قیمت کے بجائے سب سے چھوٹی ویلیو کو لوٹاتا ہے۔
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` میں قدریں لپیٹ دیں
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // اگر اب ہم یہ اسکور پاپ کرتے ہیں تو انہیں ریورس ترتیب میں واپس آنا چاہئے۔
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # وقت کی پیچیدگی
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` کی قیمت متوقع لاگت ہے۔طریقہ دستاویزات ایک زیادہ تفصیلی تجزیہ پیش کرتا ہے۔
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// ایک `BinaryHeap` پر سب سے بڑی چیز کے لئے تبدیل تبادلہ ریفرنس لپیٹ ڈھانچہ.
///
///
/// یہ `struct` [`BinaryHeap`] پر [`peek_mut`] طریقہ کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // محفوظ کریں: چیک میکٹ صرف خالی ڈھیروں کے ل for ہے۔
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // سیف: چیک میکٹ صرف خالی ڈھیروں کے لan ہے
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // سیف: چیک میکٹ صرف خالی ڈھیروں کے لan ہے
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// ڈھیر سے جھانکی ہوئی قدر کو ہٹا دیتا ہے اور اسے لوٹاتا ہے۔
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ایک خالی `BinaryHeap<T>` بناتا ہے۔
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// ایک خالی `BinaryHeap` زیادہ سے زیادہ کے طور پر بناتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// ایک خاص صلاحیت کے ساتھ خالی `BinaryHeap` بناتا ہے۔
    /// یہ `capacity` عناصر کے ل enough کافی میموری کا تعی .ن کرتا ہے ، تاکہ `BinaryHeap` کو دوبارہ گنتی نہ ہو جب تک کہ اس میں کم از کم بہت سے اقدار شامل نہ ہوں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// ثنائی کے ڈھیر میں موجود سب سے بڑی شے کے تبادلے کا حوالہ ، یا اگر خالی ہے تو `None` لوٹاتا ہے۔
    ///
    /// Note: اگر `PeekMut` ویلیو لیک ہوجاتی ہے تو ڈھیر متضاد حالت میں ہوسکتی ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # وقت کی پیچیدگی
    ///
    /// اگر آئٹم میں ترمیم کی گئی ہے تو وقت کی بدترین پیچیدگی *O*(log(*n*)) ہے ، ورنہ یہ *O*(1) ہے۔
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// بائنری ڈھیر سے سب سے بڑی شے کو ہٹاتا ہے اور اسے واپس کرتا ہے ، یا اگر خالی ہے تو `None`۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # وقت کی پیچیدگی
    ///
    /// `pop` کی سب سے خراب قیمت لاگت میں *n* عناصر پر مشتمل ڈھیر پر *O*(log(*n*)) ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // حفاظت: !self.is_empty() کا مطلب ہے self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// بائنری ڈھیر پر کسی آئٹم کو دباتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # وقت کی پیچیدگی
    ///
    /// `push` کی متوقع لاگت ، جس کے عناصر کو دھکیلنے کے ہر ممکن ترتیب سے زیادہ اوسطاus ، اور کافی تعداد میں دھکے کھاتے ہوئے ،*O*(1) ہے۔
    ///
    /// کسی بھی ترتیب والے نمونہ میں پہلے سے ہی *نہیں* عناصر کو آگے بڑھاتے وقت یہ سب سے معنی خیز میٹرک ہے۔
    ///
    /// اگر عناصر کو بنیادی طور پر صعودی ترتیب میں دھکیل دیا جائے تو وقت کی پیچیدگی کم ہوجاتی ہے۔
    /// بدترین صورت میں ، عناصر کو بڑھتے ہوئے ترتیب میں دھکیل دیا جاتا ہے اور ہر دھکا کے حساب سے قیمت ایک *O*(log(*n*)) ہے جس میں *n* عناصر ہوتے ہیں۔
    ///
    /// ایک *سنگل* کال کی `push` پر بدترین قیمت لاگت *O*(*n*) ہے۔سب سے خراب صورتحال اس وقت ہوتی ہے جب صلاحیت ختم ہوجاتی ہے اور اس کو دوبارہ سائز کی ضرورت ہوتی ہے۔
    /// پچھلے اعدادوشمار میں سائز تبدیل کرنے کی قیمت میں رقم کی گئی ہے۔
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // حفاظت: چونکہ ہم نے ایک نئی شے کو آگے بڑھایا اس کا مطلب ہے
        //  old_len= self.len() ، 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` لیتا ہے اور (ascending) ترتیب میں vector واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // محفوظ: `end` `self.len() - 1` سے 1 (دونوں شامل ہیں) پر جاتا ہے ،
            //  لہذا یہ ہمیشہ رسائی کے لئے ایک درست انڈیکس ہے۔
            //  انڈیکس 0 (یعنی `ptr`) تک رسائی حاصل کرنا محفوظ ہے ، کیونکہ
            //  1 <=آخر <self.len() ، جس کا مطلب ہے self.len()>=2۔
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // محفوظ: `end` `self.len() - 1` سے 1 (دونوں شامل ہیں) پر جاتا ہے:
            //  0 <1 <=آخر <= self.len()، 1 <self.len() جس کا مطلب ہے 0 <آخر اور اختتام <self.len()۔
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // سیفٹ اپ اور سیفٹ ڈاون کے نفاذ میں کسی عنصر کو زیڈ0 ویکٹر0 زیڈ (کسی سوراخ کے پیچھے چھوڑنا) منتقل کرنے کے لsa غیر محفوظ بلاکس استعمال ہوتے ہیں ، دوسروں کے ساتھ شفٹ ہوجاتے ہیں اور ہٹائے گئے عنصر کو واپس سوراخ کے آخری مقام پر زیڈ ویکٹر0 زیڈ میں منتقل کرتے ہیں۔
    //
    // `Hole` قسم اس کی نمائندگی کرنے کے لئے استعمال ہوتا ہے ، اور اس بات کو یقینی بناتا ہے کہ سوراخ اپنے دائرہ کار کے اختتام پر ، یہاں تک کہ panic پر بھی بھرا ہوا ہے۔
    // کسی سوراخ کا استعمال بدلاؤ کے استعمال کے مقابلے میں مستقل عنصر کو کم کرتا ہے ، جس میں دو مرتبہ کئی حرکتیں ہوتی ہیں۔
    //
    //
    //
    //

    /// # Safety
    ///
    /// کال کرنے والے کو اس کی ضمانت دینا ہوگی کہ `pos < self.len()`۔
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` پر قیمت نکالیں اور ایک سوراخ بنائیں۔
        // محفوظ: کال کرنے والے کی ضمانت دیتا ہے کہ << self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // حفاظت: hole.pos()> start>=0 ، جس کا مطلب ہے hole.pos()> 0
            //  اور اس طرح hole.pos() ، 1 زیر بہاؤ نہیں ہوسکتا ہے۔
            //  اس کی ضمانت دیتا ہے کہ والدین <hole.pos() لہذا یہ ایک درست اشاریہ ہے اور یہ بھی!= hole.pos()۔
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // حفاظت: اوپر کی طرح
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` پر عنصر لیں اور اسے ڈھیر سے نیچے منتقل کریں ، جبکہ اس کے بچے بڑے ہوں۔
    ///
    ///
    /// # Safety
    ///
    /// کال کرنے والے کو اس کی ضمانت دینا ہوگی کہ `pos < end <= self.len()`۔
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // محفوظ: کال کرنے والے کی ضمانت دیتا ہے کہ << آخر <= self.len()۔
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // لوپ ناگوار: بچہ==2 * hole.pos() + 1۔
        while child <= end.saturating_sub(2) {
            // دو بچوں کی زیادہ سے زیادہ حفاظت کے ساتھ موازنہ کریں: بچے <آخر ، 1 <self.len() اور بچہ + 1 <آخر <= self.len() ، لہذا وہ درست اشاریہ ہیں۔
            //
            //  بچہ==2 *hole.pos() + 1!= hole.pos() اور بچہ + 1==2* hole.pos() + 2!= hole.pos()۔
            // FIXME: اگر T ZST ہے تو 2 *hole.pos() + 1 یا 2* hole.pos() + 2 اوور فلو ہوسکتے ہیں
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // اگر ہم پہلے سے ترتیب میں ہیں ، رکیں۔
            // محفوظ کریں: بچہ اب یا تو بوڑھا بچہ ہے یا بوڑھا بچہ +1
            //  ہم پہلے ہی ثابت کر چکے ہیں کہ دونوں <self.len() اور!= hole.pos() ہیں
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // حفاظت: اوپر کی طرح.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // حفاظت: &&شارٹ سرکٹ ، جس کا مطلب ہے کہ
        //  دوسری شرط یہ پہلے ہی سچ ہے کہ بچہ==آخر ، 1 <self.len()۔
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // حفاظت: بچہ پہلے سے ہی درست انڈیکس ثابت ہوا ہے اور
            //  بچہ==2 * hole.pos() + 1!= hole.pos()۔
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// کال کرنے والے کو اس کی ضمانت دینا ہوگی کہ `pos < self.len()`۔
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // حفاظت: پوز <لین کال کرنے والے کی طرف سے ضمانت دی جاتی ہے اور
        //  واضح طور پر لین= self.len() <= self.len()۔
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` پر عنصر لیں اور اسے ڈھیر کے نیچے پورے راستے پر منتقل کریں ، پھر اسے اپنی پوزیشن تک لے جائیں۔
    ///
    ///
    /// Note: یہ تیز ہوتا ہے جب عنصر بڑا معلوم ہوتا ہے/نیچے سے قریب ہونا چاہئے۔
    ///
    /// # Safety
    ///
    /// کال کرنے والے کو اس کی ضمانت دینا ہوگی کہ `pos < self.len()`۔
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // محفوظ: کال کرنے والے کی ضمانت دیتا ہے کہ << self.len()۔
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // لوپ ناگوار: بچہ==2 * hole.pos() + 1۔
        while child <= end.saturating_sub(2) {
            // محفوظ کریں: بچہ <آخر ، 1 <self.len() اور
            //  بچہ +1 <آخر <= self.len() ، لہذا وہ درست اشاریہ ہیں۔
            //  بچہ==2 *hole.pos() + 1!= hole.pos() اور بچہ + 1==2* hole.pos() + 2!= hole.pos()۔
            //
            // FIXME: اگر T ZST ہے تو 2 *hole.pos() + 1 یا 2* hole.pos() + 2 اوور فلو ہوسکتے ہیں
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // حفاظت: اوپر کی طرح
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // محفوظ: بچہ==آخر ، 1 <self.len() ، لہذا یہ ایک درست اشاریہ ہے
            //  اور بچہ==2 * hole.pos() + 1!= hole.pos()۔
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // سلامتی: پوز سوراخ میں پوزیشن ہے اور پہلے ہی ثابت ہوچکی ہے
        //  ایک درست انڈیکس ہونا۔
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // حفاظت: n self.len()/2 سے شروع ہوتا ہے اور 0 پر جاتا ہے۔
            //  صرف اسی صورت میں جب! (n <self.len()) اگر self.len() ==0 ہے ، لیکن اس کی لوپ کی حالت سے انکار کردیا گیا ہے۔
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` کے تمام عناصر کو `self` میں منتقل کرتا ہے ، `other` کو خالی چھوڑ دیتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) آپریشنز اور تقریبا 2 *(len1 + len2) کا موازنہ بدترین صورت میں کرتا ہے جبکہ `extend` O(len2* log(len1)) کارروائیوں اور len1>= len2 کو سنبھالتے ہوئے 1 *len2* log_2(len1) کا مقابلہ کرتے ہیں۔
        // بڑے ڈھیروں کے ل the ، کراس اوور پوائنٹ اب اس استدلال کی پیروی نہیں کرتا ہے اور اسے تجرباتی طور پر طے کیا گیا تھا۔
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// ایک ایسیٹر لوٹاتا ہے جو ڈھیر کے آرڈر میں عناصر کو بازیافت کرتا ہے۔
    /// بازیافت عناصر کو اصل ڈھیر سے ہٹا دیا جاتا ہے۔
    /// باقی عناصر کو ہیپ آرڈر میں چھوڑنے پر نکال دیا جائے گا۔
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)) X `.drain()` سے کہیں زیادہ سست ہے۔
    ///   آپ کو زیادہ تر معاملات میں مؤخر الذکر استعمال کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // ڈھیر کے آرڈر میں تمام عناصر کو ہٹاتا ہے
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// پیش گوئی کے ذریعہ مخصوص عناصر کو برقرار رکھتا ہے۔
    ///
    /// دوسرے لفظوں میں ، `e` کے تمام عناصر کو حذف کریں جیسے `f(&e)` `false` کو واپس کرتا ہے۔
    /// عناصر کو غیر ترتیب شدہ (اور غیر متعینہ) ترتیب میں ملاحظہ کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // صرف نمبر رکھیں
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// زیربحث vector میں سبھی اقدار کے مکرر ترتیب سے ، ایک ویڈیٹر لوٹاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // صوابدیدی ترتیب میں 1 ، 2 ، 3 ، 4 پرنٹ کریں
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// ایک ایسیٹر لوٹاتا ہے جو ڈھیر کے آرڈر میں عناصر کو بازیافت کرتا ہے۔
    /// یہ طریقہ اصلی ڈھیر کھاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// بائنری ہیپ میں سب سے بڑی آئٹم ، یا اگر خالی ہے تو `None` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # وقت کی پیچیدگی
    ///
    /// بدترین صورتحال میں لاگت *O*(1) ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// ثنائی کے ڈھیر پر دوبارہ عمل کیے بغیر عنصروں کی تعداد لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// دیئے گئے `BinaryHeap` میں بالکل `additional` مزید عناصر داخل کرنے کے لئے کم سے کم گنجائش کا ذخیرہ کریں۔
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// نوٹ کریں کہ مختص کرنے والا اس کی درخواست سے کہیں زیادہ جگہ دے سکتا ہے۔
    /// لہذا صلاحیت کو کم سے کم ہونے پر انحصار نہیں کیا جاسکتا ہے۔
    /// اگر future اضافے کی توقع ہے تو [`reserve`] کو ترجیح دیں۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `usize` سے زیادہ بہتی ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` میں ڈالنے کے لئے کم از کم `additional` مزید عناصر کی گنجائش کا ذخیرہ۔
    /// کثرت رائے سے بچنے کے لئے مجموعہ میں مزید جگہ محفوظ ہوسکتی ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `usize` سے زیادہ بہتی ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// زیادہ سے زیادہ اضافی صلاحیت کو ضائع کردیں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// نچلی حد کے ساتھ گنجائش کو ضائع کردے۔
    ///
    /// گنجائش کم از کم لمبائی اور فراہم کردہ قیمت دونوں کی حد تک ہی باقی رہے گی۔
    ///
    ///
    /// اگر موجودہ صلاحیت کم حد سے کم ہے تو ، یہ کوئی آپٹ نہیں ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` استعمال کرتا ہے اور بنیادی vector کو صوابدیدی ترتیب میں واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // کچھ ترتیب میں پرنٹ کریں گے
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// بائنری ڈھیر کی لمبائی لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// چیک کرتا ہے کہ اگر بائنری کا ڈھیر خالی ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// بائنری ڈھیر کو صاف کرتا ہے ، حذف شدہ عناصر پر دوبارہ چلنے والا واپس کرتا ہے۔
    ///
    /// عناصر کو من مانی ترتیب میں ہٹا دیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ثنائی کے ڈھیر سے تمام اشیاء گرائیں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// ہول سلائس میں ایک سوراخ کی نمائندگی کرتا ہے ، یعنی جائز قدر کے بغیر ایک اشاریہ (کیونکہ اس سے نقل یا نقل تیار کیا گیا تھا)۔
///
/// ڈراپ میں ، `Hole` سوراخ کی پوزیشن کو اس قدر سے بھر کر سلائس کو بحال کرے گا جو اصل میں ہٹا دیا گیا تھا۔
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// انڈیکس `pos` پر نیا `Hole` بنائیں۔
    ///
    /// غیر محفوظ ہونے کی وجہ سے کہ پوس ڈیٹا سلائس میں ہونا ضروری ہے۔
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // سیف: پوز سلائس کے اندر ہونا چاہئے
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// خارج کردہ عنصر کا حوالہ لوٹاتا ہے۔
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` پر عنصر کا حوالہ لوٹاتا ہے۔
    ///
    /// غیر محفوظ ہونے کی وجہ سے انڈیکس ڈیٹا سلائس میں ہونا چاہئے اور اس کے برابر نہیں ہونا چاہئے۔
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// سوراخ کو نئے مقام پر منتقل کریں
    ///
    /// غیر محفوظ ہونے کی وجہ سے انڈیکس ڈیٹا سلائس میں ہونا چاہئے اور اس کے برابر نہیں ہونا چاہئے۔
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // پھر سوراخ بھریں
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` کے عناصر پر ایک تعطیر کرنے والا۔
///
/// یہ `struct` [`BinaryHeap::iter()`] کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` کے حق میں ہٹائیں
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` کے عناصر پر ایک ملکیت رکھنے والا۔
///
/// یہ `struct` [`BinaryHeap::into_iter()`] (`IntoIterator` trait کے ذریعہ فراہم کردہ) کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// ایک `BinaryHeap` کے عناصر پر ایک نالیوں کا چلانے والا۔
///
/// یہ `struct` [`BinaryHeap::drain()`] کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// ایک `BinaryHeap` کے عناصر پر ایک نالیوں کا چلانے والا۔
///
/// یہ `struct` [`BinaryHeap::drain_sorted()`] کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ڈھیر ترتیب میں ڈھیر والے عناصر کو ہٹاتا ہے۔
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` کو `BinaryHeap<T>` میں تبدیل کرتا ہے۔
    ///
    /// یہ تبادلہ جگہ جگہ ہوتا ہے ، اور اس میں *O*(*n*) وقت کی پیچیدگی ہوتی ہے۔
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` کو `Vec<T>` میں تبدیل کرتا ہے۔
    ///
    /// اس تبادلوں میں ڈیٹا کی نقل و حرکت یا مختص کی ضرورت نہیں ہے ، اور اس میں مستقل وقت کی پیچیدگی ہے۔
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ایک کھپت کرنے والا دوبارہ پیدا کرتا ہے ، یعنی وہ ، جو ہر قدر کو صلinaryی ترتیب سے بائنری ڈھیر سے باہر منتقل کرتا ہے۔
    /// اس کو فون کرنے کے بعد ثنائی کے ڈھیر کا استعمال نہیں کیا جاسکتا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // صوابدیدی ترتیب میں 1 ، 2 ، 3 ، 4 پرنٹ کریں
    /// for x in heap.into_iter() {
    ///     // ایکس کی قسم i32 ہے ، &i32 نہیں
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}