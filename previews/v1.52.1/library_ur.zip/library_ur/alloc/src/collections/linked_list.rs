//! ملکیت والے نوڈس کے ساتھ دوگنی سے منسلک فہرست۔
//!
//! `LinkedList` مستقل وقت میں یا تو آخر میں عناصر کو آگے بڑھانا اور پوپ کرنے کی اجازت دیتا ہے۔
//!
//! NOTE: [`Vec`] یا [`VecDeque`] استعمال کرنا تقریبا ہمیشہ بہتر ہے کیونکہ سرنی پر مبنی کنٹینر عام طور پر تیز ، زیادہ میموری سے موثر ہوتے ہیں اور سی پی یو کیشے کا بہتر استعمال کرتے ہیں۔
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// ملکیت والے نوڈس کے ساتھ دوگنی سے منسلک فہرست۔
///
/// `LinkedList` مستقل وقت میں یا تو آخر میں عناصر کو آگے بڑھانا اور پوپ کرنے کی اجازت دیتا ہے۔
///
/// NOTE: `Vec` یا `VecDeque` استعمال کرنا تقریبا ہمیشہ بہتر ہے کیونکہ سرنی پر مبنی کنٹینر عام طور پر تیز ، زیادہ میموری سے موثر ہوتے ہیں اور سی پی یو کیشے کا بہتر استعمال کرتے ہیں۔
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// `LinkedList` کے عناصر پر ایک تعطیر کرنے والا۔
///
/// یہ `struct` [`LinkedList::iter()`] کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` کے حق میں ہٹائیں
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// ایک `LinkedList` کے عناصر پر ایک بدلنے والا دوبارہ چلانے والا۔
///
/// یہ `struct` [`LinkedList::iter_mut()`] کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // ہم یہاں پوری فہرست کے خصوصی طور پر *نہیں* کرتے ہیں ، نوڈ کے `element` کے حوالہ تکرار کے ذریعہ دیا گیا ہے!لہذا اس کا استعمال کرتے وقت محتاط رہیں؛کہلائے جانے والے طریقوں سے آگاہ ہونا ضروری ہے کہ `element` پر ایلیسنگ پوائنٹر ہوسکتے ہیں۔
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// `LinkedList` کے عناصر پر ایک ملکیت رکھنے والا۔
///
/// یہ `struct` [`into_iter`] طریقہ کے ذریعہ [`LinkedList`] پر بنایا گیا ہے (`IntoIterator` trait کے ذریعہ فراہم کردہ)۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// نجی طریقے
impl<T> LinkedList<T> {
    /// دیئے گئے نوڈ کو فہرست کے سامنے والے حصہ میں شامل کرتا ہے۔
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // یہ طریقہ کار اس بات کا خیال رکھتا ہے کہ پورے نوڈس کے لئے تغیر پزیر حوالہ جات نہ بنائے ، تاکہ `element` میں پوائنٹس علیز کرنے کی صداقت برقرار رہے۔
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // `element` کو اوورلیپ کرنے والے نئے تبدیل شدہ (unique!) حوالہ جات نہیں بنانا۔
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// فہرست کے سامنے والے نوڈ کو ہٹاتا اور واپس کرتا ہے۔
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // یہ طریقہ کار اس بات کا خیال رکھتا ہے کہ پورے نوڈس کے لئے تغیر پزیر حوالہ جات نہ بنائے ، تاکہ `element` میں پوائنٹس علیز کرنے کی صداقت برقرار رہے۔
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // `element` کو اوورلیپ کرنے والے نئے تبدیل شدہ (unique!) حوالہ جات نہیں بنانا۔
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// دیئے گئے نوڈ کو فہرست کے پچھلے حصے میں شامل کرتا ہے۔
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // یہ طریقہ کار اس بات کا خیال رکھتا ہے کہ پورے نوڈس کے لئے تغیر پزیر حوالہ جات نہ بنائے ، تاکہ `element` میں پوائنٹس علیز کرنے کی صداقت برقرار رہے۔
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // `element` کو اوورلیپ کرنے والے نئے تبدیل شدہ (unique!) حوالہ جات نہیں بنانا۔
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// فہرست کے پیچھے نوڈ کو ہٹا دیتا ہے اور واپس کرتا ہے۔
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // یہ طریقہ کار اس بات کا خیال رکھتا ہے کہ پورے نوڈس کے لئے تغیر پزیر حوالہ جات نہ بنائے ، تاکہ `element` میں پوائنٹس علیز کرنے کی صداقت برقرار رہے۔
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // `element` کو اوورلیپ کرنے والے نئے تبدیل شدہ (unique!) حوالہ جات نہیں بنانا۔
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// موجودہ فہرست سے مخصوص نوڈ کو جوڑتا ہے۔
    ///
    /// انتباہ: یہ جانچ نہیں کرے گا کہ فراہم کردہ نوڈ موجودہ فہرست سے تعلق رکھتا ہے۔
    ///
    /// یہ طریقہ کار اس بات کا خیال رکھتا ہے کہ `element` کے لئے تغیر پزیر حوالہ جات نہ بنائے ، الیاس پوائنٹرز کی صداقت کو برقرار رکھنے کے ل.۔
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // یہ اب ہمارا ہے ، ہم ایک &mut تشکیل دے سکتے ہیں۔

        // `element` کو اوورلیپ کرنے والے نئے تبدیل شدہ (unique!) حوالہ جات نہیں بنانا۔
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // یہ نوڈ ہیڈ نوڈ ہے
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // یہ نوڈ دم نوڈ ہے
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// موجودہ نوڈس کے درمیان نوڈس کا ایک سلسلہ تقسیم کرتا ہے۔
    ///
    /// انتباہ: یہ چیک نہیں کرے گا کہ فراہم کردہ نوڈ دو موجودہ فہرستوں سے ہے۔
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // یہ طریقہ کار اس بات کا خیال رکھتا ہے کہ ایک ہی وقت میں پورے نوڈس کے متعدد متغیر حوالہ جات نہ بنائے ، تاکہ `element` میں پوائنٹس علیز کرنے کی صداقت برقرار رہے۔
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// نوڈس کی سیریز کے بطور منسلک فہرست سے تمام نوڈس کو الگ کردیں۔
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // اسپلٹ نوڈ دوسرے حصے کا نیا سر نوڈ ہے
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // دوسرے حصے کے ہیڈ پی ٹی آر کو درست کریں
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // اسپلٹ نوڈ پہلے حصے کا نیا دم نوڈ ہے اور دوسرے حصے کے سر کا مالک ہے۔
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // پہلے حصے کی دم ptr درست کریں
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// ایک خالی `LinkedList<T>` بناتا ہے۔
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// ایک خالی `LinkedList` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// `other` سے تمام عناصر کو فہرست کے اختتام تک لے جاتا ہے۔
    ///
    /// یہ `other` کے تمام نوڈس کو دوبارہ استعمال کرتا ہے اور انہیں `self` میں منتقل کرتا ہے۔
    /// اس کارروائی کے بعد ، `other` خالی ہوجاتا ہے۔
    ///
    /// اس آپریشن کو *O*(1) وقت اور *O*(1) میموری میں حساب کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` یہاں ٹھیک ہے کیونکہ ہمارے پاس دونوں فہرستوں کی پوری طرح رسائی حاصل ہے۔
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// `other` سے تمام عناصر کو فہرست کے آغاز تک لے جاتا ہے۔
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` یہاں ٹھیک ہے کیونکہ ہمارے پاس دونوں فہرستوں کی پوری طرح رسائی حاصل ہے۔
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// ایک فارورڈ ریڈیٹر فراہم کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// متغیر حوالہ جات کے ساتھ ایک فارورڈ ایریٹر فراہم کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// سامنے عنصر میں ایک کرسر فراہم کرتا ہے۔
    ///
    /// اگر فہرست خالی ہے تو کرسر "ghost" نون عنصر کی طرف اشارہ کررہا ہے۔
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// سامنے عنصر میں ترمیمی کارروائیوں کے ساتھ ایک کرسر فراہم کرتا ہے۔
    ///
    /// اگر فہرست خالی ہے تو کرسر "ghost" نون عنصر کی طرف اشارہ کررہا ہے۔
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// پچھلے عنصر پر کرسر فراہم کرتا ہے۔
    ///
    /// اگر فہرست خالی ہے تو کرسر "ghost" نون عنصر کی طرف اشارہ کررہا ہے۔
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// پچھلے عنصر میں ترمیمی کارروائیوں کے ساتھ ایک کرسر فراہم کرتا ہے۔
    ///
    /// اگر فہرست خالی ہے تو کرسر "ghost" نون عنصر کی طرف اشارہ کررہا ہے۔
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// اگر X01 خالی ہے تو `true` لوٹاتا ہے۔
    ///
    /// اس آپریشن کی گنتی *O*(1) وقت میں کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` کی لمبائی لوٹاتا ہے۔
    ///
    /// اس آپریشن کی گنتی *O*(1) وقت میں کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` سے تمام عناصر کو ہٹاتا ہے۔
    ///
    /// اس آپریشن کی گنتی *O*(*n*) وقت میں کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// اگر `LinkedList` میں دی گئی قدر کے برابر عنصر موجود ہو تو `true` واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// فرنٹ عنصر کا حوالہ فراہم کرتا ہے ، یا اگر فہرست خالی ہو تو `None`۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// فرنٹ عنصر ، یا اگر فہرست خالی ہے تو `None` کا تبادلہ خیال فراہم کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// پچھلے عنصر کا حوالہ فراہم کرتا ہے ، یا اگر فہرست خالی ہو تو `None`۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// پچھلے عنصر ، یا اگر فہرست خالی ہے تو `None` کا تغیر پذیر حوالہ فراہم کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// فہرست میں پہلے عنصر شامل کرتا ہے۔
    ///
    /// اس آپریشن کی گنتی *O*(1) وقت میں کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// پہلا عنصر ہٹاتا ہے اور اسے واپس کرتا ہے ، یا اگر فہرست خالی ہو تو `None`۔
    ///
    ///
    /// اس آپریشن کی گنتی *O*(1) وقت میں کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// فہرست کے پچھلے حصے میں عنصر شامل کرتا ہے۔
    ///
    /// اس آپریشن کی گنتی *O*(1) وقت میں کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// فہرست سے آخری عنصر کو ہٹا دیتا ہے اور اسے واپس کرتا ہے ، یا اگر یہ خالی ہے تو `None`۔
    ///
    ///
    /// اس آپریشن کی گنتی *O*(1) وقت میں کرنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// دیئے گئے انڈیکس میں فہرست کو دو میں تقسیم کرتا ہے۔
    /// انڈکس سمیت دیئے گئے انڈیکس کے بعد سب کچھ لوٹاتا ہے۔
    ///
    /// اس آپریشن کی گنتی *O*(*n*) وقت میں کرنا چاہئے۔
    ///
    /// # Panics
    ///
    /// Panics اگر `at > len` ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // ذیل میں ، ہم the i-1 eitherth نوڈ کی طرف تکرار کرتے ہیں ، یا تو شروع سے یا اختتام پر ، اس پر منحصر ہے جس میں تیز تر ہوگا۔
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() (جو ایک نیا ڈھانچہ تیار کرتا ہے) کا استعمال کرتے ہوئے اچٹیں لگانے کے بجائے ، ہم دستی طور پر اچھالتے ہیں تاکہ ہم اسکیپ کے نفاذ کی تفصیلات پر انحصار کیے بغیر ہیڈ فیلڈ تک رسائی حاصل کرسکیں۔
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // آخر سے شروع کرنا ہی بہتر ہے
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// دیئے گئے انڈیکس میں عنصر کو ہٹا دیتا ہے اور اسے لوٹاتا ہے۔
    ///
    /// اس آپریشن کی گنتی *O*(*n*) وقت میں کرنا چاہئے۔
    ///
    /// # Panics
    /// Panics اگر>=لین پر
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // نیچے ، ہم دیئے گئے انڈیکس میں نوڈ کی طرف تکرار کرتے ہیں ، یا تو شروع یا اختتام سے ، جس پر منحصر ہے کہ تیز تر ہوگا۔
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// ایک ایٹریٹر بناتا ہے جو عنصر کو ہٹانا چاہئے اس بات کا تعین کرنے کے لئے بندش کا استعمال کرتا ہے۔
    ///
    /// اگر بندش درست ہو تو ، پھر عنصر کو ہٹا کر برآمد کیا جاتا ہے۔
    /// اگر بندش غلط ہوجاتی ہے تو ، عنصر فہرست میں موجود رہے گا اور آئٹرٹر کے ذریعہ برآمد نہیں ہوگا۔
    ///
    /// نوٹ کریں کہ `drain_filter` آپ کو فلٹر بند ہونے میں ہر عنصر کو تبدیل کرنے دیتا ہے ، قطع نظر اس سے کہ آپ اسے برقرار رکھنے یا اسے ہٹانے کا انتخاب کرتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// فہرست کو شام اور مشکلات میں تقسیم کرنا ، اصل فہرست کو دوبارہ استعمال کرنا:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // ادھار کے معاملات سے گریز کریں۔
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // ذیل میں وہی لوپ جاری رکھیں جو ہم کرتے ہیں۔یہ تب چلتا ہے جب کوئی تباہ کن شخص گھبراتا ہے۔
                // اگر کوئی دوسرا panics اس کا خاتمہ کردے گا۔
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // حاصل کرنے کے لئے ایک باؤنڈ زندگی بھر کی ضرورت ہے
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // حاصل کرنے کے لئے ایک باؤنڈ زندگی بھر کی ضرورت ہے
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // حاصل کرنے کے لئے ایک باؤنڈ زندگی بھر کی ضرورت ہے
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // حاصل کرنے کے لئے ایک باؤنڈ زندگی بھر کی ضرورت ہے
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// ایک `LinkedList` پر کرسر۔
///
/// ایک `Cursor` ایک تکرار کی طرح ہے ، سوائے اس کے کہ وہ آزادانہ طور پر پیچھے اور پیچھے تلاش کرسکتی ہے۔
///
/// کرسر ہمیشہ فہرست میں دو عناصر اور منطقی طور پر سرکلر انداز میں انڈیکس کے مابین آرام کرتے ہیں۔
/// اس کو ایڈجسٹ کرنے کے لئے ، ایک "ghost" غیر عنصر موجود ہے جو فہرست کے سر اور دم کے مابین `None` حاصل کرتا ہے۔
///
///
/// جب تخلیق کیا جاتا ہے تو ، فہرست کے سامنے سے کرسرز شروع ہوجاتے ہیں ، یا اگر فہرست خالی ہو تو "ghost" غیر عنصر۔
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// ترمیمی کارروائیوں کے ساتھ ایک `LinkedList` پر کرسر۔
///
/// ایک `Cursor` ایک ریڈیٹر کی طرح ہے ، سوائے اس کے کہ وہ آزادانہ طور پر پیچھے پیچھے کی تلاش کرسکتا ہے ، اور تکرار کے دوران اس فہرست کو بحفاظت بدل سکتا ہے۔
/// اس کی وجہ یہ ہے کہ اس کے حاصل کردہ حوالہ جات کی زندگی بھر محض فہرست کی بجائے ، اپنی زندگی سے منسلک ہے۔
/// اس کا مطلب ہے کہ کرسر ایک ہی وقت میں ایک سے زیادہ عنصر پیدا نہیں کرسکتے ہیں۔
///
/// کرسر ہمیشہ فہرست میں دو عناصر اور منطقی طور پر سرکلر انداز میں انڈیکس کے مابین آرام کرتے ہیں۔
/// اس کو ایڈجسٹ کرنے کے لئے ، ایک "ghost" غیر عنصر موجود ہے جو فہرست کے سر اور دم کے مابین `None` حاصل کرتا ہے۔
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` میں کرسر پوزیشن انڈیکس لوٹاتا ہے۔
    ///
    /// یہ `None` واپس کرتا ہے اگر کرسر فی الحال "ghost" غیر عنصر کی طرف اشارہ کررہا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// کرسر کو `LinkedList` کے اگلے عنصر میں لے جاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے `LinkedList` کے پہلے عنصر میں لے جائے گا۔
    /// اگر یہ `LinkedList` کے آخری عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے "ghost" غیر عنصر کی طرف لے جائے گا۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ہمارے پاس کوئی موجودہ عنصر نہیں تھا۔کرسر ابتدائی پوزیشن پر بیٹھا تھا اگلا عنصر اس فہرست کا سربراہ ہونا چاہئے
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ہمارے پاس پچھلا عنصر تھا ، تو آئیے اس کے اگلے حصے پر جائیں
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// کرسر کو `LinkedList` کے پچھلے عنصر میں لے جاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے `LinkedList` کے آخری عنصر میں لے جائے گا۔
    /// اگر یہ `LinkedList` کے پہلے عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے "ghost" غیر عنصر کی طرف لے جائے گا۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // موجودہ نہیںہم فہرست کے آغاز پر ہیں۔کوئی بھی پیداوار اور آخر میں کود.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ایک پیشانی ہےاسے حاصل کریں اور پچھلے عنصر پر جائیں۔
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// اس عنصر کا حوالہ واپس کرتا ہے جس کی طرف ابھی کرسر اس طرف اشارہ کررہا ہے۔
    ///
    /// یہ `None` واپس کرتا ہے اگر کرسر فی الحال "ghost" غیر عنصر کی طرف اشارہ کررہا ہے۔
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// اگلے عنصر کا حوالہ لوٹاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `LinkedList` کا پہلا عنصر لوٹاتا ہے۔
    /// اگر یہ `LinkedList` کے آخری عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `None` واپس کرتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// پچھلے عنصر کا حوالہ لوٹاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `LinkedList` کا آخری عنصر لوٹاتا ہے۔
    /// اگر یہ `LinkedList` کے پہلے عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `None` واپس کرتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` میں کرسر پوزیشن انڈیکس لوٹاتا ہے۔
    ///
    /// یہ `None` واپس کرتا ہے اگر کرسر فی الحال "ghost" غیر عنصر کی طرف اشارہ کررہا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// کرسر کو `LinkedList` کے اگلے عنصر میں لے جاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے `LinkedList` کے پہلے عنصر میں لے جائے گا۔
    /// اگر یہ `LinkedList` کے آخری عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے "ghost" غیر عنصر کی طرف لے جائے گا۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ہمارے پاس کوئی موجودہ عنصر نہیں تھا۔کرسر ابتدائی پوزیشن پر بیٹھا تھا اگلا عنصر اس فہرست کا سربراہ ہونا چاہئے
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ہمارے پاس پچھلا عنصر تھا ، تو آئیے اس کے اگلے حصے پر جائیں
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// کرسر کو `LinkedList` کے پچھلے عنصر میں لے جاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے `LinkedList` کے آخری عنصر میں لے جائے گا۔
    /// اگر یہ `LinkedList` کے پہلے عنصر کی طرف اشارہ کررہا ہے تو پھر یہ اسے "ghost" غیر عنصر کی طرف لے جائے گا۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // موجودہ نہیںہم فہرست کے آغاز پر ہیں۔کوئی بھی پیداوار اور آخر میں کود.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ایک پیشانی ہےاسے حاصل کریں اور پچھلے عنصر پر جائیں۔
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// اس عنصر کا حوالہ واپس کرتا ہے جس کی طرف ابھی کرسر اس طرف اشارہ کررہا ہے۔
    ///
    /// یہ `None` واپس کرتا ہے اگر کرسر فی الحال "ghost" غیر عنصر کی طرف اشارہ کررہا ہے۔
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// اگلے عنصر کا حوالہ لوٹاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `LinkedList` کا پہلا عنصر لوٹاتا ہے۔
    /// اگر یہ `LinkedList` کے آخری عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `None` واپس کرتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// پچھلے عنصر کا حوالہ لوٹاتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `LinkedList` کا آخری عنصر لوٹاتا ہے۔
    /// اگر یہ `LinkedList` کے پہلے عنصر کی طرف اشارہ کررہا ہے تو پھر یہ `None` واپس کرتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// موجودہ عنصر کی طرف اشارہ کرنے کیلئے صرف پڑھنے کیلئے ایک کرسر لوٹاتا ہے۔
    ///
    /// واپس شدہ `Cursor` کی زندگی `CursorMut` کی پابند ہے ، جس کا مطلب ہے کہ یہ `CursorMut` کو بہتر نہیں بناسکتا ہے اور یہ کہ `Cursor` `Cursor` کی زندگی بھر منجمد ہے۔
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// اب فہرست میں ترمیم کا عمل

impl<'a, T> CursorMut<'a, T> {
    /// موجودہ عنصر کے بعد `LinkedList` میں ایک نیا عنصر داخل کرتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو نیا عنصر `LinkedList` کے سامنے میں داخل کیا جاتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" نان عنصر کا انڈیکس تبدیل ہوگیا ہے۔
                self.index = self.list.len;
            }
        }
    }

    /// موجودہ عنصر سے پہلے `LinkedList` میں ایک نیا عنصر داخل کرتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو `LinkedList` کے آخر میں نیا عنصر داخل کیا جاتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// موجودہ عنصر کو `LinkedList` سے ہٹا دیتا ہے۔
    ///
    /// عنصر جس کو حذف کیا گیا تھا واپس آ گیا ، اور کرسر کو `LinkedList` میں اگلے عنصر کی طرف اشارہ کرنے کے لئے منتقل کردیا گیا۔
    ///
    ///
    /// اگر کرسر فی الحال "ghost" نون عنصر کی طرف اشارہ کررہا ہے تو پھر کوئی عنصر نہیں ہٹایا جاتا ہے اور `None` واپس ہوجاتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// موجودہ نو عنصر کو `LinkedList` سے لسٹ لسٹ کو خارج نہیں کرتا ہے۔
    ///
    /// جس نوڈ کو حذف کیا گیا تھا اسے ایک نیا `LinkedList` کے طور پر واپس کیا گیا ہے جس میں صرف اس نوڈ ہوتا ہے۔
    /// کرسر کو موجودہ `LinkedList` میں اگلے عنصر کی نشاندہی کرنے کیلئے منتقل کردیا گیا ہے۔
    ///
    /// اگر کرسر فی الحال "ghost" نون عنصر کی طرف اشارہ کررہا ہے تو پھر کوئی عنصر نہیں ہٹایا جاتا ہے اور `None` واپس ہوجاتا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// موجودہ عناصر کے بعد دیئے گئے `LinkedList` سے عناصر داخل کرتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو `LinkedList` کے آغاز پر نئے عناصر داخل کردیئے جاتے ہیں۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" نان عنصر کا انڈیکس تبدیل ہوگیا ہے۔
                self.index = self.list.len;
            }
        }
    }

    /// موجودہ ایک سے پہلے دیئے گئے `LinkedList` سے عناصر داخل کرتا ہے۔
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو `LinkedList` کے آخر میں نئے عنصر داخل کیے جاتے ہیں۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// موجودہ عنصر کے بعد فہرست کو دو حصوں میں تقسیم کردیتا ہے۔
    /// اس سے کرسر کے بعد ہر چیز پر مشتمل ایک نئی فہرست واپس آجائے گی ، اصل فہرست سے پہلے ہر چیز کو برقرار رکھا جائے گا۔
    ///
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر `LinkedList` کے پورے مندرجات کو منتقل کردیا گیا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" غیر عنصر کا انڈیکس 0 میں تبدیل ہو گیا ہے۔
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// موجودہ عنصر سے پہلے فہرست کو دو میں تقسیم کردیتا ہے۔
    /// یہ کرسر سے پہلے ہر چیز پر مشتمل ایک نئی فہرست لوٹائے گی ، اصل فہرست کے بعد ہر چیز کو برقرار رکھے گی۔
    ///
    ///
    /// اگر کرسر "ghost" غیر عنصر کی طرف اشارہ کررہا ہے تو پھر `LinkedList` کے پورے مندرجات کو منتقل کردیا گیا ہے۔
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// لنکڈ لسٹ پر `drain_filter` کال کرکے ایک ایٹریٹر تیار کیا گیا۔
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` الیسیز `element` حوالہ جات کے ساتھ ٹھیک ہے۔
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// قیمت کو بطور اجزا پیدا کرنے والے عناصر کو فہرست میں شامل کریں۔
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// اس بات کو یقینی بنائیں کہ `LinkedList` اور اس کے صرف پڑھنے والے آئٹرس ان کی قسم کے پیرامیٹرز میں ہم خیال ہیں۔
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}