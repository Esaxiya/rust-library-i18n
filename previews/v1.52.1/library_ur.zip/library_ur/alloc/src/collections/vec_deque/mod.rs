//! ایک قابل عمل رنگ بفر کے ساتھ ایک دوہری اختتامی قطار نافذ ہے۔
//!
//! اس قطار میں کنٹینر کے دونوں سروں سے *O*(1) امورٹائزڈ داخل اور ہٹانے ہیں۔
//! اس میں Z O#(1) vector کی طرح اشاریہ سازی بھی ہے۔
//! موجود عناصر کو نقل کے قابل ہونے کی ضرورت نہیں ہے ، اور اگر قطع شدہ قسم بھیجنے کے قابل ہو تو قطار بھیجنے کے قابل ہوگی۔
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3 ، 1
const MINIMUM_CAPACITY: usize = 1; // 2 ، 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // دو کی سب سے بڑی طاقت

/// ایک قابل عمل رنگ بفر کے ساتھ ایک دوہری اختتامی قطار نافذ ہے۔
///
/// اس طرح کے "default" استعمال بطور قطار ، [`push_back`] کو قطار میں شامل کرنے کے لئے ، اور [`pop_front`] کو قطار سے ہٹانے کے لئے استعمال کرنا ہے۔
///
/// [`extend`] اور [`append`] اس طرح سے پیٹھ کی طرف دھکیلتا ہے ، اور `VecDeque` پر تکرار کرنا سامنے سے پیچھے تک جاتا ہے۔
///
/// چونکہ `VecDeque` رنگ رنگ کا بفر ہے ، لہذا ضروری ہے کہ اس کے عناصر یادداشت میں مماثل نہ ہوں۔
/// اگر آپ عناصر کو ایک ہی ٹکڑے کے ل access ، جیسے موثر ترتیب دینے کے ل access رسائی حاصل کرنا چاہتے ہیں تو ، آپ [`make_contiguous`] استعمال کرسکتے ہیں۔
/// یہ `VecDeque` کو گھماتا ہے تاکہ اس کے عنصر لپیٹ نہ پائیں ، اور اب متغیر عنصر کی ترتیب میں ایک تبدیل شدہ ٹکڑا واپس کردیں۔
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // دم اور سر بفر میں پوائنٹر ہیں۔
    // دم ہمیشہ پہلے عنصر کی طرف اشارہ کرتا ہے جسے پڑھا جاسکتا ہے ، ہیڈ ہمیشہ اس طرف اشارہ کرتا ہے جہاں ڈیٹا لکھنا چاہئے۔
    //
    // اگر دم==سر کا بفر خالی ہے۔رنگ بفر کی لمبائی دونوں کے درمیان فاصلے کے طور پر بیان کی گئی ہے۔
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// سلائس میں موجود تمام آئٹموں کے ڈسٹرکٹر کو چلاتا ہے جب گر جاتا ہے (عام طور پر یا غیر منسلک ہونے کے دوران)۔
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] کے لئے ڈراپ استعمال کریں
            ptr::drop_in_place(front);
        }
        // راوییک منتقلی کو سنبھالتا ہے
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// ایک خالی `VecDeque<T>` بناتا ہے۔
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// معمولی طور پر زیادہ آسان
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// معمولی طور پر زیادہ آسان
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // صفر سائز کی اقسام کے ل we ، ہم ہمیشہ زیادہ سے زیادہ صلاحیت پر ہوتے ہیں
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// ایک ٹکڑا میں ptr تبدیل کریں
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// پی ٹی آر کو بدلیں ٹکڑوں میں
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// کسی عنصر کو بفر سے باہر لے جاتا ہے
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// ایک عنصر کو بفر میں لکھتا ہے ، اسے منتقل کرتا ہے۔
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// اگر بفر پوری صلاحیت سے ہو تو `true` لوٹاتا ہے۔
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// دیئے گئے منطقی عنصر انڈیکس کیلئے بنیادی بفر میں انڈیکس لوٹاتا ہے۔
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// دیئے گئے منطقی عنصر انڈکس + ضمیمہ کے لئے بنیادی بفر میں انڈکس کو لوٹاتا ہے۔
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// دیئے گئے منطقی عنصر انڈیکس ، سب ٹہند کے لئے بنیادی بفر میں انڈیکس کو لوٹاتا ہے۔
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src سے dst تک لمبی لمبی میموری کا ایک مسدود بلاک کاپی کرتا ہے
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src سے dst تک لمبی لمبی میموری کا ایک مسدود بلاک کاپی کرتا ہے
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src سے مقصود تک لمبی لمبی میموری کے ل of ریپنگ بلاک کاپی کرتا ہے۔
    /// (abs(dst - src) + لین) cap() سے بڑا نہیں ہونا چاہئے (src اور مقصود کے درمیان زیادہ سے زیادہ ایک مستقل اتپریپنگ خطہ ہونا چاہئے)۔
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src لپیٹ نہیں سکتا ، dst لپیٹ نہیں دیتا ہے
                //
                //        ایس...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src سے پہلے dst ، src لپیٹ نہیں دیتا ، dst لپیٹتا ہے
                //
                //
                //    ایس...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src dst سے پہلے ، src لپیٹ نہیں دیتا ، dst لپیٹ دیتا ہے
                //
                //
                //              ایس...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // src سے پہلے dst ، src لپیٹ ، dst لپیٹ نہیں ہے
                //
                //
                //    .. ایس.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src dst سے پہلے ، src لپیٹ جاتا ہے ، dst لپیٹ نہیں دیتا ہے
                //
                //
                //    .. ایس.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // src ، src لپیٹ ، dst لپیٹ سے پہلے dst
                //
                //
                //    ... ایس.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src dst سے پہلے ، src لپیٹ ، DST لپیٹ
                //
                //
                //    .. ایس..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]۔..ڈی.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// اس حقیقت کو سنبھالنے کے لئے سر اور دم کے حصوں کو فروگس کریں کہ ہم ابھی دوبارہ جگہ لے گئے۔
    /// غیر محفوظ ہے کیونکہ اس میں پرانی_قابلیت پر اعتماد ہے۔
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // رنگ بفر TH کے مختصر ترین پیچیدہ حصے میں منتقل کریں
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // ایک نہیں
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// ایک خالی `VecDeque` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// کم از کم `capacity` عناصر کے لئے خالی جگہ `VecDeque` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 چونکہ رنگ برفر ہمیشہ ایک جگہ خالی چھوڑ دیتا ہے
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// دیئے گئے اشاریہ میں عنصر کا حوالہ فراہم کرتا ہے۔
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// دیئے گئے اشاریہ میں عنصر کا تبادلہ خیال فراہم کرتا ہے۔
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// اشاریہ `i` اور `j` پر عناصر کو تبدیل کرتا ہے۔
    ///
    /// `i` اور `j` برابر ہوسکتا ہے۔
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر انڈیکس حد سے باہر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// دوبارہ اعلان کیے بغیر `VecDeque` کے عناصر کی تعداد لوٹاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// دیئے گئے `VecDeque` میں بالکل `additional` مزید عناصر داخل کرنے کے لئے کم سے کم گنجائش کا ذخیرہ کریں۔
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// نوٹ کریں کہ مختص کرنے والا اس کی درخواست سے کہیں زیادہ جگہ دے سکتا ہے۔
    /// لہذا صلاحیت کو کم سے کم ہونے پر انحصار نہیں کیا جاسکتا ہے۔
    /// اگر future اضافے کی توقع ہے تو [`reserve`] کو ترجیح دیں۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `usize` سے زیادہ بہتی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// دیئے گئے `VecDeque` میں کم سے کم `additional` مزید عناصر داخل کرنے کی گنجائش محفوظ ہے۔
    /// کثرت رائے سے بچنے کے لئے مجموعہ میں مزید جگہ محفوظ ہوسکتی ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `usize` سے زیادہ بہتی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// `additional` مزید عناصر کو دیئے جانے والے `VecDeque<T>` میں داخل کرنے کیلئے کم سے کم گنجائش کو محفوظ کرنے کی کوشش کرتا ہے۔
    ///
    /// `try_reserve_exact` پر کال کرنے کے بعد ، صلاحیت `self.len() + additional` سے زیادہ یا اس کے برابر ہوگی۔
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// نوٹ کریں کہ مختص کرنے والا اس کی درخواست سے کہیں زیادہ جگہ دے سکتا ہے۔
    /// لہذا ، عین مطابق کم سے کم ہونے کی صلاحیت پر انحصار نہیں کیا جاسکتا ہے۔
    /// اگر future اضافے کی توقع ہے تو `reserve` کو ترجیح دیں۔
    ///
    /// # Errors
    ///
    /// اگر صلاحیت `usize` سے زیادہ بہتی ہے ، یا مختص کنندہ نے ناکامی کی اطلاع دی ہے ، تو ایک غلطی واپس کردی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // میموری کو پہلے سے محفوظ کریں ، اگر ہم نہیں کر سکتے تو باہر نکل رہے ہیں
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // اب ہم جانتے ہیں کہ یہ ہمارے پیچیدہ کام کے وسط میں OOM(Out-Of-Memory) نہیں کرسکتا
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // بہت پیچیدہ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// دیئے گئے `VecDeque<T>` میں کم از کم `additional` مزید عناصر داخل کرنے کی گنجائش کو محفوظ کرنے کی کوشش کرتا ہے۔
    /// کثرت رائے سے بچنے کے لئے مجموعہ میں مزید جگہ محفوظ ہوسکتی ہے۔
    /// `try_reserve` پر کال کرنے کے بعد ، صلاحیت `self.len() + additional` سے زیادہ یا اس کے برابر ہوگی۔
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// # Errors
    ///
    /// اگر صلاحیت `usize` سے زیادہ بہتی ہے ، یا مختص کنندہ نے ناکامی کی اطلاع دی ہے ، تو ایک غلطی واپس کردی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // میموری کو پہلے سے محفوظ کریں ، اگر ہم نہیں کر سکتے تو باہر نکل رہے ہیں
    ///     output.try_reserve(data.len())?;
    ///
    ///     // اب ہم جانتے ہیں کہ یہ ہمارے پیچیدہ کام کے بیچ او اوم نہیں کرسکتا
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // بہت پیچیدہ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// زیادہ سے زیادہ `VecDeque` کی صلاحیت کو گھٹا دیتا ہے۔
    ///
    /// یہ لمبائی کے قریب سے نیچے گر جائے گا لیکن مختص کرنے والا ابھی بھی `VecDeque` کو بتا سکتا ہے کہ کچھ اور عناصر کے لئے بھی جگہ ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// `VecDeque` کی گنجائش کو کم باؤنڈ کے ساتھ گھٹا دیتا ہے۔
    ///
    /// گنجائش کم از کم لمبائی اور فراہم کردہ قیمت دونوں کی حد تک ہی باقی رہے گی۔
    ///
    ///
    /// اگر موجودہ صلاحیت کم حد سے کم ہے تو ، یہ کوئی آپٹ نہیں ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // ہمیں اتنے بہاو کی فکر کرنے کی ضرورت نہیں ہے کیونکہ نہ تو `self.len()` اور نہ ہی `usize::MAX` کبھی بھی `usize::MAX` ہوسکتا ہے۔
        // چونکہ رنگ برفر ہمیشہ ایک جگہ خالی چھوڑ دیتا ہے۔
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // دلچسپی کے تین معاملات ہیں:
            //   تمام عناصر مطلوبہ حدود سے باہر ہیں عنصر متضاد ہیں اور سر مطلوبہ حد سے باہر ہے عنصر متضاد ہیں ، اور دم مطلوبہ حد سے باہر ہے
            //
            //
            // دوسرے تمام اوقات میں ، عنصر کے مقامات متاثر نہیں ہوتے ہیں۔
            //
            // اشارہ کرتا ہے کہ سر میں موجود عناصر کو منتقل ہونا چاہئے۔
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // عناصر کو مطلوبہ حدود سے ہٹائیں (ہدف_کیپ کے بعد پوزیشن)
            if self.tail >= target_cap && head_outside {
                // ویں
                //   [. . . . . . . . o o o o o o o . ]
                //    ویں
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // ویں
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// پہلے `len` عناصر کو برقرار رکھتے ہوئے اور باقی کو چھوڑ کر ، `VecDeque` کو مختصر کرتا ہے۔
    ///
    ///
    /// اگر `len` `VecDeque` کی موجودہ لمبائی سے زیادہ ہے تو ، اس کا کوئی اثر نہیں ہوگا۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// سلائس میں موجود تمام آئٹموں کے ڈسٹرکٹر کو چلاتا ہے جب گر جاتا ہے (عام طور پر یا غیر منسلک ہونے کے دوران)۔
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // محفوظ کیونکہ:
        //
        // * `drop_in_place` کو جو بھی سلائس منظور کی گئی ہے وہ درست ہے۔دوسرے کیس میں `len <= front.len()` ہے اور `len > self.len()` پر واپس آنے سے پہلے معاملے میں `begin <= back.len()` کو یقینی بنایا جاتا ہے
        //
        // * ایکس ڈے ایکس کو فون کرنے سے پہلے ویک ڈیک کے سربراہ کو منتقل کردیا گیا ہے ، لہذا اگر `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // اس بات کو یقینی بنائیں کہ دوسرا نصف گرا دیا جاتا ہے یہاں تک کہ جب پہلا panics میں ایک ڈسٹرکٹر۔
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// اگلے سے اگلے والا پیچھے کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// ایک اگلے سے پیچھے والے آئٹرٹر کو لوٹاتا ہے جو بدل پزیر حوالہ جات واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // حفاظت: اندرونی `IterMut` حفاظتی حملہ آور قائم ہے کیونکہ
        // `ring` ہم تخلیق زندگی بھر کے لئے قابل تعزیر کا ٹکڑا ہے '_۔
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// سلائسس کا ایک جوڑا واپس کرتا ہے جس میں ، `VecDeque` کے مندرجات پر ، ترتیب دیا گیا ہے۔
    ///
    /// اگر [`make_contiguous`] کو پہلے بھی بلایا گیا تھا تو ، `VecDeque` کے تمام عناصر پہلی سلائس میں ہوں گے اور دوسری سلائس خالی ہوگی۔
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// سلائسس کا ایک جوڑا واپس کرتا ہے جس میں ، `VecDeque` کے مندرجات پر ، ترتیب دیا گیا ہے۔
    ///
    /// اگر [`make_contiguous`] کو پہلے بھی بلایا گیا تھا تو ، `VecDeque` کے تمام عناصر پہلی سلائس میں ہوں گے اور دوسری سلائس خالی ہوگی۔
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` میں عناصر کی تعداد لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// اگر X01 خالی ہے تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// ایک آئٹرٹر بناتا ہے جو `VecDeque` میں مخصوص حدود کا احاطہ کرتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نقطہ اغاز نقطہ اختتامی نقطہ سے زیادہ ہے یا اگر اختتامی نقطہ vector کی لمبائی سے زیادہ ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // پوری رینج میں تمام مشمولات کا احاطہ کیا گیا ہے
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // ہمارے پاس &self میں مشترکہ حوالہ Iter کے '_ میں برقرار ہے۔
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// ایک آئٹرٹر بناتا ہے جو `VecDeque` میں متعین بدلنے والی حد کو کور کرتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نقطہ اغاز نقطہ اختتامی نقطہ سے زیادہ ہے یا اگر اختتامی نقطہ vector کی لمبائی سے زیادہ ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // پوری رینج میں تمام مشمولات کا احاطہ کیا گیا ہے
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // حفاظت: اندرونی `IterMut` حفاظتی حملہ آور قائم ہے کیونکہ
        // `ring` ہم تخلیق زندگی بھر کے لئے قابل تعزیر کا ٹکڑا ہے '_۔
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// ایک ڈریننگ ایریٹر بناتا ہے جو `VecDeque` میں مخصوص حد کو ہٹا دیتا ہے اور ہٹائے ہوئے آئٹمز کو برآمد کرتا ہے۔
    ///
    /// نوٹ 1: عنصر کی حد ہٹا دی جاتی ہے یہاں تک کہ اگر آئٹرٹر آخر تک استعمال نہیں کیا جاتا ہے۔
    ///
    /// نوٹ 2: یہ غیر متعین ہے کہ اگر `Drain` قدر کو گرایا نہیں گیا ، لیکن کتنے عناصر کو وقوف سے ہٹا دیا گیا ، لیکن اس کے ذریعہ لیا گیا قرض ختم ہوجاتا ہے (جیسے ، X01 ایکس کی وجہ سے)۔
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر نقطہ اغاز نقطہ اختتامی نقطہ سے زیادہ ہے یا اگر اختتامی نقطہ vector کی لمبائی سے زیادہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // پوری رینج سے تمام مشمولات صاف ہوجاتے ہیں
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // میموری کی حفاظت
        //
        // جب Drain پہلی بار تشکیل دیا گیا ہے تو ، ماخذ کی قابلیت کو کم کرنے کے لئے یہ یقینی بنایا گیا ہے کہ اگر Drain کا ڈسٹرکٹر کبھی بھی چلانے کے لئے تیار نہیں ہوتا ہے تو بلاامتیاز یا منتقل کردہ عناصر بالکل بھی قابل رسائی نہیں ہیں۔
        //
        //
        // Drain ptr::read کو نکالنے کے لئے اقدار کو ختم کرے گا۔
        // جب ختم ہوجائے تو ، باقی اعداد و شمار کو واپس چھپانے کے ل cop کاپی کریں گے ، اور head/tail اقدار کو صحیح طریقے سے بحال کیا جائے گا۔
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // مستحق عناصر کو تین حصوں میں تقسیم کیا گیا ہے۔
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail؛H= self.head؛t=drain_tail؛h=drain_head
        //
        // ہم drain_tail کو self.head کے بطور ، اور drain_head اور self.head بالترتیب Drain پر after_tail اور after_head کے طور پر اسٹور کرتے ہیں۔
        // اس سے موثر اشارے کو بھی چھوٹا جاتا ہے تاکہ اگر Drain لیک ہوجائے تو ، ہم drain کے آغاز کے بعد ممکنہ طور پر منتقل کی جانے والی اقدار کو بھول گئے ہیں۔
        //
        //
        //        T ویں H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain کے آغاز کے بعد کی اقدار کے بارے میں جب تک drain مکمل نہ ہوجائے اور Drain ڈسٹرکٹر چل نہ سکے۔
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // اہم طور پر ، ہم صرف `self` سے یہاں مشترکہ حوالہ جات تخلیق کرتے ہیں اور اس سے پڑھتے ہیں۔
                // ہم `self` کو نہیں لکھتے ہیں اور نہ ہی کسی تغیر پزیر حوالہ کی حمایت کرتے ہیں۔
                // لہذا ، `deque` کے لئے ، جو اوپر ہم نے اوپر تیار کیا ہے ، وہ درست ہے۔
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// تمام اقدار کو ختم کرتے ہوئے ، `VecDeque` کو صاف کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// اگر `VecDeque` میں دی گئی قدر کے برابر عنصر موجود ہو تو `true` واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// اگر `VecDeque` خالی ہے تو سامنے عنصر ، یا `None` کا حوالہ فراہم کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// فرنٹ عنصر ، یا اگر X01 خالی ہے تو `None` کا تغیر پذیر حوالہ فراہم کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// اگر `VecDeque` خالی ہے تو ، بیک عنصر ، یا `None` کا حوالہ فراہم کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// اگر `VecDeque` خالی ہے تو ، بیک عنصر ، یا `None` کے لئے ایک متغیر حوالہ فراہم کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// پہلا عنصر ہٹاتا ہے اور اسے واپس کرتا ہے ، یا اگر X01 خالی ہے تو `None`۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` سے آخری عنصر کو ہٹا دیتا ہے اور اسے واپس کرتا ہے ، یا اگر یہ خالی ہے تو `None`۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// ایک عنصر کو `VecDeque` میں تیار کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` کے پچھلے حصے میں عنصر شامل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: کیا ہمیں `head == 0` کا مطلب سمجھنا چاہئے؟
        // کہ `self` ملحق ہے؟
        self.tail <= self.head
    }

    /// `VecDeque` میں کہیں سے بھی عنصر کو ہٹاتا ہے اور اسے پہلے عنصر کی جگہ لے کر واپس کرتا ہے۔
    ///
    ///
    /// یہ آرڈرنگ کو محفوظ نہیں رکھتا ہے ، لیکن *O*(1) ہے۔
    ///
    /// اگر X01 ایکس حد سے باہر ہے تو `None` لوٹاتا ہے۔
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` میں کہیں سے بھی عنصر کو ہٹاتا ہے اور اسے آخری عنصر کی جگہ لے کر واپس کرتا ہے۔
    ///
    ///
    /// یہ آرڈرنگ کو محفوظ نہیں رکھتا ہے ، لیکن *O*(1) ہے۔
    ///
    /// اگر X01 ایکس حد سے باہر ہے تو `None` لوٹاتا ہے۔
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` میں ایک عنصر کو `VecDeque` میں داخل کرتا ہے ، جو تمام عناصر کو اشارے کے ساتھ `index` سے زیادہ کی سمت پیچھے کی طرف منتقل کرتا ہے۔
    ///
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر `index` `VecDeque` کی لمبائی سے زیادہ ہے
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // رنگین بفر میں عناصر کی کم سے کم تعداد میں منتقل کریں اور دیئے گئے آبجیکٹ کو داخل کریں
        //
        // زیادہ سے زیادہ len/2 میں ، 1 عناصر کو منتقل کیا جائے گا۔ O(min(n, n-i))
        //
        // تین اہم معاملات ہیں۔
        //  عنصر متفق ہیں
        //      - خصوصی معاملہ جب دم 0 ہوتا ہے تو عنصر متضاد ہوتے ہیں اور ڈالیں دم کے حصے میں ہوتے ہیں عنصر متضاد ہوتے ہیں اور داخل سر کے حصے میں ہوتا ہے
        //
        //
        // ان میں سے ہر ایک کے لئے دو اور صورتیں ہیں۔
        //  ڈالنا دم سے قریب ہے داخل سر سے قریب ہے
        //
        // کلیدی: H ، self.head
        //      T ، self.tail o ، درست عنصر I ، اضافے کا عنصر A ، عنصر جو اضافی نقطہ M کے بعد ہونا چاہئے ، اشارہ کرتا ہے عنصر کو منتقل کیا گیا تھا
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Aoooooo......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // ملحق ، دم کے قریب داخل کریں:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           ویں
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // ملحق ، دم اور دم کے قریب ڈالیں 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       ایم ایم

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // پہلے ہی دم منتقل کردی گئی ہے ، لہذا ہم صرف `index - 1` عناصر کاپی کرتے ہیں۔
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ملحق ، سر کے قریب داخل کریں:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             ویں
                    //      [. . . o o o o I A o o . . . . .]
                    //                       ایم ایم ایم

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // متضاد ، دم کے قریب ڈالیں ، دم سیکشن:
                    //
                    //                   ایچ ٹی آئی
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // متضاد ، سر کے قریب ڈالیں ، دم سیکشن:
                    //
                    //           ایچ ٹی آئی
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       ایم ایم ایم ایم

                    // نئے سر تک عناصر کاپی کریں
                    self.copy(1, 0, self.head);

                    // آخری عنصر کو بفر کے نیچے خالی جگہ پر کاپی کریں
                    self.copy(0, self.cap() - 1, 1);

                    // عناصر کو idx سے آگے کی طرف منتقل کریں not عنصر کو شامل نہیں
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // متضاد ، داخل دم ، سر کے حصے کے قریب ہے اور اندرونی بفر میں انڈیکس صفر پر ہے۔
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               ایم ایم ایم

                    // نئی دم تک عناصر کاپی کریں
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // آخری عنصر کو بفر کے نیچے خالی جگہ پر کاپی کریں
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // متضاد ، دم کے قریب ڈالیں ، سر کے حصے:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       ایم ایم ایم ایم ایم ایم

                    // نئی دم تک عناصر کاپی کریں
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // آخری عنصر کو بفر کے نیچے خالی جگہ پر کاپی کریں
                    self.copy(self.cap() - 1, 0, 1);

                    // عناصر کو idx-1 سے آگے کی طرف منتقل کریں not عنصر کو شامل نہیں
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // متضاد ، سر کے قریب ، سر کے حصے میں داخل کریں:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 ایم ایم ایم

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // دم کو تبدیل کردیا گیا ہے لہذا ہمیں دوبارہ گنتی کرنے کی ضرورت ہے
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `index` پر عنصر کو `VecDeque` سے ہٹاتا اور واپس کرتا ہے۔
    /// جو بھی اختتام ہٹانے کے نقطہ کے قریب ہے اسے کمرے میں منتقل کردیا جائے گا ، اور تمام متاثرہ عناصر کو نئی جگہوں پر منتقل کردیا جائے گا۔
    ///
    /// اگر X01 ایکس حد سے باہر ہے تو `None` لوٹاتا ہے۔
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // تین اہم معاملات ہیں۔
        //  عنصر متضاد ہوتے ہیں عنصر متضاد ہوتے ہیں اور ہٹانا دم کے حصے میں ہوتا ہے عنصر متضاد ہوتے ہیں اور ہٹانے سر کے حصے میں ہوتا ہے
        //
        //      - خاص صورت جب عناصر تکنیکی لحاظ سے موافق ہوں ، لیکن self.head =0
        //
        // ان میں سے ہر ایک کے لئے دو اور صورتیں ہیں۔
        //  ڈالنا دم سے قریب ہے داخل سر سے قریب ہے
        //
        // کلیدی: H ، self.head
        //      T، self.tail o، मान्य عنصر x، عنصر کو R کے خاتمے کے لئے نشان زد کیا گیا، عنصر کی نشاندہی کرتا ہے جس کو ہٹایا جارہا ہے M، اشارہ کرتا ہے عنصر کو منتقل کردیا گیا تھا
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // ملحق ، دم کے قریب سے دور کریں:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               ویں
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ملحق ، سر کے قریب ہٹائیں:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             ویں
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // متضاد ، دم سے قریب ، دم کے حصے کو ہٹا دیں:
                    //
                    //                   ایچ ٹی آر
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // متضاد ، سر کے قریب ، سر کے حصے کو ہٹا دیں:
                    //
                    //               آر ایچ ٹی
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // متضاد ، سر کے قریب ، دم کے حصے کو ہٹا دیں:
                    //
                    //             ایچ ٹی آر
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       ایم ایم ایم ایم
                    //
                    // یا نیم تنازعہ ، سر کے ساتھ اگلے ، دم کے حصے کو ہٹا دیں:
                    //
                    //       ایچ ٹی آر
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         ویں
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // دم کے حصے میں عناصر کھینچنا
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // زیر بہاؤ کو روکتا ہے۔
                    if self.head != 0 {
                        // پہلے عنصر کو خالی جگہ پر کاپی کریں
                        self.copy(self.cap() - 1, 0, 1);

                        // سر کے حصے میں عناصر کو پیچھے کی طرف منتقل کریں
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // متضاد ، دم کے قریب ، سر کے حصے کو ہٹا دیں:
                    //
                    //           آر ایچ ٹی
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       ایم ایم ایم ایم ایم

                    // idx تک عناصر بنائیں
                    self.copy(1, 0, idx);

                    // آخری عنصر کو خالی جگہ میں کاپی کریں
                    self.copy(0, self.cap() - 1, 1);

                    // آخری کو چھوڑ کر عناصر کو دم سے آگے کی طرف منتقل کریں
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// دیئے گئے انڈیکس میں `VecDeque` کو دو میں تقسیم کرتا ہے۔
    ///
    /// نیا مختص شدہ `VecDeque` واپس کرتا ہے۔
    /// `self` `[0, at)` عناصر پر مشتمل ہے ، اور واپس شدہ `VecDeque` میں `[at, len)` عناصر شامل ہیں۔
    ///
    /// نوٹ کریں کہ `self` کی قابلیت تبدیل نہیں ہوتی ہے۔
    ///
    /// اشاریہ 0 پر عنصر قطار کا اگلا حصہ ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر `at > len` ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` پہلے نصف میں جھوٹ
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // صرف دوسرے نصف حصے میں سے تمام لے لو.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` دوسرے نصف حصے میں ہے ، پہلے نصف حصے میں جو عناصر ہم نے چھوڑے ان میں عنصر پیدا کرنے کی ضرورت ہے۔
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // صفائی جہاں بفروں کے اختتام ہیں
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` کے تمام عناصر کو `self` میں منتقل کرتا ہے ، `other` کو خالی چھوڑ دیتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر خود میں عناصر کی نئی تعداد ایک `usize` کو بہا دیتی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // بولی impl
        self.extend(other.drain(..));
    }

    /// پیش گوئی کے ذریعہ مخصوص عناصر کو برقرار رکھتا ہے۔
    ///
    /// دوسرے لفظوں میں ، `e` کے تمام عناصر کو حذف کریں تاکہ `f(&e)` جھوٹے ہو۔
    /// یہ طریقہ کار میں کام کرتا ہے ، ہر عنصر کو ایک بار اصل ترتیب میں ملاحظہ کرتا ہے ، اور برقرار عناصر کی ترتیب کو محفوظ رکھتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// عین مطابق آرڈر بیرونی حالت کو باخبر رکھنے کے لئے کارآمد ہوسکتا ہے ، جیسے ایک انڈیکس کی طرح۔
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // یہ panic یا اسقاط ترک کر سکتا ہے
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // بفر سائز دوگنا کریں۔
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` کو جگہ جگہ تبدیل کریں تاکہ `len()` `new_len` کے برابر ہو ، یا تو پیچھے سے اضافی عنصر نکال کر یا `generator` کو پیٹھ پر کال کرکے پیدا کردہ عناصر کو شامل کرکے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// اس وقاق کے اندرونی ذخیرہ کو دوبارہ ترتیب دیتا ہے لہذا یہ ایک ماب .ا ٹکڑا ہے ، جو اس کے بعد واپس آ جاتا ہے۔
    ///
    /// یہ طریقہ مختص نہیں کرتا ہے اور داخل کردہ عناصر کی ترتیب کو تبدیل نہیں کرتا ہے۔چونکہ یہ ایک تبدیل شدہ سلائس کو لوٹاتا ہے ، اس کو کسی وقیع ترتیب دینے کے لئے استعمال کیا جاسکتا ہے۔
    ///
    /// ایک بار اندرونی اسٹوریج متناسب ہوجانے کے بعد ، [`as_slices`] اور [`as_mut_slices`] طریقوں نے `VecDeque` کے پورے مندرجات کو ایک ہی ٹکڑے میں واپس کردیں گے۔
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// کسی وقیع کے مشمولات کی ترتیب
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // وقفے کی چھانٹ رہا ہے
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // اس کو الٹ ترتیب میں چھانٹ رہا ہے
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// مسلسل ٹکڑوں تک ناقابل استعمال رسائی حاصل کرنا۔
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // اب ہم اس بات کا یقین کر سکتے ہیں کہ `slice` میں deque کے تمام عناصر شامل ہیں ، جبکہ ابھی بھی `buf` تک ناقابل تبدیلی رسائی ہے۔
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // ایک ہی وقت میں دم کی کاپی کرنے کے لئے کافی خالی جگہ ہے ، اس کا مطلب یہ ہے کہ ہم پہلے سر کو پیچھے کی طرف منتقل کرتے ہیں ، اور پھر دم کو صحیح مقام پر کاپی کرتے ہیں۔
            //
            //
            // منجانب: DEFGH .... ABC
            // منجانب: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: ہم فی الحال غور نہیں کرتے ہیں .... ABCDEFGH
            // مماثل ہونا کیونکہ اس معاملے میں `head` `0` ہوگا۔
            // اگرچہ ہم شاید اسے تبدیل کرنا چاہتے ہیں یہ معمولی بات نہیں ہے کیونکہ کچھ جگہوں سے توقع ہے کہ `is_contiguous` کا مطلب یہ ہوگا کہ ہم صرف `buf[tail..head]` کا استعمال کرکے ٹکڑے ٹکڑے کر سکتے ہیں۔
            //
            //

            // ایک ہی بار میں سر کی کاپی کرنے کے لئے کافی خالی جگہ ہے ، اس کا مطلب یہ ہے کہ ہم پہلے دم آگے کی طرف منتقل کریں ، اور پھر سر کو صحیح مقام پر کاپی کریں۔
            //
            //
            // منجانب: FGH .... ABCDE
            // تک: ... ABCDEFGH۔
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // فری سر اور دم دونوں سے چھوٹا ہے ، اس کا مطلب ہے کہ ہمیں دم اور سر کو آہستہ آہستہ "swap" کرنا پڑے گا۔
            //
            //
            // منجانب: EFGHI ... ABCD یا HIJK.ABCDEFG
            // منجانب: ABCDEFGHI ... یا ABCDEFGHIJK۔
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // عمومی پریشانی اس جی جی جے کے ایل ایم کی طرح دکھائی دیتی ہے ... اے بی سی ڈی ایف ، کسی بھی تبادلوں سے پہلے اے بی سی ڈی ایف ایف ... جی ایچ جے کے ایل ، تبادلوں کے ایک پاس کے بعد اے بی سی ڈی ایف جی ایچ جے ایم ... کے ایل ، اس وقت تک تبدیل ہوجاتا ہے جب تک کہ ٹیپ اسٹور تک بائیں طرف نہیں پہنچتا ہے
                //                  - پھر الگورتھم کو ایک نئے (smaller) اسٹور کے ساتھ دوبارہ اسٹارٹ کریں بعض اوقات عارضی اسٹور پہنچ جاتا ہے جب دائیں edge بفر کے اختتام پر ہوتا ہے ، اس کا مطلب ہے کہ ہم نے کم سویپوں کے ساتھ صحیح آرڈر مارا ہے!
                //
                // E.g
                // EF..ABCD ABCDEF .. ، چار تبدیلیاں صرف کرنے کے بعد ہم نے ختم کیا
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// ڈبل ختم ہونے والی قطار `mid` جگہیں بائیں طرف گھماتی ہے۔
    ///
    /// Equivalently,
    /// - آئٹم `mid` کو پہلی پوزیشن میں گھماتا ہے۔
    /// - پہلے `mid` آئٹمز کو پپس کرتا ہے اور انہیں آخر تک دھکا دیتا ہے۔
    /// - `len() - mid` مقامات کو دائیں طرف گھماتا ہے۔
    ///
    /// # Panics
    ///
    /// اگر `mid` `len()` سے زیادہ ہے۔
    /// نوٹ کریں کہ `mid == len()` _not_ panic کرتا ہے اور یہ کوئی آپشن نہیں ہے۔
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` وقت اور کوئی اضافی جگہ نہیں لیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// ڈبل ختم ہونے والی قطار `k` جگہوں کو دائیں طرف گھماتی ہے۔
    ///
    /// Equivalently,
    /// - پہلی شے کو `k` کی پوزیشن میں گھماتا ہے۔
    /// - آخری `k` آئٹمز کو پپس کرتا ہے اور ان کو سامنے کی طرف دھکیل دیتا ہے۔
    /// - بائیں طرف `len() - k` جگہیں گھوماتا ہے۔
    ///
    /// # Panics
    ///
    /// اگر `k` `len()` سے زیادہ ہے۔
    /// نوٹ کریں کہ `k == len()` _not_ panic کرتا ہے اور یہ کوئی آپشن نہیں ہے۔
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` وقت اور کوئی اضافی جگہ نہیں لیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // محفوظ کریں: مندرجہ ذیل دو طریقوں میں ضرورت ہوتی ہے کہ گردش کی مقدار
    // وصال کی لمبائی سے بھی کم ہو۔
    //
    // `wrap_copy` اس کیلئے `min(x, cap() - x) + copy_len <= cap()` کی ضرورت ہوتی ہے ، لیکن `min` کے مقابلے میں کبھی بھی X کی پرواہ کیے بغیر ، آدھی صلاحیت سے زیادہ کبھی نہیں ہوتا ہے ، لہذا یہاں فون کرنا مناسب ہے کیوں کہ ہم لمبائی سے بھی کم ایسی کسی چیز کے ساتھ فون کر رہے ہیں ، جو کبھی بھی نصف سے بھی زیادہ نہیں ہے۔
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// بائنری کسی مخصوص عنصر کے لئے اس ترتیب شدہ `VecDeque` کو تلاش کرتا ہے۔
    ///
    /// اگر قیمت مل جاتی ہے تو [`Result::Ok`] واپس کردیتا ہے ، جس میں ملاپ والے عنصر کی اشاریہ ہوتا ہے۔
    /// اگر وہاں متعدد میچز ہیں ، تو میچوں میں سے ایک بھی واپس ہوسکتا ہے۔
    /// اگر قیمت نہیں مل پاتی ہے تو [`Result::Err`] واپس کردیتا ہے ، جس میں انڈکس ہوتا ہے جہاں ترتیب والا نظم برقرار رکھتے ہوئے ایک مماثل عنصر داخل کیا جاسکتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// چار عناصر کا ایک سلسلہ تلاش کریں۔
    /// پہلا پایا جاتا ہے ، جس کی ایک منفرد حیثیت سے پوزیشن ہوتی ہے۔دوسرا اور تیسرا نہیں ملا۔چوتھا `[1, 4]` میں کسی بھی پوزیشن سے مماثل ہوسکتا ہے۔
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// اگر آپ ترتیب کو برقرار رکھتے ہوئے ترتیب کے مطابق `VecDeque` پر آئٹم داخل کرنا چاہتے ہیں تو:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// ثنائی تلاش کرنے والے `VecDeque` کو موازنہ کرنے والی تقریب کے ساتھ تلاش کرتی ہے۔
    ///
    /// تقابلی فعل کو ایک بنیادی آرڈر کوڈ کو واپس کرتے ہوئے بنیادی `VecDeque` کے ترتیب کے مطابق آرڈر پر عمل درآمد کرنا چاہئے جس سے یہ ظاہر ہوتا ہے کہ آیا اس کی دلیل مطلوبہ ہدف سے `Less` ، `Equal` یا `Greater` ہے۔
    ///
    ///
    /// اگر قیمت مل جاتی ہے تو [`Result::Ok`] واپس کردیتا ہے ، جس میں ملاپ والے عنصر کی اشاریہ ہوتا ہے۔اگر وہاں متعدد میچز ہیں ، تو میچوں میں سے ایک بھی واپس ہوسکتا ہے۔
    /// اگر قیمت نہیں مل پاتی ہے تو [`Result::Err`] واپس کردیتا ہے ، جس میں انڈکس ہوتا ہے جہاں ترتیب والا نظم برقرار رکھتے ہوئے ایک مماثل عنصر داخل کیا جاسکتا ہے۔
    ///
    /// # Examples
    ///
    /// چار عناصر کا ایک سلسلہ تلاش کریں۔پہلا پایا جاتا ہے ، جس کی ایک منفرد حیثیت سے پوزیشن ہوتی ہے۔دوسرا اور تیسرا نہیں ملا۔چوتھا `[1, 4]` میں کسی بھی پوزیشن سے مماثل ہوسکتا ہے۔
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// ثنائی تلاش کرتا ہے `VecDeque` کو کلیدی نکالنے والی تقریب سے۔
    ///
    /// فرض کریں کہ `VecDeque` کلید کے ذریعہ ترتیب دیا گیا ہے ، مثال کے طور پر اسی کلید نکالنے والے فنکشن کا استعمال کرتے ہوئے [`make_contiguous().sort_by_key()`](#method.make_contiguous) کے ساتھ۔
    ///
    ///
    /// اگر قیمت مل جاتی ہے تو [`Result::Ok`] واپس کردیتا ہے ، جس میں ملاپ والے عنصر کی اشاریہ ہوتا ہے۔
    /// اگر وہاں متعدد میچز ہیں ، تو میچوں میں سے ایک بھی واپس ہوسکتا ہے۔
    /// اگر قیمت نہیں مل پاتی ہے تو [`Result::Err`] واپس کردیتا ہے ، جس میں انڈکس ہوتا ہے جہاں ترتیب والا نظم برقرار رکھتے ہوئے ایک مماثل عنصر داخل کیا جاسکتا ہے۔
    ///
    /// # Examples
    ///
    /// دوسرے عناصر کے ذریعہ ترتیب دیئے گئے جوڑے کے ٹکڑے میں چار عناصر کا ایک سلسلہ دکھاتا ہے۔
    /// پہلا پایا جاتا ہے ، جس کی ایک منفرد حیثیت سے پوزیشن ہوتی ہے۔دوسرا اور تیسرا نہیں ملا۔چوتھا `[1, 4]` میں کسی بھی پوزیشن سے مماثل ہوسکتا ہے۔
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` کو جگہ جگہ تبدیل کریں تاکہ `len()` نئے_لن کے برابر ہو ، یا تو پیچھے سے اضافی عنصر نکال کر یا `value` کے کلونوں کو پیچھے سے جوڑ کر۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// دیئے گئے منطقی عنصر انڈیکس کیلئے بنیادی بفر میں انڈیکس لوٹاتا ہے۔
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // سائز ہمیشہ 2 کی طاقت ہوتا ہے
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// بفر میں پڑھے جانے والے عناصر کی تعداد کا حساب لگائیں
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // سائز ہمیشہ 2 کی طاقت ہوتا ہے
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // ہمیشہ تین حصوں میں تقسیم پذیر ، مثال کے طور پر: خود: [a b c|d e f] دوسرے: [0 1 2 3|4 5] فرنٹ=3 ، وسط=1 ، [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // سلائسس پر واپس آنے والے سلائسز پر Hash::hash_slice استعمال کرنا ممکن نہیں ہے کیونکہ ان کی لمبائی دوسری صورت میں مماثل تقویت میں مختلف ہوسکتی ہے۔
        //
        //
        // حشر صرف اپنے طریقوں پر کالوں کے عین مطابق سیٹ کے مساوات کی ضمانت دیتا ہے۔
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque` کو قیمت کے حساب سے عنصر تیار کرنے والے سامنے سے پیچھے والے آئٹرٹر میں لیتا ہے۔
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // یہ فنکشن اخلاقی مساوی ہونا چاہئے:
        //
        //      iter.into_iter() میں آئٹم کے لئے for
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// ایک [`VecDeque<T>`] کو [`VecDeque<T>`] میں تبدیل کریں۔
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// جہاں ممکن ہو وہاں دوبارہ تشخیص کرنے سے گریز کرتا ہے ، لیکن اس کے ل the ضوابط سخت ہیں ، اور اسے تبدیل کرنے کا پابند ہے ، اور اسی طرح انحصار نہیں کیا جانا چاہئے جب تک کہ `Vec<T>` `From<VecDeque<T>>` سے نہ آجائے اور دوبارہ نامعلوم نہ ہو۔
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // ZSTs کے لئے صلاحیت کے بارے میں فکر کرنے کے لئے کوئی حقیقی مختص نہیں ہے ، لیکن `Vec` اتنی لمبائی `Vec` نہیں سنبھال سکتا ہے۔
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // ہمیں صلاحیت تبدیل کرنے کی ضرورت ہے اگر استعداد دو کی طاقت نہیں ہے ، بہت چھوٹی ہے یا کم از کم ایک خالی جگہ نہیں ہے۔
            // ہم یہ کرتے ہیں جبکہ یہ ابھی بھی `Vec` میں ہے تاکہ آئٹم panic پر گر جائے۔
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// ایک [`Vec<T>`] کو [`Vec<T>`] میں تبدیل کریں۔
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// اس کے لئے کبھی بھی مختص کرنے کی ضرورت نہیں ہے ، لیکن اگر سرکلر بفر مختص ہونے کے آغاز میں نہیں ہوتا ہے تو *O*(*n*) ڈیٹا کی نقل و حرکت کرنے کی ضرورت نہیں ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // یہ ایک *O*(1) ہے۔
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // اس میں اعداد و شمار کو دوبارہ ترتیب دینے کی ضرورت ہے۔
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}