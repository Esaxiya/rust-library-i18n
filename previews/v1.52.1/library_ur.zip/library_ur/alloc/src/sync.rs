#![stable(feature = "rust1", since = "1.0.0")]

//! تھریڈ سیف ریفرنس گنتی پوائنٹرز۔
//!
//! مزید تفصیلات کے لئے [`Arc<T>`][Arc] دستاویزات دیکھیں۔

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// حوالوں کی مقدار پر ایک نرم حد جو `Arc` پر کی جاسکتی ہے۔
///
/// اس حد سے اوپر جانے سے آپ کے _exactly_ `MAX_REFCOUNT + 1` حوالوں پر (اگرچہ ضروری نہیں) پروگرام ختم کردیں گے۔
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// تھریڈ سینیٹائزر میموری باڑ کی حمایت نہیں کرتا ہے۔
// قوس/کمزور نفاذ میں غلط مثبت اطلاعات سے بچنے کے ل sy مطابقت پذیری کے ل at جوہری بوجھ کا استعمال کریں۔
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ایک تھریڈ سیف ریفرنس گنتی پوائنٹر۔'Arc' کا مطلب ہے 'اٹامکلی ریفرنس کاؤنٹیٹ'۔
///
/// قسم `Arc<T>` ڈھیر میں مختص قسم `T` کی قدر کی مشترکہ ملکیت فراہم کرتی ہے۔`Arc` پر ایکس03 ایکس کو طلب کرنا ایک نیا `Arc` مثال پیش کرتا ہے ، جو ڈھیر پر اسی طرح کے مختص کی طرف اشارہ کرتا ہے جس میں ماخذ `Arc` ہوتا ہے ، جبکہ ایک حوالہ شماری میں اضافہ ہوتا ہے۔
/// جب کسی مختص مختص کا آخری `Arc` پوائنٹر ختم ہوجاتا ہے تو ، اس مختص میں ذخیرہ شدہ قدر (اکثر "inner value" کے نام سے بھی جانا جاتا ہے) بھی گرا دیا جاتا ہے۔
///
/// Rust میں مشترکہ حوالہ جات ڈیفالٹ کے ذریعہ اتپریورتن کی اجازت نہیں دیتے ہیں ، اور `Arc` بھی اس سے مستثنیٰ نہیں ہے: آپ عام طور پر کسی `Arc` کے اندر کسی چیز کا تغیر پزیر حوالہ حاصل نہیں کرسکتے ہیں۔اگر آپ کو `Arc` کے ذریعہ تبدیل کرنے کی ضرورت ہے تو ، [`Mutex`][mutex] ، [`RwLock`][rwlock] ، یا [`Atomic`][atomic] اقسام میں سے کسی ایک کا استعمال کریں۔
///
/// ## تھریڈ سیفٹی
///
/// [`Rc<T>`] کے برعکس ، `Arc<T>` اپنی حوالہ گنتی کے لئے جوہری کارروائیوں کا استعمال کرتا ہے۔اس کا مطلب ہے کہ یہ تھریڈ سیف ہے۔نقصان یہ ہے کہ جوہری آپریشن عام میموری تک رسائی سے زیادہ مہنگے ہوتے ہیں۔اگر آپ تھریڈز کے مابین حوالہ گنتی کی رقم مختص نہیں کر رہے ہیں تو ، نچلے ہیڈ کے لئے [`Rc<T>`] استعمال کرنے پر غور کریں۔
/// [`Rc<T>`] محفوظ ڈیفالٹ ہے ، کیوں کہ تالیف دہندگان کے مابین [`Rc<T>`] بھیجنے کی کوئی کوشش پکڑے گی۔
/// تاہم ، لائبریری لائبریری صارفین کو زیادہ لچک دلانے کے لئے `Arc<T>` کا انتخاب کر سکتی ہے۔
///
/// `Arc<T>` [`Send`] اور [`Sync`] کو نافذ کریں گے جب تک کہ `T` [`Send`] اور [`Sync`] پر عمل درآمد کرے۔
/// اس کو تھریڈ سیف بنانے کے ل X آپ `Arc<T>` میں غیر تھریڈ سیف قسم `T` کیوں نہیں ڈال سکتے ہیں؟یہ سب سے پہلے تھوڑا سا انسداد بدیہی ہوسکتا ہے: آخر ، `Arc<T>` تھریڈ سیفٹی کا نقطہ نہیں ہے؟کلیدی بات یہ ہے کہ: `Arc<T>` ایک ہی ڈیٹا کی ایک سے زیادہ ملکیت رکھنے کے لئے تھریڈ کو محفوظ بناتا ہے ، لیکن اس سے اس کے ڈیٹا میں تھریڈ سیفٹی شامل نہیں ہوتی ہے۔
///
/// `آرک <` [`ریف سیل پر غور کریں<T>`]`>`۔
/// [`RefCell<T>`] [`Sync`] نہیں ہے ، اور اگر `Arc<T>` ہمیشہ [`Send`] ہوتا تو ، `آرک <` [`ریف سیل<T>`]`>`بھی ہوگا۔
/// لیکن پھر ہمیں ایک مسئلہ درپیش ہوگا:
/// [`RefCell<T>`] دھاگہ محفوظ نہیں ہے۔یہ غیر جوہری کارروائیوں کا استعمال کرتے ہوئے قرضے لینے کی گنتی کو ٹریک کرتا ہے۔
///
/// آخر میں ، اس کا مطلب یہ ہے کہ آپ کو `Arc<T>` کے ساتھ [`std::sync`] قسم کی عام طور پر [`Mutex<T>`][mutex] کی جوڑی بنانے کی ضرورت ہوسکتی ہے۔
///
/// ## `Weak` کے ساتھ سائیکل توڑ رہے ہیں
///
/// [`downgrade`][downgrade] طریقہ غیر غیر ملکیت [`Weak`] پوائنٹر بنانے کے لئے استعمال کیا جاسکتا ہے۔ایک [`Weak`] پوائنٹر [`اپگریڈ][[اپ گریڈ] d کو ایک `Arc` میں ہوسکتا ہے ، لیکن اگر یہ مختص میں رکھی ہوئی قیمت کو پہلے ہی چھوڑ دیا گیا ہو تو یہ [`None`] واپس آئے گا۔
/// دوسرے الفاظ میں ، `Weak` پوائنٹر مختص کے اندر کی قیمت کو زندہ نہیں رکھتے ہیں۔تاہم ، وہ مختص کرتے ہیں (قیمت کے لئے معاون اسٹور) کو برقرار رکھتے ہیں۔
///
/// `Arc` پوائنٹر کے درمیان چکر کبھی ختم نہیں ہوگا۔
/// اس وجہ سے ، [`Weak`] سائیکل کو توڑنے کے لئے استعمال کیا جاتا ہے۔مثال کے طور پر ، ایک درخت میں والدین کے نوڈس سے بچوں تک مضبوط `Arc` پوائنٹر اور [`Weak`] پوائنٹر بچوں سے ان کے والدین کی طرف ہوسکتے ہیں۔
///
/// # کلوننگ حوالہ جات
///
/// موجودہ حوالہ گنتی والے پوائنٹر سے ایک نیا حوالہ بنانا `Clone` trait کو [`Arc<T>`][Arc] اور [`Weak<T>`][Weak] کیلئے لاگو کیا گیا ہے۔
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // ذیل میں دو نحو مترادف ہیں۔
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // الف ، بی ، اور فو تمام آرکس ہیں جو ایک ہی میموری والے مقام کی طرف اشارہ کرتے ہیں
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` خود بخود `T` ([`Deref`][deref] trait کے زریعے) کا حوالہ دیتا ہے ، تاکہ آپ `Arc<T>` کی قسم پر `T` کے طریقوں پر کال کرسکیں۔`T` کے طریقوں سے نام کی تصادم سے بچنے کے ل X ، خود `Arc<T>` کے طریق کار وابستہ ہیں ، جن کو [fully qualified syntax] کا استعمال کرتے ہوئے کہا جاتا ہے:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `آرک<T>`Clone` جیسے traits کے نفاذ کو بھی مکمل طور پر اہل نحو کا استعمال کرتے ہوئے کہا جاسکتا ہے۔
/// کچھ لوگ مکمل طور پر کوالیفائی کردہ نحو کو استعمال کرنے کو ترجیح دیتے ہیں ، جبکہ دوسرے میتھڈ کال نحیط استعمال کرنا پسند کرتے ہیں۔
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // طریقہ کال کالیکس
/// let arc2 = arc.clone();
/// // مکمل طور پر تعلیم یافتہ نحو
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` کا خود کار طریقے سے حوالہ نہیں دیتا ہے ، کیونکہ داخلی قیمت پہلے ہی چھوڑ دی جاسکتی ہے۔
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// دھاگوں کے مابین کچھ غیر منقولہ ڈیٹا کا اشتراک:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// نوٹ کریں کہ ہم ** یہ ٹیسٹ یہاں نہیں چلاتے ہیں۔
// windows بلڈر انتہائی ناخوش ہوجاتے ہیں اگر کوئی تھریڈ مرکزی دھاگے سے نکل جاتا ہے اور پھر اسی وقت (کچھ تعطل کا شکار ہوجاتا ہے) باہر نکل جاتا ہے تو ہم ان ٹیسٹوں کو نہ چلاتے ہوئے اس سے مکمل طور پر بچ جاتے ہیں۔
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// ایک متغیر [`AtomicUsize`] کا اشتراک:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// عام طور پر حوالہ گنتی کی مزید مثالوں کے لئے [`rc` documentation][rc_examples] دیکھیں۔
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] کا ایک ایسا ورژن ہے جس میں زیر انتظام مختص کا غیر مالکانہ حوالہ ہے۔
/// `Weak` پوائنٹر پر [`upgrade`] پر کال کرکے اس مختص تک رسائی حاصل کی گئی ہے ، جو [`آپشن`] returns <`[`آرک] returns واپس کرتا ہے<T>> `.
///
/// چونکہ ایک `Weak` حوالہ ملکیت کی طرف نہیں ہے ، لہذا یہ مختص میں رکھی ہوئی قیمت کو گرنے سے نہیں روکے گا ، اور خود ہی `Weak` اس قیمت کی موجودگی کے بارے میں کوئی ضمانت نہیں دیتا ہے۔
///
/// اس طرح یہ [`None`] واپس آسکتا ہے جب [`اپ گریڈ`] ڈی۔
/// تاہم یہ نوٹ کریں کہ ایک `Weak` حوالہ *کرتا ہے* خود مختص (بیکنگ اسٹور) کو غیر موزوں ہونے سے روکتا ہے۔
///
/// ایک `Weak` پوائنٹر [`Arc`] کے ذریعہ اس کے اندرونی قدر کو گرانے سے روکنے کے بغیر مختص رقم کے عارضی حوالہ رکھنے کیلئے مفید ہے۔
/// یہ [`Arc`] پوائنٹر کے درمیان سرکلر حوالوں کو روکنے کے لئے بھی استعمال کیا جاتا ہے ، کیونکہ باہمی مالکانہ حوالہ جات کبھی بھی [`Arc`] کو خارج نہیں ہونے دیتا ہے۔
/// مثال کے طور پر ، ایک درخت میں والدین کے نوڈس سے بچوں تک مضبوط [`Arc`] پوائنٹر اور `Weak` پوائنٹر بچوں سے ان کے والدین کی طرف ہوسکتے ہیں۔
///
/// `Weak` پوائنٹر حاصل کرنے کا خاص طریقہ [`Arc::downgrade`] پر کال کرنا ہے۔
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // یہ ایک `NonNull` ہے تاکہ انامس میں اس قسم کے سائز کو بہتر بنایا جاسکے ، لیکن یہ ضروری نہیں کہ یہ ایک درست پوائنٹر ہو۔
    //
    // `Weak::new` اسے `usize::MAX` پر متعین کرتا ہے تاکہ ڈھیر پر جگہ مختص کرنے کی ضرورت نہ ہو۔
    // یہ ایک ایسی اہم قیمت نہیں ہے جس کے اصلی پوائنٹر کو کبھی حاصل ہوسکے کیونکہ آر سی بوکس میں کم سے کم 2 کی سیدھ ہوتی ہے۔
    // یہ تب ہی ممکن ہے جب `T: Sized`؛غیر منقسم `T` کبھی الجھنا نہیں۔
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ممکنہ فیلڈ آرڈرنگ کے خلاف یہ repr(C) سے future-پروف ہے ، جو منتقلی داخلی اقسام کے محفوظ [into|from]_raw() کے ساتھ مداخلت کرے گا۔
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // قدر usize::MAX عارضی طور پر "locking" کے لئے مرسل کے طور پر کام کرتی ہے جس میں کمزور پوائنٹس کو اپ گریڈ کرنے یا مضبوط افراد کو نیچے کرنے کی صلاحیت ہے۔یہ `make_mut` اور `get_mut` میں ریس سے بچنے کے لئے استعمال ہوتا ہے۔
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// ایک نیا `Arc<T>` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // کمزور پوائنٹر گنتی 1 کو شروع کریں جو کمزور پوائنٹر ہے جو تمام مضبوط پوائنٹرز (kinda) کے پاس ہے ، مزید معلومات کے لئے std/rc.rs دیکھیں
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// اپنے آپ میں کمزور حوالہ استعمال کرکے نیا `Arc<T>` تشکیل دیتا ہے۔
    /// اس فنکشن کی واپسی سے پہلے ضعیف حوالہ کو اپ گریڈ کرنے کی کوشش کے نتیجے میں `None` ویلیو ہوگی۔
    /// تاہم ، ضعیف حوالہ آزادانہ طور پر کلون کیا جاسکتا ہے اور بعد میں استعمال کے ل. ذخیرہ کیا جاسکتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // ایک واحد کمزور حوالہ کے ساتھ اندرونی "uninitialized" حالت میں تعمیر کریں۔
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // یہ ضروری ہے کہ ہم کمزور پوائنٹر کی ملکیت ترک نہیں کریں ، ورنہ `data_fn` کی واپسی کے وقت میموری کو آزاد کیا جاسکتا ہے۔
        // اگر ہم واقعتا ownership ملکیت کو منتقل کرنا چاہتے ہیں تو ہم اپنے لئے ایک اضافی کمزور پوائنٹر تشکیل دے سکتے ہیں ، لیکن اس کے نتیجے میں ضعیف حوالہ گنتی میں اضافی تازہ کاری ہوگی جو دوسری صورت میں ضروری نہیں ہوگی۔
        //
        //
        //
        //
        let data = data_fn(&weak);

        // اب ہم داخلی قدر کو صحیح طریقے سے ابتدا کرسکتے ہیں اور اپنے کمزور حوالہ کو مضبوط حوالہ میں تبدیل کرسکتے ہیں۔
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ڈیٹا فیلڈ میں مذکورہ بالا تحریر کسی بھی تھریڈ کیلئے مرئی ہونی چاہئے جو غیر صفر مضبوط گنتی کا مشاہدہ کرتی ہے۔
            // لہذا ہمیں `Weak::upgrade` میں `compare_exchange_weak` کے ساتھ ہم آہنگی پیدا کرنے کے لئے کم از کم "Release" آرڈرنگ کی ضرورت ہے۔
            //
            // "Acquire" آرڈر دینے کی ضرورت نہیں ہے۔
            // جب `data_fn` کے ممکنہ سلوک پر غور کریں تو ہمیں صرف اس پر نظر ڈالنے کی ضرورت ہوگی کہ یہ غیر اپ گریڈ ایبل `Weak` کے حوالے سے کیا کرسکتا ہے:
            //
            // - یہ کمزور حوالہ شمار میں اضافہ کرکے ، `Weak`*کا کلون* کر سکتا ہے۔
            // - یہ ان کلونوں کو چھوڑ سکتا ہے ، کمزور حوالہ شمار کو کم کرتا ہے (لیکن کبھی صفر نہیں ہوتا ہے)۔
            //
            // یہ مضر اثرات ہم پر کسی طرح اثر نہیں ڈالتے اور صرف اور صرف محفوظ کوڈ کے ذریعہ کوئی اور مضر اثرات ممکن نہیں ہیں۔
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // مضبوط حوالوں کو مشترکہ طور پر مشترکہ ضعیف حوالہ کا مالک ہونا چاہئے ، لہذا ہمارے پرانے ضعیف حوالہ کو ضائع کرنے والے کو نہ چلائیں۔
        //
        mem::forget(weak);
        strong
    }

    /// غیر منطقی مشمولات کے ساتھ ایک نیا `Arc` تشکیل دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ہی ، بنائے ہوئے مواد کے ساتھ ایک نیا `Arc` بناتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ایک نیا `Pin<Arc<T>>` بناتا ہے۔
    /// اگر `T` `Unpin` پر عمل درآمد نہیں کرتا ہے ، تو `data` میموری میں پن ہوجائے گا اور منتقل ہونے سے قاصر ہے۔
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// ایک نیا `Arc<T>` تشکیل دیتا ہے ، اگر مختص ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // کمزور پوائنٹر گنتی 1 کو شروع کریں جو کمزور پوائنٹر ہے جو تمام مضبوط پوائنٹرز (kinda) کے پاس ہے ، مزید معلومات کے لئے std/rc.rs دیکھیں
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// غیر منطقی مشمولات کے ساتھ ایک نیا `Arc` تشکیل دیتا ہے ، اگر مختص ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ، غیر بنائے ہوئے مشمولات کے ساتھ ایک نیا `Arc` تشکیل دیتا ہے ، اگر الاٹمنٹ ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// اگر `Arc` میں بالکل ایک مضبوط حوالہ ہو تو اندرونی قدر لوٹاتا ہے۔
    ///
    /// بصورت دیگر ،[`Err`] X اسی `Arc` کے ساتھ واپس کیا گیا تھا جس میں گزر چکا تھا۔
    ///
    ///
    /// یہاں تک کہ اگر یہاں ضعیف ضعیف حوالہ جات موجود ہوں تو بھی کامیابی ہوگی۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // مضبوط مضبوط کمزور حوالہ صاف کرنے کے لئے ایک کمزور پوائنٹر بنائیں
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// غیر منطقی مشمولات کے ساتھ ایک نیا جوہری حوالہ گنتی والا ٹکڑا تیار کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // موخر ابتدا:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ہی ، انیٹائٹائزڈ مشمولات کے ساتھ ایک نیا جوہری حوالہ گنتی والا ٹکڑا تیار کرتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` میں تبدیل ہوتا ہے۔
    ///
    /// # Safety
    ///
    /// جیسا کہ [`MaybeUninit::assume_init`] کی طرح ، یہ اس بات کی ضمانت دینے والے پر منحصر ہے کہ اندرونی قیمت واقعتا ابتدائی حالت میں ہے۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا فوری طور پر غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` میں تبدیل ہوتا ہے۔
    ///
    /// # Safety
    ///
    /// جیسا کہ [`MaybeUninit::assume_init`] کی طرح ، یہ اس بات کی ضمانت دینے والے پر منحصر ہے کہ اندرونی قیمت واقعتا ابتدائی حالت میں ہے۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا فوری طور پر غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // موخر ابتدا:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// لپیٹے ہوئے پوائنٹر کو لوٹاتے ہوئے ، `Arc` استعمال کرتا ہے۔
    ///
    /// میموری لیک ہونے سے بچنے کے ل the ، پوائنٹر کو [`Arc::from_raw`] کا استعمال کرکے واپس `Arc` میں تبدیل کرنا ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// اعداد و شمار کو ایک خام اشارہ فراہم کرتا ہے۔
    ///
    /// شمار کسی بھی طرح متاثر نہیں ہوتے ہیں اور `Arc` استعمال نہیں ہوتا ہے۔
    /// جب تک کہ `Arc` میں مضبوط گنتی موجود ہو تب تک یہ پوائنٹر درست ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // حفاظت: یہ Deref::deref یا RcBoxPtr::inner کے ذریعے نہیں جاسکتی ہے کیونکہ
        // اس کی ضرورت ہے جیسے raw/mut پروونانس برقرار رکھنا
        // `get_mut` `from_raw` کے ذریعہ آرسی بازیافت ہونے کے بعد پوائنٹر کے ذریعے لکھ سکتا ہے۔
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// کسی خام پوائنٹر سے `Arc<T>` بناتا ہے۔
    ///
    /// خام پوائنٹر کو پہلے بھی [`Arc<U>::into_raw`][into_raw] پر کال کے ذریعہ واپس کر دینا چاہئے جہاں `U` کے پاس ایک ہی سائز اور سیدھ `T` کی طرح ہونی چاہئے۔
    /// اگر یہ `U` `T` ہے تو یہ چھوٹی سی بات ہے۔
    /// نوٹ کریں کہ اگر `U` `T` نہیں ہے لیکن ایک ہی سائز اور سیدھ میں ہے تو ، یہ بنیادی طور پر مختلف اقسام کے حوالوں کو منتقل کرنے کی طرح ہے۔
    /// اس معاملے میں کن پابندیوں کا اطلاق ہوتا ہے اس بارے میں مزید معلومات کے لئے [`mem::transmute`][transmute] دیکھیں۔
    ///
    /// `from_raw` کے صارف کو یہ یقینی بنانا ہوگا کہ `T` کی ایک مخصوص قدر صرف ایک بار گرا دی جائے۔
    ///
    /// یہ فنکشن غیر محفوظ ہے کیونکہ ناجائز استعمال سے میموری ناجائز ہوسکتا ہے ، یہاں تک کہ اگر واپس شدہ `Arc<T>` تک کبھی بھی رسائی حاصل نہیں کی جاتی ہے۔
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // لیک کو روکنے کے لئے واپس `Arc` میں تبدیل کریں۔
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` پر مزید کالیں میموری سے غیر محفوظ ہوں گی۔
    /// }
    ///
    /// // میموری کو آزاد کیا گیا جب `x` اوپر دائرہ کار سے باہر چلا گیا ، لہذا `x_ptr` اب گھماؤ پڑا ہے!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // اصل آرک انر کو تلاش کرنے کے لئے آفسیٹ کو پلٹائیں۔
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// اس مختص کیلئے ایک نیا [`Weak`] پوائنٹر بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // یہ ریلیکسڈ ٹھیک ہے کیونکہ ہم ذیل میں سی اے ایس میں قیمت کی جانچ کررہے ہیں۔
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // چیک کریں کہ آیا اس وقت کمزور کاؤنٹر "locked" ہے۔اگر ایسا ہے تو ، گھماؤ۔
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: یہ ضابطہ فی الحال بہاو کے امکان کو نظر انداز کرتا ہے
            // usize::MAX میں؛عام طور پر آر سی اور آرک دونوں کو اوور فلو سے نمٹنے کے ل adj ایڈجسٹ کرنے کی ضرورت ہے۔
            //

            // Clone() کے برعکس ، ہمیں اس کی ضرورت ہے کہ `is_unique` سے آنے والی تحریر کے ساتھ ہم آہنگ ہونے کے لئے ایکوائر ریڈر ہو ، تاکہ اس لکھنے سے پہلے کے واقعات اس پڑھنے سے پہلے پیش آئیں۔
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // اس بات کو یقینی بنائیں کہ ہم بے ربط کمزوری کو پیدا نہیں کرتے ہیں
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// اس مختص کیلئے [`Weak`] پوائنٹرز کی تعداد حاصل ہوتی ہے۔
    ///
    /// # Safety
    ///
    /// یہ طریقہ بذات خود محفوظ ہے ، لیکن اس کا صحیح استعمال کرنے میں اضافی نگہداشت کی ضرورت ہے۔
    /// دوسرا تھریڈ کسی بھی وقت کمزور گنتی کو تبدیل کرسکتا ہے ، بشمول اس طریقہ پر کال کرنے اور اس کے نتیجے پر عمل کرنے کے درمیان۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // یہ دعوی تشخیصی ہے کیونکہ ہم نے دھاگوں کے درمیان `Arc` یا `Weak` کا اشتراک نہیں کیا ہے۔
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // اگر فی الحال کمزور گنتی مقفل ہے تو ، لاک لینے سے ٹھیک پہلے گنتی کی قدر 0 تھی۔
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// اس مختص کیلئے مضبوط (`Arc`) پوائنٹرز کی تعداد حاصل ہوتی ہے۔
    ///
    /// # Safety
    ///
    /// یہ طریقہ بذات خود محفوظ ہے ، لیکن اس کا صحیح استعمال کرنے میں اضافی نگہداشت کی ضرورت ہے۔
    /// دوسرا دھاگہ کسی بھی وقت مضبوط گنتی کو تبدیل کرسکتا ہے ، بشمول اس طریقہ کو کال کرنے اور اس کے نتیجے پر عمل کرنے کے درمیان۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // یہ دعوی تشخیصی ہے کیونکہ ہم نے `Arc` کو تھریڈ کے مابین اشتراک نہیں کیا ہے۔
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// ایک ایک کرکے فراہم کردہ پوائنٹر کے ساتھ وابستہ `Arc<T>` پر مضبوط ریفرنس گنتی میں اضافہ ہوتا ہے۔
    ///
    /// # Safety
    ///
    /// اشارہ `Arc::into_raw` کے ذریعہ حاصل کیا جانا چاہئے ، اور متعلقہ `Arc` مثال درست ہونا چاہئے (جیسے
    /// اس طریقہ کار کی مدت کے لئے مضبوط گنتی کم از کم 1) ہونی چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // یہ دعوی تشخیصی ہے کیونکہ ہم نے `Arc` کو تھریڈ کے مابین اشتراک نہیں کیا ہے۔
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // آرک کو برقرار رکھیں ، لیکن دستی ڈراپ میں ریپنگ کرکے دوبارہ گنتی کو ہاتھ نہ لگائیں
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // اب ریفکاونٹ میں اضافہ کریں ، لیکن نیا ریفکاونٹ بھی نہ چھوڑیں
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// ایک کے ذریعہ فراہم کردہ پوائنٹر کے ساتھ وابستہ `Arc<T>` پر مضبوط حوالہ شمار کو کم کرتا ہے۔
    ///
    /// # Safety
    ///
    /// اشارہ `Arc::into_raw` کے ذریعہ حاصل کیا جانا چاہئے ، اور متعلقہ `Arc` مثال درست ہونا چاہئے (جیسے
    /// مضبوط طریقہ کم سے کم 1 ہونا ضروری ہے۔
    /// یہ طریقہ حتمی `Arc` اور بیکنگ اسٹوریج کی رہائی کے لئے استعمال کیا جاسکتا ہے ، لیکن آخری X01 ایکس کے اجراء کے بعد ** نہیں بلایا جانا چاہئے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // یہ دعوے عزم پر مبنی ہیں کیونکہ ہم نے `Arc` کو موضوعات کے مابین اشتراک نہیں کیا ہے۔
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // یہ بے یقینی ٹھیک ہے کیونکہ جب تک یہ قوس زندہ ہے ہمیں ضمانت دی جاتی ہے کہ اندرونی اشارہ درست ہے۔
        // مزید یہ کہ ، ہم جانتے ہیں کہ `ArcInner` ڈھانچہ خود ہی `Sync` ہے کیونکہ اندرونی اعداد و شمار بھی `Sync` ہے ، لہذا ہم ٹھیک ہیں کہ ان مشمولات کے لut ایک ناقابل تغیراتی نکات پر قرض لیا جائے۔
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` کا غیر مابعد والا حصہ۔
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // اس وقت اعداد و شمار کو خارج کردیں ، حالانکہ ہم خود ہی باکس الاٹیکشن کو آزاد نہیں کرسکتے ہیں (اب بھی اس کے ارد گرد کمزور پوائنٹس پڑسکتے ہیں)۔
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // تمام مضبوط حوالوں کے ذریعہ مشترکہ طور پر رکھے ہوئے کمزور ریف کو گرا دیں
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// اگر دو `آرک the ایک ہی مختص کی طرف اشارہ کرتے ہیں تو `true` واپس کرتا ہے ([`ptr::eq`] کی طرح رگ میں)۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// ایک `ArcInner<T>` کو ممکنہ طور پر غیر تبدیل شدہ داخلی قیمت کے لئے کافی جگہ کے ساتھ مختص کرتا ہے جہاں قیمت میں ترتیب فراہم کی جاتی ہے۔
    ///
    /// فنکشن `mem_to_arcinner` کو ڈیٹا پوائنٹر کے ساتھ بلایا جاتا ہے اور `ArcInner<T>` کے لئے ایک (ممکنہ چربی) پوائنٹر واپس کرنا ہوگا۔
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // دیئے گئے قدر کی ترتیب کا استعمال کرکے ترتیب کا حساب لگائیں۔
        // اس سے قبل ، ترتیب `&*(ptr as* const ArcInner<T>)` پر حساب کتاب کیا جاتا تھا ، لیکن اس نے غلط دستخط شدہ حوالہ بنایا (دیکھیں #54908)۔
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ایک `ArcInner<T>` کو ممکنہ طور پر غیر تبدیل شدہ داخلی قیمت کے لئے کافی جگہ کے ساتھ مختص کرتا ہے جہاں قیمت نے ترتیب فراہم کی ہے ، اگر مختص میں ناکام ہوجاتا ہے تو ایک غلطی واپس کرنا۔
    ///
    ///
    /// فنکشن `mem_to_arcinner` کو ڈیٹا پوائنٹر کے ساتھ بلایا جاتا ہے اور `ArcInner<T>` کے لئے ایک (ممکنہ چربی) پوائنٹر واپس کرنا ہوگا۔
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // دیئے گئے قدر کی ترتیب کا استعمال کرکے ترتیب کا حساب لگائیں۔
        // اس سے قبل ، ترتیب `&*(ptr as* const ArcInner<T>)` پر حساب کتاب کیا جاتا تھا ، لیکن اس نے غلط دستخط شدہ حوالہ بنایا (دیکھیں #54908)۔
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // آرک اننر کا آغاز کریں
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// ایک غیر منقول اندرونی قدر کے ل sufficient کافی جگہ کے ساتھ ایک `ArcInner<T>` مختص کرتا ہے۔
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // دی گئی قیمت کا استعمال کرتے ہوئے `ArcInner<T>` کے لئے مختص کریں۔
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // بائٹس کے بطور قیمت کاپی کریں
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // مختص کو اس کے مندرجات کو چھوڑے بغیر آزاد کریں
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// دی گئی لمبائی کے ساتھ ایک `ArcInner<[T]>` مختص کرتا ہے۔
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// عناصر کو ٹکڑوں سے نو مختص آرک <\[T\]> میں کاپی کریں
    ///
    /// غیر محفوظ ہے کیونکہ کال کرنے والے کو یا تو ملکیت لینا چاہئے یا `T: Copy` کا پابند ہونا چاہئے۔
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// ایک ایٹریٹر سے ایک `Arc<[T]>` بناتا ہے جو ایک خاص سائز کے نام سے جانا جاتا ہے۔
    ///
    /// سلوک غیر وضاحتی ہے جب سائز غلط ہونا چاہئے۔
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Z عناصر کی کلوننگ کرتے وقت Panic گارڈ۔
        // panic کی صورت میں ، نئے آرک انر میں لکھے گئے عناصر کو خارج کردیا جائے گا ، پھر میموری کو آزاد کردیا جائے گا۔
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // پہلے عنصر کی طرف اشارہ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // سب صاف ہے۔گارڈ کو بھول جاؤ تاکہ یہ نئے آرک اننر کو آزاد نہ کرے۔
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` کے لئے استعمال کی جانے والی تخصص trait
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` پوائنٹر کا کلون بناتا ہے۔
    ///
    /// یہ ایک ہی مختص کرنے کے لئے ایک اور پوائنٹر پیدا کرتا ہے ، جس میں مضبوط حوالہ شمار بڑھ جاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // یہاں پر سکون آرڈرنگ کا استعمال ٹھیک ہے ، کیوں کہ اصل حوالہ کا علم دوسرے دھاگوں کو غلطی سے آبجیکٹ کو حذف کرنے سے روکتا ہے۔
        //
        // جیسا کہ [Boost documentation][1] میں بیان کیا گیا ہے ، ریفرنس کاؤنٹر میں اضافہ کرنا ہمیشہ میموری_ آرڈر_ رییلکسڈ کے ساتھ کیا جاسکتا ہے: کسی شے کے بارے میں نئے حوالہ جات صرف ایک موجودہ حوالہ سے ہی تشکیل پائے جا سکتے ہیں ، اور ایک موجودہ دھاگے سے دوسرے دھاگے میں گزرنے سے پہلے ہی لازمی مطابقت پذیری فراہم کرنا ضروری ہے۔
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // تاہم ہمیں کسی کو `یاد: :::بھول جانے والا آرکس ہونے کی صورت میں بڑے پیمانے پر ریفاکٹس سے بچانے کی ضرورت ہے۔
        // اگر ہم ایسا نہیں کرتے ہیں تو گنتی بہہ سکتی ہے اور صارفین مفت استعمال کریں گے۔
        // ہم اس مفروضے پر `isize::MAX` کو پوری طرح سے مطمئن کرتے ہیں کہ ایک بار میں ~2 بلین تھریڈز ریفرنس کی گنتی میں اضافہ نہیں کرتے ہیں۔
        //
        // یہ branch کبھی بھی کسی حقیقت پسندانہ پروگرام میں نہیں لیا جائے گا۔
        //
        // ہم اسقاط حمل کردیتے ہیں کیوں کہ اس طرح کا پروگرام ناقابل یقین حد تک پسماندہ ہے ، اور ہمیں اس کی حمایت کرنے کی کوئی پرواہ نہیں ہے۔
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// دیئے گئے `Arc` میں ایک متغیر حوالہ دیتا ہے۔
    ///
    /// اگر ایک ہی مختص کرنے کے لئے دوسرے `Arc` یا [`Weak`] پوائنٹر موجود ہیں تو ، پھر `make_mut` ایک نئی رقم مختص کرے گا اور منفرد ملکیت کو یقینی بنانے کے لئے [`clone`][clone] کو داخلی قدر پر منتج کرے گا۔
    /// اسے کلون آن لکھتے بھی کہا جاتا ہے۔
    ///
    /// نوٹ کریں کہ یہ [`Rc::make_mut`] کے طرز عمل سے مختلف ہے جو کسی بھی `Weak` پوائنٹرس کو الگ کرتا ہے۔
    ///
    /// [`get_mut`][get_mut] بھی دیکھیں ، جو کلوننگ کے بجائے ناکام ہوجائیں گے۔
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // کچھ بھی کلون نہیں کریں گے
    /// let mut other_data = Arc::clone(&data); // اندرونی ڈیٹا کو کلون نہیں کریں گے
    /// *Arc::make_mut(&mut data) += 1;         // کلون کا اندرونی ڈیٹا
    /// *Arc::make_mut(&mut data) += 1;         // کچھ بھی کلون نہیں کریں گے
    /// *Arc::make_mut(&mut other_data) *= 2;   // کچھ بھی کلون نہیں کریں گے
    ///
    /// // اب `data` اور `other_data` مختلف مختص کی طرف اشارہ کرتے ہیں۔
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // نوٹ کریں کہ ہمارے پاس مضبوط حوالہ اور کمزور حوالہ دونوں موجود ہیں۔
        // اس طرح ، ہمارے مضبوط حوالہ کو صرف جاری کرنے سے ، بذات خود ، یادداشت کا خاتمہ نہیں ہوگا۔
        //
        // ایکوائر کا استعمال یقینی بنائیں تاکہ ہم `weak` پر لکھنے والی کوئی بھی تحریر دیکھیں جو ریلیز سے پہلے رونما ہونے سے پہلے (یعنی کمی) `strong` پر لکھیں۔
        // چونکہ ہمارے پاس کمزور گنتی ہے ، لہذا اس بات کا کوئی امکان نہیں ہے کہ آرک اننر خود ہی شکست کھا جائے۔
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // ایک اور مضبوط پوائنٹر موجود ہے ، لہذا ہمیں کلون کرنا ہوگا۔
            // پہلے سے مختص شدہ میموری کو کلونڈ ویلیو کو براہ راست لکھنے کی اجازت دینے کیلئے۔
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // مذکورہ بالا میں آرام دہ کافی ہیں کیونکہ یہ بنیادی طور پر ایک اصلاح ہے: ہم ہمیشہ کمزور پوائنٹس کو چھوڑنے کے ساتھ دوڑ لگاتے ہیں۔
            // بدترین معاملہ ، ہم نے غیر ضروری طور پر ایک نیا آرک مختص کیا۔
            //

            // ہم نے آخری مضبوط ریفریج کو ہٹا دیا ، لیکن اس میں مزید ضعیف ریفریز باقی ہیں۔
            // ہم مشمولات کو ایک نئے آرک میں منتقل کریں گے ، اور دوسرے کمزور ریفیس کو باطل کردیں گے۔
            //

            // نوٹ کریں کہ `weak` کے پڑھنے کے لئے usize::MAX (یعنی ، مقفل) حاصل کرنا ممکن نہیں ہے ، کیوں کہ کمزور گنتی کو صرف ایک مضبوط حوالہ والے دھاگے کے ذریعہ لاک کیا جاسکتا ہے۔
            //
            //

            // ہمارے اپنے مضمر ضعیف اشارے کو مرتب کریں ، تاکہ یہ ضرورت کے مطابق آرک اننر کو صاف کرسکے۔
            //
            let _weak = Weak { ptr: this.ptr };

            // صرف ڈیٹا چوری کرسکتا ہے ، صرف ویکس باقی ہے
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ہم کسی بھی طرح کا واحد حوالہ تھے۔مضبوط ریف گنتی کو پیچھے چھوڑ دیں۔
            //
            this.inner().strong.store(1, Release);
        }

        // جیسا کہ `get_mut()` کی طرح ، بے یقینی ٹھیک ہے کیونکہ ہمارا حوالہ شروع کرنے کے لئے یا تو منفرد تھا ، یا مندرجات کی کلوننگ کرنے پر ایک بن گیا تھا۔
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// اگر ایک ہی مختص کرنے کے لئے کوئی دوسرا `Arc` یا [`Weak`] پوائنٹر نہیں ہیں تو ، دیئے گئے `Arc` میں ایک متغیر حوالہ واپس کرتا ہے۔
    ///
    ///
    /// دوسری صورت میں [`None`] لوٹاتا ہے ، کیونکہ مشترکہ قدر کو تبدیل کرنا محفوظ نہیں ہے۔
    ///
    /// یہ بھی دیکھیں [`make_mut`][make_mut] ، جو دوسرے پوائنٹر ہونے پر اندرونی قدر [`clone`][clone] کرے گا۔
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // یہ بے یقینی ٹھیک ہے کیونکہ ہمیں ضمانت دی گئی ہے کہ واپس کرنے والا پوائنٹر ہی *صرف* پوائنٹر ہے جو کبھی بھی T کو واپس کیا جائے گا۔
            // ہماری حوالہ شماری اس وقت 1 ہونے کی ضمانت ہے ، اور ہمیں خود آرک کی بھی ضرورت ہے `mut` ہونا چاہئے ، لہذا ہم داخلی اعداد و شمار کا واحد ممکنہ حوالہ واپس کر رہے ہیں۔
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// کسی چیک کے بغیر ، دیئے گئے `Arc` میں تغیر پزیر حوالہ لوٹاتا ہے۔
    ///
    /// یہ بھی دیکھیں [`get_mut`] ، جو محفوظ ہے اور مناسب جانچ پڑتال کرتا ہے۔
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ایک ہی مختص کرنے کے لئے کسی بھی دوسرے `Arc` یا [`Weak`] پوائنٹر کو واپس کیے گئے قرضوں کی مدت کے لئے حوالہ نہیں کیا جانا چاہئے۔
    ///
    /// یہ چھوٹی سی صورت میں ہے اگر ایسے کوئی اشارے موجود نہ ہوں ، مثال کے طور پر `Arc::new` کے فورا بعد۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ہم محتاط ہیں کہ *"count" فیلڈز کا احاطہ کرتے ہوئے کوئی* حوالہ نہ بنائیں ، کیونکہ یہ حوالہ گنتی تک ہم آہنگی رسائی کے ساتھ عرف ہوگا۔
        // بذریعہ `Weak`)۔
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// معلوم کریں کہ کیا یہ بنیادی اعداد و شمار کا انوکھا حوالہ ہے (جن میں کمزور ریف شامل ہیں)۔
    ///
    ///
    /// نوٹ کریں کہ اس کے لئے کمزور ریف گنتی کو لاک کرنا ضروری ہے۔
    fn is_unique(&mut self) -> bool {
        // اگر ہم واحد کمزور پوائنٹر ہولڈر معلوم ہوتے ہیں تو کمزور پوائنٹر گنتی کو مقفل کریں۔
        //
        // یہاں لیبل لیبل `weak` (خاص طور پر `Weak::upgrade` میں) `weak` گنتی (`Weak::drop` کے ذریعہ ، جو رہائی کا استعمال کرتا ہے) کی کمی سے قبل کسی بھی تحریر کے ساتھ تعلقات کو یقینی بناتا ہے۔
        // اگر اپ گریڈ شدہ کمزور ریف کو کبھی نہیں گرایا گیا تو ، یہاں کا CAS ناکام ہوجائے گا لہذا ہمیں ہم وقت سازی کی پرواہ نہیں ہے۔
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` میں `strong` کاؤنٹر کی کمی کے ساتھ مطابقت پذیر ہونے کے لئے اسے ایک `Acquire` ہونے کی ضرورت ہے۔ صرف رسائی ہی اس وقت ہوتی ہے جب کوئی بھی ہوتا ہے لیکن آخری حوالہ چھوڑ دیا جاتا ہے۔
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // یہاں ریلیز کا تحریر `downgrade` میں پڑھنے کے ساتھ ہم آہنگ ہوتا ہے ، اور `strong` کے مذکورہ بالا پڑھنے کو تحریر کے بعد ہونے سے روکتا ہے۔
            //
            //
            self.inner().weak.store(1, Release); // تالا جاری کریں
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` گرتا ہے۔
    ///
    /// اس سے مضبوط حوالہ شماری میں کمی آئے گی۔
    /// اگر مضبوط حوالہ شمار صفر تک پہنچ جاتا ہے تو صرف دوسرے حوالہ جات (اگر کوئی ہیں) [`Weak`] ہیں ، لہذا ہم داخلی قیمت کو `drop` کرتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // کچھ پرنٹ نہیں کرتا ہے
    /// drop(foo2);   // پرنٹ کریں "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // چونکہ `fetch_sub` پہلے ہی ایٹم ہے ، ہمیں دوسرے دھاگوں کے ساتھ ہم آہنگی کرنے کی ضرورت نہیں جب تک کہ ہم اس اعتراض کو حذف نہ کریں۔
        // یہ ایک ہی منطق `fetch_sub` کے نیچے X0X گنتی پر لاگو ہوتی ہے۔
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // ڈیٹا کے استعمال کو دوبارہ ترتیب دینے اور ڈیٹا کو حذف کرنے سے روکنے کے لئے اس باڑ کی ضرورت ہے۔
        // چونکہ اس کو `Release` نشان لگا دیا گیا ہے ، لہذا حوالہ شماری کا کم ہونا اس `Acquire` باڑ کے ساتھ ہم آہنگ ہوتا ہے۔
        // اس کا مطلب یہ ہے کہ ڈیٹا کا استعمال حوالہ شماری کو کم کرنے سے پہلے ہوتا ہے ، جو اس باڑ سے پہلے ہوتا ہے ، جو اعداد و شمار کو حذف کرنے سے پہلے ہوتا ہے۔
        //
        // جیسا کہ [Boost documentation][1] میں بیان کیا گیا ہے ،
        //
        // > ایک چیز میں کسی بھی ممکنہ رسائی کو نافذ کرنا ضروری ہے
        // > حذف کرنے سے پہلے * ہونے کیلئے دھاگے (موجودہ حوالہ کے ذریعے)
        // > ایک مختلف دھاگے میں اعتراض.یہ ایک "release" کے ذریعہ حاصل کیا گیا ہے
        // > حوالہ چھوڑنے کے بعد آپریشن (کسی بھی چیز تک رسائی)
        // > اس ریفرنس کے ذریعے واضح طور پر پہلے ہونا ضروری ہے) ، اور ایک
        // > "acquire" آبجیکٹ کو حذف کرنے سے پہلے آپریشن کریں۔
        //
        // خاص طور پر ، جب کہ آرک کے مندرجات عموما ناقابل تبدیلی ہوتے ہیں ، اس لئے ممکن ہے کہ کسی داخلے کو کسی خاموش کی طرح کچھ لکھ دیا جائے<T>.
        // چونکہ جب یہ حذف ہوجاتا ہے تو کوئی Mutex حاصل نہیں کیا جاتا ہے ، لہذا ہم دھاگے میں تحریریں بنانے کے ل its اس کی ہم وقت سازی کی منطق پر انحصار نہیں کرسکتے ہیں جو دھاگے B میں چلنے والے کسی ڈسٹرکٹور کے لئے مرئی ہے۔
        //
        //
        // یہ بھی نوٹ کریں کہ یہاں ایکوائر باڑ کو شاید ایکوائر بوجھ سے تبدیل کیا جاسکتا ہے ، جو انتہائی متنازعہ صورتحال میں کارکردگی کو بہتر بنا سکتا ہے۔[2] دیکھیں۔
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` کو کنکریٹ کی قسم پر گھٹانے کی کوشش کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// کسی بھی میموری کو مختص کیے بغیر ، نیا `Weak<T>` بناتا ہے۔
    /// [`upgrade`] کو واپسی کی قیمت پر کال کرنا ہمیشہ [`None`] دیتا ہے۔
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ڈیٹا فیلڈ کے بارے میں کوئی دعوی کیے بغیر حوالہ شماری تک رسائی کی اجازت دینے کیلئے مددگار کی قسم۔
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// اس `Weak<T>` کی طرف اشارہ کردہ آبجیکٹ `T` کی طرف ایک خام پوائنٹر لوٹاتا ہے۔
    ///
    /// پوائنٹر صرف اس صورت میں درست ہے جب کچھ مضبوط حوالہ جات ہوں۔
    /// ہوسکتا ہے کہ اشارہ پیچیدہ ، غیر دستخط شدہ یا [`null`] بھی ہو۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // دونوں ایک ہی چیز کی طرف اشارہ کرتے ہیں
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // یہاں کا طاقتور اسے زندہ رکھتا ہے ، لہذا ہم اب بھی اس چیز تک رسائی حاصل کرسکتے ہیں۔
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // مگر اب نہیں.
    /// // ہم weak.as_ptr() کرسکتے ہیں ، لیکن پوائنٹر تک پہنچنا غیر وضاحتی رویے کا باعث بنے گا۔
    /// // assert_eq! ("ہیلو" ، غیر محفوظ {&*weak.as_ptr() })؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // اگر پوائنٹر ڈینگ رہا ہے ، تو ہم سیدھا بھیج دیا جاتا ہے۔
            // یہ ایک درست پے لوڈ ایڈریس نہیں ہوسکتا ہے ، کیونکہ پے لوڈ کم از کم آرک آئنر ایکس00 ایکس کی طرح منسلک ہوتا ہے۔
            ptr as *const T
        } else {
            // حفاظت: اگر is_dangling غلط کو لوٹاتا ہے ، تو پھر پوائنٹر قابل تعزیر ہے۔
            // اس وقت پے لوڈ کو گرایا جاسکتا ہے ، اور ہمیں پروانوانس برقرار رکھنا ہے ، لہذا خام پوائنٹر ہیرا پھیری کا استعمال کریں۔
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` استعمال کرتا ہے اور اسے خام پوائنٹر میں بدل دیتا ہے۔
    ///
    /// یہ کمزور پوائنٹر کو خام پوائنٹر میں تبدیل کرتا ہے ، جبکہ اب بھی ایک کمزور حوالہ کی ملکیت کو محفوظ رکھتے ہوئے (کمزور گنتی کو اس آپریشن سے تبدیل نہیں کیا جاتا ہے)۔
    /// اسے [`from_raw`] کے ساتھ `Weak<T>` میں تبدیل کیا جاسکتا ہے۔
    ///
    /// [`as_ptr`] کے ساتھ ہی پوائنٹر کے ہدف تک رسائی کی وہی پابندیاں لاگو ہوتی ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// اس سے پہلے [`into_raw`] کے ذریعہ تیار کردہ ایک خام پوائنٹر کو `Weak<T>` میں تبدیل کرتا ہے۔
    ///
    /// اس کو مستحکم حوالہ حاصل کرنے کے لئے استعمال کیا جاسکتا ہے ([`upgrade`] کو بعد میں کال کرکے) یا `Weak<T>` کو چھوڑ کر کمزور گنتی کو ختم کرنا ہے۔
    ///
    /// یہ ایک ضعیف حوالہ کی ملکیت لیتا ہے ([`new`] کے ذریعہ تخلیق کردہ نکات کی رعایت کے ساتھ ، کیونکہ یہ کسی بھی چیز کے مالک نہیں ہیں؛ طریقہ اب بھی ان پر کام کرتا ہے)۔
    ///
    /// # Safety
    ///
    /// پوائنٹر کی ابتدا [`into_raw`] سے ہونی چاہئے اور اس کے اب بھی اس کے امکانی کمزور حوالہ کا مالک ہونا ضروری ہے۔
    ///
    /// اس کو کال کرنے کے وقت مضبوط گنتی 0 رکھنے کی اجازت ہے۔
    /// بہر حال ، اس میں ایک ضعیف حوالہ کی ملکیت لی گئی ہے جو فی الحال خام پوائنٹر کی حیثیت سے نمائندگی کی گئی ہے (اس آپریشن سے کمزور گنتی میں کوئی تبدیلی نہیں کی گئی ہے) اور اس لئے اسے [`into_raw`] پر سابقہ کال کے ساتھ جوڑا بنانا ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // آخری کمزور گنتی کو کم کریں۔
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ان پٹ پوائنٹر کس طرح نکالا جاتا ہے اس سیاق و سباق کے لئے Weak::as_ptr دیکھیں۔

        let ptr = if is_dangling(ptr as *mut T) {
            // یہ بے ربط کمزور ہے۔
            ptr as *mut ArcInner<T>
        } else {
            // بصورت دیگر ، ہم اس بات کی ضمانت دے رہے ہیں کہ پوائنٹر نونڈنگلنگ کمزور سے آیا ہے۔
            // سیفٹی: ڈیٹا_ آفسیٹ فون کرنا محفوظ ہے ، کیونکہ پی ٹی آر ایک حقیقی (ممکنہ طور پر گرا ہوا) ٹی کا حوالہ دیتا ہے۔
            let offset = unsafe { data_offset(ptr) };
            // اس طرح ، ہم پورے آر سی باکس کو حاصل کرنے کے لئے آفسیٹ کو پلٹ دیتے ہیں۔
            // حفاظت: اشارہ ایک کمزور سے ہوا ہے ، لہذا یہ آفسیٹ محفوظ ہے۔
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // محفوظ کریں: اب ہم نے اصل کمزور پوائنٹر کو بازیافت کرلیا ہے ، لہذا کمزور پیدا کرسکتے ہیں۔
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` پوائنٹر کو [`Arc`] میں اپ گریڈ کرنے کی کوششیں ، اگر کامیاب ہو تو داخلی قدر گرنے میں تاخیر کریں۔
    ///
    ///
    /// اگر داخلی قیمت گرا دی گئی ہو تو [`None`] واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // تمام مضبوط پوائنٹرز کو خارج کر دیں۔
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // ہم ایک fetch_add کی بجائے مضبوط گنتی میں اضافے کے لئے CAS لوپ کا استعمال کرتے ہیں کیونکہ اس فنکشن کو ریفرنس گنتی کو کبھی بھی صفر سے ایک میں نہیں لینا چاہئے۔
        //
        //
        let inner = self.inner()?;

        // آرام سے بوجھ کیونکہ 0 کا کوئی بھی تحریر جس پر ہم مشاہدہ کرسکتے ہیں وہ کھیت کو مستقل طور پر صفر حالت میں چھوڑ دیتا ہے (لہذا 0 کا ایک "stale" ٹھیک ہے) ، اور کسی بھی دوسری قیمت کی تصدیق ذیل میں CAS کے ذریعہ ہوتی ہے۔
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // ہم یہ کیوں کرتے ہیں اس کے لئے `Arc::clone` میں تبصرے دیکھیں (`mem::forget` کے لئے)۔
            if n > MAX_REFCOUNT {
                abort();
            }

            // آرام دہ اور پرسکون ناکامی کے معاملے میں ٹھیک ہے کیونکہ ہمیں نئی ریاست کے بارے میں کوئی توقع نہیں ہے۔
            // کامیابی کے معاملے کو `Arc::new_cyclic` کے ساتھ ہم آہنگی پیدا کرنے کے لئے حصول ضروری ہے ، جب `Weak` حوالہ جات پہلے ہی تیار کیے جانے کے بعد داخلی قدر کی ابتدا کی جاسکتی ہے۔
            // اس صورت میں ، ہم توقع کرتے ہیں کہ مکمل طور پر شروع شدہ قیمت کا مشاہدہ کریں۔
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // منسوخ اوپر
                Err(old) => n = old,
            }
        }
    }

    /// اس مختص کی طرف اشارہ کرنے والے مضبوط (`Arc`) پوائنٹرز کی تعداد حاصل کرتی ہے۔
    ///
    /// اگر `self` [`Weak::new`] کا استعمال کرتے ہوئے تخلیق کیا گیا تھا ، تو یہ 0 واپس آئے گا۔
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// اس مختص کی طرف اشارہ کرتے ہوئے `Weak` پوائنٹرز کی تعداد کا اندازہ ہوتا ہے۔
    ///
    /// اگر `self` کو [`Weak::new`] کا استعمال کرتے ہوئے تشکیل دیا گیا تھا ، یا اگر کوئی مضبوط پختہ کار باقی نہیں ہے تو ، یہ 0 لوٹ آئے گا۔
    ///
    /// # Accuracy
    ///
    /// نفاذ کی تفصیلات کی وجہ سے ، جب واپسی والے دھاگے کسی بھی سمت میں 1 کے ذریعہ بند ہوسکتے ہیں جب دوسرے دھاگے اسی مختص کی طرف اشارہ کرتے ہوئے کسی بھی `آرک یا` کمزوروں کو جوڑ رہے ہیں۔
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // چونکہ ہم نے مشاہدہ کیا ہے کہ کمزور گنتی کو پڑھنے کے بعد کم از کم ایک مضبوط اشارہ موجود تھا ، لہذا ہم جانتے ہیں کہ جب ہم نے کمزور گنتی کا مشاہدہ کیا تو اس کا مضمر ضعیف حوالہ (جب بھی کوئی مضبوط حوالہ زندہ ہوتا ہے) موجود تھا۔
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// `None` لوٹاتا ہے جب پوائنٹر میں خستہ ہوتا ہے اور کوئی مختص `ArcInner` نہیں ہوتا ہے ، (یعنی ، جب یہ `Weak` `Weak::new` کے ذریعہ بنایا گیا تھا)۔
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ہم محتاط ہیں کہ "data" فیلڈ کا احاطہ کرتے ہوئے کوئی * حوالہ نہ بنائیں ، کیوں کہ فیلڈ کو بیک وقت تبدیل کیا جاسکتا ہے (مثال کے طور پر ، اگر آخری `Arc` کو گرا دیا جائے تو ، ڈیٹا فیلڈ کو جگہ جگہ چھوڑ دیا جائے گا)۔
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// اگر دو `کمزور ایک ہی مختص ([`ptr::eq`] کی طرح) کی طرف اشارہ کرتے ہیں ، یا اگر دونوں کسی بھی مختص کی طرف اشارہ نہیں کرتے ہیں تو `true` کی واپسی کرتا ہے (کیونکہ وہ `Weak::new()`) کے ساتھ بنی ہیں۔
    ///
    ///
    /// # Notes
    ///
    /// چونکہ اس نکات کا موازنہ کرتا ہے اس کا مطلب یہ ہے کہ `Weak::new()` ایک دوسرے کے برابر ہوں گے ، حالانکہ وہ کسی بھی مختص کی طرف اشارہ نہیں کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` کا موازنہ کرنا۔
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` پوائنٹر کا ایک کلون بناتا ہے جو ایک ہی مختص کی طرف اشارہ کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // اس میں نرمی کیوں ہے اس کے لئے Arc::clone() میں تبصرے دیکھیں۔
        // یہ ایک بازیافت_اضافہ (تالا کو نظرانداز کرنے) کا استعمال کرسکتا ہے کیونکہ کمزور گنتی صرف اس جگہ مقفل ہوتی ہے جہاں *کوئی دوسرا* کمزور نقطہ موجود نہیں ہوتا ہے۔
        //
        // (لہذا ہم اس کوڈ میں اس صورت میں نہیں چل سکتے)۔
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // ہم یہ کیوں کرتے ہیں اس کے لئے Arc::clone() میں تبصرے دیکھیں (mem::forget کے لئے)۔
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// میموری کو مختص کیے بغیر ، نیا `Weak<T>` تشکیل دیتا ہے۔
    /// [`upgrade`] کو واپسی کی قیمت پر کال کرنا ہمیشہ [`None`] دیتا ہے۔
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` پوائنٹر گرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // کچھ پرنٹ نہیں کرتا ہے
    /// drop(foo);        // پرنٹ کریں "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // اگر ہمیں پتہ چلتا ہے کہ ہم آخری کمزور پوائنٹر تھے ، تو پھر اس وقت کو مکمل طور پر ڈیٹا لوٹ کرنے کا۔میموری آرڈرنگ کے بارے میں Arc::drop() میں گفتگو دیکھیں
        //
        // یہاں مقفل حالت کی جانچ کرنا ضروری نہیں ہے ، کیونکہ کمزور گنتی کو صرف اس صورت میں تالا لگایا جاسکتا ہے جب بالکل ہی ایک کمزور ریف موجود ہوتا ہے ، یعنی اس ڈراپ کے بعد باقی بچنے والے ضعیف ریف کو ہی چلایا جاسکتا ہے ، جو تالا کے اجراء کے بعد ہی ہوسکتا ہے۔
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ہم یہاں یہ تخصص کررہے ہیں ، اور نہ کہ `&T` پر زیادہ عمومی اصلاح کے طور پر ، کیوں کہ اس سے ریفوں پر مساوات کی تمام جانچ پڑتال میں لاگت آئے گی۔
/// ہم فرض کرتے ہیں کہ values آرک large بڑی اقدار کو ذخیرہ کرنے کے لئے استعمال کیا جاتا ہے ، جو کلون کرنے میں سست ہیں ، لیکن مساوات کی جانچ پڑتال میں بھی بھاری ہیں ، جس کی وجہ سے اس لاگت کا آسانی سے ادائیگی ہوجاتا ہے۔
///
/// اس کے دو `Arc` کلون ہونے کا بھی زیادہ امکان ہے ، جو ایک ہی قدر کی طرف اشارہ کرتے ہیں ، دو `&T`s سے۔
///
/// ہم صرف اس وقت کر سکتے ہیں جب `T: Eq` بطور X01 ایکس جان بوجھ کر غیر مجاز ہوسکتا ہے۔
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// دو `آرک for کیلئے مساوات۔
    ///
    /// دو `آرک برابر ہیں اگر ان کی داخلی اقدار برابر ہوں ، چاہے وہ مختلف مختص میں محفوظ ہوں۔
    ///
    /// اگر `T` بھی `Eq` (مساوات کے اضطراب) کا نفاذ کرتا ہے تو ، دو مختص ایک جیسے مختص کرنے کی طرف اشارہ کرتے ہیں ہمیشہ برابر رہتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// دو `آرک for کیلئے عدم مساوات۔
    ///
    /// اگر ان کی داخلی اقدار غیر مساوی ہیں تو دو `آرک غیر مساوی ہیں۔
    ///
    /// اگر `T` بھی `Eq` (مساوات کا اضطراب) لاگو کرتا ہے تو ، ایک ہی قدر کی طرف اشارہ کرنے والے دو `آرک never کبھی بھی غیر مساوی نہیں ہوتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// دو `آرک for کے لئے جزوی موازنہ۔
    ///
    /// دونوں کا موازنہ `partial_cmp()` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// دو `آرک for کے لئے مقابلے سے کم۔
    ///
    /// دونوں کا موازنہ `<` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// دو `آرک کے لئے موازنہ 'سے کم یا اس کے برابر'۔
    ///
    /// دونوں کا موازنہ `<=` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// دو سے زیادہ کے مقابلے for آرک ater
    ///
    /// دونوں کا موازنہ `>` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// دو `آرک کے لئے موازنہ 'سے زیادہ یا اس کے برابر'۔
    ///
    /// دونوں کا موازنہ `>=` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// دو `آرکس کے لئے موازنہ.
    ///
    /// دونوں کا موازنہ `cmp()` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` کی `Default` قدر کے ساتھ ، ایک نیا `Arc<T>` تشکیل دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// حوالہ گنتی سلائس مختص کریں اور `v` کے آئٹمز کو کلوننگ کرکے بھریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// ایک حوالہ گنتی `str` الاٹ کریں اور اس میں `v` کاپی کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// ایک حوالہ گنتی `str` الاٹ کریں اور اس میں `v` کاپی کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ایک باکسڈ آبجیکٹ کو ایک نئے ، حوالہ سے گنتی والے مختص پر منتقل کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// حوالہ گنتی والی سلائس مختص کریں اور اس میں آئٹمز منتقل کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // وی ای سی کو اپنی میموری کو آزاد کرنے کی اجازت دیں ، لیکن اس کے مندرجات کو برباد نہ کریں
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// ہر عنصر کو `Iterator` میں لے جاتا ہے اور اسے `Arc<[T]>` میں جمع کرتا ہے۔
    ///
    /// # کارکردگی کی خصوصیات
    ///
    /// ## عام معاملہ
    ///
    /// عام حالت میں ، `Arc<[T]>` میں جمع کرنا پہلے `Vec<T>` میں جمع کرکے کیا جاتا ہے۔یہ ، جب مندرجہ ذیل لکھتے ہو:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// یہ اس طرح برتاؤ کرتا ہے جیسے ہم نے لکھا ہے:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // مختص کا پہلا سیٹ یہاں ہوتا ہے۔
    ///     .into(); // `Arc<[T]>` کے لئے دوسرا مختص یہاں ہوتا ہے۔
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// یہ `Vec<T>` کی تعمیر کے لئے ضرورت کے مطابق کئی بار مختص کرے گا اور پھر یہ `Vec<T>` کو `Arc<[T]>` میں تبدیل کرنے کے لئے ایک بار مختص ہوگا۔
    ///
    ///
    /// ## معلوم لمبائی کے منتظم
    ///
    /// جب آپ کا `Iterator` `TrustedLen` لاگو کرتا ہے اور اس کا سائز بالکل درست ہوتا ہے تو ، `Arc<[T]>` کے لئے ایک ہی رقم مختص کی جائے گی۔مثال کے طور پر:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // یہاں صرف ایک مختص ہوتا ہے۔
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` میں جمع کرنے کے لئے استعمال کی جانے والی تخصص trait۔
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // یہ معاملہ ایک `TrustedLen` ریڈیٹر کے لئے ہے۔
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // حفاظت: ہمیں یہ یقینی بنانا ہوگا کہ تکرار کرنے والی شخص کی لمبائی ٹھیک ہے اور ہمارے پاس ہے۔
                Arc::from_iter_exact(self, low)
            }
        } else {
            // عام نفاذ پر واپس گریں۔
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ایک پوائنٹر کے پیچھے پے لوڈ کیلئے `ArcInner` کے اندر آفسیٹ حاصل کریں۔
///
/// # Safety
///
/// پوائنٹر کو T کی ایک درست مثال کے طور پر (اور اس کے لئے درست میٹا ڈیٹا ہونا چاہئے) کی طرف اشارہ کرنا چاہئے ، لیکن T کو چھوڑنے کی اجازت ہے۔
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // آرک اننر کے اختتام تک غیر متوازن قدر کو سیدھ کریں۔
    // کیونکہ RcBox repr(C) ہے ، یہ ہمیشہ میموری کا آخری میدان ہوگا۔
    // سلامتی: چونکہ صرف غیر منحصر اقسام ہی ممکن ہیں ٹکڑے ، trait اشیاء ،
    // اور بیرونی اقسام ، ان پٹ حفاظت کی ضرورت فی الحال align_of_val_raw کی ضروریات کو پورا کرنے کے لئے کافی ہے۔یہ زبان کی نفاذ کی تفصیل ہے جس پر std کے باہر انحصار نہیں کیا جاسکتا ہے۔
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}