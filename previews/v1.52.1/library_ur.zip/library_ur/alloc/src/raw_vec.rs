#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// نئی میموری کے مشمولات کو غیر متعل areق کردیا گیا ہے۔
    Uninitialized,
    /// نئی میموری کی صفر ہونے کی ضمانت ہے۔
    Zeroed,
}

/// اس میں شامل تمام کونے کے معاملات کی فکر کرنے کے بغیر ڈھیر پر میموری کے بفر کو زیادہ مختص کرنا ، دوبارہ عمل کرنا اور اس کی کمی کرنا کیلئے ایک نچلی سطح کی افادیت۔
///
/// یہ آپ کے اپنے ڈیٹا ڈھانچے جیسے Vec اور VecDeque کی تعمیر کے لئے بہترین ہے۔
/// خاص طور پر:
///
/// * صفر سائز کی اقسام پر `Unique::dangling()` تیار کرتا ہے۔
/// * صفر لمبائی کے مختص پر `Unique::dangling()` تیار کرتا ہے۔
/// * `Unique::dangling()` کو آزاد کرنے سے پرہیز کریں۔
/// * صلاحیت کے حساب میں تمام بہاؤ کو پکڑتا ہے (ان کو "capacity overflow" panics میں ترقی دیتا ہے)۔
/// * isize::MAX بائٹس سے زیادہ مختص 32 بٹ سسٹم کے خلاف گارڈز۔
/// * آپ کی لمبائی کو بہاو کے خلاف گارڈز۔
/// * ناقص مختص کیلئے `handle_alloc_error` کو کال کریں۔
/// * ایک `ptr::Unique` پر مشتمل ہے اور اس طرح صارف سے متعلقہ تمام فوائد حاصل کرتا ہے۔
/// * سب سے بڑی دستیاب صلاحیت استعمال کرنے کے لئے مختص کنندہ سے واپس کی گئی اضافی مقدار کا استعمال کریں۔
///
/// اس نوعیت سے کسی بھی طرح اس میموری کا معائنہ نہیں ہوتا ہے جو اس کا نظم کرتی ہے۔جب اسے گرا دیا جائے گا * تو یہ اپنی میموری کو آزاد کردے گا ، لیکن وہ اس کے مندرجات کو چھوڑنے کی کوشش نہیں کرے گا۔
/// `RawVec` کے صارف پر منحصر ہے کہ وہ `RawVec` کے اندر موجود چیزوں *ذخیرہ* کو سنبھال سکے۔
///
/// نوٹ کریں کہ صفر سائز کی اقسام کی زیادتی ہمیشہ لامحدود ہوتی ہے ، لہذا `capacity()` ہمیشہ `usize::MAX` کو لوٹاتا ہے۔
/// اس کا مطلب یہ ہے کہ آپ کو `Box<[T]>` کی مدد سے اس وقت کو محتاط رہنے کی ضرورت ہے ، کیونکہ `capacity()` لمبائی حاصل نہیں کرے گا۔
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): یہ موجود ہے کیونکہ `#[unstable]` `const fn`s کو `min_const_fn` کے مطابق ہونے کی ضرورت نہیں ہے اور اس لئے انہیں`min_const_fn`s میں بھی نہیں بلایا جاسکتا ہے۔
    ///
    /// اگر آپ `RawVec<T>::new` یا انحصار تبدیل کرتے ہیں تو ، براہ کرم احتیاط برتیں کہ ایسی کوئی بھی چیز متعارف نہ کرو جس سے واقعی `min_const_fn` کی خلاف ورزی ہو۔
    ///
    /// NOTE: ہم اس ہیک سے بچ سکتے ہیں اور کچھ `#[rustc_force_min_const_fn]` وصف کے ساتھ مطابقت کی جانچ کرسکتے ہیں جس کے لئے `min_const_fn` کے ساتھ تعمیل کی ضرورت ہوتی ہے لیکن ضروری نہیں ہے کہ `stable(...) const fn`/صارف کوڈ میں فون کرنے کی اجازت نہ دیں جب `#[rustc_const_unstable(feature = "foo", issue = "01234")]` موجود ہے تو
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// بغیر مختص کیے سب سے بڑا `RawVec` (سسٹم ہیپ پر) بناتا ہے۔
    /// اگر `T` کا مثبت سائز ہے ، تو پھر یہ `RawVec` کی صلاحیت کے ساتھ `0` بناتا ہے۔
    /// اگر `T` صفر سائز کا ہے تو ، پھر یہ `RawVec` کی صلاحیت کے ساتھ X بناتا ہے۔
    /// تاخیر سے مختص رقم کو نافذ کرنے کے لئے کارآمد۔
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// ایک `[T; capacity]` ایکس (نظام کے ڈھیر پر) ایک `[T; capacity]` کے ل exactly بالکل گنجائش اور سیدھ تقاضوں کے ساتھ بناتا ہے۔
    /// یہ `RawVec::new` پر کال کرنے کے مترادف ہے جب `capacity` `0` ہے یا `T` صفر سائز کا ہے۔
    /// نوٹ کریں کہ اگر `T` صفر سائز کا ہے تو اس کا مطلب ہے کہ آپ کو درخواست کی گنجائش کے ساتھ `RawVec` نہیں مل سکے گا۔
    ///
    /// # Panics
    ///
    /// Panics اگر درخواست کی گنجائش `isize::MAX` بائٹس سے زیادہ ہے۔
    ///
    /// # Aborts
    ///
    /// OOM پر رہتا ہے۔
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` کی طرح ، لیکن ضمانت دیتا ہے کہ بفر صفر ہے۔
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// ایک پوائنٹر اور صلاحیت سے ایک `RawVec` کی تشکیل کرتا ہے۔
    ///
    /// # Safety
    ///
    /// `ptr` مختص کیا جانا چاہئے (سسٹم کے ڈھیر پر) ، اور دیئے گئے `capacity` کے ساتھ۔
    /// `capacity` سائز کی اقسام کے لئے `isize::MAX` سے تجاوز نہیں کرسکتا ہے۔(صرف 32 بٹ سسٹم پر تشویش ہے)۔
    /// ZST vectors میں `usize::MAX` تک کی گنجائش ہوسکتی ہے۔
    /// اگر `ptr` اور `capacity` `RawVec` سے آئے ، تو اس کی ضمانت ہے۔
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // ٹنی ویکس گونگے ہیں۔اس پر جائیں:
    // - 8 اگر عنصر کا سائز 1 ہے ، کیونکہ کسی بھی ڈھیر کو مختص کرنے والے 8 بائٹس سے کم کی درخواست کو کم سے کم 8 بائٹس تک لے جانے کا امکان رکھتے ہیں۔
    //
    // - 4 اگر عنصر معتدل سائز (<=1 KiB) ہوں۔
    // - 1 دوسری صورت میں ، بہت ہی مختصر Vecs کے لئے زیادہ جگہ ضائع ہونے سے بچنے کے ل.۔
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` کی طرح ، لیکن واپس شدہ `RawVec` کے لئے مختص کرنے والے کے انتخاب پر پیرامیٹرائزڈ۔
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" کا مطلب ہے۔صفر سائز کی اقسام کو نظرانداز کیا جاتا ہے۔
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` کی طرح ، لیکن واپس شدہ `RawVec` کے لئے مختص کرنے والے کے انتخاب پر پیرامیٹرائزڈ۔
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` کی طرح ، لیکن واپس شدہ `RawVec` کے لئے مختص کرنے والے کے انتخاب پر پیرامیٹرائزڈ۔
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` کو `RawVec<T>` میں تبدیل کرتا ہے۔
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// پورے بفر کو مخصوص `len` کے ساتھ `Box<[MaybeUninit<T>]>` میں تبدیل کرتا ہے۔
    ///
    /// نوٹ کریں کہ یہ `cap` تبدیلیاں جو صحیح طور پر انجام دی گئی ہیں ان کی بحالی کرے گی۔(تفصیلات کے ل type قسم کی تفصیل ملاحظہ کریں۔)
    ///
    /// # Safety
    ///
    /// * `len` حالیہ درخواست کی گنجائش سے زیادہ یا اس کے برابر ہونا چاہئے ، اور
    /// * `len` `self.capacity()` سے کم یا اس کے برابر ہونا چاہئے۔
    ///
    /// نوٹ ، کہ درخواست کی گنجائش اور `self.capacity()` مختلف ہوسکتے ہیں ، کیونکہ ایک مختص کنندہ مجموعی طور پر درخواست کرسکتا ہے اور زیادہ میموری میموری کو واپس کرسکتا ہے۔
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // حفاظت کی ضرورت کا ایک آدھا تقویت چیک کریں (ہم دوسرے نصف کی جانچ نہیں کرسکتے ہیں)۔
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // ہم یہاں `unwrap_or_else` سے بچتے ہیں کیونکہ اس سے پیدا ہونے والی LLVM IR کی مقدار کو پھولا جاتا ہے۔
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// ایک پوائنٹر ، صلاحیت اور مختص کرنے والے سے `RawVec` کی تشکیل کرتا ہے۔
    ///
    /// # Safety
    ///
    /// `ptr` مختص کیا جانا چاہئے (دیئے گئے مختص کنندہ `alloc` کے ذریعے) ، اور دیئے گئے `capacity` کے ساتھ۔
    /// `capacity` سائز کی اقسام کے لئے `isize::MAX` سے تجاوز نہیں کرسکتا ہے۔
    /// (صرف 32 بٹ سسٹم پر تشویش ہے)۔
    /// ZST vectors میں `usize::MAX` تک کی گنجائش ہوسکتی ہے۔
    /// اگر `ptr` اور `capacity` `alloc` کے ذریعے بنی `RawVec` سے آئے ہیں ، تو اس کی ضمانت ہے۔
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// مختص کے آغاز کے لئے ایک خام اشارہ ملتا ہے۔
    /// نوٹ کریں کہ یہ `Unique::dangling()` ہے اگر `capacity == 0` یا `T` صفر سائز کا ہے۔
    /// سابقہ معاملے میں ، آپ کو محتاط رہنا چاہئے۔
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// مختص کی صلاحیت حاصل کرتا ہے۔
    ///
    /// اگر `T` صفر سائز کا ہو تو یہ ہمیشہ `usize::MAX` رہے گا۔
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// اس `RawVec` کی پشت پناہی کرنے والے مختص کرنے والے کا مشترکہ حوالہ لوٹاتا ہے۔
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // ہمارے پاس میموری کا ایک مختص حصہ ہے ، لہذا ہم اپنی موجودہ ترتیب حاصل کرنے کے لئے رن ٹائم چیک کو نظرانداز کرسکتے ہیں۔
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// اس بات کو یقینی بناتا ہے کہ بفر میں `len + additional` عناصر کے ل. کم از کم کافی جگہ موجود ہو۔
    /// اگر اس میں پہلے سے ہی اتنی گنجائش نہیں ہے تو ، امورائزڈ *O*(1) سلوک کرنے کیلئے کافی جگہ کے علاوہ آرام دہ اور پرسکون سلیک اسپیس کو دوبارہ گنتی جائے گی۔
    ///
    /// اس طرز عمل کو محدود کردے گا اگر یہ بے ضرورت طور پر خود کو panic کی وجہ بنتا ہے۔
    ///
    /// اگر `len` `self.capacity()` سے زیادہ ہو تو ، یہ واقعی میں درخواست کی گئی جگہ کو مختص کرنے میں ناکام ہوسکتا ہے۔
    /// یہ واقعی غیر محفوظ نہیں ہے ، لیکن غیر محفوظ کوڈ *آپ* لکھتے ہیں جو اس فنکشن کے طرز عمل پر انحصار کرتا ہے وہ ٹوٹ سکتا ہے۔
    ///
    /// یہ `extend` جیسے بلک پش آپریشن کو نافذ کرنے کے لئے مثالی ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `isize::MAX` بائٹس سے زیادہ ہے۔
    ///
    /// # Aborts
    ///
    /// OOM پر رہتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // اگر لین `isize::MAX` سے تجاوز کر گیا ہے تو ریزرو کو اسقاط یا گھبراہٹ میں مبتلا کردیا جائے گا لہذا اب یہ چیک نہ کرنا محفوظ ہے۔
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` جیسا ہی ہے ، لیکن گھبرانے یا اسقاط حمل کرنے کی بجائے غلطیوں پر لوٹتا ہے۔
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// اس بات کو یقینی بناتا ہے کہ بفر میں `len + additional` عناصر کے ل. کم از کم کافی جگہ موجود ہو۔
    /// اگر یہ پہلے سے نہیں ہے تو ، ضروری میموری کی کم از کم ممکنہ مقدار کو دوبارہ سے نامزد کریں گے۔
    /// عام طور پر یہ بالکل ضروری میموری کی مقدار ہو گی ، لیکن اصولی طور پر مختص کرنے والا آزاد ہے جس سے ہم نے کہا ہے اس سے زیادہ واپس کردیں گے۔
    ///
    ///
    /// اگر `len` `self.capacity()` سے زیادہ ہو تو ، یہ واقعی میں درخواست کی گئی جگہ کو مختص کرنے میں ناکام ہوسکتا ہے۔
    /// یہ واقعی غیر محفوظ نہیں ہے ، لیکن غیر محفوظ کوڈ *آپ* لکھتے ہیں جو اس فنکشن کے طرز عمل پر انحصار کرتا ہے وہ ٹوٹ سکتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `isize::MAX` بائٹس سے زیادہ ہے۔
    ///
    /// # Aborts
    ///
    /// OOM پر رہتا ہے۔
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` جیسا ہی ہے ، لیکن گھبرانے یا اسقاط حمل کرنے کی بجائے غلطیوں پر لوٹتا ہے۔
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// مختص رقم کو مختص کرکے کم کردیتا ہے۔
    /// اگر دی گئی رقم 0 ہے تو ، دراصل مکمل طور پر ختم ہوجاتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر دی گئی رقم موجودہ صلاحیت سے *بڑی* ہے۔
    ///
    /// # Aborts
    ///
    /// OOM پر رہتا ہے۔
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// مطلوبہ اضافی صلاحیت کو پورا کرنے کے ل the اگر بفر کو بڑھنے کی ضرورت ہو تو لوٹ آتی ہے۔
    /// بنیادی طور پر ان لائننگ ریزرو کالز کرنے کے لئے استعمال کیا جاتا ہے جس میں `grow` ان لائن کیے بغیر ممکن ہو۔
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // یہ طریقہ عام طور پر کئی بار انسٹی ٹیٹ ہوتا ہے۔لہذا ہم چاہتے ہیں کہ کم سے کم وقت ہو ، مرتب وقت کو بہتر بنائے۔
    // لیکن ہم یہ بھی چاہتے ہیں کہ اس کے زیادہ سے زیادہ مشمولات اعدادوشمار کے حساب سے قابل بنائے جائیں ، تاکہ پیدا کردہ کوڈ کو تیزی سے چلایا جاسکے۔
    // لہذا ، یہ طریقہ احتیاط سے لکھا گیا ہے تاکہ `T` پر انحصار کرنے والے تمام کوڈ اس کے اندر موجود ہوں ، جبکہ زیادہ سے زیادہ کوڈ جو `T` پر انحصار نہیں کرتا ہے ان افعال میں ہے جو `T` سے زیادہ غیر عام ہیں۔
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // یہ بات کالنگ سیاق و سباق سے یقینی ہے۔
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // چونکہ ہم `usize::MAX` کی صلاحیت واپس کرتے ہیں جب `elem_size` ہوتا ہے
            // 0 ، یہاں پہنچنے کا لازمی مطلب ہے کہ `RawVec` حد سے زیادہ ہے۔
            return Err(CapacityOverflow);
        }

        // افسوس کے ساتھ ، ان چیکوں کے بارے میں ہم واقعی کچھ نہیں کرسکتے ہیں۔
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // یہ صریحی نمو کی ضمانت دیتا ہے۔
        // ڈبلنگ اتپرواہ نہیں ہوسکتی ہے کیونکہ `cap <= isize::MAX` اور `cap` کی قسم `usize` ہے۔
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` سے زیادہ غیر عام ہے۔
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // اس طریقہ کار کی رکاوٹیں `grow_amortized` کی طرح ہی ہیں ، لیکن یہ طریقہ عام طور پر کم کثرت سے پیش کیا جاتا ہے لہذا یہ کم ضروری ہے۔
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // چونکہ جب قسم کا سائز ہوتا ہے تو ہم `usize::MAX` کی صلاحیت واپس کرتے ہیں
            // 0 ، یہاں پہنچنے کا لازمی مطلب ہے کہ `RawVec` حد سے زیادہ ہے۔
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` سے زیادہ غیر عام ہے۔
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// مرتب وقت کو کم سے کم کرنے کے لئے یہ فنکشن `RawVec` سے باہر ہے۔تفصیلات کے لئے `RawVec::grow_amortized` کے اوپر تبصرہ ملاحظہ کریں۔
// (`A` پیرامیٹر اہم نہیں ہے ، کیونکہ عملی طور پر مختلف `A` اقسام کی تعداد `T` اقسام کی تعداد سے بہت کم ہے۔)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` کے سائز کو کم سے کم کرنے کے لئے یہاں خرابی کی جانچ کریں۔
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // مختص کرنے والا سیدھ مساوات کی جانچ کرتا ہے
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*کی ملکیت میموری کو آزاد کر دیتا ہے* اس کے مندرجات کو چھوڑنے کی کوشش کیے بغیر۔
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// ریزرو کی خرابی سے نمٹنے کے لئے مرکزی تقریب
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// ہمیں مندرجہ ذیل کی ضمانت دینے کی ضرورت ہے۔
// * ہم کبھی بھی `> isize::MAX` بائٹ سائز اشیاء کو مختص نہیں کرتے ہیں۔
// * ہم `usize::MAX` کو اتنا زیادہ نہیں بہتے اور درحقیقت بہت کم مختص کرتے ہیں۔
//
// ہمیں 64 بٹ پر صرف اتنا بہاو کی جانچ پڑتال کرنے کی ضرورت ہے کیونکہ `> isize::MAX` بائٹ مختص کرنے کی کوشش ناکام ہوجائے گی۔
// 32 بٹ اور 16 بٹ پر ہمیں اس کے ل an ایک اضافی گارڈ شامل کرنے کی ضرورت ہے اگر ہم کسی ایسے پلیٹ فارم پر چل رہے ہیں جو صارف کی جگہ میں 4 جی بی ، جیسے PAE یا x32 استعمال کرسکے۔
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// صلاحیت کے بہاؤ کی اطلاع دہندگی کے لئے ذمہ دار ایک مرکزی تقریب۔
// اس بات کو یقینی بنائے گا کہ ان panics سے متعلق کوڈ جنریشن کم سے کم ہے کیونکہ وہاں صرف ایک ہی جگہ ہے جو ماڈیول میں ایک جھنڈ کے بجائے panics ہے۔
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}