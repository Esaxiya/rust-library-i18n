//! مختص Prelude
//!
//! اس ماڈیول کا مقصد `alloc` crate کی عام طور پر استعمال شدہ اشیاء کی درآمدات کو ختم کرنا ہے جو ماڈیول کے اوپری حصے میں عالمی سطح پر درآمد شامل کرکے:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;