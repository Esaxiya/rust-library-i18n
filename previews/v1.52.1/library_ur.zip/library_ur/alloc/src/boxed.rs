//! ڈھیر مختص کرنے کے لئے ایک پوائنٹر کی قسم۔
//!
//! [`Box<T>`], اتفاق سے 'box' کے طور پر جانا جاتا ہے ، Rust میں ڈھیر مختص کرنے کی آسان ترین شکل فراہم کرتا ہے۔بکس اس مختص کے لئے ملکیت مہیا کرتے ہیں ، اور جب اس کا دائرہ کار سے ہٹ جاتے ہیں تو ان کے مندرجات چھوڑ دیتے ہیں۔بکس یہ بھی یقینی بناتے ہیں کہ وہ کبھی بھی X01 بائٹس سے زیادہ مختص نہیں کرتے ہیں۔
//!
//! # Examples
//!
//! ایک [`Box`] بنا کر ڈھیر سے ڈھیر پر ایک قدر منتقل کریں:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! [`Box`] سے ایک قدر کو [dereferencing] کے ذریعہ اسٹیک پر واپس جائیں:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! اعداد و شمار کے بار بار ساخت کا تشکیل:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! اس سے `Cons (1 ، Cons(2, Nil))`.
//!
//! تکرار کرنے والے ڈھانچے کو باکسنگ کرنا ضروری ہے ، کیونکہ اگر `Cons` کی تعریف اس طرح دکھائی دیتی ہے تو:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! یہ کام نہیں کرے گا۔اس کی وجہ یہ ہے کہ `List` کا سائز اس بات پر منحصر ہے کہ فہرست میں کتنے عناصر ہیں ، اور لہذا ہم نہیں جانتے کہ `Cons` کے لئے کتنی میموری مختص کی جائے۔ایک [`Box<T>`] متعارف کروا کر ، جس کی وضاحت سائز ہے ، ہم جانتے ہیں کہ کتنا بڑا `Cons` ہونا ضروری ہے۔
//!
//! # میموری کی ترتیب
//!
//! غیر صفر سائز والے اقدار کے ل a ، ایک [`Box`] اس کے مختص کے لئے [`Global`] مختص کنندہ کا استعمال کرے گا۔[`Box`] اور [`Global`] مختص کنندہ کے ساتھ مختص شدہ خام پوائنٹر کے مابین دونوں طریقوں کو تبدیل کرنا درست ہے ، بشرطیکہ مختص کرنے والے کے ساتھ استعمال ہونے والا [`Layout`] اس قسم کے لئے درست ہے۔
//!
//! زیادہ واضح طور پر ، ایک `value:*mut T` جو [`Global`] مختص کنندہ کے ساتھ `Layout::for_value(&* value)` کے ساتھ مختص کیا گیا ہے اسے [`Box::<T>::from_raw(value)`] کا استعمال کرتے ہوئے ایک خانے میں تبدیل کیا جاسکتا ہے۔
//! اس کے برعکس ، [`Box::<T>::into_raw`] سے حاصل کردہ `value:*mut T` کی پشت پناہی کرنے والی میموری کو [`Layout::for_value(&* value)`] کے ساتھ [`Global`] مختص کار کا استعمال کرتے ہوئے خارج کیا جاسکتا ہے۔
//!
//! صفر سائز والے اقدار کے ل reads ، `Box` پوائنٹر کو ابھی بھی پڑھنے اور تحریر کے ل X [valid] ہونا ضروری ہے اور کافی حد تک منسلک ہونا چاہئے۔
//! خاص طور پر ، کسی بھی صفر والا غیر صفر عدد کو کسی خام پوائنٹر پر ڈالنا ایک درست پوائنٹر پیدا کرتا ہے ، لیکن ایک پوائنٹر جو پہلے مختص شدہ میموری میں اشارہ کرتا ہے کہ چونکہ آزاد ہوا وہ درست نہیں ہے۔
//! اگر Z01X استعمال نہیں کیا جاسکتا ہے تو ZST میں باکس بنانے کے لئے تجویز کردہ طریقہ یہ ہے کہ [`ptr::NonNull::dangling`] استعمال کریں۔
//!
//! جب تک `T: Sized` ، `Box<T>` کی ضمانت دی گئی ہے کہ وہ ایک ہی پوائنٹر کی نمائندگی کرے گی اور یہ ABI کے مطابق سی پوائنٹرز (یعنی سی ٹائپ `T*`) کے ساتھ بھی مطابقت رکھتا ہے۔
//! اس کا مطلب یہ ہے کہ اگر آپ کے پاس بیرونی "C" Rust افعال ہیں جو C سے منگوائے جائیں گے ، آپ `Box<T>` اقسام کا استعمال کرتے ہوئے ان Rust افعال کی وضاحت کرسکتے ہیں ، اور `T*` کو C کی طرف سے متعلقہ قسم کے طور پر استعمال کرسکتے ہیں۔
//! ایک مثال کے طور پر ، اس سی ہیڈر پر غور کریں جو ایسے افعال کا اعلان کرتا ہے جو کسی قسم کی `Foo` قدر بناتے اور تباہ کرتے ہیں:
//!
//! ```c
//! /* سی ہیڈر */
//!
//! /* کالر کو ملکیت لوٹاتا ہے */
//! struct Foo* foo_new(void);
//!
//! /* کال کرنے والے سے ملکیت لیتا ہے۔جب آپ NULL کے ساتھ درخواست کرتے ہیں تو کوئی آپشن نہیں ہوتا ہے */
//! void foo_delete(struct Foo*);
//! ```
//!
//! مندرجہ ذیل کے طور پر یہ دونوں افعال Rust میں لاگو ہوسکتے ہیں۔یہاں ، X سے `Box<Foo>` قسم کا ترجمہ `Box<Foo>` میں کیا گیا ہے ، جو ملکیت کی رکاوٹوں کو اپنی گرفت میں لاتا ہے۔
//! یہ بھی نوٹ کریں کہ `foo_delete` کے ساتھ منسوخ ہونے والی دلیل Rust میں `Option<Box<Foo>>` کی نمائندگی کی گئی ہے ، کیونکہ `Box<Foo>` کالعدم نہیں ہوسکتی ہے۔
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! اگرچہ `Box<T>` کی سی نمائندگی کی طرح نمائندگی اور C ABI کی طرح ہے ، اس کا مطلب یہ نہیں ہے کہ آپ صوابدیدی `T*` کو `Box<T>` میں تبدیل کرسکتے ہیں اور چیزوں کے کام کرنے کی توقع کرسکتے ہیں۔
//! `Box<T>` اقدار ہمیشہ مکمل طور پر منسلک ہوجائیں گی ، غیر منطقی اشارے۔مزید یہ کہ ، `Box<T>` کا ڈسٹرکٹر عالمی مختص کرنے والے کے ساتھ قیمت کو آزاد کرنے کی کوشش کرے گا۔عام طور پر ، بہترین مشق صرف `Box<T>` کو صرف ایسے پوائنٹرز کے لئے استعمال کرنا ہے جو عالمی مختص کرنے والے سے نکلے ہیں۔
//!
//! **اہم۔** کم از کم فی الحال ، آپ کو افعال کے لئے `Box<T>` اقسام کے استعمال سے گریز کرنا چاہئے جن کی وضاحت C میں کی گئی ہے لیکن Rust سے درخواست کی گئی ہے۔ان معاملات میں ، آپ کو C کی اقسام کو براہ راست ہر ممکن حد تک قریب سے آئینہ دینا چاہئے۔
//! `Box<T>` جیسی اقسام کا استعمال کرنا جہاں C تعریف صرف `T*` کا استعمال کررہی ہے غیر وضاحتی سلوک کا باعث بن سکتی ہے ، جیسا کہ [rust-lang/unsafe-code-guidelines#198][ucg#198] میں بیان کیا گیا ہے۔
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// ڈھیر مختص کرنے کے لئے ایک پوائنٹر کی قسم۔
///
/// مزید کے لئے [module-level documentation](../../std/boxed/index.html) دیکھیں۔
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// ڈھیر پر میموری مختص کرتا ہے اور پھر اس میں `x` رکھ دیتا ہے۔
    ///
    /// اگر اصل میں `T` صفر سائز کا ہو تو یہ مختص نہیں کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// بنائے ہوئے مواد کے ساتھ ایک نیا باکس بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ہی ، بنائے ہوئے مواد کے ساتھ ایک نیا `Box` بناتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// ایک نیا `Pin<Box<T>>` بناتا ہے۔
    /// اگر `T` `Unpin` پر عمل درآمد نہیں کرتا ہے ، تو `x` میموری میں پن ہوجائے گا اور منتقل ہونے سے قاصر ہے۔
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// ڈھیر پر میموری کو مختص کرتا ہے پھر `x` کو اس میں رکھتا ہے ، اگر کوئی رقم مختص نہیں ہوتی ہے تو غلطی لوٹتی ہے
    ///
    ///
    /// اگر اصل میں `T` صفر سائز کا ہو تو یہ مختص نہیں کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// ڈھیر پر بلا تعل contentsم مواد کے ساتھ ایک نیا باکس بناتا ہے ، اگر مختص ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// بغیر ساز و مشمولات کے ساتھ ایک نیا `Box` تشکیل دیتا ہے ، ڈھیر پر میموری `0` بائٹس سے بھر جاتا ہے
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// دیئے گئے مختص کنندہ میں میموری کو مختص کرتا ہے پھر اس میں `x` رکھ دیتا ہے۔
    ///
    /// اگر اصل میں `T` صفر سائز کا ہو تو یہ مختص نہیں کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// دیئے گئے مختص کنندہ میں میموری کو الاٹ کرتا ہے پھر `x` کو اس میں رکھتا ہے ، اگر یہ رقم مختص نہیں ہوتی ہے تو غلطی واپس کردیتی ہے
    ///
    ///
    /// اگر اصل میں `T` صفر سائز کا ہو تو یہ مختص نہیں کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// فراہم کردہ مختص کنندہ میں بلا تعل .م مواد کے ساتھ ایک نیا باکس بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: بند ہونے کی وجہ سے unwrap_or_else پر میچ کو ترجیح دیں کیونکہ کبھی کبھی ان لائن لائق نہیں ہوتا ہے۔
        // اس سے کوڈ کا سائز بڑا ہوجائے گا۔
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// فراہم کردہ مختص کنندہ میں غیر بنائے ہوئے مشمولات کے ساتھ ایک نیا باکس تشکیل دیتا ہے ، اگر مختص ناکام ہوجاتا ہے تو غلطی واپس کرتا ہے
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// فراہم کردہ مختص کنندہ میں `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ، بنائے ہوئے مواد کے ساتھ ایک نیا `Box` تشکیل دیتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: بند ہونے کی وجہ سے unwrap_or_else پر میچ کو ترجیح دیں کیونکہ کبھی کبھی ان لائن لائق نہیں ہوتا ہے۔
        // اس سے کوڈ کا سائز بڑا ہوجائے گا۔
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// فراہم کردہ مختص کنندہ میں `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ، بنائے ہوئے مشمولات کے ساتھ ایک نیا `Box` تشکیل دیتا ہے ، اگر الاٹمنٹ ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے ،
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// ایک نیا `Pin<Box<T, A>>` بناتا ہے۔
    /// اگر `T` `Unpin` پر عمل درآمد نہیں کرتا ہے ، تو `x` میموری میں پن ہوجائے گا اور منتقل ہونے سے قاصر ہے۔
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` کو `Box<[T]>` میں تبدیل کرتا ہے
    ///
    /// یہ تبادلہ ڈھیر پر مختص نہیں ہوتا ہے اور جگہ جگہ ہوتا ہے۔
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// لپیٹی ہوئی قیمت لوٹاتے ہوئے ، `Box` استعمال کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// بنائے ہوئے مواد کے ساتھ ایک نیا باکسڈ سلائس تیار کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // موخر ابتدا:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ہی ، بنائے ہوئے مواد کے ساتھ ایک نیا باکسڈ سلائس تیار کرتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// فراہم کردہ مختص کنندہ میں بلا تعطل مواد کے ساتھ ایک نیا باکسڈ سلائس تیار کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // موخر ابتدا:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ، فراہم کردہ مختص کرنے والے میں بغیر انٹیلیٹائزڈ مواد کے ساتھ ایک نیا باکسڈ سلائس تیار کرتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` میں تبدیل ہوتا ہے۔
    ///
    /// # Safety
    ///
    /// جیسا کہ [`MaybeUninit::assume_init`] کی طرح ، یہ اس بات کی ضمانت دینے والے پر منحصر ہے کہ قیمت واقعی ابتدائی حالت میں ہے۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا فوری طور پر غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // موخر ابتدا:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` میں تبدیل ہوتا ہے۔
    ///
    /// # Safety
    ///
    /// جیسا کہ [`MaybeUninit::assume_init`] کی طرح ، یہ اس بات کی ضمانت دینے والا ہے کہ اقدار واقعی ابتدائی حالت میں ہیں۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا فوری طور پر غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // موخر ابتدا:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// خام پوائنٹر سے ایک باکس بناتا ہے۔
    ///
    /// اس فنکشن کو کال کرنے کے بعد ، خام پوائنٹر نتیجے میں `Box` کی ملکیت ہے۔
    /// خاص طور پر ، `Box` ڈسٹرکٹر `T` کے ڈسٹرکٹر کو کال کرے گا اور مختص شدہ میموری کو آزاد کرے گا۔
    /// اس کے محفوظ رہنے کے ل must ، میموری کو [memory layout] X کے ذریعہ استعمال کردہ [memory layout] کے مطابق مختص کیا جانا چاہئے۔
    ///
    ///
    /// # Safety
    ///
    /// یہ فنکشن غیر محفوظ ہے کیونکہ غلط استعمال سے میموری کی پریشانی ہوسکتی ہے۔
    /// مثال کے طور پر ، اگر ایک ہی خام پوائنٹر پر تقریب میں دو بار بلایا جاتا ہے تو ایک ڈبل فری واقع ہوسکتا ہے۔
    ///
    /// حفاظتی ضوابط کو [memory layout] سیکشن میں بیان کیا گیا ہے۔
    ///
    /// # Examples
    ///
    /// ایک `Box` دوبارہ بنائیں جو پہلے [`Box::into_raw`] استعمال کرکے کسی خام پوائنٹر میں تبدیل ہوا تھا:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// دستی طور پر عالمی مختص کار کا استعمال کرکے شروع سے ایک `Box` بنائیں:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // عام طور پر .write کو `ptr` کے (uninitialized) پچھلے مندرجات کو خراب کرنے کی کوشش سے بچنے کی ضرورت ہے ، حالانکہ اس سادہ سی مثال کے لئے `*ptr = 5` نے بھی کام کیا ہوگا۔
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// دیئے گئے مختص کنندہ میں خام پوائنٹر سے ایک خانے تیار کرتا ہے۔
    ///
    /// اس فنکشن کو کال کرنے کے بعد ، خام پوائنٹر نتیجے میں `Box` کی ملکیت ہے۔
    /// خاص طور پر ، `Box` ڈسٹرکٹر `T` کے ڈسٹرکٹر کو کال کرے گا اور مختص شدہ میموری کو آزاد کرے گا۔
    /// اس کے محفوظ رہنے کے ل must ، میموری کو [memory layout] X کے ذریعہ استعمال کردہ [memory layout] کے مطابق مختص کیا جانا چاہئے۔
    ///
    ///
    /// # Safety
    ///
    /// یہ فنکشن غیر محفوظ ہے کیونکہ غلط استعمال سے میموری کی پریشانی ہوسکتی ہے۔
    /// مثال کے طور پر ، اگر ایک ہی خام پوائنٹر پر تقریب میں دو بار بلایا جاتا ہے تو ایک ڈبل فری واقع ہوسکتا ہے۔
    ///
    /// # Examples
    ///
    /// ایک `Box` دوبارہ بنائیں جو پہلے [`Box::into_raw_with_allocator`] استعمال کرکے کسی خام پوائنٹر میں تبدیل ہوا تھا:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// سسٹم مختص کرنے والے کا استعمال کرکے دستی طور پر شروع سے ایک `Box` بنائیں:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // عام طور پر .write کو `ptr` کے (uninitialized) پچھلے مندرجات کو خراب کرنے کی کوشش سے بچنے کی ضرورت ہے ، حالانکہ اس سادہ سی مثال کے لئے `*ptr = 5` نے بھی کام کیا ہوگا۔
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// لپیٹے ہوئے کچے پوائنٹر کو لوٹاتے ہوئے ، `Box` لیتا ہے۔
    ///
    /// پوائنٹر کو صحیح طریقے سے منسلک کیا جائے گا اور غیر کالعدم کیا جائے گا۔
    ///
    /// اس فنکشن کو فون کرنے کے بعد ، کالر `Box` کے ذریعہ پہلے سے زیر انتظام میموری کی ذمہ دار ہے۔
    /// خاص طور پر ، کال کرنے والے کو `T` کو صحیح طریقے سے ختم کرنا چاہئے اور `Box` کے ذریعہ استعمال ہونے والے [memory layout] کو مدنظر رکھتے ہوئے ، میموری کو جاری کرنا چاہئے۔
    /// اس کا آسان ترین طریقہ یہ ہے کہ [`Box::from_raw`] فنکشن کے ساتھ خام پوائنٹر کو واپس `Box` میں تبدیل کیا جا، ، `Box` ڈسٹرکٹر کو صفائی کرنے کی اجازت دے۔
    ///
    ///
    /// Note: یہ ایک وابستہ فنکشن ہے ، جس کا مطلب ہے کہ آپ کو `b.into_raw()` کی بجائے اسے `Box::into_raw(b)` کے نام سے پکارنا ہوگا۔
    /// یہ اس لئے ہے کہ داخلی قسم پر کسی طریقہ کار سے کوئی تنازعہ نہیں ہے۔
    ///
    /// # Examples
    /// خودکار صفائی کے لئے خام پوائنٹر کو `Box` میں X0X میں تبدیل کرنا:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// واضح طور پر ڈسٹرکٹر کو چلانے اور میموری کو ختم کرنے کے ذریعہ دستی صفائی:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` استعمال کرتا ہے ، لپیٹے ہوئے کچے پوائنٹر اور مختص کنندہ کو لوٹاتا ہے۔
    ///
    /// پوائنٹر کو صحیح طریقے سے منسلک کیا جائے گا اور غیر کالعدم کیا جائے گا۔
    ///
    /// اس فنکشن کو فون کرنے کے بعد ، کالر `Box` کے ذریعہ پہلے سے زیر انتظام میموری کی ذمہ دار ہے۔
    /// خاص طور پر ، کال کرنے والے کو `T` کو صحیح طریقے سے ختم کرنا چاہئے اور `Box` کے ذریعہ استعمال ہونے والے [memory layout] کو مدنظر رکھتے ہوئے ، میموری کو جاری کرنا چاہئے۔
    /// اس کا آسان ترین طریقہ یہ ہے کہ [`Box::from_raw_in`] فنکشن کے ساتھ خام پوائنٹر کو واپس `Box` میں تبدیل کیا جا، ، `Box` ڈسٹرکٹر کو صفائی کرنے کی اجازت دے۔
    ///
    ///
    /// Note: یہ ایک وابستہ فنکشن ہے ، جس کا مطلب ہے کہ آپ کو `b.into_raw_with_allocator()` کی بجائے اسے `Box::into_raw_with_allocator(b)` کے نام سے پکارنا ہوگا۔
    /// یہ اس لئے ہے کہ داخلی قسم پر کسی طریقہ کار سے کوئی تنازعہ نہیں ہے۔
    ///
    /// # Examples
    /// خودکار صفائی کے لئے خام پوائنٹر کو `Box` میں X0X میں تبدیل کرنا:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// واضح طور پر ڈسٹرکٹر کو چلانے اور میموری کو ختم کرنے کے ذریعہ دستی صفائی:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // اسٹیکڈ بورنز کے ذریعہ باکس کو "unique pointer" کے طور پر تسلیم کیا گیا ہے ، لیکن اندرونی طور پر یہ ٹائپ سسٹم کا خام نقطہ ہے۔
        // اسے براہ راست کسی خام پوائنٹر میں تبدیل کرنا ، "releasing" کے طور پر علیحدہ خام رسوں کی اجازت دینے کا انوکھا پوائنٹر تسلیم نہیں کیا جاسکتا ہے ، لہذا تمام خام پوائنٹر طریقوں کو `Box::leak` سے گزرنا پڑتا ہے۔
        //
        // *اس* کو کسی خام پوائنٹر کی طرف موڑنا صحیح سلوک کرتا ہے۔
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// بنیادی مختص کرنے والے کا حوالہ لوٹاتا ہے۔
    ///
    /// Note: یہ ایک وابستہ فنکشن ہے ، جس کا مطلب ہے کہ آپ کو `b.allocator()` کی بجائے اسے `Box::allocator(&b)` کے نام سے پکارنا ہوگا۔
    /// یہ اس لئے ہے کہ داخلی قسم پر کسی طریقہ کار سے کوئی تنازعہ نہیں ہے۔
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` کی کھپت اور لیک ، ایک تبدیل تبادلہ حوالہ واپس ، `&'a mut T`.
    /// نوٹ کریں کہ `T` قسم کو منتخب کردہ زندگی بھر `'a` سے بھی آگے نکل جانا چاہئے۔
    /// اگر اس قسم میں صرف مستحکم حوالہ جات ہیں ، یا کوئی بھی نہیں ، تو پھر یہ `'static` ہونے کا انتخاب کیا جاسکتا ہے۔
    ///
    /// یہ فنکشن اس اعداد و شمار کے لئے بنیادی طور پر کارآمد ہے جو پروگرام کی باقی زندگی تک زندہ رہتا ہے۔
    /// لوٹا ہوا حوالہ چھوڑنا میموری میموری کا سبب بنے گا۔
    /// اگر یہ قابل قبول نہیں ہے تو ، حوالہ پہلے [`Box::from_raw`] فنکشن کے ساتھ لپیٹنا چاہئے جس میں `Box` تیار کیا جاتا ہے۔
    ///
    /// اس کے بعد یہ `Box` ڈراپ کیا جاسکتا ہے جو `T` کو صحیح طریقے سے ختم کردے گا اور مختص شدہ میموری کو جاری کردے گا۔
    ///
    /// Note: یہ ایک وابستہ فنکشن ہے ، جس کا مطلب ہے کہ آپ کو `b.leak()` کی بجائے اسے `Box::leak(b)` کے نام سے پکارنا ہوگا۔
    /// یہ اس لئے ہے کہ داخلی قسم پر کسی طریقہ کار سے کوئی تنازعہ نہیں ہے۔
    ///
    /// # Examples
    ///
    /// آسان استعمال:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// غیر سائز شدہ ڈیٹا:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` کو `Pin<Box<T>>` میں تبدیل کرتا ہے
    ///
    /// یہ تبادلہ ڈھیر پر مختص نہیں ہوتا ہے اور جگہ جگہ ہوتا ہے۔
    ///
    /// یہ [`From`] کے ذریعہ بھی دستیاب ہے۔
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // جب `T: !Unpin` ہوتا ہے تو `Pin<Box<T>>` کے اندر کو منتقل کرنا یا تبدیل کرنا ممکن نہیں ہوتا ہے ، لہذا بغیر کسی اضافی تقاضے کے براہ راست پن لگانا محفوظ ہے۔
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: کچھ نہیں کریں ، ڈراپ فی الحال مرتب کرنے والے کے ذریعہ انجام دیا گیا ہے۔
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// ٹی کے لئے `Default` قدر کے ساتھ ، ایک `Box<T>` بناتا ہے۔
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// اس باکس کے مندرجات کی `clone()` کے ساتھ ایک نیا باکس لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // قیمت ایک جیسی ہے
    /// assert_eq!(x, y);
    ///
    /// // لیکن وہ انوکھی چیزیں ہیں
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // پہلے سے مختص شدہ میموری کو کلونڈ ویلیو کو براہ راست لکھنے کی اجازت دینے کیلئے۔
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// کاپی `ذریعہ creating کے مندرجات کو `self` میں کوئی نیا مختص نہ بنائے بغیر۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // قیمت ایک جیسی ہے
    /// assert_eq!(x, y);
    ///
    /// // اور کوئی مختص نہیں ہوا
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // اس سے اعداد و شمار کی کاپی ہوجاتی ہے
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// عام قسم کی `T` کو `Box<T>` میں تبدیل کرتا ہے
    ///
    /// تبادلہ ڈھیر پر مختص ہوتا ہے اور `t` کو اسٹیک سے اس میں منتقل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` کو `Pin<Box<T>>` میں تبدیل کرتا ہے
    ///
    /// یہ تبادلہ ڈھیر پر مختص نہیں ہوتا ہے اور جگہ جگہ ہوتا ہے۔
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` کو `Box<[T]>` میں تبدیل کرتا ہے
    ///
    /// یہ تبادلہ ڈھیر پر مختص ہوتا ہے اور `slice` کی ایک کاپی انجام دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ایک&[u8] بنائیں جو ایک باکس <[u8]> بنانے کے لئے استعمال ہوگا
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` کو `Box<str>` میں تبدیل کرتا ہے
    ///
    /// یہ تبادلہ ڈھیر پر مختص ہوتا ہے اور `s` کی ایک کاپی انجام دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` کو `Box<[u8]>` میں تبدیل کرتا ہے
    /// یہ تبادلہ ڈھیر پر مختص نہیں ہوتا ہے اور جگہ جگہ ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ایک باکس بنائیں<str>جو ایک باکس <[u8]> بنانے کیلئے استعمال ہوگا
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // ایک&[u8] بنائیں جو ایک باکس <[u8]> بنانے کے لئے استعمال ہوگا
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` کو `Box<[T]>` میں تبدیل کرتا ہے
    /// یہ تبادلہ سرنی کو نئی ڈھیر سے مختص میموری میں منتقل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// کنکریٹ کی قسم پر باکس کو ڈاؤن لوڈ کرنے کی کوشش کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// کنکریٹ کی قسم پر باکس کو ڈاؤن لوڈ کرنے کی کوشش کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// کنکریٹ کی قسم پر باکس کو ڈاؤن لوڈ کرنے کی کوشش کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // اندرونی یونیک کو براہ راست باکس سے نکالنا ممکن نہیں ہے ، بجائے اس کے کہ ہم اسے ایک * کانسٹیٹیوشن پر ڈال دیں جس سے انوکھی چیز کا تعیasesن ہوجائے۔
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// سائز کے for I`s کے لئے تخصص جو ڈیفالٹ کے بجائے `last()` پر implementation I`s کے نفاذ کا استعمال کرتا ہے۔
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}