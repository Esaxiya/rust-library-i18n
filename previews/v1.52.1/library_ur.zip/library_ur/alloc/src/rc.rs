//! ایک ہی تھریڈ والا حوالہ گنتی پوائنٹر۔'Rc' کا مطلب 'حوالہ' ہے
//! Counted'.
//!
//! قسم [`Rc<T>`][`Rc`] ڈھیر میں مختص قسم `T` کی قدر کی مشترکہ ملکیت فراہم کرتی ہے۔
//! X01 ایکس پر [`clone`][clone] کا مطالبہ کرنا ڈھیر میں اسی مختص کرنے کے لئے ایک نیا پوائنٹر پیدا کرتا ہے۔
//! جب کسی مختص مختص کا آخری [`Rc`] پوائنٹر ختم ہوجاتا ہے تو ، اس مختص میں ذخیرہ شدہ قدر (اکثر "inner value" کے نام سے بھی جانا جاتا ہے) بھی گرا دیا جاتا ہے۔
//!
//! Rust میں مشترکہ حوالہ جات ڈیفالٹ کے ذریعہ اتپریورتن کی اجازت نہیں دیتے ہیں ، اور [`Rc`] بھی اس سے مستثنیٰ نہیں ہے: آپ عام طور پر کسی [`Rc`] کے اندر کسی چیز کا تغیر پزیر حوالہ حاصل نہیں کرسکتے ہیں۔
//! اگر آپ کو بدلاؤ کی ضرورت ہو تو ، [`Rc`] کے اندر [`Cell`] یا [`RefCell`] رکھیں۔[an example of mutability inside an `Rc`][mutability] دیکھیں۔
//!
//! [`Rc`] غیر جوہری حوالہ گنتی کا استعمال کرتا ہے۔
//! اس کا مطلب یہ ہے کہ اوورہیڈ بہت کم ہے ، لیکن ایک [`Rc`] دھاگوں کے درمیان نہیں بھیجا جاسکتا ہے ، اور اس کے نتیجے میں [`Rc`] [`Send`][send] پر عمل درآمد نہیں کرتا ہے۔
//! نتیجہ کے طور پر ، Rust مرتب آپ *مرتب وقت* چیک کرے گا کہ آپ [[Rc`] s کو دھاگوں کے درمیان نہیں بھیج رہے ہیں۔
//! اگر آپ کو کثیر جہتی ، جوہری حوالہ گنتی کی ضرورت ہو تو ، [`sync::Arc`][arc] استعمال کریں۔
//!
//! [`downgrade`][downgrade] طریقہ غیر مالک [`Weak`] پوائنٹر بنانے کے لئے استعمال کیا جاسکتا ہے۔
//! ایک [`Weak`] پوائنٹر [`اپگریڈ][[اپ گریڈ]] کو ایک [`Rc`] میں ہوسکتا ہے ، لیکن اگر یہ مختص میں رکھی ہوئی قیمت پہلے ہی چھوڑ دی گئی ہے تو یہ [`None`] واپس آئے گا۔
//! دوسرے الفاظ میں ، `Weak` پوائنٹر مختص کے اندر کی قیمت کو زندہ نہیں رکھتے ہیں۔تاہم ، وہ مختص (داخلی قیمت کے لئے معاون اسٹور) کو * زندہ رکھتے ہیں۔
//!
//! [`Rc`] پوائنٹر کے درمیان چکر کبھی ختم نہیں ہوگا۔
//! اس وجہ سے ، [`Weak`] سائیکل کو توڑنے کے لئے استعمال کیا جاتا ہے۔
//! مثال کے طور پر ، ایک درخت میں والدین کے نوڈس سے بچوں تک مضبوط [`Rc`] پوائنٹر اور [`Weak`] پوائنٹر بچوں سے ان کے والدین کی طرف ہوسکتے ہیں۔
//!
//! `Rc<T>` خود بخود `T` ([`Deref`] trait کے ذریعے) کا حوالہ دیتے ہیں ، لہذا آپ [`Rc<T>`][`Rc`] کی قسم پر `T` کے طریقوں پر کال کرسکتے ہیں۔
//! `T` کے طریقوں سے نام کی تصادم سے بچنے کے ل X ، خود [`Rc<T>`][`Rc`] کے طریق کار وابستہ ہیں ، جن کو [fully qualified syntax] کا استعمال کرتے ہوئے کہا جاتا ہے:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`Clone` جیسے traits کے نفاذ کو بھی مکمل طور پر اہل نحو کا استعمال کرتے ہوئے کہا جاسکتا ہے۔
//! کچھ لوگ مکمل طور پر کوالیفائی کردہ نحو کو استعمال کرنے کو ترجیح دیتے ہیں ، جبکہ دوسرے میتھڈ کال نحیط استعمال کرنا پسند کرتے ہیں۔
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // طریقہ کال کالیکس
//! let rc2 = rc.clone();
//! // مکمل طور پر تعلیم یافتہ نحو
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` کا خود کار طریقے سے حوالہ نہیں دیتا ہے ، کیونکہ داخلی قیمت پہلے ہی چھوڑ دی جاسکتی ہے۔
//!
//! # کلوننگ حوالہ جات
//!
//! اسی مختص کا ایک نیا حوالہ بنانا موجودہ ریفرنس گنتی پوائنٹر کی طرح `Clone` trait کو [`Rc<T>`][`Rc`] اور [`Weak<T>`][`Weak`] کیلئے لاگو کیا گیا ہے۔
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // ذیل میں دو نحو مترادف ہیں۔
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a اور b دونوں فوو جیسی میموری والے مقام کی طرف اشارہ کرتے ہیں۔
//! ```
//!
//! `Rc::clone(&from)` نحو سب سے زیادہ محاور ہے کیونکہ اس سے کوڈ کے معنی واضح طور پر ملتے ہیں۔
//! مذکورہ بالا مثال میں ، یہ نحو یہ دیکھنے میں آسانی پیدا کرتا ہے کہ یہ کوڈ فو کے پورے مواد کو نقل کرنے کے بجائے ایک نیا حوالہ تشکیل دے رہا ہے۔
//!
//! # Examples
//!
//! کسی ایسے منظر نامے پر غور کریں جہاں `گیجیٹ کی ایک سیٹ کسی دیئے گئے `Owner` کی ملکیت ہے۔
//! ہم اپنے گیجٹ کا اشارہ ان کے `Owner` پر کرنا چاہتے ہیں۔ہم یہ انوکھی ملکیت کے ساتھ نہیں کرسکتے ، کیونکہ ایک سے زیادہ گیجٹ ایک ہی `Owner` سے متعلق ہوسکتے ہیں۔
//! [`Rc`] ہمیں ایک سے زیادہ گیجٹ کے درمیان `Owner` شیئر کرنے کی اجازت دیتا ہے ، اور `Owner` جب تک اس میں کسی بھی `Gadget` پوائنٹس تک مختص نہیں رہ سکتا ہے۔
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... دوسرے فیلڈز
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... دوسرے فیلڈز
//! }
//!
//! fn main() {
//!     // ایک حوالہ گنتی `Owner` بنائیں۔
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` سے متعلق `گیجٹ بنائیں۔
//!     // `Rc<Owner>` کی کلوننگ ہمیں اسی `Owner` مختص کرنے کے لئے ایک نیا اشارہ فراہم کرتی ہے ، جو عمل میں حوالہ کی گنتی میں اضافہ کرتی ہے۔
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // ہمارے مقامی متغیر `gadget_owner` کو ضائع کریں۔
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` چھوڑنے کے باوجود ، ہم اب بھی `گیجٹ کے `Owner` کا نام پرنٹ کرنے میں کامیاب ہیں۔
//!     // اس کی وجہ یہ ہے کہ ہم نے صرف ایک ہی `Rc<Owner>` ڈراپ کیا ہے ، `Owner` نہیں جس کی طرف اس کی طرف اشارہ کیا گیا ہے۔
//!     // جب تک کہ اسی `Owner` مختص پر دوسرے `Rc<Owner>` کی طرف اشارہ کیا جائے ، تب تک یہ زندہ رہے گا۔
//!     // فیلڈ پروجیکشن `gadget1.owner.name` کام کرتا ہے کیونکہ `Rc<Owner>` خود بخود `Owner` کا حوالہ دیتا ہے۔
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // فنکشن کے اختتام پر ، `gadget1` اور `gadget2` تباہ کردیئے گئے ہیں ، اور ان کے ساتھ ہمارے `Owner` کا آخری گنتی حوالہ ہے۔
//!     // گیجٹ مین اب تباہ ہوجاتا ہے۔
//!     //
//! }
//! ```
//!
//! اگر ہماری ضروریات تبدیل ہوجاتی ہیں ، اور ہمیں `Owner` سے `Gadget` تک جانے کے بھی قابل ہونے کی ضرورت ہے ، تو ہم پریشانیوں کا شکار ہوجائیں گے۔
//! `Owner` سے `Gadget` تک [`Rc`] پوائنٹر ایک سائیکل متعارف کراتا ہے۔
//! اس کا مطلب یہ ہے کہ ان کا حوالہ شمار کبھی 0 تک نہیں پہنچ سکتا ، اور الاٹمنٹ کبھی تباہ نہیں ہوگا:
//! ایک میموری لیکاس کو حاصل کرنے کے ل we ، ہم [`Weak`] پوائنٹر استعمال کرسکتے ہیں۔
//!
//! Rust دراصل اس لوپ کو پہلی جگہ تیار کرنا کسی حد تک مشکل بنا دیتا ہے۔ایک دوسرے کی طرف اشارہ کرنے والی دو اقدار کو ختم کرنے کے ل them ، ان میں سے ایک کو تغیر پزیر ہونے کی ضرورت ہے۔
//! یہ مشکل ہے کیوں کہ [`Rc`] صرف اس قدر قدر کے مشترکہ حوالہ دے کر میموری کی حفاظت کو نافذ کرتا ہے ، اور یہ براہ راست تغیرات کی اجازت نہیں دیتے ہیں۔
//! ہمیں اس قدر کا ایک حص wہ لپیٹنا ہوگا جس کی ہم ایک [`RefCell`] میں تبدیلی کرنا چاہتے ہیں ، جو *داخلہ اتپریورتن* فراہم کرتا ہے: مشترکہ حوالہ کے ذریعے تغیر پزیر ہونے کا ایک طریقہ۔
//! [`RefCell`] رن ٹائم پر Rust کے قرض لینے کے قواعد کو نافذ کرتا ہے۔
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... دوسرے فیلڈز
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... دوسرے فیلڈز
//! }
//!
//! fn main() {
//!     // ایک حوالہ گنتی `Owner` بنائیں۔
//!     // نوٹ کریں کہ ہم نے `RefCell` کے اندر `مالک` کے vector`گیجٹ` کو رکھا ہے تاکہ ہم اسے مشترکہ حوالہ سے تبدیل کرسکیں۔
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // پہلے کی طرح ، `gadget_owner` سے متعلق `گیجٹ بنائیں۔
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // `گیجٹ کو ان کے `Owner` میں شامل کریں۔
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` متحرک قرضہ یہاں ختم ہوتا ہے۔
//!     }
//!
//!     // ہمارے `گیجٹ کے بارے میں جانچیں ، ان کی تفصیلات چھپائیں۔
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ایک `Weak<Gadget>` ہے۔
//!         // چونکہ `Weak` پوائنٹر ابھی بھی موجود الاٹمنٹ کی ضمانت نہیں دے سکتے ہیں ، لہذا ہمیں `upgrade` کو فون کرنے کی ضرورت ہے ، جو ایک `Option<Rc<Gadget>>` واپس کرتا ہے۔
//!         //
//!         //
//!         // اس معاملے میں ہم جانتے ہیں کہ مختص ابھی بھی موجود ہے ، لہذا ہم محض `unwrap` `Option` کرتے ہیں۔
//!         // ایک زیادہ پیچیدہ پروگرام میں ، آپ کو `None` کے نتائج کے ل. خوبصورت مکالمے کی ضرورت ہوگی۔
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // فنکشن کے اختتام پر ، `gadget_owner` ، `gadget1` ، اور `gadget2` تباہ کردیئے گئے ہیں۔
//!     // اب گیجٹ کی طرف کوئی مضبوط (`Rc`) پوائنٹر نہیں ہیں ، لہذا وہ تباہ ہوگئے ہیں۔
//!     // اس سے گیجٹ مین پر حوالہ کی گنتی صفر ہوجاتی ہے ، لہذا وہ بھی تباہ ہوجاتا ہے۔
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// ممکنہ فیلڈ آرڈرنگ کے خلاف یہ repr(C) سے future-پروف ہے ، جو منتقلی داخلی اقسام کے محفوظ [into|from]_raw() کے ساتھ مداخلت کرے گا۔
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ایک ہی تھریڈ والا حوالہ گنتی پوائنٹر۔'Rc' کا مطلب 'حوالہ' ہے
/// Counted'.
///
/// مزید تفصیلات کے لئے [module-level documentation](./index.html) دیکھیں۔
///
/// `Rc` کے موروثی طریقے تمام وابستہ افعال ہیں ، جس کا مطلب ہے کہ آپ کو ان کو بطور مثال کے طور پر پکارنا پڑے گا ، `value.get_mut()` کی بجائے [`Rc::get_mut(&mut value)`][get_mut]۔
/// یہ اندرونی قسم کے `T` کے طریقوں سے تنازعات سے بچتا ہے۔
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // یہ بے یقینی ٹھیک ہے کیونکہ جب تک کہ یہ آر سی زندہ ہے ہمیں ضمانت دی جاتی ہے کہ اندرونی اشارہ درست ہے۔
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// ایک نیا `Rc<T>` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // ایک مضبوط ضعیف پوائنٹر ہے جس کی ملکیت تمام مضبوط پوائنٹرز کی ملکیت ہے ، جو اس بات کو یقینی بناتا ہے کہ کمزور ڈسٹرکٹر اس تقسیم کو کبھی نہیں آزاد کرتا ہے جب کہ مضبوط ڈسٹرکٹر چل رہا ہے ، یہاں تک کہ اگر کمزور پوائنٹر مضبوط کے اندر ہی محفوظ ہو۔
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// اپنے آپ میں کمزور حوالہ استعمال کرکے نیا `Rc<T>` تشکیل دیتا ہے۔
    /// اس فنکشن کی واپسی سے پہلے ضعیف حوالہ کو اپ گریڈ کرنے کی کوشش کے نتیجے میں `None` ویلیو ہوگی۔
    ///
    /// تاہم ، ضعیف حوالہ آزادانہ طور پر کلون کیا جاسکتا ہے اور بعد میں استعمال کے ل. ذخیرہ کیا جاسکتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... مزید فیلڈز
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // ایک واحد کمزور حوالہ کے ساتھ اندرونی "uninitialized" حالت میں تعمیر کریں۔
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // یہ ضروری ہے کہ ہم کمزور پوائنٹر کی ملکیت ترک نہیں کریں ، ورنہ `data_fn` کی واپسی کے وقت میموری کو آزاد کیا جاسکتا ہے۔
        // اگر ہم واقعتا ownership ملکیت کو منتقل کرنا چاہتے ہیں تو ہم اپنے لئے ایک اضافی کمزور پوائنٹر تشکیل دے سکتے ہیں ، لیکن اس کے نتیجے میں ضعیف حوالہ گنتی میں اضافی تازہ کاری ہوگی جو دوسری صورت میں ضروری نہیں ہوگی۔
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // مضبوط حوالوں کو مشترکہ طور پر مشترکہ ضعیف حوالہ کا مالک ہونا چاہئے ، لہذا ہمارے پرانے ضعیف حوالہ کو ضائع کرنے والے کو نہ چلائیں۔
        //
        mem::forget(weak);
        strong
    }

    /// غیر منطقی مشمولات کے ساتھ ایک نیا `Rc` تشکیل دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ہی ، بنائے ہوئے مواد کے ساتھ ایک نیا `Rc` بناتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// نیا `Rc<T>` تشکیل دیتا ہے ، اگر مختص ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // ایک مضبوط ضعیف پوائنٹر ہے جس کی ملکیت تمام مضبوط پوائنٹرز کی ملکیت ہے ، جو اس بات کو یقینی بناتا ہے کہ کمزور ڈسٹرکٹر اس تقسیم کو کبھی نہیں آزاد کرتا ہے جب کہ مضبوط ڈسٹرکٹر چل رہا ہے ، یہاں تک کہ اگر کمزور پوائنٹر مضبوط کے اندر ہی محفوظ ہو۔
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// غیر مختص شدہ مشمولات کے ساتھ ایک نیا `Rc` تشکیل دیتا ہے ، اگر مختص ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ، غیر بنائے ہوئے مشمولات کے ساتھ ایک نیا `Rc` تشکیل دیتا ہے ، اگر الاٹمنٹ ناکام ہوجاتا ہے تو غلطی لوٹاتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// ایک نیا `Pin<Rc<T>>` بناتا ہے۔
    /// اگر `T` `Unpin` پر عمل درآمد نہیں کرتا ہے ، تو `value` میموری میں پن ہوجائے گا اور منتقل ہونے سے قاصر ہے۔
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// اگر `Rc` میں بالکل ایک مضبوط حوالہ ہو تو اندرونی قدر لوٹاتا ہے۔
    ///
    /// بصورت دیگر ،[`Err`] X اسی `Rc` کے ساتھ واپس کیا گیا تھا جس میں گزر چکا تھا۔
    ///
    ///
    /// یہاں تک کہ اگر یہاں ضعیف ضعیف حوالہ جات موجود ہوں تو بھی کامیابی ہوگی۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // موجود چیز کو کاپی کریں

                // کمزوروں کی طرف اشارہ کریں کہ مضبوط گنتی کو کم کرکے ان کی تشہیر نہیں کی جاسکتی ہے ، اور پھر صرف ایک جعلی کمزور کو تیار کرکے ڈراپ منطق کو سنبھالنے کے ساتھ ہی ضمیمہ "strong weak" پوائنٹر کو بھی ہٹا دیں۔
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// غیر منطقی مشمولات کے ساتھ ایک نیا حوالہ گنتی سلائس تیار کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // موخر ابتدا:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ہی ، بنائے ہوئے مشمولات کے ساتھ ایک نیا حوالہ گنتی سلائس تیار کرتا ہے۔
    ///
    ///
    /// اس طریقہ کے صحیح اور غلط استعمال کی مثالوں کے لئے [`MaybeUninit::zeroed`][zeroed] دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` میں تبدیل ہوتا ہے۔
    ///
    /// # Safety
    ///
    /// جیسا کہ [`MaybeUninit::assume_init`] کی طرح ، یہ اس بات کی ضمانت دینے والے پر منحصر ہے کہ اندرونی قیمت واقعتا ابتدائی حالت میں ہے۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا فوری طور پر غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // موخر ابتدا:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` میں تبدیل ہوتا ہے۔
    ///
    /// # Safety
    ///
    /// جیسا کہ [`MaybeUninit::assume_init`] کی طرح ، یہ اس بات کی ضمانت دینے والے پر منحصر ہے کہ اندرونی قیمت واقعتا ابتدائی حالت میں ہے۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا فوری طور پر غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // موخر ابتدا:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// لپیٹے ہوئے پوائنٹر کو لوٹاتے ہوئے ، `Rc` استعمال کرتا ہے۔
    ///
    /// میموری لیک ہونے سے بچنے کے ل the ، پوائنٹر کو [`Rc::from_raw`][from_raw] کا استعمال کرکے واپس `Rc` میں تبدیل کرنا ہوگا۔
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// اعداد و شمار کو ایک خام اشارہ فراہم کرتا ہے۔
    ///
    /// شمار کسی بھی طرح متاثر نہیں ہوتے ہیں اور `Rc` استعمال نہیں ہوتا ہے۔
    /// `Rc` میں جب تک مضبوط گنتی نہیں ہے اس وقت تک یہ پوائنٹر درست ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // حفاظت: یہ Deref::deref یا Rc::inner کے ذریعے نہیں جاسکتی ہے کیونکہ
        // اس کی ضرورت ہے جیسے raw/mut پروونانس برقرار رکھنا
        // `get_mut` `from_raw` کے ذریعہ آرسی بازیافت ہونے کے بعد پوائنٹر کے ذریعے لکھ سکتا ہے۔
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// کسی خام پوائنٹر سے `Rc<T>` بناتا ہے۔
    ///
    /// خام پوائنٹر کو پہلے بھی [`Rc<U>::into_raw`][into_raw] پر کال کے ذریعہ واپس کر دینا چاہئے جہاں `U` کے پاس ایک ہی سائز اور سیدھ `T` کی طرح ہونی چاہئے۔
    /// اگر یہ `U` `T` ہے تو یہ چھوٹی سی بات ہے۔
    /// نوٹ کریں کہ اگر `U` `T` نہیں ہے لیکن ایک ہی سائز اور سیدھ میں ہے تو ، یہ بنیادی طور پر مختلف اقسام کے حوالوں کو منتقل کرنے کی طرح ہے۔
    /// اس معاملے میں کن پابندیوں کا اطلاق ہوتا ہے اس بارے میں مزید معلومات کے لئے [`mem::transmute`][transmute] دیکھیں۔
    ///
    /// `from_raw` کے صارف کو یہ یقینی بنانا ہوگا کہ `T` کی ایک مخصوص قدر صرف ایک بار گرا دی جائے۔
    ///
    /// یہ فنکشن غیر محفوظ ہے کیونکہ ناجائز استعمال سے میموری ناجائز ہوسکتا ہے ، یہاں تک کہ اگر واپس شدہ `Rc<T>` تک کبھی بھی رسائی حاصل نہیں کی جاتی ہے۔
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // لیک کو روکنے کے لئے واپس `Rc` میں تبدیل کریں۔
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` پر مزید کالیں میموری سے غیر محفوظ ہوں گی۔
    /// }
    ///
    /// // میموری کو آزاد کیا گیا جب `x` اوپر دائرہ کار سے باہر چلا گیا ، لہذا `x_ptr` اب گھماؤ پڑا ہے!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // اصل آر سی بکس کو تلاش کرنے کے لئے آفسیٹ کو پلٹائیں۔
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// اس مختص کیلئے ایک نیا [`Weak`] پوائنٹر بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // اس بات کو یقینی بنائیں کہ ہم بے ربط کمزوری کو پیدا نہیں کرتے ہیں
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// اس مختص کیلئے [`Weak`] پوائنٹرز کی تعداد حاصل ہوتی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// اس مختص کیلئے مضبوط (`Rc`) پوائنٹرز کی تعداد حاصل ہوتی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// اگر اس مختص میں کوئی `Rc` یا [`Weak`] پوائنٹر نہیں ہیں تو `true` واپس کرتا ہے۔
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// اگر ایک ہی مختص کرنے کے لئے کوئی دوسرا `Rc` یا [`Weak`] پوائنٹر نہیں ہیں تو ، دیئے گئے `Rc` میں ایک متغیر حوالہ واپس کرتا ہے۔
    ///
    ///
    /// دوسری صورت میں [`None`] لوٹاتا ہے ، کیونکہ مشترکہ قدر کو تبدیل کرنا محفوظ نہیں ہے۔
    ///
    /// یہ بھی دیکھیں [`make_mut`][make_mut] ، جو دوسرے پوائنٹر ہونے پر اندرونی قدر [`clone`][clone] کرے گا۔
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// کسی چیک کے بغیر ، دیئے گئے `Rc` میں تغیر پزیر حوالہ لوٹاتا ہے۔
    ///
    /// یہ بھی دیکھیں [`get_mut`] ، جو محفوظ ہے اور مناسب جانچ پڑتال کرتا ہے۔
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ایک ہی مختص کرنے کے لئے کسی بھی دوسرے `Rc` یا [`Weak`] پوائنٹر کو واپس کیے گئے قرضوں کی مدت کے لئے حوالہ نہیں کیا جانا چاہئے۔
    ///
    /// یہ چھوٹی سی صورت میں ہے اگر ایسے کوئی اشارے موجود نہ ہوں ، مثال کے طور پر `Rc::new` کے فورا بعد۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ہم محتاط ہیں کہ "count" فیلڈز کا احاطہ کرتے ہوئے * کوئی حوالہ نہ بنائیں ، کیونکہ اس حوالہ شمار تک رسائی سے متصادم ہوگا۔
        // بذریعہ `Weak`)۔
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// اگر دو `Rc`s ایک ہی مختص کی طرف اشارہ کرتے ہیں تو `true` واپس کرتا ہے ([`ptr::eq`] کی طرح رگ میں)۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// دیئے گئے `Rc` میں ایک متغیر حوالہ دیتا ہے۔
    ///
    /// اگر اسی مختص کرنے کے لئے دوسرے `Rc` پوائنٹر بھی موجود ہیں تو ، پھر `make_mut` اندرونی قدر کو [`clone`] میں ایک نیا مختص کرے گا تاکہ منفرد ملکیت کو یقینی بنایا جاسکے۔
    /// اسے کلون آن لکھتے بھی کہا جاتا ہے۔
    ///
    /// اگر اس مختص کے لئے کوئی دوسرا `Rc` پوائنٹر نہیں ہے ، تو اس مختص کے [`Weak`] پوائنٹرس کو الگ کردیا جائے گا۔
    ///
    /// [`get_mut`] بھی دیکھیں ، جو کلوننگ کے بجائے ناکام ہوجائیں گے۔
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // کچھ بھی کلون نہیں کریں گے
    /// let mut other_data = Rc::clone(&data);    // اندرونی ڈیٹا کو کلون نہیں کریں گے
    /// *Rc::make_mut(&mut data) += 1;        // کلون کا اندرونی ڈیٹا
    /// *Rc::make_mut(&mut data) += 1;        // کچھ بھی کلون نہیں کریں گے
    /// *Rc::make_mut(&mut other_data) *= 2;  // کچھ بھی کلون نہیں کریں گے
    ///
    /// // اب `data` اور `other_data` مختلف مختص کی طرف اشارہ کرتے ہیں۔
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] پوائنٹرس کو الگ کردیا جائے گا:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // اعداد و شمار کو کلون کرنے کے لئے ، دوسرے آر سی ایس موجود ہیں۔
            // پہلے سے مختص شدہ میموری کو کلونڈ ویلیو کو براہ راست لکھنے کی اجازت دینے کیلئے۔
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // صرف ڈیٹا چوری کرسکتا ہے ، صرف ویکس باقی ہے
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // مضبوط مضبوط کمزور ریف کو ہٹا دیں (یہاں جعلی کمزور بنانے کی ضرورت نہیں ہے-ہم جانتے ہیں کہ دوسرے کمزور ہمارے لئے صفائی کرسکتے ہیں)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // یہ بے یقینی ٹھیک ہے کیونکہ ہمیں ضمانت دی گئی ہے کہ واپس کرنے والا پوائنٹر ہی *صرف* پوائنٹر ہے جو کبھی بھی T کو واپس کیا جائے گا۔
        // ہماری حوالہ شماری اس وقت 1 ہونے کی ضمانت ہے ، اور ہمیں `Rc<T>` خود `mut` ہونے کی ضرورت ہے ، لہذا ہم اس مختص کا واحد ممکنہ حوالہ واپس کر رہے ہیں۔
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` کو کنکریٹ کی قسم پر گھٹانے کی کوشش کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// ایک `RcBox<T>` کو ممکنہ طور پر غیر تبدیل شدہ داخلی قیمت کے لئے کافی جگہ کے ساتھ مختص کرتا ہے جہاں قیمت میں ترتیب فراہم کی جاتی ہے۔
    ///
    /// فنکشن `mem_to_rcbox` کو ڈیٹا پوائنٹر کے ساتھ بلایا جاتا ہے اور `RcBox<T>` کے لئے ایک (ممکنہ چربی) پوائنٹر واپس کرنا ہوگا۔
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // دیئے گئے قدر کی ترتیب کا استعمال کرکے ترتیب کا حساب لگائیں۔
        // اس سے قبل ، ترتیب `&*(ptr as* const RcBox<T>)` پر حساب کتاب کیا جاتا تھا ، لیکن اس نے غلط دستخط شدہ حوالہ بنایا (دیکھیں #54908)۔
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ایک `RcBox<T>` کو ممکنہ طور پر غیر تبدیل شدہ داخلی قیمت کے لئے کافی جگہ کے ساتھ مختص کرتا ہے جہاں قیمت نے ترتیب فراہم کی ہے ، اگر مختص میں ناکام ہوجاتا ہے تو ایک غلطی واپس کرنا۔
    ///
    ///
    /// فنکشن `mem_to_rcbox` کو ڈیٹا پوائنٹر کے ساتھ بلایا جاتا ہے اور `RcBox<T>` کے لئے ایک (ممکنہ چربی) پوائنٹر واپس کرنا ہوگا۔
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // دیئے گئے قدر کی ترتیب کا استعمال کرکے ترتیب کا حساب لگائیں۔
        // اس سے قبل ، ترتیب `&*(ptr as* const RcBox<T>)` پر حساب کتاب کیا جاتا تھا ، لیکن اس نے غلط دستخط شدہ حوالہ بنایا (دیکھیں #54908)۔
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // لے آؤٹ کے لئے مختص کریں۔
        let ptr = allocate(layout)?;

        // RcBox شروع کریں
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// ایک غیر منقول اندرونی قدر کے ل sufficient کافی جگہ کے ساتھ ایک `RcBox<T>` مختص کرتا ہے
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // دی گئی قیمت کا استعمال کرتے ہوئے `RcBox<T>` کے لئے مختص کریں۔
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // بائٹس کے بطور قیمت کاپی کریں
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // مختص کو اس کے مندرجات کو چھوڑے بغیر آزاد کریں
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// دی گئی لمبائی کے ساتھ ایک `RcBox<[T]>` مختص کرتا ہے۔
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// عناصر کو سلائس سے نو مختص Rc <\[T\]> میں کاپی کریں
    ///
    /// غیر محفوظ ہے کیونکہ کال کرنے والے کو یا تو ملکیت لینا چاہئے یا `T: Copy` کا پابند ہونا چاہئے
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// ایک ایٹریٹر سے ایک `Rc<[T]>` بناتا ہے جو ایک خاص سائز کے نام سے جانا جاتا ہے۔
    ///
    /// سلوک غیر وضاحتی ہے جب سائز غلط ہونا چاہئے۔
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Z عناصر کی کلوننگ کرتے وقت Panic گارڈ۔
        // panic کی صورت میں ، نئے RcBox میں لکھے گئے عناصر کو گرا دیا جائے گا ، پھر میموری کو آزاد کردیا جائے گا۔
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // پہلے عنصر کی طرف اشارہ
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // سب صاف ہے۔گارڈ کو بھول جاؤ تاکہ وہ نئے آر سی بکس کو آزاد نہ کرے۔
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` کے لئے استعمال کی جانے والی تخصص trait
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` گرتا ہے۔
    ///
    /// اس سے مضبوط حوالہ شماری میں کمی آئے گی۔
    /// اگر مضبوط حوالہ شمار صفر تک پہنچ جاتا ہے تو صرف دوسرے حوالہ جات (اگر کوئی ہیں) [`Weak`] ہیں ، لہذا ہم داخلی قیمت کو `drop` کرتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // کچھ پرنٹ نہیں کرتا ہے
    /// drop(foo2);   // پرنٹ کریں "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // موجود چیز کو ختم کردیں
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // اب مضم "strong weak" پوائنٹر کو ہٹا دیں کہ ہم نے مندرجات کو ختم کردیا ہے۔
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` پوائنٹر کا کلون بناتا ہے۔
    ///
    /// یہ ایک ہی مختص کرنے کے لئے ایک اور پوائنٹر پیدا کرتا ہے ، جس میں مضبوط حوالہ شمار بڑھ جاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` کی `Default` قدر کے ساتھ ، ایک نیا `Rc<T>` تشکیل دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` پر مہارت حاصل کرنے کی اجازت دینے کے لئے ہیک اگرچہ `Eq` کا ایک طریقہ موجود ہے۔
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// ہم یہاں یہ تخصص کررہے ہیں ، اور نہ کہ `&T` پر زیادہ عمومی اصلاح کے طور پر ، کیوں کہ اس سے ریفوں پر مساوات کی تمام جانچ پڑتال میں لاگت آئے گی۔
/// ہم فرض کرتے ہیں کہ values Rc`s بڑی بڑی اقدار کو ذخیرہ کرنے کے لئے استعمال ہوتے ہیں ، جو کلون کرنے میں دھیمی ہوتی ہیں ، لیکن مساوات کی جانچ پڑتال میں بھی بھاری ہوتی ہیں ، جس کی وجہ سے اس لاگت کا آسانی سے ادائیگی ہوجاتا ہے۔
///
/// اس کے دو `Rc` کلون ہونے کا بھی زیادہ امکان ہے ، جو ایک ہی قدر کی طرف اشارہ کرتے ہیں ، دو `&T`s سے۔
///
/// ہم صرف اس وقت کر سکتے ہیں جب `T: Eq` بطور X01 ایکس جان بوجھ کر غیر مجاز ہوسکتا ہے۔
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// دو `Rc`s کے لئے مساوات۔
    ///
    /// دو `Rc`s برابر ہیں اگر ان کی داخلی اقدار برابر ہوں ، چاہے وہ مختلف مختص میں محفوظ ہوں۔
    ///
    /// اگر `T` بھی `Eq` (مساوات کا اضطراب) لاگو کرتا ہے تو ، دو `Rc` جو ایک ہی مختص کی طرف اشارہ کرتے ہیں وہ ہمیشہ برابر ہوتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// دو `Rc`s کے لئے عدم مساوات۔
    ///
    /// دو inner Rc valuess غیر مساوی ہیں اگر ان کی داخلی اقدار غیر مساوی ہیں۔
    ///
    /// اگر `T` بھی `Eq` (مساوات کا اضطراب) لاگو کرتا ہے تو ، دو `Rc` جو ایک ہی مختص کی طرف اشارہ کرتے ہیں وہ کبھی بھی غیر مساوی نہیں ہوتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// دو `Rc`s کے لئے جزوی موازنہ.
    ///
    /// دونوں کا موازنہ `partial_cmp()` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// دو `Rc`s کے مقابلے مقابلے سے کم۔
    ///
    /// دونوں کا موازنہ `<` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// دو than Rc`s کا موازنہ 'سے کم یا اس کے برابر'۔
    ///
    /// دونوں کا موازنہ `<=` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// دو `Rc`s کے مقابلے میں زیادہ سے زیادہ موازنہ۔
    ///
    /// دونوں کا موازنہ `>` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// دو than Rc`s کا موازنہ 'سے زیادہ یا اس کے برابر'۔
    ///
    /// دونوں کا موازنہ `>=` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// دو `Rc`s کے لئے موازنہ.
    ///
    /// دونوں کا موازنہ `cmp()` کو اپنی داخلی اقدار پر کال کرکے کیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// حوالہ گنتی سلائس مختص کریں اور `v` کے آئٹمز کو کلوننگ کرکے بھریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// حوالہ گنتی والی سٹرنگ سلائس مختص کریں اور اس میں `v` کاپی کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// حوالہ گنتی والی سٹرنگ سلائس مختص کریں اور اس میں `v` کاپی کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// باکسڈ آبجیکٹ کو ایک نئے ، حوالہ گنتی ، مختص پر منتقل کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// حوالہ گنتی والی سلائس مختص کریں اور اس میں آئٹمز منتقل کریں۔
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // وی ای سی کو اپنی میموری کو آزاد کرنے کی اجازت دیں ، لیکن اس کے مندرجات کو برباد نہ کریں
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// ہر عنصر کو `Iterator` میں لے جاتا ہے اور اسے `Rc<[T]>` میں جمع کرتا ہے۔
    ///
    /// # کارکردگی کی خصوصیات
    ///
    /// ## عام معاملہ
    ///
    /// عام حالت میں ، `Rc<[T]>` میں جمع کرنا پہلے `Vec<T>` میں جمع کرکے کیا جاتا ہے۔یہ ، جب مندرجہ ذیل لکھتے ہو:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// یہ اس طرح برتاؤ کرتا ہے جیسے ہم نے لکھا ہے:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // مختص کا پہلا سیٹ یہاں ہوتا ہے۔
    ///     .into(); // `Rc<[T]>` کے لئے دوسرا مختص یہاں ہوتا ہے۔
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// یہ `Vec<T>` کی تعمیر کے لئے ضرورت کے مطابق کئی بار مختص کرے گا اور پھر یہ `Vec<T>` کو `Rc<[T]>` میں تبدیل کرنے کے لئے ایک بار مختص ہوگا۔
    ///
    ///
    /// ## معلوم لمبائی کے منتظم
    ///
    /// جب آپ کا `Iterator` `TrustedLen` لاگو کرتا ہے اور اس کا سائز بالکل درست ہوتا ہے تو ، `Rc<[T]>` کے لئے ایک ہی رقم مختص کی جائے گی۔مثال کے طور پر:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // یہاں صرف ایک مختص ہوتا ہے۔
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` میں جمع کرنے کے لئے استعمال کی جانے والی تخصص trait
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // یہ معاملہ ایک `TrustedLen` ریڈیٹر کے لئے ہے۔
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // حفاظت: ہمیں یہ یقینی بنانا ہوگا کہ تکرار کرنے والی شخص کی لمبائی ٹھیک ہے اور ہمارے پاس ہے۔
                Rc::from_iter_exact(self, low)
            }
        } else {
            // عام نفاذ پر واپس گریں۔
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] کا ایک ایسا ورژن ہے جس میں زیر انتظام مختص کا غیر مالکانہ حوالہ ہے۔`Weak` پوائنٹر پر [`upgrade`] پر کال کرکے اس مختص تک رسائی حاصل کی گئی ہے ، جو [`آپشن`] returns <`[`Rc`] returns واپس کرتا ہے<T>>`.
///
/// چونکہ ایک `Weak` حوالہ ملکیت کی طرف نہیں ہے ، لہذا یہ مختص میں رکھی ہوئی قیمت کو گرنے سے نہیں روکے گا ، اور خود ہی `Weak` اس قیمت کی موجودگی کے بارے میں کوئی ضمانت نہیں دیتا ہے۔
/// اس طرح یہ [`None`] واپس آسکتا ہے جب [`اپ گریڈ`] ڈی۔
/// تاہم یہ نوٹ کریں کہ ایک `Weak` حوالہ *کرتا ہے* خود مختص (بیکنگ اسٹور) کو غیر موزوں ہونے سے روکتا ہے۔
///
/// ایک `Weak` پوائنٹر [`Rc`] کے ذریعہ اس کے اندرونی قدر کو گرانے سے روکنے کے بغیر مختص رقم کے عارضی حوالہ رکھنے کیلئے مفید ہے۔
/// یہ [`Rc`] پوائنٹر کے درمیان سرکلر حوالوں کو روکنے کے لئے بھی استعمال کیا جاتا ہے ، کیونکہ باہمی مالکانہ حوالہ جات کبھی بھی [`Rc`] کو خارج نہیں ہونے دیتا ہے۔
/// مثال کے طور پر ، ایک درخت میں والدین کے نوڈس سے بچوں تک مضبوط [`Rc`] پوائنٹر اور `Weak` پوائنٹر بچوں سے ان کے والدین کی طرف ہوسکتے ہیں۔
///
/// `Weak` پوائنٹر حاصل کرنے کا خاص طریقہ [`Rc::downgrade`] پر کال کرنا ہے۔
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // یہ ایک `NonNull` ہے تاکہ انامس میں اس قسم کے سائز کو بہتر بنایا جاسکے ، لیکن یہ ضروری نہیں کہ یہ ایک درست پوائنٹر ہو۔
    //
    // `Weak::new` اسے `usize::MAX` پر متعین کرتا ہے تاکہ ڈھیر پر جگہ مختص کرنے کی ضرورت نہ ہو۔
    // یہ ایک ایسی اہم قیمت نہیں ہے جس کے اصلی پوائنٹر کو کبھی حاصل ہوسکے کیونکہ آر سی بوکس میں کم سے کم 2 کی سیدھ ہوتی ہے۔
    // یہ تب ہی ممکن ہے جب `T: Sized`؛غیر منقسم `T` کبھی الجھنا نہیں۔
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// کسی بھی میموری کو مختص کیے بغیر ، نیا `Weak<T>` بناتا ہے۔
    /// [`upgrade`] کو واپسی کی قیمت پر کال کرنا ہمیشہ [`None`] دیتا ہے۔
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ڈیٹا فیلڈ کے بارے میں کوئی دعوی کیے بغیر حوالہ شماری تک رسائی کی اجازت دینے کیلئے مددگار کی قسم۔
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// اس `Weak<T>` کی طرف اشارہ کردہ آبجیکٹ `T` کی طرف ایک خام پوائنٹر لوٹاتا ہے۔
    ///
    /// پوائنٹر صرف اس صورت میں درست ہے جب کچھ مضبوط حوالہ جات ہوں۔
    /// ہوسکتا ہے کہ اشارہ پیچیدہ ، غیر دستخط شدہ یا [`null`] بھی ہو۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // دونوں ایک ہی چیز کی طرف اشارہ کرتے ہیں
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // یہاں کا طاقتور اسے زندہ رکھتا ہے ، لہذا ہم اب بھی اس چیز تک رسائی حاصل کرسکتے ہیں۔
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // مگر اب نہیں.
    /// // ہم weak.as_ptr() کرسکتے ہیں ، لیکن پوائنٹر تک پہنچنا غیر وضاحتی رویے کا باعث بنے گا۔
    /// // assert_eq! ("ہیلو" ، غیر محفوظ {&*weak.as_ptr() })؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // اگر پوائنٹر ڈینگ رہا ہے ، تو ہم سیدھا بھیج دیا جاتا ہے۔
            // یہ درست پے لوڈ کا پتہ نہیں ہوسکتا ہے ، کیونکہ پے لوڈ کم از کم RcBox (usize) کی طرح منسلک ہوتا ہے۔
            ptr as *const T
        } else {
            // حفاظت: اگر is_dangling غلط کو لوٹاتا ہے ، تو پھر پوائنٹر قابل تعزیر ہے۔
            // اس وقت پے لوڈ کو گرایا جاسکتا ہے ، اور ہمیں پروانوانس برقرار رکھنا ہے ، لہذا خام پوائنٹر ہیرا پھیری کا استعمال کریں۔
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` استعمال کرتا ہے اور اسے خام پوائنٹر میں بدل دیتا ہے۔
    ///
    /// یہ کمزور پوائنٹر کو خام پوائنٹر میں تبدیل کرتا ہے ، جبکہ اب بھی ایک کمزور حوالہ کی ملکیت کو محفوظ رکھتے ہوئے (کمزور گنتی کو اس آپریشن سے تبدیل نہیں کیا جاتا ہے)۔
    /// اسے [`from_raw`] کے ساتھ `Weak<T>` میں تبدیل کیا جاسکتا ہے۔
    ///
    /// [`as_ptr`] کے ساتھ ہی پوائنٹر کے ہدف تک رسائی کی وہی پابندیاں لاگو ہوتی ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// اس سے پہلے [`into_raw`] کے ذریعہ تیار کردہ ایک خام پوائنٹر کو `Weak<T>` میں تبدیل کرتا ہے۔
    ///
    /// اس کو مستحکم حوالہ حاصل کرنے کے لئے استعمال کیا جاسکتا ہے ([`upgrade`] کو بعد میں کال کرکے) یا `Weak<T>` کو چھوڑ کر کمزور گنتی کو ختم کرنا ہے۔
    ///
    /// یہ ایک ضعیف حوالہ کی ملکیت لیتا ہے ([`new`] کے ذریعہ تخلیق کردہ نکات کی رعایت کے ساتھ ، کیونکہ یہ کسی بھی چیز کے مالک نہیں ہیں؛ طریقہ اب بھی ان پر کام کرتا ہے)۔
    ///
    /// # Safety
    ///
    /// پوائنٹر کی ابتدا [`into_raw`] سے ہونی چاہئے اور اس کے اب بھی اس کے امکانی کمزور حوالہ کا مالک ہونا ضروری ہے۔
    ///
    /// اس کو کال کرنے کے وقت مضبوط گنتی 0 رکھنے کی اجازت ہے۔
    /// بہر حال ، اس میں ایک ضعیف حوالہ کی ملکیت لی گئی ہے جو فی الحال خام پوائنٹر کی حیثیت سے نمائندگی کی گئی ہے (اس آپریشن سے کمزور گنتی میں کوئی تبدیلی نہیں کی گئی ہے) اور اس لئے اسے [`into_raw`] پر سابقہ کال کے ساتھ جوڑا بنانا ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // آخری کمزور گنتی کو کم کریں۔
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ان پٹ پوائنٹر کس طرح نکالا جاتا ہے اس سیاق و سباق کے لئے Weak::as_ptr دیکھیں۔

        let ptr = if is_dangling(ptr as *mut T) {
            // یہ بے ربط کمزور ہے۔
            ptr as *mut RcBox<T>
        } else {
            // بصورت دیگر ، ہم اس بات کی ضمانت دے رہے ہیں کہ پوائنٹر نونڈنگلنگ کمزور سے آیا ہے۔
            // سیفٹی: ڈیٹا_ آفسیٹ فون کرنا محفوظ ہے ، کیونکہ پی ٹی آر ایک حقیقی (ممکنہ طور پر گرا ہوا) ٹی کا حوالہ دیتا ہے۔
            let offset = unsafe { data_offset(ptr) };
            // اس طرح ، ہم پورے آر سی باکس کو حاصل کرنے کے لئے آفسیٹ کو پلٹ دیتے ہیں۔
            // حفاظت: اشارہ ایک کمزور سے ہوا ہے ، لہذا یہ آفسیٹ محفوظ ہے۔
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // محفوظ کریں: اب ہم نے اصل کمزور پوائنٹر کو بازیافت کرلیا ہے ، لہذا کمزور پیدا کرسکتے ہیں۔
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` پوائنٹر کو [`Rc`] میں اپ گریڈ کرنے کی کوششیں ، اگر کامیاب ہو تو داخلی قدر گرنے میں تاخیر کریں۔
    ///
    ///
    /// اگر داخلی قیمت گرا دی گئی ہو تو [`None`] واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // تمام مضبوط پوائنٹرز کو خارج کر دیں۔
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// اس مختص کی طرف اشارہ کرنے والے مضبوط (`Rc`) پوائنٹرز کی تعداد حاصل کرتی ہے۔
    ///
    /// اگر `self` [`Weak::new`] کا استعمال کرتے ہوئے تخلیق کیا گیا تھا ، تو یہ 0 واپس آئے گا۔
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// اس مختص کی طرف اشارہ کرتے ہوئے `Weak` پوائنٹرز کی تعداد حاصل ہوتی ہے۔
    ///
    /// اگر کوئی مضبوط اشارہ باقی نہیں رہا تو ، یہ صفر واپس آجائے گا۔
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ضمنی کمزور پی ٹی آر کو منہا کریں
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// `None` لوٹاتا ہے جب پوائنٹر میں خستہ ہوتا ہے اور کوئی مختص `RcBox` نہیں ہوتا ہے ، (یعنی ، جب یہ `Weak` `Weak::new` کے ذریعہ بنایا گیا تھا)۔
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ہم محتاط ہیں کہ "data" فیلڈ کا احاطہ کرتے ہوئے کوئی * حوالہ نہ بنائیں ، کیوں کہ فیلڈ کو بیک وقت تبدیل کیا جاسکتا ہے (مثال کے طور پر ، اگر آخری `Rc` کو گرا دیا جائے تو ، ڈیٹا فیلڈ کو جگہ جگہ چھوڑ دیا جائے گا)۔
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// اگر دو `کمزور ایک ہی مختص ([`ptr::eq`] کی طرح) کی طرف اشارہ کرتے ہیں ، یا اگر دونوں کسی بھی مختص کی طرف اشارہ نہیں کرتے ہیں تو `true` کی واپسی کرتا ہے (کیونکہ وہ `Weak::new()`) کے ساتھ بنی ہیں۔
    ///
    ///
    /// # Notes
    ///
    /// چونکہ اس نکات کا موازنہ کرتا ہے اس کا مطلب یہ ہے کہ `Weak::new()` ایک دوسرے کے برابر ہوں گے ، حالانکہ وہ کسی بھی مختص کی طرف اشارہ نہیں کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` کا موازنہ کرنا۔
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` پوائنٹر گرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // کچھ پرنٹ نہیں کرتا ہے
    /// drop(foo);        // پرنٹ کریں "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // کمزور گنتی 1 سے شروع ہوتی ہے ، اور صرف صفر ہوجائے گی اگر تمام مضبوط اشارے غائب ہوجائیں۔
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` پوائنٹر کا ایک کلون بناتا ہے جو ایک ہی مختص کی طرف اشارہ کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// ایک نیا `Weak<T>` تشکیل دیتا ہے ، اسے شروع کیے بغیر `T` کے لئے میموری مختص کرتا ہے۔
    /// [`upgrade`] کو واپسی کی قیمت پر کال کرنا ہمیشہ [`None`] دیتا ہے۔
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: ہم نے mem::forget سے محفوظ طریقے سے نمٹنے کے لئے یہاں شامل_کیا۔خاص طور پر
// اگر آپ mem::forget آر سی ایس (یا کمزوریاں) کرتے ہیں تو ، ریف گنتی اتنا بہہ سکتی ہے ، اور پھر آپ مختص آرسیس (یا کمزوروں) کے وجود سے آزاد کرسکتے ہیں۔
//
// ہم اسقاط حمل کردیتے ہیں کیونکہ یہ اس قدر کم ہورہی منظر ہے کہ ہمیں اس سے کوئی پرواہ نہیں ہوتی کہ کیا ہوتا ہے-کوئی حقیقی پروگرام کبھی بھی اس کا تجربہ نہیں کرنا چاہئے۔
//
// اس میں آپ کے پاس نہ ہونے کے برابر ہیڈ ہونا چاہئے کیوں کہ آپ کو Rust میں حقیقت میں ملکیت اور اقدام حرکیات کا شکریہ ادا کرنے کی ضرورت نہیں ہے۔
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // ہم قدر چھوڑنے کے بجائے اوور فلو کو ختم کرنا چاہتے ہیں۔
        // جب یہ کہا جاتا ہے تو حوالہ شماری کبھی صفر نہیں ہوگی۔
        // بہر حال ، ہم LLVM کو کسی دوسری صورت میں چھوٹ جانے والی اصلاح پر اشارہ کرنے کے لئے اسقاط حمل یہاں داخل کرتے ہیں۔
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // ہم قدر چھوڑنے کے بجائے اوور فلو کو ختم کرنا چاہتے ہیں۔
        // جب یہ کہا جاتا ہے تو حوالہ شماری کبھی صفر نہیں ہوگی۔
        // بہر حال ، ہم LLVM کو کسی دوسری صورت میں چھوٹ جانے والی اصلاح پر اشارہ کرنے کے لئے اسقاط حمل یہاں داخل کرتے ہیں۔
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// ایک پوائنٹر کے پیچھے پے لوڈ کیلئے `RcBox` کے اندر آفسیٹ حاصل کریں۔
///
/// # Safety
///
/// پوائنٹر کو T کی ایک درست مثال کے طور پر (اور اس کے لئے درست میٹا ڈیٹا ہونا چاہئے) کی طرف اشارہ کرنا چاہئے ، لیکن T کو چھوڑنے کی اجازت ہے۔
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // RcBox کے اختتام تک ناکارہ قدر کو سیدھ کریں۔
    // کیونکہ RcBox repr(C) ہے ، یہ ہمیشہ میموری کا آخری میدان ہوگا۔
    // سلامتی: چونکہ صرف غیر منحصر اقسام ہی ممکن ہیں ٹکڑے ، trait اشیاء ،
    // اور بیرونی اقسام ، ان پٹ حفاظت کی ضرورت فی الحال align_of_val_raw کی ضروریات کو پورا کرنے کے لئے کافی ہے۔یہ زبان کی نفاذ کی تفصیل ہے جس پر std کے باہر انحصار نہیں کیا جاسکتا ہے۔
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}