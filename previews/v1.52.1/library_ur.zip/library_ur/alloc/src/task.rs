#![stable(feature = "wake_trait", since = "1.51.0")]
//! غیر سنجیدہ کاموں کے ساتھ کام کرنے کیلئے اقسام اور Traits۔
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// ایک ایگزیکٹر پر کوئی کام جاگنے کا نفاذ۔
///
/// یہ trait [`Waker`] بنانے کے لئے استعمال کیا جاسکتا ہے۔
/// ایک ایگزیکیوٹر اس trait کے نفاذ کی وضاحت کرسکتا ہے ، اور اس کو استعمال کرتے ہوئے اس کام کو انجام دینے کے لئے ایک Waker تعمیر کرنے کے لئے استعمال کرسکتا ہے۔
///
/// یہ trait [`RawWaker`] تعمیر کرنے کے لئے میموری سے محفوظ اور ایرگونومک متبادل ہے۔
/// یہ کام کرنے والے عمومی ڈیزائن کی حمایت کرتا ہے جس میں کسی کام کو اٹھانے کے لئے استعمال ہونے والا ڈیٹا [`Arc`] میں اسٹور کیا جاتا ہے۔
/// کچھ ایگزیکٹرز (خاص طور پر جو ایمبیڈڈ سسٹم کے لئے ہیں) اس API کا استعمال نہیں کرسکتے ہیں ، اسی وجہ سے [`RawWaker`] ان سسٹم کے متبادل کے طور پر موجود ہے۔
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// ایک بنیادی `block_on` فنکشن جو زیڈ فیوچر0 زیڈ لیتا ہے اور اسے موجودہ تھریڈ پر مکمل ہونے تک چلاتا ہے۔
///
/// **Note:** یہ مثال سادگی کے لئے درستگی کا سودا کرتی ہے۔
/// ڈیڈ لاکس کو روکنے کے ل production ، پروڈکشن گریڈ کے نفاذ کو `thread::unpark` کے ساتھ انٹسٹیمیٹ کال کے ساتھ نیسٹ انوائسس کو بھی سنبھالنا ہوگا۔
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// جب ایسا ہوتا ہے تو ایک واکر موجودہ دھاگے کو اٹھاتا ہے۔
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// موجودہ تھریڈ پر تکمیل کے لئے future چلائیں۔
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // زیڈ0 فیوچر0 زیڈ کو پن کریں تاکہ اس پر پول لگ سکے۔
///     let mut fut = Box::pin(fut);
///
///     // future پر منتقل کرنے کے لئے ایک نیا سیاق و سباق بنائیں۔
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // تکمیل کیلئے future چلائیں۔
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// اس کام کو جاگو۔
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// ویکر کو کھائے بغیر اس کام کو جاگو۔
    ///
    /// اگر کوئی ایگزیکٹر واکر کو استعمال کیے بغیر بیدار ہونے کے لئے ایک سستا طریقہ کی حمایت کرتا ہے تو ، اسے اس طریقہ کار کو اوور رائیڈ کرنا چاہئے۔
    /// پہلے سے ، یہ [`Arc`] کو کلون کرتا ہے اور کلون پر [`wake`] کو کال کرتا ہے۔
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // حفاظت: یہ محفوظ ہے کیونکہ خام_واکر محفوظ طریقے سے تعمیر کرتے ہیں
        // آرک کی طرف سے ایک RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: را واکر کی تعمیر کے لئے یہ نجی فنکشن بجائے اس کے استعمال کیا جاتا ہے
// `From<Arc<W>> for RawWaker` امپیل میں اس کا خاکہ ڈالنا ، تاکہ یہ یقینی بنائے کہ `From<Arc<W>> for Waker` کی حفاظت کا دارومدار trait ڈسپیچ پر منحصر نہیں ہے ، بجائے اس کی کہ دونوں درخواستیں اس فعل کو براہ راست اور واضح طور پر کال کریں۔
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // اس کو کلون کرنے کے لئے آرک کے حوالہ شمار میں اضافہ کریں۔
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // آرک کو Wake::wake فنکشن میں منتقل کرتے ہوئے ، قدر سے بیدار ہوں
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // حوالہ کے ذریعہ جاگو ، ویکر کو گرنے سے بچنے کے ل Man دستی طور پر ڈراپ میں لپیٹیں
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ڈراپ آرک کے حوالہ شمار کو کم کریں
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}