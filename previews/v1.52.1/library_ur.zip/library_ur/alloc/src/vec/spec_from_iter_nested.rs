use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// اوور لیپنگ کی تخصص کو دستی طور پر ترجیح دینے کے لئے ضروری Vec::from_iter کے لئے ایک اور تخصیص trait تفصیلات کے لئے [`SpecFromIter`](super::SpecFromIter) دیکھیں۔
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // پہلی تکرار کو اندراج کریں ، کیوں کہ ZTvector0Z ہر صورت میں اس تکرار پر بڑھایا جارہا ہے جب تکرار خالی نہیں ہوتا ہے ، لیکن extend_desugared() میں موجود لوپ vector کو اس کے بعد آنے والے چند لوٹوں کی تکرار میں نہیں دیکھ پاتا ہے۔
        //
        // تو ہم branch بہتر پیشن گوئی حاصل کرتے ہیں۔
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // spec_extend() کو خالی Vecs کے لX X_X کو اپنے مخصوص نمائندوں کو نمائندہ بھیجنا ہوگا
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // spec_extend() کو خالی Vecs کے لX X_X کو اپنے مخصوص نمائندوں کو نمائندہ بھیجنا ہوگا
        //
        vector.spec_extend(iterator);
        vector
    }
}