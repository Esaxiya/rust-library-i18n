use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ماخذ مختص کو دوبارہ استعمال کرتے ہوئے وی ای سی میں ایٹریٹر پائپ لائن جمع کرنے کیلئے تخصص کا نشان
/// جگہ پر پائپ لائن پر عملدرآمد.
///
/// ماخذ کے والدین trait اس تخصیص تک رسائی کے ل to ماہر فنکشن کے لئے ضروری ہے جس کو دوبارہ استعمال کیا جائے۔
/// لیکن تخصص کے درست ہونے کے ل. یہ کافی نہیں ہے۔
/// امپیل پر اضافی حدیں دیکھیں۔
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-اندرونی SourceIter/InPlaceIterable traits صرف اڈاپٹر کی زنجیروں کے ذریعہ لاگو کیا جاتا ہے <Adapter<Adapter<IntoIter>>> (تمام core/std کی ملکیت ہے)۔
// اڈاپٹر کے نفاذ پر اضافی حدیں (`impl<I: Trait> Trait for Adapter<I>` سے آگے) صرف دوسرے traits پر انحصار کرتی ہیں جن کو پہلے ہی تخصص traits (کاپی ، ٹرسٹریڈ رینڈم ایکسیس ، فیوزڈ ایٹریٹر) کے طور پر نشان زد کیا گیا ہے۔
//
// I.e. مارکر صارف کی فراہم کردہ اقسام کی زندگی وقت پر انحصار نہیں کرتا ہے۔ماڈیولو کاپی ہول ، جس پر متعدد دوسری تخصصات پہلے ہی انحصار کرتی ہیں۔
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // اضافی تقاضے جن کا اظہار trait bounds کے ذریعے نہیں ہوسکتا ہے۔ہم اس کے بجائے کانسٹ ایال پر انحصار کرتے ہیں:
        // الف) کوئی زیڈ ایس ٹی نہیں ہے کیوں کہ دوبارہ استعمال کرنے کے لئے کوئی مختص نہیں ہوگا اور پوائنٹر ریاضی میں panic نہیں ہوگا B) سائز میچ جیسا کہ Alloc معاہدے کی ضرورت ہے ج) الائنمنٹ میچ جیسا کہ Alloc معاہدے کی ضرورت ہے
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // زیادہ عمومی عمل درآمد پر فال بیک
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // اس کے بعد سے کوشش کریں
        // - یہ کچھ اوٹریٹر اڈاپٹر کے لئے بہتر طور پر ویکٹرائز کرتا ہے
        // - کثرت داخلی طریقوں کے برعکس ، یہ صرف &mut خود لیتا ہے
        // - یہ ہمیں لکھنے کے پوائنٹر کو اس کے اندرونی حصے میں دھاگے کرنے اور آخر میں اسے واپس لینے دیتا ہے
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // تکرار کامیاب ہوگ، ، سر مت چھوڑیں
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // چیک کریں کہ کیا SourceIter معاہدہ کو برقرار رکھا گیا تھا: اگر وہ نہ ہوتے تو شاید ہم اس مقام تک بھی نہ پہنچ پائیں
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIteable معاہدہ چیک کریں.یہ تب ہی ممکن ہے اگر تکرار کرنے والا ماخذ کے اشارے کو بالکل بھی آگے بڑھا سکے۔
        // اگر یہ ٹرسٹڈ رینڈم ایکسیس کے ذریعے غیر چیک شدہ رسائی کا استعمال کرتا ہے تو پھر ماخذ اشارہ اپنی ابتدائی پوزیشن میں رہے گا اور ہم اسے حوالہ کے طور پر استعمال نہیں کرسکتے ہیں۔
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // وسیلہ کی دم پر کسی بھی باقی اقدار کو چھوڑیں لیکن ایک بار انٹوئٹر دائرہ کار سے باہر ہوجانے پر خود مختص کو چھوڑنے سے روکیں اگر ڈراپ panics تو ہم بھی dst_buf میں جمع کردہ کسی بھی عنصر کو لیک کریں۔
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // یہاں InPlaceIteable معاہدہ کی تصدیق ٹھیک نہیں کی جاسکتی ہے کیونکہ try_fold کے ماخذ کے اشارے کا ایک خصوصی حوالہ ہے جس کے ذریعہ ہم صرف کر سکتے ہیں جانچ پڑتال کریں کہ یہ ابھی بھی حد میں ہے یا نہیں۔
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}