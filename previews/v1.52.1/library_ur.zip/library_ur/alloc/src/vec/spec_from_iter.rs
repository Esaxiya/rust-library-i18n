use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter کے لئے استعمال کی جانے والی تخصص trait
///
/// ## وفد کا گراف:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ایک عام معاملہ vector کو کسی فنکشن میں منتقل کررہا ہے جو فوری طور پر vector میں دوبارہ جمع ہوتا ہے۔
        // اگر ہم انٹونیٹر کو آگے بڑھا ہی نہیں گیا ہے تو ہم اس کو شارٹ سرکٹ دے سکتے ہیں۔
        // جب اسے ترقی یافتہ کردیا گیا ہے تو ہم میموری کو دوبارہ استعمال کرسکتے ہیں اور ڈیٹا کو آگے لے جا سکتے ہیں۔
        // لیکن ہم صرف اس وقت کرتے ہیں جب نتیجے میں ویک کے پاس عام استعمال کنندہ کے ذریعے اس کو بنانے سے کہیں زیادہ غیر استعمال شدہ گنجائش نہ ہوگی۔
        //
        // اس حد کو سختی سے ضروری نہیں ہے کیوں کہ وی ای سی کے مختص سلوک کو جان بوجھ کر غیر مخصوص قرار دیا گیا ہے۔
        // لیکن یہ ایک قدامت پسند انتخاب ہے۔
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // spec_extend() کو خالی Vecs کے لX X_X کو اپنے مخصوص نمائندوں کو نمائندہ بھیجنا ہوگا
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// اس سے `iterator.as_slice().to_vec()` استعمال ہوتا ہے چونکہ حتمی صلاحیت + لمبائی کے بارے میں استدلال کرنے کے ل spec spec_extend کو مزید اقدامات اٹھانا چاہئے اور اس طرح مزید کام کرنا چاہئے۔
// `to_vec()` براہ راست صحیح رقم مختص کرتا ہے اور اسے بالکل بھرتا ہے۔
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) کے ساتھ موروثی `[T]::to_vec` طریقہ ، جو اس طریقہ کی تعریف کے لئے ضروری ہے ، دستیاب نہیں ہے۔
    // اس کے بجائے `slice::to_vec` فنکشن کا استعمال کریں جو صرف cfg(test) NB کے ساتھ دستیاب ہے مزید معلومات کے لئے slice.rs میں slice::hack ماڈیول دیکھیں
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}