use core::ptr::{self};
use core::slice::{self};

// جگہ جگہ تکرار کے لئے ایک مددگار ڈھانچہ جو تکرار کے منزل ٹکڑے یعنی سر کو گراتا ہے۔
// ماخذ سلائس (دم) کو انٹٹوٹر نے گرا دیا ہے۔
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}