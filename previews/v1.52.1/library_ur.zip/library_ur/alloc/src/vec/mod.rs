//! ڈھیر مختص کردہ مشمولات کے ساتھ ، ایک قابل ترقی پذیر سرنی قسم ، تحریری `Vec<T>`۔
//!
//! Vectors میں `O(1)` انڈیکسنگ ، Amorised `O(1)` دھکا (آخر تک) اور `O(1)` پاپ (آخر سے) ہے۔
//!
//!
//! Vectors یقینی بنائیں کہ وہ کبھی بھی `isize::MAX` بائٹ سے زیادہ مختص نہیں کرتے ہیں۔
//!
//! # Examples
//!
//! آپ واضح طور پر [`Vec::new`] کے ساتھ [`Vec`] تشکیل دے سکتے ہیں۔
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... یا [`vec!`] میکرو کا استعمال کرکے:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // دس زیرو
//! ```
//!
//! آپ vector کے اختتام پر [`push`] کی قدر کرسکتے ہیں (جو vector ضرورت کے مطابق بڑھ جائے گا):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! پوپنگ اقدار اسی طرح کام کرتی ہیں:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! زیڈ0 ویکٹرز0 زیڈ ([`Index`] اور [`IndexMut`] traits کے زریعے) اشاریہ سازی کی بھی حمایت کرتا ہے:
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// ایک متمول اگنے پانے والی صف کی قسم ، جس کو `Vec<T>` لکھا گیا اور 'vector' کا تلفظ کیا گیا۔
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] میکرو ابتداء کو زیادہ آسان بنانے کے لئے فراہم کیا جاتا ہے:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// یہ ایک `Vec<T>` کے ہر عنصر کو دی گئی قدر کے ساتھ ابتدا بھی کرسکتا ہے۔
/// یہ علیحدہ مراحل میں مختص کرنے اور ابتدا کرنے سے کہیں زیادہ کارآمد ہوسکتا ہے ، خاص کر جب زیرو زیکرو ز0 زیڈ کو شروع کرنا:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // مندرجہ ذیل مساوی ہے ، لیکن ممکنہ طور پر آہستہ:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// مزید معلومات کے لئے ، دیکھیں [Capacity and Reallocation](#capacity-and-reallocation)۔
///
/// ایک `Vec<T>` موثر اسٹیک کے طور پر استعمال کریں:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // پرنٹس 3 ، 2 ، 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` قسم اشاریہ کے ذریعہ اقدار تک رسائی حاصل کرنے کی اجازت دیتی ہے ، کیونکہ یہ [`Index`] trait پر عمل درآمد کرتی ہے۔اس کی ایک مثال زیادہ واضح ہوگی۔
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // یہ '2' دکھائے گا
/// ```
///
/// تاہم ، محتاط رہیں: اگر آپ کسی ایسے انڈیکس تک رسائی حاصل کرنے کی کوشش کرتے ہیں جو `Vec` میں نہیں ہے تو ، آپ کا سافٹ ویئر panic کرے گا!تم یہ نہیں کر سکتے:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// اگر آپ یہ چیک کرنا چاہتے ہیں کہ انڈیکس `Vec` میں ہے تو [`get`] اور [`get_mut`] استعمال کریں۔
///
/// # Slicing
///
/// ایک `Vec` تغیر پزیر ہوسکتا ہے۔دوسری طرف ، سلائسیں صرف پڑھنے والی اشیاء ہیں۔
/// ایک [slice][prim@slice] حاصل کرنے کے لئے ، [`&`] استعمال کریں۔مثال:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... اور بس یہی!
/// // آپ یہ بھی اس طرح کرسکتے ہیں:
/// let u: &[usize] = &v;
/// // یا اس طرح:
/// let u: &[_] = &v;
/// ```
///
/// Rust میں ، جب آپ صرف پڑھنے تک رسائی فراہم کرنا چاہتے ہیں تو vectors کے بجائے سلائسز کو دلائل کے طور پر منتقل کرنا زیادہ عام ہے۔[`String`] اور [`&str`] کے لئے بھی یہی ہے۔
///
/// # صلاحیت اور دوبارہ تعل .ق
///
/// vector کی گنجائش کسی بھی future عناصر کے لئے مختص جگہ کی مقدار ہے جو vector پر شامل کی جائے گی۔یہ کسی vector کی *لمبائی* کے ساتھ الجھن میں نہیں پڑتا ہے ، جو vector کے اندر اصل عناصر کی تعداد متعین کرتا ہے۔
/// اگر vector کی لمبائی اس کی صلاحیت سے زیادہ ہے تو ، اس کی گنجائش خود بخود بڑھ جائے گی ، لیکن اس کے عناصر کو دوبارہ سے نامزد کرنا پڑے گا۔
///
/// مثال کے طور پر ، 10 اور لمبائی 0 کی گنجائش والا ایک vector 10 مزید عناصر کے ل for خالی vector ہوگا۔vector پر 10 یا اس سے کم عناصر کو دھکیلنے سے اس کی صلاحیت میں کوئی تبدیلی نہیں آئے گی اور نہ ہی دوبارہ وقوع پذیر ہونے کا سبب بنے گا۔
/// تاہم ، اگر vector کی لمبائی بڑھ کر 11 کردی گئی ہے تو ، اس کو دوبارہ گنانا پڑے گا ، جو سست ہوسکتا ہے۔اس وجہ سے ، جب بھی vector حاصل کرنے کی توقع کی جاتی ہے اس کی وضاحت کے ل X [`Vec::with_capacity`] استعمال کرنے کی سفارش کی جاتی ہے۔
///
/// # Guarantees
///
/// ناقابل یقین حد تک بنیادی نوعیت کی وجہ سے ، X01 اپنے ڈیزائن کے بارے میں بہت سی ضمانتیں دیتا ہے۔اس بات کو یقینی بناتا ہے کہ عام حالت میں یہ کم سے کم سر کا درجہ رکھتا ہے ، اور غیر محفوظ کوڈ کے ذریعہ ابتدائی طریقوں سے صحیح طریقے سے جوڑ لیا جاسکتا ہے۔نوٹ کریں کہ ان گارنٹیوں میں ایک نا اہل `Vec<T>` ہے۔
/// اگر اضافی قسم کے پیرامیٹرز کو شامل کیا جاتا ہے (مثال کے طور پر ، کسٹم مختص کرنے والوں کی حمایت کرنا) ، تو ان کے ڈیفالٹس کو اوورراڈ کرنے سے سلوک بدل سکتا ہے۔
///
/// زیادہ تر بنیادی طور پر ، `Vec` ہے اور ہمیشہ ایک (پوائنٹر ، صلاحیت ، لمبائی) ٹرپلٹ ہوگا۔نہ زیادہ نہ کم.ان شعبوں کی ترتیب مکمل طور پر غیر متعینہ ہے ، اور آپ کو ان میں ترمیم کرنے کیلئے مناسب طریقے استعمال کرنا چاہ.۔
/// پوائنٹر کبھی بھی کالعدم نہیں ہو گا ، لہذا اس قسم کو کال پوائنٹر کو بہتر بنایا گیا ہے۔
///
/// تاہم ، ممکن ہے کہ اشارہ مختص شدہ میموری کی طرف اشارہ نہ کرے۔
/// خاص طور پر ، اگر آپ [`Vec::new`] ، [`vec![]`][`vec!`] ، [`Vec::with_capacity(0)`][`Vec::with_capacity`] ، یا خالی Vec پر [`shrink_to_fit`] پر کال کرکے ، صلاحیت 0 کے ساتھ ایک `Vec` تعمیر کرتے ہیں تو ، اس سے میموری مختص نہیں ہوگی۔اسی طرح ، اگر آپ `Vec` کے اندر صفر سائز کی اقسام کو ذخیرہ کرتے ہیں تو ، یہ ان کے لئے جگہ مختص نہیں کرے گا۔
/// *نوٹ کریں کہ اس معاملے میں `Vec` 0* کے [`capacity`] کی اطلاع نہیں دے سکتا ہے۔
/// `Vec` صرف اور صرف اگر [`میم: : سائز_::::مختص کرے گا<T>`]`() * capacity()> 0`۔
/// عام طور پر ، `ویک` کی مختص کی تفصیلات بہت ہی لطیف ہیں-اگر آپ `Vec` کا استعمال کرتے ہوئے میموری کو مختص کرنے کا ارادہ رکھتے ہیں اور اسے کسی اور چیز کے لئے استعمال کرتے ہیں (یا تو غیر محفوظ کوڈ کو منتقل کرنا ہے ، یا خود ہی میموری کی حمایت یافتہ مجموعہ تعمیر کرنا ہے) ، اس بات کا یقین کر لیں۔ `Vec` کو بازیافت کرنے کے ل X `from_raw_parts` کا استعمال کرکے اور اس کو چھوڑ کر اس میموری کو ختم کرنا۔
///
/// اگر کسی `Vec`*نے* مختص شدہ میموری کی ہے ، تو پھر جس میموری کی طرف اس کی طرف اشارہ کیا گیا ہے وہ ڈھیر پر ہے (جیسا کہ مختص کنندہ Rust کے ذریعہ بطور ڈیفالٹ استعمال کرنے کے لئے تشکیل دیا گیا ہے) ، اور اس کا اشارہ [`len`] کی ابتدا شدہ ، متضاد عناصر کی ترتیب کی طرف اشارہ کرتا ہے (آپ کیا کریں گے ملاحظہ کریں کہ کیا آپ نے اسے ٹکڑے پر مجبور کیا ہے) ، جس کے بعد [`صلاحیت`]`،`[`لین`] منطقی طور پر غیر منطقی ، متناسب عنصر ہیں۔
///
///
/// ایک vector جس میں عناصر `'a'` اور `'b'` 4 کی گنجائش موجود ہے ، ذیل میں دیکھا جاسکتا ہے۔سب سے اوپر کا حصہ `Vec` ڈھانچہ ہے ، اس میں ڈھیر ، لمبائی اور صلاحیت میں مختص کے سر کا ایک اشارہ ہوتا ہے۔
/// نچلا حصہ ڈھیر پر مختص ہے ، ایک متمول میموری بلاک۔
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **انی انٹیٹ** میموری کی نمائندگی کرتا ہے جو ابتدا نہیں کی گئی ہے ، دیکھیں [`MaybeUninit`]۔
/// - Note: ABI مستحکم نہیں ہے اور `Vec` اپنی یادداشت کی ترتیب (قطعات کی ترتیب سمیت) کے بارے میں کوئی ضمانت نہیں دیتا ہے۔
///
/// `Vec` کبھی بھی "small optimization" نہیں کرے گا جہاں دو وجوہات کی بناء پر عناصر کو اسٹیک پر دراصل ذخیرہ کیا جاتا ہے۔
///
/// * غیر محفوظ کوڈ کیلئے `Vec` کو صحیح طریقے سے جوڑنا زیادہ مشکل بنادے گا۔`Vec` کے مندرجات کا ایک مستحکم پتہ نہیں ہوتا اگر اسے صرف منتقل کردیا جاتا ، اور یہ معلوم کرنا زیادہ مشکل ہوگا کہ آیا `Vec` نے اصل میں میموری مختص کی ہے۔
///
/// * یہ عام معاملے پر جرمانہ عائد کرے گا ، جس میں ہر رسائی پر اضافی زیڈبرینچ0 زیڈ ہوگا۔
///
/// `Vec` خود بخود کبھی بھی سکڑ نہیں پائے گا ، یہاں تک کہ اگر مکمل خالی ہو۔یہ یقینی بناتا ہے کہ کوئی غیرضروری رقم مختص نہیں کی جارہی ہے۔`Vec` کو خالی کرنا اور پھر اسی [`len`] تک پُر کرنا ، مختص کرنے والے کو کال نہیں کرنا چاہئے۔اگر آپ غیر استعمال شدہ میموری کو آزاد کرنا چاہتے ہیں تو ، [`shrink_to_fit`] یا [`shrink_to`] استعمال کریں۔
///
/// [`push`] اور [`insert`] کبھی بھی (دوبارہ) مختص نہیں کرے گا اگر اطلاع شدہ صلاحیت کافی ہے۔[`push`] اور [`insert`]*مختص کرے گا*(دوبارہ) اگر [`لین`]`==`[`صلاحیت`]۔یعنی ، اطلاع دی گئی صلاحیت مکمل طور پر درست ہے ، اور اس پر بھروسہ کیا جاسکتا ہے۔یہاں تک کہ اگر مطلوب ہو تو `Vec` کے ذریعہ مختص شدہ میموری کو دستی طور پر آزاد کرنے کے لئے بھی استعمال کیا جاسکتا ہے۔
/// بلک اندراج کے طریقوں * کو دوبارہ سے تبدیل کرنا پڑ سکتا ہے ، یہاں تک کہ جب ضروری نہ ہو۔
///
/// `Vec` مکمل ہونے پر دوبارہ تعی .ن کرتے وقت کسی خاص ترقی کی حکمت عملی کی ضمانت نہیں دیتا ہے ، اور نہ ہی جب X01 ایکس بلایا جاتا ہے۔موجودہ حکمت عملی بنیادی ہے اور عدم استحکام کے عوامل کو استعمال کرنا مطلوبہ ثابت ہوسکتا ہے۔جو بھی حکمت عملی استعمال کی جاتی ہے وہ یقینا *O*(1) Amorised [`push`] کی ضمانت دے گی۔
///
/// `vec![x; n]`, `vec![a, b, c, d]` ، اور [`Vec::with_capacity(n)`][`Vec::with_capacity`] ، سبھی درخواست کی گنجائش کے ساتھ ایک `Vec` تیار کریں گے۔
/// اگر [`len`]`==`[`صلاحیت`] ، (جیسا کہ [`vec!`] میکرو کا معاملہ ہے) ، تو پھر `Vec<T>` کو [`Box<[T]>`][owned slice] میں تبدیل کیا جاسکتا ہے اور عناصر کو دوبارہ متعل movingق یا منتقل کیے بغیر۔
///
/// `Vec` اس سے ہٹا دیئے گئے کسی بھی ڈیٹا کو خاص طور پر اوور رائٹ نہیں کرے گا ، بلکہ اسے خاص طور پر محفوظ نہیں کرے گا۔اس کی بلاضرورت میموری سکریچ کی جگہ ہے جسے وہ چاہے استعمال کرسکتی ہے۔یہ عام طور پر صرف وہی کرے گا جو سب سے زیادہ موثر ہے یا بصورت دیگر آسان ہے۔حفاظتی مقاصد کے لئے مٹائے جانے والے ڈیٹا پر انحصار نہ کریں۔
/// یہاں تک کہ اگر آپ `Vec` چھوڑ دیتے ہیں تو ، اس کا بفر ایک اور `Vec` کے ذریعہ دوبارہ استعمال کیا جاسکتا ہے۔
/// یہاں تک کہ اگر آپ سب سے پہلے کسی `ویک memory کی یادداشت کو صفر کردیتے ہیں تو ، واقعتا happen ایسا نہیں ہوسکتا ہے کیونکہ آپٹائائزر اس کو کوئی ضمنی اثر نہیں سمجھتا ہے جس کو محفوظ رکھنا چاہئے۔
/// ایک معاملہ ہے جسے ہم نہیں توڑیں گے ، تاہم: زیادہ صلاحیت پر لکھنے کے لئے `unsafe` کوڈ کا استعمال کرنا ، اور پھر لمبائی میں اضافہ کرنا ، ہمیشہ درست ہے۔
///
/// فی الحال ، `Vec` آرڈر کی ضمانت نہیں دیتا ہے جس میں عناصر گرا دیئے گئے ہیں۔
/// ماضی میں آرڈر بدلا ہے اور دوبارہ تبدیل ہوسکتا ہے۔
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// موروثی طریقے
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// ایک نیا ، خالی `Vec<T>` بناتا ہے۔
    ///
    /// vector اس وقت تک مختص نہیں کرے گا جب تک کہ عناصر اس پر دھکیل نہ جائیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// مخصوص صلاحیت کے ساتھ ایک نیا ، خالی `Vec<T>` تشکیل دیتا ہے۔
    ///
    /// vector بغیر کسی اعداد و شمار کے بالکل `capacity` عنصر کو روک سکے گا۔
    /// اگر `capacity` 0 ہے تو ، vector مختص نہیں کرے گا۔
    ///
    /// یہ نوٹ کرنا ضروری ہے کہ اگرچہ لوٹائے گئے vector کی *صلاحیت* مخصوص ہے ، لیکن vector کی لمبائی ایک صفر * ہوگی۔
    ///
    /// طوالت اور استعداد کے مابین فرق کی وضاحت کے لئے ،*[صلاحیت اور دوبارہ مقام]* دیکھیں۔
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector میں کوئی اشیاء نہیں ہے ، حالانکہ اس میں زیادہ کی گنجائش ہے
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // یہ سب کچھ دوبارہ دیکھے بغیر کیا گیا ہے ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... لیکن اس سے vector دوبارہ شروع ہوسکتا ہے
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// کسی اور vector کے خام اجزاء سے براہ راست ایک `Vec<T>` بناتا ہے۔
    ///
    /// # Safety
    ///
    /// جانچ پڑتال نہ کرنے والے حملہ آوروں کی تعداد کی وجہ سے یہ انتہائی غیر محفوظ ہے۔
    ///
    /// * `ptr` اس سے پہلے [`سٹرنگ`]/`Vec کے توسط سے مختص کرنے کی ضرورت ہے<T>`(کم از کم ، اگر یہ غلط نہ تھا تو اس کا غلط امکان بہت زیادہ ہے)۔
    /// * `T` جس سائز میں `ptr` مختص کیا گیا تھا اسی سائز اور سیدھ کی ضرورت ہے۔
    ///   (`T` ایک کم سخت سیدھ کا ہونا کافی نہیں ہے ، [`dealloc`] کی ضروریات کو پورا کرنے کے لئے سیدھ میں واقعی برابر ہونے کی ضرورت ہے کہ میموری کو اسی ترتیب کے ساتھ مختص کیا جانا چاہئے اور اسے ختم کرنا ہوگا۔)
    ///
    /// * `length` `capacity` سے کم یا اس کے برابر ہونے کی ضرورت ہے۔
    /// * `capacity` اس صلاحیت کی ضرورت ہے جس کے ساتھ پوائنٹر مختص کیا گیا تھا۔
    ///
    /// ان کی خلاف ورزی کرنے سے مسائل کا سبب بن سکتا ہے جیسے مختص کرنے والے کے اندرونی ڈیٹا ڈھانچے کو خراب کرنا۔مثال کے طور پر **نہیں** XX1X لمبائی `size_t` کے ساتھ C `char` سرنی تک ایک پوائنٹر سے `Vec<u8>` بنانا محفوظ ہے۔
    /// ایک `Vec<u16>` اور اس کی لمبائی سے ایک بنانا بھی محفوظ نہیں ہے ، کیونکہ مختص کرنے والا صف بندی کا خیال رکھتا ہے ، اور ان دونوں اقسام میں مختلف سیدھ ہیں۔
    /// بفر سیدھ 2 (`u16` کے لئے) کے ساتھ مختص کیا گیا تھا ، لیکن اسے `Vec<u8>` میں تبدیل کرنے کے بعد اس کی سیدھ میں صفائی کی جائے گی۔
    ///
    /// `ptr` کی ملکیت `Vec<T>` کو مؤثر طریقے سے منتقل کردی گئی ہے جو اس کے بعد اشارے کے ذریعہ اشارہ کردہ میموری کے مشمولات کو منقطع کرسکتا ہے ، اسے دوبارہ سے بدل سکتا ہے یا تبدیل کرسکتا ہے۔
    /// اس بات کو یقینی بنائیں کہ اس فنکشن کو فون کرنے کے بعد اور کوئی بھی پوائنٹر استعمال نہیں کرتا ہے۔
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // درست کریں جب vec_into_raw_parts مستحکم ہو۔
    ///     // running v` کے ڈسٹرکٹر کو چلانے سے روکیں تاکہ ہم مختص کے مکمل کنٹرول میں ہوں۔
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` کے بارے میں معلومات کے مختلف اہم ٹکڑوں کو نکالیں
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4 ، 5 ، 6 کے ساتھ میموری کو اوور رائٹ کریں
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ہر چیز کو ایک ساتھ ایک ویک میں رکھو
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// ایک نیا ، خالی `Vec<T, A>` بناتا ہے۔
    ///
    /// vector اس وقت تک مختص نہیں کرے گا جب تک کہ عناصر اس پر دھکیل نہ جائیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// فراہم کردہ مختص کنندہ کے ساتھ مخصوص صلاحیت کے ساتھ ایک نیا ، خالی `Vec<T, A>` تشکیل دیتا ہے۔
    ///
    /// vector بغیر کسی اعداد و شمار کے بالکل `capacity` عنصر کو روک سکے گا۔
    /// اگر `capacity` 0 ہے تو ، vector مختص نہیں کرے گا۔
    ///
    /// یہ نوٹ کرنا ضروری ہے کہ اگرچہ لوٹائے گئے vector کی *صلاحیت* مخصوص ہے ، لیکن vector کی لمبائی ایک صفر * ہوگی۔
    ///
    /// طوالت اور استعداد کے مابین فرق کی وضاحت کے لئے ،*[صلاحیت اور دوبارہ مقام]* دیکھیں۔
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector میں کوئی اشیاء نہیں ہے ، حالانکہ اس میں زیادہ کی گنجائش ہے
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // یہ سب کچھ دوبارہ دیکھے بغیر کیا گیا ہے ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... لیکن اس سے vector دوبارہ شروع ہوسکتا ہے
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// کسی اور vector کے خام اجزاء سے براہ راست ایک `Vec<T, A>` بناتا ہے۔
    ///
    /// # Safety
    ///
    /// جانچ پڑتال نہ کرنے والے حملہ آوروں کی تعداد کی وجہ سے یہ انتہائی غیر محفوظ ہے۔
    ///
    /// * `ptr` اس سے پہلے [`سٹرنگ`]/`Vec کے توسط سے مختص کرنے کی ضرورت ہے<T>`(کم از کم ، اگر یہ غلط نہ تھا تو اس کا غلط امکان بہت زیادہ ہے)۔
    /// * `T` جس سائز میں `ptr` مختص کیا گیا تھا اسی سائز اور سیدھ کی ضرورت ہے۔
    ///   (`T` ایک کم سخت سیدھ کا ہونا کافی نہیں ہے ، [`dealloc`] کی ضروریات کو پورا کرنے کے لئے سیدھ میں واقعی برابر ہونے کی ضرورت ہے کہ میموری کو اسی ترتیب کے ساتھ مختص کیا جانا چاہئے اور اسے ختم کرنا ہوگا۔)
    ///
    /// * `length` `capacity` سے کم یا اس کے برابر ہونے کی ضرورت ہے۔
    /// * `capacity` اس صلاحیت کی ضرورت ہے جس کے ساتھ پوائنٹر مختص کیا گیا تھا۔
    ///
    /// ان کی خلاف ورزی کرنے سے مسائل کا سبب بن سکتا ہے جیسے مختص کرنے والے کے اندرونی ڈیٹا ڈھانچے کو خراب کرنا۔مثال کے طور پر **نہیں** XX1X لمبائی `size_t` کے ساتھ C `char` سرنی تک ایک پوائنٹر سے `Vec<u8>` بنانا محفوظ ہے۔
    /// ایک `Vec<u16>` اور اس کی لمبائی سے ایک بنانا بھی محفوظ نہیں ہے ، کیونکہ مختص کرنے والا صف بندی کا خیال رکھتا ہے ، اور ان دونوں اقسام میں مختلف سیدھ ہیں۔
    /// بفر سیدھ 2 (`u16` کے لئے) کے ساتھ مختص کیا گیا تھا ، لیکن اسے `Vec<u8>` میں تبدیل کرنے کے بعد اس کی سیدھ میں صفائی کی جائے گی۔
    ///
    /// `ptr` کی ملکیت `Vec<T>` کو مؤثر طریقے سے منتقل کردی گئی ہے جو اس کے بعد اشارے کے ذریعہ اشارہ کردہ میموری کے مشمولات کو منقطع کرسکتا ہے ، اسے دوبارہ سے بدل سکتا ہے یا تبدیل کرسکتا ہے۔
    /// اس بات کو یقینی بنائیں کہ اس فنکشن کو فون کرنے کے بعد اور کوئی بھی پوائنٹر استعمال نہیں کرتا ہے۔
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // درست کریں جب vec_into_raw_parts مستحکم ہو۔
    ///     // running v` کے ڈسٹرکٹر کو چلانے سے روکیں تاکہ ہم مختص کے مکمل کنٹرول میں ہوں۔
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` کے بارے میں معلومات کے مختلف اہم ٹکڑوں کو نکالیں
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4 ، 5 ، 6 کے ساتھ میموری کو اوور رائٹ کریں
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ہر چیز کو ایک ساتھ ایک ویک میں رکھو
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// ایک `Vec<T>` کو اپنے خام اجزاء میں تحلیل کرتا ہے۔
    ///
    /// بنیادی اعداد و شمار ، vector کی لمبائی (عناصر میں) اور اعداد و شمار کی مختص گنجائش (عناصر میں) کو خام پوائنٹر واپس کرتا ہے۔
    /// یہ اسی ترتیب میں ایک جیسے دلائل ہیں جیسے [`from_raw_parts`] پر دلائل۔
    ///
    /// اس فنکشن کو فون کرنے کے بعد ، کالر `Vec` کے ذریعہ پہلے سے زیر انتظام میموری کی ذمہ دار ہے۔
    /// ایسا کرنے کا واحد طریقہ یہ ہے کہ خام پوائنٹر ، لمبائی اور صلاحیت کو واپس X0 X میں [`from_raw_parts`] فنکشن کے ساتھ تبدیل کیا جائے ، جس سے تباہ کن شخص کو صفائی کرنے کا موقع مل سکے۔
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // اب ہم اجزاء میں تبدیلیاں لا سکتے ہیں ، جیسے خام پوائنٹر کو مطابقت پذیر قسم میں منتقل کرنا۔
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// ایک `Vec<T>` کو اپنے خام اجزاء میں تحلیل کرتا ہے۔
    ///
    /// بنیادی اعداد و شمار ، vector کی لمبائی (عناصر میں) ، اعداد و شمار کی مختص گنجائش (عناصر میں) اور مختص کنندہ کو خام پوائنٹر واپس کرتا ہے۔
    /// یہ اسی ترتیب میں ایک جیسے دلائل ہیں جیسے [`from_raw_parts_in`] پر دلائل۔
    ///
    /// اس فنکشن کو فون کرنے کے بعد ، کالر `Vec` کے ذریعہ پہلے سے زیر انتظام میموری کی ذمہ دار ہے۔
    /// ایسا کرنے کا واحد طریقہ یہ ہے کہ خام پوائنٹر ، لمبائی اور صلاحیت کو واپس X0 X میں [`from_raw_parts_in`] فنکشن کے ساتھ تبدیل کیا جائے ، جس سے تباہ کن شخص کو صفائی کرنے کا موقع مل سکے۔
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // اب ہم اجزاء میں تبدیلیاں لا سکتے ہیں ، جیسے خام پوائنٹر کو مطابقت پذیر قسم میں منتقل کرنا۔
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector ان عناصر کی تعداد لوٹاتا ہے جو Zelvector0Z کو دوبارہ بغیر کسی اشارے کے پکڑ سکتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// دیئے گئے `Vec<T>` میں کم از کم `additional` مزید عناصر داخل کرنے کی گنجائش محفوظ ہے۔
    /// کثرت رائے سے بچنے کے لئے مجموعہ میں مزید جگہ محفوظ ہوسکتی ہے۔
    /// `reserve` پر کال کرنے کے بعد ، صلاحیت `self.len() + additional` سے زیادہ یا اس کے برابر ہوگی۔
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `isize::MAX` بائٹس سے زیادہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// دیئے گئے `Vec<T>` میں بالکل `additional` مزید عناصر داخل کرنے کے لئے کم سے کم گنجائش کا ذخیرہ کریں۔
    ///
    /// `reserve_exact` پر کال کرنے کے بعد ، صلاحیت `self.len() + additional` سے زیادہ یا اس کے برابر ہوگی۔
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// نوٹ کریں کہ مختص کرنے والا اس کی درخواست سے کہیں زیادہ جگہ دے سکتا ہے۔
    /// لہذا ، عین مطابق کم سے کم ہونے کی صلاحیت پر انحصار نہیں کیا جاسکتا ہے۔
    /// اگر future اضافے کی توقع ہے تو `reserve` کو ترجیح دیں۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `usize` سے زیادہ بہتی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// دیئے گئے `Vec<T>` میں کم از کم `additional` مزید عناصر داخل کرنے کی گنجائش کو محفوظ کرنے کی کوشش کرتا ہے۔
    /// کثرت رائے سے بچنے کے لئے مجموعہ میں مزید جگہ محفوظ ہوسکتی ہے۔
    /// `try_reserve` پر کال کرنے کے بعد ، صلاحیت `self.len() + additional` سے زیادہ یا اس کے برابر ہوگی۔
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// # Errors
    ///
    /// اگر استعداد کار سے زیادہ بہہ گیا ہے ، یا مختص کنندہ نے ناکامی کی اطلاع دی ہے ، تو ایک خامی واپس کردی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // میموری کو پہلے سے محفوظ کریں ، اگر ہم نہیں کر سکتے تو باہر نکل رہے ہیں
    ///     output.try_reserve(data.len())?;
    ///
    ///     // اب ہم جانتے ہیں کہ یہ ہمارے پیچیدہ کام کے بیچ او اوم نہیں کرسکتا
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // بہت پیچیدہ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// `additional` عناصر کو دیئے جانے والے `Vec<T>` میں ڈالنے کیلئے کم سے کم گنجائش کو محفوظ کرنے کی کوشش کرتا ہے۔
    /// `try_reserve_exact` پر کال کرنے کے بعد ، اگر یہ `Ok(())` لوٹاتا ہے تو صلاحیت `self.len() + additional` سے زیادہ یا اس کے برابر ہوگی۔
    ///
    /// اگر صلاحیت پہلے سے ہی کافی ہے تو کچھ نہیں کرتا ہے۔
    ///
    /// نوٹ کریں کہ مختص کرنے والا اس کی درخواست سے کہیں زیادہ جگہ دے سکتا ہے۔
    /// لہذا ، عین مطابق کم سے کم ہونے کی صلاحیت پر انحصار نہیں کیا جاسکتا ہے۔
    /// اگر future اضافے کی توقع ہے تو `reserve` کو ترجیح دیں۔
    ///
    /// # Errors
    ///
    /// اگر استعداد کار سے زیادہ بہہ گیا ہے ، یا مختص کنندہ نے ناکامی کی اطلاع دی ہے ، تو ایک خامی واپس کردی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // میموری کو پہلے سے محفوظ کریں ، اگر ہم نہیں کر سکتے تو باہر نکل رہے ہیں
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // اب ہم جانتے ہیں کہ یہ ہمارے پیچیدہ کام کے بیچ او اوم نہیں کرسکتا
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // بہت پیچیدہ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// زیادہ سے زیادہ vector کی صلاحیت کو گھٹا دیتا ہے۔
    ///
    /// یہ لمبائی کے قریب سے نیچے گر جائے گا لیکن مختص کرنے والا ابھی بھی vector کو اطلاع دے سکتا ہے کہ کچھ اور عناصر کے ل space جگہ موجود ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // صلاحیت کبھی بھی لمبائی سے کم نہیں ہوتی ہے ، اور جب ان کے مساوی ہوتے ہیں تو اس کے ل do کچھ کرنے کی ضرورت نہیں ہے ، لہذا ہم صرف `RawVec::shrink_to_fit` میں panic کیس سے صرف ایک بڑی صلاحیت کے ساتھ کال کرکے بچ سکتے ہیں۔
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector کی گنجائش کو کم حد کے ساتھ گھٹا دیتا ہے۔
    ///
    /// گنجائش کم از کم لمبائی اور فراہم کردہ قیمت دونوں کی حد تک ہی باقی رہے گی۔
    ///
    ///
    /// اگر موجودہ صلاحیت کم حد سے کم ہے تو ، یہ کوئی آپٹ نہیں ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector کو [`Box<[T]>`][owned slice] میں تبدیل کرتا ہے۔
    ///
    /// نوٹ کریں کہ اس سے کسی بھی اضافی گنجائش کی کمی ہوگی۔
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// کسی بھی اضافی صلاحیت کو ہٹا دیا جاتا ہے:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector کو مختصر کرتا ہے ، پہلے `len` عنصر کو برقرار رکھتے ہوئے اور باقی کو چھوڑ دیتا ہے۔
    ///
    /// اگر `len` vector کی موجودہ لمبائی سے زیادہ ہے تو ، اس کا کوئی اثر نہیں ہوگا۔
    ///
    /// [`drain`] طریقہ `truncate` کی تقلید کرسکتا ہے ، لیکن اضافی عناصر کو گرانے کی بجائے لوٹ سکتا ہے۔
    ///
    ///
    /// نوٹ کریں کہ vector کی مختص گنجائش پر اس طریقہ کار کا کوئی اثر نہیں ہے۔
    ///
    /// # Examples
    ///
    /// پانچ عنصر vector کو دو عنصروں میں تراشنا:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// جب `len` vector کی موجودہ لمبائی سے زیادہ ہے تو کوئی تنزلی نہیں ہوتی ہے:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// جب `len == 0` [`clear`] طریقہ کو کال کرنے کے مترادف ہے تو چھوٹ دینا۔
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // یہ محفوظ ہے کیونکہ:
        //
        // * `drop_in_place` پر منتقل سلائس درست ہے؛`len > self.len` کیس غلط سلائس بنانے سے گریز کرتا ہے ، اور
        // * vector کا `len` `drop_in_place` پر فون کرنے سے پہلے سکڑ گیا ہے ، جیسے `drop_in_place` میں ایک بار panic کرنے کی صورت میں کوئی قیمت دو بار نہیں گرایا جائے گا (اگر یہ panics دو بار ہے تو ، پروگرام ختم ہوجاتا ہے)۔
        //
        //
        //
        unsafe {
            // Note: یہ جان بوجھ کر ہے کہ یہ `>` ہے اور `>=` نہیں۔
            //       اسے `>=` میں تبدیل کرنے سے کچھ معاملات میں کارکردگی کے منفی اثرات مرتب ہوتے ہیں۔
            //       مزید کے لئے #78884 دیکھیں۔
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// پورے vector پر مشتمل ایک ٹکڑا نکالتا ہے۔
    ///
    /// `&s[..]` کے برابر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// پورے vector کی ایک تغیر پزیر ٹکڑا نکالتا ہے۔
    ///
    /// `&mut s[..]` کے برابر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector کے بفر پر خام پوائنٹر لوٹاتا ہے۔
    ///
    /// کال کرنے والے کو یہ یقینی بنانا ہوگا کہ vector اس فنکشن کے واپس آنے والے پوائنٹر سے نکل جائے گا ، ورنہ یہ کچرے کی طرف اشارہ کرکے ختم ہوگا۔
    /// vector میں ترمیم کرنے سے اس کا بفر دوبارہ آباد ہوسکتا ہے ، جس سے اس کی طرف کوئی اشارہ بھی غلط ہوجاتا ہے۔
    ///
    /// کال کرنے والے کو یہ بھی یقینی بنانا ہوگا کہ (non-transitively) جس نکتے کی طرف اشارہ کرتا ہے اسے اس پوائنٹر یا اس سے ماخوذ کسی بھی پوائنٹر کا استعمال کرتے ہوئے (`UnsafeCell` کے علاوہ) کبھی نہیں لکھا جاتا ہے۔
    /// اگر آپ کو سلائس کے مندرجات کو تبدیل کرنے کی ضرورت ہو تو ، [`as_mut_ptr`] استعمال کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // ہم `deref` کے ذریعے جانے سے بچنے کے ل the اسی نام کے ٹکڑے کا طریقہ سایہ کرتے ہیں ، جو ایک انٹرمیڈیٹ حوالہ تشکیل دیتا ہے۔
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector کے بفر پر غیر محفوظ غیر تبدیل شدہ پوائنٹر واپس کرتا ہے۔
    ///
    /// کال کرنے والے کو یہ یقینی بنانا ہوگا کہ vector اس فنکشن کے واپس آنے والے پوائنٹر سے نکل جائے گا ، ورنہ یہ کچرے کی طرف اشارہ کرکے ختم ہوگا۔
    ///
    /// vector میں ترمیم کرنے سے اس کا بفر دوبارہ آباد ہوسکتا ہے ، جس سے اس کی طرف کوئی اشارہ بھی غلط ہوجاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// // vector 4 عناصر کے ل enough کافی حد تک مختص کریں۔
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // کچے پوائنٹر لکھتے ہوئے عناصر کا آغاز کریں ، پھر طوالت طے کریں۔
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // ہم `deref_mut` کے ذریعے جانے سے بچنے کے ل the اسی نام کے ٹکڑے کا طریقہ سایہ کرتے ہیں ، جو ایک انٹرمیڈیٹ حوالہ تشکیل دیتا ہے۔
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// بنیادی مختص کرنے والے کا حوالہ لوٹاتا ہے۔
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector کی لمبائی کو `new_len` پر مجبور کرتا ہے۔
    ///
    /// یہ ایک نچلی سطح کا آپریشن ہے جو قسم کے عام حملہ آوروں میں سے کسی کو برقرار نہیں رکھتا ہے۔
    /// عام طور پر vector کی لمبائی تبدیل کرنا اس کی بجائے [`truncate`] ، [`resize`] ، [`extend`] ، یا [`clear`] جیسے محفوظ آپریشنوں میں سے ایک کا استعمال کرتے ہوئے کیا جاتا ہے۔
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] سے کم یا اس کے برابر ہونا چاہئے۔
    /// - `old_len..new_len` میں موجود عناصر کو شروع کرنا ضروری ہے۔
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// یہ طریقہ ان حالات کے لئے کارآمد ثابت ہوسکتا ہے جہاں vector دوسرے کوڈ کے لئے بفر کے طور پر خدمات انجام دے رہا ہے ، خاص طور پر FFI پر:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // یہ دستاویز کی مثال کے لئے کم سے کم کنکال ہے۔
    /// # // اسے کسی حقیقی لائبریری کے نقط starting آغاز کے طور پر استعمال نہ کریں۔
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI طریقہ کار کے دستاویزات کے مطابق ، "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // محفوظ کریں: جب `deflateGetDictionary` `Z_OK` کو لوٹاتا ہے تو ، اس میں یہ شامل ہوتا ہے:
    ///     // 1. `dict_length` عناصر کی ابتدا کی گئی تھی۔
    ///     // 2.
    ///     // `dict_length` <=صلاحیت (32_768) جو `set_len` کو کال کرنے کیلئے محفوظ بنائے۔
    ///     unsafe {
    ///         // FFI کال کریں ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... اور جس کی ابتدا کی گئی تھی اس کی لمبائی کو اپ ڈیٹ کریں۔
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// جب کہ مندرجہ ذیل مثال مستحکم ہے ، وہاں میموری میموری ہے کیونکہ اندرونی vectors کو `set_len` کال سے قبل آزاد نہیں کیا گیا تھا:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` خالی ہے لہذا کسی عنصر کو شروع کرنے کی ضرورت نہیں ہے۔
    /// // 2. `0 <= capacity` جو کچھ بھی ہے `capacity` ہمیشہ رکھتا ہے۔
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// عام طور پر ، یہاں ایک [`clear`] استعمال کرنے کے بجائے مشمولات کو صحیح طور پر گرا دیتا ہے اور اس طرح میموری کو خارج نہیں کرتا ہے۔
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector سے عنصر کو ہٹا دیتا ہے اور اسے لوٹاتا ہے۔
    ///
    /// ہٹائے گئے عنصر کی جگہ vector کے آخری عنصر نے لے لی ہے۔
    ///
    /// یہ آرڈرنگ کو محفوظ نہیں رکھتا ہے ، لیکن یہ O(1) ہے۔
    ///
    /// # Panics
    ///
    /// اگر `index` حد سے باہر ہے تو Panics۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // ہم خود [انڈیکس] کو آخری عنصر سے تبدیل کرتے ہیں۔
            // نوٹ کریں کہ اگر حدود کی جانچ پڑتال کامیاب ہوجاتی ہے تو وہاں ایک آخری عنصر ہونا ضروری ہے (جو خود [انڈیکس] خود ہوسکتا ہے)۔
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector کے اندر `index` پوزیشن پر عنصر داخل کرتا ہے ، تمام عناصر کو اس کے بعد دائیں طرف منتقل کرتا ہے۔
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `index > len` ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // نئے عنصر کے لئے جگہ
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // نئی قیمت ڈالنے کے لئے جگہ
            //
            {
                let p = self.as_mut_ptr().add(index);
                // جگہ بنانے کیلئے ہر چیز پر شفٹ کریں۔
                // (`انڈیکس` عنصر کو لگاتار دو مقامات پر نقل کرنا۔)
                ptr::copy(p, p.offset(1), len - index);
                // اس میں لکھیں ، `انڈیکس` عنصر کی پہلی کاپی کو اوور رائٹ کرتے ہوئے۔
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector کے اندر `index` پوزیشن پر عنصر کو ہٹاتا اور واپس کرتا ہے ، اور اس کے بعد تمام عناصر کو بائیں طرف منتقل کرتا ہے۔
    ///
    ///
    /// # Panics
    ///
    /// اگر `index` حد سے باہر ہے تو Panics۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // ہم جس جگہ سے لے رہے ہیں۔
                let ptr = self.as_mut_ptr().add(index);
                // اس کو کاپی کریں ، غیر محفوظ طریقے سے ایک ہی وقت میں اسٹیک پر اور vector میں قیمت کی ایک کاپی موجود ہے۔
                //
                ret = ptr::read(ptr);

                // اس جگہ کو پُر کرنے کیلئے ہر چیز کو نیچے شفٹ کریں۔
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// پیش گوئی کے ذریعہ مخصوص عناصر کو برقرار رکھتا ہے۔
    ///
    /// دوسرے لفظوں میں ، `e` کے تمام عناصر کو حذف کریں جیسے `f(&e)` `false` کو واپس کرتا ہے۔
    /// یہ طریقہ کار میں کام کرتا ہے ، ہر عنصر کو ایک بار اصل ترتیب میں ملاحظہ کرتا ہے ، اور برقرار عناصر کی ترتیب کو محفوظ رکھتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// چونکہ اصل ترتیب میں ایک بار عناصر کا دورہ کیا جاتا ہے ، لہذا خارجی حالت کا فیصلہ کرنے کے لئے استعمال کیا جاسکتا ہے کہ کون سے عناصر کو رکھنا ہے۔
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // اگر ڈراپ گارڈ کو پھانسی نہیں دی جاتی ہے تو ڈبل ڈراپ سے گریز کریں ، کیوں کہ ہم اس عمل کے دوران کچھ سوراخ کرسکتے ہیں۔
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-عمل شدہ لین-> |^-چیک کرنے کے لئے اگلے
        //                  | <-حذف شدہ سی این ٹی-> |
        //      | <-original_len-> |رکھی: جو عناصر واپسی کی پیش گوئی کرتے ہیں وہ درست ہیں۔
        //
        // ہول: عنصر سلاٹ منتقل یا گرا دیا گیا۔
        // چیک نہیں کیا گیا: چیک شدہ درست عنصر۔
        //
        // اس ڈراپ گارڈ کو اس وقت طلب کیا جائیگا جب پیش گوئی یا `drop` عنصر گھبرائے۔
        // یہ سوراخوں اور `set_len` کا احاطہ کرنے کے لئے بغیر جانچے ہوئے عناصر کو درست لمبائی میں منتقل کرتا ہے۔
        // ایسے معاملات میں جب پیشو گو اور `drop` کبھی گھبراتے نہیں ، اس کو بہتر بنایا جائے گا۔
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // محفوظ کریں: جانچ پڑتال نہ کرنے والی اشیاء کو درست کرنا ضروری ہے کیونکہ ہم انہیں کبھی ہاتھ نہیں لگاتے ہیں۔
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // محفوظ کریں: سوراخ بھرنے کے بعد ، تمام اشیاء مستقل میموری میں ہیں۔
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // محفوظ: چیک نہ کیا عنصر درست ہونا چاہئے۔
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // اگر `drop_in_place` گھبرائے تو ڈبل ڈراپ سے بچنے کے ل early جلد پیش قدمی کریں۔
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // محفوظ: گرنے کے بعد ہم کبھی بھی اس عنصر کو ہاتھ نہیں لگاتے ہیں۔
                unsafe { ptr::drop_in_place(cur) };
                // ہم پہلے ہی کاؤنٹر کو آگے بڑھا چکے ہیں۔
                continue;
            }
            if g.deleted_cnt > 0 {
                // حفاظت: `deleted_cnt`> 0 ، لہذا سوراخ کی سلاٹ موجودہ عنصر کے ساتھ اوورلپ نہیں ہونی چاہئے۔
                // ہم نقل کے لئے نقل استعمال کرتے ہیں ، اور پھر کبھی بھی اس عنصر کو ہاتھ نہیں لگائیں گے۔
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // تمام آئٹم پر کارروائی کی جاتی ہے۔اسے LLVM کے ذریعہ `set_len` میں بہتر بنایا جاسکتا ہے۔
        drop(g);
    }

    /// vector میں لگاتار سب سے پہلے عناصر کے علاوہ سب کو ہٹاتا ہے جو ایک ہی کلید کو حل کرتے ہیں۔
    ///
    ///
    /// اگر vector کو ترتیب دیا گیا ہے ، تو اس سے تمام نقولات ہٹ جائیں گے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// مساوی تعلقات سے متعلق مطمئن کرتے ہوئے vector میں لگاتار سب سے پہلے عناصر کے علاوہ سب کو ہٹاتا ہے۔
    ///
    /// `same_bucket` فنکشن vector سے دو عناصر کے حوالے بھیج دیا جاتا ہے اور اس کا تعین کرنا ضروری ہے کہ اگر عناصر برابر کا موازنہ کریں۔
    /// عناصر کو سلائس میں ان کے آرڈر سے مخالف ترتیب میں منتقل کیا جاتا ہے ، لہذا اگر `same_bucket(a, b)` `true` واپس کرتا ہے تو ، `a` کو ہٹا دیا جاتا ہے۔
    ///
    ///
    /// اگر vector کو ترتیب دیا گیا ہے ، تو اس سے تمام نقولات ہٹ جائیں گے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// مجموعہ کے پچھلے حصے میں عنصر شامل کرتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نئی صلاحیت `isize::MAX` بائٹس سے زیادہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // یہ panic یا اسقاط حمل کرے گا اگر ہم> isize::MAX بائٹ مختص کریں گے یا لمبائی میں اضافہ صفر سائز کی اقسام میں بہہ جائے گا۔
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector سے آخری عنصر کو ہٹاتا ہے اور اسے واپس کرتا ہے ، یا اگر یہ خالی ہے تو [`None`]۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` کے تمام عناصر کو `Self` میں منتقل کرتا ہے ، `other` کو خالی چھوڑ دیتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر vector میں عناصر کی تعداد ایک `usize` کو بہا دیتی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// دوسرے بفر سے عناصر کو `Self` میں شامل کریں۔
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// ڈریننگ ایریٹر بناتا ہے جو vector میں مخصوص حد کو ہٹا دیتا ہے اور ہٹائے گئے آئٹمز کو برآمد کرتا ہے۔
    ///
    /// جب ایریٹر ** ** چھوڑ دیا جاتا ہے تو ، رینج میں موجود تمام عناصر کو vector سے ہٹا دیا جاتا ہے ، یہاں تک کہ اگر ریٹرٹر مکمل طور پر کھایا نہ گیا ہو۔
    /// اگر تکرار کنندہ ** ** نہیں گرا ہوا ہے (مثال کے طور پر [`mem::forget`] کے ساتھ) ، یہ غیر متعین ہے کہ کتنے عناصر کو ہٹا دیا گیا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نقطہ اغاز نقطہ اختتامی نقطہ سے زیادہ ہے یا اگر اختتامی نقطہ vector کی لمبائی سے زیادہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // ایک مکمل رینج vector کو صاف کرتی ہے
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // میموری کی حفاظت
        //
        // جب Drain سب سے پہلے تشکیل دیا گیا ہے ، تو یہ ماخذ vector کی لمبائی کو کم کرتا ہے تاکہ یہ یقینی بنایا جاسکے کہ Drain کا ڈسٹرکٹر کبھی بھی چلانے کے لئے تیار نہیں ہوتا ہے۔
        //
        //
        // Drain ptr::read کو نکالنے کے لئے اقدار کو ختم کرے گا۔
        // جب ختم ہوجائے تو ، سوراخ کا احاطہ کرنے کے لئے ویکٹر کی باقی دم کاپی کی جاتی ہے ، اور vector لمبائی کو نئی لمبائی میں بحال کردیا جاتا ہے۔
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain لیک ہونے کی صورت میں محفوظ رہنے کیلئے self.vec لمبائی سیٹ کریں
            self.set_len(start);
            // پورے Drain ریٹر (جیسے &mut T) کے قرض لینے والے رویے کی نشاندہی کرنے کے لئے IterMut میں لون کا استعمال کریں۔
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector کو صاف کرتے ہوئے ، تمام اقدار کو ہٹا دیں۔
    ///
    /// نوٹ کریں کہ vector کی مختص گنجائش پر اس طریقہ کار کا کوئی اثر نہیں ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector میں عناصر کی تعداد لوٹاتا ہے ، جسے اس کا 'length' بھی کہا جاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// اگر vector میں کوئی عنصر نہ ہو تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// دیئے گئے اشاریہ میں مجموعہ کو دو حصوں میں تقسیم کرتا ہے۔
    ///
    /// `[at, len)` کی حد میں عناصر پر مشتمل ایک نئے مختص کردہ vector واپس کرتا ہے۔
    /// کال کے بعد ، اصل vector چھوڑ دیا جائے گا جس میں عناصر `[0, at)` کی پچھلی صلاحیت میں کوئی تبدیلی نہیں ہوگی۔
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `at > len` ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // نیا vector اصل بفر پر قبضہ کرسکتا ہے اور کاپی سے بچ سکتا ہے
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // غیر محفوظ طور پر `set_len` اور `other` پر آئٹمز کاپی کریں۔
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` کو جگہ جگہ تبدیل کریں تاکہ `len` `new_len` کے برابر ہو۔
    ///
    /// اگر `new_len` `len` سے زیادہ ہے تو ، `Vec` فرق کی طرف سے بڑھایا جاتا ہے ، بندش `f` کو کال کرنے کے نتیجے میں ہر اضافی سلاٹ بھرا ہوا ہے۔
    ///
    /// `f` سے واپسی کی قیمتوں کو `Vec` میں اسی ترتیب سے ختم کیا جائے گا جس ترتیب سے وہ تیار کیا گیا ہے۔
    ///
    /// اگر `new_len` `len` سے کم ہے تو ، `Vec` آسانی سے چھوٹا ہے۔
    ///
    /// یہ طریقہ ہر دھکا پر نئی اقدار پیدا کرنے کے لئے بندش کا استعمال کرتا ہے۔اگر آپ [`Clone`] کو دی گئی قدر کی بجائے ، [`Vec::resize`] استعمال کریں۔
    /// اگر آپ اقدار پیدا کرنے کے لئے [`Default`] trait استعمال کرنا چاہتے ہیں تو ، آپ [`Default::default`] کو دوسری دلیل کے طور پر پاس کرسکتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` کو استعمال اور لیک کرتا ہے ، مندرجات کا ایک متغیر حوالہ واپس کرتا ہے ، `&'a mut [T]`.
    /// نوٹ کریں کہ `T` قسم کو منتخب کردہ زندگی بھر `'a` سے بھی آگے نکل جانا چاہئے۔
    /// اگر اس قسم میں صرف مستحکم حوالہ جات ہیں ، یا کوئی بھی نہیں ، تو پھر یہ `'static` ہونے کا انتخاب کیا جاسکتا ہے۔
    ///
    /// یہ فنکشن [`leak`][Box::leak] X پر X0X فنکشن سے ملتا جلتا ہے سوائے اس کے کہ لیک ہونے والی میموری کو دوبارہ حاصل کرنے کا کوئی راستہ نہیں ہے۔
    ///
    ///
    /// یہ فنکشن اس اعداد و شمار کے لئے بنیادی طور پر کارآمد ہے جو پروگرام کی باقی زندگی تک زندہ رہتا ہے۔
    /// لوٹا ہوا حوالہ چھوڑنا میموری میموری کا سبب بنے گا۔
    ///
    /// # Examples
    ///
    /// آسان استعمال:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector کی باقی اسپیئر گنجائش کو `MaybeUninit<T>` کے ٹکڑے کے طور پر لوٹاتا ہے۔
    ///
    /// لوٹی ہوئی سلائس کو vector کو اعداد و شمار سے بھرنے کے لئے استعمال کیا جاسکتا ہے (جیسے
    /// [`set_len`] طریقہ کو استعمال کرتے ہوئے ڈیٹا کو ابتدا کے طور پر نشان زد کرنے سے پہلے) فائل سے پڑھ کر)۔
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 عناصر کے ل enough vector کافی بڑا مختص کریں۔
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // پہلے 3 عناصر کو پُر کریں۔
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // شروع کرنے کے بطور vector کے پہلے 3 عناصر کو نشان زد کریں۔
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // یہ طریقہ `split_at_spare_mut` کے لحاظ سے نافذ نہیں ہوتا ہے ، تاکہ بفر کی طرف اشارہ کرنے والوں کی باطل کو روکا جاسکے۔
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector مواد کو `T` کے ٹکڑے کے طور پر ، vector کی باقی اسپیری گنجائش کے ساتھ `MaybeUninit<T>` کے ٹکڑے کے طور پر واپس کرتا ہے۔
    ///
    /// ایکس اسپیشل صلاحیت کے ٹکڑے کو vector کو [`set_len`] کے طریقہ کار کو استعمال کرتے ہوئے ابتداء کے طور پر ڈیٹا کو نشان زد کرنے سے پہلے اعداد و شمار (جیسے فائل سے پڑھ کر) بھرنے کے لئے استعمال کیا جاسکتا ہے۔
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// نوٹ کریں کہ یہ ایک نچلی سطح کا API ہے ، جو اصلاح کے مقاصد کے ل care احتیاط کے ساتھ استعمال کیا جانا چاہئے۔
    /// اگر آپ کو `Vec` میں ڈیٹا شامل کرنے کی ضرورت ہے تو آپ اپنی درست ضروریات کے مطابق [`push`] ، [`extend`] ، [`extend_from_slice`] ، [`extend_from_within`] ، [`insert`] ، [`append`] ، [`resize`] یا [`resize_with`] استعمال کرسکتے ہیں۔
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // اضافی جگہ 10 عناصر کے ل big کافی حد تک محفوظ کریں۔
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // اگلے 4 عناصر کو پُر کریں۔
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // شروع کرنے کے بطور vector کے 4 عناصر کو نشان زد کریں۔
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - لین کو نظرانداز کیا گیا ہے اور لہذا کبھی نہیں بدلا
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// حفاظت: واپسی .2 (&mut usize) کو تبدیل کرنا `.set_len(_)` کو کال کرنے کی طرح ہی سمجھا جاتا ہے۔
    ///
    /// یہ طریقہ `extend_from_within` میں ایک بار میں تمام ویکٹر حصوں تک منفرد رسائی حاصل کرنے کے لئے استعمال ہوتا ہے۔
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` عناصر کے لئے موزوں ہونے کی ضمانت ہے
        // - `spare_ptr` بفر کے ماضی میں ایک عنصر کی نشاندہی کر رہا ہے ، لہذا یہ `initialized` کے ساتھ اوور لیپ نہیں ہوتا ہے
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` کو جگہ جگہ تبدیل کریں تاکہ `len` `new_len` کے برابر ہو۔
    ///
    /// اگر `new_len` `len` سے زیادہ ہے تو ، `Vec` `value` سے بھرا ہوا ہر اضافی سلاٹ کے ساتھ ، فرق کے ذریعہ بڑھایا جاتا ہے۔
    ///
    /// اگر `new_len` `len` سے کم ہے تو ، `Vec` آسانی سے چھوٹا ہے۔
    ///
    /// اس طریقہ کار میں [`Clone`] کو نافذ کرنے کے لئے `T` کی ضرورت ہوتی ہے ، تاکہ منظور شدہ قیمت کو کلون کرنے کے قابل ہو۔
    /// اگر آپ کو زیادہ لچک کی ضرورت ہے (یا [`Clone`] کی بجائے [`Vec::resize_with`] پر انحصار کرنا چاہتے ہیں) ، تو [`Vec::resize_with`] استعمال کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// کلونز اور `Vec` کے سلائس میں تمام عناصر کو جوڑتا ہے۔
    ///
    /// سلائس `other` پر پھیلتا ہے ، ہر عنصر کا کلون کرتا ہے ، اور پھر اسے اس `Vec` میں شامل کرتا ہے۔
    /// `other` vector ترتیب میں ہے۔
    ///
    /// نوٹ کریں کہ یہ فنکشن [`extend`] جیسا ہی ہے سوائے اس کے کہ اس کے بجائے سلائسز کے ساتھ کام کرنے میں مہارت حاصل ہو۔
    ///
    /// اگر اور جب زیڈ رسٹ0 زیڈ کو تخصیص ملتی ہے تو اس کام کا امکان ختم کردیا جائے گا (لیکن پھر بھی دستیاب ہے)۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` سے لے کر vector کے اختتام تک عناصر کاپی کریں۔
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` اس بات کی ضمانت دیتا ہے کہ دی گئی حد خود اشاریہ کے ل valid موزوں ہے
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// یہ کوڈ `extend_with_{element,default}` کو جنرل بناتا ہے۔
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// دیئے گئے جنریٹر کا استعمال کرکے ، `n` قدروں کے حساب سے vector میں اضافہ کریں۔
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // بگ کے ارد گرد کام کرنے کیلئے سیٹ لین آن ڈراپ کا استعمال کریں جہاں `ptr` کے ذریعہ X0X کے ذریعہ اسٹائل کا احساس نہیں ہوسکتا ہے کہ X0X ایکس عرف نہیں ہے۔
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // آخری عنصر کے علاوہ تمام عناصر لکھیں
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics کی صورت میں ہر قدم میں لمبائی میں اضافہ کریں
                local_len.increment_len(1);
            }

            if n > 0 {
                // ہم آخری عنصر کو بغیر کسی ضرورت کلوننگ کے براہ راست لکھ سکتے ہیں
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // اسکوپ گارڈ کے ذریعہ لین سیٹ کیا گیا
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait نفاذ کے مطابق vector میں لگاتار بار بار عناصر کو ہٹاتا ہے۔
    ///
    ///
    /// اگر vector کو ترتیب دیا گیا ہے ، تو اس سے تمام نقولات ہٹ جائیں گے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// داخلی طریقے اور افعال
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` درست انڈیکس ہونے کی ضرورت ہے
    /// - `self.capacity() - self.len()` `>= src.len()` ہونا ضروری ہے
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - عناصر کو شروع کرنے کے بعد ہی لین میں اضافہ ہوتا ہے
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - کالر کی گارنٹی ہے کہ src ایک درست اشاریہ ہے
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - عنصر ابھی `MaybeUninit::write` کے ساتھ شروع کیا گیا تھا ، لہذا لین میں اضافہ کرنا ٹھیک ہے
            // - لیک کو روکنے کے ل each ہر عنصر کے بعد لین میں اضافہ کیا جاتا ہے (ایشو #82533 دیکھیں)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - کالر کی ضمانت ہے کہ `src` ایک درست اشاریہ ہے
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - دونوں پوائنٹرز منفرد سلائس ریفرنسز (`&mut [_] from) سے تخلیق کیے گئے ہیں لہذا وہ درست ہیں اور اوورلیپ نہیں ہوتے ہیں۔
            //
            // - عنصر یہ ہیں: کاپی کریں لہذا اصل اقدار کے ساتھ کچھ بھی کیے بغیر ، ان کی کاپی کرنا ٹھیک ہے
            // - `count` `source` کی لین کے برابر ہے ، لہذا `count` پڑھنے کے لئے ذریعہ درست ہے
            // - `.reserve(count)` اس کی ضمانت دیتا ہے کہ `spare.len() >= count` لہذا اسپیئر `count` لکھنے کے لئے درست ہے
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - عناصر کو ابھی `copy_nonoverlapping` کے ذریعہ شروع کیا گیا تھا
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec کے لئے کامن trait لاگو
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) کے ساتھ موروثی `[T]::to_vec` طریقہ ، جو اس طریقہ کی تعریف کے لئے ضروری ہے ، دستیاب نہیں ہے۔
    // اس کے بجائے `slice::to_vec` فنکشن کا استعمال کریں جو صرف cfg(test) NB کے ساتھ دستیاب ہے مزید معلومات کے لئے slice.rs میں slice::hack ماڈیول دیکھیں
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ایسی کوئی بھی چیز چھوڑیں جس کو ادلھائی نہیں جائے گی
        self.truncate(other.len());

        // self.len <= other.len اوپر چھوٹی چھوٹی وجہ سے ، لہذا یہاں کے سلائسس ہمیشہ ہی اندرونی حدود میں رہتے ہیں۔
        //
        let (init, tail) = other.split_at(self.len());

        // موجود اقدار allocations/resources کو دوبارہ استعمال کریں۔
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// ایک استعمال کرنے والا ریڈیٹر بناتا ہے ، یعنی ایک ایسا جو ہر قیمت کو vector (ابتدا سے آخر تک) منتقل کرتا ہے۔
    /// vector اسے کال کرنے کے بعد استعمال نہیں کیا جاسکتا۔
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s کی قسم اسٹرنگ ہے ، &String نہیں
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // پتی کا طریقہ جس پر مختلف SpecFrom/SpecExtend عمل درآمد کرتے ہیں جب ان کے پاس اطلاق کے لئے مزید اصلاحات نہیں ہوتی ہیں
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // یہ معاملہ عام تکرار کرنے والے کے لئے ہے۔
        //
        // یہ فنکشن اخلاقی مساوی ہونا چاہئے:
        //
        //      ریڈیٹر میں آئٹم کے لئے {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB اتنا بہہ نہیں سکتا کیونکہ ہمیں پتے کی جگہ مختص کرنا پڑتی
                self.set_len(len + 1);
            }
        }
    }

    /// ایک جداگانہ دہرا بنانے والا بناتا ہے جو vector میں مخصوص حد کو دیئے گئے `replace_with` آئٹرٹر کی جگہ لے لیتا ہے اور خارج کردہ اشیاء کو حاصل کرتا ہے۔
    ///
    /// `replace_with` `range` کی لمبائی کی ضرورت نہیں ہے۔
    ///
    /// `range` حذف ہوجاتا ہے یہاں تک کہ اگر آئٹرٹر آخر تک استعمال نہیں کیا جاتا ہے۔
    ///
    /// یہ غیر متعین ہے کہ اگر `Splice` ویلیو لیک ہوجائے تو vector سے کتنے عناصر کو ہٹا دیا گیا ہے۔
    ///
    /// ان پٹ آئیٹرٹر `replace_with` صرف اس وقت استعمال ہوتا ہے جب `Splice` قدر گرا دی جاتی ہے۔
    ///
    /// یہ زیادہ سے زیادہ ہے اگر:
    ///
    /// * دم (`range` کے بعد vector میں موجود عناصر) خالی ہے ،
    /// * یا `replace_with` `حد` کی لمبائی سے کم یا مساوی عنصر برآمد کرتا ہے
    /// * یا اس کے `size_hint()` کی نچلی حد درست ہے۔
    ///
    /// ورنہ ، ایک عارضی vector مختص کی جاتی ہے اور دم دو بار منتقل کردی جاتی ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر نقطہ اغاز نقطہ اختتامی نقطہ سے زیادہ ہے یا اگر اختتامی نقطہ vector کی لمبائی سے زیادہ ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// ایک ایٹریٹر بناتا ہے جو عنصر کو ہٹانا چاہئے اس بات کا تعین کرنے کے لئے بندش کا استعمال کرتا ہے۔
    ///
    /// اگر بندش درست ہو تو ، پھر عنصر کو ہٹا کر برآمد کیا جاتا ہے۔
    /// اگر بندش غلط ہوجاتی ہے تو ، عنصر vector میں رہے گا اور آئٹرٹر کے ذریعہ برآمد نہیں ہوگا۔
    ///
    /// اس طریقے کا استعمال درج ذیل کوڈ کے مترادف ہے۔
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // آپ کا کوڈ یہاں
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// لیکن `drain_filter` استعمال کرنا آسان ہے۔
    /// `drain_filter` یہ بھی زیادہ موثر ہے ، کیونکہ یہ بڑی تعداد میں صف کے عناصر کی پشت پناہی کرسکتا ہے۔
    ///
    /// نوٹ کریں کہ `drain_filter` آپ کو فلٹر بند ہونے میں ہر عنصر کو تبدیل کرنے دیتا ہے ، قطع نظر اس سے کہ آپ اسے برقرار رکھنے یا اسے ہٹانے کا انتخاب کرتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// شام کو اور مشکلات میں کسی صف کو تقسیم کرنا ، اصل مختص کو دوبارہ استعمال کرنا:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // لیک ہونے سے ہمارے خلاف محافظ (لیک امپلیٹیشن)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// عمل میں توسیع کریں جو عناصر کو حوالہ جات سے ہٹ کر Vec پر دھکیلنے سے پہلے ان کی کاپی کردیں۔
///
/// یہ عمل سلائس ریڈیٹرس کے لئے خصوصی ہے ، جہاں یہ ایک ہی وقت میں سلائس کو جوڑنے کے لئے [`copy_from_slice`] استعمال کرتا ہے۔
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors کا موازنہ نافذ کرتا ہے ، [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors کی آرڈرنگ نافذ کرتا ہے ، [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] کے لئے ڈراپ کا استعمال کریں vector کے عناصر کو ضعیف ضروری قسم کے طور پر حوالہ کرنے کے لئے کچے ٹکڑے کا استعمال کریں۔
            //
            // کچھ معاملات میں صداقت کے سوالات سے بچ سکتے ہیں
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // راوییک منتقلی کو سنبھالتا ہے
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// ایک خالی `Vec<T>` بناتا ہے۔
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: ٹیسٹ لیبسٹڈی میں کھینچتا ہے ، جو یہاں غلطیاں پیدا کرتا ہے
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: ٹیسٹ لیبسٹڈی میں کھینچتا ہے ، جو یہاں غلطیاں پیدا کرتا ہے
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` کے پورے مندرجات کو بطور صف تیار ہوجاتا ہے ، اگر اس کا سائز مطلوبہ سرنی سے بالکل مماثل ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// اگر لمبائی مماثل نہیں ہے تو ، ان پٹ `Err` میں واپس آئے گا:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// اگر آپ صرف `Vec<T>` کا ایک پریفکس حاصل کرنے میں ٹھیک ہیں تو ، آپ پہلے [`.truncate(N)`](Vec::truncate) پر کال کرسکتے ہیں۔
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // محفوظ: `.set_len(0)` ہمیشہ مستحکم ہوتا ہے۔
        unsafe { vec.set_len(0) };

        // حفاظت: A `Vec` کا پوائنٹر ہمیشہ مناسب طریقے سے منسلک ہوتا ہے ، اور
        // صف کی جو صف بندی کی ضرورت ہوتی ہے وہ اشیاء کی طرح ہی ہوتی ہے۔
        // ہم نے پہلے چیک کیا تھا کہ ہمارے پاس کافی سامان موجود ہے۔
        // آئٹمز ڈبل نہیں گریں گے کیونکہ `set_len` `Vec` کو بھی چھوڑنے کو نہیں کہتا ہے۔
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}