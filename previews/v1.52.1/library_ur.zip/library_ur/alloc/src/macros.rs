/// دلائل پر مشتمل ایک [`Vec`] بناتا ہے۔
///
/// `vec!` `Vec`s کو سرے کے تاثرات کی طرح ایک ہی نحو کے ساتھ بیان کرنے کی اجازت دیتا ہے۔
/// اس میکرو کی دو شکلیں ہیں۔
///
/// - عناصر کی دی گئی فہرست پر مشتمل ایک [`Vec`] بنائیں:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - ایک دیئے گئے عنصر اور سائز سے ایک [`Vec`] بنائیں:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// نوٹ کریں کہ صف کے تاثرات کے برعکس یہ نحو ان تمام عناصر کی حمایت کرتا ہے جو [`Clone`] پر عمل درآمد کرتے ہیں اور عناصر کی تعداد مستقل نہیں رہتی ہے۔
///
/// یہ ایک اظہار کی نقل تیار کرنے کے لئے `clone` استعمال کرے گا ، لہذا اس کو غیر معیاری `Clone` نفاذ والی اقسام کے ساتھ استعمال کرنے میں محتاط رہنا چاہئے۔
/// مثال کے طور پر ، `vec![Rc::new(1)؛5] Z ایک ہی باکسڈ انٹیجر ویلیو کے پانچ حوالوں میں سے ایک vector تخلیق کرے گا ، پانچ حوالہ نہیں جو آزادانہ طور پر باکسڈ انٹیجرز کی طرف اشارہ کرے گا۔
///
///
/// نیز ، یہ بھی نوٹ کریں کہ `vec![expr; 0]` کی اجازت ہے ، اور خالی vector تیار کرتا ہے۔
/// تاہم ، یہ اب بھی `expr` کی جانچ کرے گا ، اور اس کے نتیجے میں آنے والی قیمت کو فوری طور پر چھوڑ دے گا ، لہذا ضمنی اثرات کو ذہن میں رکھیں۔
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) کے ساتھ موروثی `[T]::into_vec` طریقہ کار ، جو اس میکرو تعریف کے لئے ضروری ہے ، دستیاب نہیں ہے۔
// اس کے بجائے `slice::into_vec` فنکشن کا استعمال کریں جو صرف cfg(test) NB کے ساتھ دستیاب ہے مزید معلومات کے لئے slice.rs میں slice::hack ماڈیول دیکھیں
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// رن ٹائم کے تاثرات کی بازی کا استعمال کرکے ایک `String` بناتا ہے۔
///
/// `format!` کو موصول ہونے والی پہلی دلیل ایک فارمیٹ کی تار ہے۔یہ تار کا لفظی ہونا چاہئے۔فارمیٹنگ سٹرنگ کی طاقت موجود چیزوں میں ہے۔
///
/// `format!` کو بھیجے گئے اضافی پیرامیٹرز ، ترتیب میں ترتیب دینے والے اسٹرنگ کے اندر `{}}` s کی جگہ لے لیتے ہیں جب تک کہ نام یا مقاماتی پیرامیٹرز استعمال نہ ہوں۔مزید معلومات کے لئے [`std::fmt`] دیکھیں۔
///
///
/// `format!` کے لئے ایک عام استعمال کنکریٹٹیشن اور ڈوروں کا رگڑنا ہے۔
/// اسی کنونشن کو [`print!`] اور [`write!`] میکروز کے ساتھ استعمال کیا جاتا ہے ، تار کی مطلوبہ منزل پر منحصر ہے۔
///
/// کسی ایک قیمت کو تار میں تبدیل کرنے کے لئے ، [`to_string`] طریقہ استعمال کریں۔یہ [`Display`] فارمیٹنگ trait استعمال کرے گا۔
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics اگر trait کو فارمیٹنگ کرنے میں غلطی ہوتی ہے۔
/// یہ ایک غلط نفاذ کی نشاندہی کرتا ہے چونکہ `fmt::Write for String` کبھی بھی غلطی واپس نہیں کرتا ہے۔
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// پیٹرن پوزیشن میں تشخیص کو بہتر بنانے کے ل A اے ایس ٹی نوڈ کو ایک اظہار پر مجبور کریں۔
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}