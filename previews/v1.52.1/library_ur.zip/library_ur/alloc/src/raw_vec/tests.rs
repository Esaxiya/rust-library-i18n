use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // تیسری پارٹی کے مختص کنندگان اور `RawVec` کے مابین انضمام کا امتحان لکھنا تھوڑا مشکل ہے کیونکہ `RawVec` API ناقص الاٹولوتی طریقوں کو بے نقاب نہیں کرتا ہے ، لہذا ہم یہ نہیں جانچ سکتے ہیں کہ جب مختص کرنے والا ختم ہوجائے تو کیا ہوتا ہے (panic کا پتہ لگانے سے باہر)۔
    //
    //
    // اس کے بجائے ، یہ صرف چیک کرتا ہے کہ `RawVec` طریقے کم از کم الاٹایٹر API کے ذریعے جاتے ہیں جب اس میں ذخیرہ ہوتا ہے۔
    //
    //
    //
    //
    //

    // ایک گونگا مختص کرنے والا جو مختص کرنے کی کوششوں میں ناکام ہونے سے قبل ایک مقررہ مقدار میں ایندھن استعمال کرتا ہے۔
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (اس طرح 50 + 150=200 یونٹ ایندھن کا استعمال کرتے ہوئے ، ایک بدعنوانی کا سبب بنتا ہے)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // پہلے ، `reserve` مختص کرتا ہے جیسے `reserve_exact`۔
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7 سے دگنا ہے ، لہذا `reserve` کو `reserve_exact` کی طرح کام کرنا چاہئے۔
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 12 کے نصف سے کم ہے ، لہذا `reserve` کو تیزی سے بڑھنا چاہئے۔
        // اس ٹیسٹ کو لکھتے وقت فیکٹر عنصر 2 ہے ، لہذا نئی صلاحیت 24 ہے ، تاہم ، 1.5 کا بڑھنے والا عنصر بھی ٹھیک ہے۔
        //
        // لہذا زور میں `>= 18`.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}