// rsbegin.o اور rsend.o نام نہاد "compiler runtime startup objects" ہیں۔
// ان میں کمپائلر رن ٹائم کو صحیح طریقے سے شروع کرنے کے لئے درکار کوڈ ہوتا ہے۔
//
// جب کوئی قابل عمل یا ڈیلیب امیج منسلک ہوتا ہے تو ، ان دونوں آبجیکٹ فائلوں کے مابین تمام صارف کوڈ اور لائبریریاں "sandwiched" ہوتی ہیں ، لہذا rsbegin.o کا کوڈ یا ڈیٹا شبیہہ کے متعلقہ حصوں میں پہلا ہوجاتا ہے ، جبکہ rsend.o کا کوڈ اور ڈیٹا آخری بن جاتا ہے۔
// اس اثر کو علامتوں کے آغاز یا کسی حصے کے آخر میں استعمال کرنے کے ساتھ ساتھ کوئی ضروری ہیڈر یا فوٹر داخل کرنے کے لئے استعمال کیا جاسکتا ہے۔
//
// نوٹ کریں کہ اصل ماڈیول انٹری پوائنٹ سی رن ٹائم اسٹارٹ اپ آبجیکٹ (جسے عام طور پر `crtX.o` کہا جاتا ہے) میں واقع ہے ، جو اس کے بعد دوسرے رن ٹائم اجزاء کی ابتداء کال بیک (جس میں کسی اور خاص امیج سیکشن کے ذریعے رجسٹرڈ ہے) کی درخواست کرتا ہے۔
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // اسٹیک فریم انوائنڈ انفارمیشن سیکشن کے آغاز کے نشانات
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // انویندر کے اندرونی کتاب کیپنگ کے لئے سکریچ کی جگہ۔
    // اس کی وضاحت as GCC/unwind-dw2-fde.h میں `struct object` کے طور پر کی گئی ہے۔
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // ایکس ایکس ایکس ایکس کے معمولات کو کھولیں۔
    // libpanic_unwind کے دستاویزات دیکھیں۔
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ماڈیول اسٹارٹ اپ کے بارے میں معلومات کو کھولیں
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // شٹ ڈاؤن پر اندراج نہ کریں
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // منگ ڈبلیو سے متعلق init/uninit معمول کی رجسٹریشن
    pub mod mingw_init {
        // منگ ڈبلیو کے اسٹارٹ اپ آبجیکٹ (crt0.o/dllcrt0.o) .ctors اور .dtors حصوں میں اسٹارٹ اپ اور ایگزٹ میں عالمی تعمیر کاروں کی مدد کریں گے۔
        // DLLs کے معاملے میں ، جب DLL لوڈ اور ان لوڈ کیا جاتا ہے تو یہ کیا جاتا ہے۔
        //
        // لنکر حصوں کو ترتیب دے گا ، جو اس بات کو یقینی بناتا ہے کہ ہماری کال بیکس فہرست کے آخر میں واقع ہیں۔
        // چونکہ کنسٹرکٹرز ریورس ترتیب میں چلتے ہیں ، اس سے یہ یقینی بنتا ہے کہ ہماری کال بیکس پہلے اور آخری مرتبہ عمل میں لائی گئی ہیں۔
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C شروع کال بیکس
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C ختم کال بیکس
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}