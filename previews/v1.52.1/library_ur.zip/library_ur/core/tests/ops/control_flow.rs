use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // یہ سطح کا مستحکم علاقہ نہیں ہے ، لیکن ان کے درمیان `?` کو سستا رکھنے میں مدد کرتا ہے ، یہاں تک کہ اگر LLVM ابھی ہمیشہ اس کا فائدہ نہیں اٹھا سکتا ہے۔
    //
    // (افسوس کی بات ہے کہ نتیجہ اور آپشن متضاد ہیں ، لہذا کنٹرول فلو دونوں سے مماثل نہیں ہے۔)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}