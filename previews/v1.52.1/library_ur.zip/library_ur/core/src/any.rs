//! یہ ماڈیول `Any` trait نافذ کرتا ہے ، جو رن ٹائم عکاسی کے ذریعہ کسی بھی `'static` قسم کی متحرک ٹائپنگ کے قابل بناتا ہے۔
//!
//! `Any` خود ہی ایک `TypeId` حاصل کرنے کے لئے استعمال کیا جاسکتا ہے ، اور جب trait آبجیکٹ کے طور پر استعمال ہوتا ہے تو اس میں مزید خصوصیات ہوتی ہیں۔
//! جیسا کہ `&dyn Any` (ایک ادھار trait آبجیکٹ) ، اس میں `is` اور `downcast_ref` طریقے ہیں ، یہ جانچنے کے لئے کہ اگر موجود قدر ایک دی گئی نوعیت کی ہے یا نہیں ، اور داخلی قیمت کا ایک حوالہ حاصل کرنے کے ل.۔
//! `&mut dyn Any` کے طور پر ، اندرونی قدر کے لئے تغیر پذیر حوالہ حاصل کرنے کے لئے ، `downcast_mut` طریقہ بھی موجود ہے۔
//! `Box<dyn Any>` `downcast` طریقہ شامل کرتا ہے ، جو `Box<T>` میں تبدیل کرنے کی کوشش کرتا ہے۔
//! مکمل تفصیلات کے لئے [`Box`] دستاویزات دیکھیں۔
//!
//! نوٹ کریں کہ `&dyn Any` جانچ کرنے تک محدود ہے کہ آیا قیمت کسی مخصوص کنکریٹ کی نوعیت کی ہے ، اور یہ جانچ کرنے کے لئے استعمال نہیں کی جاسکتی ہے کہ آیا کوئی قسم trait لاگو کرتی ہے یا نہیں۔
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # سمارٹ پوائنٹرز اور `dyn Any`
//!
//! `Any` کو trait آبجیکٹ کے طور پر ، خاص طور پر `Box<dyn Any>` یا `Arc<dyn Any>` کی طرح کی اقسام کے ساتھ استعمال کرتے وقت ، رویے کا ایک ٹکڑا یہ ہے کہ صرف قدر پر `.type_id()` کو فون کرنے سے *کنٹینر* کے `TypeId` پیدا ہوتا ہے ، نہ کہ بنیادی trait آبجیکٹ۔
//!
//! اس کی بجائے اسمارٹ پوائنٹر کو `&dyn Any` میں تبدیل کرکے اس سے بچا جاسکتا ہے ، جو شے کے `TypeId` کو لوٹائے گا۔
//! مثال کے طور پر:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // آپ کو یہ چاہ to زیادہ امکان ہے:
//! let actual_id = (&*boxed).type_id();
//! // ... اس سے زیادہ:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ایسی صورتحال پر غور کریں جہاں ہم کسی فنکشن میں دی گئی قدر کو لاگ آؤٹ کرنا چاہتے ہیں۔
//! ہم اس قدر کو جانتے ہیں جس پر ہم ڈیبگ کے اطلاق پر کام کر رہے ہیں ، لیکن ہمیں اس کی ٹھوس قسم نہیں معلوم ہے۔ہم کچھ خاص اقسام کے ساتھ خصوصی سلوک کرنا چاہتے ہیں: اس معاملے میں اسٹرنگ ویلیوز کی قیمت سے قبل ان کی لمبائی چھپانا۔
//! ہم مرتب وقت پر اپنی قدر کی ٹھوس قسم نہیں جانتے ہیں ، لہذا ہمیں اس کے بجائے رن ٹائم ریفلیکشن استعمال کرنے کی ضرورت ہے۔
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // کسی بھی قسم کے لئے لاگر فنکشن جو ڈیبگ کو نافذ کرتا ہے۔
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // ہماری قدر کو `String` میں تبدیل کرنے کی کوشش کریں۔
//!     // اگر کامیاب ہے تو ، ہم اسٹرنگ کی لمبائی کے ساتھ ساتھ اس کی قیمت بھی آؤٹ پٹ کرنا چاہتے ہیں۔
//!     // اگر نہیں تو ، یہ ایک مختلف قسم ہے: صرف اسے غیر سجاوٹ پرنٹ کریں۔
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // یہ فنکشن کام کرنے سے پہلے اپنے پیرامیٹر کو لاگ آؤٹ کرنا چاہتا ہے۔
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... کچھ اور کام کرو
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// کوئی trait
///////////////////////////////////////////////////////////////////////////////

/// متحرک ٹائپنگ کی تقلید کرنے کے لئے ایک trait۔
///
/// زیادہ تر اقسام `Any` پر عمل درآمد کرتی ہیں۔تاہم ، کسی بھی قسم کی جس میں غیر عدم حوالہ موجود ہو۔
/// مزید تفصیلات کے لئے [module-level documentation][mod] دیکھیں۔
///
/// [mod]: crate::any
// یہ trait غیر محفوظ نہیں ہے ، حالانکہ ہم غیر محفوظ کوڈ (جیسے ، `downcast`) میں اس کی واحد امپلیس کی `type_id` فنکشن کی خصوصیات پر انحصار کرتے ہیں۔عام طور پر ، یہ ایک مسئلہ ہو گا ، لیکن چونکہ `Any` کی واحد امپلیٹ ایک کمبل عمل ہے ، لہذا ، کوئی دوسرا کوڈ `Any` پر عمل نہیں کرسکتا ہے۔
//
// ہم یہ trait غیر محفوظ طریقے سے بناسکتے ہیں-اس سے ٹوٹ پھوٹ کا سبب نہیں ہوگا ، کیوں کہ ہم تمام نفاذ پر قابو رکھتے ہیں-لیکن ہم اس کا انتخاب نہیں کرتے ہیں جو واقعی ضروری نہیں ہے اور صارفین کو غیر محفوظ traits اور غیر محفوظ طریقوں کی تفریق کے بارے میں الجھا کر سکتے ہیں (یعنی ، `type_id` اب بھی کال کرنا محفوظ رہے گا ، لیکن ہم ممکنہ طور پر اس طرح کی دستاویزات کی نشاندہی کرنا چاہیں گے)۔
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` کا `TypeId` حاصل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// کسی بھی trait آبجیکٹ کے لئے توسیع کے طریقے۔
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// اس بات کو یقینی بنائیں کہ مثال کے طور پر ، کسی تھریڈ میں شامل ہونا پرنٹ کیا جاسکتا ہے اور اس لئے اسے `unwrap` کے ساتھ استعمال کیا جاسکتا ہے۔
// ممکن ہے کہ اب اگر بھیجنے کے کام کاج کے ساتھ کام کریں تو ضرورت نہیں ہے۔
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// اگر باکسڈ قسم ایکس00 ایکس کی طرح ہے تو ، ایکس01 ایکس لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // اس قسم کی `TypeId` حاصل کریں جس کی مدد سے اس فعل کو تیز کیا جاتا ہے۔
        let t = TypeId::of::<T>();

        // `TypeId` قسم کی trait آبجیکٹ (`self`) حاصل کریں۔
        let concrete = self.type_id();

        // برابری پر دونوں `ٹائپ آئی ڈی کا موازنہ کریں۔
        t == concrete
    }

    /// باکسڈ ویلیو کا کچھ حوالہ واپس کرتا ہے اگر وہ `T` کی قسم کا ہو ، یا اگر ایسا نہیں ہو تو `None`۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // حفاظت: ابھی چیک کیا کہ آیا ہم صحیح قسم کی طرف اشارہ کررہے ہیں ، اور ہم انحصار کرسکتے ہیں
            // جو میموری کی حفاظت کے ل check چیک کرتے ہیں کیونکہ ہم نے ہر قسم کے لئے کوئی بھی نافذ کیا ہے۔کوئی اور درخواستیں موجود نہیں ہوسکتی ہیں کیونکہ وہ ہمارے امپیل سے متصادم ہوں گی۔
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// باکسڈ ویلیو کے بارے میں کچھ تبدیل شدہ حوالہ واپس کرتا ہے اگر وہ `T` قسم کا ہے ، یا اگر ایسا نہیں ہے تو `None`۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // حفاظت: ابھی چیک کیا کہ آیا ہم صحیح قسم کی طرف اشارہ کررہے ہیں ، اور ہم انحصار کرسکتے ہیں
            // جو میموری کی حفاظت کے ل check چیک کرتے ہیں کیونکہ ہم نے ہر قسم کے لئے کوئی بھی نافذ کیا ہے۔کوئی اور درخواستیں موجود نہیں ہوسکتی ہیں کیونکہ وہ ہمارے امپیل سے متصادم ہوں گی۔
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// قسم `Any` پر بیان کردہ طریقہ کی طرف۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// قسم `Any` پر بیان کردہ طریقہ کی طرف۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// قسم `Any` پر بیان کردہ طریقہ کی طرف۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// قسم `Any` پر بیان کردہ طریقہ کی طرف۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// قسم `Any` پر بیان کردہ طریقہ کی طرف۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// قسم `Any` پر بیان کردہ طریقہ کی طرف۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ٹائپ آئی ڈی اور اس کے طریقے
///////////////////////////////////////////////////////////////////////////////

/// ایک `TypeId` ایک قسم کے لئے عالمی سطح پر منفرد شناخت کنندہ کی نمائندگی کرتا ہے۔
///
/// ہر `TypeId` ایک مبہم آبجیکٹ ہے جو اپنے اندر موجود چیزوں کے معائنے کی اجازت نہیں دیتی ہے لیکن کلوننگ ، موازنہ ، طباعت اور نمائش جیسے بنیادی کاموں کی اجازت نہیں دیتی ہے۔
///
///
/// ایک `TypeId` فی الحال صرف ان اقسام کے لئے دستیاب ہے جو `'static` کی حیثیت رکھتے ہیں ، لیکن اس حد کو زی0 فیوچر0 زیڈ میں ختم کیا جاسکتا ہے۔
///
/// جبکہ `TypeId` `Hash` ، `PartialOrd` ، اور `Ord` کو لاگو کرتا ہے ، یہ بات قابل توجہ ہے کہ ہیڈز اور آرڈر Rust ریلیز کے درمیان مختلف ہوں گے۔
/// اپنے کوڈ کے اندر ان پر انحصار کرنے سے بچو!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// اس قسم کے `TypeId` کو واپس کرتا ہے جس کے ذریعہ اس عام فعل کو فوری بنایا گیا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// اسٹرنگ سلائس کے بطور اس قسم کا نام لوٹاتا ہے۔
///
/// # Note
///
/// یہ تشخیصی استعمال کے لئے ہے۔
/// موصولہ تار کے عین مطابق مندرجات اور فارمیٹ کی وضاحت نہیں کی جاسکتی ہے ، اس کے علاوہ یہ کہ اس قسم کی بہترین کوشش کی وضاحت کی جائے۔
/// مثال کے طور پر ، `type_name::<Option<String>>()` واپس آنے والی تار میں `"Option<String>"` اور `"std::option::Option<std::string::String>"` شامل ہیں۔
///
///
/// لوٹی ہوئی تار کو کسی قسم کا انفراد شناخت کرنے والا نہیں سمجھا جانا چاہئے کیونکہ متعدد اقسام ایک ہی قسم کے نام پر نقشہ کرسکتی ہیں۔
/// اسی طرح ، اس بات کی کوئی گارنٹی نہیں ہے کہ واپس آنے والی تار میں کسی بھی قسم کے تمام حصے دکھائے جائیں گے: مثال کے طور پر ، تاحیات نمایاں کرنے والا فی الحال شامل نہیں ہے۔
/// اس کے علاوہ ، مرتب کے ورژن کے درمیان آؤٹ پٹ بھی تبدیل ہوسکتا ہے۔
///
/// موجودہ نفاذ میں وہی بنیادی ڈھانچے کا استعمال کیا گیا ہے جس کی تالیف تشخیص اور ڈیبگنفو ہیں ، لیکن اس کی ضمانت نہیں ہے۔
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// اسٹرائنگ سلائس کے بطور پوائنٹس ٹو ویلیو کی قسم کا نام لوٹاتا ہے۔
/// یہ `type_name::<T>()` جیسا ہی ہے ، لیکن ایسی جگہ استعمال کی جاسکتی ہے جہاں متغیر کی قسم آسانی سے دستیاب نہ ہو۔
///
/// # Note
///
/// یہ تشخیصی استعمال کے لئے ہے۔اسٹرنگ کے صحیح مشمولات اور فارمیٹ کی وضاحت نہیں کی جاسکتی ہے ، اس کے علاوہ یہ کہ اس قسم کی بہترین کوشش کے ساتھ بیان کیا جائے۔
/// مثال کے طور پر ، `type_name_of_val::<Option<String>>(None)` `"Option<String>"` یا `"std::option::Option<std::string::String>"` واپس کرسکتا ہے ، لیکن `"foobar"` نہیں۔
///
/// اس کے علاوہ ، مرتب کے ورژن کے درمیان آؤٹ پٹ بھی تبدیل ہوسکتا ہے۔
///
/// یہ فنکشن trait اشیاء کو حل نہیں کرتا ہے ، مطلب یہ ہے کہ `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` واپس کرسکتا ہے ، لیکن `"u32"` نہیں۔
///
/// قسم کے نام کو کسی قسم کا منفرد شناخت کنندہ نہیں سمجھا جانا چاہئے۔
/// ایک سے زیادہ اقسام میں ایک ہی قسم کا نام بانٹ سکتا ہے۔
///
/// موجودہ نفاذ میں وہی بنیادی ڈھانچے کا استعمال کیا گیا ہے جس کی تالیف تشخیص اور ڈیبگنفو ہیں ، لیکن اس کی ضمانت نہیں ہے۔
///
/// # Examples
///
/// پہلے سے طے شدہ انٹیجر اور فلوٹ کی اقسام پرنٹ کرتا ہے۔
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}