//! ASCII `[u8]` پر کاروائیاں۔

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// چیک کرتا ہے کہ آیا اس سلائس کے تمام بائٹس ASCII کی حد میں ہیں۔
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// چیک کرتا ہے کہ دو ٹکڑے ٹکڑے ایک ASCII کیس غیر حساس میچ ہیں۔
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` کی طرح ، لیکن عارضی طور پر مختص اور کاپی کیے بغیر۔
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// اس سلائس کو اس کے ASCII اپر کیس میں برابر جگہ میں تبدیل کرتا ہے۔
    ///
    /// 'a' سے 'z' تک ASCII حروف 'A' سے 'Z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// موجودہ میں ترمیم کیے بغیر نئی اپرکیسیز ویلیو واپس کرنے کے لئے ، [`to_ascii_uppercase`] استعمال کریں۔
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// اس سلائس کو اس کے ASCII لوئر کیس میں برابر جگہ میں تبدیل کرتا ہے۔
    ///
    /// 'A' سے 'Z' تک ASCII حروف 'a' سے 'z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// موجودہ میں ترمیم کیے بغیر نئی نچلی قیمت کو واپس کرنے کے لئے ، [`to_ascii_lowercase`] استعمال کریں۔
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// اگر `v` کے لفظ میں کوئی بائٹ نانوسی (>=128) ہے تو `true` کی واپسی کرتا ہے۔
/// `../str/mod.rs` سے اسنیفڈ ، جو utf8 توثیق کے لئے کچھ ایسا ہی کرتا ہے۔
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// بہتر ASCII ٹیسٹ جو بائٹ ایک ٹائم آپریشن (جب ممکن ہو) بائٹ ایک ٹائم آپریشنز کی بجائے استعمال میں استعمال کریں گے۔
///
/// ہم یہاں جو الگورتھم استعمال کرتے ہیں وہ بہت آسان ہے۔اگر `s` بہت کم ہے ، تو ہم صرف ہر بائٹ کو چیک کرتے ہیں اور اس کے ساتھ ہی کام انجام دیتے ہیں۔ورنہ:
///
/// - پہلا لفظ غیر دستخط شدہ بوجھ کے ساتھ پڑھیں۔
/// - پوائنٹر کی سیدھ میں کریں ، منسلک بوجھ کے آخر تک الفاظ پڑھیں۔
/// - `s` سے آخری ایکس00 ایکس غیر دستخط شدہ بوجھ کے ساتھ پڑھیں۔
///
/// اگر ان میں سے کوئی بھی بوجھ ایسی چیز پیدا کرتا ہے جس کے لئے `contains_nonascii` (above) سچ ثابت ہوتا ہے ، تو ہم جانتے ہیں کہ جواب غلط ہے۔
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // اگر ہم وقت کے وقت لفظی عمل سے کچھ حاصل نہیں کرتے ہیں تو ، اسکیلر لوپ پر واپس جائیں۔
    //
    // ہم یہ فن تعمیرات کے لئے بھی کرتے ہیں جہاں `usize` `usize` کیلئے مناسب صف بندی نہیں ہے ، کیونکہ یہ ایک عجیب edge معاملہ ہے۔
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // ہم ہمیشہ پہلا لفظ غیر دستخط شدہ پڑھتے ہیں ، جس کا مطلب ہے `align_offset` ہے
    // 0 ، ہم ایک ہی قدر کو منسلک پڑھنے کے ل read دوبارہ پڑھیں گے۔
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // حفاظت: ہم اوپر `len < USIZE_SIZE` کی توثیق کرتے ہیں۔
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // ہم نے اسے اوپر کسی حد تک واضح طور پر چیک کیا۔
    // نوٹ کریں کہ `offset_to_aligned` یا تو `align_offset` یا `USIZE_SIZE` ہے ، دونوں کو واضح طور پر اوپر چیک کیا گیا ہے۔
    //
    debug_assert!(offset_to_aligned <= len);

    // محفوظ کریں: word_ptr (صحیح طریقے سے منسلک) استعمال ptr ہے جسے ہم پڑھنے کے لئے استعمال کرتے ہیں
    // سلائس کا درمیانی حصہ
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` کا بائٹ انڈیکس ہے ، جو لوپ کے آخر میں چیک کے لئے استعمال ہوتا ہے۔
    let mut byte_pos = offset_to_aligned;

    // پیراونیا صف بندی کے بارے میں جانچ پڑتال کریں ، چونکہ ہم غیر دستخط شدہ بوجھوں کا ایک گروپ کرنے جارہے ہیں۔
    // عملی طور پر یہ `align_offset` میں کسی مسئلے کو چھوڑ کر ناممکن ہونا چاہئے۔
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // اس کے بعد کے الفاظ آخری پڑھے ہوئے لفظ تک پڑھیں ، اس کے علاوہ آخری سیدھ میں شامل لفظ کو چھوڑ کر خود سے دم کی جانچ پڑتال کریں ، اس بات کا یقین کرنے کے لئے کہ پونچھ ہمیشہ زیادہ سے زیادہ branch `byte_pos == len` پر ایک `usize` رہتا ہے۔
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // بے وقوف چیک کریں کہ پڑھنے کی حدود ہے
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // اور یہ کہ `byte_pos` کے بارے میں ہمارے مفروضے برقرار ہیں۔
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // محفوظ: ہم جانتے ہیں کہ `word_ptr` مناسب طریقے سے منسلک ہے (کی وجہ سے
        // `align_offset`) ، اور ہم جانتے ہیں کہ ہمارے پاس `word_ptr` اور اختتام کے درمیان کافی بائٹس ہیں
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // حفاظت: ہم جانتے ہیں کہ `byte_pos <= len - USIZE_SIZE` ، جس کا مطلب ہے
        // اس `add` کے بعد ، X01 زیادہ سے زیادہ ماضی کے آخر میں ہوگا۔
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // اس بات کو یقینی بنانے کے لئے سینیٹ چیک کریں کہ واقعی میں صرف ایک `usize` باقی ہے۔
    // اس کی ضمانت ہماری لوپ حالت سے ہونی چاہئے۔
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // محفوظ: اس کا انحصار `len >= USIZE_SIZE` پر ہے ، جسے ہم شروع میں دیکھتے ہیں۔
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}