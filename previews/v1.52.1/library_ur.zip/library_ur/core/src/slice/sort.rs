//! سلائس چھانٹ رہا ہے
//!
//! اس ماڈیول میں اورسن پیٹرز کے پیٹرن کو شکست دینے والے کوئکسورٹ پر مبنی چھنٹائی کرنے والا الگورتھم موجود ہے ، جس پر شائع کیا گیا: <https://github.com/orlp/pdqsort>
//!
//!
//! غیر مستحکم چھانٹنا لائبکور کے ساتھ مطابقت رکھتا ہے کیونکہ یہ ہمارے مستحکم چھانٹنے کے عمل کے برعکس میموری کو مختص نہیں کرتا ہے۔
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// جب گرا دیا جائے تو ، `src` سے `dest` میں کاپیاں۔
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // حفاظت: یہ ایک مددگار کلاس ہے۔
        //          براہ کرم درستگی کے ل its اس کے استعمال سے رجوع کریں۔
        //          یعنی ، کسی کو یہ یقینی بنانا ہوگا کہ X001 اور `dst` `ptr::copy_nonoverlapping` کی ضرورت کے مطابق وورلیپ نہیں ہوتا ہے۔
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// پہلے عنصر کو دائیں طرف شفٹ کریں جب تک کہ اس میں کسی بڑے یا مساوی عنصر کا سامنا نہ ہو۔
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // محفوظ: ذیل میں غیر محفوظ آپریشنوں میں بغیر پابند چیک (`get_unchecked` اور `get_unchecked_mut`) کے اشاریے شامل ہیں۔
    // اور میموری (`ptr::copy_nonoverlapping`) کاپی کرنا۔
    //
    // a.اشاریہ کاری:
    //  1. ہم نے>=2 پر صف کی جانچ کی۔
    //  2. ہم جو انڈیکسنگ کریں گے وہ ہمیشہ زیادہ سے زیادہ {0 <= index < len} کے درمیان ہوتا ہے۔
    //
    // b.میموری کاپی کرنا
    //  1. ہم حوالوں کی طرف اشارے حاصل کر رہے ہیں جن کی ضمانت کی ضمانت ہے۔
    //  2. وہ اوورلپ نہیں ہوسکتے ہیں کیونکہ ہم سلائس کے اشاریوں کو فرق کرنے کے لئے پوائنٹر حاصل کرتے ہیں۔
    //     یعنی ، `i` اور `i-1`۔
    //  3. اگر سلائس کو صحیح طریقے سے منسلک کیا گیا ہو تو ، عناصر کو صحیح طریقے سے منسلک کیا جاتا ہے۔
    //     فون کرنے والے کی ذمہ داری ہے کہ اس بات کو یقینی بنائیں کہ سلائس کو صحیح طریقے سے منسلک کیا گیا ہے۔
    //
    // مزید تفصیل کے لئے ذیل میں تبصرے دیکھیں۔
    unsafe {
        // اگر پہلے دو عناصر ناقابل ترتیب ہیں ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // پہلا عنصر اسٹیک سے مختص متغیر میں پڑھیں۔
            // اگر مندرجہ ذیل موازنہ آپریشن panics ، `hole` گرا دیا جائے گا اور عنصر کو خود بخود سلائس میں لکھ دے گا۔
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // عنصر کو ایک جگہ بائیں طرف منتقل کریں ، اس طرح سوراخ کو دائیں طرف منتقل کریں۔
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` چھوڑ دیا جاتا ہے اور اس طرح `v` کو `v` کے باقی سوراخ میں کاپی کرتا ہے۔
        }
    }
}

/// آخری عنصر کو بائیں طرف منتقل کریں جب تک کہ اس میں کسی چھوٹے یا مساوی عنصر کا سامنا نہ ہو۔
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // محفوظ: ذیل میں غیر محفوظ آپریشنوں میں بغیر پابند چیک (`get_unchecked` اور `get_unchecked_mut`) کے اشاریے شامل ہیں۔
    // اور میموری (`ptr::copy_nonoverlapping`) کاپی کرنا۔
    //
    // a.اشاریہ کاری:
    //  1. ہم نے>=2 پر صف کی جانچ کی۔
    //  2. ہم جو انڈیکسنگ کریں گے وہ ہمیشہ زیادہ سے زیادہ `0 <= index < len-1` کے درمیان ہوتا ہے۔
    //
    // b.میموری کاپی کرنا
    //  1. ہم حوالوں کی طرف اشارے حاصل کر رہے ہیں جن کی ضمانت کی ضمانت ہے۔
    //  2. وہ اوورلپ نہیں ہوسکتے ہیں کیونکہ ہم سلائس کے اشاریوں کو فرق کرنے کے لئے پوائنٹر حاصل کرتے ہیں۔
    //     یعنی ، `i` اور `i+1`۔
    //  3. اگر سلائس کو صحیح طریقے سے منسلک کیا گیا ہو تو ، عناصر کو صحیح طریقے سے منسلک کیا جاتا ہے۔
    //     فون کرنے والے کی ذمہ داری ہے کہ اس بات کو یقینی بنائیں کہ سلائس کو صحیح طریقے سے منسلک کیا گیا ہے۔
    //
    // مزید تفصیل کے لئے ذیل میں تبصرے دیکھیں۔
    unsafe {
        // اگر آخری دو عناصر ناقابل ترتیب ہیں ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // آخری عنصر کو اسٹیک مختص متغیر میں پڑھیں۔
            // اگر مندرجہ ذیل موازنہ آپریشن panics ، `hole` گرا دیا جائے گا اور عنصر کو خود بخود سلائس میں لکھ دے گا۔
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // عنصر کو ایک جگہ دائیں طرف منتقل کریں ، اس طرح سوراخ کو بائیں طرف منتقل کریں۔
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` چھوڑ دیا جاتا ہے اور اس طرح `v` کو `v` کے باقی سوراخ میں کاپی کرتا ہے۔
        }
    }
}

/// ارد گرد کے متعدد باہر آرڈر عناصر کو تبدیل کرکے جزوی طور پر ایک ٹکڑا ترتیب دیتا ہے۔
///
/// اگر ٹکڑا اختتام پر ترتیب دیا گیا ہو تو `true` لوٹاتا ہے۔یہ فنکشن *O*(*n*) سب سے خراب معاملہ ہے۔
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // زیادہ سے زیادہ تعداد سے متصل آؤٹ آف آرڈر جوڑے جو منتقل ہوجائیں گے۔
    const MAX_STEPS: usize = 5;
    // اگر ٹکڑا اس سے چھوٹا ہو تو ، کسی بھی عنصر کو مت منتقل کریں۔
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // محفوظ: ہم پہلے ہی واضح طور پر `i < len` کے ساتھ پابند چیکنگ کر چکے ہیں۔
        // ہمارے بعد کی تمام اشاریہ صرف `0 <= index < len` کی حد میں ہے
        unsafe {
            // ملحقہ آؤٹ آف آرڈر عناصر کی اگلی جوڑی تلاش کریں۔
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // کیا ہم ہوچکے ہیں؟
        if i == len {
            return true;
        }

        // مختصر صفوں پر عناصر کو مت منتقل کریں ، جس کی کارکردگی قیمت ہے۔
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // عناصر کے پایا جوڑے کو تبدیل کریں۔یہ انھیں صحیح ترتیب میں رکھتا ہے۔
        v.swap(i - 1, i);

        // چھوٹے عنصر کو بائیں طرف شفٹ کریں۔
        shift_tail(&mut v[..i], is_less);
        // زیادہ سے زیادہ عنصر کو دائیں طرف شفٹ کریں۔
        shift_head(&mut v[i..], is_less);
    }

    // ٹکڑوں کو محدود تعداد میں ترتیب دینے کا انتظام نہیں کیا۔
    false
}

/// داخل کرنے کی ترتیب کا استعمال کرکے ایک ٹکڑا ترتیب دیتا ہے ، جو *O*(*n*^ 2) سب سے خراب معاملہ ہے۔
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// ہیپس پورٹ کا استعمال کرتے ہوئے `v` کو ترتیب دیتا ہے ، جو *O*(*n*\*log(* n*)) بدترین معاملے) کی ضمانت دیتا ہے۔
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // اس ثنائی کے ڈھیر نے حملہ آور `parent >= child` کا احترام کیا ہے۔
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` کے بچے:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // زیادہ سے زیادہ بچے کا انتخاب کریں۔
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // اگر حملہ آور `node` پر فائز ہوتا ہے تو رک جائیں۔
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // زیادہ سے زیادہ بچے کے ساتھ `node` تبدیل کریں ، ایک قدم نیچے جائیں ، اور چھان بین جاری رکھیں۔
            v.swap(node, greater);
            node = greater;
        }
    };

    // خطیر وقت پر ڈھیر بنائیں۔
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ڈھیر سے زیادہ سے زیادہ عنصر پاپ کریں۔
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` سے چھوٹے عناصر میں `v` کی تقسیم ، اور اس کے بعد `pivot` سے زیادہ یا اس کے مساوی عناصر۔
///
///
/// `pivot` سے چھوٹے عناصر کی تعداد لوٹاتا ہے۔
///
/// برانچنگ کے کاموں کی لاگت کو کم سے کم کرنے کے لئے تقسیم کا عمل بلاک بہ بلاک کیا جاتا ہے۔
/// یہ خیال [BlockQuicksort][pdf] پیپر میں پیش کیا گیا ہے۔
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // عام بلاک میں عناصر کی تعداد۔
    const BLOCK: usize = 128;

    // تقسیم الگورتھم تکمیل تک مندرجہ ذیل مراحل کو دہراتا ہے۔
    //
    // 1. محور سے زیادہ یا اس کے برابر عناصر کی نشاندہی کرنے کے لئے بائیں جانب سے ایک بلاک کا سراغ لگائیں۔
    // 2. محور سے چھوٹے عناصر کی شناخت کے لئے دائیں جانب سے ایک بلاک کا سراغ لگائیں۔
    // 3. بائیں اور دائیں جانب کے درمیان شناخت شدہ عناصر کا تبادلہ کریں۔
    //
    // ہم عناصر کے بلاک کے ل following درج ذیل متغیرات رکھتے ہیں:
    //
    // 1. `block` - بلاک میں عناصر کی تعداد۔
    // 2. `start` - `offsets` سرنی میں پوائنٹر شروع کریں۔
    // 3. `end` - `offsets` سرنی میں اختتامی پوائنٹر۔
    // 4. se آفسیٹ ، بلاک کے اندر باہر آرڈر والے عناصر کے اشارے۔

    // بائیں طرف موجودہ بلاک (`l` سے `l.add(block_l)`) تک)
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // دائیں طرف کا موجودہ بلاک (`r.sub(block_r)` to `r`) سے)
    // محفوظ: .add() کے دستاویزات میں یہ ذکر کیا گیا ہے کہ X01 ہمیشہ محفوظ ہے
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: جب ہم VLAs حاصل کرتے ہیں تو ، بجائے اس کی لمبائی `min(v.len() ، 2 * بلاک) کی ایک صف تیار کرنے کی کوشش کریں
    // لمبائی `BLOCK` کی دو طے شدہ سائز کے اشارے سے زیادہ۔VLAs زیادہ کیشے موثر ہو سکتے ہیں۔

    // `l` (inclusive) اور `r` (exclusive) کے مابین عناصر کی تعداد لوٹاتا ہے۔
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // جب `l` اور `r` بہت قریب ہوجاتے ہیں تو ہم تقسیم کار بلاک بہ بلاک کرتے ہیں۔
        // تب ہم باقی عناصر کو درمیان میں تقسیم کرنے کے لئے کچھ پیچ اپ کام کرتے ہیں۔
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // باقی عناصر کی تعداد (اب بھی محور کے ساتھ موازنہ نہیں)۔
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // بلاک کے سائز کو ایڈجسٹ کریں تاکہ بائیں اور دائیں بلاک کو عبور نہ ہو ، لیکن باقی بچا ہوا خلا کو پورا کرنے کے لئے بالکل سیدھے ہو جائیں۔
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // بائیں طرف سے `block_l` عناصر کا سراغ لگائیں۔
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // محفوظ کریں: نیچے کی ناقص کارروائیوں میں `offset` کا استعمال شامل ہے۔
                //         فنکشن کو درکار شرائط کے مطابق ، ہم انہیں مطمئن کرتے ہیں کیونکہ:
                //         1. `offsets_l` اسٹیک مختص ہے ، اور اس طرح الگ الگ مختص آبجیکٹ سمجھا جاتا ہے۔
                //         2. فنکشن `is_less` ایک `bool` واپس کرتا ہے۔
                //            `bool` کو کاسٹ کرنے سے `isize` کبھی بھی بہاو نہیں ہوگا۔
                //         3. ہم نے ضمانت دی ہے کہ `block_l` `<= BLOCK` ہوگا۔
                //            اس کے علاوہ ، `end_l` ابتدا میں `offsets_` کے شروعاتی پوائنٹر پر سیٹ کیا گیا تھا جو اسٹیک پر اعلان کیا گیا تھا۔
                //            اس طرح ، ہم جانتے ہیں کہ بدترین صورتحال میں بھی (`is_less` کی تمام درخواستیں جھوٹی واپس ہوجاتی ہیں) ہم صرف زیادہ سے زیادہ 1 بائٹ کے اختتام کو گزریں گے۔
                //        یہاں ایک اور ناقابل ترجیحی کارروائی `elem` کا تعی .ن کررہی ہے۔
                //        تاہم ، `elem` ابتدائی طور پر سلائس کا آغاز نقطہ تھا جو ہمیشہ درست ہے۔
                unsafe {
                    // برانچ لیس موازنہ۔
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // دائیں طرف سے `block_r` عناصر کا سراغ لگائیں۔
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // محفوظ کریں: نیچے کی ناقص کارروائیوں میں `offset` کا استعمال شامل ہے۔
                //         فنکشن کو درکار شرائط کے مطابق ، ہم انہیں مطمئن کرتے ہیں کیونکہ:
                //         1. `offsets_r` اسٹیک مختص ہے ، اور اس طرح الگ الگ مختص آبجیکٹ سمجھا جاتا ہے۔
                //         2. فنکشن `is_less` ایک `bool` واپس کرتا ہے۔
                //            `bool` کو کاسٹ کرنے سے `isize` کبھی بھی بہاو نہیں ہوگا۔
                //         3. ہم نے ضمانت دی ہے کہ `block_r` `<= BLOCK` ہوگا۔
                //            اس کے علاوہ ، `end_r` ابتدا میں `offsets_` کے شروعاتی پوائنٹر پر سیٹ کیا گیا تھا جو اسٹیک پر اعلان کیا گیا تھا۔
                //            اس طرح ، ہم جانتے ہیں کہ بدترین صورتحال میں بھی (`is_less` کی تمام درخواستیں درست ہوجاتی ہیں) ہم صرف زیادہ سے زیادہ 1 بائٹ کے اختتام کو گزریں گے۔
                //        یہاں ایک اور ناقابل ترجیحی کارروائی `elem` کا تعی .ن کررہی ہے۔
                //        تاہم ، `elem` ابتدا میں اختتام پر `1 *sizeof(T)` تھا اور ہم اسے `1* sizeof(T)` تک پہنچنے سے پہلے اس میں کمی کرتے ہیں۔
                //        نیز ، `block_r` کو `BLOCK` سے کم ہونے کا اصرار کیا گیا تھا اور `elem` لہذا زیادہ تر سلائس کے آغاز کی طرف اشارہ کیا جائے گا۔
                unsafe {
                    // برانچ لیس موازنہ۔
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // باہر اور آرڈر عناصر کی تعداد بائیں اور دائیں جانب کے درمیان تبادلہ کرنے کے لئے۔
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // اس وقت ایک جوڑے کو تبدیل کرنے کے بجائے ، سائیکل چال چلانے کا عمل زیادہ موثر ہے۔
            // یہ تبادلوں کے ل strictly سختی کے مترادف نہیں ہے ، لیکن میموری کے کم کاموں کا استعمال کرتے ہوئے اسی طرح کا نتیجہ برآمد کرتا ہے۔
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // بائیں بلاک کے تمام آؤٹ آف آرڈر عنصروں کو منتقل کردیا گیا تھا۔اگلے بلاک پر جائیں۔
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // دائیں بلاک کے تمام آؤٹ آف آرڈر عنصر منتقل کردیئے گئے تھے۔پچھلے بلاک پر جائیں۔
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // اب جو باقی رہ گیا ہے وہ زیادہ سے زیادہ ایک بلاک میں ہے (یا تو بائیں یا دائیں) آرڈر آؤٹ عناصر کے ساتھ جسے منتقل کرنے کی ضرورت ہے۔
    // اس طرح کے باقی عناصر کو آسانی سے اپنے بلاک کے آخر میں منتقل کیا جاسکتا ہے۔
    //

    if start_l < end_l {
        // بائیں بلاک باقی ہے.
        // اس کے باقی آؤٹ آف آرڈر عنصر کو دائیں طرف لے جائیں۔
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // دائیں بلاک باقی ہے.
        // اس کے باقی آؤٹ آف آرڈر عنصر کو بہت بائیں طرف منتقل کریں۔
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // اور کچھ نہیں کرنا ، ہم کام کرچکے ہیں۔
        width(v.as_mut_ptr(), l)
    }
}

/// `v` سے چھوٹے عناصر میں `v` کی پارٹیشنز ، اس کے بعد `v[pivot]` سے زیادہ یا مساوی عناصر ہوتے ہیں۔
///
///
/// اس کا ایک ٹوٹل واپس کرتا ہے:
///
/// 1. `v[pivot]` سے چھوٹے عناصر کی تعداد۔
/// 2. اگر `v` پہلے ہی تقسیم ہوچکا ہے تو سچ ہے۔
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // سلائس کے آغاز میں محور رکھیں۔
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // محرک کو کارکردگی کے ل st اسٹیک سے مختص متغیر میں پڑھیں۔
        // اگر مندرجہ ذیل موازنہ آپریشن panics ، محور خود بخود سلائس میں لکھا جائے گا۔
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // باہر کے آرڈر والے عناصر کی پہلی جوڑی تلاش کریں۔
        let mut l = 0;
        let mut r = v.len();

        // محفوظ کریں: نیچے دیئے گئے ناموس میں ایک صف کی ترتیب شامل ہے۔
        // پہلے میں سے ایک کے لئے: ہم پہلے ہی `l < r` کے ساتھ حدود کی جانچ پڑتال کرتے ہیں۔
        // دوسرے کے لئے: ہمارے پاس ابتدا میں `l == 0` اور `r == v.len()` ہے اور ہم نے ہر انڈیکسنگ آپریشن میں `l < r` کی جانچ کی ہے۔
        //                     یہاں سے ہم جانتے ہیں کہ `r` کم از کم `r == l` ہونا چاہئے جو پہلے سے درست ثابت ہوا تھا۔
        unsafe {
            // پہلا عنصر محور سے زیادہ یا اس کے برابر تلاش کریں۔
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // آخری عنصر چھوٹا معلوم کریں کہ محور
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` دائرہ کار سے ہٹ جاتا ہے اور محور (جو ایک اسٹیک مختص متغیر ہے) کو اس سلائس میں واپس لکھتا ہے جہاں یہ اصل میں تھا۔
        // حفاظت کو یقینی بنانے کے لئے یہ اقدام اہم ہے!
        //
    };

    // دو پارٹیشنوں کے درمیان محور رکھیں۔
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` کے برابر عناصر میں `v` کی تقسیم ، اس کے بعد `v[pivot]` سے زیادہ عناصر بنائیں۔
///
/// محور کے برابر عناصر کی تعداد لوٹاتا ہے۔
/// یہ فرض کیا جاتا ہے کہ `v` میں محور سے چھوٹے عنصر نہیں ہوتے ہیں۔
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // سلائس کے آغاز میں محور رکھیں۔
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // محرک کو کارکردگی کے ل st اسٹیک سے مختص متغیر میں پڑھیں۔
    // اگر مندرجہ ذیل موازنہ آپریشن panics ، محور خود بخود سلائس میں لکھا جائے گا۔
    // حفاظت: یہاں کا اشارہ درست ہے کیونکہ یہ سلائس کے حوالہ سے حاصل کیا جاتا ہے۔
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // اب ٹکڑا تقسیم کریں۔
    let mut l = 0;
    let mut r = v.len();
    loop {
        // محفوظ کریں: نیچے دیئے گئے ناموس میں ایک صف کی ترتیب شامل ہے۔
        // پہلے میں سے ایک کے لئے: ہم پہلے ہی `l < r` کے ساتھ حدود کی جانچ پڑتال کرتے ہیں۔
        // دوسرے کے لئے: ہمارے پاس ابتدا میں `l == 0` اور `r == v.len()` ہے اور ہم نے ہر انڈیکسنگ آپریشن میں `l < r` کی جانچ کی ہے۔
        //                     یہاں سے ہم جانتے ہیں کہ `r` کم از کم `r == l` ہونا چاہئے جو پہلے سے درست ثابت ہوا تھا۔
        unsafe {
            // محور سے بڑا عنصر ڈھونڈیں۔
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // محور کے برابر آخری عنصر تلاش کریں۔
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // کیا ہم ہوچکے ہیں؟
            if l >= r {
                break;
            }

            // باہر کے آرڈر والے عناصر کی جوڑی کو تبدیل کریں۔
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // ہمیں محور کے برابر `l` عنصر ملے ہیں۔محور کے اکاؤنٹ میں 1 شامل کریں۔
    l + 1

    // `_pivot_guard` دائرہ کار سے ہٹ جاتا ہے اور محور (جو ایک اسٹیک مختص متغیر ہے) کو اس سلائس میں واپس لکھتا ہے جہاں یہ اصل میں تھا۔
    // حفاظت کو یقینی بنانے کے لئے یہ اقدام اہم ہے!
}

/// پیٹرن کو توڑنے کی کوشش میں کچھ عناصر کو پھیلاتے ہیں جس کی وجہ سے کوئیکسورٹ میں عدم توازن کا سبب بن سکتا ہے۔
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // جارج مارسگلیہ کے "Xorshift RNGs" کاغذ سے چھڈورینڈم نمبر جنریٹر۔
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // اس نمبر کو بے ترتیب نمبروں پر لیں۔
        // تعداد `usize` میں فٹ بیٹھتی ہے کیونکہ `len` `isize::MAX` سے زیادہ نہیں ہے۔
        let modulus = len.next_power_of_two();

        // کچھ محور امیدوار اس انڈیکس کے آس پاس ہوں گے۔آئیے انہیں بے ترتیب کردیں۔
        let pos = len / 4 * 2;

        for i in 0..3 {
            // ایک بے ترتیب نمبر ماڈیولو `len` بنائیں۔
            // تاہم ، مہنگے آپریشنوں سے بچنے کے ل. ہم پہلے اسے دو میں سے ایک کی طاقت بناتے ہیں ، اور پھر `len` تک کم ہوجاتے ہیں جب تک کہ یہ `[0, len - 1]` کی حد میں فٹ نہ ہوجائے۔
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` سے کم رہنے کی ضمانت ہے۔
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` میں ایک محور کا انتخاب کرتا ہے اور اگر سلائس کو پہلے ہی ترتیب دیا گیا ہو تو انڈیکس اور X01 ایکس واپس کرتا ہے۔
///
/// اس عمل میں `v` میں موجود عناصر کو دوبارہ ترتیب دیا جاسکتا ہے۔
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // میڈین آف میڈیسن طریقہ منتخب کرنے کے لئے کم سے کم لمبائی۔
    // چھوٹی سلائسیں میڈین آف تھری کا آسان طریقہ استعمال کرتی ہیں۔
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // اس تقریب میں زیادہ سے زیادہ تبدیلیاں کی جاسکتی ہیں۔
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // تین اشارے جس کے قریب ہم ایک محور کا انتخاب کرنے جارہے ہیں۔
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // فہرستوں کی چھانٹ کے دوران ہم جو تبدیلیاں کرنے جارہے ہیں ان کی کل تعداد گنتی ہے۔
    let mut swaps = 0;

    if len >= 8 {
        // تبادلہ اشاریہ تاکہ `v[a] <= v[b]`۔
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // انڈیکس انڈیکس تاکہ `v[a] <= v[b] <= v[c]`۔
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` کا وسط ڈھونڈتا ہے اور انڈیکس کو `a` میں اسٹور کرتا ہے۔
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a` ، `b` ، اور `c` کے پڑوس میں میڈین تلاش کریں۔
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a` ، `b` ، اور `c` کے درمیان میڈین تلاش کریں۔
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // زیادہ سے زیادہ تبدیلیاں انجام دی گئیں۔
        // امکان یہ ہے کہ سلائس اترتی ہے یا زیادہ تر اترتی ہے ، لہذا تبدیل کرنے سے شاید اس کی تیز رفتار ترتیب دینے میں مدد ملے گی۔
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` کو بار بار ترتیب دیتا ہے۔
///
/// اگر سلائس کا اصل صف میں پیشرو تھا تو ، اسے `pred` کے طور پر بتایا گیا ہے۔
///
/// `limit` `heapsort` پر سوئچ کرنے سے پہلے اجازت شدہ متوازن پارٹیشنز کی تعداد ہے۔
/// اگر صفر ہے تو ، یہ فنکشن فوری طور پر ہیپس پورٹ میں تبدیل ہوجائے گا۔
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // لمبائی تک کے ٹکڑوں کو اندراج کی ترتیب سے ترتیب دیا جاتا ہے۔
    const MAX_INSERTION: usize = 20;

    // سچ ہے اگر آخری تقسیم مناسب طریقے سے متوازن ہو۔
    let mut was_balanced = true;
    // یہ سچ ہے کہ اگر آخری تقسیم نے عناصر کو تبدیل نہیں کیا (سلائس پہلے ہی تقسیم ہوچکی تھی)۔
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // اندراج کی ترتیب کا استعمال کرتے ہوئے بہت ہی مختصر سلائسیں ترتیب دی جاتی ہیں۔
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // اگر بہت سارے خراب محور انتخاب کیے گئے تھے تو ، `O(n * log(n))` بدترین معاملے کی ضمانت کے ل simply صرف ہیپس پورٹ پر واپس گریں۔
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // اگر آخری تقسیم غیر متوازن تھی تو ، آس پاس کے کچھ عناصر کو تبدیل کرکے سلائس میں پیٹرن توڑنے کی کوشش کریں۔
        // امید ہے کہ ہم اس بار ایک بہتر محور کا انتخاب کریں گے۔
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // ایک محور کا انتخاب کریں اور اندازہ لگانے کی کوشش کریں کہ ٹکڑا پہلے ہی ترتیب دیا گیا ہے یا نہیں۔
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // اگر آخری تقسیم مستقل طور پر متوازن تھی اور عناصر کو تبدیل نہیں کیا جاتا تھا ، اور اگر محور انتخاب پیش گوئی کرتا ہے کہ ٹکڑا پہلے ہی ترتیب دیا گیا ہے تو ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // آرڈر کے متعدد عناصر کی نشاندہی کرنے اور انہیں صحیح مقام پر منتقل کرنے کی کوشش کریں۔
            // اگر ٹکڑا مکمل طور پر حل ہونے کے بعد ختم ہوجائے تو ، ہم کام کر چکے ہیں۔
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // اگر منتخب کردہ محور پیشرو کے برابر ہے ، تو یہ ٹکڑا میں سب سے چھوٹا عنصر ہے۔
        // ٹکڑا کو برابر کے عناصر اور محور سے زیادہ عناصر میں تقسیم کریں۔
        // اس معاملے کو عام طور پر اس وقت متاثر کیا جاتا ہے جب سلائس میں بہت سارے ڈپلیکیٹ عنصر ہوتے ہیں۔
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // محور سے زیادہ عناصر کی چھانٹیا جاری رکھیں۔
                v = &mut { v }[mid..];
                continue;
            }
        }

        // ٹکڑا تقسیم.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // سلائس کو `left` ، `pivot` ، اور `right` میں تقسیم کریں۔
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // تکرار کالوں کی کل تعداد کو کم سے کم کرنے اور اسٹیک اسپیس کی کم مقدار استعمال کرنے کے ل only صرف چھوٹی سائیڈ میں دوبارہ تکرار کریں۔
        // پھر صرف لمبی طرف کے ساتھ جاری رکھیں (یہ دم تکرار کے مترادف ہے)۔
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// پیٹرن کو شکست دینے والے کوئکسورٹ کا استعمال کرتے ہوئے `v` کو ترتیب دیتا ہے ، جو *O*(*n*\*log(* n*)) بدترین معاملہ) ہے۔
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // صفر سائز کی اقسام پر چھانٹنا کا کوئی معنی خیز رویہ نہیں ہے۔
    if mem::size_of::<T>() == 0 {
        return;
    }

    // متوازن پارٹیشنز کی تعداد کو `floor(log2(len)) + 1` تک محدود کریں۔
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // اس لمبائی تک کے سلائسوں کے ل sort ان کی ترتیب کرنا شاید تیز تر ہے۔
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ایک محور کا انتخاب کریں
        let (pivot, _) = choose_pivot(v, is_less);

        // اگر منتخب کردہ محور پیشرو کے برابر ہے ، تو یہ ٹکڑا میں سب سے چھوٹا عنصر ہے۔
        // ٹکڑا کو برابر کے عناصر اور محور سے زیادہ عناصر میں تقسیم کریں۔
        // اس معاملے کو عام طور پر اس وقت متاثر کیا جاتا ہے جب سلائس میں بہت سارے ڈپلیکیٹ عنصر ہوتے ہیں۔
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // اگر ہم اپنا انڈیکس گزر چکے ہیں ، تو ہم اچھے ہیں۔
                if mid > index {
                    return;
                }

                // بصورت دیگر ، محور سے زیادہ عناصر کی چھانٹنا جاری رکھیں۔
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // سلائس کو `left` ، `pivot` ، اور `right` میں تقسیم کریں۔
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // اگر وسط==اشاریہ ہے ، تو ہم مکمل ہو گئے ، چونکہ partition() نے ضمانت دی ہے کہ وسط کے بعد کے تمام عناصر وسط سے زیادہ یا برابر ہوتے ہیں۔
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // صفر سائز کی اقسام پر چھانٹنا کا کوئی معنی خیز رویہ نہیں ہے۔کچھ نہ کرو.
    } else if index == v.len() - 1 {
        // زیادہ سے زیادہ عنصر تلاش کریں اور اسے سرنی کی آخری پوزیشن میں رکھیں۔
        // ہم یہاں `unwrap()` استعمال کرنے میں آزاد ہیں کیونکہ ہمیں معلوم ہے کہ v کو خالی نہیں ہونا چاہئے۔
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // کم سے کم عنصر تلاش کریں اور اسے صف کی پہلی پوزیشن میں رکھیں۔
        // ہم یہاں `unwrap()` استعمال کرنے میں آزاد ہیں کیونکہ ہمیں معلوم ہے کہ v کو خالی نہیں ہونا چاہئے۔
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}