// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// حد `[mid-left, mid+right)` کو اس طرح گھمااتا ہے کہ `mid` پر عنصر پہلا عنصر بن جاتا ہے۔مساویانہ طور پر ، رینج `left` عناصر کو بائیں یا `right` عناصر کو دائیں سے گھماتے ہیں۔
///
/// # Safety
///
/// پڑھنے اور لکھنے کے لئے مخصوص حد ضروری ہے۔
///
/// # Algorithm
///
/// الگورتھم 1 `left + right` کی چھوٹی اقدار کے لئے یا بڑے `T` کے لئے استعمال کیا جاتا ہے۔
/// `mid - left` سے شروع ہونے والے اور `right` اقدامات ماڈیولو `left + right` کے ذریعہ پیش قدمی کرتے ہوئے عناصر کو ایک بار اپنی آخری پوزیشن میں منتقل کردیا جاتا ہے ، اس طرح کہ صرف ایک عارضی کی ضرورت ہوتی ہے۔
/// آخر کار ، ہم واپس `mid - left` پر پہنچیں۔
/// تاہم ، اگر `gcd(left + right, right)` 1 نہیں ہے تو ، مذکورہ بالا اقدامات عناصر پر چھوڑ دیئے گئے۔
/// مثال کے طور پر:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// خوش قسمتی سے ، حتمی شکل دینے والے عناصر کے مابین چھوٹ جانے والے عناصر کی تعداد ہمیشہ برابر رہتی ہے ، لہذا ہم صرف اپنی ابتدائی پوزیشن کو بہتر بناسکتے ہیں اور زیادہ چکر لگاسکتے ہیں (راؤنڈ کی کل تعداد `gcd(left + right, right)` value) ہے۔
///
/// آخری نتیجہ یہ ہے کہ تمام عناصر کو ایک بار اور صرف ایک بار حتمی شکل دی جاتی ہے۔
///
/// اگر `left + right` بڑا ہے تو الگورتھم 2 کا استعمال کیا جاتا ہے لیکن اسٹیک بفر پر فٹ ہونے کے لئے `min(left, right)` اتنا چھوٹا ہے۔
/// `min(left, right)` عناصر کو بفر پر کاپی کیا جاتا ہے ، `memmove` کا اطلاق دوسروں پر ہوتا ہے ، اور بفر پر موجود افراد کو جہاں سے شروع ہوا تھا اس کے مخالف سمت میں واپس سوراخ میں منتقل کردیا جاتا ہے۔
///
/// ایک بار جب `left + right` کافی بڑا ہوجائے تو الگورتھم جو اوپر کی کارکردگی کو بہتر انداز میں بیان کرسکتے ہیں۔
/// یلگوردم 1 ایک بار میں بہت سارے راؤنڈ کا انتخاب کرکے کارکردگی کا مظاہرہ کرسکتا ہے ، لیکن اوسطا بہت کم راؤنڈ ہوتے ہیں جب تک کہ `left + right` بہت زیادہ نہ ہو ، اور ایک ہی راؤنڈ کی بدترین صورت ہمیشہ موجود رہتی ہے۔
/// اس کے بجائے ، الگورتھم 3 `min(left, right)` عناصر کو بار بار تبدیل کرنے کا استعمال کرتا ہے جب تک کہ ایک چھوٹا گھومنے والی دشواری باقی نہ رہ جائے۔
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// جب `left < right` تبدیل ہونے کی بجائے بائیں سے ہوتا ہے۔
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. اگر ان معاملات کی جانچ نہ کی گئی ہو تو مندرجہ ذیل الگورتھم ناکام ہوسکتے ہیں
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // الگورتھم 1 مائکرو بینچ مارکس سے پتہ چلتا ہے کہ بے ترتیب شفٹوں کے لئے اوسط کارکردگی تقریبا X `left + right == 32` تک ہر لحاظ سے بہتر ہے ، لیکن بدترین صورت کی کارکردگی بھی 16 کے آس پاس ٹوٹ جاتی ہے۔
            // 24 کو درمیانی زمین کے طور پر منتخب کیا گیا تھا۔
            // اگر `T` کا سائز 4 `usize`s سے بڑا ہے تو ، یہ الگورتھم دوسرے الگورتھم کو بھی بہتر بنا دیتا ہے۔
            //
            //
            let x = unsafe { mid.sub(left) };
            // پہلے دور کا آغاز
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` کا حساب کتاب کر کے ہاتھ سے پہلے پایا جاسکتا ہے ، لیکن ایک لوپ کرنا تیز ہے جو جی سی ڈی کو ضمنی اثر کے طور پر حساب کرتا ہے ، پھر باقی حص doingے کو کر رہا ہے۔
            //
            //
            let mut gcd = right;
            // بینچ مارک سے پتہ چلتا ہے کہ عارضی طور پر ایک بار عارضی پڑھنے ، پیچھے کاپی کرنے کی بجائے ، اور پھر عارضی تحریر کے آخر میں لکھنا تیز تر ہے۔
            // یہ ممکنہ طور پر اس حقیقت کی وجہ سے ہے کہ عارضی تبدیلیاں یا تبدیل کرنے سے دو کا انتظام کرنے کی ضرورت کے بجائے لوپ میں صرف ایک میموری پتے کا استعمال ہوتا ہے۔
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` کو بڑھانے اور پھر جانچ پڑتال کرنے کے بجائے کہ آیا یہ حد سے باہر ہے ، ہم چیک کرتے ہیں کہ اگلی انکرمنٹ میں `i` حد سے باہر جائے گا یا نہیں۔
                // یہ اشارے یا `usize` کو کسی بھی طرح سے لپیٹنے سے روکتا ہے۔
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // پہلے دور کا اختتام
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // اگر `left + right >= 15` ہے تو یہ مشروط ہونا ضروری ہے
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // زیادہ راؤنڈ کے ساتھ حصہ ختم
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` صفر سائز کی قسم کی نہیں ہے ، لہذا اس کے سائز کے حساب سے تقسیم کرنا ٹھیک ہے۔
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // الگورتھم 2 X یہاں X کو یقینی بنانا ہے کہ یہ مناسب طریقے سے ٹی کے لئے منسلک ہے
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // الگورتھم 3 تبادلہ کرنے کا ایک متبادل طریقہ ہے جس میں یہ بھی شامل ہے کہ اس الگورتھم کا آخری تبادلہ کہاں ہوگا ، اور اس الگورتھم جیسے ملحقہ حصوں کو تبدیل کرنے کی بجائے آخری حص chہ کو تبدیل کرنے میں شامل ہے ، لیکن یہ راستہ ابھی بھی تیز ہے۔
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // الگورتھم 3، `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}