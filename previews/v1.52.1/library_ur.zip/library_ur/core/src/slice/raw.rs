//! `&[T]` اور `&mut [T]` بنانے کے لئے مفت کام کرتا ہے۔

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// ایک پوائنٹر اور لمبائی سے ٹکڑا تشکیل دیتا ہے۔
///
/// `len` دلیل **عناصر** کی تعداد ہے ، بائٹس کی تعداد نہیں ہے۔
///
/// # Safety
///
/// اگر مندرجہ ذیل شرائط میں سے کسی کی خلاف ورزی ہوتی ہے تو طرز عمل کی وضاحت نہیں کی جاتی ہے۔
///
/// * `data` `len * mem::size_of::<T>()` بہت سارے بائٹس کے مطالعے کے ل X [valid] ہونا ضروری ہے ، اور اسے صحیح طور پر سیدھ میں ہونا چاہئے۔اس کا مطلب خاص طور پر ہے:
///
///     * اس ٹکڑے کی پوری میموری کی حد ایک ہی مختص آبجیکٹ میں ہونی چاہئے۔
///       ٹکڑے ٹکڑے کبھی بھی متعدد مختص آبجیکٹ میں نہیں پھیل سکتے ہیں۔کسی مثال کے ل account [below](#incorrect-usage) ملاحظہ کریں کہ اس کو خاطر میں نہیں لاتے ہیں۔
///     * `data` صفر کی لمبائی کے سلائس کے ل even بھی بے بنیاد ہونا چاہئے اور منسلک ہونا چاہئے۔
///     اس کی ایک وجہ یہ ہے کہ اینوم لے آؤٹ آپٹیمائزیشن حوالہ جات (جس میں کسی لمبائی کے ٹکڑے بھی شامل ہے) پر منحصر ہوسکتی ہے تاکہ وہ دوسرے ڈیٹا سے ممتاز ہوسکے۔
///     آپ ایک ایسا پوائنٹر حاصل کرسکتے ہیں جو [`NonNull::dangling()`] کا استعمال کرتے ہوئے صفر لمبائی کے سلائس کے لئے `data` کے بطور قابل استعمال ہو۔
///
/// * `data` X001 قسم کی مسلسل مناسب طریقے سے شروع کی گئی اقدار کو `len` کی طرف اشارہ کرنا چاہئے۔
///
/// * واپس شدہ سلائس کے ذریعہ یادداشت کو `UnsafeCell` X کے علاوہ ، تاحیات `'a` کی مدت میں تبدیل نہیں کیا جانا چاہئے۔
///
/// * سلائس کا کل سائز `len * mem::size_of::<T>()` `isize::MAX` سے بڑا نہیں ہونا چاہئے۔
///   [`pointer::offset`] کی حفاظتی دستاویزات دیکھیں۔
///
/// # Caveat
///
/// لوٹی ہوئی سلائس کے لئے زندگی بھر اس کے استعمال سے اندازہ لگایا جاتا ہے۔
/// حادثاتی غلط استعمال کی روک تھام کے ل it's ، تجویز کیا گیا ہے کہ سیاق و سباق میں جو بھی ذریعہ زندگی محفوظ ہو ، اس کی زندگی کو زندگی کے ساتھ باندھ دیا جائے ، جیسے کسی مددگار کے فنکشن کے ذریعہ سلائس کی میزبانی کی قیمت کے دوران ، یا واضح بیانات کے ذریعے۔
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // ایک عنصر کے لئے ایک ٹکڑا ظاہر
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### غلط استعمال
///
/// مندرجہ ذیل `join_slices` فنکشن **انوسنڈ** is ہے
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // مذکورہ بالا دعوے کو یقینی بناتا ہے کہ `fst` اور `snd` مماثل ہیں ، لیکن وہ اب بھی _different allocated objects_ کے اندر موجود ہوسکتے ہیں ، ایسی صورت میں اس سلائس کو تشکیل دینا غیر متعینہ طرز عمل ہے۔
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` اور `b` مختلف مختص اشیاء ہیں ...
///     let a = 42;
///     let b = 27;
///     // ... جو بہر حال یادداشت میں مستقل طور پر رکھی جاسکتی ہے: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // محفوظ: کال کرنے والے کو `from_raw_parts` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// [`from_raw_parts`] جیسا ہی فعالیت انجام دیتا ہے ، سوائے اس کے کہ ایک تغیر پزیر ٹکڑا واپس کردیا جائے۔
///
/// # Safety
///
/// اگر مندرجہ ذیل شرائط میں سے کسی کی خلاف ورزی ہوتی ہے تو طرز عمل کی وضاحت نہیں کی جاتی ہے۔
///
/// * `data` بہت سے بائٹس `len * mem::size_of::<T>()` کے ل reads پڑھنے اور لکھنے دونوں کے لئے [valid] ہونا ضروری ہے ، اور اسے صحیح طور پر سیدھ میں ہونا چاہئے۔اس کا مطلب خاص طور پر ہے:
///
///     * اس ٹکڑے کی پوری میموری کی حد ایک ہی مختص آبجیکٹ میں ہونی چاہئے۔
///       ٹکڑے ٹکڑے کبھی بھی متعدد مختص آبجیکٹ میں نہیں پھیل سکتے ہیں۔
///     * `data` صفر کی لمبائی کے سلائس کے ل even بھی بے بنیاد ہونا چاہئے اور منسلک ہونا چاہئے۔
///     اس کی ایک وجہ یہ ہے کہ اینوم لے آؤٹ آپٹیمائزیشن حوالہ جات (جس میں کسی لمبائی کے ٹکڑے بھی شامل ہے) پر منحصر ہوسکتی ہے تاکہ وہ دوسرے ڈیٹا سے ممتاز ہوسکے۔
///
///     آپ ایک ایسا پوائنٹر حاصل کرسکتے ہیں جو [`NonNull::dangling()`] کا استعمال کرتے ہوئے صفر لمبائی کے سلائس کے لئے `data` کے بطور قابل استعمال ہو۔
///
/// * `data` X001 قسم کی مسلسل مناسب طریقے سے شروع کی گئی اقدار کو `len` کی طرف اشارہ کرنا چاہئے۔
///
/// * واپسی سلائس کے ذریعہ حوالہ شدہ میموری کو تاحیات `'a` کی مدت کے لئے کسی دوسرے پوائنٹر (ریٹرن ویلیو سے ماخوذ نہیں) تک رسائی حاصل نہیں ہونی چاہئے۔
///   پڑھنے لکھنے دونوں تک رسائی ممنوع ہے۔
///
/// * سلائس کا کل سائز `len * mem::size_of::<T>()` `isize::MAX` سے بڑا نہیں ہونا چاہئے۔
///   [`pointer::offset`] کی حفاظتی دستاویزات دیکھیں۔
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // محفوظ: کال کرنے والے کو `from_raw_parts_mut` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T کے حوالہ کو لمبائی 1 (کاپی کیے بغیر) کے ٹکڑے میں بدل دیتا ہے۔
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T کے حوالہ کو لمبائی 1 (کاپی کیے بغیر) کے ٹکڑے میں بدل دیتا ہے۔
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}