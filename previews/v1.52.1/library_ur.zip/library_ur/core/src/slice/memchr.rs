// اصل عمل درآمد rust-mechr سے لیا گیا۔
// کاپی رائٹ 2015 اینڈریو گیلنٹ ، bluss اور نکولس کوچ

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// تراشنا استعمال کریں۔
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// اگر `x` میں کوئی صفر بائٹ شامل ہو تو `true` لوٹاتا ہے۔
///
/// *معاملات کمپیوٹیشنل*، جے ارندٹ سے:
///
/// "خیال یہ ہے کہ ہر بائٹس میں سے ایک کو گھٹائیں اور پھر بائٹس تلاش کریں جہاں قرضے نے تمام راستے کو انتہائی نمایاں کردیا۔
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` میں بائٹ `x` سے مماثل پہلا انڈیکس لوٹاتا ہے۔
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // چھوٹے سلائسین کے لئے تیز راہ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ایک بار میں دو `usize` الفاظ پڑھ کر ایک بائٹ ویلیو کیلئے اسکین کریں۔
    //
    // `text` کو تین حصوں میں تقسیم کریں
    // - پہلے دستخط میں پہلا لفظ منسلک ایڈریس سے پہلے غیر دستخط شدہ ابتدائی حصہ
    // - جسم ، ایک وقت میں 2 الفاظ کے ذریعہ اسکین کریں
    // - آخری باقی حصہ ، <2 لفظی سائز

    // منسلک حد تک تلاش کریں
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // متن کی باڈی تلاش کریں
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // حفاظت: جب کہ پیش گوئی کم از کم 2 * usize_bytes کے فاصلے کی ضمانت دیتا ہے
        // آفسیٹ اور سلائس کے اختتام کے درمیان۔
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // اگر کوئی مماثل بائٹ ہے توڑ دیں
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // اس نقطہ کے بعد بائٹ تلاش کریں جس کے بعد جسم کا لوپ رک گیا تھا۔
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` میں بائٹ `x` سے مماثل آخری انڈیکس لوٹاتا ہے۔
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ایک بار میں دو `usize` الفاظ پڑھ کر ایک بائٹ ویلیو کیلئے اسکین کریں۔
    //
    // `text` کو تین حصوں میں تقسیم کریں:
    // - بغیر دستخط شدہ پونچھ ، آخری لفظ کے متنی خط میں سیدھے پتے کے بعد ،
    // - جسم ، ایک وقت میں 2 الفاظ سے اسکین ،
    // - پہلا باقی بائٹس ، <2 لفظ سائز۔
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // ہم اسے صرف ماقبل اور ماقبل کی لمبائی حاصل کرنے کے ل call کہتے ہیں۔
        // بیچ میں ہم ہمیشہ ایک ہی وقت میں دو ٹکڑوں پر عملدرآمد کرتے ہیں۔
        // محفوظ: `[u8]` کو `[usize]` میں منتقل کرنا محفوظ ہے سوائے سائز کے فرق کے جو `align_to` کے ذریعہ سنبھالا جاتا ہے۔
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // متن کی باڈی تلاش کریں ، یقینی بنائیں کہ ہم منٹ_الائنٹ_آفسیٹ کو عبور نہیں کرتے ہیں۔
    // آفسیٹ ہمیشہ سیدھ میں رہتا ہے ، لہذا صرف `>` کی جانچ کافی ہے اور ممکنہ بہاؤ سے بچ جاتا ہے۔
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // محفوظ: جب تک کہ اس سے زیادہ ہو ، آفسیٹ لین ، suffix.len() سے شروع ہوتا ہے
        // من_الائنڈ_آفسیٹ (prefix.len()) باقی فاصلہ کم از کم 2 * ٹکڑا_بیٹس ہے۔
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // اگر کوئی مماثل بائٹ ہے توڑ دیں۔
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // اس نقطہ سے پہلے بائٹ تلاش کریں جس سے جسم کا لوپ رک گیا ہو۔
    text[..offset].iter().rposition(|elt| *elt == x)
}