//! لائبکور کیلئے Panic سپورٹ
//!
//! بنیادی لائبریری گھبراہٹ کی وضاحت نہیں کرسکتی ہے ، لیکن اس میں خوف و ہراس کا *اعلان* ہوتا ہے۔
//! اس کا مطلب یہ ہے کہ لیبکور کے اندر موجود افعال کو زیڈ پیپنک0 زیڈ کی اجازت دی گئی ہے ، لیکن مفید ہونے کے لئے ایک upstream crate استعمال کرنے کے لb لائبکور کے لئے گھبرانے کی وضاحت کرنی چاہئے۔
//! گھبرانے کا موجودہ انٹرفیس یہ ہے:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! یہ تعریف کسی بھی عام پیغام سے گھبرانے کی اجازت دیتی ہے ، لیکن یہ `Box<Any>` قدر کے ساتھ ناکام ہونے کی اجازت نہیں دیتی ہے۔
//! (`PanicInfo` صرف ایک `&(dyn Any + Send)` پر مشتمل ہے ، جس کے ل we ہم `PanicInfo: : اندرونی_کونسٹریکٹر` میں ایک ڈمی قدر کو بھرتے ہیں۔) اس کی وجہ یہ ہے کہ لیبکور کو مختص کرنے کی اجازت نہیں ہے۔
//!
//!
//! اس ماڈیول میں کچھ دیگر گھبراہٹ والے افعال شامل ہیں ، لیکن یہ صرف مرتب کرنے والے کے لئے ضروری لینگ آئٹمز ہیں۔تمام panics اس ایک فنکشن کے ذریعے تیار کیے گئے ہیں۔
//! `#[panic_handler]` وصف کے ذریعہ اصل علامت کا اعلان کیا گیا ہے۔
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// جب کوئی فارمیٹنگ استعمال نہیں ہوتی ہے تو لائبکور کے `panic!` میکرو کا بنیادی نفاذ۔
#[cold]
// جتنا ممکن ہو سکے کال سائٹس پر کوڈ بلاٹ سے بچنے کے ل pan جب تک گھبراہٹ_میڈیٹ_ابورٹ نہ کریں ان لائن کبھی نہیں بنائیں
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // اوور فلو اور دیگر `Assert` MIR ٹرمنیٹرز پر panic کیلئے کوڈجن کی ضرورت ہے
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ممکنہ طور پر سائز کے اوورہیڈ کو کم کرنے کے لئے format_args! ("{}"، expr) کی بجائے Arguments::new_v1 استعمال کریں۔
    // فارمیٹ_ارگس!میکرو ایکسپریس لکھنے کے لئے str کے ڈسپلے trait کا استعمال کرتا ہے ، جو Formatter::pad کہتا ہے ، جس میں سٹرنگ ٹرنکشن اور پیڈنگ کو ایڈجسٹ کرنا ضروری ہے (اگرچہ یہاں کوئی بھی استعمال نہیں ہوتا ہے)۔
    //
    // Arguments::new_v1 استعمال کرنے سے مرتب کو Formatter::pad کو آؤٹ پٹ بائنری سے خارج کرنے کی اجازت مل سکتی ہے ، جس سے کچھ کلو بائٹ تک کی بچت ہوگی۔
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // ضبط کی جانچ پڑتال panics کے لئے ضروری ہے
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice تک رسائی پر panic کیلئے کوڈجن کے ذریعہ درکار ہے
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// جب فارمیٹنگ استعمال کی جاتی ہے تو لائبکور کے `panic!` میکرو کا بنیادی نفاذ۔
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // نوٹ: یہ فنکشن کبھی بھی FFI کی حد سے تجاوز نہیں کرتا ہے۔یہ ایک Rust-to-Rust کال ہے جو `#[panic_handler]` فنکشن میں حل ہوجاتی ہے۔
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // محفوظ: `panic_impl` کو محفوظ Rust کوڈ میں بیان کیا گیا ہے اور اس طرح کال کرنا محفوظ ہے۔
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` اور `assert_ne!` میکروز کیلئے داخلی فنکشن
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}