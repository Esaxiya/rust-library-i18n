//! اعشاریہ تار کو آئی ای ای 754 بائنری فلوٹنگ پوائنٹ نمبرز میں تبدیل کرنا۔
//!
//! # مسئلہ یہ بیان
//!
//! ہمیں ایک اعشاریہ تار فراہم کی جاتی ہے جیسے `12.34e56`۔
//! اس تار میں لازمی (`12`) ، جزوی (`34`) ، اور خاکہ (`56`) حصے ہوتے ہیں۔تمام حصے اختیاری ہیں اور غائب ہونے پر صفر کی ترجمانی کرتے ہیں۔
//!
//! ہم IEEE 754 فلوٹنگ پوائنٹ نمبر ڈھونڈتے ہیں جو اعشاریہ تار کی صحیح قدر کے قریب ہے۔
//! یہ بات مشہور ہے کہ بہت سارے اعشاریہ تار کی بنیاد دو میں اختتامی نمائندگی نہیں ہوتی ہے ، لہذا ہم آخری جگہ 0.5 یونٹ کی طرف چکر لگاتے ہیں (دوسرے لفظوں میں بھی ، اسی طرح ممکن ہے)۔
//! تعلقات ، دشمنی اقدار بالکل دو فلوٹ کے درمیان بالکل آدھے راستے کو ، آدھے سے شام تک کی حکمت عملی کے ساتھ حل کیا جاتا ہے ، جسے بینکر کی گول کاری بھی کہا جاتا ہے۔
//!
//! یہ کہنے کی ضرورت نہیں کہ یہ عمل درآمد کی پیچیدگی اور سی پی یو سائیکل کے معاملے میں بھی کافی مشکل ہے۔
//!
//! # Implementation
//!
//! پہلے ، ہم علامات کو نظرانداز کرتے ہیں۔یا بجائے ، ہم اسے تبادلوں کے عمل کے آغاز پر ہی ختم کردیتے ہیں اور اسے بالکل آخر میں دوبارہ لاگو کرتے ہیں۔
//! ZEedge0Z کے تمام معاملات میں یہ درست ہے چونکہ IEEE فلوٹس صفر کے آس پاس مطابقت رکھتے ہیں ، اس کی نفی کرتے ہوئے پہلا سا جھپٹ جاتا ہے۔
//!
//! پھر ہم خاکہ کو ایڈجسٹ کرکے اعشاریہ نکات کو ہٹاتے ہیں: تصور کے مطابق ، `12.34e56` `1234e54` میں بدل جاتا ہے ، جس کی وضاحت ہم ایک مثبت انٹیجر `f = 1234` اور ایک انٹیجر `e = 54` کے ساتھ کرتے ہیں۔
//! `(f, e)` نمائندگی تجزیہ مرحلے کے ماضی قریب کے تمام کوڈ کے ذریعہ استعمال ہوتی ہے۔
//!
//! اس کے بعد ہم مشین سائز کے انٹیجرز اور چھوٹے ، فکسڈ سائز فلوٹنگ پوائنٹ نمبر (پہلے `f32`/`f64` ، پھر 64 بٹ اہمیت والی ، `Fp` والی ایک قسم) کا استعمال کرتے ہوئے آہستہ آہستہ زیادہ عام اور مہنگے خصوصی مقدمات کی ایک لمبی سلسلہ آزماتے ہیں۔
//!
//! جب یہ سب ناکام ہوجاتے ہیں تو ، ہم گولی کاٹتے ہیں اور ایک آسان لیکن انتہائی سست الگورتھم کا سہارا لیتے ہیں جس میں `f * 10^e` کو مکمل طور پر کمپیوٹنگ کرنا اور بہترین اندازہ لگانے کے لئے ایک تکراری تلاش کرنا شامل ہے۔
//!
//! بنیادی طور پر ، یہ ماڈیول اور اس کے بچے مندرجہ ذیل بیان کردہ الگورتھم پر عمل درآمد کرتے ہیں:
//! "How to Read Floating Point Numbers Accurately" بذریعہ ولیم ڈی۔
//! کلینجر ، آن لائن دستیاب: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! اس کے علاوہ ، مددگار کے متعدد کام ہیں جو کاغذ میں استعمال ہوتے ہیں لیکن Rust (یا کم از کم بنیادی طور پر) میں دستیاب نہیں ہیں۔
//! ہمارا ورژن اضافی اور زیر بہاؤ کو سنبھالنے کی ضرورت اور معمولی نمبروں کو سنبھالنے کی خواہش سے بھی پیچیدہ ہے۔
//! بیلروفون اور الگورتھم آر کو اوور فلو ، سب نارمل اور انڈر فلو سے پریشانی ہے۔
//! آدانوں کے اہم خطے میں آنے سے پہلے ہی ہم قدامت پسندی سے الگورتھم ایم (کاغذ کے سیکشن 8 میں بیان کردہ ترمیم کے ساتھ) تبدیل ہوجاتے ہیں۔
//!
//! ایک اور پہلو جس پر توجہ دینے کی ضرورت ہے وہ ہے ``RawFloat`` trait جس کے ذریعہ تقریبا all تمام افعال پیرامیٹریائزڈ ہیں۔کسی کو لگتا ہے کہ یہ `f64` کی تجزیہ کرنے اور اس کا نتیجہ `f32` پر ڈالنے کے لئے کافی ہے۔
//! بدقسمتی سے یہ وہ دنیا نہیں ہے جس میں ہم رہتے ہیں ، اور اس کا اڈہ یا آدھے سے لے کر برابر گول کرنے کے ساتھ کوئی تعلق نہیں ہے۔
//!
//! مثال کے طور پر دو اقسام `d2` اور `d4` پر اعشاریے کی نمائندگی کرتے ہوئے دو اعشاریہ چار اعشاریہ اور چار اعشاریہ چار ہندسوں پر غور کریں اور "0.01499" کو ان پٹ کے طور پر لیں۔آؤٹ اپ راؤنڈنگ کا استعمال کریں۔
//! براہ راست دو اعشاریہ ہندسے میں جانے سے `0.01` ملتا ہے ، لیکن اگر ہم پہلے چار ہندسوں تک پہنچ جاتے ہیں تو ہمیں `0.0150` مل جاتا ہے ، جو اس کے بعد `0.02` تک ہوتا ہے۔
//! ایک ہی اصول دوسرے آپریشنوں پر بھی لاگو ہوتا ہے ، اگر آپ 0.5 ULP کی درستگی چاہتے ہیں تو آپ کو ایک ساتھ تمام تر کٹے ہوئے بٹس پر غور کرکے *سب کچھ* مکمل صحت سے متعلق اور گول * بالکل ٹھیک ایک بار کرنا چاہئے۔
//!
//! FIXME: اگرچہ کچھ کوڈ ڈپلیکیکشن ضروری ہے ، ممکن ہے کہ کوڈ کے کچھ حص suchوں کو اس طرح پھیر لیا جائے کہ کم کوڈ کی نقل ہو۔
//! الگورتھم کے بڑے حصے پیداوار کے لحاظ سے فلوٹ قسم سے آزاد ہیں ، یا صرف کچھ مستقل تک رسائی کی ضرورت ہے ، جس کو پیرامیٹرز کے طور پر منظور کیا جاسکتا ہے۔
//!
//! # Other
//!
//! تبادلوں میں کبھی بھی * panic نہیں ہونا چاہئے۔
//! کوڈ میں دعوے اور صریح panics موجود ہیں ، لیکن ان کو کبھی متحرک نہیں کیا جانا چاہئے اور صرف داخلی سینیٹ چیک کے طور پر کام کرنا چاہئے۔کسی بھی panics کو ایک بگ سمجھا جانا چاہئے۔
//!
//! یہاں یونٹ ٹیسٹ موجود ہیں لیکن وہ درستی کو یقینی بنانے میں بری طرح ناکافی ہیں ، وہ صرف ممکنہ غلطیوں کا تھوڑا سا حصہ پورا کرتے ہیں۔
//! ڈائریکٹری `src/etc/test-float-parse` میں Python اسکرپٹ کی حیثیت سے کہیں زیادہ وسیع ٹیسٹ موجود ہیں۔
//!
//! عددی حد سے زیادہ بہاؤ پر ایک نوٹ: اس فائل کے بہت سے حص partsے اعشاریے والے `e` کے ساتھ ریاضی کا مظاہرہ کرتے ہیں۔
//! بنیادی طور پر ، ہم اعشاریہ چاروں طرف منتقل کرتے ہیں: پہلے اعشاریے سے پہلے ، آخری اعشاریہ ہندسے کے بعد ، اور اسی طرح کی۔اگر بے احتیاطی سے کام کیا گیا تو یہ بہہ سکتا ہے۔
//! ہم صرف چھوٹی چھوٹی چھوٹی قیمتیں نکالنے کے لئے پارسنگ سبموڈول پر انحصار کرتے ہیں ، جہاں "sufficient" کا مطلب "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" ہے۔
//! بڑے نقصان دہندگان کو قبول کرلیا جاتا ہے ، لیکن ہم ان کے ساتھ ریاضی نہیں کرتے ہیں ، انہیں فورا. ہی {positive,negative} {zero,infinity} میں تبدیل کردیا جاتا ہے۔
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// ان دونوں کے اپنے ٹیسٹ ہیں۔
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// بیس 10 میں سٹرنگ کو فلوٹ میں بدلتا ہے۔
            /// ایک اختیاری اعشاریہ اخراج کو قبول کرتا ہے۔
            ///
            /// یہ فنکشن جیسے ڈور کو قبول کرتا ہے
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', یا مساوی طور پر ، '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', یا ، برابر ، '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// معروف اور پچھلے حص whے کی سفیدی ایک خامی کی نمائندگی کرتی ہے۔
            ///
            /// # Grammar
            ///
            /// مندرجہ ذیل [EBNF] گرامر پر عمل کرنے والے سارے تار کے نتیجے میں [`Ok`] واپس آجائے گا:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # معلوم کیڑے
            ///
            /// کچھ حالات میں ، کچھ تاریں جو درست فلوٹ تشکیل دیتی ہیں اس کی بجائے غلطی واپس کردیتی ہیں۔
            /// تفصیلات کے لئے [issue #31407] دیکھیں۔
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src ، ایک تار
            ///
            /// # واپسی کی قیمت
            ///
            /// `Err(ParseFloatError)` اگر سٹرنگ درست نمبر کی نمائندگی نہیں کرتی ہے۔
            /// بصورت دیگر ، `Ok(n)` جہاں `n` وہ تیرتا نقطہ نمبر ہے جس کی نمائندگی `src` کرتا ہے۔
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// ایک غلطی جو فلوٹ کی تجزیہ کرتے وقت واپس کی جاسکتی ہے۔
///
/// یہ غلطی [`f32`] اور [`f64`] کے لئے [`FromStr`] نفاذ کے لئے غلطی کی قسم کے بطور استعمال کی جاتی ہے۔
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// کسی اعشاریہ تار کو نشان اور باقی میں تقسیم کرتا ہے ، بقیہ معائنہ یا توثیق کے بغیر۔
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // اگر تار غلط ہے تو ہم کبھی بھی اس نشان کو استعمال نہیں کرتے ہیں ، لہذا ہمیں یہاں توثیق کرنے کی ضرورت نہیں ہے۔
        _ => (Sign::Positive, s),
    }
}

/// ایک اعشاریہ تار کو ایک فلوٹنگ پوائنٹ نمبر میں بدل دیتا ہے۔
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// اعشاریہ سے فلوٹ کے تبادلوں کے لئے اہم ورک ہورس: تمام پیشگی عمل کو آرکیسٹ کریں اور یہ معلوم کریں کہ کون سا الگورتھم کو اصل تبادلوں کرنا چاہئے۔
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift اعشاریے سے باہر
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 1280 بٹس تک محدود ہے ، جو تقریبا 385 اعشاریہ ہندسوں میں ترجمہ ہوتا ہے۔
    // اگر ہم اس سے تجاوز کرتے ہیں تو ، ہم کریش ہوجائیں گے ، لہذا ہم قریب ہونے سے پہلے ہی غلطی کرتے ہیں (10 ^ 10 کے اندر)۔
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // اب خاکہ یقینی طور پر 16 بٹ میں فٹ بیٹھتا ہے ، جو پورے الگورتھم میں استعمال ہوتا ہے۔
    let e = e as i16;
    // FIXME یہ حدود بلکہ قدامت پسند ہیں۔
    // بیلروفون کے ناکامی کے طریقوں کا زیادہ محتاط تجزیہ کرنے سے یہ زیادہ سے زیادہ معاملات میں بڑے پیمانے پر تیزرفتاری کے ل using استعمال کرنے کی اجازت مل سکتی ہے۔
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// جیسا کہ لکھا گیا ہے ، یہ بری طرح سے بہتر بناتا ہے (دیکھیں #27130 ، حالانکہ اس سے کوڈ کے پرانے ورژن کی طرف اشارہ ہوتا ہے)۔
// `inline(always)` اس کے لئے ایک کام ہے.
// مجموعی طور پر صرف دو کال سائٹس ہیں اور اس سے کوڈ کا سائز زیادہ خراب نہیں ہوتا ہے۔

/// جہاں ممکن ہو وہاں پٹی زیرو ، یہاں تک کہ جب اس میں اخراج کو تبدیل کرنے کی ضرورت ہو
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // ان زیرو کو تراشنا کچھ تبدیل نہیں کرتا لیکن تیز راہ (<15 ہندسوں) کو اہل بناتا ہے۔
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // فارم کی تعداد کو آسان بنائیں 0.0 ... x اور x ... 0.0 ، اس کے مطابق اخراج کو ایڈجسٹ کریں۔
    // یہ ہمیشہ جیت نہیں ہوسکتی ہے (ممکنہ طور پر کچھ نمبروں کو تیز راہ سے دور کردیتی ہے) ، لیکن یہ دوسرے حصوں کو نمایاں طور پر آسان بنا دیتا ہے (خاص طور پر ، قدر کی وسعت کے قریب)۔
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// دیئے گئے اعشاریے پر کام کرنے کے دوران الگورتھم آر اور الگورتھم M جو حساب دیں گے اس سب سے بڑی قدر کے (log10) سائز پر ایک تیز گندی اوپری حد کو لوٹاتا ہے۔
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // ہمیں یہاں trivial_cases() اور پارسر کا شکریہ کہ زیادہ فلو کے بارے میں زیادہ پریشان ہونے کی ضرورت نہیں ہے ، جو ہمارے لئے انتہائی ان پٹ کو فلٹر کرتے ہیں۔
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // معاملہ e>=0 میں ، دونوں الگورتھم کا حساب `f * 10^e` کے بارے میں ہے۔
        // الگورتھم آر اس کے ساتھ کچھ پیچیدہ حساب کتاب کرنے کے لئے آگے بڑھتا ہے لیکن ہم اوپری باؤنڈ کے لئے اس کو نظرانداز کرسکتے ہیں کیونکہ اس سے پہلے سے بھی حصہ کم ہوجاتا ہے ، لہذا ہمارے پاس اس میں کافی مقدار میں بفر موجود ہے۔
        //
        f_len + (e as u64)
    } else {
        // اگر e <0 ، الگورتھم R تقریبا ایک ہی کام کرتا ہے ، لیکن الگورتھم M مختلف ہے:
        // یہ مثبت نمبر K تلاش کرنے کی کوشش کرتا ہے جیسے `f << k / 10^e` ایک حد درجہ کی اہمیت رکھتا ہے۔
        // اس کے نتیجے میں تقریبا `2^53 *f* 10^e` <`10^17 *f* 10^e` ہوگا۔
        // ایک ان پٹ جو اس کو متحرک کرتا ہے وہ 0.33 ... 33 (375 x 3) ہے۔
        f_len + e.unsigned_abs() + 17
    }
}

/// اعشاریہ ہندسوں کو بھی دیکھے بغیر واضح اوور فلوز اور انڈر فلوز کا پتہ لگاتا ہے۔
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // وہاں زیرو تھے لیکن انہیں ایکس00 ایکس نے چھین لیا
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // یہ ceil(log10(the real value)) کا خام تخمینہ ہے۔
    // ہمیں یہاں بہاؤ کے بارے میں زیادہ پریشان ہونے کی ضرورت نہیں ہے کیونکہ ان پٹ کی لمبائی چھوٹی ہے (کم از کم 2 ^ 64 کے مقابلے میں) اور پارسر پہلے ہی خاکوں کو سنبھالتا ہے جس کی مطلق قیمت 10 ^ 18 سے زیادہ ہے (جو اب بھی 10 ^ 19 مختصر ہے 2 ^ 64)۔
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}