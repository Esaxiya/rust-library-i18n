//! مثبت آئی ای ای 754 فلوٹس پر بٹ ہلنا۔منفی نمبرات نہیں ہیں اور ان کو سنبھالنے کی ضرورت نہیں ہے۔
//! عمومی تیرتی نقطہ نمبر کی ایک عمومی نمائندگی ہوتی ہے جیسے (frac، exp) جیسا کہ قدر 2 <sup>Exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>))) ہے جہاں N بٹس کی تعداد ہے۔
//!
//! معمولی نوعیت قدرے مختلف اور عجیب ہوتی ہے ، لیکن یہی اصول لاگو ہوتا ہے۔
//!
//! یہاں ، تاہم ، ہم ان کی نمائندگی بطور (سگ ، کے) ایف مثبت کے ساتھ کرتے ہیں ، جیسے کہ قیمت *
//! 2 <sup>ای</sup> ."hidden bit" کو واضح کرنے کے علاوہ ، یہ نام نہاد مانٹیسا شفٹ کے ذریعہ اخراج کو بدل دیتا ہے۔
//!
//! ایک اور راستہ بتائیں ، عام طور پر فلوٹس کو (1) لکھا جاتا ہے لیکن یہاں وہ (2) کے طور پر لکھے گئے ہیں:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! ہم (1) کو **جزء کی نمائندگی** اور (2) کو **لازمی نمائندگی** کہتے ہیں۔
//!
//! اس ماڈیول میں بہت سے کام صرف عام تعداد کو سنبھالتے ہیں۔dec2flt معمولات بہت ہی چھوٹی اور بہت بڑی تعداد کے ل con عالمی سطح پر درست سست راہ (الگورتھم M) کو قدامت پسندی سے اختیار کرتے ہیں۔
//! اس الگورتھم کو صرف next_float() کی ضرورت ہے جو معمولی اور زیرو کو سنبھالتا ہے۔
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` اور `f64` کے بنیادی طور پر تمام تبادلوں کے کوڈ کی نقل سے بچنے کے لئے ایک مددگار trait
///
/// یہ ضروری کیوں ہے اس کے لئے والدین ماڈیول کا ڈاکٹر تبصرہ دیکھیں۔
///
/// کیا **کبھی نہیں** کبھی بھی دوسری اقسام کے لئے نافذ نہیں ہونا چاہئے یا ڈیک فلٹ ماڈیول سے باہر استعمال ہونا چاہئے۔
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` اور `from_bits` کے ذریعہ استعمال شدہ قسم۔
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// کسی عدد کو خام ترسیل پیش کرتا ہے۔
    fn to_bits(self) -> Self::Bits;

    /// کسی عدد سے خام ترسیل انجام دیتا ہے۔
    fn from_bits(v: Self::Bits) -> Self;

    /// اس زمرے میں آتا ہے جس میں یہ نمبر آتا ہے۔
    fn classify(self) -> FpCategory;

    /// منٹیسہ ، اخراج اور اشارے کے بطور دستخط لوٹاتا ہے۔
    fn integer_decode(self) -> (u64, i16, i8);

    /// فلوٹ کو ڈیکوڈ کریں۔
    fn unpack(self) -> Unpacked;

    /// چھوٹے چھوٹے عدد سے ذاتیات جن کی نمایندگی کی جاسکتی ہے۔
    /// Panic اگر اعداد کی نمائندگی نہیں کی جاسکتی ہے تو ، اس ماڈیول میں موجود دوسرے کوڈ کو کبھی بھی ایسا ہونے نہیں دینا یقینی بناتا ہے۔
    fn from_int(x: u64) -> Self;

    /// پہلے سے حساب والے ٹیبل سے 10 <sup>ای</sup> قدر ملتی ہے۔
    /// `e >= CEIL_LOG5_OF_MAX_SIG` کے لئے Panics۔
    fn short_fast_pow10(e: usize) -> Self;

    /// نام کیا کہتا ہے۔
    /// ہرن کوڈ میں آسانی سے آسان ہے جیسا کہ انٹگلکس کو لاگو کرنا اور LLVM کو مستحکم کرنے کی امید ہے۔
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // آلودگی کے اعشاری ہندسوں پر پابند ایک قدامت پسند جو اوور فلو یا صفر یا پیدا نہیں کرسکتا ہے
    /// معمولی چیزیں۔شاید زیادہ سے زیادہ عام قدر کا اعشاریہ اخراج ، لہذا نام۔
    const MAX_NORMAL_DIGITS: usize;

    /// جب سب سے اہم اعشاریہ اعداد کی ایک جگہ کی قیمت اس سے زیادہ ہوتی ہے تو ، یہ تعداد یقینی طور پر لامحدود ہوجاتی ہے۔
    ///
    const INF_CUTOFF: i64;

    /// جب انتہائی اہم اعشاریہ ہندسے کی جگہ کی قیمت اس سے کم ہوتی ہے تو ، یقینی طور پر یہ تعداد صفر تک ہوجاتی ہے۔
    ///
    const ZERO_CUTOFF: i64;

    /// خاکہ میں بٹس کی تعداد۔
    const EXP_BITS: u8;

    /// اہمیت میں بٹس کی تعداد ،*بشمول* پوشیدہ سا۔
    const SIG_BITS: u8;

    /// چھپی ہوئی بٹ کو چھوڑ کر * اہمیت میں بٹس کی تعداد۔
    const EXPLICIT_SIG_BITS: u8;

    /// جزوی نمائندگی میں زیادہ سے زیادہ قانونی نقصان دہندہ۔
    const MAX_EXP: i16;

    /// معمولی ترجیحات کو چھوڑ کر ، جزوی نمائندگی میں کم سے کم قانونی نقصان دہندہ۔
    const MIN_EXP: i16;

    /// `MAX_EXP` لازمی نمائندگی کے ل، ، یعنی شفٹ کا اطلاق ہوتا ہے۔
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` انکوڈ شدہ (یعنی آفسیٹ تعصب کے ساتھ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` لازمی نمائندگی کے ل، ، یعنی شفٹ کا اطلاق ہوتا ہے۔
    const MIN_EXP_INT: i16;

    /// لازمی نمائندگی میں زیادہ سے زیادہ معمول کی اہمیت۔
    const MAX_SIG: u64;

    /// لازمی نمائندگی میں کم سے کم معمولی اہمیت۔
    const MIN_SIG: u64;
}

// زیادہ تر #34344 کے لئے ایک مشقت.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// منٹیسہ ، اخراج اور اشارے کے بطور دستخط لوٹاتا ہے۔
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // متعصبانہ تعصب + مینٹیسا شفٹ
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe غیر یقینی ہے کہ آیا `as` صحیح طور پر تمام پلیٹ فارمز پر چکر لگاتا ہے۔
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// منٹیسہ ، اخراج اور اشارے کے بطور دستخط لوٹاتا ہے۔
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // متعصبانہ تعصب + مینٹیسا شفٹ
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe غیر یقینی ہے کہ آیا `as` صحیح طور پر تمام پلیٹ فارمز پر چکر لگاتا ہے۔
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// ایک `Fp` کو قریب ترین مشین فلوٹ کی قسم میں بدلتا ہے۔
/// غیر معمولی نتائج کو نہیں سنبھالتا ہے۔
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 بٹ ہے ، لہذا Xe میں 63 کی مینٹیسا شفٹ ہے
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// آدھے تا شام کے ساتھ T::SIG_BITS بٹس کے لئے 64 بٹ اہمیت کو گول بنائیں۔
/// اخراج کے بہاؤ کو نہیں سنبھالتا ہے
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // مینٹیسا شفٹ ایڈجسٹ کریں
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// عام کردہ نمبروں کیلئے `RawFloat::unpack()` کا الٹا۔
/// Panics اگر اہمیت دینے والی تعداد کے ل the اہمیت یا حامل درست نہیں ہے۔
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // پوشیدہ سا ہٹا دیں
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // خارجی تعصب اور مانٹیسا شفٹ کے ل for اخراج کو ایڈجسٹ کریں
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // سائن بٹ کو 0 ("+") پر چھوڑیں ، ہمارے نمبر تمام مثبت ہیں
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ایک غیر معمولی کی تعمیر.0 کے ایک مانٹیسہ کی اجازت ہے اور صفر کی تشکیل کرتا ہے۔
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // انکوڈ شدہ اخراج 0 ہے ، سائن بٹ 0 ہے ، لہذا ہمیں صرف بٹس کی دوبارہ وضاحت کرنا ہوگی۔
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ایک Fp کے ساتھ لگ بھگ ایک bignumنصف ٹو شام کے ساتھ 0.5 ULP کے اندر گول
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // ہم نے انڈیکس `start` سے پہلے تمام بٹس کاٹ ڈالے ہیں ، یعنی ہم `start` کی مقدار سے مؤثر طریقے سے رائٹ شفٹ کرلیتے ہیں ، لہذا یہ وہی خاکہ بھی ہے جس کی ہمیں ضرورت ہے۔
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // کٹے ہوئے بٹس پر منحصر گول (half-to-even)۔
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// دلیل سے سختی سے چھوٹا سب سے بڑا فلوٹنگ پوائنٹ نمبر تلاش کرتا ہے۔
/// معمولی حرارت ، صفر ، یا اخراج خسارے کو نہیں سنبھالتا ہے۔
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// دلیل سے سختی سے چھوٹا چھوٹا تیرتا نقطہ نمبر تلاش کریں۔
// یہ آپریشن سنورٹنگ ہے ، یعنی ، next_float(inf) ==inf۔
// اس ماڈیول میں زیادہ تر کوڈ کے برعکس ، اس فنکشن میں صفر ، غیر معمولی اور بدنامیوں کا سامنا ہے۔
// تاہم ، یہاں دوسرے تمام کوڈ کی طرح ، اس میں این اے این اور منفی نمبروں کا معاملہ نہیں ہوتا ہے۔
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // یہ سچ ثابت ہونا بہت اچھا لگتا ہے ، لیکن یہ کام کرتا ہے۔
        // 0.0 تمام صفر لفظ کی حیثیت سے انکوڈ کیا جاتا ہے۔معمولات 0x000m ... m ہیں جہاں M مینڈیسا ہے۔
        // خاص طور پر ، سب سے چھوٹا غیر معمولی 0x0 ... 01 اور سب سے بڑا 0x000F ... F ہے۔
        // سب سے چھوٹی عام نمبر 0x0010 ... 0 ہے ، لہذا یہ کارنر کیس بھی کام کرتا ہے۔
        // اگر انٹریمنٹ مینڈیسا سے زیادہ بہتی ہے تو ، کیری بٹ اخراجات کو بڑھاتا ہے جیسا کہ ہم چاہتے ہیں ، اور مانٹیسا بٹس صفر ہوجاتا ہے۔
        // پوشیدہ بٹ کنونشن کی وجہ سے ، یہ بھی بالکل وہی ہے جو ہم چاہتے ہیں!
        // آخر میں ، f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY۔
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}