//! کاغذ سے مختلف الگورتھم.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// ایف پی میں اہم بٹس کی تعداد
const P: u32 = 64;

// ہم صرف *تمام* اخراج کنندگان کے ل the بہترین تخمینہ ذخیرہ کرتے ہیں ، تاکہ متغیر "h" اور اس سے وابستہ حالات کو خارج کیا جاسکے۔
// یہ ایک جوڑے کلو بائٹ جگہ کی کارکردگی کا سودا کرتا ہے۔

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// زیادہ تر فن تعمیرات میں ، فلوٹنگ پوائنٹ آپریشن کا ایک واضح سا سائز ہوتا ہے ، لہذا کمپیوٹ کی درستگی کا تعین فی آپریشن کی بنیاد پر کیا جاتا ہے۔
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 پر ، x87 FPU فلوٹ کارروائیوں کے لئے استعمال کیا جاتا ہے اگر SSE/SSE2 ایکسٹینشن دستیاب نہیں ہیں۔
// x87 FPU پہلے سے طے شدہ 80 بٹس کے ساتھ کام کرتا ہے ، اس کا مطلب ہے کہ آپریشنز 80 بٹس تک چکر لگائیں گے جب ڈبل راؤنڈ ہونے کا سبب بنتا ہے جب اقدار کو بالآخر پیش کیا جاتا ہے
//
// 32/64 بٹ فلوٹ قدریںاس پر قابو پانے کے لئے ، ایف پی یو کنٹرول کا لفظ ترتیب دیا جاسکتا ہے تاکہ مطلوبہ صحت سے متعلق کمپیوٹرز انجام دیئے جائیں۔
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU کنٹرول لفظ کی اصل قدر کو محفوظ کرنے کے لئے استعمال ہونے والا ایک ڈھانچہ ، تاکہ جب ڈھانچہ ڈراپ ہوجائے تو اسے بحال کیا جاسکے۔
    ///
    ///
    /// ایکس00 ایکس ایف پی یو 16 بٹس رجسٹر ہے جس کے کھیت درج ذیل ہیں:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// تمام فیلڈز کے لئے دستاویزات IA-32 آرکیٹیکچر سافٹ ویئر ڈویلپر کے دستی (جلد 1) میں دستیاب ہے۔
    ///
    /// صرف فیلڈ جو درج ذیل کوڈ کے لئے متعلقہ ہے وہ پی سی ، پریسجن کنٹرول ہے۔
    /// یہ فیلڈ FPU کے ذریعہ انجام دی گئی کارروائیوں کی درستگی کا تعین کرتا ہے۔
    /// اس پر سیٹ کی جاسکتی ہے:
    ///  - 0b00 ، سنگل صحت سے متعلق یعنی 32 بٹس
    ///  - 0b10 ، ڈبل صحت سے متعلق یعنی 64 بٹس
    ///  - 0b11 ، ڈبل بڑھا ہوا صحت سے متعلق یعنی 80-بٹس (پہلے سے طے شدہ حالت) 0b01 قدر محفوظ ہے اور اسے استعمال نہیں کیا جانا چاہئے۔
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // محفوظ: `fldcw` کی ہدایت کا صحیح طریقے سے کام کرنے کے قابل ہونے کے لئے آڈٹ کیا گیا ہے
        // کوئی `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: ہم LLVM 8 اور LLVM 9 کی مدد کے لئے ATT نحو کا استعمال کر رہے ہیں۔
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU کے صحت سے متعلق فیلڈ کو `T` پر سیٹ کرتا ہے اور `FPUControlWord` واپس کرتا ہے۔
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // پریسجن کنٹرول فیلڈ کے ل the قدر کی گنتی کریں جو `T` کے لئے موزوں ہے۔
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 بٹس
            8 => 0x0200, // 64 بٹس
            _ => 0x0300, // پہلے سے طے شدہ ، 80 بٹس
        };

        // جب اسے `FPUControlWord` ڈھانچہ سلامت چھوڑ دیا جائے تو بعد میں اسے بحال کرنے کے ل control کنٹرول لفظ کی اصل قدر حاصل کریں: `fnstcw` ہدایات کا آڈٹ کیا گیا ہے تاکہ کسی بھی `u16` کے ساتھ صحیح طریقے سے کام کرنے کے قابل ہو۔
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: ہم LLVM 8 اور LLVM 9 کی مدد کے لئے ATT نحو کا استعمال کر رہے ہیں۔
                options(att_syntax, nostack),
            )
        }

        // کنٹرول لفظ مطلوبہ صحت سے متعلق پر مقرر کریں۔
        // یہ پرانے صحت سے متعلق (بٹس 8 اور 9 ، 0x300) کو نقاب پوش کرکے اور اس کی جگہ اوپر صحت سے متعلق پریسٹی پرچم لگا کر حاصل کیا گیا ہے۔
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// بیلجروفون کا تیز رفتار راستہ جس میں مشین کے سائز والے عددی عدد اور فلوٹس استعمال ہوں گے۔
///
/// یہ ایک علیحدہ فنکشن میں نکالا جاتا ہے تاکہ ایک بیگم بنانے سے پہلے اس کی کوشش کی جاسکے۔
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95
    // ہم قریب قریب MAX_SIG سے صحیح قدر کا موازنہ کرتے ہیں ، یہ صرف ایک تیز ، سستا مسترد ہے (اور باقی کوڈ کو بھی بہاو کی فکر کرنے سے آزاد کرتا ہے)۔
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // تیز رفتار راستہ کا ریاضی پر انحصار ہے جس میں بغیر کسی انٹرمیڈیٹ کے چکر لگائے بٹس کی صحیح تعداد میں گول کیا جا.۔
    // x86 پر (SSE یا SSE2 کے بغیر) x87 FPU اسٹیک کی صحت سے متعلق تبدیلی کی ضرورت ہوتی ہے تاکہ یہ براہ راست 64/32 بٹ پر چکر لگائے۔
    // `set_precision` فنکشن آرکیٹیکچر پر صحت سے متعلق ترتیب دینے کا خیال رکھتا ہے جس میں عالمی حالت (x87 FPU کے کنٹرول لفظ کی طرح) کو تبدیل کرکے اس کی ترتیب کی ضرورت ہوتی ہے۔
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // معاملہ e <0 دوسرے branch میں جوڑ نہیں سکتا۔
    // منفی قوتوں کے نتیجے میں بائنری میں اعادہ جزوی حصہ ہوتا ہے ، جو گول ہوجاتا ہے ، جو حتمی نتیجے میں حقیقی (اور کبھی کبھار خاصی اہم غلطیاں) کا سبب بنتا ہے۔
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// الگوریتم بیلروفون ایک چھوٹی سی کوڈ ہے جسے غیر معمولی عددی تجزیے کے ذریعہ جائز قرار دیا گیا ہے۔
///
/// یہ 64 بٹ اہمیت والے ایک فلوٹ پر ``f`` کا چکر لگاتا ہے اور اسے `10^e` (اسی فلوٹنگ پوائنٹ فارمیٹ میں) کے بہترین قریب سے ضرب دیتا ہے۔صحیح نتیجہ حاصل کرنے کے لئے یہ اکثر کافی ہوتا ہے۔
/// تاہم ، جب نتیجہ دو ملحقہ (ordinary) فلوٹس کے درمیان آدھے راستے کے قریب ہے تو ، دو قربت ضرب کرنے سے کمپاؤنڈ گول کرنے میں خرابی کا مطلب ہے کہ نتیجہ کچھ بٹس کے ذریعہ بند ہوسکتا ہے۔
/// جب ایسا ہوتا ہے تو ، تکرار الگورتھم R چیزوں کو ٹھیک کرتا ہے۔
///
/// کاغذ میں عددی تجزیے کے ذریعہ ہاتھ سے لہرائے جانے والا "close to halfway" عین مطابق بنایا گیا ہے۔
/// کلینجر کے الفاظ میں:
///
/// > کم سے کم اہم بٹ کی اکائیوں میں اظہار کیا گیا ڈھلوان ، غلطی کا ایک جامع پابند ہے
/// > f * 10 ^ e کے قریب کے تیرتے نقطہ حساب کے دوران جمع ہوتا ہے۔(ڈھلوان ہے)
/// > حقیقی غلطی کا پابند نہیں بلکہ قریب Z اور
/// > ممکنہ طور پر ممکنہ قریب سے جو پی بٹس کو اہمیت کا استعمال کرتا ہو۔)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) معاملات fast_path() میں ہیں
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // کیا ڈھال اتنی بڑی ہے کہ ن بٹس کو گول کرتے وقت فرق پڑ سکتا ہے؟
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// ایک تکراری الگورتھم جو `f * 10^e` کے تیرتے نقطہ کی تخمینہ کو بہتر بناتا ہے۔
///
/// ہر تکرار کو آخری جگہ پر ایک یونٹ مل جاتا ہے ، اگر `z0` ہلکے سے دور بھی ہو تو اس میں تبدیل ہونے میں کون سا بہت طویل وقت لگتا ہے۔
/// خوش قسمتی سے ، جب بیلروفون کے فال بیک کے طور پر استعمال ہوتا ہے تو ، شروعاتی قریب کی حد تک زیادہ تر ایک یو ایل پی بند ہوجاتا ہے۔
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x` ، `y` جیسے مثبت انٹیجرز تلاش کریں جیسے `x / y` بالکل `(f *10^e) / (m* 2^k)` ہے۔
        // یہ نہ صرف `e` اور `k` کی علامتوں سے نمٹنے سے گریز کرتا ہے ، بلکہ ہم تعداد کو چھوٹا بنانے کے لئے `10^e` اور `k` میں دو عام کی طاقت کو بھی ختم کردیتے ہیں۔
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // یہ تھوڑا سا عجیب و غریب تحریر سے لکھا گیا ہے کیونکہ ہمارے bignums منفی اعداد کی حمایت نہیں کرتے ہیں ، لہذا ہم مطلق قدر + نشان کی معلومات کا استعمال کرتے ہیں۔
        // ایم_ڈیجٹس کے ساتھ ضرب زیادہ بہاو نہیں ہوسکتا ہے۔
        // اگر `x` یا `y` اتنا بڑا ہے کہ ہمیں اوور فلو کے بارے میں فکر کرنے کی ضرورت ہے ، تو پھر وہ اتنے بڑے بھی ہیں کہ X X 2 ایکس نے 2 ^ 64 یا اس سے زیادہ کے عنصر کے ذریعہ فریکشن کو کم کردیا ہے۔
        //
        //
        let (d2, d_negative) = if x >= y {
            // مزید X کی ضرورت نہیں ، ایک clone() کو بچائیں۔
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // پھر بھی y کی ضرورت ہے ، ایک کاپی بنائیں۔
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` اور `y = m` دیئے گئے جہاں `f` معمول کے مطابق ان پٹ اعشاریہ ہندسوں کی نمائندگی کرتا ہے اور `m` ایک تیرتے نقطہ کے قریب ہونے کی اہمیت ہے ، `x / y` کو `(f *10^e) / (m* 2^k)` کے برابر تناسب بنائیں ، ممکنہ طور پر دونوں کی طاقت سے دونوں میں مشترک ہو۔
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e، y=m* 2 ^ k، سوائے اس کے کہ ہم دو کی طاقت سے اس حصے کو کم کردیں۔
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k)، y=m یہ اتپر فلو نہیں ہوسکتی ہے کیونکہ اس میں مثبت `e` اور منفی `k` کی ضرورت ہوتی ہے ، جو صرف 1 کے قریب قدر کے ل for ہوسکتا ہے ، جس کا مطلب ہے کہ `e` اور `k` نسبتا. چھوٹے ہوں گے۔
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f، y=m *10^abs(e)* 2 ^ k یہ بھی بہا نہیں سکتا ، اوپر دیکھیں۔
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k)، y=m* 10^abs(e)، دوبارہ دو کی مشترکہ طاقت کے ذریعہ کم کرنا۔
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// اعدادوشمار کو فلوٹ میں تبدیل کرنے کے لئے الگورتھم ایم آسان ترین طریقہ ہے۔
///
/// ہم ایک ایسا تناسب بناتے ہیں جو `f * 10^e` کے برابر ہے ، پھر دو کی طاقتوں میں ڈالتے ہیں یہاں تک کہ جب تک یہ درست فلوٹ کو اہمیت نہ دے۔
/// بائنری ایکسپونٹر `k` اس وقت کی تعداد ہے جس کو ہم نے دو یا ہندسے کو دو سے بڑھایا ، ہر وقت `f *10^e` `(u / v)* 2^k` کے برابر ہے۔
/// جب ہمیں اہمیت کا پتہ چل گیا تو ، ہمیں صرف ڈویژن کے باقی حصوں کا معائنہ کرکے گول کرنے کی ضرورت ہوتی ہے ، جو مزید نیچے مددگار افعال میں کیا جاتا ہے۔
///
///
/// یہ الگورتھم `quick_start()` میں بیان کردہ اصلاح کے باوجود بھی انتہائی سست ہے۔
/// تاہم ، بہاؤ ، زیر بہاؤ اور غیر معمولی نتائج کے ل ad ڈھلنے کے ل al الگورتھم کا یہ سب سے آسان ہے۔
/// جب بیلیلیروفون اور الگورتھم آر مغلوب ہو جاتے ہیں تو اس پر عمل درآمد ہوتا ہے۔
/// انڈر فلو اور اوور فلو کا پتہ لگانا آسان ہے: تناسب اب بھی حد درجہ اہمیت کا حامل نہیں ہے ، پھر بھی minimum/maximum اخراج کو پہنچ چکا ہے۔
/// زیادہ بہاؤ کی صورت میں ، ہم آسانی سے انفینٹی لوٹ جاتے ہیں۔
///
/// انڈر فلو اور سب معمولات کو سنبھالنا مشکل ہے۔
/// ایک بڑا مسئلہ یہ ہے کہ ، کم سے کم اخراج کے ساتھ ، تناسب اب بھی ایک اہمیت کے ل for بہت زیادہ ہوسکتا ہے۔
/// تفصیلات کے لئے underflow() دیکھیں۔
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME ممکنہ اصلاح: big_to_fp کو عام بنائیں تاکہ ہم صرف ڈبل راؤنڈنگ کے بغیر ، fp_to_float(big_to_fp(u)) کے برابر کام کرسکیں۔
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // ہمیں کم سے کم اخراج پر رکنا ہے ، اگر ہم `k < T::MIN_EXP_INT` تک انتظار کریں تو ہم دو عنصر سے دور ہوجائیں گے۔
            // بدقسمتی سے اس کا مطلب ہے کہ ہمیں کم سے کم خرچ کرنے والے کے ساتھ عام تعداد میں خصوصی تعداد رکھنا ہوگی۔
            // FIXME ایک زیادہ خوبصورت وضع تیار کریں ، لیکن یہ یقینی بنانے کے لئے `tiny-pow10` ٹیسٹ چلائیں کہ یہ واقعی صحیح ہے!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// تھوڑا سا لمبائی کی جانچ کرکے زیادہ تر الگورتھم ایم کے اعدادوشمار پر جائیں۔
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // تھوڑا سا لمبائی بیس ٹو لوگارڈم ، اور log(u / v) = log(u) ، log(v) کا تخمینہ ہے۔
    // تخمینہ زیادہ سے زیادہ 1 کے ذریعہ بند ہے ، لیکن ہمیشہ تخمینہ نہیں ہوتا ہے ، لہذا log(u) اور log(v) پر غلطی ایک ہی علامت کی ہے اور منسوخ ہوجاتی ہے (اگر دونوں بڑے ہیں)۔
    // لہذا log(u / v) کے لئے بھی غلطی زیادہ سے زیادہ ایک ہے۔
    // ہدف کا تناسب ایک ہے جہاں u/v ایک حد میں اہمیت کا حامل ہے۔اس طرح ہماری معطلی کی حالت log2(u / v) کی اہم بٹس ، plus/minus ایک ہے۔
    // FIXME دوسری بٹ کو دیکھنے سے اندازہ بہتر ہوسکتا ہے اور کچھ اور تقسیم سے بچ سکتا ہے۔
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // انڈر فلو یا غیر معمولی۔مرکزی تقریب پر چھوڑ دیں۔
            break;
        }
        if *k == T::MAX_EXP_INT {
            // اتپرواہ۔مرکزی تقریب پر چھوڑ دیں۔
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // تناسب کم سے کم اخراج کنندہ کے ساتھ کوئی حد درجہ کی اہمیت نہیں رکھتا ہے ، لہذا ہمیں ضرورت سے زیادہ بٹس کو دور کرنے اور اس کے مطابق اخراج کو ایڈجسٹ کرنے کی ضرورت ہے۔
    // اصل قدر اب اس طرح دکھائی دیتی ہے۔
    //
    //        x ایل ایس بی
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q ٹرنک۔(نمائندگی یاد)
    //
    // لہذا ، جب راؤنڈ آف بٹس ہیں!= 0.5 ULP ، تو وہ خود ہی راؤنڈنگ کا فیصلہ کرتے ہیں۔
    // جب وہ برابر ہوں اور بقیہ غیر صفر ہوں تو پھر بھی قیمت کو بڑھانا ضروری ہے۔
    // صرف اس صورت میں جب راؤنڈ آف بٹس 1/2 ہوں اور بقیہ صفر ہو تو ہمارے پاس آدھے سے برابر کی صورتحال ہوتی ہے۔
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// عام راؤنڈ ٹو بھی ، کسی ڈویژن کے باقی حصے کی بنیاد پر راؤنڈ ہونے سے پریشان ہوجاتا ہے۔
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}