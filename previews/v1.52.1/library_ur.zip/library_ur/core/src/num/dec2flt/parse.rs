//! فارم کے اعشاریہ تار کی توثیق اور اس کو گل کرنا:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! دوسرے الفاظ میں ، معیاری فلوٹنگ پوائنٹ نحو ، دو استثناء کے ساتھ: کوئی نشان نہیں ، اور "inf" اور "NaN" کا کوئی ہینڈلنگ نہیں۔یہ ڈرائیور فنکشن (super::dec2flt) کے ذریعہ سنبھالے جاتے ہیں۔
//!
//! اگرچہ درست آدانوں کو پہچاننا نسبتا easy آسان ہے ، اس ماڈیول کو لاتعداد غیرقانونی تغیرات ، کبھی بھی panic کو مسترد کرنے کی ضرورت نہیں ہے ، اور متعدد جانچ پڑتال کرنا ہے کہ دوسرے ماڈیولز بدلے میں panic (یا اوور فلو) پر انحصار نہیں کرتے ہیں۔
//!
//! معاملات کو مزید خراب کرنے کے لئے ، یہ سب کچھ ان پٹ کے ایک ہی پاس میں ہوتا ہے۔
//! لہذا ، کسی بھی چیز میں ترمیم کرتے وقت محتاط رہیں ، اور دوسرے ماڈیولز سے ڈبل چیک کریں۔
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// ایک اعشاریہ تار کے دلچسپ حصے۔
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// اعشاریہ اخراج ، جس کی ضمانت 18 اعشاریہ سے بھی کم ہندسوں کی ہے۔
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// چیک کرتا ہے کہ آیا ان پٹ سٹرنگ ایک درست فلوٹنگ پوائنٹ نمبر ہے اور اگر ایسا ہے تو ، لازمی حص ،ہ ، جزوی حصہ اور اس میں خاکہ تلاش کریں۔
/// اشارے نہیں سنبھالتے ہیں۔
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' سے پہلے کوئی ہندسے نہیں ہیں
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // ہمیں نقطہ سے پہلے یا بعد میں کم از کم ایک ہندسہ کی ضرورت ہوتی ہے۔
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // جزوی حص afterے کے بعد ردی کی ٹوکری
            }
        }
        _ => Invalid, // پہلا ہندسے کے بعد آنے والا ردی
    }
}

/// پہلے غیر ہندسے والے حرف تک اعشاریہ ہندسے تیار کرتا ہے۔
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// خاکہ نکالنے اور غلطی کی جانچ پڑتال۔
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // مسافر کے بعد چلنے والا ردی
    }
    if number.is_empty() {
        return Invalid; // خالی خالی
    }
    // اس وقت ، ہمارے پاس یقینی طور پر ہندسوں کی ایک درست تار موجود ہے۔ہوسکتا ہے کہ ایک `i64` میں رکھنا بہت لمبا ہو ، لیکن اگر یہ بہت زیادہ ہے تو ، ان پٹ یقینا zero صفر یا لامحدود ہے۔
    // چونکہ اعشاریہ ہندسے میں ہر صفر صرف اخراج کو +/-1 کے ذریعہ ایڈجسٹ کرتا ہے ، تو exp=10 at 18 میں ان پٹ کو حد سے دور ہونے کے قریب ہونے کے ل to ، 17 ایکسابائٹ (!) زیرو ہونا پڑے گا۔
    //
    // یہ بالکل استعمال کا معاملہ نہیں ہے جس کی ہمیں ضرورت ہے۔
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}