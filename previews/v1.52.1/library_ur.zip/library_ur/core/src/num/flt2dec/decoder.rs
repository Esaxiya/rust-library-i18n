//! فرش پوائنٹ پوائنٹ کی قیمت کو انفرادی حصوں اور غلطی کی حدوں میں ڈی کوڈ کرتے ہیں۔

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// کوڈ کوڈ پر دستخط شدہ محدود قیمت ، اس طرح:
///
/// - اصل قدر `mant * 2^exp` کے برابر ہے۔
///
/// - `(mant - minus)*2^exp` سے `(mant + plus)* 2^exp` تک کی کوئی بھی تعداد اصل قدر کے مطابق ہوگی۔
/// حد صرف اس وقت شامل ہے جب `inclusive` `true` ہے۔
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// تراکیب والا منٹیسا۔
    pub mant: u64,
    /// کم غلطی کی حد۔
    pub minus: u64,
    /// اوپری غلطی کی حد۔
    pub plus: u64,
    /// بیس 2 میں مشترکہ اشتعال انگیز
    pub exp: i16,
    /// غلطی کی حد بھی شامل ہونے پر درست ہے۔
    ///
    /// آئی ای ای ای 754 میں ، یہ سچ ہے جب اصلی مینٹیسا برابر تھا۔
    pub inclusive: bool,
}

/// غیر دستخط شدہ دستخط شدہ قدر
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// ناانصافی ، مثبت یا منفی۔
    Infinite,
    /// صفر ، مثبت یا منفی۔
    Zero,
    /// مزید ڈی کوڈ فیلڈز کے ساتھ محدود تعداد۔
    Finite(Decoded),
}

/// فلوٹنگ پوائنٹ کی قسم جو `ڈیکوڈیڈ ہوسکتی ہے۔
pub trait DecodableFloat: RawFloat + Copy {
    /// کم از کم مثبت معمول کی قیمت۔
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// دیئے ہوئے فلوٹنگ پوائنٹ نمبر سے ایک نشان (صحیح ہونے پر منفی) اور `FullDecoded` قدر لوٹاتا ہے۔
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // پڑوسی: (منٹ ، 2 ، میعاد)-(منٹ ، میعاد ختم)-(منٹ + 2 ، میعاد)
            // Float::integer_decode ہمیشہ اخراج کو محفوظ رکھتا ہے ، لہذا منتیسا معمولی معماروں کے لئے چھوٹی ہے۔
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // پڑوسیوں: (زیادہ سے زیادہ ، ایکسپریس ، 1)-(منسٹرمنٹ ، میعاد ختم ہوجانا)-(منینرمنٹ + 1 ، میعاد)
                // جہاں میکسمینٹ=مننرمنٹ * 2 ، 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // پڑوسی: (منٹ ، 1 ، میعاد ختم)-(منٹ ، میعاد ختم)-(منٹ + 1 ، میعاد)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}