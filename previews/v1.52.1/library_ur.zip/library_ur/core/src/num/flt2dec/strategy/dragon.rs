//! "پرنٹنگ فلوٹنگ پوائنٹ نمبرز جلدی اور درست طریقے سے" [^ 1] کے اعداد و شمار 3 کا Rust ترجمہ تقریبا direct براہ راست (لیکن قدرے بہتر)
//!
//!
//! [^1]: Burger, آر جی اور ڈیبویگ ، آر کے 1996۔ فلوٹنگ پوائنٹ نمبر پرنٹنگ
//!   جلدی اور درست طریقے سے۔سگنل نہیں۔31 ، 5 (مئی 1996) ، 108-116۔

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) کے لئے `ہندسوں کی precalculated arrays
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// صرف قابل استعمال جب `x < 16 * scale`؛`scaleN` `scale.mul_small(N)` ہونا چاہئے
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ڈریگن کے لئے مختصر ترین طریقہ پر عمل درآمد۔
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // نمبر `v` فارمیٹ کرنے کے لئے جانا جاتا ہے:
    // - `mant * 2^exp` کے برابر؛
    // - اصل قسم میں پہلے `(mant - 2 *minus)* 2^exp`؛اور
    // - اصل قسم میں `(mant + 2 *plus)* 2^exp` کے بعد۔
    //
    // ظاہر ہے ، `minus` اور `plus` صفر نہیں ہوسکتے ہیں۔(انفنٹیوں کے ل we ، ہم حد سے باہر کی اقدار کا استعمال کرتے ہیں۔) ہم یہ بھی فرض کرتے ہیں کہ کم از کم ایک ہندسہ تیار ہوتا ہے ، یعنی ، X01 بھی صفر نہیں ہوسکتا۔
    //
    // اس کا یہ مطلب بھی ہے کہ `low = (mant - minus)*2^exp` اور `high = (mant + plus)* 2^exp` کے درمیان کوئی بھی تعداد اس عین مطابق تیرتے نقطہ نمبر کا نقشہ بنائے گی ، جس میں حدیں شامل ہوں گی جب اصلی مینٹیسا برابر تھا (یعنی ، `!mant_was_odd`)۔
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` ہے
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` کو مطمئن کرنے والے اصل آدانوں سے `k_0` کا تخمینہ لگائیں۔
    // سخت پابند `k` قابل اطمینان `10^(k-1) < high <= 10^k` بعد میں حساب کیا جاتا ہے۔
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` کو جزوی شکل میں تبدیل کریں تاکہ:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` کو `10^k` سے تقسیم کریں۔اب `scale / 10 < mant + plus <= scale * 10`۔
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // جب فکس اپ `mant + plus > scale` (یا `>=`)۔
    // ہم دراصل `scale` میں ترمیم نہیں کر رہے ہیں ، کیونکہ ہم اس کے بجائے ابتدائی ضرب کو چھوڑ سکتے ہیں۔
    // اب `scale < mant + plus <= scale * 10` اور ہم ہندسے تیار کرنے کے لئے تیار ہیں۔
    //
    // نوٹ کریں کہ `d[0]`*جب*`scale - plus < mant < scale` ہو تو ، صفر ہوسکتا ہے۔
    // اس معاملے میں راؤنڈ اپ اپ کی حالت (نیچے `up`) کو فوری طور پر متحرک کردیا جائے گا۔
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // 10 کے ذریعہ `scale` اسکیل کرنے کے مترادف
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ڈیجیٹ نسل کے ل c کیشے `(2, 4, 8) * scale`۔
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // حملہ آور ، جہاں اب تک `d[0..n-1]` ہندسے بنائے گئے ہیں:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (اس طرح `mant / scale < 10`) جہاں `d[i..j]` `d [i] * 10 ^ (جی) + کے لئے مختصر ہے
        // + d [j-1] * 10 + d[j]`۔

        // ایک ہندسہ بنائیں: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // یہ ترمیم شدہ ڈریگن الگورتھم کی ایک آسان وضاحت ہے۔
        // بہت سارے انٹرمیڈیٹ مشتقات اور مکمل دلائل سہولت کے لit خارج کردیئے گئے ہیں۔
        //
        // ترمیم شدہ حملہ آوروں کے ساتھ شروع کریں ، جیسا کہ ہم نے `n` کو اپ ڈیٹ کیا ہے:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // فرض کریں کہ `d[0..n-1]` `low` اور `high` کے درمیان سب سے مختصر نمائندگی ہے ، یعنی ، `d[0..n-1]` درج ذیل میں سے دونوں کو مطمئن کرتا ہے لیکن `d[0..n-2]` ایسا نہیں کرتا ہے:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (دوہری سرگرمی: ہندسے تک `v` تک)؛اور
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (آخری ہندسہ درست ہے)
        //
        // دوسری حالت `2 * mant <= scale` پر آسان ہے۔
        // `mant` ، `low` اور `high` کے لحاظ سے حملہ آوروں کو حل کرنے سے پہلی شرط کا آسان ورژن ملتا ہے: `-plus < mant < minus`.
        // `-plus < 0 <= mant` کے بعد ، جب ہمارے پاس `mant < minus` اور `2 * mant <= scale` ہوتا ہے تو ہمارے پاس مختصر ترین نمائندگی ہوتی ہے۔
        // (جب اصلی مینٹیسا برابر ہو تو سابقہ `mant <= minus` ہوجاتا ہے۔)
        //
        // جب دوسرا پاس نہیں رکھتا (`2 * منٹ> اسکیل`) ، ہمیں آخری ہندسہ بڑھانے کی ضرورت ہے۔
        // اس حالت کی بحالی کے لئے یہ کافی ہے: ہم پہلے ہی جانتے ہیں کہ ہندسہ کی نسل `0 <= v / 10^(k-n) - d[0..n-1] < 1` کی ضمانت دیتا ہے۔
        // اس صورت میں ، پہلی شرط `-plus < mant - scale < minus` بن جاتی ہے۔
        // نسل کے بعد `mant < scale` کے بعد سے ، ہمارے پاس `scale < mant + plus` ہے۔
        // (ایک بار پھر ، یہ اصلی `scale <= mant + plus` ہو جاتا ہے جب اصلی مینٹیسا برابر ہو۔)
        //
        // مختصرا:
        // - جب `mant < minus` (یا `<=`) ہو تو `down` کو روکیں اور گول کریں۔
        // - جب `scale < mant + plus` (یا `<=`) ہو تو `up` (آخری ہندسے میں اضافہ کریں) کو روکیں اور گول کریں۔
        // - دوسری صورت میں پیدا کرتے رہیں۔
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ہماری مختصر نمائندگی ہے ، دور تک آگے بڑھیں

        // حملہ آوروں کو بحال کریں۔
        // یہ الگورتھم کو ہمیشہ ختم کرتا ہے: `minus` اور `plus` ہمیشہ بڑھتا رہتا ہے ، لیکن `mant` کلپ کیا ہوا موڈیولو `scale` ہے اور `scale` درست ہے۔
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // پکڑ دھکڑ اس وقت ہوتی ہے جب i) صرف راؤنڈ اپ کی حالت کو متحرک کیا گیا تھا ، یا II) دونوں ہی حالتیں متحرک ہو گئیں اور باندھ توڑنے کو ترجیح دیتی ہے۔
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // اگر پکڑ دھکڑ کی لمبائی میں تبدیلی آتی ہے تو ، خاکہ نگار کو بھی تبدیل ہونا چاہئے۔
        // ایسا لگتا ہے کہ اس حالت کو پورا کرنا بہت مشکل ہے (ممکنہ طور پر ناممکن) ، لیکن ہم یہاں صرف محفوظ اور مستقل مزاج ہیں۔
        //
        // حفاظت: ہم نے اس میموری کو اوپر شروع کیا۔
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // حفاظت: ہم نے اس میموری کو اوپر شروع کیا۔
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ڈریگن کے لئے قطعی اور فکسڈ وضع کا نفاذ۔
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` کو مطمئن کرنے والے اصل آدانوں سے `k_0` کا تخمینہ لگائیں۔
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` کو `10^k` سے تقسیم کریں۔اب `scale / 10 < mant <= scale * 10`۔
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // جب `mant + plus >= scale` ، جہاں `plus / scale = 10^-buf.len() / 2`۔
    // فکسڈ سائز bignum رکھنے کے لئے ، ہم اصل میں `mant + floor(plus) >= scale` استعمال کرتے ہیں۔
    // ہم دراصل `scale` میں ترمیم نہیں کر رہے ہیں ، کیونکہ ہم اس کے بجائے ابتدائی ضرب کو چھوڑ سکتے ہیں۔
    // ایک بار پھر مختصر ترین الگورتھم کے ساتھ ، `d[0]` صفر ہوسکتا ہے لیکن آخر میں اس کا مقابلہ ہوجائے گا۔
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // 10 کے ذریعہ `scale` اسکیل کرنے کے مترادف
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // اگر ہم آخری ہندسے کی حد کے ساتھ کام کر رہے ہیں تو ، ہمیں ڈبل راؤنڈنگ سے بچنے کے ل we اصل انجام دینے سے پہلے بفر کو مختصر کرنے کی ضرورت ہے۔
    //
    // نوٹ کریں کہ جب دور ہوتا ہے تو ہمیں دوبارہ بفر کو وسعت دینا پڑتا ہے!
    let mut len = if k < limit {
        // افوہ ، ہم *ایک* ہندسہ بھی پیدا نہیں کرسکتے ہیں۔
        // یہ تب ممکن ہے جب ، جب ہم کہتے ہیں کہ ہمارے پاس 9.5 جیسا کچھ مل گیا ہے اور اس کی گول 10 ہو جاتی ہے۔
        // ہم ایک خالی بفر واپس کرتے ہیں ، بعدازاں راؤنڈ اپ کیس کی رعایت کے ساتھ جو `k == limit` پر ہوتا ہے اور بالکل ایک ہندسہ تیار کرنا پڑتا ہے۔
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // ڈیجیٹ نسل کے ل c کیشے `(2, 4, 8) * scale`۔
        // (یہ مہنگا ہوسکتا ہے ، لہذا جب بفر خالی ہو تو ان کا حساب نہ لگائیں۔)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // مندرجہ ذیل ہندسے تمام زیرو ہیں ، ہم یہاں رک جاتے ہیں *گول کرنے کی کوشش نہیں کرتے*!بلکہ بقیہ ہندسے بھریں۔
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // حفاظت: ہم نے اس میموری کو اوپر شروع کیا۔
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // اگر ہم ہندسوں کے وسط میں رک جاتے ہیں تو درج ذیل ہندسے بالکل 5000 ہیں ، پہلے نمبر کو چیک کریں اور یہاں تک کہ گول کرنے کی کوشش کریں (یعنی ، جب پہلے کا ہندسہ برابر ہو تو پکڑنے سے گریز کریں)۔
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // محفوظ: `buf[len-1]` شروع کیا گیا ہے۔
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // اگر پکڑ دھکڑ کی لمبائی میں تبدیلی آتی ہے تو ، خاکہ نگار کو بھی تبدیل ہونا چاہئے۔
        // لیکن ہم سے اعداد کی ایک مقررہ تعداد کی درخواست کی گئی ہے ، لہذا بفر میں ردوبدل نہ کریں ...
        // حفاظت: ہم نے اس میموری کو اوپر شروع کیا۔
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... جب تک کہ اس کے بجائے ہم سے مقررہ صحت سے متعلق درخواست نہ کی جائے۔
            // ہمیں یہ بھی چیک کرنے کی ضرورت ہے ، اگر اصل بفر خالی تھا تو ، اضافی ہندسہ صرف اسی وقت شامل کیا جاسکتا ہے جب `k == limit` (edge کیس)۔
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // حفاظت: ہم نے اس میموری کو اوپر شروع کیا۔
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}