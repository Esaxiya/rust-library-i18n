//! مستحکم `f32` سنگل صحت سے متعلق فلوٹنگ پوائنٹ کی قسم۔
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` ذیلی ماڈیول میں ریاضی کے لحاظ سے اہم تعداد فراہم کی گئی ہے۔
//!
//! اس ماڈیول میں براہ راست وضاحت شدہ مستقلات کے لئے (جیسا کہ `consts` ذیلی ماڈیول میں بیان کردہ سے مختلف ہے) ، نئے کوڈ کے بجائے `f32` قسم پر براہ راست متعین متعلقہ مستقل کا استعمال کرنا چاہئے۔
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` کی داخلی نمائندگی کا رڈکس یا بنیاد۔
/// اس کے بجائے [`f32::RADIX`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ارادہ طریقہ
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// بیس 2 میں اہم ہندسوں کی تعداد۔
/// اس کے بجائے [`f32::MANTISSA_DIGITS`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ارادہ طریقہ
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// بیس 10 میں اہم ہندسوں کی اندازا number تعداد۔
/// اس کے بجائے [`f32::DIGITS`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ارادہ طریقہ
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` کی قدر۔
/// اس کے بجائے [`f32::EPSILON`] استعمال کریں۔
///
/// یہ ہی فرق ہے `1.0` اور اگلی بڑی نمائندہ تعداد میں۔
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ارادہ طریقہ
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// سب سے چھوٹی حد تک `f32` قدر۔
/// اس کے بجائے [`f32::MIN`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ارادہ طریقہ
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// سب سے چھوٹی مثبت نارمل `f32` قدر۔
/// اس کے بجائے [`f32::MIN_POSITIVE`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ارادہ طریقہ
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// سب سے بڑی حد تک `f32` قدر۔
/// اس کے بجائے [`f32::MAX`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ارادہ طریقہ
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// کم سے کم ممکنہ معمول کی طاقت سے زیادہ ایک
/// اس کے بجائے [`f32::MIN_EXP`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ارادہ طریقہ
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// زیادہ سے زیادہ ممکنہ طاقت 2 اخراج کنندہ۔
/// اس کے بجائے [`f32::MAX_EXP`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ارادہ طریقہ
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// کم سے کم ممکنہ معمولی طاقت 10 اخراج کنندہ کی۔
/// اس کے بجائے [`f32::MIN_10_EXP`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ارادہ طریقہ
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// زیادہ سے زیادہ 10 طاقت دینے والے کی طاقت
/// اس کے بجائے [`f32::MAX_10_EXP`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ارادہ طریقہ
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// ایک نمبر (NaN) نہیں۔
/// اس کے بجائے [`f32::NAN`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ارادہ طریقہ
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// انفینٹی (∞)۔
/// اس کے بجائے [`f32::INFINITY`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ارادہ طریقہ
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// منفی انفینٹی (−∞)۔
/// اس کے بجائے [`f32::NEG_INFINITY`] استعمال کریں۔
///
/// # Examples
///
/// ```rust
/// // فرسودہ طریقہ
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ارادہ طریقہ
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// بنیادی ریاضی کی مستقل مزاج۔
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath سے ریاضیاتی مستقل کی جگہ لے لیں۔

    /// آرکیڈیمز کا مستقل (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// مکمل دائرہ مستقل (τ)
    ///
    /// 2π کے برابر۔
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// ایلر کا نمبر (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` کی داخلی نمائندگی کا رڈکس یا بنیاد۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// بیس 2 میں اہم ہندسوں کی تعداد۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// بیس 10 میں اہم ہندسوں کی اندازا number تعداد۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` کی قدر۔
    ///
    /// یہ ہی فرق ہے `1.0` اور اگلی بڑی نمائندہ تعداد میں۔
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// سب سے چھوٹی حد تک `f32` قدر۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// سب سے چھوٹی مثبت نارمل `f32` قدر۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// سب سے بڑی حد تک `f32` قدر۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// کم سے کم ممکنہ معمول کی طاقت سے زیادہ ایک
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// زیادہ سے زیادہ ممکنہ طاقت 2 اخراج کنندہ۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// کم سے کم ممکنہ معمولی طاقت 10 اخراج کنندہ کی۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// زیادہ سے زیادہ 10 طاقت دینے والے کی طاقت
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// ایک نمبر (NaN) نہیں۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// انفینٹی (∞)۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// منفی انفینٹی (−∞)۔
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// اگر یہ قدر `NaN` ہے تو `true` لوٹاتا ہے۔
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` پورٹیبلٹی کے بارے میں خدشات کے سبب لائبکور میں عوامی طور پر دستیاب نہیں ہے ، لہذا یہ عمل داخلی طور پر نجی استعمال کے لئے ہے۔
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// اگر یہ قدر مثبت لامحدودیت یا منفی لامحدود ہے ، اور دوسری صورت میں `false` ہے تو `true` لوٹاتا ہے۔
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// اگر یہ نمبر نہ تو لامحدود ہے اور نہ ہی `NaN`۔
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN کو الگ سے سنبھالنے کی ضرورت نہیں ہے: اگر خود NaN ہے تو ، موازنہ بالکل اسی طرح مطلوبہ نہیں ہے۔
        //
        self.abs_private() < Self::INFINITY
    }

    /// اگر نمبر [subnormal] ہے تو `true` لوٹاتا ہے۔
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` اور `min` کے درمیان قدریں غیر معمولی ہیں۔
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// اگر نمبر نہ تو صفر ، لامحدود ، [subnormal] ، یا `NaN` نہیں ہے تو `true` واپس کرتا ہے۔
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` اور `min` کے درمیان قدریں غیر معمولی ہیں۔
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// نمبر کا تیرتا نقطہ زمرہ لوٹاتا ہے۔
    /// اگر صرف ایک ہی پراپرٹی کی جانچ کی جا رہی ہے تو ، اس کی بجائے مخصوص پیش گوئی کو استعمال کرنا عام طور پر تیز ہے۔
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// اگر `self` کے پاس ایک مثبت علامت ہے ، تو X01 ایکس لوٹاتا ہے ، بشمول `+0.0` ، sign NaN`s کے ساتھ مثبت سائن بٹ اور مثبت انفینٹی۔
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// اگر `self` میں منفی علامت ہے ، تو X01 ایکس لوٹائے گا ، بشمول `-0.0` ، negative NaN`s کے ساتھ منفی سائن بٹ اور منفی لامحدودیت۔
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // آئی ای ای 754 کہتے ہیں: isSignMinus(x) درست ہے اگر اور صرف اس صورت میں جب ایکس میں منفی علامت ہے۔
        // isSignMinus بھی صفر اور NaNs پر لاگو ہوتا ہے۔
        self.to_bits() & 0x8000_0000 != 0
    }

    /// ایک نمبر کا باہمی (inverse) لیتا ہے ، `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// ریڈیئنز کو ڈگری میں بدلتا ہے۔
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // بہتر صحت سے متعلق کے لئے ایک مستحکم استعمال کریں۔
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// ڈگری کو ریڈیوں میں بدلتا ہے۔
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// دو نمبروں میں سے زیادہ سے زیادہ لوٹاتا ہے۔
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// اگر ایک دلیل NaN ہے ، تو دوسری دلیل واپس کردی جاتی ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// کم سے کم دو نمبروں کو لوٹاتا ہے۔
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// اگر ایک دلیل NaN ہے ، تو دوسری دلیل واپس کردی جاتی ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// صفر کی طرف گول ہوتا ہے اور کسی بھی قدیم عددی قسم میں بدل جاتا ہے ، یہ فرض کرتے ہوئے کہ قدر محدود ہے اور اس قسم میں فٹ بیٹھتی ہے۔
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// قیمت ضروری ہے:
    ///
    /// * `NaN` نہیں ہونا چاہئے
    /// * لامحدود نہ ہو
    /// * `Int` کے اس کے جزوی حصے کو چھوٹنے کے بعد ، واپسی کی قسم `Int` میں نمایاں رہیں
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // محفوظ: کال کرنے والے کو `FloatToInt::to_int_unchecked` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` میں خام ترسیل۔
    ///
    /// یہ فی الحال تمام پلیٹ فارمز میں `transmute::<f32, u32>(self)` کی طرح ہے۔
    ///
    /// اس آپریشن کی پورٹیبلٹی کے بارے میں کچھ گفتگو کے لئے `from_bits` ملاحظہ کریں (تقریبا کوئی مسئلہ نہیں ہے)
    ///
    /// نوٹ کریں کہ یہ فنکشن `as` کاسٹنگ سے الگ ہے ، جو *عددی* قیمت ، نہ کہ بٹویس ویلیو کو محفوظ کرنے کی کوشش کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() معدنیات سے متعلق نہیں ہے!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // محفوظ: `u32` ایک سادہ پرانا ڈیٹا ٹائپ ہے لہذا ہم ہمیشہ اس میں منتقل کرسکتے ہیں
        unsafe { mem::transmute(self) }
    }

    /// `u32` سے خام ترسیل۔
    ///
    /// یہ فی الحال تمام پلیٹ فارمز میں `transmute::<u32, f32>(v)` کی طرح ہے۔
    /// معلوم ہوا کہ یہ ناقابل یقین حد تک قابل نقل ہے ، دو وجوہات کی بناء پر:
    ///
    /// * تمام تائید شدہ پلیٹ فارمز پر فلوٹس اور انٹس کا اختتام ایک جیسا ہے۔
    /// * آئی ای ای 754 انتہائی واضح طور پر فلوٹس کی تھوڑا سا ترتیب کو واضح کرتا ہے۔
    ///
    /// تاہم ، یہاں ایک انتباہی بات ہے: آئی ای ای-754 کے 2008 ورژن سے پہلے ، نین سگنلنگ بٹ کی تشریح کرنے کا طریقہ حقیقت میں بیان نہیں کیا گیا تھا۔
    /// زیادہ تر پلیٹ فارمز (خاص طور پر x86 اور ARM) نے اس تشریح کو منتخب کیا جو بالآخر 2008 میں معیاری قرار دیا گیا تھا ، لیکن کچھ نے (خاص طور پر MIP) نہیں کیا۔
    /// نتیجے کے طور پر ، MIPS پر تمام سگنلنگ این این x86 پر خاموش نین ہیں ، اور اس کے برعکس ہیں۔
    ///
    /// سگنلنگ-نیس کراس پلیٹ فارم کو محفوظ رکھنے کی کوشش کرنے کے بجائے ، یہ نفاذ عین مطابق بٹس کو محفوظ کرنے کے حق میں ہے۔
    /// اس کا مطلب یہ ہے کہ NaNs میں انکوڈ شدہ کسی بھی پے لوڈز کو محفوظ رکھا جائے گا یہاں تک کہ اگر اس طریقہ کار کا نتیجہ نیٹ ورک پر ایک x86 مشین سے MIPS پر بھیجا جائے۔
    ///
    ///
    /// اگر اس طریقہ کار کے نتائج صرف اسی فن تعمیر کے ذریعہ ہی جوڑ پائے جاتے ہیں جس نے انہیں تیار کیا ہے ، تو پھر اس میں پورٹیبلٹی کا کوئی خدشہ نہیں ہے۔
    ///
    /// اگر ان پٹ NaN نہیں ہے ، تو پھر پورٹیبلٹی کی کوئی تشویش نہیں ہے۔
    ///
    /// اگر آپ سگنلنگ (بہت امکان) کے بارے میں پرواہ نہیں کرتے ہیں ، تو پھر پورٹیبلٹی کی کوئی تشویش نہیں ہے۔
    ///
    /// نوٹ کریں کہ یہ فنکشن `as` کاسٹنگ سے الگ ہے ، جو *عددی* قیمت ، نہ کہ بٹویس ویلیو کو محفوظ کرنے کی کوشش کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // محفوظ: `u32` ایک سادہ پرانا ڈیٹا ٹائپ ہے لہذا ہم ہمیشہ اس سے ٹرانسمیٹ کرسکتے ہیں
        // اس سے پتہ چلتا ہے کہ sNaN کے ساتھ حفاظت کے معاملات دبے ہوئے تھے!ہورے!
        unsafe { mem::transmute(v) }
    }

    /// بگ اینڈین (network) بائٹ آرڈر میں بطور صف کے بطور اس تیرتے پوائنٹ نمبر کی میموری نمائندگی واپس کریں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// اس فلوٹنگ پوائنٹ نمبر کی میموری نمائندگی کو بطور سرے بطور چھوٹی اینڈین بائٹ ترتیب میں واپس کریں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// اس فلوٹنگ پوائنٹ نمبر کی میموری نمائندگی بائیٹ صف کے بطور دیسی بائٹ آرڈر میں واپس کریں۔
    ///
    /// چونکہ ہدف پلیٹ فارم کی آبائی خاتمہ استعمال ہوتا ہے ، لہذا ، پورٹیبل کوڈ کو [`to_be_bytes`] یا [`to_le_bytes`] استعمال کرنا چاہئے ، بجا as مناسب۔
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// اس فلوٹنگ پوائنٹ نمبر کی میموری نمائندگی بائیٹ صف کے بطور دیسی بائٹ آرڈر میں واپس کریں۔
    ///
    ///
    /// [`to_ne_bytes`] جب بھی ممکن ہو اس پر ترجیح دی جانی چاہئے۔
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // محفوظ: `f32` ایک سادہ پرانا ڈیٹا ٹائپ ہے لہذا ہم ہمیشہ اس میں منتقل کرسکتے ہیں
        unsafe { &*(self as *const Self as *const _) }
    }

    /// بگ اینڈین میں بائٹ سرنی کی حیثیت سے اس کی نمائندگی سے فلوٹنگ پوائنٹ ویلیو بنائیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// تھوڑا اینڈیان میں بائٹ سرنی کی حیثیت سے اس کی نمائندگی سے فلوٹنگ پوائنٹ ویلیو بنائیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// آبائی اینڈین میں بائٹ سرنی کی حیثیت سے اس کی نمائندگی سے ایک فلوٹنگ پوائنٹ ویلیو بنائیں۔
    ///
    /// چونکہ ہدف پلیٹ فارم کی آبائی خاتمہ استعمال ہوتا ہے ، لہذا پورٹیبل کوڈ ممکنہ طور پر مناسب طور پر [`from_be_bytes`] یا [`from_le_bytes`] استعمال کرنا چاہتا ہے۔
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// خود اور دیگر اقدار کے درمیان آرڈر لوٹاتا ہے۔
    /// فلوٹنگ پوائنٹ نمبر کے مابین معیاری جزوی موازنہ کے برخلاف ، یہ موازنہ ہمیشہ کل آرڈر پیشکیٹ کے مطابق آرڈر تیار کرتا ہے جیسا کہ IEEE 754 (2008 نظرثانی) فلوٹنگ پوائنٹ اسٹینڈرڈ میں بیان کیا گیا ہے۔
    /// اقدار کو درج ذیل ترتیب میں ترتیب دیا گیا ہے۔
    /// - منفی خاموش این این
    /// - منفی سگنلنگ این این
    /// - منفی لامحدودیت
    /// - منفی نمبر
    /// - منفی معمولی نمبر
    /// - منفی صفر
    /// - مثبت صفر
    /// - مثبت معمولی نمبر
    /// - مثبت نمبر
    /// - مثبت لامحدودیت
    /// - مثبت سگنلنگ این این
    /// - مثبت خاموش این این
    ///
    /// نوٹ کریں کہ یہ فنکشن `f32` کے [`PartialOrd`] اور [`PartialEq`] نفاذ کے ساتھ ہمیشہ اتفاق نہیں کرتا ہے۔خاص طور پر ، وہ منفی اور مثبت صفر کو برابر کے برابر سمجھتے ہیں ، جبکہ `total_cmp` ایسا نہیں کرتا ہے۔
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // منفی کی صورت میں ، علامت کے سوا تمام بٹس پلٹائیں جس طرح دو کے تکمیل والے عدد کے ساتھ ملتی جلتی ترتیب حاصل کریں
        //
        // یہ کام کیوں کرتا ہے؟آئی ای ای ای 754 فلوٹس میں تین فیلڈز شامل ہیں:
        // سائن بٹ ، کفیل اور مانٹیسا۔مجموعی طور پر کھیتی والے اور مینٹیسا فیلڈوں کے سیٹ میں یہ خاصیت ہوتی ہے کہ ان کا بٹ سائڈ آرڈر عددی پیمائش کے برابر ہے جہاں طول و عرض کی وضاحت کی گئی ہے۔
        // عمومی طور پر NaN کی اقدار پر تعریف نہیں کی جاتی ہے ، لیکن IEEE 754 ٹوٹل آرڈر نے NN کی اقدار کی وضاحت بھی کی ہے تاکہ بٹ وائی آرڈر پر عمل کیا جاسکے۔اس سے ڈاکٹر کے تبصرے میں بیان کردہ آرڈر ہوتا ہے۔
        // تاہم ، منفی اور مثبت تعداد کے لئے وسعت کی نمائندگی یکساں ہے-صرف سائن بٹ الگ ہے۔
        // فلوٹس کو آسانی سے دستخط شدہ عدد کے ساتھ موازنہ کرنے کے ل we ، ہمیں منفی اعداد کی صورت میں خاکہ اور مانٹیسا بٹس کو پلٹائیں گے۔
        // ہم تعداد کو مؤثر طریقے سے "two's complement" فارم میں تبدیل کرتے ہیں۔
        //
        // پلٹائیں کرنے کے ل we ، ہم اس کے خلاف ماسک اور XOR بناتے ہیں۔
        // ہم شاخوں کے بغیر منفی دستخط شدہ اقدار سے ایک "all-ones except for the sign bit" ماسک کا حساب لگاتے ہیں: دائیں شفٹنگ سے عدد میں توسیع ہوتی ہے ، لہذا ہم ماسک کو X بکس کے ساتھ ایکس بکس دیتے ہیں ، اور پھر ایک اور صفر بٹ کو آگے بڑھانے کے لئے دستخط شدہ میں تبدیل ہوجاتے ہیں۔
        //
        // مثبت اقدار پر ، نقاب پوش تمام صفر ہے ، لہذا یہ آپٹ نہیں ہے۔
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// کسی خاص وقفے تک کسی قدر کو محدود رکھیں جب تک کہ وہ این اے این نہ ہو۔
    ///
    /// اگر `self` `max` سے زیادہ ہے تو `max` ، اور اگر `self` `min` سے کم ہے تو `max` لوٹاتا ہے۔
    /// بصورت دیگر یہ `self` لوٹاتا ہے۔
    ///
    /// نوٹ کریں کہ اگر یہ ابتدائی قیمت بھی NaN تھی تو یہ فنکشن NaN کو لوٹاتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر `min > max` ، `min` NaN ہے ، یا `max` NaN ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}