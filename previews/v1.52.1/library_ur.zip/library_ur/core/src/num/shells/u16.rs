//! مستقل طور پر 16 بٹ کے بغیر دستخط کیے ہوئے عدد اعداد کی قسم۔
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! نیا کوڈ براہ راست ابتدائی نوعیت سے متعلقہ مستقل استعمال کرے۔

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }