//! 8 بٹ پر دستخط شدہ عددی قسم کے مستقل۔
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! نیا کوڈ براہ راست ابتدائی نوعیت سے متعلقہ مستقل استعمال کرے۔

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }