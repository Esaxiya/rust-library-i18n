//! اشارے کے سائز پر دستخط کامل عددی قسم کیلئے مستقل۔
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! نیا کوڈ براہ راست ابتدائی نوعیت سے متعلقہ مستقل استعمال کرے۔

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }