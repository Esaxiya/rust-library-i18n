//! لازمی اقسام میں تبدیلی کے ل Error غلطی کی اقسام۔

use crate::convert::Infallible;
use crate::fmt;

/// غلطی کی قسم اس وقت لوٹائی گئی جب ایک چیک انٹیبل قسم کی تبدیلی میں ناکام ہوجاتا ہے۔
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // جبرو `From<Infallible> for TryFromIntError` جیسے `!` کا عرف بن جاتا ہے تو `From<Infallible> for TryFromIntError` جیسا کوڈ کام کرتا رہے گا اس بات کو یقینی بنانے کے لئے مجبور کرنے کے بجائے میچ۔
        //
        //
        match never {}
    }
}

/// ایک غلطی جو عدد کو پارس کرتے وقت واپس آسکتی ہے۔
///
/// اس غلطی کو `from_str_radix()` افعال کے لئے [`i8::from_str_radix`] جیسے بنیادی انٹیجر قسموں میں غلطی کی قسم کے طور پر استعمال کیا جاتا ہے۔
///
/// # ممکنہ اسباب
///
/// دیگر وجوہات میں ، `ParseIntError` کو اسٹرنگ میں مثال کے طور پر ، جب یہ معیاری ان پٹ سے حاصل کیا جاتا ہے تو وہائٹ اسپیس کو معروف یا پیچھے چھوڑنے کی وجہ سے پھینک سکتا ہے۔
///
/// [`str::trim()`] طریقہ کا استعمال یقینی بناتا ہے کہ پارس کرنے سے پہلے کوئی خالی جگہ باقی نہ رہے۔
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// انوم کو مختلف اقسام کی غلطیوں کو ذخیرہ کرنے کے ل that جو عدد کو پارس کرنا ناکام بن سکتے ہیں۔
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// تجزیہ کی جانے والی قیمت خالی ہے۔
    ///
    /// دیگر وجوہات میں سے ، اس خاکہ کو خالی تار کی تجزیہ کرتے وقت تعمیر کیا جائے گا۔
    Empty,
    /// اس کے سیاق و سباق میں ایک غلط ہندسہ ہے۔
    ///
    /// دیگر وجوہات میں ، اس طرح کی تاروں کو پارکس کرتے وقت تعمیر کیا جائے گا جس میں غیر ASCII چار ہے۔
    ///
    /// جب یہ ایک `+` یا `-` اپنی طرف سے یا کسی عدد کے وسط میں کسی تار کے اندر غلط جگہ پر جاتا ہے تو یہ مختلف شکل بھی تیار کی جاتی ہے۔
    ///
    ///
    InvalidDigit,
    /// ہدف عددی قسم میں ذخیرہ کرنے کے لئے انٹیجر بہت بڑا ہے۔
    PosOverflow,
    /// ہدف عددی قسم میں ذخیرہ کرنے کے لئے انٹیجر بہت چھوٹا ہے۔
    NegOverflow,
    /// قدر زیرو تھی
    ///
    /// یہ مختلف حالت خارج ہوگی جب پارس کرنے والے تار کی قدر صفر ہوجاتی ہے ، جو غیر صفر اقسام کے لئے غیر قانونی ہوگی۔
    ///
    Zero,
}

impl ParseIntError {
    /// انٹریجر کے ناکام ہونے کی تفصیلی وجوہ کا پتہ لگاتا ہے۔
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}