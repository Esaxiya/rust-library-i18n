//! اقسام کے مابین تبادلوں کیلئے Traits۔
//!
//! اس ماڈیول میں traits ایک قسم سے دوسری قسم میں تبدیل کرنے کا ایک طریقہ فراہم کرتا ہے۔
//! ہر trait مختلف مقصد کے لئے کام کرتا ہے:
//!
//! - سستے حوالہ سے حوالہ تبادلوں کے ل the [`AsRef`] trait نافذ کریں
//! - سستے بدل پزیر سے بدلے جانے والے تبادلوں کیلئے [`AsMut`] trait نافذ کریں
//! - قدر سے قیمت میں تبادلوں کے ل for [`From`] trait نافذ کریں
//! - موجودہ crate سے باہر اقسام میں قدر سے قیمت میں تبادلوں کے ل for [`Into`] trait نافذ کریں۔
//! - [`TryFrom`] اور [`TryInto`] traits [`From`] اور [`Into`] کی طرح برتاؤ کرتا ہے ، لیکن اس پر عمل درآمد کیا جانا چاہئے جب تبادلہ ناکام ہوسکتا ہے۔
//!
//! اس ماڈیول میں traits اکثر عام کاموں کے لئے trait bounds کے بطور استعمال ہوتا ہے جیسے متعدد اقسام کے دلائل کی حمایت کی جاتی ہے۔مثال کے طور پر ہر trait کی دستاویزات دیکھیں۔
//!
//! لائبریری مصنف کی حیثیت سے ، آپ کو ہمیشہ [`From<T>`][`From`] یا [`TryFrom<T>`][`TryFrom`] کو [`Into<U>`][`Into`] یا [`TryInto<U>`][`TryInto`] کے بجائے نفاذ کو ترجیح دینی چاہئے ، کیونکہ [`From`] اور [`TryFrom`] زیادہ سے زیادہ لچک فراہم کرتے ہیں اور معیاری لائبریری میں ایک کمبل کے نفاذ کے بدولت ، مفت میں [`Into`] یا [`TryInto`] کے مساوی طور پر پیش کرتے ہیں۔
//! جب Rust 1.41 سے پہلے کسی ورژن کو نشانہ بناتے ہو تو ، موجودہ crate سے باہر کسی قسم میں تبدیل کرتے وقت [`Into`] یا [`TryInto`] کو براہ راست لاگو کرنا ضروری ہوسکتا ہے۔
//!
//! # عام عمل
//!
//! - [`AsRef`] اور اگر داخلی قسم کا حوالہ ہو تو [`AsMut`] آٹو ڈیریکرنس
//! - [`منجمد]` <U>کے لئے T`کا مطلب [`In``]` ہے</u><T><U>U` کے لئے</u>
//! - [`TryFrom`]`<U>T` کا مطلب ہے [`TryInto`]`</u><T><U>U` کے لئے</u>
//! - [`From`] اور [`Into`] اضطراری ہیں ، اس کا مطلب ہے کہ تمام اقسام خود `into` اور خود `from` کرسکتی ہیں
//!
//! استعمال کی مثالوں کے ل each ہر trait دیکھیں۔
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// شناختی فنکشن۔
///
/// اس فنکشن کے بارے میں دو چیزیں نوٹ کرنا ضروری ہیں۔
///
/// - یہ ہمیشہ `|x| x` جیسے بندش کے مترادف نہیں ہے ، کیونکہ بندش `x` کو ایک مختلف قسم میں مجبور کر سکتی ہے۔
///
/// - یہ ان پٹ کو `x` فنکشن میں منتقل کرتا ہے۔
///
/// اگرچہ ایسا فعل ہونا عجیب معلوم ہوسکتا ہے جو صرف ان پٹ کو لوٹاتا ہے ، لیکن اس کے کچھ دلچسپ استعمال ہیں۔
///
///
/// # Examples
///
/// دوسرے ، دلچسپ ، افعال کی ترتیب میں کچھ نہیں کرنے کے لئے `identity` کا استعمال کرنا:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // آئیے یہ دکھاوا کرتے ہیں کہ ایک شامل کرنا ایک دلچسپ فنکشن ہے۔
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// مشروط میں `identity` کو بطور "do nothing" بیس کیس استعمال کرنا:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // مزید دلچسپ چیزیں کریں ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` کے ایٹریٹر کے `Some` مختلف حالتوں کو برقرار رکھنے کے لئے `identity` کا استعمال:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// ایک ارزاں حوالہ سے حوالہ کی تبدیلی کرنے کے لئے استعمال ہوتا ہے۔
///
/// یہ trait [`AsMut`] کی طرح ہے جو تغیر پزیر حوالوں کے مابین تبدیل کرنے کے لئے استعمال ہوتا ہے۔
/// اگر آپ کو مہنگا تبادلہ کرنے کی ضرورت ہے تو یہ بہتر ہے کہ [`From`] کو `&T` کی قسم سے نافذ کریں یا اپنی مرضی کے مطابق فنکشن لکھیں۔
///
/// `AsRef` [`Borrow`] جیسا ہی دستخط ہے ، لیکن [`Borrow`] چند پہلوؤں میں مختلف ہے:
///
/// - `AsRef` کے برعکس ، [`Borrow`] میں کسی بھی `T` کے لئے کمبل امپیل ہوتا ہے ، اور اسے حوالہ یا قدر قبول کرنے کے لئے استعمال کیا جاسکتا ہے۔
/// - [`Borrow`] یہ بھی ضروری ہے کہ [`Hash`] ، [`Eq`] اور [`Ord`] ادھار قدر کے مالکانہ قیمت کے برابر ہوں۔
/// اس وجہ سے ، اگر آپ کسی ڈھانچے کے صرف ایک فیلڈ پر قرض لینا چاہتے ہیں تو آپ `AsRef` لاگو کرسکتے ہیں ، لیکن [`Borrow`] نہیں۔
///
/// **Note: اس trait میں ** ناکام نہیں ہونا چاہئے۔اگر تبادلہ ناکام ہوسکتا ہے تو ، ایک سرشار طریقہ استعمال کریں جو [`Option<T>`] یا [`Result<T, E>`] واپس کرے۔
///
/// # عام عمل
///
/// - `AsRef` اگر داخلی نوعیت کا حوالہ یا تبدیل شدہ حوالہ ہو تو آٹو ڈیریکرنس (جیسے: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds استعمال کرکے ہم اس وقت تک مختلف اقسام کے دلائل قبول کرسکتے ہیں جب تک کہ وہ مخصوص قسم `T` میں تبدیل ہوجائیں۔
///
/// مثال کے طور پر: ایک ایسی عام تقریب تشکیل دے کر جو ایک `AsRef<str>` لے لیتا ہے ہم اس بات کا اظہار کرتے ہیں کہ ہم ان تمام حوالوں کو قبول کرنا چاہتے ہیں جن کو [`&str`] میں بطور دلیل تبدیل کیا جاسکتا ہے۔
/// چونکہ [`String`] اور [`&str`] دونوں `AsRef<str>` کو لاگو کرتے ہیں ہم ان پٹ دلیل کے طور پر دونوں کو قبول کرسکتے ہیں۔
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// تبادلوں کو انجام دیتا ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// ایک سستے سے بدلاؤ سے بدل پانے والے حوالہ کی تبدیلی کے ل to استعمال ہوتا ہے۔
///
/// یہ trait [`AsRef`] کی طرح ہے لیکن متغیر حوالوں کے مابین تبدیل کرنے کے لئے استعمال ہوتا ہے۔
/// اگر آپ کو مہنگا تبادلہ کرنے کی ضرورت ہے تو یہ بہتر ہے کہ [`From`] کو `&mut T` کی قسم سے نافذ کریں یا اپنی مرضی کے مطابق فنکشن لکھیں۔
///
/// **Note: اس trait میں ** ناکام نہیں ہونا چاہئے۔اگر تبادلہ ناکام ہوسکتا ہے تو ، ایک سرشار طریقہ استعمال کریں جو [`Option<T>`] یا [`Result<T, E>`] واپس کرے۔
///
/// # عام عمل
///
/// - `AsMut` اگر داخلی قسم ایک متغیر حوالہ ہو تو آٹو ڈیریکرنس (جیسے: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// `AsMut` کو بطور trait bound استعمال کرتے ہوئے عام فعل کے ل we ہم ان تمام متغیر حوالہ جات کو قبول کرسکتے ہیں جن کو `&mut T` ٹائپ میں تبدیل کیا جاسکتا ہے۔
/// چونکہ [`Box<T>`] `AsMut<T>` کو لاگو کرتا ہے ہم ایک فنکشن `add_one` لکھ سکتے ہیں جس میں تمام دلائل لیئے جاتے ہیں جن کو `&mut u64` میں تبدیل کیا جاسکتا ہے۔
/// چونکہ [`Box<T>`] `AsMut<T>` لاگو کرتا ہے ، `add_one` `&mut Box<u64>` قسم کے دلائل کو بھی قبول کرتا ہے۔
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// تبادلوں کو انجام دیتا ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// ایک قدر سے قدر میں تبادلہ جو ان پٹ ویلیو کو کھاتا ہے۔[`From`] کے برعکس۔
///
/// کسی کو [`Into`] کے نفاذ سے گریز کرنا چاہئے اور اس کی بجائے [`From`] کو لاگو کرنا چاہئے۔
/// [`From`] کو لاگو کرنا معیاری لائبریری میں کمبل کے نفاذ کے ل X خود بخود [`Into`] پر عمل درآمد فراہم کرتا ہے۔
///
/// [`Into`] پر [`Into`] استعمال کرنے کو ترجیح دیں جب trait bounds کو عمومی فنکشن پر بتاتے ہوئے اس بات کا یقین کرنے کے لئے کہ صرف [`Into`] پر عمل درآمد کرنے والی اقسام کو بھی استعمال کیا جاسکتا ہے۔
///
/// **Note: اس trait میں ** ناکام نہیں ہونا چاہئے۔اگر تبادلہ ناکام ہوسکتا ہے تو ، [`TryInto`] استعمال کریں۔
///
/// # عام عمل
///
/// - [`منجمد]`<T>U` کا مطلب `Into<U> for T` ہے
/// - [`Into`] اضطراری ہے ، جس کا مطلب ہے کہ `Into<T> for T` لاگو کیا گیا ہے
///
/// # Rust کے پرانے ورژن میں بیرونی اقسام میں تبادلوں کے لئے [`Into`] لاگو کرنا
///
/// Rust 1.41 سے پہلے ، اگر منزل کی قسم موجودہ crate کا حصہ نہیں تھی تو آپ [`From`] کو براہ راست لاگو نہیں کرسکتے ہیں۔
/// مثال کے طور پر ، یہ کوڈ لیں:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// یہ زبان کے پرانے ورژنوں کو مرتب کرنے میں ناکام ہوجائے گا کیونکہ Rust کے یتیم اصول کچھ زیادہ سخت ہوتے تھے۔
/// اس کو نظرانداز کرنے کے لئے ، آپ براہ راست [`Into`] لاگو کرسکتے ہیں:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// یہ سمجھنا ضروری ہے کہ [`Into`] [`From`] نفاذ فراہم نہیں کرتا ہے (جیسا کہ [`From`] [`Into`] کے ساتھ کرتا ہے)۔
/// لہذا ، آپ کو ہمیشہ [`From`] کو نفاذ کرنے کی کوشش کرنی چاہئے اور پھر اگر [`From`] لاگو نہیں ہوسکتا ہے تو [`Into`] پر واپس آجائیں۔
///
/// # Examples
///
/// [`String`] اوزار [`میں`] `<` [`Vec`]`<`[`u8`] `>>`:
///
/// یہ ظاہر کرنے کے لئے کہ ہم ایک عام فعل چاہتے ہیں کہ وہ تمام دلائل لیں جو ایک مخصوص قسم `T` میں تبدیل ہوسکتے ہیں ، ہم [`ان``]`کے trait bound استعمال کرسکتے ہیں۔<T>`.
///
/// مثال کے طور پر: فنکشن `is_hello` وہ تمام دلائل لیتا ہے جن کو [[Vec`]`<`[`u8`]`> `میں تبدیل کیا جاسکتا ہے۔
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// تبادلوں کو انجام دیتا ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ان پٹ ویلیو کو استعمال کرتے ہوئے ویلیو ٹو ویلیو تبادلوں کیلئے استعمال ہوتا ہے۔یہ [`Into`] کا باضابطہ ہے۔
///
/// کسی کو ہمیشہ `From` کو [`Into`] پر عمل درآمد کرنے کو ترجیح دینی چاہئے کیونکہ `From` پر عمل درآمد خود بخود [`Into`] پر عمل درآمد فراہم کرتا ہے جس سے معیاری لائبریری میں کمبل کے نفاذ کا شکریہ۔
///
///
/// Rust 1.41 سے پہلے کسی ورژن کو نشانہ بناتے ہوئے اور موجودہ crate سے باہر کسی قسم میں تبدیل کرتے وقت صرف [`Into`] کو نافذ کریں۔
/// `From` Rust کے یتیم اصولوں کی وجہ سے پہلے کے ورژن میں اس قسم کے تبادلوں کا اہل نہیں تھا۔
/// مزید تفصیلات کے لئے [`Into`] دیکھیں۔
///
/// عام فعل پر trait bounds کی وضاحت کرتے وقت [`Into`] کا استعمال کرنے سے زیادہ [`Into`] کو ترجیح دیں۔
/// اس طرح ، ایسی اقسام جو [`Into`] کو براہ راست لاگو کرتی ہیں دلائل کے طور پر بھی استعمال کی جاسکتی ہیں۔
///
/// غلطی سے نمٹنے کے دوران `From` بھی بہت مفید ہے۔جب کسی ایسے فنکشن کی تشکیل جو ناکام ہونے کے قابل ہو تو ، واپسی کی قسم عام طور پر `Result<T, E>` کی شکل میں ہوگی۔
/// `From` trait غلطی سے نمٹنے کو آسان بناتا ہے جس میں ایک فنکشن کو ایک ہی غلطی کی قسم واپس کرنے کی اجازت دی جاتی ہے جو متعدد غلطی کی اقسام کو گھیر لیتا ہے۔مزید تفصیلات کے لئے "Examples" سیکشن اور [the book][book] دیکھیں۔
///
/// **Note: اس trait میں ** ناکام نہیں ہونا چاہئے۔اگر تبادلہ ناکام ہوسکتا ہے تو ، [`TryFrom`] استعمال کریں۔
///
/// # عام عمل
///
/// - `From<T> for U` Tlies <U>کے لئے</u> [`Into`] lies کا مطلب ہے
/// - `From` اضطراری ہے ، جس کا مطلب ہے کہ `From<T> for T` لاگو کیا گیا ہے
///
/// # Examples
///
/// [`String`] `From<&str>` لاگو:
///
/// ایک `&str` سے اسٹرنگ میں واضح تبادلہ مندرجہ ذیل ہے۔
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// غلطی سے نمٹنے کے دوران ، آپ اپنی غلطی کی قسم کے لئے `From` لاگو کرنا اکثر کارآمد ثابت ہوتا ہے۔
/// بنیادی غلطی کی اقسام کو اپنی مرضی کے مطابق غلطی کی قسم میں تبدیل کرکے جو بنیادی غلطی کی قسم کو گھیر لیتے ہیں ، ہم بنیادی وجوہ کے بارے میں معلومات کو کھونے کے بغیر ایک ہی غلطی کی قسم واپس کرسکتے ہیں۔
/// '?' آپریٹر `Into<CliError>::into` پر کال کرکے خود بخود بنیادی خرابی کی قسم کو اپنی مرضی کے مطابق غلطی کی قسم میں بدل دیتا ہے جو `From` لاگو کرتے وقت خود بخود فراہم کیا جاتا ہے۔
/// مرتب کرنے والے پھر اس بات کا اندازہ لگاتا ہے کہ `Into` پر عمل درآمد کون سا استعمال ہوگا۔
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// تبادلوں کو انجام دیتا ہے۔
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// ایک کوشش شدہ تبادلوں جو `self` کھاتا ہے ، جو مہنگا بھی ہوسکتا ہے اور نہیں بھی۔
///
/// لائبریری مصنفین کو عام طور پر اس trait پر براہ راست عمل درآمد نہیں کرنا چاہئے ، لیکن [`TryFrom`] trait پر عملدرآمد کو ترجیح دینی چاہئے ، جو زیادہ لچک پیش کرتا ہے اور معیاری لائبریری میں ایک کمبل کے نفاذ کی بدولت مفت میں مساوی `TryInto` عمل درآمد فراہم کرتا ہے۔
/// اس بارے میں مزید معلومات کے ل X ، [`Into`] کے لئے دستاویزات دیکھیں۔
///
/// # `TryInto` لاگو کیا جا رہا ہے
///
/// اس کو وہی پابندیوں اور استدلال کا سامنا کرنا پڑتا ہے جیسے [`Into`] پر عمل درآمد ہوتا ہے ، تفصیلات کے لئے وہاں دیکھیں۔
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// تبادلوں کی خرابی کی صورت میں اس قسم کی واپسی ہوئی۔
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// تبادلوں کو انجام دیتا ہے۔
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// آسان اور محفوظ قسم کے تبادلوں جو کچھ حالات میں کنٹرول انداز میں ناکام ہوسکتے ہیں۔یہ [`TryInto`] کا باضابطہ ہے۔
///
/// یہ اس وقت کارآمد ہے جب آپ کسی ایسے قسم کے تبادلوں کا کام کررہے ہیں جو چھوٹی سی کامیابی ہوسکتی ہے لیکن اسے خصوصی ہینڈلنگ کی بھی ضرورت پڑسکتی ہے۔
/// مثال کے طور پر ، [`From`] trait کا استعمال کرتے ہوئے [`i64`] کو [`i32`] میں تبدیل کرنے کا کوئی طریقہ نہیں ہے ، کیونکہ [`i64`] میں ایسی قدر ہوسکتی ہے جو [`i32`] نمائندگی نہیں کرسکتی ہے اور لہذا تبادلہ ڈیٹا سے محروم ہوجائے گا۔
///
/// یہ [`i64`] کو [`i32`] (بنیادی طور پر [`i64`] کی قدر موڈیولو [`i32::MAX`] دے کر) دے کر یا سنجیدگی سے [`i32::MAX`] واپس کرکے ، یا کسی اور طریقے سے سنبھالا جاسکتا ہے۔
/// [`From`] trait کامل تبادلوں کے ل is ہے ، لہذا `TryFrom` trait پروگرامر کو اس وقت مطلع کرتا ہے جب ایک قسم کی تبادلوں میں خرابی آسکتی ہے اور وہ اس کو سنبھالنے کا فیصلہ کرنے دیتا ہے۔
///
/// # عام عمل
///
/// - `TryFrom<T> for U` T`<U>کے لئے</u> [`TryInto`] lies کا مطلب ہے
/// - [`try_from`] ریفلیکسیو ہے ، جس کا مطلب ہے کہ `TryFrom<T> for T` لاگو کیا گیا ہے اور ناکام نہیں ہوسکتا-`T` کی قسم پر `T::try_from()` پر کال کرنے کے لئے متعلقہ `Error` قسم [`Infallible`] ہے۔
/// جب [`!`] قسم مستحکم ہوجائے تو [`Infallible`] اور [`!`] برابر ہوگا۔
///
/// `TryFrom<T>` مندرجہ ذیل کے طور پر لاگو کیا جا سکتا ہے:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// جیسا کہ بیان کیا گیا ہے ، [`i32`] نافذ کرتا ہے `ٹر فریم <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // خاموشی سے `big_number` کو چھوٹ دیتا ہے ، حقیقت کے بعد تراشنا کا پتہ لگانے اور ان سے نمٹنے کی ضرورت ہوتی ہے۔
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // خرابی واپس کرتا ہے کیونکہ `big_number` ایک `i32` میں فٹ ہونے کے لئے بہت بڑا ہے۔
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` واپس کرتا ہے۔
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// تبادلوں کی خرابی کی صورت میں اس قسم کی واپسی ہوئی۔
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// تبادلوں کو انجام دیتا ہے۔
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// عام IMPLS
////////////////////////////////////////////////////////////////////////////////

// جیسے ہی لفٹیں&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// جیسے &mut سے زیادہ لفٹیں
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): مندرجہ بالا مزید عام کے ساتھ&/&موافقت پذیری کے لئے مندرجہ بالا امپلیسس کو تبدیل کریں:
// // جیسے ڈیرف پر لفٹیں
// impl <D: ?Sized + Deref<Target: AsRef<U>> ، U:؟ سائز: <U>D {fn as_ref(&self) کے لئے AsRef-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut سے زیادہ لفٹ کرتا ہے
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut کے لئے مندرجہ بالا امپیل کو مندرجہ ذیل مزید عام سے تبدیل کریں۔
// // AsMut ڈیریٹ مٹ پر لفٹ کرتا ہے
// impl <D: ?Sized + Deref<Target: AsMut<U>> ، U:؟ سائز> AsMut <U>برائے D {fn as_mut(&mut self)-> &mut U</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// اس سے مراد
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// (اور اس طرح اس میں) سے اضطراری ہے
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **استحکام نوٹ:** یہ عملی شکل ابھی موجود نہیں ہے ، لیکن ہم اسے future میں شامل کرنے کے لئے "reserving space" ہیں۔
/// تفصیلات کے لئے [rust-lang/rust#64715][#64715] دیکھیں۔
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): اس کے بجائے اصولی طور پر درست کریں۔
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// ٹر فریم کا مطلب ٹر آئینٹو ہے
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// ناقابل تردید تبدیلیوں کو بغیر کسی غلطی کی قسم کے غلط الفاظ کے غلطی کے مترادف ہے۔
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// آئی ایم پی ایل کو ختم کریں
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// کوئی غلطی غلطی قسم
////////////////////////////////////////////////////////////////////////////////

/// غلطیوں کے لئے غلطی کی قسم جو کبھی نہیں ہوسکتی ہے۔
///
/// چونکہ اس اینوم کی کوئی تغیر نہیں ہے ، لہذا اس نوع کی قدر کبھی بھی موجود نہیں ہوسکتی ہے۔
/// یہ عام APIs کے لئے مفید ہوسکتا ہے جو [`Result`] استعمال کرتے ہیں اور غلطی کی قسم کو پیرامیٹرائز کرتے ہیں ، اس بات کی نشاندہی کرنے کے لئے کہ نتیجہ ہمیشہ [`Ok`] ہوتا ہے۔
///
/// مثال کے طور پر ، [`TryFrom`] trait (تبادلوں جو [`Result`] واپس کرتا ہے) میں ہر قسم کے لئے ایک کمبل عمل درآمد ہوتا ہے جہاں ایک الٹا [`Into`] نفاذ موجود ہے۔
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future مطابقت
///
/// اس اینوم کا [the `!`“never”type][never] جیسا ہی کردار ہے ، جو Rust کے اس ورژن میں غیر مستحکم ہے۔
/// جب `!` مستحکم ہوجاتا ہے ، تو ہم `Infallible` کو اس کا ایک ٹائپ عرف بنانے کا ارادہ رکھتے ہیں:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …اور آخر کار `Infallible` کو نظرانداز کریں۔
///
/// تاہم ، ایک معاملہ ایسا ہے جہاں `!` نحو کا استعمال ایک مکمل قسم کے طور پر مستحکم ہونے سے پہلے ہی کیا جاسکتا ہے: کسی فنکشن کی واپسی کی قسم کی پوزیشن میں۔
/// خاص طور پر ، یہ دو مختلف فنکشن پوائنٹر اقسام کے لئے ممکنہ نفاذ ہے:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` ایک enum ہونے کی وجہ سے ، یہ کوڈ درست ہے۔
/// تاہم ، جب `Infallible` never type کا عرف بن جاتا ہے ، تو دو امپلاؤ آورپلائپ ہونا شروع ہوجائیں گے لہذا زبان کے trait ہم آہنگی کے قواعد کے ذریعہ اس کی اجازت نہیں ہوگی۔
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}