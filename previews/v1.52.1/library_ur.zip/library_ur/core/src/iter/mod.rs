//! کمپوزایبل بیرونی تکرار
//!
//! اگر آپ نے کسی قسم کا ایک مجموعہ اپنے آپ کو پایا ہے ، اور کہا مجموعہ کے عناصر پر آپریشن کرنے کی ضرورت ہے تو ، آپ جلدی سے 'iterators' میں چلے جائیں گے۔
//! Iteators بھاری استعمال کیا جاتا ہے محاورہ Rust کوڈ میں ، لہذا یہ ان کے ساتھ واقف ہونے کے قابل ہے۔
//!
//! مزید وضاحت کرنے سے پہلے آئیے اس ماڈیول کی تشکیل کی بات کے بارے میں بات کریں:
//!
//! # Organization
//!
//! یہ ماڈیول بڑے پیمانے پر قسم کے لحاظ سے ترتیب دیا گیا ہے۔
//!
//! * [Traits] بنیادی حص areہ ہیں: یہ traits اس بات کی وضاحت کرتی ہے کہ کس طرح کے آئٹیٹر موجود ہیں اور آپ ان کے ساتھ کیا کرسکتے ہیں۔ان traits کے طریق کار مطالعہ کے لئے کچھ اضافی وقت ڈالنے کے قابل ہیں۔
//! * [Functions] کچھ بنیادی ریڈیٹرس بنانے کے ل some کچھ مددگار طریقے فراہم کریں۔
//! * [Structs] اس ماڈیول کے traits پر اکثر مختلف طریقوں کی واپسی کی اقسام ہیں۔آپ عام طور پر `struct` کے بجائے `struct` بنانے کا طریقہ دیکھنا چاہتے ہیں۔
//! اس کے بارے میں مزید تفصیل کے لئے ، '[عملدرآمد التجا]](#عمل درآمد کرنے والا)' دیکھیں۔
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! یہی ہے!آئیٹروں میں کھودیں۔
//!
//! # Iterator
//!
//! اس ماڈیول کا دل اور روح [`Iterator`] trait ہے۔[`Iterator`] کا بنیادی کچھ اس طرح لگتا ہے:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! ایک آئریٹر کے پاس ایک طریقہ ہے ، [`next`] ، جسے جب بلایا جاتا ہے تو ، [`آپشن`]`واپس کرتا ہے<Item>`.
//! [`next`] جب تک عناصر موجود ہوں [`Some(Item)`] X واپس کردیں گے ، اور ایک بار جب وہ سب ختم ہوجائیں تو ، `None` کو لوٹ آئے گا اس بات کی نشاندہی کرنے کے لئے کہ یہ اعادہ ختم ہوچکا ہے۔
//! انفرادی طور پر دوبارہ چلنے والوں کو دوبارہ شروع کرنے کا انتخاب ہوسکتا ہے ، اور لہذا [`next`] کو دوبارہ فون کرنا کسی وقت [`Some(Item)`] کو دوبارہ لوٹنا شروع کر سکتا ہے یا نہیں (مثال کے طور پر ، [`TryIter`] ملاحظہ کریں)۔
//!
//!
//! [te Iterator`] کی مکمل تعریف میں متعدد دوسرے طریقے بھی شامل ہیں ، لیکن وہ پہلے سے طے شدہ طریقے ہیں ، جو [`next`] کے سب سے اوپر پر تعمیر کیے گئے ہیں ، اور لہذا آپ انہیں مفت میں حاصل کرتے ہیں۔
//!
//! Iteters بھی قابل تحسین ہیں ، اور پروسیسنگ کی زیادہ پیچیدہ شکلوں کو انجام دینے کے ل together ان کو اکٹھا کرنا ایک عام بات ہے۔مزید تفصیلات کے لئے نیچے [Adapters](#adapters) سیکشن دیکھیں۔
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # تکرار کی تین شکلیں
//!
//! یہاں تین عام طریقے ہیں جو ایک مجموعے سے تکرار پیدا کرسکتے ہیں۔
//!
//! * `iter()`, جو `&T` سے زیادہ ہے۔
//! * `iter_mut()`, جو `&mut T` سے زیادہ ہے۔
//! * `into_iter()`, جو `T` سے زیادہ ہے۔
//!
//! معیاری لائبریری میں مختلف چیزیں جہاں مناسب ہو وہاں تین میں سے ایک یا زیادہ کو نافذ کرسکتی ہیں۔
//!
//! # لاگو کرنے والا الٹیٹر
//!
//! اپنے ہی ایک ایٹریٹر کی تشکیل میں دو مراحل شامل ہیں: تکرار کرنے والے کی حالت برقرار رکھنے کے لئے `struct` بنانا ، اور پھر اس `struct` کے لئے [`Iterator`] لاگو کریں۔
//! یہی وجہ ہے کہ اس ماڈیول میں بہت سارے ڈھانچے ہیں: ہر ریڈیٹر اور ریٹر ایڈیٹر کے لئے ایک ایک ہوتا ہے۔
//!
//! `Counter` نامی ایک ایٹریٹر بنائیں جس کا شمار `1` سے `5` تک ہوتا ہے:
//!
//! ```
//! // سب سے پہلے ، ڈھانچہ:
//!
//! /// ایک تکرار کرنے والا جو ایک سے پانچ تک شمار ہوتا ہے
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ہم چاہتے ہیں کہ ہماری گنتی ایک سے شروع ہو ، لہذا مدد کرنے کے لئے new() کا طریقہ شامل کریں۔
//! // یہ سختی سے ضروری نہیں ہے ، لیکن آسان ہے۔
//! // نوٹ کریں کہ ہم `count` کو صفر سے شروع کرتے ہیں ، ہم دیکھیں گے کہ نیچے `next()`'s پر عمل درآمد کیوں ہے۔
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // پھر ، ہم اپنے `Counter` کیلئے `Iterator` لاگو کرتے ہیں:
//!
//! impl Iterator for Counter {
//!     // ہم usize کے ساتھ گنتی کریں گے
//!     type Item = usize;
//!
//!     // next() واحد مطلوبہ طریقہ ہے
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // ہماری گنتی میں اضافہ کریں۔اسی لئے ہم نے صفر سے آغاز کیا۔
//!         self.count += 1;
//!
//!         // چیک کریں کہ آیا ہم گنتی ختم کرچکے ہیں یا نہیں۔
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // اور اب ہم اسے استعمال کرسکتے ہیں!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! اس طرح [`next`] کال کرنا بار بار ملتا ہے۔Rust میں ایک کنسٹرکٹ ہے جو آپ کے ریڈیٹر پر [`next`] پر کال کرسکتی ہے ، جب تک کہ یہ `None` تک نہ پہنچ جائے۔آئیے اس کے اگلے حصے پر جائیں۔
//!
//! یہ بھی نوٹ کریں کہ `Iterator` `nth` اور `fold` جیسے طریقوں پر پہلے سے طے شدہ نفاذ فراہم کرتا ہے جو `next` کو داخلی طور پر کہتے ہیں۔
//! تاہم ، یہ بھی ممکن ہے کہ `nth` اور `fold` جیسے طریقوں پر اپنی مرضی کے مطابق نفاذ لکھیں اگر کوئی تکرار کرنے والا `next` پر کال کیے بغیر ان کی زیادہ موثر انداز میں حساب کر سکے۔
//!
//! # `for` لوپس اور `IntoIterator`
//!
//! Rust کا `for` لوپ نحو دراصل تکرار کرنے والوں کے لئے چینی ہے۔یہاں `for` کی ایک بنیادی مثال ہے۔
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! اس سے ہر ایک کو اپنی لائن پر ایک سے پانچ تک نمبر پرنٹ کریں گے۔لیکن آپ کو یہاں پر کچھ نظر آئے گا: ہم نے کبھی بھی اپنے vector پر کوئی ایٹرٹر تیار کرنے کے لئے فون نہیں کیا۔کیا دیتا ہے؟
//!
//! معیاری لائبریری میں کسی چیز کو آئٹر میں تبدیل کرنے کے لئے ایک trait ہے۔ [`IntoIterator`].
//! اس trait میں ایک طریقہ ہے ، [`into_iter`] ، جو [`IntoIterator`] کو لاگو کرنے والی چیز کو ایک آئریٹر میں تبدیل کرتا ہے۔
//! آئیے ایک بار پھر اس `for` لوپ پر ایک نظر ڈالیں ، اور مرتب کنندہ اسے کس چیز میں تبدیل کرتا ہے:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust ڈی شوگر کو اس میں:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! پہلے ، ہم قدر پر `into_iter()` کہتے ہیں۔پھر ، ہم دوبارہ چلنے والے سے ملتے ہیں جو لوٹتا ہے ، [`next`] کو زیادہ سے زیادہ کال کرتا ہے جب تک کہ ہم ایک `None` نہ دیکھیں۔
//! اس وقت ، ہم لوپ سے `break` کر چکے ہیں ، اور ہم دوبارہ چل رہے ہیں۔
//!
//! یہاں ایک اور لطیف سا سا بھی ہے: معیاری لائبریری میں [`IntoIterator`] کا ایک دلچسپ عمل ہے۔
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! دوسرے لفظوں میں ، تمام [te Iterator`] [`IntoIterator`] کا نفاذ کرتے ہیں ، صرف اپنے آپ کو لوٹ کر۔اس کا مطلب ہے دو چیزیں:
//!
//! 1. اگر آپ [`Iterator`] لکھ رہے ہیں تو ، آپ اسے `for` لوپ کے ساتھ استعمال کرسکتے ہیں۔
//! 2. اگر آپ کوئی مجموعہ تشکیل دے رہے ہیں تو ، اس کے لئے [`IntoIterator`] لاگو کرنے سے آپ کا مجموعہ `for` لوپ کے ساتھ استعمال ہونے کی اجازت ملے گی۔
//!
//! # حوالہ کے ذریعہ Iterating
//!
//! چونکہ [`into_iter()`] `self` قدر کے حساب سے لیتا ہے ، لہذا ایک مجموعہ پر اعادہ کرنے کے لئے `for` لوپ کا استعمال کرتے ہوئے اس مجموعہ کا استعمال ہوتا ہے۔اکثر ، آپ کسی مجموعہ کو استعمال کیے بغیر اس کی تکرار کرنا چاہتے ہیں۔
//! بہت سارے مجموعے ایسے طریقوں کی پیش کش کرتے ہیں جو حوالوں سے زیادہ دہندگان کو مہی provideا کرتے ہیں ، جسے روایتی طور پر `iter()` اور `iter_mut()` کہا جاتا ہے:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` اب بھی اس فنکشن کی ملکیت ہے۔
//! ```
//!
//! اگر ایک مجموعہ کی قسم `C` `iter()` فراہم کرتا ہے تو ، یہ عام طور پر `&C` کے لئے `IntoIterator` بھی نافذ کرتا ہے ، اس پر عمل درآمد ہوتا ہے جس کو صرف `iter()` کہتے ہیں۔
//! اسی طرح ، ایک مجموعہ `C` جو `iter_mut()` مہیا کرتا ہے عام طور پر `iter_mut()` کو تفویض کرکے `&mut C` کیلئے `IntoIterator` لاگو کرتا ہے۔یہ ایک آسان شارٹ ہینڈ کے قابل بناتا ہے:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` جیسا ہی ہے
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` جیسا ہی ہے
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! جبکہ بہت سارے مجموعے `iter()` پیش کرتے ہیں ، تمام پیش کش `iter_mut()` نہیں کرتے ہیں۔
//! مثال کے طور پر ، [`HashSet<T>`] یا [`HashMap<K, V>`] کی چابیاں تبدیل کرنے سے اگر کلید ہیش تبدیل ہوجائے تو اس مجموعہ کو متضاد حالت میں ڈال دیا جاسکتا ہے ، لہذا یہ جمع صرف `iter()` پیش کرتے ہیں۔
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! وہ افعال جو ایک [`Iterator`] لے جاتے ہیں اور ایک اور [`Iterator`] کو واپس کرتے ہیں انہیں اکثر 'ایٹریٹر اڈیپٹر' کہا جاتا ہے ، کیونکہ وہ 'اڈیپٹر' کی ایک شکل ہیں
//! pattern'.
//!
//! عام اوٹریٹر اڈاپٹر میں [`map`] ، [`take`] ، اور [`filter`] شامل ہیں۔
//! مزید کے لئے ، ان کی دستاویزات ملاحظہ کریں۔
//!
//! اگر ایک ایٹریٹر اڈاپٹر panics ہے تو ، ایٹریٹر غیر مخصوص (لیکن میموری محفوظ) حالت میں ہوگا۔
//! اس ریاست کی بھی Rust کے مختلف ورژن میں ایک ہی رہنے کی ضمانت نہیں ہے ، لہذا آپ کو گھبرانے والے دوبارہ چلنے والے کے ذریعہ موصولہ صحیح قدروں پر انحصار کرنے سے گریز کرنا چاہئے۔
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! ایٹریٹر (اور ایٹریٹر X01 ایکس *سست* ہیں۔ اس کا مطلب یہ ہے کہ صرف ایک ایٹریٹر بنانا پوری طرح _do_ نہیں کرتا۔ جب تک آپ [`next`] پر فون نہیں کرتے ہیں واقعی میں کچھ نہیں ہوتا ہے۔
//! مکمل طور پر اس کے ضمنی اثرات کے ل an ایٹریٹر بناتے وقت یہ الجھن کا باعث ہوتا ہے۔
//! مثال کے طور پر ، [`map`] طریقہ ہر عنصر پر بند ہونے کا مطالبہ کرتا ہے جس پر اس کا اعادہ ہوتا ہے:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! یہ کسی بھی اقدار کو پرنٹ نہیں کرے گا ، کیوں کہ ہم نے اسے استعمال کرنے کے بجائے صرف ایک ریڈیٹر بنایا ہے۔مرتب کرنے والا ہمیں اس طرح کے سلوک کے بارے میں متنبہ کرے گا:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! اس کے مضر اثرات کے ل a [`map`] لکھنے کا محاورہ طریقہ ایک `for` لوپ کا استعمال کرنا یا [`for_each`] طریقہ پر کال کرنا ہے:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! ایٹریٹر کا اندازہ کرنے کا دوسرا عام طریقہ یہ ہے کہ ایک نیا مجموعہ تیار کرنے کے لئے [`collect`] کا طریقہ استعمال کریں۔
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! آئٹریٹرز کو محدود نہیں ہونا ضروری ہے۔ایک مثال کے طور پر ، ایک کھلی ہوئی حد ایک لامحدود تکرار کرنے والا ہے:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! لامحدود تکرار کو ایک محدود شکل میں تبدیل کرنے کے لئے [`take`] ریٹرٹر اڈیپٹر کا استعمال عام ہے۔
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! یہ `4` کے ذریعے `0` نمبر پرنٹ کرے گا ، ہر ایک اپنی اپنی لائن پر۔
//!
//! یہ بات ذہن میں رکھیں کہ لامحدود تکرار کرنے والے طریق کار ، حتی کہ جن کے لئے نتیجہ طے شدہ وقت میں ریاضی سے طے کیا جاسکتا ہے ، ختم نہیں ہوسکتا ہے۔
//! خاص طور پر ، [`min`] جیسے طریقے ، جن میں عام طور پر آئٹرٹر میں ہر عنصر کو عبور کرنے کی ضرورت ہوتی ہے ، ممکنہ طور پر کسی لامحدود تکرار کرنے والوں کے لئے کامیابی کے ساتھ واپس نہ آئے۔
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // ارے نہیں!ایک لامحدود لوپ!
//! // `ones.min()` لامحدود لوپ کا سبب بنتا ہے ، لہذا ہم اس مقام تک نہیں پہنچ پائیں گے!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;