use crate::iter::{FusedIterator, TrustedLen};

/// ایک ایٹریٹر بناتا ہے جو عنصر کو بالکل ایک بار ملتا ہے۔
///
/// یہ عام طور پر کسی ایک قدر کو دوسری قسم کے تکرار کی [`chain()`] میں ڈھالنے کے لئے استعمال ہوتا ہے۔
/// ہوسکتا ہے کہ آپ کے پاس ایٹریٹر ہو جو تقریبا everything ہر چیز پر محیط ہو ، لیکن آپ کو ایک اضافی خصوصی معاملہ درکار ہے۔
/// ہوسکتا ہے کہ آپ کے پاس ایک فنکشن ہے جو مکرروں پر کام کرتا ہے ، لیکن آپ کو صرف ایک قدر پر عملدرآمد کرنے کی ضرورت ہے۔
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::iter;
///
/// // ایک اکیلی تعداد ہے
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // صرف ایک ، بس ہمیں حاصل ہے
/// assert_eq!(None, one.next());
/// ```
///
/// دوسرے آئریٹر کے ساتھ مل کر سلسلہ بندی کرنا۔
/// ہم کہتے ہیں کہ ہم `.foo` ڈائرکٹری کی ہر فائل پر اعادہ کرنا چاہتے ہیں ، بلکہ ایک تشکیل فائل بھی ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ہمیں دیر اینٹری ایس کے ایٹریٹر سے پاتھ بفس کے ایریٹر میں تبدیل کرنے کی ضرورت ہے ، لہذا ہم نقشہ استعمال کرتے ہیں
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // اب ، ہمارے ریٹر صرف ہماری تشکیل فائل کے لئے
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ایک دوسرے کے ساتھ ایک ساتھ دو بار چلانے والوں کو زنجیر بنائیں
/// let files = dirs.chain(config);
///
/// // یہ ہم سب کو .foo کے ساتھ ساتھ .foorc کی فائلیں دے گا
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// ایک تکرار کرنے والا جو عنصر کو بالکل ایک بار حاصل کرتا ہے۔
///
/// یہ `struct` [`once()`] فنکشن کے ذریعہ تشکیل دیا گیا ہے۔مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}