use crate::iter::{FusedIterator, TrustedLen};

/// ایک ایسیٹر تیار کرتا ہے جو فراہم کردہ بندش کی مدد سے ایک بار سست طور پر ایک قدر پیدا کرتا ہے۔
///
/// یہ عام طور پر کسی ایک اقدار جنریٹر کو [`chain()`] میں دوسری قسم کے تکرار کے مطابق بنانے کے لئے استعمال ہوتا ہے۔
/// ہوسکتا ہے کہ آپ کے پاس ایٹریٹر ہو جو تقریبا everything ہر چیز پر محیط ہو ، لیکن آپ کو ایک اضافی خصوصی معاملہ درکار ہے۔
/// ہوسکتا ہے کہ آپ کے پاس ایک فنکشن ہے جو مکرروں پر کام کرتا ہے ، لیکن آپ کو صرف ایک قدر پر عملدرآمد کرنے کی ضرورت ہے۔
///
/// [`once()`] کے برعکس ، یہ فنکشن سستگی سے درخواست پر قیمت پیدا کرے گا۔
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::iter;
///
/// // ایک اکیلی تعداد ہے
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // صرف ایک ، بس ہمیں حاصل ہے
/// assert_eq!(None, one.next());
/// ```
///
/// دوسرے آئریٹر کے ساتھ مل کر سلسلہ بندی کرنا۔
/// ہم کہتے ہیں کہ ہم `.foo` ڈائرکٹری کی ہر فائل پر اعادہ کرنا چاہتے ہیں ، بلکہ ایک تشکیل فائل بھی ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ہمیں دیر اینٹری ایس کے ایٹریٹر سے پاتھ بفس کے ایریٹر میں تبدیل کرنے کی ضرورت ہے ، لہذا ہم نقشہ استعمال کرتے ہیں
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // اب ، ہمارے ریٹر صرف ہماری تشکیل فائل کے لئے
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ایک دوسرے کے ساتھ ایک ساتھ دو بار چلانے والوں کو زنجیر بنائیں
/// let files = dirs.chain(config);
///
/// // یہ ہم سب کو .foo کے ساتھ ساتھ .foorc کی فائلیں دے گا
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// ایک آئٹرٹر جو فراہم کردہ بندش `F: FnOnce() -> A` کو لاگو کرکے `A` قسم کا ایک ہی عنصر برآمد کرتا ہے۔
///
///
/// یہ `struct` [`once_with()`] فنکشن کے ذریعہ تشکیل دیا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}