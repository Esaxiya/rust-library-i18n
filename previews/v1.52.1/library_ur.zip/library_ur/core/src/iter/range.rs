use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// وہ آبجیکٹ جن کے بارے میں *جانشین* اور *پیشرو* کارروائیوں کا تصور ہوتا ہے۔
///
/// *جانشین* آپریشن ان اقدار کی طرف بڑھتا ہے جو زیادہ سے زیادہ کا موازنہ کرتے ہیں۔
/// *پیشرو* آپریشن ان اقدار کی طرف بڑھتا ہے جو کم موازنہ کرتے ہیں۔
///
/// # Safety
///
/// یہ trait `unsafe` ہے کیونکہ `unsafe trait TrustedLen` نفاذ کی حفاظت کے ل its اس کا نفاذ درست ہونا چاہئے ، اور اس trait کو استعمال کرنے کے نتائج کو `unsafe` کوڈ کے ذریعہ اعتماد کیا جاسکتا ہے تاکہ وہ درست ہو اور درج ذمہ داریوں کو پورا کرسکے۔
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` سے `end` حاصل کرنے کے لئے درکار *جانشین* اقدامات کی تعداد لوٹاتا ہے۔
    ///
    /// `None` واپس کرتا ہے اگر اقدامات کی تعداد `usize` کو بہا لے گی (یا لامحدود ہے ، یا اگر `end` کبھی نہیں پہنچ پائے گا)۔
    ///
    ///
    /// # Invariants
    ///
    /// کسی بھی `a` ، `b` ، اور `n` کیلئے:
    ///
    /// * `steps_between(&a, &b) == Some(n)` اگر اور صرف `Step::forward_checked(&a, n) == Some(b)` ہے
    /// * `steps_between(&a, &b) == Some(n)` اگر اور صرف `Step::backward_checked(&a, n) == Some(a)` ہے
    /// * `steps_between(&a, &b) == Some(n)` صرف اگر `a <= b`
    ///   * منطقی نتیجہ: `steps_between(&a, &b) == Some(0)` اگر اور صرف `a == b` ہے
    ///   * نوٹ کریں کہ `a <= b` _not_ پر `steps_between(&a, &b) != None` پر عمل کرتا ہے۔
    ///     یہ صورت ہے جب `b` پر جانے کے لئے `usize::MAX` سے زیادہ اقدامات کی ضرورت ہوگی
    /// * `steps_between(&a, &b) == None` اگر `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// وہ قدر لوٹاتا ہے جو `self` `count` اوقات کے *جانشین* کو حاصل کرکے حاصل کیا جائے گا۔
    ///
    /// اگر یہ `Self` کے ذریعہ تعاون یافتہ اقدار کی حد کو بڑھا دے تو ، `None` واپس کردیتا ہے۔
    ///
    /// # Invariants
    ///
    /// کسی بھی `a` ، `n` ، اور `m` کیلئے:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// کسی بھی `a` ، `n` ، اور `m` کے لئے جہاں `n + m` زیادہ نہیں آتا ہے:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// کسی بھی `a` اور `n` کیلئے:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// وہ قدر لوٹاتا ہے جو `self` `count` اوقات کے *جانشین* کو حاصل کرکے حاصل کیا جائے گا۔
    ///
    /// اگر یہ `Self` کے ذریعہ تعاون یافتہ اقدار کی حد کو بڑھا دے گا تو ، اس فعل کو panic ، لپیٹنا ، یا مطمئن کرنے کی اجازت ہے۔
    ///
    /// تجویز کردہ سلوک panic سے ہے جب ڈیبگ دعوے اہل ہوجاتے ہیں ، اور دوسری صورت میں لپیٹ یا مطمئن کرنا۔
    ///
    /// غیر محفوظ کوڈ کو اوور فلو کے بعد سلوک کی درستگی پر انحصار نہیں کرنا چاہئے۔
    ///
    /// # Invariants
    ///
    /// کسی بھی `a` ، `n` ، اور `m` کے لئے ، جہاں کہیں زیادہ بہاؤ نہیں ہوتا ہے:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// کسی بھی `a` اور `n` کے لئے ، جہاں کہیں زیادہ بہاؤ نہیں ہوتا ہے:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// وہ قدر لوٹاتا ہے جو `self` `count` اوقات کے *جانشین* کو حاصل کرکے حاصل کیا جائے گا۔
    ///
    /// # Safety
    ///
    /// `Self` کے ذریعہ تعاون یافتہ اقدار کی حد کو بڑھانا اس آپریشن کے لئے غیر متعین سلوک ہے۔
    /// اگر آپ اس بات کی ضمانت نہیں دے سکتے ہیں کہ یہ بہاو نہیں کرے گا تو ، اس کے بجائے `forward` یا `forward_checked` استعمال کریں۔
    ///
    /// # Invariants
    ///
    /// کسی بھی `a` کے لئے:
    ///
    /// * اگر وہاں `b` موجود ہے جیسے `b > a` ، تو `Step::forward_unchecked(a, 1)` پر کال کرنا محفوظ ہے
    /// * اگر وہاں `b` ، `n` جیسے `steps_between(&a, &b) == Some(n)` موجود ہیں تو ، کسی بھی `m <= n` کیلئے `Step::forward_unchecked(a, m)` پر کال کرنا محفوظ ہے۔
    ///
    ///
    /// کسی بھی `a` اور `n` کے لئے ، جہاں کہیں زیادہ بہاؤ نہیں ہوتا ہے:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` کے برابر ہے
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// وہ قدر لوٹاتا ہے جو `self` `count` اوقات کے *پیشرو* کو لے کر حاصل کیا جائے گا۔
    ///
    /// اگر یہ `Self` کے ذریعہ تعاون یافتہ اقدار کی حد کو بڑھا دے تو ، `None` واپس کردیتا ہے۔
    ///
    /// # Invariants
    ///
    /// کسی بھی `a` ، `n` ، اور `m` کیلئے:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// کسی بھی `a` اور `n` کیلئے:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// وہ قدر لوٹاتا ہے جو `self` `count` اوقات کے *پیشرو* کو لے کر حاصل کیا جائے گا۔
    ///
    /// اگر یہ `Self` کے ذریعہ تعاون یافتہ اقدار کی حد کو بڑھا دے گا تو ، اس فعل کو panic ، لپیٹنا ، یا مطمئن کرنے کی اجازت ہے۔
    ///
    /// تجویز کردہ سلوک panic سے ہے جب ڈیبگ دعوے اہل ہوجاتے ہیں ، اور دوسری صورت میں لپیٹ یا مطمئن کرنا۔
    ///
    /// غیر محفوظ کوڈ کو اوور فلو کے بعد سلوک کی درستگی پر انحصار نہیں کرنا چاہئے۔
    ///
    /// # Invariants
    ///
    /// کسی بھی `a` ، `n` ، اور `m` کے لئے ، جہاں کہیں زیادہ بہاؤ نہیں ہوتا ہے:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// کسی بھی `a` اور `n` کے لئے ، جہاں کہیں زیادہ بہاؤ نہیں ہوتا ہے:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// وہ قدر لوٹاتا ہے جو `self` `count` اوقات کے *پیشرو* کو لے کر حاصل کیا جائے گا۔
    ///
    /// # Safety
    ///
    /// `Self` کے ذریعہ تعاون یافتہ اقدار کی حد کو بڑھانا اس آپریشن کے لئے غیر متعین سلوک ہے۔
    /// اگر آپ اس بات کی ضمانت نہیں دے سکتے ہیں کہ یہ بہاو نہیں کرے گا تو ، اس کے بجائے `backward` یا `backward_checked` استعمال کریں۔
    ///
    /// # Invariants
    ///
    /// کسی بھی `a` کے لئے:
    ///
    /// * اگر وہاں `b` موجود ہے جیسے `b < a` ، تو `Step::backward_unchecked(a, 1)` پر کال کرنا محفوظ ہے
    /// * اگر وہاں `b` ، `n` جیسے `steps_between(&b, &a) == Some(n)` موجود ہیں تو ، کسی بھی `m <= n` کیلئے `Step::backward_unchecked(a, m)` پر کال کرنا محفوظ ہے۔
    ///
    ///
    /// کسی بھی `a` اور `n` کے لئے ، جہاں کہیں زیادہ بہاؤ نہیں ہوتا ہے:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` کے برابر ہے
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// یہ اب بھی میکرو جنریٹڈ ہیں کیونکہ انٹیجر لٹریشل مختلف اقسام کا حل کرتے ہیں۔
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `start + n` اتپرواہ نہ ہو۔
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `start - n` اتپرواہ نہ ہو۔
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ڈیبگ بنڈس میں ، اوور فلو پر panic کو ٹرگر کریں۔
            // یہ رہائی کی تعمیر میں مکمل طور پر بہتر بنانا چاہئے۔
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // مثال کے طور پر اجازت دینے کے ل wra ریپنگ ریاضی کرتے ہیں `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ڈیبگ بنڈس میں ، اوور فلو پر panic کو ٹرگر کریں۔
            // یہ رہائی کی تعمیر میں مکمل طور پر بہتر بنانا چاہئے۔
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // مثال کے طور پر اجازت دینے کے ل wra ریپنگ ریاضی کرتے ہیں `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // یہ $u_narrower <=usize پر انحصار کرتا ہے
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // اگر n حد سے باہر ہے تو ، `unsigned_start + n` بھی ہے
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // اگر n حد سے باہر ہے تو ، `unsigned_start - n` بھی ہے
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // یہ $i_narrower <=usize پر انحصار کرتا ہے
                        //
                        // آئیزاائز کرنے کے لئے معدنیات سے متعلق چوڑائی میں توسیع ہوتی ہے لیکن نشانی محفوظ ہوتی ہے۔
                        // آئی ایسائز اسپیس میں ریپنگ_سوب کا استعمال کریں اور اس فرق کی گنتی کے ل us کاسٹ کرنے کے لئے کاسٹ کریں جو آئی ایسائز کی حد کے اندر فٹ نہیں ہوسکتے ہیں۔
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ریپنگ `Step::forward(-120_i8, 200) == Some(80_i8)` جیسے معاملات کو سنبھالتی ہے ، حالانکہ 200 i8 کی حد سے باہر ہے۔
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // اضافہ بہہ گیا
                            }
                        }
                        // اگر n جیسے حد سے باہر ہے
                        // u8, تو یہ i8 کی پوری حد سے بڑا ہے لہذا `any_i8 + n` لازمی طور پر i8 کو بہا لے۔
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ریپنگ `Step::forward(-120_i8, 200) == Some(80_i8)` جیسے معاملات کو سنبھالتی ہے ، حالانکہ 200 i8 کی حد سے باہر ہے۔
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // گھٹائو اترا
                            }
                        }
                        // اگر n جیسے حد سے باہر ہے
                        // u8, تو یہ i8 کی پوری حد سے بڑا ہے لہذا `any_i8 - n` لازمی طور پر i8 کو بہا لے۔
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // اگر فرق بہت بڑا ہو جیسے
                            // i128 ، کم بٹس کے ساتھ استعمال کے ل it's یہ بھی بہت بڑا ہوگا۔
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // محفوظ کریں: res ایک صحیح یونیکوڈ اسکیلر ہے
            // (0x110000 سے نیچے اور 0xD800..0xE000 میں نہیں)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // محفوظ کریں: res ایک صحیح یونیکوڈ اسکیلر ہے
        // (0x110000 سے نیچے اور 0xD800..0xE000 میں نہیں)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ اس سے زیادہ بہاو نہ ہو
        // چار کے لئے اقدار کی حد۔
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ اس سے زیادہ بہاو نہ ہو
            // چار کے لئے اقدار کی حد۔
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // حفاظت: پچھلے معاہدے کی وجہ سے ، اس کی ضمانت ہے
        // کال کرنے والے کے ذریعہ ایک درست چارٹ ہوگا۔
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ اس سے زیادہ بہاو نہ ہو
        // چار کے لئے اقدار کی حد۔
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ اس سے زیادہ بہاو نہ ہو
            // چار کے لئے اقدار کی حد۔
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // حفاظت: پچھلے معاہدے کی وجہ سے ، اس کی ضمانت ہے
        // کال کرنے والے کے ذریعہ ایک درست چارٹ ہوگا۔
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // محفوظ کریں: ابھی جانچ پڑتال کی شرط
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // محفوظ کریں: ابھی جانچ پڑتال کی شرط
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// یہ میکروز مختلف قسم کی اقسام کے لئے `ExactSizeIterator` امپلیسس تیار کرتے ہیں۔
//
// * `ExactSizeIterator::len` ہمیشہ ایک عین مطابق `usize` واپس کرنے کی ضرورت ہوتی ہے ، لہذا کوئی رینج `usize::MAX` سے زیادہ لمبی نہیں ہوسکتی ہے۔
//
// * `Range<_>` میں عددی اقسام کے لئے ، یہ `usize` سے چھوٹی یا چوڑائی والی اقسام کا ہے۔
//   `RangeInclusive<_>` میں عددی اقسام کے ل X یہ مثال کے طور پر `usize` کے مقابلے میں *سختی سے تنگ* ہے
//   `(0..=u64::MAX).len()` `u64::MAX + 1` ہوگا۔
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // یہ مذکورہ بالا استدلال کے مطابق منحرف ہیں ، لیکن انہیں ہٹانا ایک وقفے میں تبدیلی ہوگی کیونکہ وہ Rust 1.0.0 میں مستحکم ہوئے تھے۔
    // تو جیسے
    // `(0..66_000_u32).len()` مثال کے طور پر 16 بٹ پلیٹ فارم پر بغیر کسی غلطی اور انتباہ کے مرتب کریں گے ، لیکن غلط نتیجہ دینا جاری رکھیں گے۔
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // یہ مندرجہ بالا استدلال کے مطابق الگ الگ ہیں ، لیکن انہیں ہٹانا ایک وقفے وقفے سے تبدیلی ہوگی کیونکہ وہ Rust 1.26.0 میں مستحکم ہوئے تھے۔
    // تو جیسے
    // `(0..=u16::MAX).len()` مثال کے طور پر 16 بٹ پلیٹ فارم پر بغیر کسی غلطی اور انتباہ کے مرتب کریں گے ، لیکن غلط نتیجہ دینا جاری رکھیں گے۔
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // محفوظ کریں: ابھی جانچ پڑتال کی شرط
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // محفوظ کریں: ابھی جانچ پڑتال کی شرط
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // محفوظ کریں: ابھی جانچ پڑتال کی شرط
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // محفوظ کریں: ابھی جانچ پڑتال کی شرط
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // محفوظ کریں: ابھی جانچ پڑتال کی شرط
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // محفوظ کریں: ابھی جانچ پڑتال کی شرط
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}