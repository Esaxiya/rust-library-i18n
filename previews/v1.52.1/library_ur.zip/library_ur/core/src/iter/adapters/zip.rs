use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// ایک ریڈیٹر جو بیک وقت دو دیگر تکرار دہندگان کو۔
///
/// یہ `struct` [`Iterator::zip`] کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // اشاریہ ، لین اور a_len صرف زپ کے خصوصی ورژن کے ذریعہ استعمال ہوتے ہیں
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // حفاظت: `ZipImpl::__iterator_get_unchecked` کی حفاظت ایک جیسی ہے
        // `Iterator::__iterator_get_unchecked` کے طور پر ضروریات.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// زپ کی تخصص trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // اس کی حفاظت کی وہی ضروریات ہیں جیسے `Iterator::__iterator_get_unchecked`
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// جنرل زپ امپیل
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // ایک ، بی سے برابر لمبائی ایڈجسٹ کریں
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // محفوظ: `i` `self.len` سے چھوٹا ہے ، اس طرح `self.a.len()` اور `self.b.len()` سے چھوٹا ہے
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // بیس پر عمل درآمد کے ممکنہ ضمنی اثرات سے سلامتی کا مقابلہ: ہم نے ابھی `i` <`self.a.len()` کی جانچ کی
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // محفوظ: `delta` کا حساب لگانے کے لئے `cmp::min` کا استعمال
                // اس بات کو یقینی بناتا ہے کہ `end` `self.len` سے چھوٹا یا اس کے برابر ہے ، لہذا `i` بھی `self.len` سے چھوٹا ہے۔
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // حفاظت: اوپر کی طرح.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // ایک ، بی کو مساوی لمبائی میں ایڈجسٹ کریں ، یہ یقینی بنائیں کہ `next_back` کی صرف پہلی کال ہی ایسا کرتی ہے ، بصورت دیگر ہم `get_unchecked()` پر کال کرنے کے بعد `self.next_back()` پر کالز پر پابندی کو توڑ دیں گے۔
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // محفوظ: `i` ، `self.len` کی پچھلی قیمت سے چھوٹا ہے ،
            // جو `self.a.len()` اور `self.b.len()` سے بھی چھوٹا یا اس کے برابر ہے
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // محفوظ: کال کرنے والے کو `Iterator::__iterator_get_unchecked` کا معاہدہ برقرار رکھنا چاہئے۔
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// غیر منطقی طور پر زپ کی تکرار کے بائیں جانب کو XtrX کے طور پر منتخب کرتا ہے اس میں دونوں کو آزمانے کے قابل ہونے کے ل negative منفی trait bounds کی ضرورت ہوگی۔
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // محفوظ: غیر محفوظ فنکشن کو اسی ضروریات کے ساتھ غیر محفوظ فعل میں بھیجنا
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// آئٹم تک محدود: چونکہ زپ کے ٹرسٹریڈ رینڈم ایکسیس کے استعمال اور ماخذ پر ڈراپ عمل درآمد کے مابین تعامل واضح نہیں ہے۔
//
// ماخذ کو منطقی طور پر پیش کیا گیا ہے اس کی تعداد کو واپس کرنے کا ایک اضافی طریقہ (next()) پر کال کیے بغیر وسیلہ کے بقیہ کو مناسب طریقے سے چھوڑنے کی ضرورت ہوگی۔
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // یہ موجود ہے کہ آپ ان تکرار کرنا شروع کردیں کیونکہ یہ ایک بار پھر تکرار کرنے لگے ہیں کہ وہ عجیب ، ممکنہ طور پر غیر محفوظ ہیں۔
        //
        f.debug_struct("Zip").finish()
    }
}

/// ایک ایسیٹر جس کی اشیاء بے ترتیب طور پر قابل رسائ موصول ہوں
///
/// # Safety
///
/// آئٹرٹر کا `size_hint` کال کرنے کے لئے قطعی اور سستا ہونا چاہئے۔
///
/// `size` غالبا. زیر اثر نہیں رہ سکتا ہے۔
///
/// `<Self as Iterator>::__iterator_get_unchecked` مندرجہ ذیل شرائط پوری ہوجائیں بشرطیکہ کال کرنے کے لئے محفوظ رہنا چاہئے۔
///
/// 1. `0 <= idx` اور `idx < self.size()`۔
/// 2. اگر `self: !Clone` ، تو `get_unchecked` کو ایک ہی انڈکس کے ساتھ `self` پر ایک سے زیادہ مرتبہ کبھی نہیں کہا جاتا ہے۔
/// 3. `self.get_unchecked(idx)` کے کال کرنے کے بعد پھر `next_back` زیادہ سے زیادہ `self.size() - idx - 1` اوقات میں ہی کہا جائے گا۔
/// 4. `get_unchecked` کے پکارنے کے بعد ، `self` پر صرف مندرجہ ذیل طریقے بلائے جائیں گے:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// مزید یہ کہ ان شرائط پر پورا اترنے کے بعد ، اس کی ضمانت بھی لازمی ہے کہ:
///
/// * یہ `size_hint` سے واپس کردہ قدر کو تبدیل نہیں کرتا ہے
/// * `get_unchecked` پر کال کرنے کے بعد `self` پر مذکورہ بالا طریقوں کو کال کرنا محفوظ سمجھنا چاہئے ، یہ فرض کرکے کہ مطلوبہ traits لاگو ہے۔
///
/// * `get_unchecked` پر کال کرنے کے بعد `self` چھوڑنا بھی محفوظ ہونا چاہئے۔
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // سہولت کا طریقہ۔
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` اگر آئٹرٹر عنصر ملنے کے مضر اثرات ہوسکتے ہیں۔
    /// اندرونی تکرار کرنے والوں کو خاطر میں رکھنا یاد رکھیں۔
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` کی طرح ، لیکن اس `U: TrustedRandomAccess` کو جاننے کے لئے مرتب کرنے والے کی ضرورت نہیں ہے۔
///
///
/// ## Safety
///
/// اسی طرح کی ضروریات جو `get_unchecked` کو براہ راست کال کرتی ہیں۔
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // محفوظ: کال کرنے والے کو `Iterator::__iterator_get_unchecked` کا معاہدہ برقرار رکھنا چاہئے۔
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// اگر `Self: TrustedRandomAccess` ہے تو ، `Iterator::__iterator_get_unchecked(self, index)` پر کال کرنا محفوظ ہونا چاہئے۔
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // محفوظ: کال کرنے والے کو `Iterator::__iterator_get_unchecked` کا معاہدہ برقرار رکھنا چاہئے۔
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}