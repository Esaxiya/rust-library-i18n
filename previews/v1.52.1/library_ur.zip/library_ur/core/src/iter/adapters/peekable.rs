use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// `peek()` والا آئٹرٹر جو اگلے عنصر کے لئے اختیاری حوالہ لوٹاتا ہے۔
///
///
/// یہ `struct` [`Iterator`] پر [`peekable`] طریقہ کے ذریعہ بنایا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// ایک جھانکنے والی قدر کو یاد رکھیں ، یہاں تک کہ اگر یہ کوئی بھی نہ تھا۔
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// جھانکنے والے کو یاد رکھنا چاہئے کہ کیا `.peek()` طریقہ میں کوئی نہیں دیکھا گیا ہے۔
// یہ یقینی بناتا ہے کہ `.peek()؛.peek();` یا `.peek()؛.next();` صرف ایک بار میں ہی بنیادی ریڈیٹر کو ترقی دیتا ہے۔
// یہ بذریعہ خود بار بار چلنے والے کو فیوز نہیں کرتا ہے۔
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// ایٹرٹر کو پیش قدمی کیے بغیر next() ویلیو کا حوالہ لوٹاتا ہے۔
    ///
    /// [`next`] کی طرح ، اگر کوئی قیمت ہے تو ، یہ `Some(T)` میں لپیٹ دی جاتی ہے۔
    /// لیکن اگر تکرار ختم ہوجائے تو ، `None` لوٹ آئے گا۔
    ///
    /// [`next`]: Iterator::next
    ///
    /// چونکہ `peek()` ایک حوالہ واپس کرتا ہے ، اور بہت سارے حوالہ دہندگان حوالوں سے اعادہ کرتے ہیں ، اس وجہ سے ممکنہ طور پر الجھاؤ والی صورتحال ہوسکتی ہے جہاں واپسی کی قیمت دوگنا حوالہ ہے۔
    /// آپ یہ اثر ذیل کی مثالوں میں دیکھ سکتے ہیں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ہمیں future میں دیکھنے کی اجازت دیتا ہے
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // اگر ہم متعدد بار `peek` کرتے ہیں تو بھی ایٹریٹر آگے نہیں بڑھتا ہے
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ریڈیٹر ختم ہونے کے بعد ، `peek()` بھی ہے
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// ایٹریٹر کو پیش قدمی کیے بغیر next() قدر کا ایک متغیر حوالہ واپس کرتا ہے۔
    ///
    /// [`next`] کی طرح ، اگر کوئی قیمت ہے تو ، یہ `Some(T)` میں لپیٹ دی جاتی ہے۔
    /// لیکن اگر تکرار ختم ہوجائے تو ، `None` لوٹ آئے گا۔
    ///
    /// چونکہ `peek_mut()` ایک حوالہ واپس کرتا ہے ، اور بہت سارے آئٹرس حوالوں سے اعادہ کرتے ہیں ، اس وجہ سے ممکنہ طور پر پریشان کن صورتحال پیدا ہوسکتی ہے جہاں واپسی کی قیمت دوگنا حوالہ ہے۔
    /// آپ یہ اثر ذیل کی مثالوں میں دیکھ سکتے ہیں۔
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` کی طرح ، ہم بھی زیٹر کو آگے بڑھے بغیر ، future میں دیکھ سکتے ہیں۔
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // تکرار کرنے والے کو جھانکیں اور متغیر حوالہ کے پیچھے قیمت مقرر کریں۔
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // جو قدر ہم نے دوبارہ رکھی ہے وہ دوبارہ چلنے کے ساتھ ہی جاری ہے۔
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// اگر کوئی حالت درست ہو تو اس دوبارہ کرنے والے کی اگلی قیمت استعمال کریں اور واپس کریں۔
    /// اگر `func` اس آئٹرٹر کی اگلی قیمت کے ل X `true` لوٹاتا ہے تو ، اسے استعمال کرکے واپس کردیں۔
    /// بصورت دیگر ، `None` واپس کریں۔
    /// # Examples
    /// ایک تعداد استعمال کریں اگر یہ 0 کے برابر ہے۔
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // مکرر کی پہلی شے 0 ہے۔اسے کھا لو۔
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // اگلی آئٹم واپس آئے اب 1 ہے ، لہذا `consume` `false` واپس کرے گا۔
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` اگلی آئٹم کی قدر کو بچاتا ہے اگر وہ `expected` کے برابر نہ ہو۔
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// کسی بھی تعداد کو 10 سے کم استعمال کریں۔
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // تمام نمبر 10 سے کم استعمال کریں
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // اگلی قیمت 10 ہو گی
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // چونکہ ہم نے `self.next()` کہا ، ہم نے `self.peeked` کھایا۔
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// اگلی آئٹم استعمال کریں اور واپس کردیں اگر یہ `expected` کے برابر ہے۔
    /// # Example
    /// ایک تعداد استعمال کریں اگر یہ 0 کے برابر ہے۔
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // مکرر کی پہلی شے 0 ہے۔اسے کھا لو۔
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // اگلی آئٹم واپس آئے اب 1 ہے ، لہذا `consume` `false` واپس کرے گا۔
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` اگلی آئٹم کی قدر کو بچاتا ہے اگر وہ `expected` کے برابر نہ ہو۔
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // محفوظ: غیر محفوظ فنکشن کو اسی ضروریات کے ساتھ غیر محفوظ فعل میں بھیجنا
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}