/// ایک ریڈیٹر جو اس کی درست لمبائی کو جانتا ہے۔
///
/// بہت سے [te Iterator`] s نہیں جانتے ہیں کہ وہ کتنی بار اعادہ کریں گے ، لیکن کچھ کرتے ہیں۔
/// اگر کوئی تکرار کرنے والا جانتا ہے کہ یہ کتنی بار دہرا سکتا ہے تو ، اس معلومات تک رسائی فراہم کرنا مفید ثابت ہوسکتا ہے۔
/// مثال کے طور پر ، اگر آپ پیچھے ہٹنا چاہتے ہیں تو ، ایک اچھی شروعات یہ جاننا ہوگی کہ آخر کہاں ہے۔
///
/// `ExactSizeIterator` لاگو کرتے وقت ، آپ کو [`Iterator`] بھی نافذ کرنا چاہئے۔
/// جب ایسا کرتے ہو تو ، [`Iterator::size_hint`]*کے نفاذ میں* دوبارہ کرنے والا کا عین مطابق سائز واپس کرنا ہوگا۔
///
/// [`len`] طریقہ کار میں پہلے سے طے شدہ عمل ہے ، لہذا آپ کو عام طور پر اس پر عمل درآمد نہیں کرنا چاہئے۔
/// تاہم ، آپ پہلے سے طے شدہ سے زیادہ پرفارمنس نفاذ فراہم کرنے کے قابل ہوسکتے ہیں ، لہذا اس معاملے میں اس کا جائزہ لینا معنی خیز ہے۔
///
///
/// نوٹ کریں کہ یہ trait ایک محفوظ trait ہے اور جیسا کہ *نہیں* اور * ضمانت نہیں دے سکتے کہ لوٹی ہوئی لمبائی درست ہے۔
/// اس کا مطلب ہے کہ `unsafe` کوڈ ** **[`Iterator::size_hint`] کی درستگی پر انحصار نہیں کرنا چاہئے۔
/// غیر مستحکم اور غیر محفوظ [`TrustedLen`](super::marker::TrustedLen) trait اس اضافی ضمانت دیتا ہے۔
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// // ایک محدود حد قطعی طور پر جانتی ہے کہ یہ کتنی بار دہرائے گا
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] میں ، ہم نے [`Iterator`] لاگو کیا ، `Counter`.
/// آئیے اس کے لئے بھی `ExactSizeIterator` لاگو کریں:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ہم تکرار کی باقی تعداد کا آسانی سے حساب لگاسکتے ہیں۔
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // اور اب ہم اسے استعمال کرسکتے ہیں!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// ریڈیٹر کی عین مطابق لمبائی لوٹاتا ہے۔
    ///
    /// نفاذ یقینی بناتا ہے کہ تکرار کرنے والا [`None`] واپس کرنے سے پہلے [`Some(T)`] قدر سے بالکل `len()` زیادہ بار لوٹائے گا۔
    ///
    /// اس طریقہ کار پر پہلے سے طے شدہ عمل درآمد ہوتا ہے ، لہذا آپ کو عام طور پر براہ راست اس پر عمل درآمد نہیں کرنا چاہئے۔
    /// تاہم ، اگر آپ زیادہ موثر عمل درآمد فراہم کرسکتے ہیں تو ، آپ ایسا کرسکتے ہیں۔
    /// ایک مثال کے لئے [trait-level] دستاویزات دیکھیں۔
    ///
    /// اس فنکشن میں وہی حفاظتی ضامن ہیں جیسے [`Iterator::size_hint`] فنکشن۔
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// // ایک محدود حد قطعی طور پر جانتی ہے کہ یہ کتنی بار دہرائے گا
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: یہ دعوی حد سے زیادہ دفاعی ہے ، لیکن یہ حملہ آور کو چیک کرتا ہے
        // trait کے ذریعہ ضمانت دی گئی ہے۔
        // اگر یہ trait rust داخلی ہوتا تو ہم ڈیبگ_اسٹرٹ استعمال کرسکتے ہیں۔assert_eq!تمام Rust صارف کے نفاذ کو بھی چیک کریں گے۔
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// اگر دوبارہ کرنے والا خالی ہو تو `true` لوٹاتا ہے۔
    ///
    /// [`ExactSizeIterator::len()`] کا استعمال کرتے ہوئے اس طریقہ کار پر پہلے سے طے شدہ عمل درآمد ہوتا ہے ، لہذا آپ کو خود اس پر عمل درآمد کرنے کی ضرورت نہیں ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}