// نظرانداز-فائل لینتھ یہ فائل تقریبا خصوصی طور پر `Iterator` کی تعریف پر مشتمل ہے۔
// ہم اسے متعدد فائلوں میں تقسیم نہیں کرسکتے ہیں۔
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// تکرار کرنے والوں سے نمٹنے کے لئے ایک انٹرفیس۔
///
/// یہ مین ریٹرٹر trait ہے۔
/// عام طور پر تکرار کرنے والوں کے تصور کے بارے میں مزید معلومات کے ل please ، براہ کرم [module-level documentation] دیکھیں۔
/// خاص طور پر ، آپ [implement `Iterator`][impl] کا طریقہ جاننا چاہتے ہو۔
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// عناصر کی قسم جس پر اعادہ کیا جارہا ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// تکرار کار کو آگے بڑھاتا ہے اور اگلی قیمت لوٹاتا ہے۔
    ///
    /// جب دوبارہ عمل ختم ہوجائے تو [`None`] لوٹاتا ہے۔
    /// انفرادی تکراری عمل درآمد دوبارہ شروع کرنے کا انتخاب کرسکتا ہے ، اور لہذا `next()` کو دوبارہ فون کرنا کسی وقت [`Some(Item)`] کو دوبارہ لوٹنا شروع کر سکتا ہے یا نہیں۔
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ایکس00 ایکس پر کال اگلی قیمت واپس کرے گی ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... اور پھر ختم ہونے کے بعد کوئی بھی نہیں۔
    /// assert_eq!(None, iter.next());
    ///
    /// // زیادہ کالز `None` واپس کر سکتی ہیں یا نہیں کر سکتی ہیں۔یہاں ، وہ ہمیشہ کریں گے۔
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// آئٹرٹر کی باقی لمبائی کی حدود لوٹاتا ہے۔
    ///
    /// خاص طور پر ، `size_hint()` ایک ٹپل واپس کرتا ہے جہاں پہلا عنصر کم باونڈ ہوتا ہے ، اور دوسرا عنصر اوپری باؤنڈ ہوتا ہے۔
    ///
    /// واپس آنے والے ٹپل کا دوسرا نصف حص [ہ [`آپشن`]`<`[`usize`] `>` ہے۔
    /// یہاں ایک [`None`] کا مطلب یہ ہے کہ یا تو کوئی اوپری باؤنڈ معلوم نہیں ہوتا ہے ، یا اوپری باؤنڈ [`usize`] سے بڑا ہے۔
    ///
    /// # عملدرآمد نوٹ
    ///
    /// یہ نفاذ نہیں کیا جاتا ہے کہ ایک تعی .ن عمل کرنے والے عناصر کی اعلان کردہ تعداد کو حاصل کرتا ہے۔چھوٹی چھوٹی سے دوبارہ چلانے والے کو کم حد سے کم یا عناصر کی بالائی حد سے زیادہ پیداوار مل سکتی ہے۔
    ///
    /// `size_hint()` بنیادی طور پر اصلاح کے ل used استعمال کرنے کا ارادہ ہے جیسے تکرار کرنے والے کے عناصر کے لئے جگہ محفوظ رکھنا ، لیکن اس پر بھروسہ نہیں کرنا چاہئے جیسے غیر محفوظ کوڈ میں حدود چیک کو چھوڑ دیں۔
    /// `size_hint()` کے غلط نفاذ سے میموری کی حفاظت کی خلاف ورزی نہیں ہوسکتی ہے۔
    ///
    /// اس نے کہا ، اس پر عمل درآمد کو ایک درست تخمینہ فراہم کرنا چاہئے ، کیونکہ بصورت دیگر یہ trait کے پروٹوکول کی خلاف ورزی ہوگی۔
    ///
    /// پہلے سے طے شدہ نفاذ `(0،` [`No``]`) returns واپس کرتا ہے جو کسی بھی تکرار کرنے والے کے لئے درست ہے۔
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// ایک اور پیچیدہ مثال:
    ///
    /// ```
    /// // یہاں تک کہ صفر سے دس تک کی تعداد۔
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ہم صفر سے دس بار بار بار ہو سکتے ہیں۔
    /// // یہ جاننا کہ یہ بالکل ٹھیک پانچ ہے filter() پر عمل کیے بغیر ممکن نہیں ہے۔
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // آئیے chain() کے ساتھ مزید پانچ تعداد شامل کریں
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // اب دونوں حدود میں پانچ کا اضافہ ہوا ہے
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// اوپری باؤنڈ کیلئے `None` واپس کرنا:
    ///
    /// ```
    /// // ایک لامحدود تکرار کرنے والا کا کوئی اوپری باؤنڈ اور زیادہ سے زیادہ ممکن حد تک کم باؤنڈ نہیں ہوتا ہے
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// تکرار کرنے والے کی تعداد گنتی ہے اور اسے لوٹتی ہے۔
    ///
    /// یہ طریقہ [`next`] کو بار بار فون کرے گا جب تک کہ [`None`] کا سامنا نہ ہو ، [`Some`] کو دیکھا جانے والی تعداد کو واپس کردیں۔
    /// نوٹ کریں کہ [`next`] کو کم از کم ایک بار فون کرنا پڑتا ہے یہاں تک کہ اگر اسٹر میں کوئی عنصر نہ ہو۔
    ///
    /// [`next`]: Iterator::next
    ///
    /// # اوور فلو سلوک
    ///
    /// یہ طریقہ اتنے بہاؤ سے کوئی حفاظت نہیں کرتا ہے ، لہذا [`usize::MAX`] سے زیادہ عناصر والے آئٹرٹر کے عنصروں کی گنتی غلط نتیجہ یا panics پیدا کرتی ہے۔
    ///
    /// اگر ڈیبگ کے دعوے قابل ہیں تو ، ایک panic کی ضمانت دی جاتی ہے۔
    ///
    /// # Panics
    ///
    /// اگر آئٹرٹر میں [`usize::MAX`] سے زیادہ عنصر ہوں تو یہ فنکشن panic ہوسکتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// آخری عنصر کو لوٹتے ہوئے ، آئٹرٹر استعمال کرتا ہے۔
    ///
    /// یہ طریقہ تکرار کرنے والے کا اندازہ کرے گا جب تک کہ وہ [`None`] واپس نہ آئے۔
    /// ایسا کرتے وقت ، یہ موجودہ عنصر کو ٹریک کرتا ہے۔
    /// [`None`] کی واپسی کے بعد ، `last()` پھر آخری عنصر جس نے دیکھا اسے لوٹائے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` عناصر کے ذریعہ ایٹریٹر کو آگے بڑھاتا ہے۔
    ///
    /// جب تک [`None`] کا سامنا نہ ہو اس وقت تک [`next`] تک [`next`] پر کال کرکے یہ طریقہ `n` عناصر کو بے تابی سے چھوڑ دے گا۔
    ///
    /// `advance_by(n)` اگر `n` عناصر کے ذریعہ ایٹریٹر کامیابی کے ساتھ پیش قدمی کرے ، یا [`Err(k)`][Err] اگر [`None`] کا سامنا کرنا پڑتا ہے تو ، [`Ok(())`][Ok] واپس کرے گا ، جہاں `k` عناصر کی تعداد ہے جس میں عناصر سے باہر چلنے سے پہلے تکرار کرنے والا جدید ہوتا ہے (جیسے۔
    /// تکرار کرنے والے کی لمبائی)۔
    /// نوٹ کریں کہ `k` ہمیشہ `n` سے کم ہوتا ہے۔
    ///
    /// `advance_by(0)` پر کال کرنے سے کوئی عنصر استعمال نہیں ہوتا ہے اور ہمیشہ ہی [`Ok(())`][Ok] کی واپسی ہوتی ہے۔
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // صرف `&4` کو چھوڑ دیا گیا تھا
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// آئٹرٹر کا element n` element عنصر لوٹاتا ہے۔
    ///
    /// زیادہ تر اشاریہ سازی کی کارروائیوں کی طرح ، گنتی بھی صفر سے شروع ہوتی ہے ، لہذا `nth(0)` پہلی قدر ، `nth(1)` دوسری ، اور اسی طرح کی واپسی کرتا ہے۔
    ///
    /// نوٹ کریں کہ تمام پچھلے عنصروں کے ساتھ ساتھ لوٹا ہوا عنصر بھی آئٹرٹر سے کھایا جائے گا۔
    /// اس کا مطلب یہ ہے کہ پچھلے عناصر کو ضائع کردیا جائے گا ، اور یہ بھی کہ `nth(0)` کو ایک ہی بار پر ایک سے زیادہ بار کال کرنے سے مختلف عناصر واپس آئیں گے۔
    ///
    ///
    /// `nth()` اگر `n` دوبارہ کرنے والے کی لمبائی سے زیادہ یا مساوی ہے تو [`None`] واپس کرے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// متعدد بار `nth()` کال کرنے سے دوبارہ کرنے والا دوبارہ نہیں پڑتا ہے۔
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// اگر `n + 1` سے بھی کم عناصر موجود ہوں تو `None` واپس کرنا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// ایک ہی نقطہ سے شروع ہونے والا ایک ایریٹر بناتا ہے ، لیکن ہر ایک تکرار پر دی گئی رقم سے قدم بڑھاتا ہے۔
    ///
    /// نوٹ 1: دیئے گئے قدم سے قطع نظر ، دوبارہ کرنے والا کا پہلا عنصر ہمیشہ لوٹائے گا۔
    ///
    /// نوٹ 2: نظر انداز کرنے والے عناصر کو کھینچنے کا وقت طے نہیں ہے۔
    /// `StepBy` ترتیب `next(), nth(step-1), nth(step-1),…` کی طرح برتاؤ کرتا ہے ، لیکن ترتیب کی طرح برتاؤ کرنے کے لئے بھی آزاد ہے
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// کارکردگی کی وجوہات کی بناء پر استعمال کرنے والے راستے کو کچھ تعی .ن کاروں کے لئے تبدیل کیا جاسکتا ہے۔
    /// دوسرا راستہ پہلے چلنے والے کو آگے بڑھائے گا اور زیادہ اشیاء استعمال کرسکتا ہے۔
    ///
    /// `advance_n_and_return_first` اس کے برابر ہے:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// اگر Zedspanic0Z طریقہ دیا جائے گا اگر دیئے جانے والا مرحلہ `0` ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// دو آئٹرٹر لیتا ہے اور دونوں کے مابین ایک نیا ریڈیٹر بناتا ہے۔
    ///
    /// `chain()` ایک نیا ریڈیٹر لوٹائے گا جو پہلے اوٹراٹر سے پہلے اقدار سے اور پھر دوسرے ریڈیٹر کی قدروں پر اعادہ کرے گا۔
    ///
    /// دوسرے لفظوں میں ، یہ ایک سلسلہ میں ، دو بار بازوں کو جوڑتا ہے۔🔗
    ///
    /// [`once`] عام طور پر ایک ہی قدر کو دوسری طرح کے تکرار کی زنجیر میں ڈھالنے کے لئے استعمال ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// چونکہ `chain()` کی دلیل [`IntoIterator`] کا استعمال کرتا ہے ، لہذا ہم کسی بھی ایسی چیز کو منتقل کرسکتے ہیں جسے [`Iterator`] میں تبدیل کیا جاسکتا ہے ، نہ کہ خود ایک [`Iterator`]۔
    /// مثال کے طور پر ، سلائسز (`&[T]`) [`IntoIterator`] کو لاگو کرتے ہیں ، اور اسی طرح براہ راست `chain()` پر بھیجا جاسکتا ہے:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// اگر آپ Windows API کے ساتھ کام کرتے ہیں تو ، آپ [`OsStr`] کو `Vec<u16>` میں تبدیل کرنا چاہتے ہیں۔
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// جوڑے کے ایک ہی ریڈیٹر میں دو آئٹروں کو 'زپ اپ' کریں۔
    ///
    /// `zip()` ایک نیا ریڈیٹر لوٹاتا ہے جو دو دیگر آئٹروں کے ساتھ تکرار کرتا ہے ، ایک ٹپل واپس کرتا ہے جہاں پہلا عنصر پہلے آئٹرٹر سے آتا ہے ، اور دوسرا عنصر دوسرے آئٹرٹر سے آتا ہے۔
    ///
    ///
    /// دوسرے لفظوں میں ، یہ ایک ساتھ میں دو تکرار کرنے والوں کو ایک ساتھ زپ کرتا ہے۔
    ///
    /// اگر یا تو آئٹرٹر [`None`] لوٹاتا ہے تو ، زپ ایٹریٹر سے [`next`] [`None`] لوٹائے گا۔
    /// اگر پہلا تکرار کرنے والا [`None`] واپس کرتا ہے تو ، `zip` شارٹ سرکٹ میں آئے گا اور دوسرے آئٹرٹر پر `next` نہیں بلایا جائے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// چونکہ `zip()` کی دلیل [`IntoIterator`] کا استعمال کرتا ہے ، لہذا ہم کسی بھی ایسی چیز کو منتقل کرسکتے ہیں جسے [`Iterator`] میں تبدیل کیا جاسکتا ہے ، نہ کہ خود ایک [`Iterator`]۔
    /// مثال کے طور پر ، سلائسز (`&[T]`) [`IntoIterator`] کو لاگو کرتے ہیں ، اور اسی طرح براہ راست `zip()` پر بھیجا جاسکتا ہے:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ایک لامتناہی تکرار کرنے والے کو اکثر کسی محدود حد تک زپ کرنے کے لئے استعمال ہوتا ہے۔
    /// یہ کام کرتا ہے کیوں کہ زائپر کو ختم کرتے ہوئے ، حد سے تکرار کرنے والا بالآخر [`None`] لوٹ آئے گا۔`(0..)` کے ساتھ زپ کرنا بہت زیادہ [`enumerate`] کی طرح نظر آسکتا ہے:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// ایک نیا ریڈیٹر بناتا ہے جو اصل آئٹرٹر کے ملحقہ آئٹمز کے درمیان `separator` کی ایک کاپی رکھتا ہے۔
    ///
    /// اگر `separator` [`Clone`] پر عمل درآمد نہیں کرتا ہے یا ہر بار حساب لگانے کی ضرورت ہے تو ، [`intersperse_with`] استعمال کریں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` سے پہلا عنصر۔
    /// assert_eq!(a.next(), Some(&100)); // جداکار۔
    /// assert_eq!(a.next(), Some(&1));   // `a` کا اگلا عنصر۔
    /// assert_eq!(a.next(), Some(&100)); // جداکار۔
    /// assert_eq!(a.next(), Some(&2));   // `a` کا آخری عنصر۔
    /// assert_eq!(a.next(), None);       // تکرار کرنے والا ختم ہوگیا۔
    /// ```
    ///
    /// `intersperse` ایک عام عنصر کا استعمال کرتے ہوئے ایک ریڈیٹر اشیاء میں شامل ہونے کے لئے بہت مفید ہوسکتا ہے:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// ایک نیا ریٹر تیار کرتا ہے جو اصل آئٹرٹر کے ملحقہ آئٹمز کے درمیان `separator` کے ذریعہ تیار کردہ کسی آئٹم کو رکھتا ہے۔
    ///
    /// بندش کو قطعی طور پر ایک بار کہا جائے گا جب ہر بار بنیادی آئٹرٹر سے دو ملحقہ اشیاء کے درمیان کوئی چیز رکھی جائے۔
    /// خاص طور پر ، اگر بندہ دو طرف سے کم اشیاء حاصل کرتا ہے اور آخری آئٹم برآمد ہونے کے بعد بندش نہیں کہا جاتا ہے۔
    ///
    ///
    /// اگر تکرار کرنے والے کی شے [`Clone`] لاگو کرتی ہے تو ، [`intersperse`] استعمال کرنا آسان ہوسکتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` سے پہلا عنصر۔
    /// assert_eq!(it.next(), Some(NotClone(99))); // جداکار۔
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` کا اگلا عنصر۔
    /// assert_eq!(it.next(), Some(NotClone(99))); // جداکار۔
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` سے آخری عنصر۔
    /// assert_eq!(it.next(), None);               // تکرار کرنے والا ختم ہوگیا۔
    /// ```
    ///
    /// `intersperse_with` ایسی صورتحال میں استعمال کیا جاسکتا ہے جہاں علیحدگیہ کی گنتی کی ضرورت ہو:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // بندش کسی شے کو تیار کرنے کے ل mut اس کے سیاق و سباق سے قرض لیتا ہے
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// ایک بندش لیتا ہے اور ایک ریڈیٹر تخلیق کرتا ہے جو ہر عنصر پر اس بند کو کہتے ہیں۔
    ///
    /// `map()` اس کی دلیل کے ذریعہ ، ایک ریڈیٹر کو دوسرے میں تبدیل کرتا ہے۔
    /// کچھ ایسی چیز جو [`FnMut`] لاگو کرتی ہے۔یہ ایک نیا ریٹر تیار کرتا ہے جو اصل بند کرنے والے کے ہر عنصر پر اس بند کو کہتے ہیں۔
    ///
    /// اگر آپ اقسام میں سوچنے میں اچھے ہیں تو ، آپ `map()` کے بارے میں اس طرح سوچ سکتے ہیں:
    /// اگر آپ کے پاس ایٹریٹر ہے جو آپ کو کسی قسم کے `A` کے عناصر فراہم کرتا ہے ، اور آپ کو کسی اور قسم `B` کا اعادہ کرنا چاہتے ہیں تو ، آپ `map()` استعمال کرسکتے ہیں ، ایک بندش گزرتے ہوئے جو `A` لیتا ہے اور `B` واپس کرتا ہے۔
    ///
    ///
    /// `map()` [`for`] لوپ کی طرح ہے۔تاہم ، چونکہ `map()` سست ہے ، جب آپ پہلے سے ہی دوسرے تکرار کرنے والوں کے ساتھ مل کر کام کر رہے ہو تو اس کا بہترین استعمال کیا جاتا ہے۔
    /// اگر آپ ضمنی اثرات کے لئے کسی طرح کی لوپنگ کررہے ہیں تو ، `map()` کے مقابلے میں [`for`] استعمال کرنا زیادہ محرک سمجھا جاتا ہے۔
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// اگر آپ کسی طرح کے ضمنی اثرات کر رہے ہیں تو ، [`for`] سے `map()` پر ترجیح دیں:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ایسا مت کریں:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // یہ عمل نہیں کرے گا ، کیوں کہ یہ سست ہے۔Rust اس کے بارے میں آپ کو متنبہ کرے گا۔
    ///
    /// // اس کے بجائے ، استعمال کریں:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// ایک آئٹرٹر کے ہر عنصر پر بندش کا مطالبہ کرتا ہے۔
    ///
    /// یہ آئٹرٹر پر [`for`] لوپ کے استعمال کے مترادف ہے ، اگرچہ بند ہونے سے `break` اور `continue` ممکن نہیں ہیں۔
    /// عام طور پر ایک `for` لوپ کو استعمال کرنے کے لئے زیادہ محاور ہے ، لیکن لمبا تکرار کرنے والی زنجیروں کے اختتام پر آئٹم پر کارروائی کرتے وقت `for_each` زیادہ سنجیدہ ہوسکتا ہے۔
    ///
    /// کچھ معاملات میں `for_each` بھی لوپ سے تیز تر ہوسکتا ہے ، کیونکہ یہ `Chain` جیسے اڈیپٹر پر داخلی تکرار استعمال کرے گا۔
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// اس طرح کی ایک چھوٹی سی مثال کے طور پر ، ایک `for` لوپ صاف ہوسکتا ہے ، لیکن `for_each` لمبا تکرار کرنے والوں کے ساتھ فنکشنل انداز رکھنے میں افضل ہوگا:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ایک ایٹریٹر بناتا ہے جو اس بات کا تعین کرنے کے لئے بندش کا استعمال کرتا ہے کہ عنصر کو برآمد ہونا چاہئے۔
    ///
    /// کسی عنصر کی وجہ سے بندش کو `true` یا `false` واپس کرنا ہوگا۔لوٹایا جانے والا دوبارہ صرف وہی عناصر برآمد کرے گا جس کے لئے بندش صحیح ثابت ہوگی۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// چونکہ `filter()` کو بند ہونے کا حوالہ لیتا ہے ، اور بہت سے تکرار کرنے والے حوالوں سے اعادہ کرتے ہیں ، اس وجہ سے ممکنہ طور پر الجھنے والی صورتحال پیدا ہوتی ہے ، جہاں بند ہونے کی نوعیت دوہرا حوالہ ہے۔
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // دو * کی ضرورت ہے!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// دلیل پر ڈسٹریکچرنگ کا استعمال عام کرنا عام ہے۔
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // دونوں اور *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// یا دونوں:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // دو &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ان تہوں میں سے
    ///
    /// نوٹ کریں کہ `iter.filter(f).next()` `iter.find(f)` کے برابر ہے۔
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// فلٹر اور نقشے دونوں ہی ایک ایٹریٹر بناتا ہے۔
    ///
    /// لوٹا ہوا آئٹرٹر صرف the قدر `حاصل کرتا ہے جس کے لئے فراہم کردہ بندش `Some(value)` واپس کرتا ہے۔
    ///
    /// `filter_map` [`filter`] اور [`map`] کی زنجیریں بنانے کے ل used استعمال کیا جاسکتا ہے۔
    /// ذیل کی مثال سے پتہ چلتا ہے کہ کس طرح ایک `map().filter().map()` کو `filter_map` پر ایک ہی کال پر مختصر کیا جاسکتا ہے۔
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// یہاں ایک ہی مثال ہے ، لیکن [`filter`] اور [`map`] کے ساتھ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// ایک ایٹریٹر بناتا ہے جو موجودہ اعداد شمار کے ساتھ ساتھ اگلی قیمت بھی دیتا ہے۔
    ///
    /// ایٹریٹر نے جوڑا `(i, val)` حاصل کیا ، جہاں `i` تکرار کا حالیہ انڈیکس ہے اور `val` وہی قدر ہے جو آئٹرٹر کے ذریعہ لوٹائی گئی ہے۔
    ///
    ///
    /// `enumerate()` اس کی گنتی ایک [`usize`] کے طور پر کرتی ہے۔
    /// اگر آپ مختلف سائز کے عددی اعتبار سے گننا چاہتے ہیں تو ، [`zip`] فنکشن اسی طرح کی فعالیت فراہم کرتا ہے۔
    ///
    /// # اوور فلو سلوک
    ///
    /// یہ طریقہ اتنے بہاؤ سے کوئی حفاظت نہیں کرتا ہے ، لہذا [`usize::MAX`] سے زیادہ عناصر کا حساب لگانے سے یا تو غلط نتیجہ یا panics پیدا ہوتا ہے۔
    /// اگر ڈیبگ کے دعوے قابل ہیں تو ، ایک panic کی ضمانت دی جاتی ہے۔
    ///
    /// # Panics
    ///
    /// اگر لوٹائے جانے والا انڈیکس ایک [`usize`] کو بہا لے جائے گا تو لوٹنے والا دوبارہ کرنے والا panic ہوسکتا ہے۔
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// ایک ایٹریٹر بناتا ہے جو [`peek`] استعمال کرکے دوبارہ استعمال کرنے والے کے اگلے عنصر کو دیکھنے کے ل. استعمال کرسکتا ہے۔
    ///
    /// ایک ویٹر میں ایک [`peek`] طریقہ شامل کرتا ہے۔مزید معلومات کے لئے اس کی دستاویزات دیکھیں۔
    ///
    /// نوٹ کریں کہ جب پہلی بار [`peek`] طلب کیا گیا ہے تو بنیادی ڈوکیٹر ابھی بھی اعلی درجے کی ہے: اگلے عنصر کو بازیافت کرنے کے لئے ، [`next`] کو بنیادی ریٹرائٹر پر بلایا جاتا ہے ، لہذا کوئی ضمنی اثرات (جیسے۔
    ///
    /// [`next`] طریقہ کی اگلی قیمت لانے کے علاوہ اور کچھ بھی ہوگا۔
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ہمیں future میں دیکھنے کی اجازت دیتا ہے
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ہم ایک سے زیادہ بار peek() کرسکتے ہیں ، دوبارہ کرنے والا آگے نہیں بڑھتا ہے
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ریڈیٹر ختم ہونے کے بعد ، peek() بھی ہے
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// ایک ایریٹر بناتا ہے جو [`skip`] کے عناصر کی پیش گوئی پر مبنی ہوتا ہے۔
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ایک دلیل کے طور پر ایک بند لے جاتا ہے.یہ بند کرنے والے کو ہر عنصر پر یہ بند کرے گا ، اور جب تک کہ وہ `false` واپس نہیں کرے تب تک عناصر کو نظرانداز کرے گا۔
    ///
    /// `false` کی واپسی کے بعد ، `skip_while()`'s نوکری ختم ہوچکی ہے ، اور باقی عناصر برآمد ہوجاتے ہیں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// چونکہ `skip_while()` کو بند ہونے کا حوالہ لیتا ہے ، اور بہت سارے تکرار حوالوں سے اعادہ کرتے ہیں ، اس وجہ سے ممکنہ طور پر الجھاؤ والی صورتحال پیدا ہوجاتی ہے ، جہاں بند ہونے کی دلیل کی طرح ایک دوہرا حوالہ ہے۔
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // دو * کی ضرورت ہے!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ابتدائی `false` کے بعد رکنا:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // اگرچہ یہ غلط ہوگا ، چونکہ ہم پہلے ہی غلط ہو چکے ہیں ، skip_while() مزید استعمال نہیں ہوتا ہے
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ایک ایٹریٹر بناتا ہے جو پیش گوئی پر مبنی عناصر برآمد کرتا ہے۔
    ///
    /// `take_while()` ایک دلیل کے طور پر ایک بند لے جاتا ہے.یہ اس بندش کو آئٹرٹر کے ہر عنصر پر کال کرے گا ، اور عناصر کو برآمد کرے گا جب کہ وہ `true` واپس کرے گا۔
    ///
    /// `false` کی واپسی کے بعد ، `take_while()`'s نوکری ختم ہوگئی ، اور باقی عناصر کو نظرانداز کردیا گیا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// چونکہ `take_while()` کو بند ہونے کا حوالہ لیتا ہے ، اور بہت سے تکرار کرنے والے حوالوں سے اعادہ کرتے ہیں ، اس وجہ سے ممکنہ طور پر الجھنے والی صورتحال پیدا ہوتی ہے ، جہاں بند ہونے کی نوعیت دوہرا حوالہ ہے۔
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // دو * کی ضرورت ہے!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ابتدائی `false` کے بعد رکنا:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // ہمارے پاس اور بھی ایسے عناصر موجود ہیں جو صفر سے کم ہیں ، لیکن چونکہ ہمارے پاس پہلے سے ہی غلط ہوچکا ہے ، take_while() مزید استعمال نہیں ہوا ہے
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// چونکہ `take_while()` کو یہ دیکھنے کے ل the کہ قدر کو دیکھنے کی ضرورت ہے کہ آیا اس میں شامل ہونا چاہئے یا نہیں ، لہذا استعمال کرنے والے یہ دیکھیں گے کہ اسے ہٹا دیا گیا ہے:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` اب موجود نہیں ہے ، کیونکہ یہ استعمال کرنے کے لئے کھایا گیا تھا کہ آیا اعداد رکنا بند ہوجائے ، لیکن اسے دوبارہ چلانے والے میں نہیں رکھا گیا تھا۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// ایک ایٹریٹر بناتا ہے جس سے دونوں پیش گوئی اور نقشوں پر مبنی عناصر برآمد کرتے ہیں۔
    ///
    /// `map_while()` ایک دلیل کے طور پر ایک بند لے جاتا ہے.
    /// یہ اس بندش کو آئٹرٹر کے ہر عنصر پر کال کرے گا ، اور عناصر کو برآمد کرے گا جب کہ وہ [`Some(_)`][`Some`] واپس کرے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// یہاں ایک ہی مثال ہے ، لیکن [`take_while`] اور [`map`] کے ساتھ:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ابتدائی [`None`] کے بعد رکنا:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // ہمارے پاس اور بھی عنصر موجود ہیں جو u32 (4 ، 5) میں فٹ بیٹھ سکتے ہیں ، لیکن `map_while` نے `None` کو `-3` (`predicate` نے `None` کو لوٹایا) کے طور پر واپس کردیا اور `collect` کا سامنا کرنا پڑا پہلے `None` پر رک گیا۔
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// چونکہ `map_while()` کو یہ دیکھنے کے ل the کہ قدر کو دیکھنے کی ضرورت ہے کہ آیا اس میں شامل ہونا چاہئے یا نہیں ، لہذا استعمال کرنے والے یہ دیکھیں گے کہ اسے ہٹا دیا گیا ہے:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` اب موجود نہیں ہے ، کیونکہ یہ استعمال کرنے کے لئے کھایا گیا تھا کہ آیا اعداد رکنا بند ہوجائے ، لیکن اسے دوبارہ چلانے والے میں نہیں رکھا گیا تھا۔
    ///
    /// نوٹ کریں کہ [`take_while`] کے برعکس یہ ریڈیٹر **نہیں** فیوز ہے۔
    /// یہ بھی واضح نہیں ہے کہ پہلے [`None`] کے واپس آنے کے بعد یہ دوبارہ کرنے والا کیا واپس کرتا ہے۔
    /// اگر آپ کو فیوز ایٹریٹر کی ضرورت ہو تو ، [`fuse`] استعمال کریں۔
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// ایک ایٹریٹر بناتا ہے جو پہلے `n` عنصر کو چھوڑ دیتا ہے۔
    ///
    /// ان کے کھانے کے بعد ، باقی عناصر حاصل ہوجاتے ہیں۔
    /// اس طریقہ کو براہ راست اوور رائیڈ کرنے کے بجائے ، `nth` طریقہ کو اوور رائیڈ کریں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// ایک ایٹریٹر بناتا ہے جو اس کے پہلے `n` عنصر برآمد کرتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` اس کو محدود کرنے کے ل often ، اکثر ایک لامحدود تکرار کرنے والا کے ساتھ استعمال ہوتا ہے:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// اگر `n` سے بھی کم عناصر دستیاب ہوں تو ، `take` خود کو بنیادی ریٹرٹر کے سائز تک محدود کردے گا:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] جیسا ہی ایک ایٹریٹر اڈاپٹر جو اندرونی حالت رکھتا ہے اور ایک نیا ریٹر تیار کرتا ہے۔
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` دو دلائل لیتا ہے: ایک ابتدائی قیمت جس میں داخلی حالت کا بیج ہوتا ہے ، اور دو دلائل کے ساتھ بندش ، پہلی داخلی حالت کا تغیر پذیر حوالہ اور دوسرا تکرار عنصر۔
    ///
    /// بندش داخلی حالت کو تفویض کرسکتی ہے کہ تکرار کے مابین ریاست کا اشتراک کریں۔
    ///
    /// تکرار کرنے پر ، بندش کا اطلاق آئٹرٹر کے ہر عنصر پر ہوگا اور بندش سے واپسی کی قیمت ، ایک [`Option`] ، آئٹرٹر کے ذریعہ حاصل ہوگی۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ہر تکرار ، ہم عنصر کے ذریعہ ریاست کو ضرب دیں گے
    ///     *state = *state * x;
    ///
    ///     // تب ، ہم ریاست کی نفی حاصل کریں گے
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// ایک ایٹریٹر بناتا ہے جو نقشہ کی طرح کام کرتا ہے ، لیکن گھریلو ڈھانچے کو چپٹا دیتا ہے۔
    ///
    /// [`map`] اڈاپٹر بہت مفید ہے ، لیکن صرف اس صورت میں جب بند ہونے کی دلیل سے اقدار پیدا ہوں۔
    /// اگر اس کی بجائے اسٹر کو پیدا کرتا ہے تو ، اندیشے کی ایک اضافی پرت ہے۔
    /// `flat_map()` اس اضافی پرت کو خود ہی ختم کردے گی۔
    ///
    /// آپ `flat_map(f)` کے بارے میں [`map`] پنگ کے معنی مساوی اور پھر [` فلیٹین] کے طور پر `map(f).flatten()` کی طرح سوچ سکتے ہیں۔
    ///
    /// `flat_map()` کے بارے میں سوچنے کا ایک اور طریقہ: [`map`] کی بندش ہر عنصر کے لئے ایک آئٹم لوٹاتی ہے ، اور `flat_map()`'s کی بندش ہر عنصر کے لئے ایک ریڈیٹر لوٹاتی ہے۔
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ایک ریڈیٹر لوٹاتا ہے
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// ایک ایسیٹر تیار کرتا ہے جو گھریلو ڈھانچے کو چپٹا کرتا ہے۔
    ///
    /// یہ اس وقت کارآمد ہے جب آپ کے پاس ریڈیٹرس کی چیزیں ہوں یا ایسی چیزوں کا ایٹریٹر ہو جو ایٹریٹر میں تبدیل ہوسکتے ہیں اور آپ اندرا کی ایک سطح کو دور کرنا چاہتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// نقشہ سازی اور پھر چپٹا ہونا:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ایک ریڈیٹر لوٹاتا ہے
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// آپ اسے [`flat_map()`] کے لحاظ سے بھی دوبارہ لکھ سکتے ہیں ، جو اس معاملے میں افضل ہے کیونکہ اس سے یہ زیادہ واضح طور پر ارادے کو پیش کرتا ہے:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ایک ریڈیٹر لوٹاتا ہے
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// چاپلوسی کرنا ایک وقت میں گھوںسلا کے صرف ایک درجے کو ہٹا دیتا ہے:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// یہاں ہم دیکھتے ہیں کہ `flatten()` "deep" فلیٹ کو انجام نہیں دیتا ہے۔
    /// اس کے بجائے ، گھوںسلی کے صرف ایک درجے کو ہٹا دیا گیا ہے۔یعنی ، اگر آپ ایک سہ جہتی صف کو `flatten()` کرتے ہیں تو ، نتیجہ دو جہتی ہوگا اور ایک جہتی نہیں۔
    /// ایک جہتی ڈھانچہ حاصل کرنے کے ل you ، آپ کو دوبارہ `flatten()` کرنا پڑے گا۔
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ایک ایٹریٹر بناتا ہے جو پہلے [`None`] کے بعد ختم ہوتا ہے۔
    ///
    /// ایک آئریٹر کے [`None`] کی واپسی کے بعد ، زیڈ فیوچر0 زیڈ کالز ایک بار پھر [`Some(T)`] برآمد کرسکتی ہیں یا نہیں کر سکتی ہیں۔
    /// `fuse()` ایک ریڈیٹر کو اپناتا ہے ، اس بات کو یقینی بناتا ہے کہ [`None`] دینے کے بعد ، یہ ہمیشہ کے لئے [`None`] ہمیشہ کے لئے لوٹائے گا۔
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// // ایک تکرار کرنے والا جو کچھ اور کسی کے درمیان متبادل نہیں ہوتا ہے
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // اگر یہ بھی ہے تو ، Some(i32) ، اور کوئی نہیں
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ہم دیکھ سکتے ہیں کہ ہمارا اعرابی آگے پیچھے ہوتا جارہا ہے
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // تاہم ، ایک بار جب ہم اسے فیوز ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // یہ پہلی بار کے بعد ہمیشہ `None` لوٹائے گا۔
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// قدر کو آگے بڑھاتے ہوئے ، ایک ریڈیٹر کے ہر عنصر کے ساتھ کچھ کرتا ہے۔
    ///
    /// تکرار کرنے والوں کا استعمال کرتے وقت ، آپ اکثر ان میں سے کئی ایک ساتھ جکڑے جاتے ہیں۔
    /// اس طرح کے کوڈ پر کام کرنے کے دوران ، آپ یہ چیک کرنا چاہیں گے کہ پائپ لائن کے مختلف حصوں میں کیا ہو رہا ہے۔ایسا کرنے کیلئے ، `inspect()` پر کال داخل کریں۔
    ///
    /// آپ کے آخری کوڈ میں موجود ہونے کے بجائے `inspect()` کو ڈیبگنگ ٹول کے طور پر استعمال کرنا زیادہ عام ہے ، لیکن ایپلیکیشنز کو کچھ خاص حالتوں میں کارآمد ثابت ہوسکتا ہے جب غلطیوں کو ضائع کرنے سے پہلے لاگ ان کرنے کی ضرورت ہوتی ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // یہ دوبارہ کرنے والا ترتیب پیچیدہ ہے۔
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // آئیے کیا ہو رہا ہے اس کی تحقیقات کے لئے کچھ inspect() کالیں شامل کریں
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// یہ پرنٹ کرے گا:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// غلطیوں کو ختم کرنے سے پہلے لاگ ان کریں:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// یہ پرنٹ کرے گا:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// اس کو استعمال کرنے کی بجائے ایک آئٹرٹر لیتے ہیں۔
    ///
    /// یہ پھر بھی اصل آئٹرٹر کی ملکیت برقرار رکھنے کے دوران ایٹریٹر اڈاپٹر کو استعمال کرنے کی اجازت دینے کے لئے مفید ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // اگر ہم دوبارہ ایٹر استعمال کرنے کی کوشش کرتے ہیں تو ، یہ کام نہیں کرے گا۔
    /// // مندرجہ ذیل لائن "غلطی دیتی ہے: منتقل شدہ قیمت کا استعمال: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // آئیے دوبارہ کوشش کریں
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // اس کے بجائے ، ہم ایک .by_ref() میں شامل کریں
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // اب یہ ٹھیک ہے:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// ایک ایٹریٹر کو ایک مجموعہ میں تبدیل کرتا ہے۔
    ///
    /// `collect()` قابل تکرار چیزیں لے سکتے ہیں اور اسے متعلقہ مجموعہ میں تبدیل کر سکتے ہیں۔
    /// یہ معیاری لائبریری کا ایک زیادہ طاقتور طریقہ ہے ، جو متعدد سیاق و سباق میں استعمال ہوتا ہے۔
    ///
    /// سب سے بنیادی نمونہ جس میں `collect()` استعمال کیا جاتا ہے وہ یہ ہے کہ ایک مجموعہ کو دوسرے میں تبدیل کیا جائے۔
    /// آپ ایک مجموعہ لیتے ہیں ، اس پر [`iter`] پر کال کریں ، تبادلوں کا ایک گروپ کریں ، اور پھر آخر میں `collect()`۔
    ///
    /// `collect()` ایسی اقسام کی مثال بھی بنا سکتے ہیں جو عام مجموعہ نہیں ہیں۔
    /// مثال کے طور پر ، [`چار`] s سے ایک [`String`] بنایا جاسکتا ہے ، اور [`Result<T, E>`][`Result`] آئٹمز کا ایک ایٹریٹر `Result<Collection<T>, E>` میں جمع کیا جاسکتا ہے۔
    ///
    /// مزید کے لئے ذیل میں مثالیں ملاحظہ کریں.
    ///
    /// چونکہ `collect()` بہت عام ہے ، لہذا اس کی وجہ سے قسم کی تشخیص میں پریشانی پیدا ہوسکتی ہے۔
    /// اس طرح ، `collect()` ان چند بار میں سے ایک ہے جو آپ نحو کو پیار کے ساتھ 'turbofish' کے نام سے جانا جاتا دیکھیں گے۔ `::<>`.
    /// اس سے اندازہ الگورتھم کو خاص طور پر یہ سمجھنے میں مدد ملتی ہے کہ آپ کس ذخیرے میں جمع کرنے کی کوشش کر رہے ہیں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// نوٹ کریں کہ ہمیں بائیں طرف `: Vec<i32>` کی ضرورت تھی۔اس کی وجہ یہ ہے کہ ہم اس کی بجائے ایک [`VecDeque<T>`] جمع کرسکتے ہیں:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` کو تشریح کرنے کے بجائے 'turbofish' کا استعمال کریں:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// چونکہ `collect()` صرف اس بات کی پرواہ کرتا ہے جس میں آپ جمع کررہے ہیں ، لہذا آپ ابھی بھی جزوی قسم کا اشارہ ، `_` ، ٹربو فش کے ساتھ استعمال کرسکتے ہیں۔
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] بنانے کے لئے `collect()` کا استعمال:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// اگر آپ کے پاس [`نتائج کی فہرست موجود ہے<T, E>`][`نتائج`] s ، آپ یہ دیکھنے کے لئے `collect()` استعمال کرسکتے ہیں کہ آیا ان میں سے کوئی ناکام ہوا:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ہمیں پہلی غلطی فراہم کرتا ہے
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ہمیں جوابات کی فہرست فراہم کرتا ہے
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// اس سے دو مجموعے تخلیق کرتے ہوئے ، ایک ایٹریٹر استعمال کرتا ہے۔
    ///
    /// `partition()` کو منظور شدہ پیشکیہ `true` ، یا `false` واپس کرسکتا ہے۔
    /// `partition()` ایک جوڑی ، سبھی عناصر جن کے لئے اس نے `true` لوٹایا ، اور وہ تمام عناصر جن کے لئے اس نے `false` لوٹایا ، واپس کرتا ہے۔
    ///
    ///
    /// [`is_partitioned()`] اور [`partition_in_place()`] بھی دیکھیں۔
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// اس آئریٹر کے عناصر کو دیئے گئے پیش گوئی کے مطابق * * جگہ * پر دوبارہ ترتیب دیتا ہے ، جیسا کہ `true` کو واپس کرنے والے تمام `false` واپس آنے والے تمام لوگوں سے پہلے ہیں۔
    ///
    /// پائے گئے `true` عناصر کی تعداد لوٹاتا ہے۔
    ///
    /// منقسم اشیاء کی رشتہ دار ترتیب برقرار نہیں ہے۔
    ///
    /// [`is_partitioned()`] اور [`partition()`] بھی دیکھیں۔
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // شام اور مشکلات کے درمیان جگہ جگہ تقسیم ہونا
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: کیا ہمیں گنتی کے بہہ جانے کی فکر کرنی چاہئے؟اس سے زیادہ حاصل کرنے کا واحد طریقہ
        // `usize::MAX` تغیر پزیر حوالہ جات ZSTs کے ساتھ ہیں ، جو تقسیم کے لئے کارآمد نہیں ہیں ...

        // یہ بند "factory" افعال `Self` میں سخاوت سے بچنے کے لئے موجود ہیں۔

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // بار بار پہلا `false` تلاش کریں اور اسے آخری `true` کے ساتھ تبدیل کریں۔
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// جانچ پڑتال کرتا ہے کہ آیا اس آیتریٹر کے عناصر کو دیئے گئے پیشنٹ کے مطابق تقسیم کیا گیا ہے ، جیسے کہ `true` کو واپس کرنے والے تمام `false` کو واپس کرنے والے سب سے پہلے۔
    ///
    ///
    /// [`partition()`] اور [`partition_in_place()`] بھی دیکھیں۔
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // یا تو تمام آئٹمز `true` کی جانچ کرتے ہیں ، یا پہلی شق `false` پر رک جاتی ہے اور ہم چیک کرتے ہیں کہ اس کے بعد `true` آئٹمز کی کوئی اور چیز نہیں ہے۔
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ایک تکرار کرنے والا طریقہ جو ایک فنکشن کا اطلاق اس وقت تک ہوتا ہے جب تک کہ وہ کامیابی سے واپس آئے ، ایک واحد ، حتمی قیمت تیار کرے۔
    ///
    /// `try_fold()` دو دلائل لیتا ہے: ایک ابتدائی قیمت ، اور دو دلائل کے ساتھ بند ہونا: ایک 'accumulator' ، اور ایک عنصر۔
    /// بندش یا تو کامیابی کے ساتھ واپس آجاتی ہے ، جس قدر کے ساتھ جمع کرنے والے کو اگلی تکرار کے ل have ہونا چاہئے ، یا یہ خرابی کی قیمت کے ساتھ ، ناکامی کو واپس کرتا ہے جو فون کرنے والے کو فوری طور پر ایکس00 ایکس تک پھیلاتا ہے۔
    ///
    ///
    /// ابتدائی قدر وہ قیمت ہے جو جمع کرنے والے کی پہلی کال پر ہوگی۔اگر بندش کو لاگو کرنے سے قیامت کے ہر عنصر کے خلاف کامیاب ہو گیا تو ، `try_fold()` حتمی جمع کو کامیابی کے طور پر واپس کرتا ہے۔
    ///
    /// جب بھی آپ کے پاس کسی چیز کا ذخیرہ ہوتا ہے تو فولڈنگ کارآمد ہوتی ہے ، اور اس سے ایک ہی قدر پیدا کرنا چاہتے ہیں۔
    ///
    /// # نفاذ کرنے والوں کو نوٹ کریں
    ///
    /// دوسرے بہت سے (forward) طریقوں میں اس کے لحاظ سے پہلے سے طے شدہ نفاذ ہیں ، لہذا اس کو واضح طور پر نافذ کرنے کی کوشش کریں اگر یہ پہلے سے طے شدہ `for` لوپ پر عملدرآمد سے کچھ بہتر کرسکتا ہے۔
    ///
    /// خاص طور پر ، کوشش کریں کہ یہ کال `try_fold()` ان داخلی حصوں پر کی جائے جہاں سے یہ ریڈیٹر تشکیل دیا گیا ہو۔
    /// اگر متعدد کالوں کی ضرورت ہو تو ، `?` آپریٹر اکولیٹر ویلیو کے ساتھ ساتھ سلسلہ بندی کرنے کے ل convenient آسان ہوسکتا ہے ، لیکن کسی بھی حملہ آور سے ہوشیار رہیں جن کی واپسی سے قبل ان کی بحالی کی ضرورت ہو۔
    /// یہ ایک `&mut self` طریقہ ہے ، لہذا یہاں کسی غلطی کو نشانہ بنانے کے بعد تکرار دوبارہ شروع کرنے کی ضرورت ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // سرنی کے تمام عناصر کا چیک کیا ہوا جوڑ
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // یہ عنصر 100 عنصر شامل کرتے وقت بہہ جاتا ہے
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // چونکہ یہ مختصر گردش میں ہے ، باقی عناصر ابھی بھی دوبارہ چلانے والے کے ذریعہ دستیاب ہیں۔
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ایک تکرار کرنے والا طریقہ جو آئٹرٹر میں ہر آئٹم پر ایک غلط فعل کا اطلاق کرتا ہے ، پہلی غلطی پر رک جاتا ہے اور اس غلطی کو لوٹاتا ہے۔
    ///
    ///
    /// اس کے بارے میں [`for_each()`] کی ناقص شکل یا [`try_fold()`] کے سٹیٹلیس ورژن کے طور پر بھی سوچا جاسکتا ہے۔
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // یہ مختصر گردش میں ہوا ، لہذا باقی اشیاء ابھی بھی دوبارہ چلانے والے میں موجود ہیں۔
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// کسی عمل کو لاگو کرکے ، حتمی نتیجہ کو لوٹاتے ہوئے ، ہر عنصر کو اکولیٹر میں جوڑتا ہے۔
    ///
    /// `fold()` دو دلائل لیتا ہے: ایک ابتدائی قیمت ، اور دو دلائل کے ساتھ بند ہونا: ایک 'accumulator' ، اور ایک عنصر۔
    /// بندش سے وہ قیمت آجاتی ہے جو جمع کرنے والی کو اگلی تکرار کے ل should ہونا چاہئے۔
    ///
    /// ابتدائی قدر وہ قیمت ہے جو جمع کرنے والے کی پہلی کال پر ہوگی۔
    ///
    /// اس بندش کو ایٹریٹر کے ہر عنصر پر لاگو کرنے کے بعد ، `fold()` جمع کرنے والا واپس کرتا ہے۔
    ///
    /// اس آپریشن کو کبھی کبھی 'reduce' یا 'inject' کہا جاتا ہے۔
    ///
    /// جب بھی آپ کے پاس کسی چیز کا ذخیرہ ہوتا ہے تو فولڈنگ کارآمد ہوتی ہے ، اور اس سے ایک ہی قدر پیدا کرنا چاہتے ہیں۔
    ///
    /// Note: `fold()` ، اور اسی طرح کے طریقے جو پورے آئٹرٹر کو عبور کرتے ہیں ، لامحدود اعداد کاروں کے لئے ختم نہیں ہوسکتے ہیں ، یہاں تک کہ traits پر بھی ، جس کے لئے کوئی نتیجہ طے شدہ وقت میں طے ہوتا ہے۔
    ///
    /// Note: ابتدائی قدر کے طور پر پہلے عنصر کو استعمال کرنے کے لئے [`reduce()`] کا استعمال کیا جاسکتا ہے ، اگر جمع کرنے والا قسم اور اشیاء کی قسم ایک جیسی ہو۔
    ///
    /// # نفاذ کرنے والوں کو نوٹ کریں
    ///
    /// دوسرے بہت سے (forward) طریقوں میں اس کے لحاظ سے پہلے سے طے شدہ نفاذ ہیں ، لہذا اس کو واضح طور پر نافذ کرنے کی کوشش کریں اگر یہ پہلے سے طے شدہ `for` لوپ پر عملدرآمد سے کچھ بہتر کرسکتا ہے۔
    ///
    ///
    /// خاص طور پر ، کوشش کریں کہ یہ کال `fold()` ان داخلی حصوں پر کی جائے جہاں سے یہ ریڈیٹر تشکیل دیا گیا ہو۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // سرنی کے تمام عناصر کا مجموعہ
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// آئیے یہاں تکلیف کے ہر ایک قدم پر چلتے ہیں۔
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// اور اسی طرح ، ہمارا آخری نتیجہ ، `6`.
    ///
    /// یہ ان لوگوں کے لئے عام ہے جنہوں نے نتیجہ بنانے کے ل things چیزوں کی فہرست کے ساتھ `for` لوپ کو استعمال کرنے کے لئے تکرار کرنے والوں کو بہت زیادہ استعمال نہیں کیا ہے۔جن کو `fold()`s میں تبدیل کیا جاسکتا ہے:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // لوپ کے لئے:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // وہ ایک جیسے ہیں
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// بار بار کم کرنے والے آپریشن کو لاگو کرکے ، عناصر کو ایک میں گھٹاتا ہے۔
    ///
    /// اگر ریڈیٹر خالی ہے تو ، [`None`] لوٹاتا ہے؛بصورت دیگر ، کمی کا نتیجہ لوٹاتا ہے۔
    ///
    /// کم از کم ایک عنصر والے تکرار کرنے والوں کے لئے ، یہ [`fold()`] جیسا ہی ہے جس میں آئٹرٹر کے پہلے عنصر کے ساتھ ابتدائی ویلیو ہوتا ہے ، ہر آنے والے عنصر کو اس میں فولڈ کرتا ہے۔
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// زیادہ سے زیادہ قیمت تلاش کریں:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// جانچ پڑتال کرتا ہے کہ اگر ہر ایک عنصر کسی پیشوکی سے میل کھاتا ہے۔
    ///
    /// `all()` ایک بندش لیتا ہے جو `true` یا `false` کی واپسی کرتا ہے۔اس بندش کو اطراق کے ہر عنصر پر لاگو ہوتا ہے ، اور اگر وہ سب `true` لوٹتے ہیں تو `all()` بھی ہوتا ہے۔
    /// اگر ان میں سے کوئی بھی `false` واپس کرتا ہے تو ، وہ `false` واپس کرتا ہے۔
    ///
    /// `all()` مختصر گردش ہے؛دوسرے لفظوں میں ، جیسے ہی اسے `false` ملتا ہے ، اس سے پروسیسنگ بند ہوجائے گی ، بشرطیکہ اس سے کوئی فرق نہیں پڑتا ہے کہ اور کیا ہوتا ہے ، نتیجہ بھی `false` ہی ہوگا۔
    ///
    ///
    /// ایک خالی تکرار کرنے والا `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// پہلے `false` پر رکنا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ہم ابھی بھی `iter` استعمال کرسکتے ہیں ، کیونکہ مزید عناصر موجود ہیں۔
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// جانچ پڑتال کرتا ہے کہ اگر کوئ عمل کرنے والا عنصر کسی پیشوٹی سے مماثل ہے۔
    ///
    /// `any()` ایک بندش لیتا ہے جو `true` یا `false` کی واپسی کرتا ہے۔یہ بند کرنے کا اطلاق کرنے والے کے ہر عنصر پر ہوتا ہے ، اور اگر ان میں سے کوئی `true` لوٹاتا ہے تو پھر `any()` بھی ہوتا ہے۔
    /// اگر وہ سب `false` لوٹاتے ہیں تو ، یہ `false` واپس کردیتی ہے۔
    ///
    /// `any()` مختصر گردش ہے؛دوسرے لفظوں میں ، جیسے ہی اسے `true` ملتا ہے ، اس سے پروسیسنگ بند ہوجائے گی ، بشرطیکہ اس سے کوئی فرق نہیں پڑتا ہے کہ اور کیا ہوتا ہے ، نتیجہ بھی `true` ہی ہوگا۔
    ///
    ///
    /// ایک خالی تکرار کرنے والا `false` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// پہلے `true` پر رکنا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ہم ابھی بھی `iter` استعمال کرسکتے ہیں ، کیونکہ مزید عناصر موجود ہیں۔
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ایٹریٹر کے ایسے عنصر کی تلاش کرتا ہے جو کسی پیشی کو پورا کرے۔
    ///
    /// `find()` ایک بندش لیتا ہے جو `true` یا `false` واپس کرتا ہے۔
    /// اس بندش کو اطراق کے ہر عنصر پر لاگو ہوتا ہے ، اور اگر ان میں سے کوئی `true` واپس کرتا ہے تو `find()` [`Some(element)`] واپس کرتا ہے۔
    /// اگر وہ سب `false` لوٹاتے ہیں تو ، یہ [`None`] واپس کردیتی ہے۔
    ///
    /// `find()` مختصر گردش ہے؛دوسرے لفظوں میں ، یہ `true` کی واپسی کے ساتھ ہی اس پر کارروائی کرنا بند کردے گی۔
    ///
    /// چونکہ `find()` ایک حوالہ لیتا ہے ، اور بہت سے تکرار کرنے والے حوالوں پر اعادہ کرتے ہیں ، اس وجہ سے ممکنہ طور پر الجھنے والی صورتحال پیدا ہوتی ہے جہاں دلیل دوہرا حوالہ ہوتا ہے۔
    ///
    /// آپ یہ اثر `&&x` کے ساتھ ذیل کی مثالوں میں دیکھ سکتے ہیں۔
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// پہلے `true` پر رکنا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ہم ابھی بھی `iter` استعمال کرسکتے ہیں ، کیونکہ مزید عناصر موجود ہیں۔
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// نوٹ کریں کہ `iter.find(f)` `iter.filter(f).next()` کے برابر ہے۔
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// آئٹرٹر کے عناصر پر فنکشن کا اطلاق ہوتا ہے اور پہلا غیر عدم نتیجہ واپس کرتا ہے۔
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` کے برابر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// آئٹرٹر کے عناصر پر فنکشن کا اطلاق ہوتا ہے اور پہلا صحیح نتیجہ یا پہلی غلطی واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ایک اشارے میں عنصر کی تلاش ، اس کی اشاریہ کو لوٹانا۔
    ///
    /// `position()` ایک بندش لیتا ہے جو `true` یا `false` واپس کرتا ہے۔
    /// اس بندش کو اطراق کے ہر عنصر پر لاگو ہوتا ہے ، اور اگر ان میں سے ایک `true` واپس کرتا ہے ، تو `position()` [`Some(index)`] واپس کرتا ہے۔
    /// اگر یہ سب `false` لوٹاتے ہیں تو ، یہ [`None`] واپس کردیتی ہے۔
    ///
    /// `position()` مختصر گردش ہے؛دوسرے لفظوں میں ، جیسے ہی اسے `true` مل جاتا ہے تو اس کی کارروائی کرنا بند ہوجائے گی۔
    ///
    /// # اوور فلو سلوک
    ///
    /// یہ طریقہ اتنے بہاؤ سے کوئی حفاظت نہیں کرتا ہے ، لہذا اگر اگر [`usize::MAX`] سے زیادہ غیر مماثلت عناصر موجود ہوں تو ، یہ یا تو غلط نتیجہ پیدا کرتا ہے یا panics۔
    ///
    /// اگر ڈیبگ کے دعوے قابل ہیں تو ، ایک panic کی ضمانت دی جاتی ہے۔
    ///
    /// # Panics
    ///
    /// یہ فنکشن panic ہوسکتا ہے اگر اگر آئٹرٹر میں `usize::MAX` سے زیادہ غیر مماثل عنصر ہوں۔
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// پہلے `true` پر رکنا:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ہم ابھی بھی `iter` استعمال کرسکتے ہیں ، کیونکہ مزید عناصر موجود ہیں۔
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // لوٹا ہوا انڈیکس تکرار کرنے والی حالت پر منحصر ہوتا ہے
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// دائیں طرف سے ایک ایٹریٹر میں عنصر کی تلاش ، اس کا اشاریہ واپس کرتا ہے۔
    ///
    /// `rposition()` ایک بندش لیتا ہے جو `true` یا `false` واپس کرتا ہے۔
    /// یہ اختتامیہ کے ہر عنصر پر یہ بندش لاگو ہوتا ہے ، آخر سے شروع ہوتا ہے ، اور اگر ان میں سے ایک `true` واپس کرتا ہے ، تو `rposition()` [`Some(index)`] واپس کرتا ہے۔
    ///
    /// اگر یہ سب `false` لوٹاتے ہیں تو ، یہ [`None`] واپس کردیتی ہے۔
    ///
    /// `rposition()` مختصر گردش ہے؛دوسرے لفظوں میں ، جیسے ہی اسے `true` مل جاتا ہے تو اس کی کارروائی کرنا بند ہوجائے گی۔
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// پہلے `true` پر رکنا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ہم ابھی بھی `iter` استعمال کرسکتے ہیں ، کیونکہ مزید عناصر موجود ہیں۔
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // یہاں اوور فلو چیک کی ضرورت نہیں ہے ، کیونکہ `ExactSizeIterator` سے ظاہر ہوتا ہے کہ عناصر کی تعداد `usize` میں فٹ بیٹھتی ہے۔
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ایک آئٹرٹر کا زیادہ سے زیادہ عنصر لوٹاتا ہے۔
    ///
    /// اگر متعدد عناصر اتنے ہی زیادہ سے زیادہ ہوں تو ، آخری عنصر لوٹ آئے گا۔
    /// اگر ریڈیٹر خالی ہے تو ، [`None`] لوٹ آئے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ایک آئٹرٹر کا کم سے کم عنصر لوٹاتا ہے۔
    ///
    /// اگر متعدد عناصر یکساں طور پر کم سے کم ہوں تو ، پہلا عنصر لوٹائے گا۔
    /// اگر ریڈیٹر خالی ہے تو ، [`None`] لوٹ آئے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// عنصر کو لوٹاتا ہے جو مخصوص فنکشن سے زیادہ سے زیادہ قیمت دیتا ہے۔
    ///
    ///
    /// اگر متعدد عناصر اتنے ہی زیادہ سے زیادہ ہوں تو ، آخری عنصر لوٹ آئے گا۔
    /// اگر ریڈیٹر خالی ہے تو ، [`None`] لوٹ آئے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// عنصر کو لوٹاتا ہے جو موازنہ کے فعل کے حوالے سے زیادہ سے زیادہ قیمت دیتا ہے۔
    ///
    ///
    /// اگر متعدد عناصر اتنے ہی زیادہ سے زیادہ ہوں تو ، آخری عنصر لوٹ آئے گا۔
    /// اگر ریڈیٹر خالی ہے تو ، [`None`] لوٹ آئے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// عنصر کو لوٹاتا ہے جو مخصوص فنکشن سے کم سے کم قیمت دیتا ہے۔
    ///
    ///
    /// اگر متعدد عناصر یکساں طور پر کم سے کم ہوں تو ، پہلا عنصر لوٹائے گا۔
    /// اگر ریڈیٹر خالی ہے تو ، [`None`] لوٹ آئے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// وہ عنصر واپس کرتا ہے جو مخصوص موازنہ تقریب کے حوالے سے کم سے کم قیمت دیتا ہے۔
    ///
    ///
    /// اگر متعدد عناصر یکساں طور پر کم سے کم ہوں تو ، پہلا عنصر لوٹائے گا۔
    /// اگر ریڈیٹر خالی ہے تو ، [`None`] لوٹ آئے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// اعرابی ہدایت کو تبدیل کرتا ہے۔
    ///
    /// عام طور پر ، تکرار کرنے والوں کو بائیں سے دائیں تک دہرانا ہوتا ہے۔
    /// `rev()` استعمال کرنے کے بعد ، ایک آئریٹر اس کے بجائے دائیں سے بائیں مکرر آئے گا۔
    ///
    /// یہ تب ہی ممکن ہے جب تکرار کرنے والا کا اختتام ہو ، لہذا `rev()` صرف [`DoubleEidedIterator`] s پر کام کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// جوڑوں کے اعرابی کو کنٹینروں کی جوڑی میں تبدیل کرتا ہے۔
    ///
    /// `unzip()` جوڑے کے پورے اعرابی کھاتے ہیں ، جس سے دو مجموعے تیار ہوتے ہیں: ایک جوڑے کے بائیں عنصر سے اور دوسرا دائیں عناصر سے۔
    ///
    ///
    /// یہ فنکشن ، کسی لحاظ سے ، [`zip`] کے برعکس ہے۔
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// ایک ایٹریٹر بناتا ہے جو اس کے تمام عناصر کی کاپی کرتا ہے۔
    ///
    /// جب آپ کے پاس `&T` سے زیادہ بار چلانے والا ہو تو یہ کارآمد ہے ، لیکن آپ کو `T` سے زیادہ تکلیف دہندگی کی ضرورت ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // کاپی .map(|&x| x) جیسا ہی ہے
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// ایک ایٹریٹر بناتا ہے جو [`clone`] s کے تمام عنصر ہیں۔
    ///
    /// جب آپ کے پاس `&T` سے زیادہ بار چلانے والا ہو تو یہ کارآمد ہے ، لیکن آپ کو `T` سے زیادہ تکلیف دہندگی کی ضرورت ہے۔
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // کلونج مسکین کے لئے ، .map(|&x| x) جیسا ہی ہے
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// کسی وقتاrator فوق کو نہ ختم کرنے کے ساتھ دہراتا ہے۔
    ///
    /// [`None`] پر رکنے کے بجائے ، شروع کرنے والے دوبارہ شروع کریں گے۔دوبارہ تکرار کرنے کے بعد ، یہ پھر شروع میں شروع ہوگا۔اور ایک بار پھر.
    /// اور ایک بار پھر.
    /// Forever.
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// تکرار کرنے والے کے عناصر کا مجموعہ۔
    ///
    /// ہر عنصر کو لیتا ہے ، ان کو ایک ساتھ جوڑتا ہے ، اور نتیجہ لوٹاتا ہے۔
    ///
    /// ایک خالی تکرار کرنے والا قسم کی صفر قدر لوٹاتا ہے۔
    ///
    /// # Panics
    ///
    /// جب `sum()` کو کال کرنا اور کسی قدیم انٹیجر کی قسم کو واپس کرنا ہو تو ، یہ طریقہ panic کرے گا اگر کمپیوٹیشن اتپرواس اور ڈیبگ دعوے کو اہل بنائے گئے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// تمام عناصر کو ضرب کرتے ہوئے ، پورے آئٹرٹر پر اعداد و شمار
    ///
    /// ایک خالی تکرار کرنے والا اس قسم کی ایک قدر لوٹاتا ہے۔
    ///
    /// # Panics
    ///
    /// جب `product()` کو کال کرنا اور کسی قدیم عددی قسم کی واپسی کی جارہی ہو تو ، اگر طریقہ حساب اتنا بہاؤ اور ڈیبگ اثبات کو اہل بنا دیا گیا ہو تو ، panic طریقہ اختیار کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) اس [`Iterator`] کے عناصر کا موازنہ دوسرے کے ساتھ کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) اس [`Iterator`] کے عناصر کا موازنہ کسی دوسرے کے مخصوص موازنہ کے فنکشن کے ساتھ کرتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) اس [`Iterator`] کے عناصر کا موازنہ دوسرے کے ساتھ کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) اس [`Iterator`] کے عناصر کا موازنہ کسی دوسرے کے مخصوص موازنہ کے فنکشن کے ساتھ کرتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// تعین کرتا ہے کہ آیا اس [`Iterator`] کے عناصر دوسرے کے برابر ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// متعین کرتا ہے کہ آیا اس [`Iterator`] کے عنصر مخصوص مساوات کے سلسلے میں کسی دوسرے کے برابر ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// اس [`Iterator`] کے عناصر کسی دوسرے سے غیر مساوی ہیں کا تعین کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// تعین کرتا ہے کہ آیا اس [`Iterator`] کے عنصر [lexicographically](Ord#lexicographical-comparison) دوسرے کے مقابلے میں کم ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// تعین کرتا ہے کہ آیا اس [`Iterator`] کے عنصر [lexicographically](Ord#lexicographical-comparison) دوسرے یا اس کے برابر ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// تعین کرتا ہے کہ آیا اس [`Iterator`] کے عنصر [lexicographically](Ord#lexicographical-comparison) دوسرے کے مقابلے میں زیادہ ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// تعین کرتا ہے کہ آیا اس [`Iterator`] کے عناصر [lexicographically](Ord#lexicographical-comparison) دوسرے سے بڑے یا اس کے برابر ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// چیک کرتا ہے کہ آیا اس ریڈیٹر کے عناصر کو ترتیب دیا گیا ہے۔
    ///
    /// یعنی ، ہر عنصر `a` اور اس کے مندرجہ ذیل عنصر `b` کے لئے ، `a <= b` لازمی ہے۔اگر ریڈیٹر بالکل صفر یا ایک عنصر برآمد کرتا ہے تو ، `true` لوٹ آتا ہے۔
    ///
    /// نوٹ کریں کہ اگر `Self::Item` صرف `PartialOrd` ہے ، لیکن `Ord` نہیں ہے ، تو مذکورہ بالا تعریف سے یہ ظاہر ہوتا ہے کہ اگر یہ کوئی دوسرا دو آئٹم موازنہ نہیں کیا جاتا ہے تو یہ فنکشن `PartialOrd` واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// جانچ پڑتال کرتا ہے کہ آیا اس تکرار کرنے والے کے عناصر کو دیئے گئے موازنہ کار کو استعمال کرکے ترتیب دیا گیا ہے۔
    ///
    /// `PartialOrd::partial_cmp` استعمال کرنے کے بجائے ، یہ فنکشن دو عناصر کی ترتیب کو طے کرنے کے لئے دیئے گئے `compare` فنکشن کا استعمال کرتا ہے۔
    /// اس کے علاوہ ، یہ [`is_sorted`] کے برابر ہے۔مزید معلومات کے لئے اس کی دستاویزات دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// چیک کرتا ہے کہ آیا اس آئٹرٹر کے عناصر کو دیئے گئے کلیدی نکالنے والے فنکشن کا استعمال کرکے ترتیب دیا گیا ہے۔
    ///
    /// اس فعل میں آئٹرٹر کے عناصر سے براہ راست موازنہ کرنے کے بجائے ، `f` کے ذریعہ طے شدہ ، عناصر کی چابیاں کا موازنہ کیا جاتا ہے۔
    /// اس کے علاوہ ، یہ [`is_sorted`] کے برابر ہے۔مزید معلومات کے لئے اس کی دستاویزات دیکھیں۔
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] دیکھیں
    // غیر معمولی نام ہے طریقہ کار کے حل میں نام کے تصادم سے بچنے کے لئے دیکھیں #76479۔
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}