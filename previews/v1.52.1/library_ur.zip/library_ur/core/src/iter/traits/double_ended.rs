use crate::ops::{ControlFlow, Try};

/// ایک تکرار کرنے والا جو دونوں سروں سے عناصر تیار کرسکتا ہے۔
///
/// `DoubleEndedIterator` کو لاگو کرنے والی کسی چیز میں [`Iterator`] پر عمل درآمد کرنے کی ایک اضافی صلاحیت ہے: پچھلے حصے کے ساتھ ساتھ سامنے سے بھی `آئٹمز لینے کی صلاحیت۔
///
///
/// یہ نوٹ کرنا ضروری ہے کہ پیچھے اور پیچھے دونوں ایک ہی حد پر کام کرتے ہیں ، اور عبور نہیں کرتے ہیں: درمیان میں ملنے پر تکرار ختم ہوجاتی ہے۔
///
/// اسی طرح کے فیشن میں ، [`Iterator`] پروٹوکول میں ، ایک بار جب `DoubleEndedIterator` [`next_back()`] کو [`next_back()`] سے واپس کرتا ہے ، تو اسے دوبارہ فون کرکے [`Some`] کو دوبارہ کبھی نہیں لوٹ سکتا ہے۔
/// [`next()`] اور [`next_back()`] اس مقصد کے ل inter تبادلہ خیال ہیں۔
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// آئٹرٹر کے آخر سے عنصر کو ہٹاتا اور واپس کرتا ہے۔
    ///
    /// جب مزید عناصر نہ ہوں تو `None` لوٹاتا ہے۔
    ///
    /// [trait-level] دستاویزات میں مزید تفصیلات شامل ہیں۔
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEenderIterator` کے طریقوں سے حاصل کردہ عناصر [te Iterator`] کے طریقوں سے حاصل کردہ عناصر سے مختلف ہوسکتے ہیں:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` عناصر کے ذریعہ پیچھے سے آئٹرٹر کو آگے بڑھاتا ہے۔
    ///
    /// `advance_back_by` [`advance_by`] کا الٹا ورژن ہے۔یہ طریقہ [`next_back`] کو [`next_back`] تک کال کرکے [`next_back`] تک [`next_back`] تک کال کرکے `n` عنصر کو پیچھے سے شروع ہونے والے `n` عناصر کو بے تابی سے چھوڑ دے گا۔
    ///
    /// `advance_back_by(n)` اگر `n` عناصر کے ذریعہ ایٹریٹر کامیابی کے ساتھ پیش قدمی کرے گا ، یا [`Err(k)`] اگر [`None`] کا سامنا کرنا پڑتا ہے تو ، [`Ok(())`] واپس کرے گا ، جہاں `k` عناصر کی تعداد ہے جس میں عناصر سے باہر چلنے سے پہلے تکرار کرنے والا جدید ہوتا ہے (جیسے۔
    /// تکرار کرنے والے کی لمبائی)۔
    /// نوٹ کریں کہ `k` ہمیشہ `n` سے کم ہوتا ہے۔
    ///
    /// `advance_back_by(0)` پر کال کرنے سے کوئی عنصر استعمال نہیں ہوتا ہے اور ہمیشہ ہی [`Ok(())`] کی واپسی ہوتی ہے۔
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // صرف `&3` کو چھوڑ دیا گیا تھا
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// آئٹرٹر کے آخر سے element n` عنصر کو لوٹاتا ہے۔
    ///
    /// یہ بنیادی طور پر [`Iterator::nth()`] کا الٹا ورژن ہے۔
    /// اگرچہ زیادہ تر اشاریہ سازی کی طرح ، گنتی صفر سے شروع ہوتی ہے ، لہذا `nth_back(0)` اختتام سے پہلی قدر ، `nth_back(1)` دوسری ، اور اسی طرح واپس کرتا ہے۔
    ///
    ///
    /// نوٹ کریں کہ واپس ہونے والے عنصر سمیت اختتام اور لوٹائے گئے عنصر کے درمیان تمام عنصریں کھا جائیں گی۔
    /// اس کا یہ مطلب بھی ہے کہ `nth_back(0)` کو ایک ہی بار پر ایک سے زیادہ بار کال کرنے سے مختلف عناصر واپس آئیں گے۔
    ///
    /// `nth_back()` اگر `n` دوبارہ کرنے والے کی لمبائی سے زیادہ یا مساوی ہے تو [`None`] واپس کرے گا۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// متعدد بار `nth_back()` کال کرنے سے دوبارہ کرنے والا دوبارہ نہیں پڑتا ہے۔
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// اگر `n + 1` سے بھی کم عناصر موجود ہوں تو `None` واپس کرنا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// یہ [`Iterator::try_fold()`] کا الٹا ورژن ہے: اس میں عناصر لی takesے والے کے پچھلے حصے سے شروع ہوتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // چونکہ یہ مختصر گردش میں ہے ، باقی عناصر ابھی بھی دوبارہ چلانے والے کے ذریعہ دستیاب ہیں۔
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ایک تکرار کرنے والا طریقہ جو پیچھے سے شروع ہونے والے آئٹرٹر کے عناصر کو ایک واحد ، حتمی قیمت تک کم کردیتا ہے۔
    ///
    /// یہ [`Iterator::fold()`] کا الٹا ورژن ہے: اس میں عناصر لی takesے والے کے پچھلے حصے سے شروع ہوتے ہیں۔
    ///
    /// `rfold()` دو دلائل لیتا ہے: ایک ابتدائی قیمت ، اور دو دلائل کے ساتھ بند ہونا: ایک 'accumulator' ، اور ایک عنصر۔
    /// بندش سے وہ قیمت آجاتی ہے جو جمع کرنے والی کو اگلی تکرار کے ل should ہونا چاہئے۔
    ///
    /// ابتدائی قدر وہ قیمت ہے جو جمع کرنے والے کی پہلی کال پر ہوگی۔
    ///
    /// اس بندش کو ایٹریٹر کے ہر عنصر پر لاگو کرنے کے بعد ، `rfold()` جمع کرنے والا واپس کرتا ہے۔
    ///
    /// اس آپریشن کو کبھی کبھی 'reduce' یا 'inject' کہا جاتا ہے۔
    ///
    /// جب بھی آپ کے پاس کسی چیز کا ذخیرہ ہوتا ہے تو فولڈنگ کارآمد ہوتی ہے ، اور اس سے ایک ہی قدر پیدا کرنا چاہتے ہیں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ایک کے تمام عناصر کا مجموعہ
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// یہ مثال ایک تار تیار کرتی ہے ، جس کی ابتداء قدر سے ہوتی ہے اور ہر عنصر کے ساتھ پیچھے سے سامنے تک جاری رہتی ہے۔
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// پیچھے سے ایک ایٹریٹر کے ایسے عنصر کی تلاش کرتا ہے جو کسی پیش گوئی کو مطمئن کرتا ہے۔
    ///
    /// `rfind()` ایک بندش لیتا ہے جو `true` یا `false` واپس کرتا ہے۔
    /// یہ اختتامیہ کے آخر میں شروع ہونے والے ہر عنصر پر اس بندش کا اطلاق ہوتا ہے ، اور اگر ان میں سے کوئی `true` واپس کرتا ہے تو `rfind()` [`Some(element)`] واپس کرتا ہے۔
    /// اگر وہ سب `false` لوٹاتے ہیں تو ، یہ [`None`] واپس کردیتی ہے۔
    ///
    /// `rfind()` مختصر گردش ہے؛دوسرے لفظوں میں ، یہ `true` کی واپسی کے ساتھ ہی اس پر کارروائی کرنا بند کردے گی۔
    ///
    /// چونکہ `rfind()` ایک حوالہ لیتا ہے ، اور بہت سے تکرار کرنے والے حوالوں پر اعادہ کرتے ہیں ، اس وجہ سے ممکنہ طور پر الجھنے والی صورتحال پیدا ہوتی ہے جہاں دلیل دوہرا حوالہ ہوتا ہے۔
    ///
    /// آپ یہ اثر `&&x` کے ساتھ ذیل کی مثالوں میں دیکھ سکتے ہیں۔
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// پہلے `true` پر رکنا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ہم ابھی بھی `iter` استعمال کرسکتے ہیں ، کیونکہ مزید عناصر موجود ہیں۔
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}