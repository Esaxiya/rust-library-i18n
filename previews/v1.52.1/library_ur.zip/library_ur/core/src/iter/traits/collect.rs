/// [`Iterator`] سے تبدیلی۔
///
/// کسی قسم کے لئے `FromIterator` لاگو کرکے ، آپ یہ بیان کرتے ہیں کہ یہ دوبارہ بنانے والے سے کیسے تیار ہوگا۔
/// یہ ان اقسام کے لئے عام ہے جو کسی طرح کے مجموعے کی وضاحت کرتی ہیں۔
///
/// [`FromIterator::from_iter()`] اسے شاذ و نادر ہی واضح طور پر کہا جاتا ہے ، اور اس کی بجائے اسے [`Iterator::collect()`] طریقہ کے ذریعے استعمال کیا جاتا ہے۔
///
/// مزید مثالوں کے لئے [`Iterator::collect()`]'s دستاویزات دیکھیں۔
///
/// بھی دیکھو: [`IntoIterator`].
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` کو واضح طور پر `FromIterator` استعمال کرنے کیلئے:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// آپ کی قسم کے لئے `FromIterator` لاگو کرنا:
///
/// ```
/// use std::iter::FromIterator;
///
/// // ایک نمونہ مجموعہ ، جو Vec کے اوپر محیط ہے<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // آئیے اس کو کچھ طریقے بتائیں تاکہ ہم کوئی ایک پیدا کریں اور اس میں چیزیں شامل کریں۔
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // اور ہم fromIterator لاگو کریں گے
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // اب ہم ایک نیا ریڈیٹر بنا سکتے ہیں ...
/// let iter = (0..5).into_iter();
///
/// // ... اور اس میں سے میرا کلیکشن بنائیں
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // کام بھی جمع!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// آیتریٹر سے ایک قدر بناتا ہے۔
    ///
    /// مزید کے لئے [module-level documentation] دیکھیں۔
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// ایک [`Iterator`] میں تبدیلی۔
///
/// ایک قسم کے لئے `IntoIterator` کو لاگو کرکے ، آپ یہ بیان کرتے ہیں کہ اسے دوبارہ چلانے والے میں کس طرح تبدیل کیا جائے گا۔
/// یہ ان اقسام کے لئے عام ہے جو کسی طرح کے مجموعے کی وضاحت کرتی ہیں۔
///
/// `IntoIterator` لاگو کرنے کا ایک فائدہ یہ ہے کہ آپ کی قسم [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) ہوگی۔
///
///
/// بھی دیکھو: [`FromIterator`].
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// آپ کی قسم کے لئے `IntoIterator` لاگو کرنا:
///
/// ```
/// // ایک نمونہ مجموعہ ، جو Vec کے اوپر محیط ہے<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // آئیے اس کو کچھ طریقے بتائیں تاکہ ہم کوئی ایک پیدا کریں اور اس میں چیزیں شامل کریں۔
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // اور ہم داخل کریں گے
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // اب ہم ایک نیا مجموعہ بنا سکتے ہیں ...
/// let mut c = MyCollection::new();
///
/// // ... اس میں کچھ چیزیں شامل کریں ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... اور پھر اسے ایک تجزیہ کار میں تبدیل کریں:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` کو trait bound کے بطور استعمال کرنا عام ہے۔اس سے ان پٹ کلیکشن کی قسم کو تبدیل ہونے کی اجازت ملتی ہے ، جب تک کہ یہ ابھی تک دوبارہ چلنے والا ہے۔
/// اضافی حدود کو محدود کرکے مخصوص کیا جاسکتا ہے
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// عناصر کی قسم جس پر اعادہ کیا جارہا ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ہم اس کو کس قسم کا ایٹریٹر بنا رہے ہیں؟
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ایک قدر سے ایک ریڈیٹر بناتا ہے۔
    ///
    /// مزید کے لئے [module-level documentation] دیکھیں۔
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// دوبارہ کرنے والے کے مندرجات کے ساتھ ایک مجموعہ میں اضافہ کریں۔
///
/// Iteters اقدار کی ایک سیریز تیار کرتے ہیں ، اور جمع کرنے کو بھی اقدار کی ایک سیریز کے طور پر سوچا جاسکتا ہے۔
/// `Extend` trait اس خلا کو پُر کرتا ہے ، جس کی مدد سے آپ اس تعاقب کنندہ کے مشمولات کو شامل کرکے ایک مجموعہ میں توسیع کرسکتے ہیں۔
/// پہلے سے موجود کلید کی مدد سے کسی مجموعہ میں توسیع کرتے وقت ، اس اندراج کو اپ ڈیٹ کیا جاتا ہے یا اس مجموعے کی صورت میں جو مساوی کلیدوں والے متعدد اندراجات کی اجازت دیتا ہے ، تو اس اندراج کو داخل کیا جاتا ہے۔
///
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// // آپ کچھ حروف کے ساتھ ایک تار کو بڑھا سکتے ہیں:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` لاگو کرنا:
///
/// ```
/// // ایک نمونہ مجموعہ ، جو Vec کے اوپر محیط ہے<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // آئیے اس کو کچھ طریقے بتائیں تاکہ ہم کوئی ایک پیدا کریں اور اس میں چیزیں شامل کریں۔
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // چونکہ مائی کلیکشن میں آئی 32 ایس کی ایک فہرست ہے ، لہذا ہم i32 کے لئے توسیع کو نافذ کرتے ہیں
/// impl Extend<i32> for MyCollection {
///
///     // یہ ٹھوس قسم کے دستخط کے ساتھ قدرے آسان ہے: ہم کسی بھی ایسی چیز پر توسیع کا مطالبہ کرسکتے ہیں جس کو Iterator میں تبدیل کیا جاسکے جو ہمیں i32s دیتا ہے۔
///     // کیوں کہ ہمیں مائی کلیکشن میں ڈالنے کے لئے آئی 32 ایس کی ضرورت ہے۔
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // اس کا نفاذ بہت سیدھا ہے: تکرار کرنے والے کے ذریعہ لوپ کریں ، اور ہر عنصر کو اپنے پاس رکھیں۔
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // آئیے اپنا مجموعہ مزید تین نمبروں کے ساتھ بڑھا دیں
/// c.extend(vec![1, 2, 3]);
///
/// // ہم نے آخر میں ان عناصر کو شامل کیا ہے
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ایک مجموعہ میں ایک آیتریٹر کے مندرجات کے ساتھ توسیع کرتا ہے۔
    ///
    /// چونکہ اس trait کیلئے یہ واحد مطلوبہ طریقہ ہے ، لہذا [trait-level] دستاویزات میں مزید تفصیلات موجود ہیں۔
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// // آپ کچھ حروف کے ساتھ ایک تار کو بڑھا سکتے ہیں:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// بالکل ایک عنصر کے ساتھ ایک مجموعہ میں توسیع کرتا ہے۔
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// اضافی عناصر کی دی گئی تعداد کے ل a کسی مجموعہ میں صلاحیت محفوظ رکھتی ہے۔
    ///
    /// پہلے سے طے شدہ عمل سے کچھ نہیں ہوتا ہے۔
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}