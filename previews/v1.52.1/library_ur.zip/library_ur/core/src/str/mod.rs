//! سٹرنگ ہیرا پھیری۔
//!
//! مزید تفصیلات کے لئے ، [`std::str`] ماڈیول دیکھیں۔
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. حد سے باہر
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. شروع <=آخر
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. کردار کی حد
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // کردار تلاش کریں
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` لین اور چار حد سے کم ہونا چاہئے
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` کی لمبائی لوٹاتا ہے۔
    ///
    /// یہ لمبائی بائٹ میں ہے ، [`چار`] s یا گرافیمز میں نہیں۔
    /// دوسرے الفاظ میں ، یہ نہیں ہوسکتا ہے کہ انسان تار کی لمبائی کو سمجھتا ہو۔
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // پسند ہیں!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// اگر `self` کی لمبائی صفر بائٹ ہے تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// چیک کرتا ہے کہ `index`-th بائٹ UTF-8 کوڈ پوائنٹ ترتیب یا سٹرنگ کے اختتام پر پہلا بائٹ ہے۔
    ///
    ///
    /// سٹرنگ کا آغاز اور اختتام (جب `index== self.len()`) کو حدود سمجھا جاتا ہے۔
    ///
    /// اگر `index` `self.len()` سے زیادہ ہے تو `false` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` کا آغاز
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` کا دوسرا بائٹ
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` کا تیسرا بائٹ
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 اور لین ہمیشہ ٹھیک رہتے ہیں۔
        // 0 کے لئے واضح طور پر جانچیں تاکہ وہ آسانی سے چیک کو بہتر بنا سکے اور اس معاملے میں پڑھنے والے سٹرنگ ڈیٹا کو چھوڑ سکے۔
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // یہ تھوڑا سا جادو کے برابر ہے: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// سٹرنگ سلائس کو بائٹ سلائس میں تبدیل کرتا ہے۔
    /// بائٹ سلائس کو دوبارہ اسٹرنگ سلائس میں تبدیل کرنے کے لئے ، [`from_utf8`] فنکشن کا استعمال کریں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // حفاظت: مستحکم آواز کیونکہ ہم ایک ہی ترتیب کے ساتھ دو اقسام کو منتقل کرتے ہیں
        unsafe { mem::transmute(self) }
    }

    /// بدلنے والے اسٹرنگ سلائس کو ایک تبدیل شدہ بائٹ سلائس میں تبدیل کرتا ہے۔
    ///
    /// # Safety
    ///
    /// کال کرنے والے کو یہ یقینی بنانا ہوگا کہ قرض ختم ہونے اور بنیادی `str` استعمال کرنے سے پہلے سلائس کا مواد UTF-8 X درست ہے۔
    ///
    ///
    /// ایک `str` کا استعمال جس کے مندرجات درست نہیں ہیں UTF-8 غیر وضاحتی سلوک ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // محفوظ: `&str` سے `&[u8]` تک کاسٹ `str` کے بعد سے محفوظ ہے
        // `&[u8]` جیسا لے آؤٹ ہے (صرف اس بات کی ضمانت دے سکتا ہے)
        // اس نقطہ نظر کی حفاظت محفوظ ہے کیوں کہ یہ ایک تغیر پزیر حوالہ سے آتا ہے جس کی ضمانت تحریری طور پر موزوں ہے۔
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// سٹرنگ سلائس کو کچے پوائنٹر میں بدل دیتا ہے۔
    ///
    /// چونکہ سٹرنگ سلائسس بائٹس کا ایک ٹکڑا ہے ، لہذا خام پوائنٹر ایک [`u8`] کی طرف اشارہ کرتا ہے۔
    /// یہ پوائنٹر اسٹرنگ سلائس کے پہلے بائٹ کی طرف اشارہ کرے گا۔
    ///
    /// کال کرنے والے کو یہ یقینی بنانا ہوگا کہ لوٹا ہوا پوائنٹر کبھی بھی نہیں لکھا گیا ہے۔
    /// اگر آپ کو سٹرنگ سلائس کے مشمولات کو تبدیل کرنے کی ضرورت ہے تو ، [`as_mut_ptr`] استعمال کریں۔
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// تغیر پزیر سٹرنگ سلائس کو کچے پوائنٹر میں بدل دیتا ہے۔
    ///
    /// چونکہ سٹرنگ سلائسس بائٹس کا ایک ٹکڑا ہے ، لہذا خام پوائنٹر ایک [`u8`] کی طرف اشارہ کرتا ہے۔
    /// یہ پوائنٹر اسٹرنگ سلائس کے پہلے بائٹ کی طرف اشارہ کرے گا۔
    ///
    /// یہ آپ کی ذمہ داری ہے کہ اس بات کو یقینی بنائیں کہ اسٹرنگ سلائس میں صرف اس طرح ترمیم ہوجائے کہ یہ درست UTF-8 ہی رہے۔
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` کا ایک ذیلی حصہ لوٹاتا ہے۔
    ///
    /// یہ `str` کو انڈیکس کرنے کا غیر گھبرانے والا متبادل ہے۔
    /// [`None`] واپس کرتا ہے جب بھی مساوی اشاریہ سازی کا عمل panic کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // اشارے UTF-8 تسلسل کی حدود پر نہیں
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // حد سے باہر
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` کا متغیر سبسلیس لوٹاتا ہے۔
    ///
    /// یہ `str` کو انڈیکس کرنے کا غیر گھبرانے والا متبادل ہے۔
    /// [`None`] واپس کرتا ہے جب بھی مساوی اشاریہ سازی کا عمل panic کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // درست لمبائی
    /// assert!(v.get_mut(0..5).is_some());
    /// // حد سے باہر
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` کا بغیر چیک شدہ سبسلیس لوٹاتا ہے۔
    ///
    /// یہ `str` کو انڈیکس کرنے کے لئے غیر چیک شدہ متبادل ہے۔
    ///
    /// # Safety
    ///
    /// اس فنکشن کے کال کرنے والے ذمہ دار ہیں کہ یہ شرطیں مطمئن ہیں:
    ///
    /// * شروعاتی انڈیکس اختتامی انڈیکس سے تجاوز نہیں کرنا چاہئے۔
    /// * اشاریہ جات کو اصل سلائس کی حدود میں ہونا چاہئے۔
    /// * اشاریوں کو UTF-8 تسلسل کی حدود پر ہونا چاہئے۔
    ///
    /// اس میں ناکام رہتے ہوئے ، لوٹائی گئی سٹرنگ سلائس غلط میموری کا حوالہ دے سکتی ہے یا `str` ٹائپ کے ذریعہ گفتگو کردہ حملہ آوروں کی خلاف ورزی کر سکتی ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // محفوظ: کال کرنے والے کو `get_unchecked` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        // سلائس قابل تعزیر ہے کیونکہ `self` ایک محفوظ حوالہ ہے۔
        // لوٹا ہوا پوائنٹر محفوظ ہے کیونکہ `SliceIndex` کی امپلس کو اس بات کی ضمانت دینا ہوگی۔
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` کا ایک متغیر ، بغیر چیک شدہ سبسلس کو لوٹاتا ہے۔
    ///
    /// یہ `str` کو انڈیکس کرنے کے لئے غیر چیک شدہ متبادل ہے۔
    ///
    /// # Safety
    ///
    /// اس فنکشن کے کال کرنے والے ذمہ دار ہیں کہ یہ شرطیں مطمئن ہیں:
    ///
    /// * شروعاتی انڈیکس اختتامی انڈیکس سے تجاوز نہیں کرنا چاہئے۔
    /// * اشاریہ جات کو اصل سلائس کی حدود میں ہونا چاہئے۔
    /// * اشاریوں کو UTF-8 تسلسل کی حدود پر ہونا چاہئے۔
    ///
    /// اس میں ناکام رہتے ہوئے ، لوٹائی گئی سٹرنگ سلائس غلط میموری کا حوالہ دے سکتی ہے یا `str` ٹائپ کے ذریعہ گفتگو کردہ حملہ آوروں کی خلاف ورزی کر سکتی ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // محفوظ: کال کرنے والے کو `get_unchecked_mut` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        // سلائس قابل تعزیر ہے کیونکہ `self` ایک محفوظ حوالہ ہے۔
        // لوٹا ہوا پوائنٹر محفوظ ہے کیونکہ `SliceIndex` کی امپلس کو اس بات کی ضمانت دینا ہوگی۔
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// حفاظتی چیکوں کو نظرانداز کرتے ہوئے ، دوسرے سٹرنگ سلائس سے سٹرنگ سلائس تیار کرتا ہے۔
    ///
    /// عام طور پر اس کی سفارش نہیں کی جاتی ہے ، احتیاط کے ساتھ استعمال کریں!محفوظ متبادل کے لئے دیکھیں [`str`] اور [`Index`]۔
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// یہ نیا ٹکڑا `begin` سے `end` تک جاتا ہے ، بشمول `begin` لیکن `end` کو چھوڑ کر۔
    ///
    /// اس کے بجائے بدلنے والے اسٹرنگ سلائس حاصل کرنے کے لئے ، [`slice_mut_unchecked`] طریقہ دیکھیں۔
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// اس فنکشن کے کال کرنے والے ذمہ دار ہیں کہ تین پیشگی شرائط پوری ہوں:
    ///
    /// * `begin` `end` سے زیادہ نہیں ہونا چاہئے۔
    /// * `begin` اور `end` لازمی طور پر سٹرائ سلائس کے اندر بائٹ پوزیشن میں ہونا چاہئے۔
    /// * `begin` اور `end` کو UTF-8 ترتیب کی حدود پر جھوٹ بولنا چاہئے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // محفوظ: کال کرنے والے کو `get_unchecked` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        // سلائس قابل تعزیر ہے کیونکہ `self` ایک محفوظ حوالہ ہے۔
        // لوٹا ہوا پوائنٹر محفوظ ہے کیونکہ `SliceIndex` کی امپلس کو اس بات کی ضمانت دینا ہوگی۔
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// حفاظتی چیکوں کو نظرانداز کرتے ہوئے ، دوسرے سٹرنگ سلائس سے سٹرنگ سلائس تیار کرتا ہے۔
    /// عام طور پر اس کی سفارش نہیں کی جاتی ہے ، احتیاط کے ساتھ استعمال کریں!محفوظ متبادل کے لئے دیکھیں [`str`] اور [`IndexMut`]۔
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// یہ نیا ٹکڑا `begin` سے `end` تک جاتا ہے ، بشمول `begin` لیکن `end` کو چھوڑ کر۔
    ///
    /// اس کے بجائے غیر منقولہ سٹرنگ سلائس حاصل کرنے کے لئے ، [`slice_unchecked`] طریقہ دیکھیں۔
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// اس فنکشن کے کال کرنے والے ذمہ دار ہیں کہ تین پیشگی شرائط پوری ہوں:
    ///
    /// * `begin` `end` سے زیادہ نہیں ہونا چاہئے۔
    /// * `begin` اور `end` لازمی طور پر سٹرائ سلائس کے اندر بائٹ پوزیشن میں ہونا چاہئے۔
    /// * `begin` اور `end` کو UTF-8 ترتیب کی حدود پر جھوٹ بولنا چاہئے۔
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // محفوظ: کال کرنے والے کو `get_unchecked_mut` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        // سلائس قابل تعزیر ہے کیونکہ `self` ایک محفوظ حوالہ ہے۔
        // لوٹا ہوا پوائنٹر محفوظ ہے کیونکہ `SliceIndex` کی امپلس کو اس بات کی ضمانت دینا ہوگی۔
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ایک سٹرنگ سلائس کو انڈیکس میں دو میں تقسیم کریں۔
    ///
    /// دلیل ، `mid` ، سٹرنگ کے آغاز سے ہی ایک بائٹ آفسیٹ ہونا چاہئے۔
    /// یہ بھی UTF-8 کوڈ پوائنٹ کی حدود میں ہونا چاہئے۔
    ///
    /// دونوں سلائسس واپس آئے سٹرنگ سلائس کے آغاز سے `mid` ، اور `mid` سے لے کر سٹرنگ سلائس کے اختتام تک۔
    ///
    /// اس کے بجائے بدلنے والے سٹرنگ سلائسس حاصل کرنے کے لئے ، [`split_at_mut`] طریقہ دیکھیں۔
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics اگر `mid` UTF-8 کوڈ پوائنٹ حدود پر نہیں ہے ، یا اگر اس میں تار کے ٹکڑے کے آخری کوڈ پوائنٹ کے اختتام پر ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_bundary چیک کرتا ہے کہ انڈیکس [0 ، .len()]
        if self.is_char_boundary(mid) {
            // محفوظ کریں: ابھی چیک کیا کہ `mid` چار باؤنڈری پر ہے۔
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ایک متغیر سٹرنگ سلائس کو انڈیکس میں دو میں تقسیم کریں۔
    ///
    /// دلیل ، `mid` ، سٹرنگ کے آغاز سے ہی ایک بائٹ آفسیٹ ہونا چاہئے۔
    /// یہ بھی UTF-8 کوڈ پوائنٹ کی حدود میں ہونا چاہئے۔
    ///
    /// دونوں سلائسس واپس آئے سٹرنگ سلائس کے آغاز سے `mid` ، اور `mid` سے لے کر سٹرنگ سلائس کے اختتام تک۔
    ///
    /// اس کے بجائے غیر منقولہ سٹرنگس حاصل کرنے کے لئے ، [`split_at`] طریقہ دیکھیں۔
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics اگر `mid` UTF-8 کوڈ پوائنٹ حدود پر نہیں ہے ، یا اگر اس میں تار کے ٹکڑے کے آخری کوڈ پوائنٹ کے اختتام پر ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_bundary چیک کرتا ہے کہ انڈیکس [0 ، .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // محفوظ کریں: ابھی چیک کیا کہ `mid` چار باؤنڈری پر ہے۔
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// [string چار`] s پر اسٹرنگ سلائس میں ایک ایریٹر لوٹاتا ہے۔
    ///
    /// چونکہ ایک سٹرنگ سلائس درست UTF-8 پر مشتمل ہے ، لہذا ہم [`char`] کے ذریعہ سٹرنگ سلائس کے ذریعے اعادہ کرسکتے ہیں۔
    /// یہ طریقہ اس طرح کے تکرار کو لوٹاتا ہے۔
    ///
    /// یہ یاد رکھنا ضروری ہے کہ [`char`] یونیکوڈ اسکیلر ویلیو کی نمائندگی کرتا ہے ، اور ہوسکتا ہے کہ آپ کے خیال سے 'character' کیا ہو۔
    ///
    /// گرافیم کلسٹرز پر انحراف وہی ہوسکتا ہے جو آپ اصل میں چاہتے ہو۔
    /// یہ فعالیت Rust کی معیاری لائبریری کے ذریعہ فراہم نہیں کی گئی ہے ، بجائے crates.io چیک کریں۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// یاد رکھنا ، [`char`] s حرفوں کے بارے میں آپ کی بدیہی سے مماثل نہیں ہوگا:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' نہیں
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// [string چار`] s کے سٹرنگ سلائس اور ان کی پوزیشنوں پر ایک ایریٹر لوٹاتا ہے۔
    ///
    /// چونکہ ایک سٹرنگ سلائس درست UTF-8 پر مشتمل ہے ، لہذا ہم [`char`] کے ذریعہ سٹرنگ سلائس کے ذریعے اعادہ کرسکتے ہیں۔
    /// یہ طریقہ ان دونوں [`چار`] s کے ساتھ ساتھ ان کی بائٹ پوزیشنوں کا اعرابی لوٹاتا ہے۔
    ///
    /// تکرار کرنے والے کو ٹوپل ملتا ہے۔پوزیشن پہلے ہے ، [`char`] دوسرا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// یاد رکھنا ، [`char`] s حرفوں کے بارے میں آپ کی بدیہی سے مماثل نہیں ہوگا:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // نہیں (0 ، 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // یہاں 3 پر نوٹ کریں ، آخری کردار نے دو بائٹس اٹھائے تھے
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// اسٹرائنگ سلائس کے بائٹس پر ایک ایٹریٹر۔
    ///
    /// چونکہ سٹرنگ سلائس بائٹس کی ترتیب پر مشتمل ہوتا ہے ، اس لئے ہم بائٹ کے ذریعہ سٹرنگ سلائس کے ذریعہ اعادہ کرسکتے ہیں۔
    /// یہ طریقہ اس طرح کے تکرار کو لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// وائٹ اسپیس کے ذریعہ سٹرنگ سلائس کو الگ کرتا ہے۔
    ///
    /// واپس کرنے والا لوٹ مار کرنے والے سٹرنگس سلائسس کو واپس کرے گا جو اصل تار کے ذیلی سلائس ہیں ، کسی بھی جگہ کو خالی جگہ سے الگ کرکے۔
    ///
    ///
    /// 'Whitespace' یونیکوڈ اخذ کردہ کور پراپرٹی `White_Space` کی شرائط کے مطابق تعریف کی گئی ہے۔
    /// اگر آپ اس کے بجائے صرف ASCII وائٹ اسپیس پر ہی تقسیم کرنا چاہتے ہیں تو ، [`split_ascii_whitespace`] استعمال کریں۔
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ہر قسم کی خالی جگہ پر غور کیا جاتا ہے:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII وائٹ اسپیس کے ذریعہ سٹرنگ سلائس تقسیم کرتا ہے۔
    ///
    /// واپس کرنے والا دوبارہ اسٹرنگ سلائسس کو واپس کرے گا جو اصل سٹرنگ سلائسس کے ذیلی سلائس ہیں ، کسی بھی مقدار میں ASCII کی جگہ سے الگ ہوجاتے ہیں۔
    ///
    ///
    /// اس کے بجائے یونیکوڈ `Whitespace` سے الگ ہونے کے لئے ، [`split_whitespace`] استعمال کریں۔
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ہر قسم کی ASCII وائٹ اسپیس پر غور کیا جاتا ہے:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// تار کی لکیروں پر ایک تکرار کرنے والا ، جیسے تار کے ٹکڑے۔
    ///
    /// لائنوں کا اختتام ایک نئی لائن (`\n`) یا لائن فیڈ (`\r\n`) کے ساتھ کیریج ریٹرن سے ہوتا ہے۔
    ///
    /// آخری لائن اختتام اختیاری ہے۔
    /// حتمی لائن اختتام پذیر ہونے والی تار ایک حتمی لائن اختتام پذیر بغیر اسی طرح کی لائنوں کو واپس کرے گی۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// حتمی لائن ختم ہونے کی ضرورت نہیں ہے:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// تار کی لکیروں پر ایک تکرار کرنے والا۔
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 کے بطور انکوڈ شدہ اسٹرنگ پر `u16` کا ایک ایٹرٹر لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// اگر دی گئی پیٹرن اس سٹرنگ سلائس کے ذیلی سلائس سے مماثل ہے تو `true` لوٹاتا ہے۔
    ///
    /// اگر ایسا نہیں ہوتا ہے تو `false` لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// اگر دی گئی پیٹرن اس سٹرنگ سلائس کے کسی سابقے سے میل کھاتا ہے تو `true` لوٹاتا ہے۔
    ///
    /// اگر ایسا نہیں ہوتا ہے تو `false` لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// اگر دی گئی پیٹرن اس سٹرنگ سلائس کے ایک لاحقہ سے میل کھاتا ہے تو `true` لوٹاتا ہے۔
    ///
    /// اگر ایسا نہیں ہوتا ہے تو `false` لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// اس سٹرنگ سلائس کے پہلے کردار کا بائٹ انڈیکس لوٹاتا ہے جو پیٹرن سے میل کھاتا ہے۔
    ///
    /// اگر پیٹرن مماثل نہیں ہے تو [`None`] لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// پوائنٹ فری فری اسٹائل اور بندش کا استعمال کرتے ہوئے مزید پیچیدہ نمونوں:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// نمونہ نہیں ڈھونڈ رہا:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// اس سٹرنگ سلائس میں پیٹرن کے دائیں بازو کے میچ کے پہلے کردار کے لئے بائٹ انڈیکس لوٹاتا ہے۔
    ///
    /// اگر پیٹرن مماثل نہیں ہے تو [`None`] لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// بندش کے ساتھ زیادہ پیچیدہ نمونوں:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// نمونہ نہیں ڈھونڈ رہا:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// اس سٹرنگ سلائس کے ذیلی سٹرنگ کے اوپر ایک ریڈیٹر ، ایک نمونہ کے مطابق مماثل حروف کے ذریعہ جدا ہوا۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے اور forward/reverse تلاش میں وہی عناصر برآمد ہوتے ہیں تو لوٹا ہوا ریٹر ایک [`DoubleEndedIterator`] ہوگا۔
    /// یہ ، مثال کے طور پر ، [`char`] کے لئے درست ہے ، لیکن `&str` کے لئے نہیں۔
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے لیکن اس کے نتائج آگے کی تلاش سے مختلف ہوسکتے ہیں تو ، [`rsplit`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// اگر پیٹرن حروف کا ٹکڑا ہے تو ، کسی بھی حرف کے ہر واقعے پر تقسیم ہوجائیں۔
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// بندش کا استعمال کرتے ہوئے ایک اور پیچیدہ نمونہ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// اگر کسی تار میں متعدد پیچیدہ جداکار ہوتے ہیں تو ، آپ آؤٹ پٹ میں خالی تار کے ساتھ ختم ہوجائیں گے۔
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// مسلسل جداکار خالی تار کے ذریعہ الگ ہوجاتے ہیں۔
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// تار کے شروع یا اختتام پر جداکار خالی ڈور کے ذریعہ ہمسایہ ہیں۔
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// جب خالی تار کو جداکار کے طور پر استعمال کیا جاتا ہے ، تو وہ تار کے آغاز اور آخر کے ساتھ ساتھ ، تار کے ہر کردار کو الگ کرتا ہے۔
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// وائٹ اسپیس جداکار کے بطور استعمال ہونے پر متنازعہ علیحدگی اختیار کرنے والے افراد نے ممکنہ طور پر حیرت انگیز رویہ اختیار کیا۔یہ کوڈ درست ہے:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// یہ _not_ آپ کو دیتا ہے:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// اس سلوک کے ل X [`split_whitespace`] استعمال کریں۔
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// اس سٹرنگ سلائس کے ذیلی سٹرنگ کے اوپر ایک ریڈیٹر ، ایک نمونہ کے مطابق مماثل حروف کے ذریعہ جدا ہوا۔
    /// اس `split_inclusive` میں `split` کے ذریعہ تیار کردہ ایٹریٹر سے مختلف ہوتا ہے جو ملائے ہوئے حصے کو سٹرنگ کے ٹرمنیٹر کے طور پر چھوڑ دیتا ہے۔
    ///
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// اگر اسٹرنگ کا آخری عنصر مماثلت رکھتا ہے تو ، اس عنصر کو پچھلے اسٹریننگ کا ٹرمنیٹر سمجھا جائے گا۔
    /// وہ سٹرنگ آخری آئٹم ہوگا جو آئٹرٹر کے ذریعہ لوٹا گیا ہے۔
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// دیئے گئے سٹرنگ سلائس کے ذیلی سٹرنگز پر ایک ریڈیٹر ، حرفوں کے ذریعہ جدا ہوا جس کا نمونہ ملا ہوا ہے اور الٹا ترتیب میں ملا ہے
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// واپس لوٹنے والے کا تقاضا ہے کہ پیٹرن ایک الٹ تلاش کی حمایت کرتا ہے ، اور اگر forward/reverse تلاش میں وہی عنصر برآمد ہوں تو یہ [`DoubleEndedIterator`] ہوگا۔
    ///
    ///
    /// سامنے سے تکرار کرنے کے لئے ، [`split`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// بندش کا استعمال کرتے ہوئے ایک اور پیچیدہ نمونہ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// دیئے گئے سٹرنگ سلائس کے سبسٹرنگس پر ایک آئٹرٹر ، ایک نمونہ کے مطابق مماثل حروف سے الگ ہوجاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] کے مساوی ، سوائے اس کے کہ اگر خالی ہو تو پچھلے حصے کو چھوڑ دیا جائے گا۔
    ///
    /// [`split`]: str::split
    ///
    /// اس طریقہ کار کو اسٹرنگ ڈیٹا کیلئے استعمال کیا جاسکتا ہے جو _terminated_ ہے ، بجائے کسی نمونے کے ذریعہ _terminated_۔
    ///
    /// # Iterator سلوک
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے اور forward/reverse تلاش میں وہی عناصر برآمد ہوتے ہیں تو لوٹا ہوا ریٹر ایک [`DoubleEndedIterator`] ہوگا۔
    /// یہ ، مثال کے طور پر ، [`char`] کے لئے درست ہے ، لیکن `&str` کے لئے نہیں۔
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے لیکن اس کے نتائج آگے کی تلاش سے مختلف ہوسکتے ہیں تو ، [`rsplit_terminator`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` کے ذیلی سٹرنگوں پر ایک تعی .ن کرنے والا ، جو ایک نمونہ کے مطابق مماثل حروف کے ذریعہ جدا ہوا اور الٹا ترتیب میں ملا
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] کے مساوی ، سوائے اس کے کہ اگر خالی ہو تو پچھلے حصے کو چھوڑ دیا جائے گا۔
    ///
    /// [`split`]: str::split
    ///
    /// اس طریقہ کار کو اسٹرنگ ڈیٹا کیلئے استعمال کیا جاسکتا ہے جو _terminated_ ہے ، بجائے کسی نمونے کے ذریعہ _terminated_۔
    ///
    /// # Iterator سلوک
    ///
    /// واپس لوٹنے والے کا تقاضا ہے کہ پیٹرن ایک الٹ تلاش کی حمایت کرتا ہے ، اور اگر forward/reverse تلاش میں وہی عنصر برآمد ہوں تو یہ دوگنا ختم ہوجائے گا۔
    ///
    ///
    /// سامنے سے تکرار کرنے کے لئے ، [`split_terminator`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// دیئے گئے سٹرنگ سلائس کے ذیلی سٹرنگوں پر ایک تعطیر کرنے والا ، کسی نمونہ کے ذریعہ جدا ہوا ، زیادہ تر `n` آئٹمز پر لوٹنے تک محدود ہے۔
    ///
    /// اگر `n` سب سٹرنگز واپس کردی گئیں تو ، آخری سٹرنگ (`n`th اسٹراسٹنگ) میں باقی سٹرنگ باقی ہوگی۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// لوٹائے جانے والا دوبارہ کرنے والا دوگنا ختم نہیں ہوگا ، کیونکہ اس کی تائید کرنا موثر نہیں ہے۔
    ///
    /// اگر پیٹرن معکوس تلاش کی اجازت دیتا ہے تو ، [`rsplitn`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// بندش کا استعمال کرتے ہوئے ایک اور پیچیدہ نمونہ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// اس سٹرنگ سلائس کے ذیلی سٹرنگز پر ایک ایٹریٹر ، ایک پیٹرن کے ذریعہ جدا ہوا ، تار کے اختتام سے شروع ہوتا ہے ، زیادہ تر `n` آئٹمز پر لوٹنے تک محدود ہے۔
    ///
    ///
    /// اگر `n` سب سٹرنگز واپس کردی گئیں تو ، آخری سٹرنگ (`n`th اسٹراسٹنگ) میں باقی سٹرنگ باقی ہوگی۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// لوٹائے جانے والا دوبارہ کرنے والا دوگنا ختم نہیں ہوگا ، کیونکہ اس کی تائید کرنا موثر نہیں ہے۔
    ///
    /// سامنے سے الگ ہونے کے لئے ، [`splitn`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// بندش کا استعمال کرتے ہوئے ایک اور پیچیدہ نمونہ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// ڈلیئیمٹر کے پہلے واقعہ پر تار الگ ہوجاتا ہے اور ڈیلیمیٹر سے پہلے ہی پریفکس اور ڈلییمٹر کے بعد لاحقہ واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// مخصوص ڈلیمیٹر کی آخری واردات پر تار الگ ہوجاتا ہے اور ڈیلییمٹر سے پہلے ہی ڈیلی میٹر اور لاحقہ کے بعد لاحقہ واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// دیئے گئے اسٹرائنگ سلائس کے اندر کسی پیٹرن کے ناپائید میچوں سے متعلق ایک ریڈیٹر۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے اور forward/reverse تلاش میں وہی عناصر برآمد ہوتے ہیں تو لوٹا ہوا ریٹر ایک [`DoubleEndedIterator`] ہوگا۔
    /// یہ ، مثال کے طور پر ، [`char`] کے لئے درست ہے ، لیکن `&str` کے لئے نہیں۔
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے لیکن اس کے نتائج آگے کی تلاش سے مختلف ہوسکتے ہیں تو ، [`rmatches`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// اس سٹرنگ سلائس کے اندر کسی پیٹرن کے مایوس کن میچوں پر ایک اٹریٹر ، الٹ ترتیب میں ملا۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// واپس لوٹنے والے کا تقاضا ہے کہ پیٹرن ایک الٹ تلاش کی حمایت کرتا ہے ، اور اگر forward/reverse تلاش میں وہی عنصر برآمد ہوں تو یہ [`DoubleEndedIterator`] ہوگا۔
    ///
    ///
    /// سامنے سے تکرار کرنے کے لئے ، [`matches`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// اس سٹرنگ سلائس کے اندر کسی نمونہ کے ناپائید میچوں کے ساتھ ساتھ میچ کا آغاز ہونے والے انڈیکس پر ایک تعطیر کرنے والا۔
    ///
    /// `self` کے اندر موجود `pat` کے میچوں کے لئے جو اوور لپیٹ میں آتے ہیں ، صرف پہلے میچ سے وابستہ انڈیکس ہی واپس ہوتے ہیں۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے اور forward/reverse تلاش میں وہی عناصر برآمد ہوتے ہیں تو لوٹا ہوا ریٹر ایک [`DoubleEndedIterator`] ہوگا۔
    /// یہ ، مثال کے طور پر ، [`char`] کے لئے درست ہے ، لیکن `&str` کے لئے نہیں۔
    ///
    /// اگر پیٹرن ایک الٹ تلاش کی اجازت دیتا ہے لیکن اس کے نتائج آگے کی تلاش سے مختلف ہوسکتے ہیں تو ، [`rmatch_indices`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // صرف پہلا `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` کے اندر اندر کسی نمونہ کے ناپائید میچوں پر تعیratorن کرنے والا ، میچ کے اشاریے کے ساتھ ہی الٹ ترتیب میں ملا۔
    ///
    /// `self` کے اندر موجود `pat` کے میچوں کے لئے جو اوورلیپ ہو رہے ہیں ، صرف آخری میچ سے وابستہ اشاریہ جات ہی واپس آئے ہیں۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator سلوک
    ///
    /// واپس لوٹنے والے کا تقاضا ہے کہ پیٹرن ایک الٹ تلاش کی حمایت کرتا ہے ، اور اگر forward/reverse تلاش میں وہی عنصر برآمد ہوں تو یہ [`DoubleEndedIterator`] ہوگا۔
    ///
    ///
    /// سامنے سے تکرار کرنے کے لئے ، [`match_indices`] طریقہ استعمال کیا جاسکتا ہے۔
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // صرف آخری `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// معروف اور ٹریلنگ وائٹ اسپیس ہٹائے جانے کے ساتھ سٹرنگ سلائس واپس کرتا ہے۔
    ///
    /// 'Whitespace' یونیکوڈ اخذ کردہ کور پراپرٹی `White_Space` کی شرائط کے مطابق تعریف کی گئی ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// معروف سفید فام جگہ ہٹانے کے ساتھ سٹرنگ سلائس واپس کرتا ہے۔
    ///
    /// 'Whitespace' یونیکوڈ اخذ کردہ کور پراپرٹی `White_Space` کی شرائط کے مطابق تعریف کی گئی ہے۔
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// `start` اس تناظر میں اس بائٹ ڈور کی پہلی پوزیشن کا مطلب ہے۔انگریزی یا روسی جیسی بائیں سے دائیں زبان کے ل this ، یہ بائیں طرف ہوگا ، اور عربی یا عبرانی جیسی دائیں سے بائیں زبانوں کے لئے ، یہ دائیں طرف ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// وائرل اسپیس ہٹانے کے ساتھ سٹرنگ سلائس واپس کرتا ہے۔
    ///
    /// 'Whitespace' یونیکوڈ اخذ کردہ کور پراپرٹی `White_Space` کی شرائط کے مطابق تعریف کی گئی ہے۔
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// `end` اس تناظر میں اس بائٹ ڈور کی آخری پوزیشن کا مطلب ہے۔انگریزی یا روسی جیسی بائیں سے دائیں زبان کے ل this ، یہ دائیں طرف ہوگا ، اور عربی یا عبرانی جیسی دائیں سے بائیں زبانوں کے لئے ، یہ بائیں طرف ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// معروف سفید فام جگہ ہٹانے کے ساتھ سٹرنگ سلائس واپس کرتا ہے۔
    ///
    /// 'Whitespace' یونیکوڈ اخذ کردہ کور پراپرٹی `White_Space` کی شرائط کے مطابق تعریف کی گئی ہے۔
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// 'Left' اس تناظر میں اس بائٹ ڈور کی پہلی پوزیشن کا مطلب ہے۔عربی یا عبرانی جیسی زبان کے لئے جو 'بائیں سے دائیں' کے بجائے 'دائیں سے بائیں' ہوتی ہے ، یہ _right_ طرف ہوگی ، بائیں نہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// وائرل اسپیس ہٹانے کے ساتھ سٹرنگ سلائس واپس کرتا ہے۔
    ///
    /// 'Whitespace' یونیکوڈ اخذ کردہ کور پراپرٹی `White_Space` کی شرائط کے مطابق تعریف کی گئی ہے۔
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// 'Right' اس تناظر میں اس بائٹ ڈور کی آخری پوزیشن کا مطلب ہے۔عربی یا عبرانی جیسی زبان کے لئے جو 'بائیں سے دائیں' کے بجائے 'دائیں سے بائیں' ہوتی ہے ، یہ _left_ طرف ہوگی ، دائیں نہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// بار بار ہٹائے جانے والے پیٹرن سے ملنے والے تمام سابقوں اور لاحقہ کے ساتھ ایک تار سلائس لوٹاتا ہے۔
    ///
    /// [pattern] ایک [`char`] ، [`چار`] s کا ٹکڑا ، یا کوئی فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// بندش کا استعمال کرتے ہوئے ایک اور پیچیدہ نمونہ:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // قدیم ترین میچ یاد رکھیں ، ذیل میں اسے درست کریں اگر
            // آخری میچ مختلف ہے
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // محفوظ: `Searcher` درست فہرستوں کو واپس کرنے کے لئے جانا جاتا ہے۔
        unsafe { self.get_unchecked(i..j) }
    }

    /// بار بار ہٹائے جانے والے پیٹرن سے ملنے والے تمام سابقوں کے ساتھ سٹرنگ سلائس لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// `start` اس تناظر میں اس بائٹ ڈور کی پہلی پوزیشن کا مطلب ہے۔انگریزی یا روسی جیسی بائیں سے دائیں زبان کے ل this ، یہ بائیں طرف ہوگا ، اور عربی یا عبرانی جیسی دائیں سے بائیں زبانوں کے لئے ، یہ دائیں طرف ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // محفوظ: `Searcher` درست فہرستوں کو واپس کرنے کے لئے جانا جاتا ہے۔
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ہٹائے ہوئے پریفکس کے ساتھ سٹرنگ سلائس لوٹاتا ہے۔
    ///
    /// اگر سٹرنگ `prefix` کے پیٹرن سے شروع ہوتی ہے تو ، `Some` میں لپیٹے ہوئے ، سابقے کے بعد اسٹورنگ لوٹاتا ہے۔
    /// `trim_start_matches` کے برعکس ، یہ طریقہ ایک بار ٹھیک سے ہی سابقہ کو ہٹا دیتا ہے۔
    ///
    /// اگر سٹرنگ `prefix` سے شروع نہیں ہوتی ہے تو ، `None` لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// لاحقہ لاحقہ کے ساتھ سٹرنگ سلائس لوٹاتا ہے۔
    ///
    /// اگر سٹرنگ `suffix` کے پیٹرن کے ساتھ ختم ہوجائے تو ، `Some` میں لپیٹے ہوئے لاحقہ سے پہلے اسٹورنگ لوٹاتا ہے۔
    /// `trim_end_matches` کے برعکس ، یہ طریقہ لاحقہ کو ایک بار بالکل ہٹاتا ہے۔
    ///
    /// اگر تار `suffix` کے ساتھ ختم نہیں ہوتا ہے تو ، `None` کو لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// بار بار ہٹائے جانے والے پیٹرن سے ملنے والے تمام لاحقہ کے ساتھ سٹرنگ سلائس لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// `end` اس تناظر میں اس بائٹ ڈور کی آخری پوزیشن کا مطلب ہے۔انگریزی یا روسی جیسی بائیں سے دائیں زبان کے ل this ، یہ دائیں طرف ہوگا ، اور عربی یا عبرانی جیسی دائیں سے بائیں زبانوں کے لئے ، یہ بائیں طرف ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// بندش کا استعمال کرتے ہوئے ایک اور پیچیدہ نمونہ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // محفوظ: `Searcher` درست فہرستوں کو واپس کرنے کے لئے جانا جاتا ہے۔
        unsafe { self.get_unchecked(0..j) }
    }

    /// بار بار ہٹائے جانے والے پیٹرن سے ملنے والے تمام سابقوں کے ساتھ سٹرنگ سلائس لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// 'Left' اس تناظر میں اس بائٹ ڈور کی پہلی پوزیشن کا مطلب ہے۔عربی یا عبرانی جیسی زبان کے لئے جو 'بائیں سے دائیں' کے بجائے 'دائیں سے بائیں' ہوتی ہے ، یہ _right_ طرف ہوگی ، بائیں نہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// بار بار ہٹائے جانے والے پیٹرن سے ملنے والے تمام لاحقہ کے ساتھ سٹرنگ سلائس لوٹاتا ہے۔
    ///
    /// [pattern] ایک `&str` ، [`char`] ، [`چار`] کا ایک ٹکڑا ، یا ایک فنکشن یا بندش ہوسکتا ہے جو اس بات کا تعین کرتا ہے کہ آیا کوئی کردار مماثل ہے۔
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن کی سمت
    ///
    /// ایک تار بائٹس کا ایک تسلسل ہے۔
    /// 'Right' اس تناظر میں اس بائٹ ڈور کی آخری پوزیشن کا مطلب ہے۔عربی یا عبرانی جیسی زبان کے لئے جو 'بائیں سے دائیں' کے بجائے 'دائیں سے بائیں' ہوتی ہے ، یہ _left_ طرف ہوگی ، دائیں نہیں۔
    ///
    ///
    /// # Examples
    ///
    /// سادہ پیٹرن:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// بندش کا استعمال کرتے ہوئے ایک اور پیچیدہ نمونہ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// اس سٹرنگ سلائس کو دوسری قسم میں پارس کرتا ہے۔
    ///
    /// چونکہ `parse` بہت عام ہے ، لہذا اس کی وجہ سے قسم کی تشخیص میں پریشانی پیدا ہوسکتی ہے۔
    /// اس طرح ، `parse` ان چند بار میں سے ایک ہے جو آپ نحو کو پیار کے ساتھ 'turbofish' کے نام سے جانا جاتا دیکھیں گے۔ `::<>`.
    ///
    /// اس سے اندازہ الگورتھم کو خاص طور پر یہ سمجھنے میں مدد ملتی ہے کہ آپ کس قسم کا تجزیہ کرنے کی کوشش کر رہے ہیں۔
    ///
    /// `parse` [`FromStr`] trait پر عمل درآمد کرنے والی کسی بھی قسم میں تجزیہ کرسکتی ہے۔
    ///

    /// # Errors
    ///
    /// اگر اس سٹرنگ سلائس کو مطلوبہ قسم میں پارس کرنا ممکن نہ ہو تو [`Err`] واپس کردے گا۔
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// بنیادی استعمال
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` کو تشریح کرنے کے بجائے 'turbofish' کا استعمال کریں:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// تجزیہ کرنے میں ناکامی:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// چیک کرتا ہے کہ آیا اس سٹرنگ کے سارے کردار ASCII کی حد میں ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // ہم یہاں ہر بائٹ کو بطور کردار بطور سلوک کرسکتے ہیں: تمام ملٹی بائٹ حروف ایسے بائٹ سے شروع ہوتے ہیں جو اسکی رینج میں نہیں ہے ، لہذا ہم پہلے ہی وہاں رک جائیں گے۔
        //
        //
        self.as_bytes().is_ascii()
    }

    /// چیک کرتا ہے کہ دو تار ایک ASCII کیس غیر حساس میچ ہے۔
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` کی طرح ، لیکن عارضی طور پر مختص اور کاپی کیے بغیر۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// اس سٹرنگ کو اس کے ASCII اپر کیس میں برابر جگہ میں تبدیل کرتا ہے۔
    ///
    /// 'a' سے 'z' تک ASCII حروف 'A' سے 'Z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// موجودہ میں ترمیم کیے بغیر نئی اپرکیسیز ویلیو واپس کرنے کے لئے ، [`to_ascii_uppercase()`] استعمال کریں۔
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // محفوظ: محفوظ ہے کیونکہ ہم ایک ہی ترتیب کے ساتھ دو اقسام کو منتقل کرتے ہیں۔
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// اس سٹرنگ کو اس کے ASCII لوئر کیس کے برابر جگہ میں تبدیل کرتا ہے۔
    ///
    /// 'A' سے 'Z' تک ASCII حروف 'a' سے 'z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// موجودہ میں ترمیم کیے بغیر نئی نچلی قیمت کو واپس کرنے کے لئے ، [`to_ascii_lowercase()`] استعمال کریں۔
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // محفوظ: محفوظ ہے کیونکہ ہم ایک ہی ترتیب کے ساتھ دو اقسام کو منتقل کرتے ہیں۔
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// ایک ایٹریٹر واپس کریں جو ہر چار سے [`char::escape_debug`] میں [`char::escape_debug`] کے ساتھ فرار ہوجائے۔
    ///
    ///
    /// Note: صرف تار بڑھنے والے گرافیم کوڈپوائنٹس سے بچ جائے گا۔
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// ایک ایٹریٹر واپس کریں جو ہر چار سے [`char::escape_default`] میں [`char::escape_default`] کے ساتھ فرار ہوجائے۔
    ///
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// ایک ایٹریٹر واپس کریں جو ہر چار سے [`char::escape_unicode`] میں [`char::escape_unicode`] کے ساتھ فرار ہوجائے۔
    ///
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// ایک خالی str پیدا کرتا ہے
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// ایک خالی میوٹیبل str پیدا کرتا ہے
    #[inline]
    fn default() -> Self {
        // سیکیورٹی: خالی تار درست UTF-8 ہے۔
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// ایک قابل نام ، کلونئبل ایف این قسم
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // حفاظت: محفوظ نہیں ہے
        unsafe { from_utf8_unchecked(bytes) }
    };
}