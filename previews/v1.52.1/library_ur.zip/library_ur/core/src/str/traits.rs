//! `str` کے لئے Trait لاگو۔

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// تاروں کو ترتیب دینے کا عمل نافذ کرتا ہے۔
///
/// اسٹرنگز کو ان کی بائٹ اقدار کے ذریعہ [lexicographically](Ord#lexicographical-comparison) کا آرڈر دیا گیا ہے۔
/// یہ کوڈ چارٹ میں ان کی پوزیشنوں پر مبنی یونیکوڈ کوڈ پوائنٹس کا آرڈر دیتا ہے۔
/// یہ ضروری نہیں کہ "alphabetical" آرڈر جیسا ہو ، جو زبان اور مقام کے لحاظ سے مختلف ہوتا ہے۔
/// ثقافتی طور پر قبول کردہ معیارات کے مطابق تاروں کی ترتیب میں مقامی طور پر مخصوص اعداد و شمار کی ضرورت ہوتی ہے جو `str` قسم کے دائرے سے باہر ہو۔
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// ڈور پر موازنہ کے عمل کو نافذ کرتا ہے۔
///
/// اسٹرنگز کا موازنہ [lexicographically](Ord#lexicographical-comparison) کو ان کی بائٹ اقدار سے کرنا ہے
/// اس میں کوڈ چارٹ میں ان کی پوزیشن کی بنیاد پر کوڈ کوڈ پوائنٹس کا موازنہ کیا گیا ہے۔
/// یہ ضروری نہیں کہ "alphabetical" آرڈر جیسا ہو ، جو زبان اور مقام کے لحاظ سے مختلف ہوتا ہے۔
/// تاروں کا ثقافتی طور پر قبول کردہ معیار کے مطابق موازنہ کرنے میں مقامی طور پر مخصوص ڈیٹا کی ضرورت ہوتی ہے جو `str` قسم کے دائرے سے باہر ہو۔
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// نحو `&self[..]` یا `&mut self[..]` کے ساتھ سلائیزنگ سلائسنگ کا نفاذ کرتا ہے۔
///
/// پوری سٹرنگ کا ایک ٹکڑا لوٹاتا ہے ، یعنی ، `&self` یا `&mut self` کی واپسی کرتا ہے۔`&خود [0 .. کے برابر ہے]
/// لین] `یا`&خود کو تبدیل کریں [0 ..
/// len]`.
/// دیگر اشاریہ سازی کے برعکس ، یہ کبھی بھی panic نہیں کرسکتا ہے۔
///
/// یہ آپریشن *O*(1) ہے۔
///
/// 1.20.0 سے پہلے ، ان اشاریہ سازی کے عملوں کو اب بھی `Index` اور `IndexMut` پر براہ راست عمل درآمد کرنے کی حمایت کی گئی تھی۔
///
/// `&self[0 .. len]` یا `&mut self[0 .. len]` کے برابر۔
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// نحو `&self[begin .. end]` یا `&mut self[begin .. end]` کے ساتھ سلائیزنگ سلائسنگ کا نفاذ کرتا ہے۔
///
/// بائٹ رینج [`شروعات` ، `end`) سے دیئے گئے سٹرنگ کا ایک ٹکڑا لوٹاتا ہے۔
///
/// یہ آپریشن *O*(1) ہے۔
///
/// 1.20.0 سے پہلے ، ان اشاریہ سازی کے عملوں کو اب بھی `Index` اور `IndexMut` پر براہ راست عمل درآمد کرنے کی حمایت کی گئی تھی۔
///
/// # Panics
///
/// Panics اگر `begin` یا `end` کسی کردار کے شروع ہونے والے بائٹ آفسیٹ (`is_char_boundary` کی وضاحت کے مطابق) کی طرف اشارہ نہیں کرتا ہے ، اگر `begin > end` ، یا `end > len` ہے۔
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // یہ panic کرے گا:
/// // بائٹ 2 `ö` کے اندر ہے:
/// // &s [2 ..3]؛
///
/// // بائٹ 8 `老`&s کے اندر ہے [1 ..
/// // 8];
///
/// // بائٹ 100 سٹرنگ سے باہر ہے [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // محفوظ: ابھی ابھی جانچ پڑتال کی کہ `start` اور `end` چار حدود پر ہیں ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            // ہم نے چار حدود کی بھی جانچ کی ، لہذا یہ درست UTF-8 ہے۔
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // محفوظ: ابھی ابھی چیک کیا کہ `start` اور `end` چار حدود پر ہیں۔
            // ہم جانتے ہیں کہ پوائنٹر انوکھا ہے کیونکہ ہمیں یہ `slice` سے ملا ہے۔
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // محفوظ: کال کرنے والا ضمانت دیتا ہے کہ `self` `slice` کی حدود میں ہے
        // جو `add` کی تمام شرائط کو پورا کرتا ہے۔
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // محفوظ: `get_unchecked` کے لئے تبصرے دیکھیں۔
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_bundary چیک کرتا ہے کہ انڈیکس [0 میں ہے ، .len()] اوپر کی طرح `get` کو دوبارہ استعمال نہیں کرسکتا ، کیونکہ NLL پریشانی کی وجہ سے ہے
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // محفوظ: ابھی ابھی جانچ پڑتال کی کہ `start` اور `end` چار حدود پر ہیں ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// نحو `&self[.. end]` یا `&mut self[.. end]` کے ساتھ سلائیزنگ سلائسنگ کا نفاذ کرتا ہے۔
///
/// بائٹ رینج [`0` ، `end`) سے دیئے گئے سٹرنگ کا ایک ٹکڑا لوٹاتا ہے۔
/// `&self[0 .. end]` یا `&mut self[0 .. end]` کے برابر۔
///
/// یہ آپریشن *O*(1) ہے۔
///
/// 1.20.0 سے پہلے ، ان اشاریہ سازی کے عملوں کو اب بھی `Index` اور `IndexMut` پر براہ راست عمل درآمد کرنے کی حمایت کی گئی تھی۔
///
/// # Panics
///
/// Panics اگر `end` کسی کردار کے شروع ہونے والے بائٹ آفسیٹ کی نشاندہی نہیں کرتا ہے (جیسا کہ `is_char_boundary` کی وضاحت ہے) ، یا اگر `end > len` ہے۔
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // محفوظ: ابھی چیک کیا کہ `end` چار باؤنڈری پر ہے ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // محفوظ: ابھی چیک کیا کہ `end` چار باؤنڈری پر ہے ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // محفوظ: ابھی چیک کیا کہ `end` چار باؤنڈری پر ہے ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// نحو `&self[begin ..]` یا `&mut self[begin ..]` کے ساتھ سلائیزنگ سلائسنگ کا نفاذ کرتا ہے۔
///
/// بائٹ رینج [`شروعات` ، `len`) سے دیئے گئے سٹرنگ کا ایک ٹکڑا لوٹاتا ہے۔`اور خود کے برابر [شروع کریں ..
/// لین] `یا`&خود کو تبدیل کریں [شروع کریں ..
/// len]`.
///
/// یہ آپریشن *O*(1) ہے۔
///
/// 1.20.0 سے پہلے ، ان اشاریہ سازی کے عملوں کو اب بھی `Index` اور `IndexMut` پر براہ راست عمل درآمد کرنے کی حمایت کی گئی تھی۔
///
/// # Panics
///
/// Panics اگر `begin` کسی کردار کے شروع ہونے والے بائٹ آفسیٹ کی نشاندہی نہیں کرتا ہے (جیسا کہ `is_char_boundary` کی وضاحت ہے) ، یا اگر `begin > len` ہے۔
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // محفوظ: ابھی چیک کیا کہ `start` چار باؤنڈری پر ہے ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // محفوظ: ابھی چیک کیا کہ `start` چار باؤنڈری پر ہے ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // محفوظ: کال کرنے والا ضمانت دیتا ہے کہ `self` `slice` کی حدود میں ہے
        // جو `add` کی تمام شرائط کو پورا کرتا ہے۔
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // محفوظ: `get_unchecked` کی طرح ہے۔
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // محفوظ: ابھی چیک کیا کہ `start` چار باؤنڈری پر ہے ،
            // اور ہم ایک محفوظ حوالہ سے گزر رہے ہیں ، لہذا واپسی کی قیمت بھی ایک ہوگی۔
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// نحو `&self[begin ..= end]` یا `&mut self[begin ..= end]` کے ساتھ سلائیزنگ سلائسنگ کا نفاذ کرتا ہے۔
///
/// [`begin`, `end`] بائٹ رینج سے دیئے گئے سٹرنگ کا ایک ٹکڑا لوٹاتا ہے۔`&self [begin .. end + 1]` یا `&mut self[begin .. end + 1]` کے مساوی ، سوائے اس کے کہ `end` میں `usize` کی زیادہ سے زیادہ قیمت ہے۔
///
/// یہ آپریشن *O*(1) ہے۔
///
/// # Panics
///
/// Panics اگر `begin` کسی حرف کے شروع ہونے والے بائٹ آفسیٹ کی طرف اشارہ نہیں کرتا ہے (جیسا کہ `is_char_boundary` کی وضاحت ہے) ، اگر `end` کسی حرف کے اختتامی بائٹ آفسیٹ کی طرف اشارہ نہیں کرتا ہے (`end + 1` یا تو ایک ابتدائی بائٹ آفسیٹ ہے یا `len` کے برابر ہے) ، اگر `begin > end` ، یا اگر `end >= len` ہے۔
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // محفوظ: کال کرنے والے کو `get_unchecked` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // محفوظ: کال کرنے والے کو `get_unchecked_mut` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// نحو `&self[..= end]` یا `&mut self[..= end]` کے ساتھ سلائیزنگ سلائسنگ کا نفاذ کرتا ہے۔
///
/// بائٹ رینج [0, `end`] سے دیئے گئے سٹرنگ کا ایک ٹکڑا لوٹاتا ہے۔
/// `&self [0 .. end + 1]` کے مساوی ، سوائے اس کے کہ اگر `end` میں `usize` کی زیادہ سے زیادہ قیمت ہو۔
///
/// یہ آپریشن *O*(1) ہے۔
///
/// # Panics
///
/// Panics اگر `end` کسی حرف کی اختتامی بائٹ آفسیٹ کی طرف اشارہ نہیں کرتا ہے (`end + 1` یا تو ایک ابتدائی بائٹ آفسیٹ ہے جس کی وضاحت `is_char_boundary` کے مطابق ہے ، یا `len` کے برابر ہے) ، یا اگر `end >= len` ہے۔
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // محفوظ: کال کرنے والے کو `get_unchecked` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // محفوظ: کال کرنے والے کو `get_unchecked_mut` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// تار سے کسی قدر کا تجزیہ کریں
///
/// `منجانٹر کا [`from_str`] طریقہ اکثر [` str`] کے [`parse`] طریقہ کے ذریعہ ، واضح طور پر استعمال کیا جاتا ہے۔
/// مثال کے طور پر [ars پارسی] کی دستاویزات دیکھیں۔
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` زندگی بھر کا پیرامیٹر نہیں ہے ، اور لہذا آپ صرف ان اقسام کی تجزیہ کرسکتے ہیں جن میں خود زندگی بھر پیرامیٹر نہیں ہوتا ہے۔
///
/// دوسرے لفظوں میں ، آپ `FromStr` کے ساتھ `i32` کی تجزیہ کرسکتے ہیں ، لیکن `&i32` نہیں۔
/// آپ اسٹرک کا تجزیہ کرسکتے ہیں جس میں `i32` ہو ، لیکن ایسا نہیں جس میں `&i32` ہو۔
///
/// # Examples
///
/// ایک مثال `Point` قسم پر `FromStr` کا بنیادی نفاذ:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// وابستہ غلطی جو پارس کرنے سے واپس آسکتی ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// اس قسم کی کوئی قیمت واپس کرنے کے لئے ایک سٹرنگ `s` کو پارس کرتا ہے۔
    ///
    /// اگر تجزیہ کامیاب ہوجاتا ہے تو ، [`Ok`] کے اندر کی قیمت لوٹائیں ، ورنہ جب تار غلط فارمیٹ ہوا ہے تو اندر کی [`Err`] سے متعلق ایک غلطی واپس کریں۔
    /// غلطی کی قسم trait پر عمل درآمد کے لئے مخصوص ہے۔
    ///
    /// # Examples
    ///
    /// [`i32`] کے ساتھ بنیادی استعمال ، ایک قسم جو `FromStr` کو نافذ کرتی ہے:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// اسٹرنگ سے ایک `bool` پارس کریں۔
    ///
    /// ایک `Result<bool, ParseBoolError>` حاصل کرتا ہے ، کیونکہ `s` اصل میں تجزیہ کار ہوسکتا ہے یا نہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// نوٹ ، بہت سے معاملات میں ، `str` پر `.parse()` کا طریقہ زیادہ مناسب ہے۔
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}