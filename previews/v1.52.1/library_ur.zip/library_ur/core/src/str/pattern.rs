//! سٹرنگ پیٹرن API۔
//!
//! پیٹرن API مختلف طرز کے طریقوں کو استعمال کرنے کے لئے ایک عام طریقہ کار فراہم کرتا ہے جب کسی تار کے ذریعے تلاش کرتے ہیں۔
//!
//! مزید تفصیلات کے لئے ، traits [`Pattern`] ، [`Searcher`] ، [`ReverseSearcher`] ، اور [`DoubleEndedSearcher`] دیکھیں۔
//!
//! اگرچہ یہ API غیر مستحکم ہے ، لیکن [`str`] قسم پر مستحکم API کے ذریعہ اس کا انکشاف کیا گیا ہے۔
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`] ، [`char`] ، [`char`] کے سلائس ، اور `FnMut(char) -> bool` پر عمل درآمد اور بند ہونے کے ل the مستحکم API میں [implemented][pattern-impls] ہے۔
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // چارٹ پیٹرن
//! assert_eq!(s.find('n'), Some(2));
//! // چارس پیٹرن کا ٹکڑا
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // بندش پیٹرن
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// ایک تار پیٹرن
///
/// ایک `Pattern<'a>` اظہار کرتا ہے کہ [`&'a str`][str] میں تلاش کرنے کے لئے عمل درآمد کی قسم کو سٹرنگ پیٹرن کے طور پر استعمال کیا جاسکتا ہے۔
///
/// مثال کے طور پر ، `'a'` اور `"aa"` دونوں پیٹرن ہیں جو `"baaaab"` کے سٹرنگ میں انڈیکس `1` پر ملتے ہیں۔
///
/// trait خود ایک متعلقہ [`Searcher`] قسم کے لئے ایک بلڈر کے طور پر کام کرتا ہے ، جو اسٹرنگ میں پیٹرن کے واقعات کو تلاش کرنے کا اصل کام کرتا ہے۔
///
///
/// پیٹرن کی قسم پر منحصر ہے ، [`str::find`] اور [`str::contains`] جیسے طریقوں کا طرز عمل تبدیل ہوسکتا ہے۔
/// ذیل میں دیئے گئے جدول میں ان میں سے کچھ طرز عمل کی وضاحت کی گئی ہے۔
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// اس طرز کے لئے وابستہ تلاش کنندہ
    type Searcher: Searcher<'a>;

    /// تلاش کرنے کیلئے `self` اور `haystack` سے وابستہ تلاش کنندہ تشکیل دیتا ہے۔
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// یہ جانچ پڑتال کرتا ہے کہ گھاس کے نواح میں کہیں بھی پیٹرن سے میل کھاتا ہے
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// یہ چیک کرتا ہے کہ کیا گھاس کے اگلے حصے میں پیٹرن مماثل ہے
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// یہ چیک کرتا ہے کہ کیا گھاس کے پچھلے حصے میں پیٹرن مماثل ہے
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// اگر یہ مماثل ہے تو گھاس کے سامنے سے پیٹرن کو ہٹاتا ہے۔
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // محفوظ: `Searcher` درست فہرستوں کو واپس کرنے کے لئے جانا جاتا ہے۔
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// اگر یہ میل کھاتا ہے تو گھاس کے پچھلے حصے سے پیٹرن کو ہٹاتا ہے۔
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // محفوظ: `Searcher` درست فہرستوں کو واپس کرنے کے لئے جانا جاتا ہے۔
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] یا [`ReverseSearcher::next_back()`] پر کال کرنے کا نتیجہ۔
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// اظہار کرتا ہے کہ پیٹرن کا ایک میچ `haystack[a..b]` پر پایا گیا ہے۔
    ///
    Match(usize, usize),
    /// اظہار کرتا ہے کہ پیٹرن کے ممکنہ میچ کے طور پر `haystack[a..b]` کو مسترد کردیا گیا ہے۔
    ///
    /// نوٹ کریں کہ دو `میچ`س کے مابین ایک سے زیادہ `Reject` ہوسکتا ہے ، ان میں ایک ساتھ مل جانے کی ضرورت نہیں ہے۔
    ///
    ///
    Reject(usize, usize),
    /// تعبیر کرتا ہے کہ گھاس کا ہر بائٹ ملاحظہ کیا گیا ہے ، اختتام کو ختم کرتے ہوئے۔
    ///
    Done,
}

/// سٹرنگ پیٹرن کے لئے تلاش کرنے والا۔
///
/// یہ trait کسی سٹرنگ کے اگلے (left) سے شروع ہونے والے پیٹرن کے غیر اوورلیپنگ میچوں کی تلاش کے لئے طریقے مہیا کرتا ہے۔
///
/// اس کو [`Pattern`] trait کی متعلقہ `Searcher` اقسام کے ذریعہ لاگو کیا جائے گا۔
///
/// trait غیر محفوظ قرار دیا گیا ہے کیونکہ [`next()`][Searcher::next] طریقوں کے ذریعہ واپس آنے والے اشاریہ جات کو گھاس کی نالی میں درست utf8 حدود پر جھوٹ بولنا ضروری ہے۔
/// اس trait کے صارفین کو اضافی رن ٹائم چیکس کے بغیر گھاس کا ٹکڑا ٹکڑے کرنے کا اہل بناتا ہے۔
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// زیرنگ سٹرنگ کیلئے Z0 گیٹر0 زیڈ
    ///
    /// ہمیشہ ایک ہی [`&str`][str] واپس کرے گا۔
    fn haystack(&self) -> &'a str;

    /// اگلے سرچ مرحلے کو سامنے سے شروع کرتے ہوئے انجام دیتا ہے۔
    ///
    /// - اگر X01 پیٹرن سے میل کھاتا ہے تو [`Match(a, b)`][SearchStep::Match] لوٹاتا ہے۔
    /// - اگر `haystack[a..b]` جزوی طور پر بھی پیٹرن سے میل نہیں کھاتا ہے تو [`Reject(a, b)`][SearchStep::Reject] واپس کرتا ہے۔
    /// - اگر گھاس کا ہر بائٹ ملاحظہ کیا گیا ہو تو [`Done`][SearchStep::Done] واپس کرتا ہے۔
    ///
    /// [`Match`][SearchStep::Match] اور [`Reject`][SearchStep::Reject] قدروں کا [`Done`][SearchStep::Done] تک کا سلسلہ ندی میں ایسی اشاریہ کی حدود پر مشتمل ہوگا جو ملحقہ ، غیر اوورلیپنگ ، پورے گھاس کو ڈھکنے اور utf8 حدود پر پوشیدہ ہے۔
    ///
    ///
    /// ایک [`Match`][SearchStep::Match] کے نتیجے میں پورے مماثل پیٹرن پر مشتمل ہونا ضروری ہے ، تاہم ، [`Reject`][SearchStep::Reject] کے نتائج متعدد ملحقہ ٹکڑوں میں تقسیم ہوسکتے ہیں۔دونوں حدود کی لمبائی صفر ہوسکتی ہے۔
    ///
    /// مثال کے طور پر ، پیٹرن `"aaa"` اور گھاس `"cbaaaaab"` ندی کو پیدا کرسکتا ہے
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// اگلا [`Match`][SearchStep::Match] نتیجہ تلاش کرتا ہے۔[`next()`][Searcher::next] دیکھیں۔
    ///
    /// [`next()`][Searcher::next] کے برعکس ، اس بات کی کوئی ضمانت نہیں ہے کہ اس اور [`next_reject`][Searcher::next_reject] کی واپسی حدود اوورپلائپ ہوں گی۔
    /// یہ `(start_match, end_match)` واپس آئے گا ، جہاں start_match انڈیکس ہے جہاں میچ شروع ہوتا ہے ، اور end_match میچ کے اختتام کے بعد انڈیکس ہے۔
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// اگلا [`Reject`][SearchStep::Reject] نتیجہ تلاش کرتا ہے۔[`next()`][Searcher::next] اور [`next_match()`][Searcher::next_match] دیکھیں۔
    ///
    /// [`next()`][Searcher::next] کے برعکس ، اس بات کی کوئی ضمانت نہیں ہے کہ اس اور [`next_match`][Searcher::next_match] کی واپسی حدود اوورپلائپ ہوں گی۔
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// اسٹرنگ پیٹرن کے لئے ایک الٹا تلاش کرنے والا۔
///
/// یہ trait کسی سٹرنگ کے پچھلے (right) سے شروع ہونے والے پیٹرن کے غیر اوورلیپنگ میچوں کی تلاش کے لئے طریقے مہیا کرتا ہے۔
///
/// [`Pattern`] trait کی متعلقہ [`Searcher`] اقسام کے ذریعہ اس پر عمل درآمد کیا جائے گا اگر پیٹرن پیچھے سے اس کی تلاش میں مدد کرتا ہے۔
///
///
/// اس trait کے ذریعہ واپس کی جانے والی اشاریہ کی حدود کو الٹ میں آگے کی تلاش کے عین مطابق میچ کرنے کی ضرورت نہیں ہے۔
///
/// اس trait پر غیر محفوظ نشان زد ہونے کی وجہ سے ، ان کے والدین trait [`Searcher`] دیکھیں۔
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// اگلے سرچ مرحلے کو پیچھے سے شروع کرتے ہوئے انجام دیتا ہے۔
    ///
    /// - اگر X01 پیٹرن سے میل کھاتا ہے تو [`Match(a, b)`][SearchStep::Match] لوٹاتا ہے۔
    /// - اگر `haystack[a..b]` جزوی طور پر بھی پیٹرن سے میل نہیں کھاتا ہے تو [`Reject(a, b)`][SearchStep::Reject] واپس کرتا ہے۔
    /// - اگر گھاس کا ہر بائٹ ملاحظہ کیا گیا ہو تو [`Done`][SearchStep::Done] واپس کرتا ہے
    ///
    /// [`Match`][SearchStep::Match] اور [`Reject`][SearchStep::Reject] قدروں کا [`Done`][SearchStep::Done] تک کا سلسلہ ندی میں ایسی اشاریہ کی حدود پر مشتمل ہوگا جو ملحقہ ، غیر اوورلیپنگ ، پورے گھاس کو ڈھکنے اور utf8 حدود پر پوشیدہ ہے۔
    ///
    ///
    /// ایک [`Match`][SearchStep::Match] کے نتیجے میں پورے مماثل پیٹرن پر مشتمل ہونا ضروری ہے ، تاہم ، [`Reject`][SearchStep::Reject] کے نتائج متعدد ملحقہ ٹکڑوں میں تقسیم ہوسکتے ہیں۔دونوں حدود کی لمبائی صفر ہوسکتی ہے۔
    ///
    /// ایک مثال کے طور پر ، پیٹرن `"aaa"` اور گھاس `"cbaaaaab"` ندی `[Reject(7, 8) ، Match(4, 7) ، Reject(1, 4) ، Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// اگلا [`Match`][SearchStep::Match] نتیجہ تلاش کرتا ہے۔
    /// [`next_back()`][ReverseSearcher::next_back] دیکھیں۔
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// اگلا [`Reject`][SearchStep::Reject] نتیجہ تلاش کرتا ہے۔
    /// [`next_back()`][ReverseSearcher::next_back] دیکھیں۔
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ایک مارکر trait اس بات کا اظہار کرنے کے لئے کہ [`ReverseSearcher`] کو [`DoubleEndedIterator`] کے نفاذ کے لئے استعمال کیا جاسکتا ہے۔
///
/// اس کے ل X ، [`Searcher`] اور [`ReverseSearcher`] کی ایمپلائ کو ان شرائط پر عمل کرنے کی ضرورت ہے۔
///
/// - `next()` کے تمام نتائج کو الٹا ترتیب میں `next_back()` کے نتائج سے ملتے جلتے ہونے کی ضرورت ہے۔
/// - `next()` اور `next_back()` کو اقدار کی ایک حد کے دونوں سروں کی طرح برتاؤ کرنے کی ضرورت ہے ، وہ یہ ہے کہ وہ "walk past each other" نہیں کرسکتے ہیں۔
///
/// # Examples
///
/// `char::Searcher` ایک `DoubleEndedSearcher` ہے کیونکہ [`char`] کی تلاش میں صرف ایک وقت میں ایک کی ضرورت ہوتی ہے ، جو دونوں سروں سے ایک جیسا ہی سلوک کرتا ہے۔
///
/// `(&str)::Searcher` `DoubleEndedSearcher` نہیں ہے کیونکہ گھاس `"aa"` میں پیٹرن `"aa"` `"[aa]a"` یا `"a[aa]"` کے طور پر مماثل ہے ، اس پر منحصر ہے کہ اسے کس طرف سے تلاش کیا جاتا ہے۔
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// چار کے لئے درخواست
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` کے لئے وابستہ قسم
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // حفاظتی حملہ آور: `finger`/`finger_back` `haystack` کا درست utf8 بائٹ انڈیکس ہونا چاہئے۔ اس ناگوار کو * اگلے_مچ اور اگلے_مچ_ بیک کے اندر توڑا جاسکتا ہے ، البتہ ان کو انگلیوں کے ساتھ درست کوڈ پوائنٹ حدود پر باہر نکلنا ہوگا۔
    //
    //
    /// `finger` آگے کی تلاش کا موجودہ بائٹ انڈیکس ہے۔
    /// ذرا تصور کریں کہ یہ بائیک سے پہلے اپنے انڈیکس میں موجود ہے ، یعنی
    /// `haystack[finger]` سلائس کا پہلا بائٹ ہے جسے ہمیں آگے کی تلاش کے دوران معائنہ کرنا چاہئے
    ///
    finger: usize,
    /// `finger_back` ریورس سرچ کا موجودہ بائٹ انڈیکس ہے۔
    /// ذرا تصور کریں کہ یہ بائٹ کے بعد اپنے انڈیکس میں موجود ہے ، یعنی
    /// گھاس کا نشان [فنگر_بیک ، 1] اس ٹکڑے کا آخری بائٹ ہے جسے ہمیں آگے کی تلاشی کے دوران معائنہ کرنا چاہئے (اور اس طرح next_back()) پر کال کرتے وقت معائنہ کیا جانے والا پہلا بائٹ ہے۔
    ///
    finger_back: usize,
    /// جس کردار کی تلاش کی جارہی ہے
    needle: char,

    // حفاظتی حملہ آور: `utf8_size` 5 سے کم ہونا چاہئے
    /// utf8 میں انکوڈ ہونے پر بائٹس کی تعداد `needle` بڑھ جاتی ہے۔
    utf8_size: usize,
    /// ایک utf8 کو `needle` کی انکوڈ شدہ کاپی
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // سیکیورٹی: `get_unchecked` کی 1-4 ضمانت کی حفاظت
        // 1. `self.finger` اور `self.finger_back` کو یونیکوڈ حدود پر رکھا گیا ہے (یہ ناگزیر ہے)
        // 2. `self.finger >= 0` چونکہ یہ 0 سے شروع ہوتا ہے اور صرف بڑھتا ہے
        // 3. `self.finger < self.finger_back` کیونکہ بصورت دیگر چار `iter` `SearchStep::Done` واپس کردے گا
        // 4.
        // `self.finger` گھاس کے خاتمے سے پہلے آتا ہے کیونکہ `self.finger_back` اختتام پر شروع ہوتا ہے اور صرف کم ہوتا ہے
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 بطور دوبارہ انکوڈنگ کیے بغیر موجودہ کردار کے آفسیٹ کو شامل کریں
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // آخری کردار ملنے کے بعد گھاس کا نشان بنائیں
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 انکوڈڈ سوئی سیفٹی کی آخری بائٹ: ہمارے پاس ناگوار ہے کہ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // نئی انگلی اس بائٹ کی انڈیکس ہے جو ہمیں ملا ، علاوہ ایک ، چونکہ ہم کردار کے آخری بائٹ کے لئے یاد کرتے ہیں۔
                //
                // نوٹ کریں کہ یہ ہمیشہ UTF8 باؤنڈری پر انگلی نہیں دیتا ہے۔
                // اگر ہمیں اپنے کردار کو *نہیں* مل پائے تو ہوسکتا ہے کہ ہم کسی 3 بائٹ یا 4 بائٹ کیریکٹر کی آخری آخری بائٹ کی طرف اشارہ کریں۔
                // ہم صرف اگلے درست شروع ہونے والے بائٹ پر نہیں جاسکتے کیونکہ character (U + A041 YI SYLLABLE PA) ، utf-8 `EA 81 81` جیسے کردار ہمیں تیسری تلاش کرتے وقت ہمیشہ دوسرا بائٹ تلاش کرلیتے ہیں۔
                //
                //
                // تاہم ، یہ بالکل ٹھیک ہے۔
                // اگرچہ ہمارے پاس یہ حملہ آور ہے کہ self.finger ایک UTF8 حدود پر ہے ، لیکن اس حملہ آور کو اس طریقہ کار میں انحصار نہیں کیا جاتا ہے (اس پر انحصار CharSearcher::next()) پر ہے۔
                //
                // ہم صرف اس طریقہ کار سے باہر نکلتے ہیں جب ہم تار کے اختتام پر پہنچ جاتے ہیں ، یا اگر ہمیں کوئی چیز مل جاتی ہے۔جب ہمیں کوئی چیز مل جاتی ہے تو `finger` ایک UTF8 حد میں سیٹ ہوجائے گا۔
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // کچھ نہیں ملا ، باہر نکلیں
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // اگلے_سریکر trait سے پہلے سے طے شدہ نفاذ کو استعمال کریں
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // محفوظ کریں: اوپر next() کے لئے تبصرے دیکھیں
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // بطور موجودہ کردار کی بائٹ آفسیٹ کو X-X بطور دوبارہ انکوڈنگ کیے بغیر
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // گھاس تک پہنچیں لیکن تلاش کردہ آخری کردار کو شامل نہیں کریں
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 انکوڈڈ سوئی سیفٹی کی آخری بائٹ: ہمارے پاس ناگوار ہے کہ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // ہم نے ایک ٹکڑا تلاش کیا جو self.finger کے ذریعہ پیش کیا گیا تھا ، اصل انڈیکس کی بازیابی کے لئے self.finger شامل کریں
                //
                let index = self.finger + index;
                // میمرچرل بائٹ کا انڈیکس واپس کردیں گے جو ہم ڈھونڈنا چاہتے ہیں۔
                // کسی ASCII کردار کی صورت میں ، حقیقت میں یہ تھا کہ ہماری خواہش ہوتی کہ ہماری نئی انگلی ("after" موثر چارٹ کو ریورس ایٹریشن کے نمونے میں) بنائے۔
                //
                // ملٹی بائٹ چارس کے ل AS ہمیں ASCII سے زیادہ بائٹس کی تعداد چھوڑ کر جانے کی ضرورت ہے
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // کردار ملنے سے پہلے انگلی منتقل کریں (یعنی ، اس کے آغاز انڈیکس پر)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // ہم یہاں فنگر بیک بیک=انڈیکس ، سائز + 1 استعمال نہیں کرسکتے ہیں۔
                // اگر ہمیں کسی مختلف سائز کے حرف (یا مختلف کردار کا مڈل بائٹ) کا آخری چارہ ملا تو ہمیں فنگر بیک کو `index` پر ٹکرانے کی ضرورت ہے۔
                // یہ اسی طرح `finger_back` کی حدود میں مزید رہنے کی صلاحیت نہیں رکھتا ہے ، لیکن یہ ٹھیک ہے کیونکہ ہم صرف اس فنکشن کو باؤنڈری پر چھوڑ دیتے ہیں یا جب گھاس کی پٹی کو مکمل طور پر تلاش کیا جاتا ہے۔
                //
                //
                // نیکسٹ_میچ کے برعکس اس میں utf-8 میں بار بار بائٹس کا مسئلہ نہیں ہے کیوں کہ ہم آخری بائٹ تلاش کررہے ہیں ، اور جب ہم الٹ میں تلاش کرتے ہیں تو ہمیں آخری بائٹ ہی مل سکتی ہیں۔
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // کچھ نہیں ملا ، باہر نکلیں
                return None;
            }
        }
    }

    // اگلے_ریجیکٹ_ بیک کو تلاش کرنے والے trait سے پہلے سے طے شدہ نفاذ کا استعمال کریں
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// کرداروں کی تلاشیں جو ایک دیئے گئے [`char`] کے برابر ہیں۔
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// ملٹی چیئر ریپر کے لئے درخواست کریں
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // موجودہ چار کی لمبائی معلوم کرنے کے لئے اندرونی بائٹ سلائس ریٹرٹر کی لمبائی کا موازنہ کریں
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // موجودہ چار کی لمبائی معلوم کرنے کے لئے اندرونی بائٹ سلائس ریٹرٹر کی لمبائی کا موازنہ کریں
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[چار] کے لئے درخواست کریں
/////////////////////////////////////////////////////////////////////////////

// Todo: معنی میں ابہام کی وجہ سے تبدیل/حذف کریں۔

/// `<&[char] as Pattern<'a>>::Searcher` کے لئے وابستہ قسم
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// حجروں کی تلاشیں جو ٹکڑوں میں کسی بھی [`چار`] کے برابر ہیں۔
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// ایف کیلئے درخواست دیں: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` کے لئے وابستہ قسم
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// [`چار`] کی تلاش ہے جو دیئے گئے پیش گوئی سے مماثل ہے۔
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str کے لئے درخواست کریں
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl کے مندوبین
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str کے لئے درخواست دیں
/////////////////////////////////////////////////////////////////////////////

/// غیر مختص اسٹریننگ کی تلاش۔
///
/// `""` کو ہر کردار کی حد پر خالی میچوں کی واپسی کے ساتھ نمونہ سنبھالے گا۔
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// یہ چیک کرتا ہے کہ کیا گھاس کے اگلے حصے میں پیٹرن مماثل ہے۔
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// اگر یہ مماثل ہے تو گھاس کے سامنے سے پیٹرن کو ہٹاتا ہے۔
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // محفوظ کریں: موجودگی کے لئے صرف فرد کی توثیق کی گئی تھی۔
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// یہ چیک کرتا ہے کہ کیا گھاس کے پچھلے حصے میں پیٹرن مماثل ہے۔
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// اگر یہ میل کھاتا ہے تو گھاس کے پچھلے حصے سے پیٹرن کو ہٹاتا ہے۔
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // حفاظت: لاحقہ صرف موجود ہونے کی توثیق کی گئی تھی۔
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ٹو وے اسٹرانگ سرچر
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` کے لئے وابستہ قسم
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // خالی انجکشن ہر چار کو مسترد کرتی ہے اور ان کے درمیان ہر خالی ڈور سے میل کھاتا ہے
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // ٹو وے سیچر درست *میچ* انڈیکس تیار کرتا ہے جو چار حدود میں اس وقت تک تقسیم ہوتا ہے جب تک کہ یہ درست مماثلت نہیں کرتا ہے اور یہ کہ گھاس اسٹیک اور سوئی درست ہے UTF-8 *مستردات* الگورتھم سے کسی بھی انڈیکس پر پڑسکتی ہے ، لیکن ہم ان کو دستی طور پر اگلے کردار کی حد تک چلائیں گے۔ ، تاکہ وہ utf-8 محفوظ رہیں۔
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // اگلی چار باؤنڈری پر جائیں
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` اور `false` مقدمات تحریر کریں تاکہ مرتب کرنے والے کو دونوں معاملات کو الگ سے مہارت حاصل کرنے کی ترغیب ملے۔
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // اگلی چار باؤنڈری پر جائیں
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` اور `false` لکھیں ، جیسے `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// دو طرفہ اسٹورنگ سرچ الگورتھم کی داخلی حالت۔
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// اہم عنصر انڈیکس
    crit_pos: usize,
    /// الٹ انجکشن کے لئے اہم عنصر انڈیکس
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ایک توسیع ہے (دو طرفہ الگورتھم کا حصہ نہیں ہے)؛
    /// یہ ایک 64 بٹ "fingerprint" ہے جہاں ہر سیٹ بٹ `j` انجکشن میں موجود (بائٹ اور 63)==j کے مساوی ہے۔
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// سوئی میں انڈیکس جس سے پہلے ہم مل چکے ہیں
    memory: usize,
    /// سوئی میں انڈیکس جس کے بعد ہم پہلے ہی میچ کرچکے ہیں
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // یہاں جو کچھ ہورہا ہے اس کی ایک خاص طور پر پڑھنے کے قابل وضاحت Crochemore اور Ryter کی کتاب "Text Algorithms" ، ch 13 میں مل سکتی ہے۔
        // خاص طور پر p پر "Algorithm CP" کا کوڈ دیکھیں۔
        // 323.
        //
        // کیا ہو رہا ہے کہ ہمارے پاس سوئی کا کچھ نازک عنصر (u، v) ہے ، اور ہم یہ طے کرنا چاہتے ہیں کہ آپ&v [.. مدت] کا لاحقہ ہے یا نہیں۔
        // اگر یہ ہے تو ، ہم "Algorithm CP1" استعمال کرتے ہیں۔
        // بصورت دیگر ہم "Algorithm CP2" استعمال کرتے ہیں ، جو انجکشن کی مدت بڑی ہونے پر بہتر ہوتا ہے۔
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // مختصر مدت کی صورت-مدت بالکل الٹ انجکشن x=u 'v' جہاں | v '| الگ الگ اہم عنصر کا حساب لگانا ہے<period(x)۔
            //
            // پہلے سے ہی جانے جانے والے دور کی وجہ سے اس کی رفتار بڑھ جاتی ہے۔
            // نوٹ کریں کہ x= "acba" جیسے معاملے کو بالکل فارورڈز (کریک_پوس=1 ، پیریڈ=3) جبکہ ریورس میں قریب مدت کے ساتھ اسٹیکٹر کیا جاسکتا ہے (تنقید_پوز=2 ، مدت=2)۔
            // ہم دیئے گئے معکوس عوامل کو استعمال کرتے ہیں لیکن صحیح مدت کو برقرار رکھتے ہیں۔
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // طویل مدت کا معاملہ-ہمارے پاس اصل مدت سے قریب ہے اور حفظ استعمال نہیں کریں گے۔
            //
            //
            // کم باؤنڈ max(|u|, |v|) + 1 کی طرف سے مدت کا تخمینہ۔
            // آگے بڑھنے اور الٹ تلاش دونوں کے ل use استعمال کرنے کے لئے اہم عنصر کارگر ہے۔
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // ڈمی قدر جو اس بات کی نشاندہی کرے گی کہ مدت لمبی ہے
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // ٹو وے کے اہم خیالات میں سے ایک یہ ہے کہ ہم انجکشن کو دو حصوں میں تقسیم کرتے ہیں ، (u، v) ، اور بائیں سے دائیں اسکین کرکے گھاس کے پٹی میں v تلاش کرنے کی کوشش کرنا شروع کردیتے ہیں۔
    // اگر وی میچ ہوتا ہے تو ، ہم آپ کو دائیں سے بائیں اسکین کرکے میچ کرنے کی کوشش کرتے ہیں۔
    // جب ہم مابعد سے ملتے ہیں تو ہم اس حد تک کتنے کود سکتے ہیں کہ یہ سب اس حقیقت پر مبنی ہے کہ (یو ، وی) انجکشن کے لئے ایک اہم عنصر ہے۔
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` کو اس کے کرسر کے طور پر استعمال کرتا ہے
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // چیک کریں کہ ہمارے پاس پوزیشن + سوئی_لوسٹ میں ڈھونڈنے کی گنجائش ہے اگر ہم فرض کرلیں کہ سلائسیں اسائز کی حد سے جکڑی ہوئی ہیں۔
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // ہمارے حصے سے غیر متعلقہ بڑے حصوں سے جلدی سے جائیں
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // دیکھیں کہ انجکشن کا دایاں حصہ ملتا ہے یا نہیں
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // دیکھیں کہ انجکشن کا بایاں حصہ ملتا ہے یا نہیں
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // ہمیں ایک میچ ملا ہے!
            let match_pos = self.position;

            // Note: اوور لیپنگ میچز کیلئے needle.len() کی بجائے self.period شامل کریں
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // اوورلیپنگ میچوں کے لئے needle.len() ، self.period پر سیٹ کریں
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` میں آئیڈیوں کی پیروی کرتا ہے۔
    //
    // period(x) = period(reverse(x)) اور local_period(u, v) = local_period(reverse(v) ، reverse(u)) کے ساتھ ، تعریفیں متوازی ہیں ، لہذا اگر (u ، v) ایک اہم عنصر ہے ، تو (reverse(v) بھی ہے ، reverse(u)).
    //
    //
    // ریورس کیس کے لئے ہم نے ایک اہم عنصر x=u 'v' (فیلڈ `crit_pos_back`) کی گنتی کی ہے۔ہمیں ضرورت ہے | u |<ایکس00 ایکس فارورڈ کیس کیلئے اور اس طرح | v '|ریورس کے لئے <period(x)۔
    //
    // گھاس کے اس راستے کو تلاش کرنے کے ل we ، ہم ایک الٹ گھاس کے ڈھیر کے ذریعہ آگے کی تلاش میں ڈھل جاتے ہیں ، پہلے یو اور پھر وی سے ملتے ہیں۔
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` کو اس کے کرسر کی حیثیت سے استعمال کرتا ہے-تاکہ `next()` اور `next_back()` آزاد ہوں۔
        //
        let old_end = self.end;
        'search: loop {
            // چیک کریں کہ ہمارے پاس آخر میں تلاش کرنے کے لئے گنجائش موجود ہے ، جب اور جگہ نہ ہو تو needle.len() چاروں طرف لپیٹ جائے گا ، لیکن لمبائی کی حد کی حد کے سبب یہ کبھی بھی کدو کی لمبائی میں کبھی نہیں لپیٹ سکتا ہے۔
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // ہمارے حصے سے غیر متعلقہ بڑے حصوں سے جلدی سے جائیں
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // دیکھیں کہ انجکشن کا بایاں حصہ ملتا ہے یا نہیں
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // دیکھیں کہ انجکشن کا دایاں حصہ ملتا ہے یا نہیں
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // ہمیں ایک میچ ملا ہے!
            let match_pos = self.end - needle.len();
            // Note: اوور لیپنگ میچز کیلئے needle.len() کی بجائے ذیلی self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` کے زیادہ سے زیادہ لاحقہ کی گنتی کریں۔
    //
    // زیادہ سے زیادہ لاحقہ `arr` کا ایک ممکنہ اہم عنصر (u، v) ہے۔
    //
    // واپسی (`i`، `p`) جہاں `i` v کا ابتدائی اشاریہ ہے اور `p` v کی مدت ہے۔
    //
    // `order_greater` اس بات کا تعین کرتا ہے کہ آیا لغوی ترتیب `<` یا `>` ہے۔
    // دونوں آرڈرز کا حساب کتاب ہونا ضروری ہے-سب سے بڑے `i` کے ساتھ آرڈر دینا ایک اہم عنصر دیتا ہے۔
    //
    //
    // طویل مدت کے معاملات کے ل resulting ، نتیجے میں آنے والا دورانیہ عین مطابق نہیں ہوتا ہے (یہ بہت مختصر ہے)۔
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // کاغذ میں I کے مطابق ہے
        let mut right = 1; // کاغذ میں j کے مطابق ہے
        let mut offset = 0; // کاغذ کے مطابق ، لیکن 0 سے شروع
        // 0 پر مبنی اشاریہ سازی سے ملنے کے لئے۔
        let mut period = 1; // کاغذ میں پی کے مطابق ہے

        while let Some(&a) = arr.get(right + offset) {
            // `left` جب `right` ہے تو ان باؤنڈز ہوں گے۔
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // لاحقہ چھوٹا ہے ، دورانیہ اب تک پورا پورا ہے۔
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // موجودہ دور کی تکرار کے ذریعے آگے بڑھیں۔
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // لاحقہ بڑا ہے ، موجودہ جگہ سے شروع کریں۔
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` کے الٹ کے زیادہ سے زیادہ لاحقہ کا حساب لگائیں۔
    //
    // زیادہ سے زیادہ لاحقہ `arr` کا ایک ممکنہ اہم عنصر (u '، v') ہے۔
    //
    // `i` واپس کرتا ہے جہاں `i` پیچھے سے 'v' کا ابتدائی اشاریہ ہے۔
    // جب `known_period` کی مدت پوری ہوجائے تو فورا. واپس آجاتا ہے۔
    //
    // `order_greater` اس بات کا تعین کرتا ہے کہ آیا لغوی ترتیب `<` یا `>` ہے۔
    // دونوں آرڈرز کا حساب کتاب ہونا ضروری ہے-سب سے بڑے `i` کے ساتھ آرڈر دینا ایک اہم عنصر دیتا ہے۔
    //
    //
    // طویل مدت کے معاملات کے ل resulting ، نتیجے میں آنے والا دورانیہ عین مطابق نہیں ہوتا ہے (یہ بہت مختصر ہے)۔
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // کاغذ میں I کے مطابق ہے
        let mut right = 1; // کاغذ میں j کے مطابق ہے
        let mut offset = 0; // کاغذ کے مطابق ، لیکن 0 سے شروع
        // 0 پر مبنی اشاریہ سازی سے ملنے کے لئے۔
        let mut period = 1; // کاغذ میں پی کے مطابق ہے
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // لاحقہ چھوٹا ہے ، دورانیہ اب تک پورا پورا ہے۔
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // موجودہ دور کی تکرار کے ذریعے آگے بڑھیں۔
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // لاحقہ بڑا ہے ، موجودہ جگہ سے شروع کریں۔
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// ٹو وے اسٹریٹیجی الگورتھم کو یا تو غیر میچوں کو جلد سے جلد چھوڑنے کی اجازت دیتا ہے ، یا ایسے موڈ میں کام کرنے کی اجازت دیتا ہے جہاں نسبتا quickly مسترد ہوجاتا ہے۔
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// وقفوں کو جلد سے جلد میچ کرنے کے لئے جائیں
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// باقاعدگی سے اخراج مسترد کریں
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}