//! UTF-8 توثیق سے متعلق آپریشنز۔

use crate::mem;

use super::Utf8Error;

/// پہلے بائٹ کے لئے ابتدائی کوڈپوائنٹ جمع کرنے والا لوٹاتا ہے۔
/// پہلا بائٹ خاص ہے ، صرف چوڑائی 2 کے لئے نیچے 5 بٹس ، چوڑائی 3 کے لئے 4 بٹس ، اور چوڑائی 4 کے لئے 3 بٹس چاہتے ہیں۔
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// تسلسل بائٹ `byte` کے ساتھ تازہ کاری شدہ `ch` کی قدر لوٹاتا ہے۔
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// چیک کرتا ہے کہ بائٹ UTF-8 تسلسل بائٹ ہے (یعنی ، بٹس `10` سے شروع ہوتا ہے)۔
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// اگلے کوڈ پوائنٹ کو بائٹ آئٹرٹر (ایک UTF-8 جیسے انکوڈنگ سنبھالتے ہوئے) پڑھتا ہے۔
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // ڈی کوڈ UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // ملٹی بائٹ کیس باہر کی طرف سے بائٹ مرکب سے ڈی کوڈ کی پیروی کرتا ہے: [[[x y] z] w]
    //
    // NOTE: کارکردگی یہاں پر درست شکل دینے کے لئے حساس ہے
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] معاملہ
        // 0xE0 میں 5 واں سا .. 0xEF ہمیشہ واضح رہتا ہے ، لہذا `init` اب بھی درست ہے
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] کیس `init` کے صرف نچلے 3 بٹس استعمال کریں
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// بائٹ آئٹرٹر سے آخری کوڈ پوائنٹ پڑھتا ہے (UTF-8 جیسے انکوڈنگ کو فرض کرتے ہوئے)
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // ڈی کوڈ UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // ملٹی بائٹ کیس میں سے بائٹ کے امتزاج سے کوڈ کو نکالا جاتا ہے: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64 کو استعمال میں لانے کے لئے تراکیب کا استعمال کریں
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// اگر `x` کے لفظ میں کوئی بائٹ نانوسی (>=128) ہے تو `true` کی واپسی کرتا ہے۔
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` جانچ پڑتال کرتا ہے کہ یہ جائز UTF-8 ترتیب ہے ، اس صورت میں `Ok(())` کو لوٹاتا ہے ، یا ، اگر یہ غلط ہے ، `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // ہمیں ڈیٹا کی ضرورت تھی ، لیکن کوئی بھی نہیں تھا: غلطی!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2 بائٹ انکوڈنگ کوڈپوائنٹس\u {0080} سے\u {07ff} پہلے C2 80 آخری DF BF کیلئے ہے
            // 3 بائٹ انکوڈنگ کوڈپوائنٹس\u {0800} سے\u {ffff for کے لئے ہے۔ پہلے E0 A0 80 آخری EF BF BF کو چھوڑ کر سروگیٹس کوڈپوائنٹس\u {d800} سے\u {dfff} ED A0 80 تا ED BF BF
            // 4 بائٹ انکوڈنگ کوڈپوائنٹس کے لئے ہے\u {1000} 0 سے {u} 10ff first ff پہلے F0 90 80 80 آخری F4 8F BF BF
            //
            // آر ایف سی سے UTF-8 نحو کا استعمال کریں
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=٪ x00-7F UTF8-2=٪ xC2-DF UTF8 دم UTF8-3= %xE0٪ xA0-BF UTF8 دم/٪ xE1-EC 2( UTF8-tail )/%xED٪ x80-9F UTF8-پونچھ/٪ xEE-EF 2( UTF8-tail ) UTF8-4= %xF0٪ x90-BF 2( UTF8-tail )/٪ xF1-F3 3( UTF8-tail )/%xF4٪ x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // اسکی کیس ، جلدی سے آگے بڑھنے کی کوشش کریں۔
            // جب پوائنٹر سیدھ میں ہوجائے تو ، اعداد و شمار کے 2 الفاظ فی تکرار کو پڑھیں جب تک کہ ہمیں ایک ایسا لفظ نہ ملے جب کوئی عیسائ بائٹ نہ ہو۔
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // محفوظ: چونکہ `align - index` اور `ascii_block_size` ہیں
                    // `usize_bytes` ، `block = ptr.add(index)` کے ضوابط ہمیشہ ایک `usize` کے ساتھ منسلک ہوتے ہیں لہذا `block` اور `block.offset(1)` دونوں کو مستحکم کرنا محفوظ ہے۔
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // اگر نونسی بائٹ ہے توڑ دو
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // اس مقام سے قدم اٹھائیں جہاں ورڈ لوپ رک گیا ہے
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// پہلا بائٹ دیا ، اس بات کا تعین کرتا ہے کہ اس UTF-8 کردار میں کتنے بائٹس ہیں۔
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// تسلسل بائٹ کے ویلیو بٹس کا ماسک۔
const CONT_MASK: u8 = 0b0011_1111;
/// تسلسل بائٹ کی ٹیگ بٹس کی قیمت (ٹیگ ماسک !CONT_MASK ہے)۔
const TAG_CONT_U8: u8 = 0b1000_0000;

// `max` کو زیادہ تر برابر `max` کی لمبائی میں چھوٹ دیں ، اگر یہ چھوٹا ہوا تھا تو ، اور نیا str۔
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}