//! utf8 غلطی کی قسم کی وضاحت کرتا ہے۔

use crate::fmt;

/// وہ خامیاں جو [`u8`] کے تسلسل کو اسٹرنگ کی طرح بیان کرنے کی کوشش کرتے وقت رونما ہوسکتی ہیں۔
///
/// اس طرح ، [`اسٹرنگ] اور [`&str`] دونوں کے کام اور طریقوں پر مشتمل `from_utf8` فیملی اس غلطی کو استعمال کرتی ہے ، مثال کے طور پر۔
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// اس غلطی کے طریقوں کا استعمال ہیپ میموری کو مختص کیے بغیر `String::from_utf8_lossy` کی طرح کی فعالیت پیدا کرنے کے لئے کیا جاسکتا ہے:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// دیئے گئے اسٹرنگ میں انڈیکس لوٹاتا ہے جس تک درست UTF-8 کی توثیق ہوئی تھی۔
    ///
    /// یہ ایسا زیادہ سے زیادہ انڈیکس ہے کہ `from_utf8(&input[..index])` `Ok(_)` واپس کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector میں کچھ غلط بائٹس
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 ایک Utf8Error واپس کرتا ہے
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // دوسرا بائٹ یہاں باطل ہے
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ناکامی کے بارے میں مزید معلومات فراہم کرتا ہے:
    ///
    /// * `None`: ان پٹ کا اختتام غیر متوقع طور پر پہنچا تھا۔
    ///   `self.valid_up_to()` ان پٹ کے اختتام سے 1 سے 3 بائٹس ہے۔
    ///   اگر بائٹ اسٹریم (جیسے فائل یا نیٹ ورک ساکٹ) کو تیزی سے ڈی کوڈ کیا جارہا ہے تو ، یہ ایک درست `char` ہوسکتا ہے جس کا UTF-8 بائٹ تسلسل متعدد حصوں پر پھیلا ہوا ہے۔
    ///
    ///
    /// * `Some(len)`: ایک غیر متوقع بائٹ کا سامنا کرنا پڑا۔
    ///   فراہم کردہ لمبائی غلط باائٹ تسلسل کی ہے جو `valid_up_to()` کے ذریعہ دیئے گئے انڈیکس پر شروع ہوتی ہے۔
    ///   نقصان دہ ڈویکنگ کی صورت میں اس ترتیب (ایک [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] داخل کرنے کے بعد) کے بعد کوڈ کو دوبارہ شروع کرنا چاہئے۔
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] کا استعمال کرتے ہوئے `bool` کی پارس کرتے وقت ایک خامی واپس آگئی
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}