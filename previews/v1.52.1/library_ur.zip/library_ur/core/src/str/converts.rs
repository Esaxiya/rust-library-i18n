//! بائٹس سلائس سے `str` بنانے کے طریقے۔

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// بائٹس کے سلائس کو سٹرنگ سلائس میں تبدیل کرتا ہے۔
///
/// اسٹرنگ سلائس ([`&str`]) بائٹس ([`u8`]) سے بنا ہے ، اور بائٹ سلائس ([`&[u8]`][byteslice]) بائٹس سے بنا ہوا ہے ، لہذا یہ فنکشن دونوں کے مابین تبدیل ہوجاتا ہے۔
/// تمام بائٹ سلائسس درست سٹرنگ سلائسس نہیں ہوتے ہیں ، تاہم: [`&str`] کی ضرورت ہوتی ہے کہ یہ درست UTF-8 ہے۔
/// `from_utf8()` اس بات کو یقینی بنانے کے لئے چیک کرتا ہے کہ بائٹس درست UTF-8 ہیں ، اور پھر تبادلوں کا کام کرتا ہے۔
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// اگر آپ کو یقین ہے کہ بائٹ سلائس درست UTF-8 ہے ، اور آپ کو توثیق کی جانچ پڑتال نہیں کرنا چاہتی ہے تو ، اس فنکشن کا ایک غیر محفوظ ورژن ہے ، [`from_utf8_unchecked`] ، جو ایک ہی طرز عمل رکھتا ہے لیکن چیک کو چھوڑ دیتا ہے۔
///
///
/// اگر آپ کو `&str` کی بجائے `String` کی ضرورت ہو تو ، [`String::from_utf8`][string] پر غور کریں۔
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// چونکہ آپ ایک `[u8; N]` کو اسٹیک مختص کرسکتے ہیں ، اور آپ اس کا [`&[u8]`][byteslice] لے سکتے ہیں ، لہذا یہ اسٹیک اسٹیک مختص تار کا ایک طریقہ ہے۔ذیل میں مثالوں کے حصے میں اس کی ایک مثال موجود ہے۔
///
/// [byteslice]: slice
///
/// # Errors
///
/// اگر سلائس UTF-8 نہیں ہے تو وضاحت کے ساتھ `Err` لوٹاتا ہے کہ فراہم کردہ سلائس UTF-8 کیوں نہیں ہے۔
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::str;
///
/// // کچھ بائٹس ، vector میں
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ہم جانتے ہیں کہ یہ بائٹس درست ہیں ، لہذا صرف `unwrap()` استعمال کریں۔
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// غلط بائٹس:
///
/// ```
/// use std::str;
///
/// // vector میں کچھ غلط بائٹس
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// واپس آنے والی غلطیوں کی نوعیت کے بارے میں مزید تفصیلات کے لئے [`Utf8Error`] کے لئے دستاویزات دیکھیں۔
///
/// ایک "stack allocated string":
///
/// ```
/// use std::str;
///
/// // کچھ بائٹس ، اسٹیک مختص صف میں
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // ہم جانتے ہیں کہ یہ بائٹس درست ہیں ، لہذا صرف `unwrap()` استعمال کریں۔
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // محفوظ کریں: ابھی توثیق ہوگئی۔
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// بائٹس کے تبدیل شدہ سلائس کو بدلنے والے سٹرنگ سلائس میں تبدیل کرتا ہے۔
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" ایک تبدیل vector کے طور پر
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // جیسا کہ ہم جانتے ہیں کہ یہ بائٹس درست ہیں ، ہم `unwrap()` استعمال کرسکتے ہیں
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// غلط بائٹس:
///
/// ```
/// use std::str;
///
/// // تبدیل شدہ vector میں کچھ غلط بائٹس
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// واپس آنے والی غلطیوں کی نوعیت کے بارے میں مزید تفصیلات کے لئے [`Utf8Error`] کے لئے دستاویزات دیکھیں۔
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // محفوظ کریں: ابھی توثیق ہوگئی۔
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// بائٹس کے ایک سلائس کو سٹرنگ سلائس میں تبدیل کرتا ہے بغیر یہ چیک کیے کہ اسٹرنگ میں درست UTF-8 ہے۔
///
/// مزید معلومات کے لئے ، محفوظ ورژن ، [`from_utf8`] دیکھیں۔
///
/// # Safety
///
/// یہ فنکشن غیر محفوظ ہے کیونکہ اس کی جانچ نہیں ہوتی ہے کہ اس کو بھیجے گئے بائٹس درست UTF-8 ہیں۔
/// اگر اس رکاوٹ کی خلاف ورزی کی گئی ہے تو ، غیر متعینہ طرز عمل کے نتائج ، جیسا کہ بقیہ Rust فرض کرلیتا ہے کہ [`&str`] جائز UTF-8 ہیں۔
///
///
/// [`&str`]: str
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::str;
///
/// // کچھ بائٹس ، vector میں
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // محفوظ: کال کرنے والے کو ضمانت دینا ہوگی کہ بائٹس `v` درست UTF-8 ہیں۔
    // ایک ہی ترتیب رکھنے والے `&str` اور `&[u8]` پر بھی انحصار کرتا ہے۔
    unsafe { mem::transmute(v) }
}

/// بائٹس کے ایک سلائس کو سٹرنگ سلائس میں تبدیل کرتا ہے بغیر یہ چیک کیے کہ اسٹرنگ میں درست UTF-8 ہے۔بدلنے والا ورژن
///
///
/// مزید معلومات کے لئے ناقابل تغیراتی ورژن ، [`from_utf8_unchecked()`] دیکھیں۔
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ بائٹس `v` ہے
    // درست UTF-8 ہیں ، اس طرح `*mut str` پر کاسٹ محفوظ ہے۔
    // نیز ، پوائنٹر ڈیریفرنس محفوظ ہے کیونکہ وہ اشارہ ایک حوالہ سے آتا ہے جس کی تحریروں کے لئے موزوں ہونے کی ضمانت ہے۔
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}