//! سست قدریں اور جامد اعداد و شمار کا ایک وقتی آغاز۔

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// ایک سیل جس میں صرف ایک بار لکھا جاسکتا ہے۔
///
/// `RefCell` کے برعکس ، ایک `OnceCell` صرف اس کی قیمت کے مشترکہ `&T` حوالہ جات فراہم کرتا ہے۔
/// `Cell` کے برعکس ، ایک `OnceCell` کو قیمت تک رسائی حاصل کرنے کے لئے کاپی کرنے یا اس کی جگہ لینے کی ضرورت نہیں ہے۔
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // ناگوار: ایک بار میں زیادہ سے زیادہ
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// ایک نیا خالی سیل بناتا ہے۔
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// بنیادی قیمت کا حوالہ دیتا ہے۔
    ///
    /// اگر خالی ہے تو `None` لوٹاتا ہے۔
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // محفوظ: `اندرونی inv کے حملہ آور کی وجہ سے محفوظ ہے
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// بنیادی قیمت کا تغیر پذیر حوالہ ملتا ہے۔
    ///
    /// اگر خالی ہے تو `None` لوٹاتا ہے۔
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // حفاظت: محفوظ کیونکہ ہمارے پاس منفرد رسائی ہے
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// سیل کے مندرجات کو `value` پر سیٹ کریں۔
    ///
    /// # Errors
    ///
    /// یہ طریقہ `Ok(())` واپس کرتا ہے اگر سیل خالی تھا اور `Err(value)` اگر یہ بھرا ہوا تھا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // محفوظ کریں: محفوظ ہے کیونکہ ہمارے پاس بدلی جداگانہ قرض نہیں ہوسکتا ہے
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // حفاظت: یہ واحد جگہ ہے جہاں ہم نے سلاٹ طے کیا ، کوئی ریس نہیں
        // reentrancy/concurrency کی وجہ سے ممکن ہے ، اور ہم نے جانچ پڑتال کی ہے کہ اس وقت سلاٹ `None` ہے ، لہذا یہ تحریر `اندرونی کے ناگوار کو برقرار رکھتی ہے۔
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// سیل کے مندرجات کو حاصل کرتا ہے ، اگر خالی تھا تو اسے `f` سے شروع کریں۔
    ///
    /// # Panics
    ///
    /// اگر `f` panics ، panic کو فون کرنے والے تک پہونچایا جاتا ہے ، اور خلیہ بن بلا ہی رہتا ہے۔
    ///
    ///
    /// `f` سے سیل کو بار بار شروع کرنا غلطی ہے۔ایسا کرنے کا نتیجہ panic ہوجاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// سیل کے مندرجات کو حاصل کرتا ہے ، اگر خالی تھا تو اسے `f` سے شروع کریں۔
    /// اگر سیل خالی تھا اور `f` ناکام ہوگیا تو ، ایک خامی واپس کردی گئی۔
    ///
    /// # Panics
    ///
    /// اگر `f` panics ، panic کو فون کرنے والے تک پہونچایا جاتا ہے ، اور خلیہ بن بلا ہی رہتا ہے۔
    ///
    ///
    /// `f` سے سیل کو بار بار شروع کرنا غلطی ہے۔ایسا کرنے کا نتیجہ panic ہوجاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // نوٹ کریں کہ *کچھ* کرایے کرنے والی ابتدائی شکلیں UB کا باعث بن سکتی ہیں (دیکھیں `reentrant_init` ٹیسٹ)۔
        // مجھے یقین ہے کہ `set/get` کو رکھنا صرف اس `assert` کو ہٹانا درست ہوگا ، لیکن خاموشی سے پرانی قدر کو استعمال کرنے کی بجائے panic کو بہتر لگتا ہے۔
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// لپیٹی ہوئی قیمت لوٹاتے ہوئے ، سیل کا استعمال کرتا ہے۔
    ///
    /// اگر سیل خالی تھا تو `None` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // چونکہ `into_inner` `self` کو قدر کے حساب سے لیتا ہے ، مرتب اعدادوشمار کی تصدیق کرتا ہے کہ یہ فی الحال قرض نہیں لیا گیا ہے۔
        // لہذا `Option<T>` کو باہر منتقل کرنا محفوظ ہے۔
        self.inner.into_inner()
    }

    /// اس `OnceCell` سے قدر نکالتا ہے ، اسے واپس بلا بناوٹ حالت میں منتقل کرتا ہے۔
    ///
    /// کوئی اثر نہیں پڑتا ہے اور اگر `OnceCell` کی ابتدا نہیں کی گئی ہے تو `None` واپس کردیتی ہے۔
    ///
    /// کسی تغیر پزیر حوالہ کی ضرورت سے حفاظت کی ضمانت ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ایک ایسی قیمت جو پہلی رسائی سے شروع کی جاتی ہے۔
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   شروع کرنے کے لئے تیار
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// دیئے گئے ابتدائی فنکشن کے ساتھ ایک نیا سست قدر بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// اس سست قدر کی تشخیص پر مجبور کرتا ہے اور نتائج کا حوالہ دیتا ہے۔
    ///
    ///
    /// یہ `Deref` impl کے برابر ہے ، لیکن واضح ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// شروع کرنے والے فنکشن کے بطور `Default` استعمال کرکے ایک نئی سست قدر بناتی ہے۔
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}