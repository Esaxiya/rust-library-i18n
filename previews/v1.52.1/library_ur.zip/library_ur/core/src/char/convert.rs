//! کردار کی تبدیلی۔

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` کو `char` میں تبدیل کرتا ہے۔
///
/// نوٹ کریں کہ تمام [`چار`] جائز ہیں [`u32`] s ، اور جس کے ساتھ ایک کاسٹ کیا جاسکتا ہے
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// تاہم ، اس کے برعکس سچ نہیں ہے: تمام درست [`u32`] s [[Char`] s کے لئے درست نہیں ہیں۔
/// `from_u32()` اگر ان پٹ [`char`] کے لئے درست قدر نہیں ہے تو `None` واپس کرے گا۔
///
/// اس فنکشن کے غیر محفوظ ورژن کے لئے جو ان چیکوں کو نظرانداز کرتا ہے ، دیکھیں [`from_u32_unchecked`]۔
///
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None` واپس کرنا جب ان پٹ درست [`char`] نہیں ہے:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// درستگی کو نظر انداز کرتے ہوئے ، ایک `char` کو `char` میں تبدیل کرتا ہے۔
///
/// نوٹ کریں کہ تمام [`چار`] جائز ہیں [`u32`] s ، اور جس کے ساتھ ایک کاسٹ کیا جاسکتا ہے
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// تاہم ، اس کے برعکس سچ نہیں ہے: تمام درست [`u32`] s [[Char`] s کے لئے درست نہیں ہیں۔
/// `from_u32_unchecked()` اس کو نظرانداز کرے گا ، اور [`char`] پر آنکھیں بند کردیئے جائیں گے ، ممکنہ طور پر ایک غلط بنائیں۔
///
///
/// # Safety
///
/// یہ فنکشن غیر محفوظ ہے ، کیونکہ یہ غلط `char` قدریں تشکیل دے سکتا ہے۔
///
/// اس فنکشن کے محفوظ ورژن کے لئے ، [`from_u32`] فنکشن دیکھیں۔
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `i` ایک درست چار ویلیو ہے۔
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] کو [`u32`] میں تبدیل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] کو [`u64`] میں تبدیل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // چار کوڈ پوائنٹ کی قدر کے مطابق باندھا جاتا ہے ، پھر صفر سے بڑھا کر 64 بٹ ہوجاتا ہے۔
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] دیکھیں
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] کو [`u128`] میں تبدیل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // چار کوڈ پوائنٹ کی قدر کے مطابق باندھا جاتا ہے ، پھر صفر سے بڑھا کر 128 بٹ کردیا جاتا ہے۔
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] دیکھیں
        c as u128
    }
}

/// 0x00 میں ایک بائٹ کا نقشہ ..=0xFF ایک `char` پر جس کے کوڈ پوائنٹ کی ایک ہی قدر ہے U + 0000 ..=U + 00FF میں۔
///
/// یونیکوڈ کو اس طرح ڈیزائن کیا گیا ہے کہ اس سے بائیکٹس کو ان کردار کے انکوڈنگ کے ساتھ موثر انداز میں ضابطہ اخذ کیا جاتا ہے جسے IANA ISO-8859-1 کہتے ہیں۔
/// یہ انکوڈنگ ASCII کے ساتھ مطابقت رکھتی ہے۔
///
/// نوٹ کریں کہ یہ ISO/IEC 8859-1 عرف سے مختلف ہے
/// آئی ایس او 8859-1 (ایک کم ہائفن کے ساتھ) ، جو کچھ "blanks" ، بائٹ ویلیوز چھوڑ دیتا ہے جو کسی بھی کردار کو تفویض نہیں کیا جاتا ہے۔
/// ISO-8859-1 (IANA ایک) انہیں C0 اور C1 کنٹرول کوڈ پر تفویض کرتا ہے۔
///
/// نوٹ کریں کہ یہ ونڈوز 1252 عرف سے بھی * مختلف ہے
/// کوڈ کا صفحہ 1252 ، جو ایک سپرٹ ISO/IEC 8859-1 ہے جو کچھ (تمام نہیں!) خالی جگہوں کو اوقاف اور مختلف لاطینی حروف کو تفویض کرتا ہے۔
///
/// چیزوں کو مزید الجھانے کے ل X ، [on the Web](https://encoding.spec.whatwg.org/) `ascii` ، `iso-8859-1` ، اور `windows-1252` ونڈوز 1252 کے سپر اسٹیٹ کے تمام عرفی نام ہیں جو C0 اور C1 کنٹرول کوڈ کے ساتھ باقی خالی جگہوں کو بھرتے ہیں۔
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] کو [`char`] میں تبدیل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// ایک غلطی جو چار کو پارس کرتے وقت واپس کی جاسکتی ہے۔
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // محفوظ: جانچ پڑتال کی کہ یہ قانونی یونیکوڈ ویلیو ہے
            Ok(unsafe { transmute(i) })
        }
    }
}

/// جب u32 سے چار میں تبادلہ ناکام ہوتا ہے تو غلطی کی قسم واپس آ جاتی ہے۔
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// دیئے گئے ریڈکس میں ایک ہندسے کو `char` میں تبدیل کرتا ہے۔
///
/// یہاں ایک 'radix' کبھی کبھی 'base' بھی کہا جاتا ہے۔
/// دو کی رڈکس کچھ عام اقدار دینے کے ل a ، ایک بائنری نمبر ، دس کے دس ، اعشاریہ ، اور سولہ ، ہیکساڈسیمل کے ایک رڈکس کی نشاندہی کرتی ہے۔
///
/// صوابدیدی تابکاری کی حمایت کی جاتی ہے۔
///
/// `from_digit()` اگر ان پٹ دیئے گئے رڈکس میں کوئی ہندسہ نہیں ہے تو `None` لوٹائے گا۔
///
/// # Panics
///
/// Panics اگر 36 سے زیادہ کا ریڈکس دیا جائے۔
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // بیس 16 میں اعشاریہ 11 ایک ہندسہ ہے
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// جب ان پٹ کوئی ہندسہ نہیں ہوتا ہے تو `None` واپس کرنا:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ایک بڑی رڈیکس کا گزرنا ، panic کا سبب بنتا ہے:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}