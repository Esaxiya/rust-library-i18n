//! impl چار {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// ایک `char` میں سب سے زیادہ درست کوڈ پوائنٹ ہوسکتا ہے۔
    ///
    /// A `char` ایک [Unicode Scalar Value] ہے ، جس کا مطلب ہے کہ یہ ایک [Code Point] ہے ، لیکن صرف ایک مخصوص حد میں ہے۔
    /// `MAX` ایک اعلی ترین درست کوڈ پوائنٹ ہے جو ایک درست [Unicode Scalar Value] ہے۔
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` یونیکوڈ میں ضابطہ کشائی کی غلطی کی نمائندگی کرنے کے لئے () استعمال کیا جاتا ہے۔
    ///
    /// یہ واقع ہوسکتا ہے ، مثال کے طور پر ، جب [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) کو غیر منقولہ UTF-8 بائٹس دیتے وقت۔
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) کا ورژن جس پر `char` اور `str` طریقوں کے یونیکوڈ حصے پر مبنی ہیں۔
    ///
    /// یونیکوڈ کے نئے ورژن باقاعدگی سے جاری کیے جاتے ہیں اور اس کے بعد یونیکوڈ پر منحصر معیاری لائبریری کے تمام طریقوں کو اپ ڈیٹ کیا جاتا ہے۔
    /// لہذا کچھ `char` اور `str` طریقوں کا برتاؤ اور وقت کے ساتھ ساتھ اس مستقل تبدیلیوں کی قدر۔
    /// اس کو توڑ پھوڑ سمجھا جاتا ہے۔
    ///
    /// ورژن نمبر اسکیم کی وضاحت [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) میں کی گئی ہے۔
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` میں UTF-16 انکوڈڈ کوڈ پوائنٹس کے اوپر ایک ایٹرٹر بناتا ہے ، بغیر کسی جوڑی والے سرجیکیٹس کو بطور `ایرس واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` کے نتائج کو متبادل کردار سے تبدیل کرکے ایک نقصان دہ ڈویکڈر حاصل کیا جاسکتا ہے:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` کو `char` میں تبدیل کرتا ہے۔
    ///
    /// نوٹ کریں کہ تمام چارس درست ہیں [`u32`] s ، اور جس کے ساتھ کسی کو کاسٹ کیا جاسکتا ہے
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// تاہم ، اس کے برعکس سچ نہیں ہے: تمام درست [`u32`] درست چارجز نہیں ہیں۔
    /// `from_u32()` اگر ان پٹ `char` کے لئے درست قدر نہیں ہے تو `None` واپس کرے گا۔
    ///
    /// اس فنکشن کے غیر محفوظ ورژن کے لئے جو ان چیکوں کو نظرانداز کرتا ہے ، دیکھیں [`from_u32_unchecked`]۔
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` واپس کرنا جب ان پٹ درست `char` نہیں ہے:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// درستگی کو نظر انداز کرتے ہوئے ، ایک `char` کو `char` میں تبدیل کرتا ہے۔
    ///
    /// نوٹ کریں کہ تمام چارس درست ہیں [`u32`] s ، اور جس کے ساتھ کسی کو کاسٹ کیا جاسکتا ہے
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// تاہم ، اس کے برعکس سچ نہیں ہے: تمام درست [`u32`] درست چارجز نہیں ہیں۔
    /// `from_u32_unchecked()` اس کو نظرانداز کرے گا ، اور `char` پر آنکھیں بند کردیئے جائیں گے ، ممکنہ طور پر ایک غلط بنائیں۔
    ///
    ///
    /// # Safety
    ///
    /// یہ فنکشن غیر محفوظ ہے ، کیونکہ یہ غلط `char` قدریں تشکیل دے سکتا ہے۔
    ///
    /// اس فنکشن کے محفوظ ورژن کے لئے ، [`from_u32`] فنکشن دیکھیں۔
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // حفاظت: حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے۔
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// دیئے گئے ریڈکس میں ایک ہندسے کو `char` میں تبدیل کرتا ہے۔
    ///
    /// یہاں ایک 'radix' کبھی کبھی 'base' بھی کہا جاتا ہے۔
    /// دو کی رڈکس کچھ عام اقدار دینے کے ل a ، ایک بائنری نمبر ، دس کے دس ، اعشاریہ ، اور سولہ ، ہیکساڈسیمل کے ایک رڈکس کی نشاندہی کرتی ہے۔
    ///
    /// صوابدیدی تابکاری کی حمایت کی جاتی ہے۔
    ///
    /// `from_digit()` اگر ان پٹ دیئے گئے رڈکس میں کوئی ہندسہ نہیں ہے تو `None` لوٹائے گا۔
    ///
    /// # Panics
    ///
    /// Panics اگر 36 سے زیادہ کا ریڈکس دیا جائے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // بیس 16 میں اعشاریہ 11 ایک ہندسہ ہے
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// جب ان پٹ کوئی ہندسہ نہیں ہوتا ہے تو `None` واپس کرنا:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ایک بڑی رڈیکس کا گزرنا ، panic کا سبب بنتا ہے:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// جانچ پڑتال کرتا ہے کہ دیئے گئے رڈکس میں اگر `char` عددی ہے۔
    ///
    /// یہاں ایک 'radix' کبھی کبھی 'base' بھی کہا جاتا ہے۔
    /// دو کی رڈکس کچھ عام اقدار دینے کے ل a ، ایک بائنری نمبر ، دس کے دس ، اعشاریہ ، اور سولہ ، ہیکساڈسیمل کے ایک رڈکس کی نشاندہی کرتی ہے۔
    ///
    /// صوابدیدی تابکاری کی حمایت کی جاتی ہے۔
    ///
    /// [`is_numeric()`] کے مقابلے میں ، اس فنکشن میں صرف `0-9` ، `a-z` اور `A-Z` حروف کی شناخت کی گئی ہے۔
    ///
    /// 'Digit' صرف مندرجہ ذیل حروف کی تعریف کی گئی ہے:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' کی مزید جامع تفہیم کے لئے ، [`is_numeric()`] ملاحظہ کریں۔
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics اگر 36 سے زیادہ کا ریڈکس دیا جائے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ایک بڑی رڈیکس کا گزرنا ، panic کا سبب بنتا ہے:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` X کو دیئے گئے رڈکس میں ایک ہندسے میں بدلتا ہے۔
    ///
    /// یہاں ایک 'radix' کبھی کبھی 'base' بھی کہا جاتا ہے۔
    /// دو کی رڈکس کچھ عام اقدار دینے کے ل a ، ایک بائنری نمبر ، دس کے دس ، اعشاریہ ، اور سولہ ، ہیکساڈسیمل کے ایک رڈکس کی نشاندہی کرتی ہے۔
    ///
    /// صوابدیدی تابکاری کی حمایت کی جاتی ہے۔
    ///
    /// 'Digit' صرف مندرجہ ذیل حروف کی تعریف کی گئی ہے:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// اگر `char` دیئے گئے رڈکس میں کسی ہندسے کا حوالہ نہیں دیتا ہے تو `None` واپس کرتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر 36 سے زیادہ کا ریڈکس دیا جائے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ناکامی میں غیر ہندسے کے نتائج کو پاس کرنا:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ایک بڑی رڈیکس کا گزرنا ، panic کا سبب بنتا ہے:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` مستقل اور 10 یا اس سے چھوٹا معاملات کے لئے عمل درآمد کی رفتار کو بہتر بنانے کے لئے کوڈ کو یہاں تقسیم کیا گیا ہے
        //
        let val = if likely(radix <= 10) {
            // اگر کوئی ہندسہ نہیں ہے تو ، ریڈکس سے بڑی تعداد تشکیل دی جائے گی۔
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// ایک ایٹریٹر لوٹاتا ہے جو کسی کردار کے ہیکساڈسمل یونیکوڈ فرار کو بطور چارج حاصل کرتا ہے۔
    ///
    /// یہ `\u{NNNNNN}` فارم کے Rust نحو کے حرفوں سے بچ جائے گا جہاں `NNNNNN` ایک ہیکساڈسیمل نمائندگی ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // یا-1 1 اس بات کو یقینی بناتا ہے کہ c==0 کے لئے کوڈ کا حساب لگاتا ہے کہ ایک ہندسہ چھاپنا چاہئے اور (جو ایک جیسی ہے) انڈر فلو (31 ، 32) سے گریز کرتا ہے
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // انتہائی اہم ہیکس ہندسے کا اشاریہ
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` کا ایک توسیع شدہ ورژن جو اختیاری طور پر توسیعی گرافیم کوڈپوائنٹس سے فرار ہونے کی اجازت دیتا ہے۔
    /// اس کی مدد سے ہم کرداروں کو فارمیٹ کرسکتے ہیں جیسے نان اسپیسنگ مارکس جب اسٹرنگ کے آغاز پر ہوتے ہیں۔
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ایک آئیٹر لوٹاتا ہے جو کسی کردار کے لغوی فرار کوڈ کو بطور چارج حاصل کرتا ہے۔
    ///
    /// یہ `str` یا `char` کے `Debug` نفاذ کی طرح کے حروف سے بچ جائے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ایک آئیٹر لوٹاتا ہے جو کسی کردار کے لغوی فرار کوڈ کو بطور چارج حاصل کرتا ہے۔
    ///
    /// ڈیفالٹ کا انتخاب لفظی تیار کرنے کی طرف تعصب کے ساتھ کیا جاتا ہے جو مختلف زبانوں میں قانونی ہیں جن میں C++ 11 اور اسی طرح کی سی فیملی زبانیں شامل ہیں۔
    /// عین قواعد یہ ہیں:
    ///
    /// * ٹیب `\t` کے طور پر فرار ہوگیا ہے۔
    /// * کیریج کی واپسی `\r` کے طور پر فرار ہوگئی ہے۔
    /// * لائن فیڈ `\n` کے طور پر فرار ہوگیا ہے۔
    /// * ایک حوالہ `\'` کے طور پر فرار ہوگیا ہے۔
    /// * ڈبل اقتباس `\"` کے طور پر فرار ہوگیا ہے۔
    /// * بیک سلیش `\\` کے طور پر فرار ہوگیا ہے۔
    /// * 'پرنٹ ایبل ASCII' رینج `0x20` میں کوئی بھی کردار .. `0x7e` شامل نہیں ہے۔
    /// * دوسرے تمام کرداروں کو ہیکساڈیسمل یونیکوڈ فرار ہونے کی اطلاع دی گئی ہے۔[`escape_unicode`] دیکھیں۔
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// اگر UTF-8 میں انکوڈ ہوئے ہیں تو اس `char` کی ضرورت ہوگی بائٹس کی تعداد کو لوٹاتا ہے۔
    ///
    /// اس میں بائٹس کی تعداد ہمیشہ 1 اور 4 کے درمیان ہوتی ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` قسم ضمانت دیتا ہے کہ اس کے مندرجات UTF-8 ہیں ، اور لہذا ہم اس لمبائی کا موازنہ کرسکتے ہیں جس میں ہر کوڈ پوائنٹ کو `char` بمقابلہ `&str` میں دکھایا گیا ہو تو:
    ///
    ///
    /// ```
    /// // کردار کے طور پر
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // دونوں کو تین بائٹس کی نمائندگی کی جاسکتی ہے
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str کی حیثیت سے ، یہ دونوں UTF-8 میں انکوڈ ہیں
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ہم دیکھ سکتے ہیں کہ وہ کل چھ بائٹس لیتے ہیں ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... بالکل جیسے &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// اگر UTF-16 میں انکوڈ کیا گیا ہے تو اس `char` کی ضرورت والے 16 بٹ کوڈ یونٹوں کی تعداد لوٹاتا ہے۔
    ///
    ///
    /// اس تصور کی مزید وضاحت کے لئے دستاویزات کو [`len_utf8()`] دیکھیں۔
    /// یہ فنکشن آئینہ دار ہے ، لیکن UTF-8 کے بجائے X0X کیلئے۔
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// اس کردار کو UTF-8 کے بطور فراہم کردہ بائٹ بفر میں انکوڈ کرتا ہے ، اور پھر بفر کی سبسلیس کو لوٹاتا ہے جس میں انکوڈڈ کیریکٹر ہوتا ہے۔
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر بفر کافی بڑا نہیں ہے۔
    /// لمبائی کا ایک بفر کسی بھی `char` کو انکوڈ کرنے کے ل enough کافی بڑا ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// ان دونوں مثالوں میں ، 'ß' انکوڈ کرنے میں دو بائٹس لیتا ہے۔
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ایک چھوٹا سا بفر جو بہت چھوٹا ہے:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // محفوظ: `char` ایک سروگیٹ نہیں ہے ، لہذا یہ درست UTF-8 ہے۔
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// اس کردار کو UTF-16 کے بطور فراہم کردہ `u16` بفر میں انکوڈ کرتا ہے ، اور پھر ان کوڈ کریکٹر پر مشتمل بفر کی سبیلائز واپس کرتا ہے۔
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر بفر کافی بڑا نہیں ہے۔
    /// لمبائی 2 کا ایک بفر اتنا بڑا ہے کہ کسی بھی `char` کو انکوڈ کرسکے۔
    ///
    /// # Examples
    ///
    /// ان دونوں مثالوں میں ، '𝕊' انکوڈ کرنے میں دو takes u16` لیتا ہے۔
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// ایک چھوٹا سا بفر جو بہت چھوٹا ہے:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// اگر `char` میں `Alphabetic` پراپرٹی ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// `Alphabetic` [Unicode Standard] کے باب 4 (خصوصیت کی خصوصیات) میں بیان کیا گیا ہے اور [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] میں بیان کیا گیا ہے۔
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // محبت بہت سی چیزیں ہیں ، لیکن یہ حرف تہجی نہیں ہے
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// اگر `char` میں `Lowercase` پراپرٹی ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// `Lowercase` [Unicode Standard] کے باب 4 (خصوصیت کی خصوصیات) میں بیان کیا گیا ہے اور [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] میں بیان کیا گیا ہے۔
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // چینی کے مختلف اسکرپٹس اور رموز کا معاملہ نہیں ہے ، اور اسی طرح:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// اگر `char` میں `Uppercase` پراپرٹی ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// `Uppercase` [Unicode Standard] کے باب 4 (خصوصیت کی خصوصیات) میں بیان کیا گیا ہے اور [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] میں بیان کیا گیا ہے۔
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // چینی کے مختلف اسکرپٹس اور رموز کا معاملہ نہیں ہے ، اور اسی طرح:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// اگر `char` میں `White_Space` پراپرٹی ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] میں بیان کیا گیا ہے۔
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ایک توڑنے کی جگہ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// اگر `char` [`is_alphabetic()`] یا [`is_numeric()`] میں سے کسی ایک کو مطمئن کردے تو `true` واپس کرتا ہے۔
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// اگر اس `char` میں کنٹرول کوڈز کے لئے عمومی زمرہ موجود ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// کنٹرول کوڈ (`Cc` کے عام قسم کے ساتھ کوڈ پوائنٹس) کو [Unicode Standard] کے باب 4 (خصوصیت کی خصوصیات) میں بیان کیا گیا ہے اور [Unicode Character Database][ucd] [`UnicodeData.txt`] میں بیان کیا گیا ہے۔
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// // U + 009C ، STRING ٹرمینیٹر
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// اگر `char` میں `Grapheme_Extend` پراپرٹی ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] میں بیان کیا گیا ہے اور [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] میں بیان کیا گیا ہے۔
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// اگر اس X01 میں اعداد کے لئے عمومی زمرے میں سے ایک ہے تو `true` واپس کرتا ہے۔
    ///
    /// [Unicode Character Database][ucd] [`UnicodeData.txt`] میں اعداد کے لئے عام قسم (اعشاریہ ہندسے کے لئے `Nd` ، حرف نما عددی حروف کے لئے `Nl` ، اور دوسرے عددی حروف کے لئے `No`) کی وضاحت کی گئی ہے۔
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ایک ایٹریٹر لوٹاتا ہے جو اس `char` کی لوئر کیس میپنگ کو ایک یا زیادہ کے طور پر برآمد کرتا ہے
    /// `char`s.
    ///
    /// اگر اس `char` میں لوئر کیسز میپنگ نہیں ہے تو ، ایٹریٹر ایک ہی `char` حاصل کرتا ہے۔
    ///
    /// اگر اس `char` میں [Unicode Character Database][ucd] [`UnicodeData.txt`] کے ذریعہ دی گئی ایک سے ایک چھوٹی کیپ کی نقشہ سازی ہے تو ، دوبارہ کرنے والا `char` حاصل کرتا ہے۔
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// اگر اس `char` کو خصوصی غور و فکر کی ضرورت ہے (جیسے ایک سے زیادہ `چار)ز) توجیٹر [`SpecialCasing.txt`] کے ذریعہ دیئے گئے` چارٹ (حص sوں) کی پیداوار کرتا ہے۔
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// یہ آپریشن بغیر ٹیلرنگ کے غیر مشروط نقشہ سازی کرتا ہے۔یعنی ، تبدیلی سیاق و سباق اور زبان سے آزاد ہے۔
    ///
    /// [Unicode Standard] میں ، باب 4 (کریکٹر پراپرٹیز) عام طور پر کیس میپنگ پر تبادلہ خیال کرتا ہے اور باب 3 (Conformance) معاملے میں تبادلوں کے لئے پہلے سے طے شدہ الگورتھم پر تبادلہ خیال کرتا ہے۔
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // بعض اوقات نتیجہ ایک سے زیادہ کرداروں میں ہوتا ہے۔
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // ایسے حروف جن میں بڑے اور چھوٹے حصے دونوں نہیں ہوتے ہیں وہ خود میں بدل جاتے ہیں۔
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ایک ایٹریٹر لوٹاتا ہے جو اس `char` کے بڑے پیمانے پر میپنگ ایک یا ایک سے زیادہ کے طور پر برآمد کرتا ہے
    /// `char`s.
    ///
    /// اگر اس `char` میں بڑے پیمانے پر میپنگ نہیں ہے تو ، ایٹریٹر ایک ہی `char` حاصل کرتا ہے۔
    ///
    /// اگر اس `char` میں ایک سے ایک اپر کیس کی تعریفیں [Unicode Character Database][ucd] [`UnicodeData.txt`] کے ذریعہ دی گئیں تو ، دوبارہ کرنے والا `char` حاصل کرتا ہے۔
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// اگر اس `char` کو خصوصی غور و فکر کی ضرورت ہے (جیسے ایک سے زیادہ `چار)ز) توجیٹر [`SpecialCasing.txt`] کے ذریعہ دیئے گئے` چارٹ (حص sوں) کی پیداوار کرتا ہے۔
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// یہ آپریشن بغیر ٹیلرنگ کے غیر مشروط نقشہ سازی کرتا ہے۔یعنی ، تبدیلی سیاق و سباق اور زبان سے آزاد ہے۔
    ///
    /// [Unicode Standard] میں ، باب 4 (کریکٹر پراپرٹیز) عام طور پر کیس میپنگ پر تبادلہ خیال کرتا ہے اور باب 3 (Conformance) معاملے میں تبادلوں کے لئے پہلے سے طے شدہ الگورتھم پر تبادلہ خیال کرتا ہے۔
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ایک تکرار کنندہ کے بطور:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// براہ راست `println!` کا استعمال:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// دونوں برابر ہیں:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` استعمال کرنا:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // بعض اوقات نتیجہ ایک سے زیادہ کرداروں میں ہوتا ہے۔
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // ایسے حروف جن میں بڑے اور چھوٹے حصے دونوں نہیں ہوتے ہیں وہ خود میں بدل جاتے ہیں۔
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # جگہ پر نوٹ
    ///
    /// ترکی میں ، لاطینی میں 'i' کے برابر دو کی بجائے پانچ شکلیں ہیں:
    ///
    /// * 'Dotless': I/ı ، کبھی کبھی لکھا جاتا ہے ï
    /// * 'Dotted': ./i
    ///
    /// نوٹ کریں کہ لوئر کیسڈ ڈاٹڈ ایکس00 ایکس لاطینی کی طرح ہے۔لہذا:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// یہاں `upper_i` کی قدر متن کی زبان پر منحصر ہے: اگر ہم `en-US` میں ہیں تو ، یہ `"I"` ہونا چاہئے ، لیکن اگر ہم `tr_TR` میں ہیں تو ، یہ `"İ"` ہونا چاہئے۔
    /// `to_uppercase()` اس کو خاطر میں نہیں لیتے ، اور اسی طرح:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// زبانوں کے پاس ہے۔
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// جانچ پڑتال کریں کہ کیا قیمت ASCII کی حد میں ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// اس کی ASCII اپر کیس کے برابر قیمت کی ایک کاپی بناتی ہے۔
    ///
    /// 'a' سے 'z' تک ASCII حروف 'A' سے 'Z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// جگہ میں قدر کو بڑے کرنے کیلئے ، [`make_ascii_uppercase()`] استعمال کریں۔
    ///
    /// غیر ASCII حروف کے علاوہ ASCII حروف کو بھی بڑے کرنے کے لئے ، [`to_uppercase()`] استعمال کریں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// اس کی ASCII لوئر کیس کے برابر قیمت کی ایک کاپی بناتی ہے۔
    ///
    /// 'A' سے 'Z' تک ASCII حروف 'a' سے 'z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// جگہ کو کم کرنے کے ل، ، [`make_ascii_lowercase()`] استعمال کریں۔
    ///
    /// غیر ASCII حروف کے علاوہ ASCII حروف کو بھی کم کرنے کے لئے ، [`to_lowercase()`] استعمال کریں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// چیک کرتا ہے کہ دو اقدار ASCII کیس غیر حساس میچ ہیں۔
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` کے برابر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// اس قسم کو اس کے ASCII اپر کیس میں برابر جگہ میں تبدیل کرتا ہے۔
    ///
    /// 'a' سے 'z' تک ASCII حروف 'A' سے 'Z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// موجودہ میں ترمیم کیے بغیر نئی اپرکیسیز ویلیو واپس کرنے کے لئے ، [`to_ascii_uppercase()`] استعمال کریں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// اس قسم کو اس کے ASCII لوئر کیس میں جگہ جگہ تبدیل کرتا ہے۔
    ///
    /// 'A' سے 'Z' تک ASCII حروف 'a' سے 'z' تک نقش کیے گئے ہیں ، لیکن غیر ASCII حروف میں کوئی تبدیلی نہیں ہے۔
    ///
    /// موجودہ میں ترمیم کیے بغیر نئی نچلی قیمت کو واپس کرنے کے لئے ، [`to_ascii_lowercase()`] استعمال کریں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// جانچ پڑتال کریں کہ کیا قیمت ASCII حروف تہجی ہے
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ، یا
    /// - U + 0061 'a' ..=U + 007A 'z'۔
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// جانچ پڑتال کرتا ہے کہ کیا قیمت ASCII بڑے حرف کی ہے؟
    /// U + 0041 'A' ..=U + 005A 'Z'۔
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// جانچ پڑتال کرتا ہے کہ کیا قیمت ASCII چھوٹے حروف کی ہے:
    /// U + 0061 'a' ..=U + 007A 'z'۔
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// جانچ پڑتال کرتا ہے کہ کیا قیمت ASCII حروف نمبر ہے
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ، یا
    /// - U + 0061 'a' ..=U + 007A 'z' ، یا
    /// - U + 0030 '0' ..=U + 0039 '9'۔
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// جانچ پڑتال کریں کہ کیا قیمت ASCII اعشاریہ ہندسہ ہے:
    /// U + 0030 '0' ..=U + 0039 '9'۔
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// جانچ پڑتال کرتا ہے کہ کیا قیمت ASCII ہیکساڈیسیمل ہندسہ ہے:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' ، یا
    /// - U + 0041 'A' ..=U + 0046 'F' ، یا
    /// - U + 0061 'a' ..=U + 0066 'f'۔
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// جانچ پڑتال کرتا ہے کہ کیا قیمت ASCII اوقاف کی شکل ہے:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` ، یا
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` ، یا
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` ، یا
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// جانچ پڑتال کرتا ہے کہ کیا قیمت ASCII گرافک کردار ہے:
    /// U + 0021 '!' ..=U + 007E '~'۔
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// جانچ پڑتال کرتا ہے کہ کیا قیمت ASCII وائٹ اسپیس کریکٹر ہے:
    /// U + 0020 جگہ ، U + 0009 ہارجنٹل ٹیب ، U + 000A لائن فیڈ ، U + 000C فارم فیڈ ، یا U + 000D کیریج لوٹنا۔
    ///
    /// Rust واٹ ڈبلیو جی انفرا اسٹینڈرڈ کا [definition of ASCII whitespace][infra-aw] استعمال کرتا ہے۔وسیع استعمال میں متعدد دوسری تعریفیں ہیں۔
    /// مثال کے طور پر ، [the POSIX locale][pct] میں U + 000B ورٹیکل ٹیب کے ساتھ ساتھ مذکورہ بالا سارے کردار بھی شامل ہیں ، لیکن same ایک ہی وضاحت سے-[بوورن hell میں "field splitting" کے لئے پہلے سے طے شدہ قاعدہ][bfs]*صرف* اسپیس ، ہورجنٹل ٹیب ، اور وائٹ اسپیس کے طور پر لائن فیڈ
    ///
    ///
    /// اگر آپ کوئی ایسا پروگرام لکھ رہے ہیں جو موجودہ فائل فارمیٹ پر عملدرآمد کرے گا تو چیک کریں کہ اس فنکشن کو استعمال کرنے سے پہلے وائٹ اسپیس کی اس فارمیٹ کی تعریف کیا ہے۔
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// جانچ پڑتال کریں کہ کیا قیمت ASCII کنٹرول کردار ہے:
    /// U +0000 NUL ..=U + 001F UNIT SEPARATOR ، یا U + 007F خارج کریں۔
    /// نوٹ کریں کہ زیادہ تر ASCII وائٹ اسپیس حروف کنٹرول حروف ہیں ، لیکن جگہ ایسا نہیں ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ایک خام u32 قدر کو UTF-8 کے بطور فراہم کردہ بائٹ بفر میں انکوڈ کرتا ہے ، اور پھر بفر کی سبسائز کو لوٹاتا ہے جس میں انکوڈڈ کیریکٹر ہوتا ہے۔
///
///
/// `char::encode_utf8` کے برعکس ، یہ طریقہ سروگیٹ رینج میں کوڈپوائنٹس کو بھی سنبھالتا ہے۔
/// (سروگیٹ رینج میں `char` بنانا یو بی ہے۔) نتیجہ درست [generalized UTF-8] ہے لیکن درست UTF-8 نہیں ہے۔
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics اگر بفر کافی بڑا نہیں ہے۔
/// لمبائی کا ایک بفر کسی بھی `char` کو انکوڈ کرنے کے ل enough کافی بڑا ہوتا ہے۔
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// فراہم کردہ `u16` بفر میں UTF-16 کی حیثیت سے ایک خام u32 قدر کو انکوڈ کرتا ہے ، اور پھر ان کوڈ کریکٹر پر مشتمل بفر کی سبسس لوٹاتا ہے۔
///
///
/// `char::encode_utf16` کے برعکس ، یہ طریقہ سروگیٹ رینج میں کوڈپوائنٹس کو بھی سنبھالتا ہے۔
/// (سروگیٹ رینج میں ایک `char` بنانا یو بی ہے۔)
///
/// # Panics
///
/// Panics اگر بفر کافی بڑا نہیں ہے۔
/// لمبائی 2 کا ایک بفر اتنا بڑا ہے کہ کسی بھی `char` کو انکوڈ کرسکے۔
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // حفاظت: ہر بازو چیک کرتا ہے کہ لکھنے کے لئے کافی بٹس موجود ہیں یا نہیں
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // بی ایم پی سے گزرتا ہے
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // اضافی طیارے سروگیٹس میں ٹوٹ جاتے ہیں۔
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}