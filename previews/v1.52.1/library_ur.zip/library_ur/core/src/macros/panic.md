Panics موجودہ تھریڈ۔

اس سے پروگرام کو فوری طور پر ختم کرنے اور پروگرام کے فون کرنے والے کو آراء فراہم کرنے کی سہولت ملتی ہے۔
`panic!` جب پروگرام ناقابل باز حالت میں پہنچ جاتا ہے تو اسے استعمال کرنا چاہئے۔

یہ میکرو مثال کے طور پر کوڈ اور ٹیسٹوں میں حالات پر زور دینے کا بہترین طریقہ ہے۔
`panic!` [`Option`][ounwrap] اور [`Result`][runwrap] دونوں enums کے `unwrap` طریقہ کے ساتھ قریب سے بندھا ہوا ہے۔
دونوں نفاذات `panic!` پر کال کرتے ہیں جب وہ [`None`] یا [`Err`] مختلف حالتوں پر سیٹ ہوجاتے ہیں۔

جب `panic!()` استعمال کرتے ہو تو آپ اسٹرنگ پے لوڈ کی وضاحت کرسکتے ہیں ، جو [`format!`] نحو کا استعمال کرکے بنایا گیا ہے۔
panic کو کال کرنے والے Rust تھریڈ میں انجیکشن دیتے وقت اس پے لوڈ کا استعمال کیا جاتا ہے ، جس سے تھریڈ مکمل طور پر panic پر آجاتا ہے۔

پہلے سے طے شدہ `std` hook ، یعنی سلوک
کوڈ جو panic کی درخواست کے بعد براہ راست چلتا ہے ، `panic!()` کال کی file/line/column معلومات کے ساتھ `stderr` پر پیغام پے لوڈ پرنٹ کرنا ہے۔

آپ [`std::panic::set_hook()`] کا استعمال کرتے ہوئے panic hook کو اوور رائڈ کرسکتے ہیں۔
hook کے اندر ایک X0panic0Z تک `&dyn Any + Send` کی طرح رسائی حاصل کی جاسکتی ہے ، جس میں `&str` یا `String` پر مشتمل ہے۔
کسی دوسری قسم کی قدر کے ساتھ panic میں ، [`panic_any`] استعمال کیا جاسکتا ہے۔

[`Result`] اینوم اکثر `panic!` میکرو کے استعمال سے غلطیوں سے بازیافت کرنے کا ایک بہتر حل ہے۔
اس میکرو کو غلط اقدار ، جیسے بیرونی ذرائع سے ، آگے بڑھنے سے بچنے کے ل. استعمال کیا جانا چاہئے۔
غلطی سے نمٹنے کے بارے میں تفصیلی معلومات [book] میں مل جاتی ہے۔

تالیف کے دوران غلطیاں اٹھانے کیلئے میکرو [`compile_error!`] بھی دیکھیں۔

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# موجودہ عمل درآمد

اگر مرکزی دھاگہ panics یہ آپ کے سارے تھریڈز کو ختم کردے گا اور `101` کوڈ کے ذریعہ آپ کے پروگرام کا اختتام کرے گا۔

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





