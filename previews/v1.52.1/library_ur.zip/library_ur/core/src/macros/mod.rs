#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // کالر کے ایڈیشن کے لحاظ سے یا تو `$crate::panic::panic_2015` یا `$crate::panic::panic_2021` میں توسیع ہوتی ہے۔
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// زور دیتا ہے کہ دو تاثرات ایک دوسرے کے برابر ہیں ([`PartialEq`] کا استعمال کرتے ہوئے)۔
///
/// panic پر ، یہ میکرو اظہار کی اقدار کو اپنی ڈیبگ نمائندگیوں کے ساتھ پرنٹ کرے گا۔
///
///
/// [`assert!`] کی طرح ، اس میکرو کی بھی دوسری شکل ہے ، جہاں ایک کسٹم panic پیغام فراہم کیا جاسکتا ہے۔
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // نیچے دیئے ہوئے بورجز جان بوجھ کر ہیں۔
                    // ان کے بغیر ، قرضوں کے لئے اسٹیک سلاٹ کو اقدار کے موازنہ کرنے سے پہلے ہی شروع کردیا جاتا ہے ، جس کی وجہ سے قابل دید سست روی پیدا ہوتی ہے۔
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // نیچے دیئے ہوئے بورجز جان بوجھ کر ہیں۔
                    // ان کے بغیر ، قرضوں کے لئے اسٹیک سلاٹ کو اقدار کے موازنہ کرنے سے پہلے ہی شروع کردیا جاتا ہے ، جس کی وجہ سے قابل دید سست روی پیدا ہوتی ہے۔
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// زور دیتا ہے کہ دو تاثرات ایک دوسرے کے برابر نہیں ہیں ([`PartialEq`] کا استعمال کرتے ہوئے)۔
///
/// panic پر ، یہ میکرو اظہار کی اقدار کو اپنی ڈیبگ نمائندگیوں کے ساتھ پرنٹ کرے گا۔
///
///
/// [`assert!`] کی طرح ، اس میکرو کی بھی دوسری شکل ہے ، جہاں ایک کسٹم panic پیغام فراہم کیا جاسکتا ہے۔
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // نیچے دیئے ہوئے بورجز جان بوجھ کر ہیں۔
                    // ان کے بغیر ، قرضوں کے لئے اسٹیک سلاٹ کو اقدار کے موازنہ کرنے سے پہلے ہی شروع کردیا جاتا ہے ، جس کی وجہ سے قابل دید سست روی پیدا ہوتی ہے۔
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // نیچے دیئے ہوئے بورجز جان بوجھ کر ہیں۔
                    // ان کے بغیر ، قرضوں کے لئے اسٹیک سلاٹ کو اقدار کے موازنہ کرنے سے پہلے ہی شروع کردیا جاتا ہے ، جس کی وجہ سے قابل دید سست روی پیدا ہوتی ہے۔
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// زور دیتا ہے کہ رن ٹائم کے وقت بولین کا اظہار `true` ہے۔
///
/// یہ [`panic!`] میکرو کو طلب کرے گا اگر فراہم کردہ اظہار کا اندازہ رن ٹائم کے وقت `true` پر نہ کیا جاسکے۔
///
/// [`assert!`] کی طرح ، اس میکرو کا دوسرا ورژن بھی ہے ، جہاں ایک کسٹم panic پیغام فراہم کیا جاسکتا ہے۔
///
/// # Uses
///
/// [`assert!`] کے برعکس ، `debug_assert!` بیانات صرف نان مرضی کے مطابق بلڈز میں بطور ڈیفالٹ فعال ہیں۔
/// ایک مرضی کے مطابق تعمیر `debug_assert!` بیانات پر عمل نہیں کرے گا جب تک کہ `-C debug-assertions` مرتب کرنے والے کو منتقل نہ کیا جائے۔
/// اس سے `debug_assert!` ان چیکوں کے لئے کارآمد ثابت ہوتا ہے جو ریلیز کی تعمیر میں موجود ہونا بہت مہنگا ہوتا ہے لیکن ترقی کے دوران مددگار ثابت ہوسکتا ہے۔
/// `debug_assert!` کو بڑھانے کا نتیجہ ہمیشہ ٹائپ چیک ہوتا ہے۔
///
/// غیر چیک شدہ دعوی سے متضاد حالت میں ایک پروگرام چلتا رہتا ہے ، جس کے غیر متوقع نتائج ہوسکتے ہیں لیکن جب تک یہ صرف محفوظ کوڈ میں ہوتا ہے اس وقت تک ناکارہ نہیں ہوتا ہے۔
///
/// تاہم ، دعووں کی کارکردگی کی قیمت عام طور پر قابل پیمائش نہیں ہے۔
/// [`assert!`] کی جگہ `debug_assert!` کی جگہ پوری پروفائلنگ کے بعد صرف حوصلہ افزائی کی جاتی ہے ، اور زیادہ اہم بات یہ ہے کہ صرف محفوظ کوڈ میں!
///
/// # Examples
///
/// ```
/// // ان دعوؤں کے لئے panic پیغام دیئے گئے اظہار کی مختلف قیمت ہے۔
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ایک بہت ہی آسان تقریب
/// debug_assert!(some_expensive_computation());
///
/// // اپنی مرضی کے پیغام کے ساتھ دعوی کریں
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// زور دیتا ہے کہ دو تاثرات ایک دوسرے کے برابر ہیں۔
///
/// panic پر ، یہ میکرو اظہار کی اقدار کو اپنی ڈیبگ نمائندگیوں کے ساتھ پرنٹ کرے گا۔
///
/// [`assert_eq!`] کے برعکس ، `debug_assert_eq!` بیانات صرف نان مرضی کے مطابق بلڈز میں بطور ڈیفالٹ فعال ہیں۔
/// ایک مرضی کے مطابق تعمیر `debug_assert_eq!` بیانات پر عمل نہیں کرے گا جب تک کہ `-C debug-assertions` مرتب کرنے والے کو منتقل نہ کیا جائے۔
/// اس سے `debug_assert_eq!` ان چیکوں کے لئے کارآمد ثابت ہوتا ہے جو ریلیز کی تعمیر میں موجود ہونا بہت مہنگا ہوتا ہے لیکن ترقی کے دوران مددگار ثابت ہوسکتا ہے۔
///
/// `debug_assert_eq!` کو بڑھانے کا نتیجہ ہمیشہ ٹائپ چیک ہوتا ہے۔
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// زور دیتا ہے کہ دو تاثرات ایک دوسرے کے برابر نہیں ہیں۔
///
/// panic پر ، یہ میکرو اظہار کی اقدار کو اپنی ڈیبگ نمائندگیوں کے ساتھ پرنٹ کرے گا۔
///
/// [`assert_ne!`] کے برعکس ، `debug_assert_ne!` بیانات صرف نان مرضی کے مطابق بلڈز میں بطور ڈیفالٹ فعال ہیں۔
/// ایک مرضی کے مطابق تعمیر `debug_assert_ne!` بیانات پر عمل نہیں کرے گا جب تک کہ `-C debug-assertions` مرتب کرنے والے کو منتقل نہ کیا جائے۔
/// اس سے `debug_assert_ne!` ان چیکوں کے لئے کارآمد ثابت ہوتا ہے جو ریلیز کی تعمیر میں موجود ہونا بہت مہنگا ہوتا ہے لیکن ترقی کے دوران مددگار ثابت ہوسکتا ہے۔
///
/// `debug_assert_ne!` کو بڑھانے کا نتیجہ ہمیشہ ٹائپ چیک ہوتا ہے۔
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// آیا لوٹ دیا گیا اظہار دیا ہوا نمونوں میں سے کسی سے مماثل ہے۔
///
/// ایک `match` اظہار کی طرح ، پیٹرن کو اختیاری طور پر `if` اور گارڈ کا اظہار کیا جاسکتا ہے جس میں اس نمونہ کے پابند ناموں تک رسائی حاصل ہے۔
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// کسی نتیجے کو غیر لپیٹتا ہے یا اس کی غلطی کو پھیلاتا ہے۔
///
/// `?` آپریٹر کو `try!` کو تبدیل کرنے کے لئے شامل کیا گیا تھا اور اس کے بجائے استعمال کیا جانا چاہئے۔
/// مزید برآں ، `try` Rust 2018 میں ایک مخصوص لفظ ہے ، لہذا اگر آپ اسے استعمال کرنا چاہیں تو ، آپ کو [raw-identifier syntax][ris] استعمال کرنے کی ضرورت ہوگی۔ `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` دیئے گئے [`Result`] سے مماثل ہے۔`Ok` متغیر کی صورت میں ، اظہار کی لپیٹی ہوئی قیمت کی قدر ہوتی ہے۔
///
/// `Err` مختلف حالت کے معاملے میں ، یہ اندرونی خامی کو بازیافت کرتا ہے۔`try!` پھر `From` استعمال کرکے تبادلوں کا کام کرتا ہے۔
/// اس سے خصوصی خرابیوں اور زیادہ عمومی غلطیوں کے مابین خودکار تبادلوں کی سہولت ملتی ہے۔
/// اس کے نتیجے میں غلطی فوری طور پر واپس کردی جاتی ہے۔
///
/// جلد واپسی کی وجہ سے ، `try!` صرف ان افعال میں استعمال کیا جاسکتا ہے جو [`Result`] کو واپس کرتے ہیں۔
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // فوری واپسی کی نقائص کا ترجیحی طریقہ
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // فوری واپسی کی نقائص کا پچھلا طریقہ
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // اس کے برابر ہے:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// فارمیٹڈ ڈیٹا بفر میں لکھتا ہے۔
///
/// یہ میکرو ایک 'writer' ، شکل کی تار ، اور دلائل کی فہرست کو قبول کرتا ہے۔
/// دلائل کو مخصوص فارمیٹ کے تار کے مطابق فارمیٹ کیا جائے گا اور اس کا نتیجہ مصنف کے پاس جائے گا۔
/// `write_fmt` طریقہ کار کے ساتھ مصنف کی کوئی قیمت ہوسکتی ہے۔عام طور پر یہ [`fmt::Write`] یا [`io::Write`] trait میں سے کسی ایک کے نفاذ سے آتا ہے۔
/// میکرو `write_fmt` طریقہ جو بھی لوٹاتا ہے اسے واپس کرتا ہے۔عام طور پر ایک [`io::Result`]، یا ایک [`io::Result`]۔
///
/// فارمیٹ سٹرنگ ترکیب سے متعلق مزید معلومات کے لئے [`std::fmt`] دیکھیں۔
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ایک ماڈیول ، `std::fmt::Write` اور `std::io::Write` دونوں کو درآمد کرسکتا ہے اور `write!` کو بھی لاگو کرنے والی اشیاء پر کال کرسکتا ہے ، کیونکہ اشیاء عام طور پر دونوں پر عمل درآمد نہیں کرتے ہیں۔
///
/// تاہم ، ماڈیول کو لازمی طور پر traits کوالیفائیڈ درآمد کرنا ہوگا تاکہ ان کے نام متصادم نہ ہوں:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt استعمال کرتا ہے
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt استعمال کرتا ہے
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: اس میکرو کو `no_std` سیٹ اپ میں بھی استعمال کیا جاسکتا ہے۔
/// `no_std` سیٹ اپ میں آپ اجزاء کے نفاذ کی تفصیلات کے ذمہ دار ہیں۔
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// بفر میں فارمیٹ ڈیٹا لکھیں ، جس میں ایک نئی لائن شامل کی گئی ہے۔
///
/// تمام پلیٹ فارمز پر ، نئی لائن تنہا لائن فیڈ کیکٹر (`\n`/`U+000A`) ہے (کوئی اضافی کیریج واپس نہیں (`\r`/`U+000D`)۔
///
/// مزید معلومات کے لئے ، دیکھیں [`write!`]۔فارمیٹ سٹرنگ ترکیب سے متعلق معلومات کے ل X ، [`std::fmt`] دیکھیں۔
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ایک ماڈیول ، `std::fmt::Write` اور `std::io::Write` دونوں کو درآمد کرسکتا ہے اور `write!` کو بھی لاگو کرنے والی اشیاء پر کال کرسکتا ہے ، کیونکہ اشیاء عام طور پر دونوں پر عمل درآمد نہیں کرتے ہیں۔
/// تاہم ، ماڈیول کو لازمی طور پر traits کوالیفائیڈ درآمد کرنا ہوگا تاکہ ان کے نام متصادم نہ ہوں:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt استعمال کرتا ہے
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt استعمال کرتا ہے
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// ناقابل رسائی کوڈ کی نشاندہی کرتا ہے۔
///
/// یہ کسی بھی وقت مفید ہے کہ مرتب کرنے والا یہ طے نہیں کرسکتا ہے کہ کچھ کوڈ ناقابل رسائی ہے۔مثال کے طور پر:
///
/// * محافظ کی شرائط کے ساتھ ہتھیاروں کا مقابلہ کریں۔
/// * لوپس جو متحرک طور پر ختم ہوجاتے ہیں۔
/// * Iteters جو متحرک طور پر ختم.
///
/// اگر یہ عزم کہ کوڈ تک ناقابل رسائی ہے تو غلط ثابت ہوتا ہے ، پروگرام فوری طور پر ایک [`panic!`] کے ساتھ ختم ہوجاتا ہے۔
///
/// اس میکرو کا غیر محفوظ ہم منصب [`unreachable_unchecked`] فنکشن ہے ، جو کوڈ تک پہنچنے پر غیر وضاحتی رویے کا سبب بنے گا۔
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// یہ ہمیشہ [`panic!`] رہے گا۔
///
/// # Examples
///
/// میچ بازو:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // اگر تبصرہ کیا گیا تو کمپائل کی غلطی
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 کے غریب ترین نفاذ میں سے ایک
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" کے پیغام سے گھبراتے ہوئے غیر نافذ شدہ کوڈ کی نشاندہی کرتا ہے۔
///
/// اس سے آپ کے کوڈ کو ٹائپ چیک کرنے کی اجازت ملتی ہے ، جو مفید ہے اگر آپ trait کو پروٹو ٹائپ کر رہے ہو یا اس پر عمل درآمد کر رہے ہو جس کے لئے متعدد طریقوں کی ضرورت ہو جس کا آپ سب کو استعمال کرنے کا ارادہ نہیں رکھتے ہیں۔
///
/// `unimplemented!` اور [`todo!`] کے درمیان فرق یہ ہے کہ جبکہ `todo!` بعد میں فعالیت پر عمل درآمد کرنے کا ارادہ پیش کرتا ہے اور پیغام "not yet implemented" ہے ، `unimplemented!` اس طرح کے دعوے نہیں کرتا ہے۔
/// اس کا میسج "not implemented" ہے۔
/// نیز کچھ IDEs `todo! mark کو نشان زد کریں گے۔
///
/// # Panics
///
/// یہ ہمیشہ [`panic!`] رہے گا کیونکہ `unimplemented!` صرف ایک مختصر ، `panic!` کے لئے ایک مقررہ ، مخصوص پیغام کے ساتھ ہے۔
///
/// `panic!` کی طرح ، اس میکرو کی بھی اپنی مرضی کے مطابق اقدار کی نمائش کے لئے دوسری شکل ہے۔
///
/// # Examples
///
/// کہتے ہیں کہ ہمارے پاس trait `Foo` ہے:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// ہم 'MyStruct' کے لئے `Foo` کو لاگو کرنا چاہتے ہیں ، لیکن کسی وجہ سے صرف `bar()` فنکشن کو عملی جامہ پہنانا سمجھ میں آتا ہے۔
/// `baz()` اور `qux()` کو ابھی بھی ہمارے `Foo` کے نفاذ میں بیان کرنے کی ضرورت ہوگی ، لیکن ہم اپنے کوڈ کو مرتب کرنے کے لئے `unimplemented!` کو ان کی تعریفوں میں استعمال کرسکتے ہیں۔
///
/// ہم ابھی بھی چاہتے ہیں کہ اگر غیر منحصر طریقوں تک پہونچ جاتا ہے تو ہمارا پروگرام چلنا بند ہو۔
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` کو ایک `MyStruct` کرنے میں کوئی معنی نہیں رکھتا ہے ، لہذا ہمارے یہاں کوئی منطق نہیں ہے۔
/////
///         // یہ "thread 'main' panicked at 'not implemented'" دکھائے گا۔
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ہمارے یہاں کچھ منطق ہے ، ہم ایک عمل بغیر عمل میں شامل کرسکتے ہیں!ہماری بھول کو ظاہر کرنے کے لئے.
///         // یہ ظاہر ہوگا: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// نامکمل کوڈ کی نشاندہی کرتا ہے۔
///
/// اگر آپ پروٹو ٹائپنگ کررہے ہیں اور صرف آپ کوڈ ٹائپیک چیک کرنے کے خواہاں ہیں تو یہ کارآمد ثابت ہوسکتا ہے۔
///
/// [`unimplemented!`] اور `todo!` کے درمیان فرق یہ ہے کہ جبکہ `todo!` بعد میں فعالیت پر عمل درآمد کرنے کا ارادہ پیش کرتا ہے اور پیغام "not yet implemented" ہے ، `unimplemented!` اس طرح کے دعوے نہیں کرتا ہے۔
/// اس کا میسج "not implemented" ہے۔
/// نیز کچھ IDEs `todo! mark کو نشان زد کریں گے۔
///
/// # Panics
///
/// یہ ہمیشہ [`panic!`] رہے گا۔
///
/// # Examples
///
/// یہاں کچھ ترقی میں کوڈ کی ایک مثال ہے۔ہمارے پاس trait `Foo` ہے:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// ہم اپنی ایک قسم پر `Foo` لاگو کرنا چاہتے ہیں ، لیکن ہم صرف `bar()` پر بھی کام کرنا چاہتے ہیں۔ہمارے کوڈ کو مرتب کرنے کے ل we ، ہمیں `baz()` لاگو کرنے کی ضرورت ہے ، لہذا ہم `todo!` استعمال کرسکیں:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // عمل یہاں جاتا ہے
///     }
///
///     fn baz(&self) {
///         // آئیے ابھی کے لئے baz() کو لاگو کرنے کے بارے میں فکر نہ کریں
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ہم baz() بھی استعمال نہیں کر رہے ہیں ، لہذا یہ ٹھیک ہے۔
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// بلٹ میں میکرو کی تعریفیں۔
///
/// میکرو کی زیادہ تر خصوصیات (استحکام ، مرئیت وغیرہ) یہاں کے ماخذ کوڈ سے لی گئی ہیں ، توسیع کے افعال کو چھوڑ کر میکرو آدانوں کو آؤٹ پٹس میں تبدیل کردیتا ہے ، ان افعال کو مرتب کرنے والے کے ذریعہ فراہم کیا جاتا ہے۔
///
///
pub(crate) mod builtin {

    /// پیش آنے والے خامی پیغام کے ساتھ تالیف کو ناکام ہونے کا سبب بنتا ہے۔
    ///
    /// اس میکرو کو استعمال کیا جانا چاہئے جب ایک crate غلط حالات کے لئے غلطی کے بہتر پیغامات فراہم کرنے کیلئے ایک مشروط تالیف حکمت عملی استعمال کرتا ہے۔
    ///
    /// یہ [`panic!`] کی مرتب کی سطح کی شکل ہے ، لیکن *تالیف* کے دوران *رن ٹائم* کے بجائے خامی خارج کرتی ہے۔
    ///
    /// # Examples
    ///
    /// اس طرح کی دو مثالیں میکروز اور `#[cfg]` ماحولیات ہیں۔
    ///
    /// اگر میکرو نے غلط اقدار کو منظور کیا ہے تو بہتر مرتب غلطی خارج کریں۔
    /// حتمی زیڈبرینچ0 زیڈ کے بغیر ، مرتب کرنے والا پھر بھی غلطی خارج کردے گا ، لیکن غلطی کے پیغام میں دو جائز اقدار کا ذکر نہیں ہوگا۔
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// اگر متعدد خصوصیات میں سے ایک دستیاب نہ ہو تو کمپائلر میں خرابی خارج کریں۔
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// دوسرے سٹرنگ-فارمیٹنگ میکروز کے لئے پیرامیٹرز تیار کرتا ہے۔
    ///
    /// یہ میکرو ہر اضافی دلیل کے لئے `{}` پر مشتمل فارمیٹنگ سٹرنگ لٹریل لے کر کام کرتا ہے۔
    /// `format_args!` اضافی پیرامیٹرز تیار کرتا ہے تاکہ یہ یقینی بنایا جاسکے کہ آؤٹ پٹ کو اسٹرنگ کی طرح سمجھا جاسکتا ہے اور دلائل کو ایک ہی قسم میں کیننائزائز کیا جاتا ہے۔
    /// [`Display`] trait پر عمل درآمد کرنے والی کوئی بھی قیمت `format_args!` کو منتقل کی جاسکتی ہے ، جیسا کہ کسی بھی [`Debug`] نفاذ کو فارمیٹنگ سٹرنگ میں `{:?}` میں منتقل کیا جاسکتا ہے۔
    ///
    ///
    /// یہ میکرو [`fmt::Arguments`] قسم کی قدر پیدا کرتا ہے۔یہ قدر [`std::fmt`] کے اندر میکرو کو مفید ری ڈائریکشن انجام دینے کے لئے منتقل کی جاسکتی ہے۔
    /// دوسرے تمام فارمیٹنگ میکروز ([`فارمیٹ!`] ، [`write!`] ، [`println!`] ، وغیرہ) اس کے ذریعے ہی پرکسی کیے جاتے ہیں۔
    /// `format_args!`, اس سے ماخوذ میکروز کے برخلاف ڈھیر مختص کرنے سے گریز کرتا ہے۔
    ///
    /// آپ [`fmt::Arguments`] قدر کا استعمال کرسکتے ہیں جو `format_args!` `Debug` اور `Display` سیاق و سباق میں واپس آرہا ہے۔
    /// مثال سے یہ بھی ظاہر ہوتا ہے کہ `Debug` اور `Display` فارمیٹ کو ایک ہی چیز کے لئے: `format_args!` میں انٹرپولٹیٹ فارمیٹ کی تار۔
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// مزید معلومات کے لئے ، دستاویزات کو [`std::fmt`] میں دیکھیں۔
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` کی طرح ہی ، لیکن آخر میں ایک نئی لائن شامل کرتا ہے۔
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// تالیف کے وقت ماحول کے متغیر کا معائنہ کرتا ہے۔
    ///
    /// یہ میکرو مرتب وقت پر نامزد ماحول کے متغیر کی قدر میں توسیع کرے گا ، اور `&'static str` کی قسم کا اظہار کرے گا۔
    ///
    ///
    /// اگر ماحول کے متغیر کی وضاحت نہیں کی گئی ہے ، تو تالیف کی غلطی خارج ہوگی۔
    /// تالیف غلطی کو خارج نہ کرنے کے ل the ، اس کے بجائے [`option_env!`] میکرو کا استعمال کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// آپ اسٹرنگ کو دوسرے پیرامیٹر کی طرح پاس کرکے غلطی پیغام کو حسب ضرورت بنا سکتے ہیں۔
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// اگر `documentation` ماحول متغیر کی وضاحت نہیں کی گئی ہے تو ، آپ کو درج ذیل خامی ہوگی۔
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// اختیاری طور پر تالیف کے وقت ماحول کے متغیر کا معائنہ کریں۔
    ///
    /// اگر نامزد کردہ ماحول متغیر مرتب وقت پر موجود ہے تو ، یہ `Option<&'static str>` قسم کے اظہار میں پھیل جائے گا جس کی قدر ماحولیاتی متغیر کی قدر کا `Some` ہے۔
    /// اگر ماحول کا متغیر موجود نہیں ہے تو ، پھر یہ `None` تک پھیل جائے گا۔
    /// اس قسم کی مزید معلومات کے ل X [`Option<T>`][Option] دیکھیں۔
    ///
    /// اس میکرو کا استعمال کرتے وقت کسی مرتب وقت کی غلطی کبھی خارج نہیں ہوتی اس سے قطع نظر کہ ماحولیاتی متغیر موجود ہے یا نہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// شناخت کرنے والوں کو ایک شناخت کنندہ میں مقابلہ کرتا ہے۔
    ///
    /// یہ میکرو متعدد کوما سے جدا شناختوں کی حیثیت رکھتا ہے ، اور ان سب کو ایک ساتھ بناتا ہے ، جس سے ایک اظہار ملتا ہے جو ایک نیا شناخت کنندہ ہے۔
    /// نوٹ کریں کہ حفظان صحت اس طرح کی ہے کہ یہ میکرو مقامی متغیرات کو گرفت میں نہیں لے سکتا ہے۔
    /// نیز ، ایک عام اصول کے طور پر ، میکروز کو صرف آئٹم ، بیان یا اظہار کی پوزیشن میں ہی اجازت دی جاتی ہے۔
    /// اس کا مطلب یہ ہے کہ جب آپ اس میکرو کو موجودہ متغیرات ، افعال یا ماڈیولز وغیرہ کا حوالہ دینے کے ل use استعمال کرسکتے ہیں تو ، آپ اس کے ساتھ کوئی نیا بیان نہیں کرسکتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn کونکات_ٹینس! (نیا ، تفریح ، نام) { }//اس طرح سے قابل استعمال نہیں!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// لغتن کو مستحکم سٹرنگ سلائس میں مقابلہ کرتا ہے۔
    ///
    /// یہ میکرو کسی بھی تعداد میں کوما سے جدا لغزش لیتا ہے ، جس سے `&'static str` قسم کا اظہار ملتا ہے جو بائیں طرف سے دائیں طرف جمع ہونے والے تمام لغوی حص representsوں کی نمائندگی کرتا ہے۔
    ///
    ///
    /// کنٹینٹیٹ ہونے کے لئے انٹیجر اور فلوٹنگ پوائنٹ لٹریلز کو تار میں ترتیب دیا گیا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// اس لائن نمبر میں پھیل جاتی ہے جس پر اس کو طلب کیا گیا تھا۔
    ///
    /// [`column!`] اور [`file!`] کے ساتھ ، یہ میکروز وسیل کے اندر موجود محل وقوع کے بارے میں ڈویلپرز کو ڈیبگنگ معلومات فراہم کرتے ہیں۔
    ///
    /// توسیعی اظہار میں `u32` کی قسم ہے اور یہ 1 پر مبنی ہے ، لہذا ہر فائل میں پہلی لائن 1 ، دوسری سے 2 ، وغیرہ کی جانچ کرتی ہے۔
    /// یہ عام مرتب کرنے والوں یا مشہور ایڈیٹرز کے غلط پیغامات کے مطابق ہے۔
    /// واپس شدہ لائن *ضروری نہیں*`line!` ہی کی درخواست کی لکیر ہے ، بلکہ `line!` میکرو کی منتقلی تک پہلا میکرو کی درخواست ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// کالم نمبر تک پھیل جاتا ہے جس پر اسے طلب کیا گیا تھا۔
    ///
    /// [`line!`] اور [`file!`] کے ساتھ ، یہ میکروز وسیل کے اندر موجود محل وقوع کے بارے میں ڈویلپرز کو ڈیبگنگ معلومات فراہم کرتے ہیں۔
    ///
    /// توسیعی اظہار میں `u32` کی قسم ہے اور یہ 1 پر مبنی ہے ، لہذا ہر لائن میں پہلا کالم 1 ، دوسرے سے 2 ، وغیرہ کی تشخیص کرتا ہے۔
    /// یہ عام مرتب کرنے والوں یا مشہور ایڈیٹرز کے غلط پیغامات کے مطابق ہے۔
    /// واپس کردہ کالم * ضروری نہیں ہے کہ خود ہی `column!` کی درخواست کی لائن ہو ، بلکہ `column!` میکرو کی منتقلی تک پہلا میکرو کی درخواست ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// اس فائل کے نام تک پھیل جاتی ہے جس میں اسے طلب کیا گیا تھا۔
    ///
    /// [`line!`] اور [`column!`] کے ساتھ ، یہ میکروز وسیل کے اندر موجود محل وقوع کے بارے میں ڈویلپرز کو ڈیبگنگ معلومات فراہم کرتے ہیں۔
    ///
    /// توسیعی اظہار میں `&'static str` کی قسم ہے ، اور واپس کی گئی فائل خود `file!` میکرو کی درخواست نہیں ہے ، بلکہ `file!` میکرو کی منتقلی تک پہلا میکرو کی درخواست ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// اس کے دلائل کو مضبوط بناتا ہے۔
    ///
    /// یہ میکرو `&'static str` کی قسم کا اظہار کرے گا جو میکرو کو منتقل کردہ تمام tokens کی تار ہے۔
    /// خود میکرو کی درخواست کے نحو پر کوئی پابندی نہیں ہے۔
    ///
    /// نوٹ کریں کہ tokens ان پٹ کے توسیع شدہ نتائج future میں تبدیل ہوسکتے ہیں۔اگر آپ آؤٹ پٹ پر بھروسہ کرتے ہیں تو آپ کو محتاط رہنا چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// اسٹرنگ کے بطور UTF-8 انکوڈ فائل پر مشتمل ہے۔
    ///
    /// موجودہ فائل کے مطابق فائل واقع ہے (اسی طرح ماڈیول کیسے پائے جاتے ہیں)۔
    /// فراہم کردہ راہ کی تالیف کے وقت پلیٹ فارم سے مخصوص انداز میں تشریح کی جاتی ہے۔
    /// لہذا ، مثال کے طور پر ، Windows پاتھ کے ساتھ ایک بیکٹیلاسشس `\` پر مشتمل ایک درخواست Unix پر صحیح طور پر مرتب نہیں ہوگی۔
    ///
    ///
    /// اس میکرو سے `&'static str` قسم کا اظہار ملے گا جو فائل کے مندرجات ہیں۔
    ///
    /// # Examples
    ///
    /// فرض کریں کہ ایک ہی ڈائریکٹری میں مندرجہ ذیل مواد کے ساتھ دو فائلیں ہیں۔
    ///
    /// فائل 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// فائل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' مرتب کرنا اور اس کے نتیجے میں بائنری چلانا "adiós" پرنٹ کرے گا۔
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// بائٹ سرنی کے حوالے سے ایک فائل شامل ہے۔
    ///
    /// موجودہ فائل کے مطابق فائل واقع ہے (اسی طرح ماڈیول کیسے پائے جاتے ہیں)۔
    /// فراہم کردہ راہ کی تالیف کے وقت پلیٹ فارم سے مخصوص انداز میں تشریح کی جاتی ہے۔
    /// لہذا ، مثال کے طور پر ، Windows پاتھ کے ساتھ ایک بیکٹیلاسشس `\` پر مشتمل ایک درخواست Unix پر صحیح طور پر مرتب نہیں ہوگی۔
    ///
    ///
    /// اس میکرو سے `&'static [u8; N]` قسم کا اظہار ملے گا جو فائل کے مندرجات ہیں۔
    ///
    /// # Examples
    ///
    /// فرض کریں کہ ایک ہی ڈائریکٹری میں مندرجہ ذیل مواد کے ساتھ دو فائلیں ہیں۔
    ///
    /// فائل 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// فائل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' مرتب کرنا اور اس کے نتیجے میں بائنری چلانا "adiós" پرنٹ کرے گا۔
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// اس تار میں پھیلا ہوا ہے جو موجودہ ماڈیول راہ کی نمائندگی کرتا ہے۔
    ///
    /// موجودہ ماڈیول راستے کے بارے میں crate root تک واپس جانے والے ماڈیولز کے درجہ بندی کے بارے میں سوچا جاسکتا ہے۔
    /// واپس آنے والے راستے کا پہلا جزو اس وقت مرتب کیا جارہا crate کا نام ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// مرتب وقت پر ترتیباتی جھنڈوں کے بولین امتزاجات کا اندازہ کرتا ہے۔
    ///
    /// `#[cfg]` اوصاف کے علاوہ ، یہ میکرو ترتیباتی جھنڈوں کی بولین اظہار کی تشخیص کی اجازت دینے کے لئے مہیا کیا گیا ہے۔
    /// اس کی وجہ سے اکثر کم نقل کوڈ ہوتا ہے۔
    ///
    /// اس میکرو کو دیا ہوا نحو ایک ہی ترکیب ہے جو [`cfg`] وصف ہے۔
    ///
    /// `cfg!`, `#[cfg]` کے برعکس ، کوئی کوڈ نہیں ہٹاتا ہے اور صرف صحیح یا غلط کی تشخیص کرتا ہے۔
    /// مثال کے طور پر ،if/else X کے تمام بلاکس کو درست ہونے کی ضرورت ہے جب `cfg!` حالت کے لئے استعمال کیا جاتا ہے ، قطع نظر اس سے قطع نظر کہ `cfg!` کیا جائزہ لے رہا ہے۔
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// سیاق و سباق کے مطابق کسی فائل کو اظہار یا کسی شے کے طور پر تجزیہ کرتا ہے۔
    ///
    /// موجودہ فائل کے مطابق فائل واقع ہے (اسی طرح ماڈیول کیسے پائے جاتے ہیں)۔فراہم کردہ راہ کی تالیف کے وقت پلیٹ فارم سے مخصوص انداز میں تشریح کی جاتی ہے۔
    /// لہذا ، مثال کے طور پر ، Windows پاتھ کے ساتھ ایک بیکٹیلاسشس `\` پر مشتمل ایک درخواست Unix پر صحیح طور پر مرتب نہیں ہوگی۔
    ///
    /// اس میکرو کو استعمال کرنا اکثر برا خیال ہوتا ہے ، کیونکہ اگر فائل کو اظہار کے طور پر تجزیہ کیا گیا ہے تو ، اسے غیر ارادی طور پر آس پاس کے کوڈ میں رکھا جائے گا۔
    /// اس کے نتیجے میں متغیرات یا افعال فائل کی توقع سے مختلف ہوسکتے ہیں اگر موجودہ جگہ میں متغیر یا افعال ایک ہی نام ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// فرض کریں کہ ایک ہی ڈائریکٹری میں مندرجہ ذیل مواد کے ساتھ دو فائلیں ہیں۔
    ///
    /// فائل 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// فائل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' مرتب کرنا اور اس کے نتیجے میں بائنری چلانا "🙈🙊🙉🙈🙊🙉" پرنٹ کرے گا۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// زور دیتا ہے کہ رن ٹائم کے وقت بولین کا اظہار `true` ہے۔
    ///
    /// یہ [`panic!`] میکرو کو طلب کرے گا اگر فراہم کردہ اظہار کا اندازہ رن ٹائم کے وقت `true` پر نہ کیا جاسکے۔
    ///
    /// # Uses
    ///
    /// دعووں کو ہمیشہ ڈیبگ اور ریلیز دونوں طرح کی تعمیر میں جانچا جاتا ہے ، اور اسے غیر فعال نہیں کیا جاسکتا ہے۔
    /// [`debug_assert!`] کو ان دعوؤں کے لئے دیکھیں جو پہلے سے طے شدہ طور پر رہائی کے قابل نہیں ہیں۔
    ///
    /// غیر محفوظ کوڈ `assert!` پر انحصار کر سکتا ہے کہ رن ٹائم انوائینٹس کو نافذ کیا جا، ، اگر خلاف ورزی کی گئی تو وہ عدم تحفظ کا باعث بن سکتا ہے۔
    ///
    /// `assert!` کے دوسرے استعمال کے معاملات میں سیف کوڈ میں رن ٹائم حملہ آوروں کی جانچ اور ان کا نفاذ شامل ہے (جس کی خلاف ورزی کے نتیجے میں عدم استحکام پیدا نہیں ہوسکتا ہے)۔
    ///
    ///
    /// # حسب ضرورت پیغامات
    ///
    /// اس میکرو کی ایک دوسری شکل ہے ، جہاں فارمیٹنگ کے ل argu بغیر کسی دلیل کے اپنی مرضی کے مطابق panic پیغام فراہم کیا جاسکتا ہے۔
    /// اس فارم کے نحو کے ل X [`std::fmt`] دیکھیں۔
    /// شکل استدلال کے بطور استعمال شدہ تاثرات کا اندازہ اسی صورت میں ہوگا جب دعوی ناکام ہوجاتا ہے۔
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ان دعوؤں کے لئے panic پیغام دیئے گئے اظہار کی مختلف قیمت ہے۔
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ایک بہت ہی آسان تقریب
    ///
    /// assert!(some_computation());
    ///
    /// // اپنی مرضی کے پیغام کے ساتھ دعوی کریں
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ان لائن اسمبلی۔
    ///
    /// استعمال کے لئے [unstable book] پڑھیں۔
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM طرز کی ان لائن اسمبلی۔
    ///
    /// استعمال کے لئے [unstable book] پڑھیں۔
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// ماڈیول کی سطح کی ان لائن اسمبلی۔
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// پرنٹ tokens معیاری آؤٹ پٹ میں گزر گئے۔
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// دوسرے میکرو کو ٹھیک کرنے کے لئے استعمال کی جانے والی ٹریسنگ کی فعالیت کو اہل یا غیر فعال کرتی ہے۔
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ڈرییو میکرو کو لاگو کرنے کے لئے استعمال ہونے والی خصوصیت میکرو۔
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ایک فنکشن کو یونٹ ٹیسٹ میں تبدیل کرنے کے لئے انٹریبیوٹ میکرو کا اطلاق ہوتا ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ایک فنکشن کو بینچ مارک ٹیسٹ میں تبدیل کرنے کے لئے ایٹریبیوٹ میکرو کا اطلاق ہوتا ہے۔
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` اور `#[bench]` میکروز کی عمل آوری کی تفصیل۔
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// اسٹیبیوٹ میکرو نے جامد پر اسے عالمی مختص کنندہ کے طور پر رجسٹر کرنے کے لئے لاگو کیا۔
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) بھی دیکھیں۔
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// جس شے پر اس کا اطلاق ہوتا ہے اسے پاس رکھتا ہے اگر گزرنے والا راستہ قابل رسائی ہے ، اور اسے ہٹا دیتا ہے۔
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// جس کوڈ ٹکڑے پر اس کا اطلاق ہوتا ہے اس میں `#[cfg]` X اور `#[cfg_attr]` کی تمام خصوصیات کو وسعت دیتا ہے۔
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` مرتب کرنے والے کی غیر مستحکم نفاذ کی تفصیل ، استعمال نہ کریں۔
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` مرتب کرنے والے کی غیر مستحکم نفاذ کی تفصیل ، استعمال نہ کریں۔
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}