use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// غیر متشدد آئٹرس سے نمٹنے کے لئے ایک انٹرفیس۔
///
/// یہ مرکزی دھارے میں trait ہے۔
/// عام طور پر اسٹریمز کے تصور کے بارے میں مزید معلومات کے ل please ، براہ کرم [module-level documentation] دیکھیں۔
/// خاص طور پر ، آپ [implement `Stream`][impl] کا طریقہ جاننا چاہتے ہو۔
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// ندی کے ذریعہ حاصل کردہ آئٹمز کی قسم۔
    type Item;

    /// اس اسٹریم کی اگلی قیمت کو نکالنے کی کوشش کریں ، اگر ابھی قیمت دستیاب نہیں ہے تو ویک اپ کے لئے موجودہ ٹاسک کو رجسٹر کریں ، اور ندی ختم ہونے پر `None` واپس کریں۔
    ///
    /// # واپسی کی قیمت
    ///
    /// واپسی کی بہت ساری قدریں ہیں ، ہر ایک الگ ندی کی حالت کی نشاندہی کرتی ہے۔
    ///
    /// - `Poll::Pending` اس کا مطلب ہے کہ اس ندی کی اگلی قیمت ابھی تک تیار نہیں ہے۔عمل درآمد یقینی بنائے گا کہ موجودہ کام کو مطلع کیا جائے گا جب اگلی قیمت تیار ہوسکتی ہے۔
    ///
    /// - `Poll::Ready(Some(val))` اس کا مطلب ہے کہ ندی نے کامیابی کے ساتھ ، ایک `val` قدر تیار کی ہے ، اور بعد میں `poll_next` کالز پر مزید قدریں پیدا کرسکتی ہے۔
    ///
    /// - `Poll::Ready(None)` اس کا مطلب ہے کہ ندی ختم ہوچکی ہے ، اور `poll_next` کو دوبارہ طلب نہیں کیا جانا چاہئے۔
    ///
    /// # Panics
    ///
    /// ایک بار جب کوئی سلسلہ ختم ہوجاتا ہے (`Ready(None)` from `poll_next`) کو لوٹتا ہے ، اپنے `poll_next` طریقہ کو دوبارہ کال کرتا ہے ، panic کو ہمیشہ کے لئے روک سکتا ہے ، یا دیگر قسم کی پریشانیوں کا سبب بن سکتا ہے the `Stream` trait اس طرح کے کال کے اثرات کی کوئی ضرورت نہیں رکھتا ہے۔
    ///
    /// تاہم ، چونکہ `poll_next` طریقہ کو `unsafe` کی حیثیت سے نشان زد نہیں کیا گیا ہے ، Rust کے معمول کے قواعد لاگو ہوتے ہیں: کالوں کو کبھی بھی غیر متعینہ سلوک (میموری کی بدعنوانی ، `unsafe` افعال کا غلط استعمال ، یا اس طرح کے) کا سبب نہیں ہونا چاہئے ، قطع نظر اس سلسلے کی حالت کی۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// ندی کی باقی لمبائی کی حدود لوٹاتا ہے۔
    ///
    /// خاص طور پر ، `size_hint()` ایک ٹپل واپس کرتا ہے جہاں پہلا عنصر کم باونڈ ہوتا ہے ، اور دوسرا عنصر اوپری باؤنڈ ہوتا ہے۔
    ///
    /// واپس آنے والے ٹپل کا دوسرا نصف حص [ہ [`آپشن`]`<`[`usize`] `>` ہے۔
    /// یہاں ایک [`None`] کا مطلب یہ ہے کہ یا تو کوئی اوپری باؤنڈ معلوم نہیں ہوتا ہے ، یا اوپری باؤنڈ [`usize`] سے بڑا ہے۔
    ///
    /// # عملدرآمد نوٹ
    ///
    /// یہ نفاذ نہیں کیا جاتا ہے کہ ندی کے نفاذ سے عناصر کی اعلان شدہ تعداد حاصل ہوتی ہے۔چھوٹی چھوٹی ندی نچلے حد سے کم یا عناصر کی بالائی حد سے زیادہ حاصل کرسکتی ہے۔
    ///
    /// `size_hint()` بنیادی طور پر اصلاح کے ل used استعمال کرنے کا ارادہ ہے جیسے ندی کے عناصر کے ل. جگہ محفوظ کرنا ، لیکن اس پر بھروسہ نہیں کرنا چاہئے جیسے غیر محفوظ کوڈ میں حدود چیک کو چھوڑ دیں۔
    /// `size_hint()` کے غلط نفاذ سے میموری کی حفاظت کی خلاف ورزی نہیں ہوسکتی ہے۔
    ///
    /// اس نے کہا ، اس پر عمل درآمد کو ایک درست تخمینہ فراہم کرنا چاہئے ، کیونکہ بصورت دیگر یہ trait کے پروٹوکول کی خلاف ورزی ہوگی۔
    ///
    /// پہلے سے طے شدہ نفاذ returns (0، `[` No``]`) returns واپس کرتا ہے جو کسی بھی سلسلے کے لئے درست ہے۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}