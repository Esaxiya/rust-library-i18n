#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! غیر ملکی فنکشن انٹرفیس (FFI) پابندیوں سے متعلق افادیت۔

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// جب [pointer] کے طور پر استعمال ہوتا ہے تو C کی `void` قسم کے مساوی ہوتا ہے۔
///
/// جوہر میں ، `*const c_void` C کے `const void*` کے برابر ہے اور `*mut c_void` C کے `void*` کے برابر ہے۔
/// اس نے کہا ، یہ *X* X کی واپسی کی طرح نہیں ہے ، جو Rust کی `()` قسم کی ہے۔
///
/// ایف ایف آئی میں غیر واضح اقسام کی طرف اشارہ کرنے والے ماڈل کے لئے ، جب تک کہ `extern type` مستحکم نہ ہوجائے ، خالی بائٹ صف کے چاروں طرف newtype ریپر استعمال کرنے کی سفارش کی جاتی ہے۔
///
/// تفصیلات کے لئے [Nomicon] دیکھیں۔
///
/// کوئی `std::os::raw::c_void` استعمال کرسکتا ہے اگر وہ پرانے Rust مرتب کرنے والے کو 1.1.0 پر تعاون کرنا چاہتے ہیں۔
/// Rust 1.30.0 کے بعد ، اس تعریف کے ذریعہ اسے دوبارہ برآمد کیا گیا۔
/// مزید معلومات کے لئے ، براہ کرم [RFC 2521] پڑھیں۔
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB ، LLVM کو باطل پوائنٹر کی قسم کو تسلیم کرنے کے لئے اور malloc() جیسے توسیعی افعال کے ذریعہ ، ہمیں LLVM بٹ کوڈ میں اسے i8 * کی نمائندگی کرنے کی ضرورت ہے۔
// یہاں استعمال ہونے والے اینوم اس کو یقینی بناتا ہے اور صرف نجی قسموں کے ذریعہ "raw" قسم کے غلط استعمال کو روکتا ہے۔
// ہمیں دو مختلف حالتوں کی ضرورت ہے ، کیونکہ مرتب کرنے والے کو repr وصف کے بارے میں شکایت ہے اور ہمیں کم از کم ایک شکل کی ضرورت ہے کیونکہ بصورت دیگر enum غیر آباد ہوگا اور کم از کم ایسے نکات کو ڈی بی ڈیفینس کرنا UB ہوگا۔
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// ایک `va_list` کا بنیادی عمل۔
// نام WIP ہے ، ابھی کے لئے `VaListImpl` استعمال کرتا ہے۔
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` سے زیادہ مختلف ، لہذا ہر `VaListImpl<'f>` آبجیکٹ کو اس فنکشن کے علاقے سے جوڑا جاتا ہے جس میں اس کی وضاحت کی گئی ہے
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ABI `va_list` کا نفاذ۔
/// مزید تفصیلات کے لئے [AArch64 Procedure Call Standard] دیکھیں۔
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ABI `va_list` کا نفاذ۔
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ABI `va_list` کا نفاذ۔
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` کے ل A ریپر
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ایک `VaListImpl` کو `VaList` میں تبدیل کریں جو سی کے `va_list` کے ساتھ بائنری کے موافق ہے۔
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ایک `VaListImpl` کو `VaList` میں تبدیل کریں جو سی کے `va_list` کے ساتھ بائنری کے موافق ہے۔
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// واآرگ سیف زیڈ ٹریٹ0 زیڈ کو عوامی انٹرفیس میں استعمال کرنے کی ضرورت ہے ، تاہم ، trait کو خود بھی اس ماڈیول کے باہر استعمال کرنے کی اجازت نہیں ہونی چاہئے۔
// صارفین کو کسی نئی قسم کے لئے trait پر عمل درآمد کرنے کی اجازت دینا (جس کے ذریعہ va_arg اندرونی چیز کو ایک نئی قسم پر استعمال کرنے کی اجازت دی جائے) غیر یقینی رویے کا سبب بننے کا امکان ہے۔
//
// FIXME(dlrobertson): عوامی انٹرفیس میں واآرگ سیف زیڈ ٹرائٹ0 زیڈ استعمال کرنے کے ل but لیکن یہ بھی یقینی بنائیں کہ اسے کہیں اور استعمال نہیں کیا جاسکتا ہے ، trait کو نجی ماڈیول میں عوامی ہونے کی ضرورت ہے۔
// ایک بار جب آر ایف سی 2145 نافذ ہوجائے تو اس میں بہتری لائیں۔
//
//
//
//
mod sealed_trait {
    /// Trait جو اجازت دیتا ہے کہ قسموں کو [super::VaListImpl::arg] کے ساتھ استعمال کرنے کی اجازت دیتا ہے۔
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// اگلی دلیل پر آگے بڑھیں۔
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // محفوظ: کال کرنے والے کو `va_arg` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe { va_arg(self) }
    }

    /// موجودہ مقام پر `va_list` کی کاپی کریں۔
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // محفوظ: کال کرنے والے کو `va_end` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // محفوظ: ہم `MaybeUninit` کو لکھتے ہیں ، اس طرح اس کی ابتدا کی جاتی ہے اور `assume_init` قانونی ہے
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: اس کو `va_end` فون کرنا چاہئے ، لیکن اس کا کوئی صاف طریقہ نہیں ہے
        // اس بات کی گارنٹی ہے کہ `drop` ہمیشہ اس کے فون کرنے والے کی طرف مائل ہوجاتا ہے ، لہذا `va_end` اسی فنکشن سے براہ راست اسی `va_copy` کی طرح فون کرے گا۔
        // `man va_end` بیان کرتا ہے کہ سی کو اس کی ضرورت ہوتی ہے ، اور ایل ایل وی ایم بنیادی طور پر سی سیمنٹکس کی پیروی کرتا ہے ، لہذا ہمیں یہ یقینی بنانا ہوگا کہ `va_end` ہمیشہ اسی فنکشن سے `va_copy` کے طور پر بلایا جاتا ہے۔
        //
        // مزید تفصیلات کے لیے، see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // یہ اب کے ل works کام کرتا ہے ، کیونکہ `va_end` تمام موجودہ LLVM اہداف پر ایک انتخاب نہیں ہے۔
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` یا `va_copy` کے ساتھ ابتدا کے بعد آرگ لسٹ `ap` کو خارج کردیں۔
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// آرگلسٹ `src` کے موجودہ مقام کو آرگ لسٹ `dst` میں کاپی کرتا ہے۔
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` سے `T` قسم کی ایک دلیل لوڈ کرتا ہے اور `ap` کی طرف اشارہ کرنے والے دلیل میں اضافہ ہوتا ہے۔
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}