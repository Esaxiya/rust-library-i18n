//! جوہری اقسام
//!
//! جوہری اقسام دھاگوں کے مابین مشترکہ میموری مشترکہ مواصلت فراہم کرتے ہیں ، اور یہ دوسرے ہم آہنگ اقسام کے بنیادی بلاکس ہیں۔
//!
//! یہ ماڈیول آدم اقسام کی ایک منتخب تعداد کے جوہری ورژن کی وضاحت کرتا ہے ، جس میں [`AtomicBool`] ، [`AtomicIsize`] ، [`AtomicUsize`] ، [`AtomicI8`] ، [`AtomicU16`] ، وغیرہ شامل ہیں۔
//! جوہری اقسام آپریشن پیش کرتے ہیں جو صحیح طریقے سے استعمال ہونے پر ، دھاگوں کے مابین تازہ ترین معلومات کو ہم وقت ساز کرتے ہیں۔
//!
//! ہر طریقہ کار میں ایک [`Ordering`] ہوتا ہے جو اس آپریشن کے لئے میموری رکاوٹ کی طاقت کی نمائندگی کرتا ہے۔یہ آرڈرز [C++20 atomic orderings][1] جیسی ہی ہیں۔مزید معلومات کے لئے دیکھیں [nomicon][2]۔
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! جوہری تغیرات دھاگوں کے مابین شیئر کرنا محفوظ ہیں (وہ [`Sync`] لاگو کرتے ہیں) لیکن وہ خود Rust کے [threading model](../../../std/thread/index.html#the-threading-model) کو بانٹنے اور ان کی پیروی کرنے کا طریقہ کار فراہم نہیں کرتے ہیں۔
//!
//! جوہری متغیر کا اشتراک کرنے کا سب سے عام طریقہ یہ ہے کہ اسے [`Arc`][arc] (ایک جوہری لحاظ سے حوالہ سے گنتی والا مشترکہ پوائنٹر) میں ڈالنا ہے۔
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! جوہری اقسام کو جامد متغیر میں اسٹور کیا جاسکتا ہے ، مستحکم ابتدائی [`AtomicBool::new`] کا استعمال کرتے ہوئے ابتدا کی جاتی ہے۔جوہری اسٹیٹکس اکثر سست عالمی شروعات کے لئے استعمال ہوتے ہیں۔
//!
//! # Portability
//!
//! اس ماڈیول میں موجود تمام جوہری قسموں کے [lock-free] کی ضمانت دی گئی ہے اگر وہ دستیاب ہوں۔اس کا مطلب ہے کہ وہ داخلی طور پر عالمی سطح پر خاموشی اختیار نہیں کرتے ہیں۔جوہری اقسام اور کاروائیوں کی ضمانت آزاد نہیں ہے۔
//! اس کا مطلب یہ ہے کہ `fetch_or` جیسے آپس میں موازنہ اور تبادلہ لوپ کے ساتھ عمل درآمد کیا جاسکتا ہے۔
//!
//! ایٹم آپریشن بڑے پیمانے پر ایٹمکس کے ساتھ انسٹرکشن لیئر پر لاگو ہو سکتے ہیں۔مثال کے طور پر کچھ پلیٹ فارم `AtomicI8` کو لاگو کرنے کے لئے 4 بائٹ ایٹم ہدایت کا استعمال کرتے ہیں۔
//! نوٹ کریں کہ اس تقلید کا کوڈ کی درستگی پر اثر انداز نہیں ہونا چاہئے ، اس سے باخبر رہنا ہی کچھ ہے۔
//!
//! ہوسکتا ہے کہ اس ماڈیول میں جوہری قسمیں تمام پلیٹ فارمز پر دستیاب نہ ہوں۔تاہم ، یہاں جوہری قسمیں تمام وسیع پیمانے پر دستیاب ہیں ، اور عام طور پر موجودہ پر انحصار کیا جاسکتا ہے۔کچھ قابل ذکر مستثنیات یہ ہیں:
//!
//! * PowerPC اور 32 بٹ پوائنٹرز والے MIPS پلیٹ فارم میں `AtomicU64` یا `AtomicI64` اقسام نہیں ہیں۔
//! * ARM `armv5te` جیسے پلیٹ فارم جو Linux کیلئے نہیں ہیں وہ صرف `load` اور `store` کاروائیاں مہیا کرتے ہیں ، اور `swap` ، `fetch_add` ، جیسے X اور (CAS) کا موازنہ اور تبادلہ کرنے کی حمایت نہیں کرتے ہیں۔
//! اضافی طور پر Linux پر ، یہ CAS آپریشنز [operating system support] کے ذریعے نافذ کیے جاتے ہیں ، جو کارکردگی کی سزا کے ساتھ آسکتے ہیں۔
//! * ARM `thumbv6m` والے اہداف صرف `load` اور `store` کاروائیاں مہیا کرتے ہیں ، اور `swap`، `fetch_add` ، جیسے (CAS) آپریشن کا موازنہ اور تبادلہ کرنے کی حمایت نہیں کرتے ہیں۔
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! نوٹ کریں کہ زیڈ فیوچر0 زیڈ پلیٹ فارمز کو شامل کیا جاسکتا ہے جس میں کچھ جوہری کارروائیوں کی بھی حمایت حاصل نہیں ہے۔زیادہ سے زیادہ پورٹیبل کوڈ محتاط رہنا چاہتا ہے کہ کون سی جوہری قسمیں استعمال ہوتی ہیں۔
//! `AtomicUsize` اور `AtomicIsize` عام طور پر سب سے زیادہ پورٹیبل ہیں ، لیکن پھر بھی وہ ہر جگہ دستیاب نہیں ہیں۔
//! حوالہ کے ل the ، `std` لائبریری میں پوائنٹر سائز کے ایٹمکس کی ضرورت ہے ، حالانکہ `core` ایسا نہیں کرتا ہے۔
//!
//! فی الحال آپ کو جوہری عناصر کے ساتھ کوڈ میں مشروط طور پر مرتب کرنے کے لئے بنیادی طور پر `#[cfg(target_arch)]` استعمال کرنے کی ضرورت ہوگی۔ایک غیر مستحکم `#[cfg(target_has_atomic)]` بھی ہے جو future میں مستحکم ہوسکتا ہے۔
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ایک سادہ اسپن لاک:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // دوسرے دھاگے کا تالا جاری کرنے کا انتظار کریں
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! براہ راست تھریڈز کی عالمی گنتی رکھیں:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// ایک بولین کی قسم جو دھاگوں کے مابین محفوظ طریقے سے شیئر کی جاسکتی ہے۔
///
/// اس قسم میں [`bool`] جیسی ہی میموری میں نمائندگی ہے۔
///
/// **نوٹ**: یہ قسم صرف ان پلیٹ فارم پر دستیاب ہے جو `u8` کے جوہری بوجھ اور اسٹورز کی حمایت کرتے ہیں۔
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` سے شروع کردہ ایک `AtomicBool` بناتا ہے۔
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// ایٹمکول کے لئے بھیجیں پر واضح طور پر عمل درآمد کیا گیا ہے۔
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ایک خام پوائنٹر کی قسم جو دھاگوں کے مابین محفوظ طریقے سے شیئر کی جاسکتی ہے۔
///
/// اس قسم میں `*mut T` جیسی ہی میموری میں نمائندگی ہے۔
///
/// **نوٹ**: یہ قسم صرف ان پلیٹ فارم پر دستیاب ہے جو ایٹم بوجھ اور پوائنٹرس اسٹورز کو سپورٹ کرتے ہیں۔
/// اس کا سائز ہدف پوائنٹر کے سائز پر منحصر ہوتا ہے۔
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// ایک کالعدم `AtomicPtr<T>` بناتا ہے۔
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ایٹم میموری میموری
///
/// میموری کے آرڈرنگ جوہری آپریشنز میموری کو ہم آہنگ کرنے کا طریقہ بتاتے ہیں۔
/// اس کے سب سے کمزور [`Ordering::Relaxed`] میں ، آپریشن سے براہ راست چھونے والی میموری کو ہم وقت ساز کیا جاتا ہے۔
/// دوسری طرف ، [`Ordering::SeqCst`] کارروائیوں کا ایک اسٹور بوجھ جوڑا دوسرے میموری کو ہم آہنگ کرتا ہے جبکہ اضافی طور پر اس طرح کے آپریشنز کے مجموعی ترتیب کو تمام تھریڈز میں محفوظ کرتا ہے۔
///
///
/// Rust کی میموری کے آرڈر [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) ہیں۔
///
/// مزید معلومات کے لئے دیکھیں [nomicon]۔
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// آرڈرنگ کی کوئی رکاوٹیں نہیں ، صرف ایٹمی عمل ہیں۔
    ///
    /// C ++ 20 میں [`memory_order_relaxed`] کے مطابق ہے۔
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// جب کسی اسٹور کے ساتھ مل کر ، [`Acquire`] (یا مضبوط) آرڈر کے ساتھ اس قدر کے کسی بوجھ سے پہلے کے تمام سابقہ آپریشن آرڈر ہوجاتے ہیں۔
    ///
    /// خاص طور پر ، تمام پچھلی تحریریں ان تمام دھاگوں کے لئے مرئی ہوجاتی ہیں جو اس قدر کا ایک [`Acquire`] (یا زیادہ مضبوط) انجام دیتے ہیں۔
    ///
    /// نوٹ کریں کہ بوجھ اور اسٹورز کو یکجا کرنے والے آپریشن کے ل this اس آرڈرنگ کا استعمال [`Relaxed`] لوڈ آپریشن کا باعث بنتا ہے!
    ///
    /// یہ آرڈرنگ صرف ان کارروائیوں کے لئے ہی قابل اطلاق ہے جو اسٹور انجام دے سکتی ہے۔
    ///
    /// C ++ 20 میں [`memory_order_release`] کے مطابق ہے۔
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// جب بوجھ کے ساتھ مل کر ، اگر بھاری مالیت [`Release`] (یا زیادہ مضبوط) آرڈر والے اسٹور آپریشن کے ذریعہ لکھی گئی ہو ، تو اس کے بعد کے تمام کام اس اسٹور کے بعد آرڈر ہوجائیں گے۔
    /// خاص طور پر ، اس کے بعد کے تمام بوجھ اسٹور سے پہلے لکھا ہوا ڈیٹا دیکھیں گے۔
    ///
    /// نوٹ کریں کہ بوجھ اور اسٹورز کو یکجا کرنے والے آپریشن کیلئے اس آرڈرنگ کا استعمال [`Relaxed`] اسٹور آپریشن کا باعث بنتا ہے!
    ///
    /// یہ آرڈرنگ صرف ان کارروائیوں کے لئے قابل اطلاق ہے جو بوجھ انجام دے سکتے ہیں۔
    ///
    /// C ++ 20 میں [`memory_order_acquire`] کے مطابق ہے۔
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// ایک ساتھ [`Acquire`] اور [`Release`] دونوں کے اثرات ہیں:
    /// بوجھ کے لئے یہ [`Acquire`] آرڈرنگ کا استعمال کرتا ہے۔اسٹورز کے لئے یہ [`Release`] آرڈرنگ کا استعمال کرتا ہے۔
    ///
    /// نوٹ کریں کہ `compare_and_swap` کی صورت میں ، یہ ممکن ہے کہ آپریشن کسی بھی اسٹور کو انجام نہیں دے رہا ہو اور اسی وجہ سے اس کا صرف [`Acquire`] آرڈر ہو۔
    ///
    /// تاہم ، `AcqRel` کبھی بھی [`Relaxed`] تک رسائی حاصل نہیں کرے گا۔
    ///
    /// یہ آرڈرنگ صرف ان کارروائیوں کے لئے قابل اطلاق ہے جو بوجھ اور اسٹور دونوں کو یکجا کرتے ہیں۔
    ///
    /// C ++ 20 میں [`memory_order_acq_rel`] کے مطابق ہے۔
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [qu ایکوائرqu]/[`ریلیز`]/[` ایکقریلی](اضافی گارنٹی کے ساتھ (بالترتیب بوجھ ، اسٹور اور بوجھ کے ساتھ اسٹور کی کارروائیوں کے لئے)) اضافی گارنٹی کے ساتھ کہ تمام تھریڈز ایک ہی ترتیب میں تمام تسلسل کے مطابق کاروائیاں دیکھتے ہیں۔ .
    ///
    ///
    /// C ++ 20 میں [`memory_order_seq_cst`] کے مطابق ہے۔
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// ایک [`AtomicBool`] `false` میں شروع ہوا۔
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// ایک نیا `AtomicBool` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// بنیادی [`bool`] کا تبادلہ خیال لوٹاتا ہے۔
    ///
    /// یہ محفوظ ہے کیونکہ تغیر پزیر حوالہ اس بات کی ضمانت دیتا ہے کہ بیک وقت کوئی دوسرے دھاگے جوہری اعداد و شمار تک نہیں پہنچ رہے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // حفاظت: تغیر پذیر حوالہ انفرادیت کی ملکیت کی ضمانت دیتا ہے۔
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` تک ایٹم تک رسائی حاصل کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // حفاظت: تغیر پذیر حوالہ انوکھی ملکیت کی ضمانت دیتا ہے ، اور
        // `bool` اور `Self` دونوں کی سیدھ 1 ہے۔
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// جوہری استعمال کرتا ہے اور موجود قدر کو لوٹاتا ہے۔
    ///
    /// یہ محفوظ ہے کیونکہ `self` کو قدر کے لحاظ سے گزرنا اس بات کی ضمانت دیتا ہے کہ کوئی دوسرے دھاگے بیک وقت ایٹم کے ڈیٹا تک نہیں پہنچ رہے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool سے ایک قدر لوڈ کرتا ہے۔
    ///
    /// `load` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
    /// ممکنہ اقدار ہیں [`SeqCst`] ، [`Acquire`] اور [`Relaxed`]۔
    ///
    /// # Panics
    ///
    /// Panics اگر `order` [`Release`] یا [`AcqRel`] ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // محفوظ: کسی بھی اعداد و شمار کی دوڑ کو جوہری اندرونی اور خام مواد سے روکا جاتا ہے
        // میں پاس کیا ہوا پوائنٹر درست ہے کیونکہ ہمیں یہ ایک حوالہ سے ملا ہے۔
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// `store` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
    /// ممکنہ اقدار ہیں [`SeqCst`] ، [`Release`] اور [`Relaxed`]۔
    ///
    /// # Panics
    ///
    /// Panics اگر `order` [`Acquire`] یا [`AcqRel`] ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // محفوظ: کسی بھی اعداد و شمار کی دوڑ کو جوہری اندرونی اور خام مواد سے روکا جاتا ہے
        // میں پاس کیا ہوا پوائنٹر درست ہے کیونکہ ہمیں یہ ایک حوالہ سے ملا ہے۔
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool میں ایک قیمت اسٹور کرتا ہے ، پچھلی ویلیو کو لوٹاتا ہے۔
    ///
    /// `swap` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
    /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
    ///
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// اگر موجودہ قیمت `current` قدر کی سی ہے تو [`bool`] میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// واپسی کی قیمت ہمیشہ پچھلی قیمت ہوتی ہے۔اگر یہ `current` کے برابر ہے تو پھر قیمت کو اپ ڈیٹ کردیا گیا۔
    ///
    /// `compare_and_swap` ایک [`Ordering`] دلیل بھی لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
    /// نوٹ کریں کہ یہاں تک کہ جب [`AcqRel`] استعمال کرتے ہوئے بھی ، آپریشن ناکام ہوسکتا ہے اور اس وجہ سے صرف ایک `Acquire` بوجھ انجام دے سکتا ہے ، لیکن اس میں `Release` الفاظ نہیں ہیں۔
    /// [`Acquire`] کا استعمال اسٹور کو [`Relaxed`] کا اس آپریشن کا حصہ بناتا ہے اگر ایسا ہوتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] ہوجاتا ہے۔
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # `compare_exchange` اور `compare_exchange_weak` میں منتقل ہورہا ہے
    ///
    /// `compare_and_swap` میموری آرڈرنگ کے ل X مندرجہ ذیل نقشہ سازی کے ساتھ `compare_exchange` کے برابر ہے:
    ///
    /// اصل |کامیابی |ناکامی
    /// -------- | ------- | -------
    /// آرام دہ |آرام دہ |آرام سے حصول |حاصل |حصول کی رہائی |رہائی |آرام دہ ایکقریل |AcqRel |سیکو سسٹ حاصل کریںSeqCst |SeqCst
    ///
    /// `compare_exchange_weak` جب موازنہ کامیاب ہوجاتا ہے تب بھی حوصلہ افزائی سے ناکام ہونے کی اجازت دی جاتی ہے ، جس سے کمپلر بہتر اسمبلی کوڈ تیار کرنے کی اجازت دیتا ہے جب موازنہ اور تبادلہ لوپ میں استعمال ہوتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// اگر موجودہ قیمت `current` قدر کی سی ہے تو [`bool`] میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// واپسی کی قیمت ایک نتیجہ ہے جس سے یہ ظاہر ہوتا ہے کہ آیا نئی قیمت لکھی گئی تھی اور اس میں پچھلی قیمت موجود تھی۔
    /// کامیابی پر یہ قیمت `current` کے برابر ہونے کی ضمانت ہے۔
    ///
    /// `compare_exchange` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
    /// `success` ریڈ میڈیفائی رائٹ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جو `current` کے ساتھ موازنہ کامیاب ہوجاتا ہے تو ہوتا ہے۔
    /// `failure` موازنہ ناکام ہونے پر ہونے والے لوڈ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے۔
    /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
    ///
    /// آرڈر کی ناکامی صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// اگر موجودہ قیمت `current` قدر کی سی ہے تو [`bool`] میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// [`AtomicBool::compare_exchange`] کے برعکس ، موازنہ کامیاب ہونے پر بھی اس فنکشن کو تیزی سے ناکام ہونے کی اجازت ہے ، جس کے نتیجے میں کچھ پلیٹ فارمز پر زیادہ موثر کوڈ مل سکتا ہے۔
    ///
    /// واپسی کی قیمت ایک نتیجہ ہے جس سے یہ ظاہر ہوتا ہے کہ آیا نئی قیمت لکھی گئی تھی اور اس میں پچھلی قیمت موجود تھی۔
    ///
    /// `compare_exchange_weak` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
    /// `success` ریڈ میڈیفائی رائٹ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جو `current` کے ساتھ موازنہ کامیاب ہوجاتا ہے تو ہوتا ہے۔
    /// `failure` موازنہ ناکام ہونے پر ہونے والے لوڈ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے۔
    /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
    /// آرڈر کی ناکامی صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// منطقی "and" ایک بولین قدر کے ساتھ۔
    ///
    /// موجودہ قدر اور دلیل `val` پر ایک منطقی "and" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر متعین کرتا ہے۔
    ///
    /// پچھلی قیمت لوٹاتا ہے۔
    ///
    /// `fetch_and` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
    /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
    ///
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// منطقی "nand" ایک بولین قدر کے ساتھ۔
    ///
    /// موجودہ قدر اور دلیل `val` پر ایک منطقی "nand" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر متعین کرتا ہے۔
    ///
    /// پچھلی قیمت لوٹاتا ہے۔
    ///
    /// `fetch_nand` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
    /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
    ///
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // ہم یہاں جوہری_نند کا استعمال نہیں کرسکتے ہیں کیونکہ اس کا نتیجہ bool میں غلط قیمت کے ساتھ ہوسکتا ہے۔
        // ایسا اس لئے ہوتا ہے کیونکہ جوہری آپریشن اندرونی طور پر 8 بٹ عدد کے ساتھ کیا جاتا ہے ، جس سے اوپری 7 بٹس سیٹ ہوتی ہیں۔
        //
        // لہذا ہم اس کے بجائے صرف بازیافت_کسیور یا تبادلہ استعمال کرتے ہیں۔
        if val {
            // ! (x&true)== !x ہمیں bool تبدیل کرنا چاہئے۔
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&غلط)==سچ ہمیں bool کو سچ پر سیٹ کرنا ہوگا۔
            //
            self.swap(true, order)
        }
    }

    /// منطقی "or" ایک بولین قدر کے ساتھ۔
    ///
    /// موجودہ قدر اور دلیل `val` پر ایک منطقی "or" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر متعین کرتا ہے۔
    ///
    /// پچھلی قیمت لوٹاتا ہے۔
    ///
    /// `fetch_or` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
    /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
    ///
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// منطقی "xor" ایک بولین قدر کے ساتھ۔
    ///
    /// موجودہ قدر اور دلیل `val` پر ایک منطقی "xor" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر متعین کرتا ہے۔
    ///
    /// پچھلی قیمت لوٹاتا ہے۔
    ///
    /// `fetch_xor` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
    /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
    ///
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// بنیادی تبادلہ [`bool`] پر ایک بدلنے والا پوائنٹر لوٹاتا ہے۔
    ///
    /// نتیجے میں عدد پر غیر جوہری پڑھنے اور لکھنا کرنا ڈیٹا ریس ہوسکتا ہے۔
    /// یہ طریقہ زیادہ تر FFI کے لئے مفید ہے ، جہاں تقریب کے دستخط میں `&AtomicBool` کی بجائے `*mut bool` کا استعمال کیا جاسکتا ہے۔
    ///
    /// اس جوہری کے مشترکہ حوالہ سے `*mut` پوائنٹر کی واپسی محفوظ ہے کیونکہ جوہری اقسام داخلی تغیر پذیر کے ساتھ کام کرتے ہیں۔
    /// ایک جوہری کی تمام ترامیم مشترکہ حوالہ کے ذریعہ قدر کو بدلتی ہیں ، اور جب تک وہ ایٹمی کارروائیوں کا استعمال کرتے ہیں تو محفوظ طریقے سے کر سکتے ہیں۔
    /// لوٹے ہوئے خام پوائنٹر کے کسی بھی استعمال کے لئے ایک `unsafe` بلاک کی ضرورت ہوتی ہے اور اب بھی اسی پابندی کو برقرار رکھنا پڑتا ہے: اس پر کاروائیاں جوہری ہونی چاہئیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// قدر لاتا ہے ، اور اس پر ایک فنکشن لاگو ہوتا ہے جو اختیاری نئی ویلیو واپس کرتا ہے۔`Ok(previous_value)` کا `Result` واپس کرتا ہے ، اگر فنکشن `Some(_)` کو واپس کرتا ہے ، ورنہ `Err(previous_value)`۔
    ///
    /// Note: اگر اس دوران اس فنکشن میں X50X کی واپسی ہوتی ہے تو ، اگر اس دوران دیگر دھاگوں سے قدر تبدیل کردی گئی ہو تو یہ فنکشن کو متعدد بار کال کرسکتا ہے ، لیکن فنکشن صرف ایک بار اسٹورڈ ویلیو پر لاگو ہوگا۔
    ///
    ///
    /// `fetch_update` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
    /// پہلے آپریشن کے کامیاب ہونے کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جبکہ دوسرا بوجھ کے ل for مطلوبہ آرڈرنگ کی وضاحت کرتا ہے۔
    /// یہ بالترتیب [`AtomicBool::compare_exchange`] کی کامیابی اور ناکامی کے آرڈرز کے مطابق ہیں۔
    ///
    /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے آخری کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
    /// (failed) لوڈ آرڈرنگ صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
    ///
    /// **Note:** یہ طریقہ صرف پلیٹ فارم پر دستیاب ہے جو `u8` پر جوہری کارروائیوں کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// ایک نیا `AtomicPtr` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// زیربحث پوائنٹر کا ایک متغیر حوالہ واپس کرتا ہے۔
    ///
    /// یہ محفوظ ہے کیونکہ تغیر پزیر حوالہ اس بات کی ضمانت دیتا ہے کہ بیک وقت کوئی دوسرے دھاگے جوہری اعداد و شمار تک نہیں پہنچ رہے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// کسی پوائنٹر تک ایٹم تک رسائی حاصل کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - تغیر پزیر حوالہ انفرادیت کی ملکیت کی ضمانت دیتا ہے۔
        //  - `*mut T` اور `Self` کی سیدھ میں شامل rust کے ذریعے تعاون کردہ تمام پلیٹ فارمز پر ایک جیسا ہے ، جیسا کہ اوپر تصدیق شدہ ہے۔
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// جوہری استعمال کرتا ہے اور موجود قدر کو لوٹاتا ہے۔
    ///
    /// یہ محفوظ ہے کیونکہ `self` کو قدر کے لحاظ سے گزرنا اس بات کی ضمانت دیتا ہے کہ کوئی دوسرے دھاگے بیک وقت ایٹم کے ڈیٹا تک نہیں پہنچ رہے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// پوائنٹر سے ایک قدر لوڈ کرتا ہے۔
    ///
    /// `load` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
    /// ممکنہ اقدار ہیں [`SeqCst`] ، [`Acquire`] اور [`Relaxed`]۔
    ///
    /// # Panics
    ///
    /// Panics اگر `order` [`Release`] یا [`AcqRel`] ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// پوائنٹر میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// `store` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
    /// ممکنہ اقدار ہیں [`SeqCst`] ، [`Release`] اور [`Relaxed`]۔
    ///
    /// # Panics
    ///
    /// Panics اگر `order` [`Acquire`] یا [`AcqRel`] ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// پچھلی قیمت کو لوٹاتے ہوئے ، کسی پوائنٹر میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// `swap` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
    /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
    ///
    ///
    /// **Note:** یہ طریقہ کار صرف ان پلیٹ فارم پر دستیاب ہے جو پوائنٹرز پر ایٹم آپریشن کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// اگر موجودہ قیمت `current` قدر کی سی ہے تو پوائنٹر میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// واپسی کی قیمت ہمیشہ پچھلی قیمت ہوتی ہے۔اگر یہ `current` کے برابر ہے تو پھر قیمت کو اپ ڈیٹ کردیا گیا۔
    ///
    /// `compare_and_swap` ایک [`Ordering`] دلیل بھی لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
    /// نوٹ کریں کہ یہاں تک کہ جب [`AcqRel`] استعمال کرتے ہوئے بھی ، آپریشن ناکام ہوسکتا ہے اور اس وجہ سے صرف ایک `Acquire` بوجھ انجام دے سکتا ہے ، لیکن اس میں `Release` الفاظ نہیں ہیں۔
    /// [`Acquire`] کا استعمال اسٹور کو [`Relaxed`] کا اس آپریشن کا حصہ بناتا ہے اگر ایسا ہوتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] ہوجاتا ہے۔
    ///
    /// **Note:** یہ طریقہ کار صرف ان پلیٹ فارم پر دستیاب ہے جو پوائنٹرز پر ایٹم آپریشن کی حمایت کرتے ہیں۔
    ///
    /// # `compare_exchange` اور `compare_exchange_weak` میں منتقل ہورہا ہے
    ///
    /// `compare_and_swap` میموری آرڈرنگ کے ل X مندرجہ ذیل نقشہ سازی کے ساتھ `compare_exchange` کے برابر ہے:
    ///
    /// اصل |کامیابی |ناکامی
    /// -------- | ------- | -------
    /// آرام دہ |آرام دہ |آرام سے حصول |حاصل |حصول کی رہائی |رہائی |آرام دہ ایکقریل |AcqRel |سیکو سسٹ حاصل کریںSeqCst |SeqCst
    ///
    /// `compare_exchange_weak` جب موازنہ کامیاب ہوجاتا ہے تب بھی حوصلہ افزائی سے ناکام ہونے کی اجازت دی جاتی ہے ، جس سے کمپلر بہتر اسمبلی کوڈ تیار کرنے کی اجازت دیتا ہے جب موازنہ اور تبادلہ لوپ میں استعمال ہوتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// اگر موجودہ قیمت `current` قدر کی سی ہے تو پوائنٹر میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// واپسی کی قیمت ایک نتیجہ ہے جس سے یہ ظاہر ہوتا ہے کہ آیا نئی قیمت لکھی گئی تھی اور اس میں پچھلی قیمت موجود تھی۔
    /// کامیابی پر یہ قیمت `current` کے برابر ہونے کی ضمانت ہے۔
    ///
    /// `compare_exchange` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
    /// `success` ریڈ میڈیفائی رائٹ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جو `current` کے ساتھ موازنہ کامیاب ہوجاتا ہے تو ہوتا ہے۔
    /// `failure` موازنہ ناکام ہونے پر ہونے والے لوڈ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے۔
    /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
    ///
    /// آرڈر کی ناکامی صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
    ///
    /// **Note:** یہ طریقہ کار صرف ان پلیٹ فارم پر دستیاب ہے جو پوائنٹرز پر ایٹم آپریشن کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// اگر موجودہ قیمت `current` قدر کی سی ہے تو پوائنٹر میں ایک قدر اسٹور کرتا ہے۔
    ///
    /// [`AtomicPtr::compare_exchange`] کے برعکس ، موازنہ کامیاب ہونے پر بھی اس فنکشن کو تیزی سے ناکام ہونے کی اجازت ہے ، جس کے نتیجے میں کچھ پلیٹ فارمز پر زیادہ موثر کوڈ مل سکتا ہے۔
    ///
    /// واپسی کی قیمت ایک نتیجہ ہے جس سے یہ ظاہر ہوتا ہے کہ آیا نئی قیمت لکھی گئی تھی اور اس میں پچھلی قیمت موجود تھی۔
    ///
    /// `compare_exchange_weak` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
    /// `success` ریڈ میڈیفائی رائٹ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جو `current` کے ساتھ موازنہ کامیاب ہوجاتا ہے تو ہوتا ہے۔
    /// `failure` موازنہ ناکام ہونے پر ہونے والے لوڈ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے۔
    /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
    /// آرڈر کی ناکامی صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
    ///
    /// **Note:** یہ طریقہ کار صرف ان پلیٹ فارم پر دستیاب ہے جو پوائنٹرز پر ایٹم آپریشن کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // حفاظت: یہ اندرونی غیر محفوظ ہے کیونکہ یہ خام پوائنٹر پر چلتا ہے
        // لیکن ہم یقینی طور پر جانتے ہیں کہ یہ پوائنٹر درست ہے (ہمیں ابھی ایک `UnsafeCell` سے ملا ہے جو ہمارے پاس حوالہ سے ہے) اور جوہری آپریشن ہی ہمیں `UnsafeCell` مشمولات کو بحفاظت تبدیل کرنے کی اجازت دیتا ہے۔
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// قدر لاتا ہے ، اور اس پر ایک فنکشن لاگو ہوتا ہے جو اختیاری نئی ویلیو واپس کرتا ہے۔`Ok(previous_value)` کا `Result` واپس کرتا ہے ، اگر فنکشن `Some(_)` کو واپس کرتا ہے ، ورنہ `Err(previous_value)`۔
    ///
    /// Note: اگر اس دوران اس فنکشن میں X50X کی واپسی ہوتی ہے تو ، اگر اس دوران دیگر دھاگوں سے قدر تبدیل کردی گئی ہو تو یہ فنکشن کو متعدد بار کال کرسکتا ہے ، لیکن فنکشن صرف ایک بار اسٹورڈ ویلیو پر لاگو ہوگا۔
    ///
    ///
    /// `fetch_update` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
    /// پہلے آپریشن کے کامیاب ہونے کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جبکہ دوسرا بوجھ کے ل for مطلوبہ آرڈرنگ کی وضاحت کرتا ہے۔
    /// یہ بالترتیب [`AtomicPtr::compare_exchange`] کی کامیابی اور ناکامی کے آرڈرز کے مطابق ہیں۔
    ///
    /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے آخری کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
    /// (failed) لوڈ آرڈرنگ صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
    ///
    /// **Note:** یہ طریقہ کار صرف ان پلیٹ فارم پر دستیاب ہے جو پوائنٹرز پر ایٹم آپریشن کی حمایت کرتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` کو `AtomicBool` میں تبدیل کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // یہ میکرو کچھ فن تعمیرات کے غیر استعمال شدہ ہو کر ختم ہوتا ہے۔
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// ایک عددی قسم جو دھاگوں کے مابین محفوظ طریقے سے شیئر کی جاسکتی ہے۔
        ///
        /// اس قسم کی میموری کی نمائندگی اسی طرح کی بنیادی انٹیجر قسم کی ہوتی ہے ، [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// جوہری اقسام اور غیر جوہری اقسام کے مابین فرق کے بارے میں مزید معلومات کے ساتھ ساتھ اس قسم کی نقل و حمل کے بارے میں معلومات کے لئے ، براہ کرم [module-level documentation] دیکھیں۔
        ///
        ///
        /// **Note:** یہ قسم صرف ان پلیٹ فارم پر دستیاب ہے جو [`] کے جوہری بوجھ اور اسٹورز کو سپورٹ کرتے ہیں
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// ایک جوہری عددی `0` سے شروع کیا گیا۔
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // بھیجیں واضح طور پر لاگو کیا گیا ہے۔
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// ایک نیا جوہری عدد بناتا ہے۔
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// بنیادی عدد کو ایک متغیر حوالہ واپس کرتا ہے۔
            ///
            /// یہ محفوظ ہے کیونکہ تغیر پزیر حوالہ اس بات کی ضمانت دیتا ہے کہ بیک وقت کوئی دوسرے دھاگے جوہری اعداد و شمار تک نہیں پہنچ رہے ہیں۔
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5؛
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// چلو mut_some_int=123؛
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int، 100)؛
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - تغیر پزیر حوالہ انفرادیت کی ملکیت کی ضمانت دیتا ہے۔
                //  - `$int_type` اور `Self` کی سیدھ ایک جیسی ہے ، جیسا کہ $cfg_align کے ذریعہ وعدہ کیا گیا ہے اور اوپر تصدیق شدہ ہے۔
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// جوہری استعمال کرتا ہے اور موجود قدر کو لوٹاتا ہے۔
            ///
            /// یہ محفوظ ہے کیونکہ `self` کو قدر کے لحاظ سے گزرنا اس بات کی ضمانت دیتا ہے کہ کوئی دوسرے دھاگے بیک وقت ایٹم کے ڈیٹا تک نہیں پہنچ رہے ہیں۔
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// جوہری عددی سے ایک قدر لادتے ہیں۔
            ///
            /// `load` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
            /// ممکنہ اقدار ہیں [`SeqCst`] ، [`Acquire`] اور [`Relaxed`]۔
            ///
            /// # Panics
            ///
            /// Panics اگر `order` [`Release`] یا [`AcqRel`] ہے۔
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// ایک قدر کو جوہری اعداد میں جمع کرتا ہے۔
            ///
            /// `store` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
            ///  ممکنہ اقدار ہیں [`SeqCst`] ، [`Release`] اور [`Relaxed`]۔
            ///
            /// # Panics
            ///
            /// Panics اگر `order` [`Acquire`] یا [`AcqRel`] ہے۔
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// ایک قدر کو جوہری اعداد میں جمع کرتا ہے ، پچھلی قیمت کو لوٹاتا ہے۔
            ///
            /// `swap` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// اگر موجودہ قیمت `current` ویلیو جیسا ہی ہے تو کسی قدر کو جوہری اعداد میں جمع کرتا ہے۔
            ///
            /// واپسی کی قیمت ہمیشہ پچھلی قیمت ہوتی ہے۔اگر یہ `current` کے برابر ہے تو پھر قیمت کو اپ ڈیٹ کردیا گیا۔
            ///
            /// `compare_and_swap` ایک [`Ordering`] دلیل بھی لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔
            /// نوٹ کریں کہ یہاں تک کہ جب [`AcqRel`] استعمال کرتے ہوئے بھی ، آپریشن ناکام ہوسکتا ہے اور اس وجہ سے صرف ایک `Acquire` بوجھ انجام دے سکتا ہے ، لیکن اس میں `Release` الفاظ نہیں ہیں۔
            ///
            /// [`Acquire`] کا استعمال اسٹور کو [`Relaxed`] کا اس آپریشن کا حصہ بناتا ہے اگر ایسا ہوتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] ہوجاتا ہے۔
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` اور `compare_exchange_weak` میں منتقل ہورہا ہے
            ///
            /// `compare_and_swap` میموری آرڈرنگ کے ل X مندرجہ ذیل نقشہ سازی کے ساتھ `compare_exchange` کے برابر ہے:
            ///
            /// اصل |کامیابی |ناکامی
            /// -------- | ------- | -------
            /// آرام دہ |آرام دہ |آرام سے حصول |حاصل |حصول کی رہائی |رہائی |آرام دہ ایکقریل |AcqRel |سیکو سسٹ حاصل کریںSeqCst |SeqCst
            ///
            /// `compare_exchange_weak` جب موازنہ کامیاب ہوجاتا ہے تب بھی حوصلہ افزائی سے ناکام ہونے کی اجازت دی جاتی ہے ، جس سے کمپلر بہتر اسمبلی کوڈ تیار کرنے کی اجازت دیتا ہے جب موازنہ اور تبادلہ لوپ میں استعمال ہوتا ہے۔
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// اگر موجودہ قیمت `current` ویلیو جیسا ہی ہے تو کسی قدر کو جوہری اعداد میں جمع کرتا ہے۔
            ///
            /// واپسی کی قیمت ایک نتیجہ ہے جس سے یہ ظاہر ہوتا ہے کہ آیا نئی قیمت لکھی گئی تھی اور اس میں پچھلی قیمت موجود تھی۔
            /// کامیابی پر یہ قیمت `current` کے برابر ہونے کی ضمانت ہے۔
            ///
            /// `compare_exchange` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
            /// `success` ریڈ میڈیفائی رائٹ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جو `current` کے ساتھ موازنہ کامیاب ہوجاتا ہے تو ہوتا ہے۔
            /// `failure` موازنہ ناکام ہونے پر ہونے والے لوڈ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے۔
            /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
            ///
            /// آرڈر کی ناکامی صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// اگر موجودہ قیمت `current` ویلیو جیسا ہی ہے تو کسی قدر کو جوہری اعداد میں جمع کرتا ہے۔
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// موازنہ کامیاب ہونے پر بھی اس فنکشن کو تیزرفتاری سے ناکام ہونے کی اجازت ہے ، جس کے نتیجے میں کچھ پلیٹ فارمز پر زیادہ موثر کوڈ مل سکتا ہے۔
            /// واپسی کی قیمت ایک نتیجہ ہے جس سے یہ ظاہر ہوتا ہے کہ آیا نئی قیمت لکھی گئی تھی اور اس میں پچھلی قیمت موجود تھی۔
            ///
            /// `compare_exchange_weak` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
            /// `success` ریڈ میڈیفائی رائٹ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جو `current` کے ساتھ موازنہ کامیاب ہوجاتا ہے تو ہوتا ہے۔
            /// `failure` موازنہ ناکام ہونے پر ہونے والے لوڈ آپریشن کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے۔
            /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
            ///
            /// آرڈر کی ناکامی صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// چلو mut old= val.load(Ordering::Relaxed)؛
            /// لوپ {new new=Old * 2؛
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } match سے ملائیں
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// موجودہ قدر میں اضافہ ، پچھلی قیمت کو لوٹانا۔
            ///
            /// یہ آپریشن اوور فلو کے گرد لپیٹ جاتا ہے۔
            ///
            /// `fetch_add` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// موجودہ قیمت سے تخفیف ، پچھلی قیمت کو لوٹانا۔
            ///
            /// یہ آپریشن اوور فلو کے گرد لپیٹ جاتا ہے۔
            ///
            /// `fetch_sub` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// موجودہ قدر کے ساتھ بٹ وائی "and"۔
            ///
            /// موجودہ قدر اور دلیل `val` پر تھوڑا سا "and" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر کا تعین کرتا ہے۔
            ///
            /// پچھلی قیمت لوٹاتا ہے۔
            ///
            /// `fetch_and` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// موجودہ قدر کے ساتھ بٹ وائی "nand"۔
            ///
            /// موجودہ قدر اور دلیل `val` پر تھوڑا سا "nand" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر کا تعین کرتا ہے۔
            ///
            /// پچھلی قیمت لوٹاتا ہے۔
            ///
            /// `fetch_nand` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31))؛
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// موجودہ قدر کے ساتھ بٹ وائی "or"۔
            ///
            /// موجودہ قدر اور دلیل `val` پر تھوڑا سا "or" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر کا تعین کرتا ہے۔
            ///
            /// پچھلی قیمت لوٹاتا ہے۔
            ///
            /// `fetch_or` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// موجودہ قدر کے ساتھ بٹ وائی "xor"۔
            ///
            /// موجودہ قدر اور دلیل `val` پر تھوڑا سا "xor" آپریشن انجام دیتا ہے ، اور نتائج کو نئی قدر کا تعین کرتا ہے۔
            ///
            /// پچھلی قیمت لوٹاتا ہے۔
            ///
            /// `fetch_xor` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// قدر لاتا ہے ، اور اس پر ایک فنکشن لاگو ہوتا ہے جو اختیاری نئی ویلیو واپس کرتا ہے۔`Ok(previous_value)` کا `Result` واپس کرتا ہے ، اگر فنکشن `Some(_)` کو واپس کرتا ہے ، ورنہ `Err(previous_value)`۔
            ///
            /// Note: اگر اس دوران اس فنکشن میں X50X کی واپسی ہوتی ہے تو ، اگر اس دوران دیگر دھاگوں سے قدر تبدیل کردی گئی ہو تو یہ فنکشن کو متعدد بار کال کرسکتا ہے ، لیکن فنکشن صرف ایک بار اسٹورڈ ویلیو پر لاگو ہوگا۔
            ///
            ///
            /// `fetch_update` اس آپریشن کی میموری ترتیب کو بیان کرنے کیلئے دو [`Ordering`] دلائل لیتا ہے۔
            /// پہلے آپریشن کے کامیاب ہونے کے لئے مطلوبہ آرڈر کی وضاحت کرتا ہے جبکہ دوسرا بوجھ کے ل for مطلوبہ آرڈرنگ کی وضاحت کرتا ہے۔یہ کامیابی اور ناکامی کے آرڈر کے مساوی ہیں
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] کو کامیابی کے آرڈر کے بطور استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے آخری کامیاب بوجھ [`Relaxed`] ہوجاتا ہے۔
            /// (failed) لوڈ آرڈرنگ صرف [`SeqCst`] ، [`Acquire`] یا [`Relaxed`] ہوسکتی ہے اور کامیابی کے حکم سے مساوی یا کمزور ہونا چاہئے۔
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ترتیب دیتے ہوئے: SeqCst، Ordering::SeqCst، | x | Some(x + 1))، Ok(7));
            /// assert_eq! (x.fetch_update (ترتیب دیتے ہوئے: SeqCst، Ordering::SeqCst، | x | Some(x + 1))، Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// موجودہ قدر کے ساتھ زیادہ سے زیادہ
            ///
            /// زیادہ سے زیادہ موجودہ قدر اور دلیل `val` ڈھونڈتا ہے ، اور نتائج کو نئی قدر متعین کرتا ہے۔
            ///
            /// پچھلی قیمت لوٹاتا ہے۔
            ///
            /// `fetch_max` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// چلو بار=42؛
            /// زیادہ سے زیادہ_فلو=foo.fetch_max (بار ، Ordering::SeqCst).max(bar);
            /// زور! (زیادہ سے زیادہ_==42)؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// کم از کم موجودہ قیمت کے ساتھ۔
            ///
            /// کم از کم موجودہ قدر اور دلیل `val` ڈھونڈتا ہے ، اور نتائج کو نئی قدر متعین کرتا ہے۔
            ///
            /// پچھلی قیمت لوٹاتا ہے۔
            ///
            /// `fetch_min` ایک [`Ordering`] دلیل لیتا ہے جو اس آپریشن کی میموری ترتیب کو بیان کرتا ہے۔آرڈر کرنے کے تمام طریقے ممکن ہیں۔
            /// نوٹ کریں کہ [`Acquire`] کا استعمال اسٹور کو اس آپریشن [`Relaxed`] کا حصہ بناتا ہے ، اور [`Release`] استعمال کرنے سے بوجھ حصہ [`Relaxed`] بن جاتا ہے۔
            ///
            ///
            /// **نوٹ**: یہ طریقہ صرف ان پلیٹ فارمز پر دستیاب ہے جو ایٹم آپریشنز کی حمایت کرتے ہیں
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// چلو بار=12؛
            /// چلیں min_foo=foo.fetch_min (بار ، Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo، 12)؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڈیٹا ریس کو جوہری اندرونی عمل سے روکا جاتا ہے۔
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// مابعد پوائنٹر کو بنیادی انٹیجر پر لوٹاتا ہے۔
            ///
            /// نتیجے میں عدد پر غیر جوہری پڑھنے اور لکھنا کرنا ڈیٹا ریس ہوسکتا ہے۔
            /// یہ طریقہ زیادہ تر FFI کے لئے مفید ہے ، جہاں فعل کے دستخط استعمال کرسکتے ہیں
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// اس جوہری کے مشترکہ حوالہ سے `*mut` پوائنٹر کی واپسی محفوظ ہے کیونکہ جوہری اقسام داخلی تغیر پذیر کے ساتھ کام کرتے ہیں۔
            /// ایک جوہری کی تمام ترامیم مشترکہ حوالہ کے ذریعہ قدر کو بدلتی ہیں ، اور جب تک وہ ایٹمی کارروائیوں کا استعمال کرتے ہیں تو محفوظ طریقے سے کر سکتے ہیں۔
            /// لوٹے ہوئے خام پوائنٹر کے کسی بھی استعمال کے لئے ایک `unsafe` بلاک کی ضرورت ہوتی ہے اور اب بھی اسی پابندی کو برقرار رکھنا پڑتا ہے: اس پر کاروائیاں جوہری ہونی چاہئیں۔
            ///
            ///
            /// # Examples
            ///
            /// 00 `X (extern-declaration) کو نظر انداز کریں
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// بیرونی "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // محفوظ: جب تک کہ `my_atomic_op` جوہری ہے محفوظ ہے۔
            /// غیر محفوظ {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // محفوظ: کال کرنے والے کو `atomic_store` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_load` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_swap` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// پچھلی قیمت (جیسے __ sync_fetch_and_add) لوٹاتا ہے۔
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_add` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// پچھلی قیمت (جیسے __ sync_fetch_and_sub) لوٹاتا ہے۔
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_sub` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // محفوظ: کال کرنے والے کو `atomic_compare_exchange` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // محفوظ: کال کرنے والے کو `atomic_compare_exchange_weak` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_and` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_nand` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_or` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_xor` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// زیادہ سے زیادہ قیمت (دستخط شدہ موازنہ) لوٹاتا ہے
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_max` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// کم سے کم قیمت (دستخط شدہ موازنہ) لوٹاتا ہے
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_min` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// زیادہ سے زیادہ قیمت لوٹاتا ہے (دستخط شدہ موازنہ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_umax` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// کم سے کم قیمت (دستخط شدہ موازنہ) لوٹاتا ہے
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // محفوظ: کال کرنے والے کو `atomic_umin` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// ایک ایٹم باڑ
///
/// مخصوص آرڈر پر منحصر ہے ، باڑ کمپائلر اور سی پی یو کو اپنے ارد گرد کی کچھ خاص قسم کی میموری کو دوبارہ ترتیب دینے سے روکتی ہے۔
/// جو اس کے اور دوسرے دھاگوں میں جوہری کارروائیوں یا باڑ کے مابین ہم آہنگی پیدا کرتا ہے۔
///
/// ایک باڑ 'A' جس میں (کم سے کم) [`Release`] آرڈرنٹ سیمنٹکس ہے ، باڑ 'B' کے ساتھ ہم آہنگی پیدا کرتا ہے (کم از کم) [`Acquire`] سیمنٹکس کے ساتھ ، اگر اور صرف وہاں موجود ہے تو X اور Y ، دونوں کچھ ایٹم آبجیکٹ 'M' پر چلتے ہیں جیسے کہ پہلے ترتیب دیا گیا ہو X ، Y کو مطابقت پذیر بنائے جانے سے پہلے B اور Y M میں تبدیلی کا مشاہدہ کریں
/// یہ A اور B کے درمیان وقتا فوقتا انحصار فراہم کرتا ہے۔
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] یا [`Acquire`] سیمنٹکس کے ساتھ جوہری آپریشن بھی باڑ کے ساتھ ہم آہنگ ہوسکتے ہیں۔
///
/// ایک باڑ جس میں [`SeqCst`] آرڈرنگ ہے ، [`Acquire`] اور [`Release`] سیمنٹکس دونوں ہونے کے علاوہ ، دوسرے [`SeqCst`] کاموں اور/یا باڑ کے عالمی پروگرام آرڈر میں بھی حصہ لیتا ہے۔
///
/// [`Acquire`] ، [`Release`] ، [`AcqRel`] اور [`SeqCst`] آرڈرنگز کو قبول کرتا ہے۔
///
/// # Panics
///
/// Panics اگر `order` [`Relaxed`] ہے۔
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // اسپن لاک پر مبنی باہمی اخراج کو آدم۔
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // جب تک پرانی قدر `false` نہ ہو تب تک انتظار کریں۔
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // یہ باڑ `unlock` میں اسٹور کے ساتھ مطابقت پذیر ہے۔
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // حفاظت: جوہری باڑ کا استعمال محفوظ ہے۔
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// ایک مرتب میموری باڑ
///
/// `compiler_fence` کسی بھی مشین کوڈ کو خارج نہیں کرتا ہے ، لیکن اس قسم کی میموری پر پابندی لگاتا ہے جس کے مرتب کرنے والے کو دوبارہ ترتیب دینے کا حکم دیا جاتا ہے۔خاص طور پر ، دیئے گئے [`Ordering`] الفاظ کی بنیاد پر ، `compiler_fence` پر کال کے پہلے یا بعد میں کال سے پہلے یا اس کے بعد لکھنے والے کو پڑھنے یا تحریری حرکت سے مرتب کرنے سے انکار کیا جاسکتا ہے۔نوٹ کریں کہ یہ **نہیں***ہارڈ ویئر* کو اس طرح کے آرڈر کرنے سے روکتا ہے۔
///
/// یہ ایک ہی تھریڈڈ ، عملدرآمد کے سیاق و سباق میں کوئی مسئلہ نہیں ہے ، لیکن جب دوسرے دھاگے بیک وقت میموری کو تبدیل کرسکتے ہیں تو ، مضبوط ہم آہنگی کے قدیم جیسے [`fence`] کی ضرورت ہوتی ہے۔
///
/// دوبارہ ترتیب دینے والے الفاظ مختلف آرڈر والے سامنتکس کے ذریعہ روکے گئے ہیں۔
///
///  - [`SeqCst`] کے ساتھ ، اس نقطہ پر پڑھنے اور لکھنے کو دوبارہ ترتیب دینے کی اجازت نہیں ہے۔
///  - [`Release`] کے ساتھ ، پچھلا پڑھنے اور لکھنے کو ماضی کے بعد کی تحریروں میں منتقل نہیں کیا جاسکتا ہے۔
///  - [`Acquire`] کے ساتھ ، بعد میں پڑھنے اور لکھنے کو سابقہ پڑھنے سے آگے نہیں بڑھایا جاسکتا۔
///  - [`AcqRel`] کے ساتھ ، مذکورہ بالا دونوں قواعد نافذ ہیں۔
///
/// `compiler_fence` عام طور پر صرف ایک دھاگے کو * اپنے ساتھ دوڑنے سے روکنے کے لئے مفید ہے۔یعنی ، اگر دیئے گئے دھاگے کوڈ کے ایک ٹکڑے کو پھانسی دے رہے ہیں ، اور پھر اس میں خلل پڑتا ہے ، اور کہیں اور کوڈ پر عمل درآمد شروع ہوجاتا ہے (جبکہ اسی تھریڈ میں ابھی بھی ہے ، اور نظریاتی طور پر اب بھی اسی کور پر)۔روایتی پروگراموں میں ، یہ تب ہی ہوسکتا ہے جب سگنل ہینڈلر رجسٹرڈ ہو۔
/// زیادہ نچلی سطح کے کوڈ میں ، مداخلتوں سے نمٹنے کے دوران ، جب پہلے سے سبز دھاگوں کے ساتھ گرین تھریڈز نافذ کرنا وغیرہ بھی پیدا ہوسکتے ہیں۔
/// متجسس قارئین کو Linux دانا کی [memory barriers] کی مباحثہ پڑھنے کی ترغیب دی جاتی ہے۔
///
/// # Panics
///
/// Panics اگر `order` [`Relaxed`] ہے۔
///
/// # Examples
///
/// `compiler_fence` کے بغیر ، مندرجہ ذیل کوڈ میں موجود `assert_eq!` ایک ہی دھاگے میں سب کچھ ہونے کے باوجود ، کامیابی کی ضمانت نہیں *ہے*۔
/// کیوں دیکھنے کے ل remember ، یاد رکھیں کہ مرتب اسٹورز کو `IMPORTANT_VARIABLE` اور `IS_READ` میں تبدیل کرنے کے لئے آزاد ہے کیونکہ وہ دونوں ہی `Ordering::Relaxed` ہیں۔اگر ایسا ہوتا ہے ، اور `IS_READY` کی تازہ کاری کے فورا بعد ہی سگنل ہینڈلر کو طلب کیا گیا ہے ، تو سگنل ہینڈلر `IS_READY=1` ، لیکن `IMPORTANT_VARIABLE=0` دیکھے گا۔
/// اس صورتحال میں `compiler_fence` علاج کا استعمال کریں۔
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // پہلے کی تحریروں کو اس مقام سے آگے بڑھنے سے روکیں
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // حفاظت: جوہری باڑ کا استعمال محفوظ ہے۔
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// پروسیسر کو اشارہ کرتا ہے کہ یہ ایک مصروف انتظار اسپن لوپ ("اسپن لاک") کے اندر ہے۔
///
/// یہ فنکشن [`hint::spin_loop`] کے حق میں فرسودہ ہے۔
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}