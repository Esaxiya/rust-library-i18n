use crate::iter::FromIterator;

/// ایک یونٹر سے تمام یونٹ اشیاء کو ایک میں بدل دیتا ہے۔
///
/// یہ زیادہ کارآمد ہے جب اعلی سطحی تجریدوں کے ساتھ مل کر ، جیسے `Result<(), E>` پر اکٹھا کرنا جہاں آپ صرف غلطیوں کا خیال رکھتے ہو:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}