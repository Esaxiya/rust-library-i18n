use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// اگرچہ یہ فنکشن ایک جگہ پر استعمال کیا جاتا ہے اور اس پر عمل درآمد کیا جاسکتا ہے ، لیکن ایسا کرنے کی سابقہ کوششوں نے زیڈ ٹرسٹ0 زیڈ کو آہستہ کردیا۔
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// میموری کے ایک بلاک کی ترتیب.
///
/// `Layout` کی ایک مثال میموری کی ایک خاص ترتیب کو بیان کرتی ہے۔
/// آپ ایک مختص کنندہ کو دینے کے لئے ایک ان پٹ کے بطور ایک `Layout` تیار کرتے ہیں۔
///
/// تمام ترتیب میں ایک وابستہ سائز اور پاور ٹو ٹو سیدھ ہے۔
///
/// (نوٹ کریں کہ لے آؤٹ *غیر صفر سائز کی ضرورت نہیں* ہیں ، حالانکہ `GlobalAlloc` کا تقاضا ہے کہ میموری کی تمام درخواستوں کا سائز غیر صفر ہونا چاہئے۔
/// ایک کال کرنے والے کو یا تو یقینی بنانا چاہئے کہ اس طرح کے حالات پورے ہو گئے ہیں ، کھوئے ہوئے تقاضوں کے ساتھ مخصوص مختص کاروں کا استعمال کریں ، یا زیادہ نرم `Allocator` انٹرفیس استعمال کریں۔)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // بائٹس میں ماپا میموری کی درخواست کردہ بلاک کا سائز۔
    size_: usize,

    // بائٹس میں ماپا میموری کے مطلوبہ بلاک کی سیدھ۔
    // ہم اس بات کو یقینی بناتے ہیں کہ یہ ہمیشہ ایک طاقت کا مقابلہ ہوتا ہے ، کیوں کہ API کی طرح `posix_memalign` کو اس کی ضرورت ہوتی ہے اور لے آؤٹ تعمیر کرنے والوں پر تھوپنا مناسب پابندی ہے۔
    //
    //
    // (تاہم ، ہمیں یکساں طور پر `سیدھ>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) کی ضرورت نہیں ہے
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// ایک دیئے گئے `size` اور `align` سے `Layout` بناتا ہے ، یا اگر مندرجہ ذیل شرائط میں سے کسی کو پورا نہیں کیا گیا تو `LayoutError` واپس کرتا ہے:
    ///
    /// * `align` صفر نہیں ہونا چاہئے ،
    ///
    /// * `align` دو کی طاقت ہونا چاہئے ،
    ///
    /// * `size`, جب `align` کے قریبی ایک سے زیادہ تک گول ہوجائے تو ، اتنا زیادہ بہاو نہیں ہونا چاہئے (یعنی ، گول قیمت `usize::MAX` سے کم یا اس کے برابر ہونی چاہئے)۔
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (بجلی سے دو کا مطلب سیدھ میں ہے!=0.)

        // گول سائز ہے:
        //   سائز_گراونڈ_پ=(سائز + سیدھ ، 1)&! (سیدھ کریں ، 1)؛
        //
        // ہم اوپر سے جانتے ہیں کہ سیدھ میں!=0
        // اگر شامل کریں (سیدھ کریں ، 1) اتپرواہ نہیں ہوتا ہے تو ، پھر گول کرنا ٹھیک ہوگا۔
        //
        // اس کے برعکس ، اور ساتھ بنانا! (سیدھ کریں ، 1) صرف کم آرڈر والے بٹس کو ہی منہا کرے گا۔
        // اس طرح اگر اوور فلو جوہر کے ساتھ ہوتا ہے تو ،&ماسک اس اوور فلو کو کالعدم کرنے کے لئے کافی گھٹا نہیں کر سکتا۔
        //
        //
        // مذکورہ بالا مطلب یہ ہے کہ چوٹیوں کے اوور فلو کی جانچ پڑتال ضروری اور کافی ہے۔
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // محفوظ کریں: `from_size_align_unchecked` کے لئے حالات ہیں
        // اوپر جانچ پڑتال
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// تمام چیکوں کو نظرانداز کرکے ، ایک ترتیب تیار کرتا ہے۔
    ///
    /// # Safety
    ///
    /// یہ فنکشن غیر محفوظ ہے کیونکہ یہ [`Layout::from_size_align`] سے پیشگی شرائط کی تصدیق نہیں کرتا ہے۔
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // محفوظ: کال کرنے والے کو یہ یقینی بنانا ہوگا کہ `align` صفر سے زیادہ ہے۔
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// اس لے آؤٹ کے میموری بلاک کیلئے بائٹس میں کم از کم سائز۔
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// اس لے آؤٹ کے میموری بلاک کیلئے کم از کم بائٹ سیدھ۔
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// قسم `T` کی قدر رکھنے کے لئے موزوں ایک `Layout` بناتا ہے۔
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // حفاظت: سیدھ کی ضمانت Rust کے ذریعہ دو اور کی طاقت ہے
        // سائز + سیدھ کریں طومار ہمارے ایڈریس اسپیس میں فٹ ہونے کی ضمانت ہے۔
        // اس کے نتیجے میں یہاں غیر چیک شدہ کنسٹرکٹر کا استعمال کریں تاکہ کوڈ داخل کرنے سے گریز کریں کہ panics اگر یہ کافی حد تک بہتر نہیں ہے۔
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ایک ایسے ریکارڈ کی وضاحت کرنے کی ترتیب تیار کرتا ہے جو `T` (جو trait یا کسی سلائس کی طرح کی دوسری غیر منقسم قسم کی ہوسکتی ہے) کیلئے بیکنگ ڈھانچہ مختص کرنے کے لئے استعمال ہوسکتی ہے۔
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // محفوظ کریں: `new` میں عقلیت دیکھیں کہ یہ غیر محفوظ قسم کو کیوں استعمال کررہا ہے
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ایک ایسے ریکارڈ کی وضاحت کرنے کی ترتیب تیار کرتا ہے جو `T` (جو trait یا کسی سلائس کی طرح کی دوسری غیر منقسم قسم کی ہوسکتی ہے) کیلئے بیکنگ ڈھانچہ مختص کرنے کے لئے استعمال ہوسکتی ہے۔
    ///
    /// # Safety
    ///
    /// اگر یہ کام مندرجہ ذیل شرائط میں ہیں تو یہ فون صرف محفوظ ہے:
    ///
    /// - اگر `T` `Sized` ہے تو ، یہ فعل کال کرنے کے لئے ہمیشہ محفوظ ہے۔
    /// - اگر `T` کی غیر تسلیم شدہ دم ہے:
    ///     - [slice] ، پھر سلائس دم کی لمبائی ایک انٹلیٹائزڈ انٹیجر ہونا چاہئے ، اور *پوری ویلیو*(متحرک دم کی لمبائی + مستحکم سائز کا سابقہ) کا سائز `isize` میں فٹ ہونا چاہئے۔
    ///     - ایک [trait object] ، پھر پوائنٹر کے ویٹیبل حصے کو کسی غیر تسخیر کڑن کے ذریعہ حاصل کردہ `T` قسم کے لئے ایک درست vtable کی طرف اشارہ کرنا چاہئے ، اور *پوری ویلیو*(متحرک دم کی لمبائی + مستحکم سائز کا سابقہ) `isize` میں فٹ ہونا چاہئے۔
    ///
    ///     - ایک (unstable) [extern type] ، پھر یہ فنکشن ہمیشہ کال کرنے کے لئے محفوظ ہے ، لیکن panic یا دوسری صورت میں غلط قدر واپس کرسکتا ہے ، کیونکہ بیرونی قسم کی ترتیب معلوم نہیں ہے۔
    ///     بیرونی قسم کی دم کے حوالہ سے یہ وہی سلوک ہے جو [`Layout::for_value`] ہے۔
    ///     - بصورت دیگر ، اسے قدامت پسندی سے اس فنکشن کو فون کرنے کی اجازت نہیں ہے۔
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // حفاظت: ہم ان افعال کی لازمی شرائط کے ساتھ کال کرنے والے کو منتقل کرتے ہیں
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // محفوظ کریں: `new` میں عقلیت دیکھیں کہ یہ غیر محفوظ قسم کو کیوں استعمال کررہا ہے
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ایک ایسا `NonNull` بناتا ہے جو گھٹا ہوا ہوتا ہے ، لیکن اس لے آؤٹ کے لئے اچھی طرح سے منسلک ہوتا ہے۔
    ///
    /// نوٹ کریں کہ پوائنٹر ویلیو ممکنہ طور پر درست پوائنٹر کی نمائندگی کرسکتی ہے ، جس کا مطلب ہے کہ اسے "not yet initialized" سینٹینل ویلیو کے طور پر استعمال نہیں کرنا چاہئے۔
    /// ان اقسام کو جو بتدریج سے مختص کرتے ہیں ان کو کسی اور ذرائع سے ابتداء کو ٹریک کرنا چاہئے
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // سلامتی: سیدھ میں صفر نہ ہونے کی ضمانت ہے
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// ریکارڈ کی وضاحت کرنے والا ایک ایسا نمونہ بناتا ہے جس میں `self` جیسی ہی ترتیب کی قدر ہوسکتی ہے ، لیکن یہ بھی `align` (بائٹ میں ماپا) سیدھ میں لانا ہے۔
    ///
    ///
    /// اگر `self` پہلے ہی تجویز کردہ سیدھ کو پورا کرتا ہے ، تو `self` واپس کردیتی ہے۔
    ///
    /// نوٹ کریں کہ یہ طریقہ مجموعی سائز میں کوئی بھرتی نہیں جوڑتا ہے ، قطع نظر اس سے قطع نظر کہ لوٹائے ہوئے ترتیب میں ایک سیدھ میں ایک سیدھ ہے۔
    /// دوسرے الفاظ میں ، اگر `K` کا سائز 16 ہے ، تو `K.align_to(32)`*پھر بھی* سائز 16 میں ہوگا۔
    ///
    /// اگر `self.size()` اور دیئے گئے `align` کا مجموعہ [`Layout::from_size_align`] میں درج حالات کی خلاف ورزی کرتا ہے تو خرابی واپس کرتا ہے۔
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// اس بات کا یقین کرنے کے لئے کہ `self` کے بعد ہمیں بھرنے والی بھرتی کی مقدار واپس کردے گی تاکہ مندرجہ ذیل پتے `align` کو پورا کرے گا (بائٹس میں ماپا)۔
    ///
    /// مثال کے طور پر ، اگر `self.size()` 9 ہے ، تو `self.padding_needed_for(4)` 3 لوٹاتا ہے ، کیونکہ یہ 4 منسلک ایڈریس حاصل کرنے کے لئے درکار کم بائٹس کی کم سے کم تعداد ہے (یہ فرض کرتے ہوئے کہ یہ اسی میموری بلاک 4 منسلک پتے سے شروع ہوتا ہے)۔
    ///
    ///
    /// اگر `align` دو سے طاقت نہیں ہے تو اس فنکشن کی واپسی کی قیمت کا کوئی معنی نہیں ہے۔
    ///
    /// نوٹ کریں کہ لوٹی گئی قیمت کی افادیت کے لئے `align` کی ضرورت ہوتی ہے کہ میموری کے پورے مختص کردہ بلاک کے لئے ابتدائی پتے کی سیدھ میں برابر یا برابر ہو۔اس رکاوٹ کو پورا کرنے کا ایک طریقہ `align <= self.align()` کو یقینی بنانا ہے۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // گول قیمت ہے:
        //   len_rounded_up=(لین + سیدھ کریں ، 1)&! (سیدھ کریں ، 1)؛
        // اور پھر ہم بھرتے ہوئے فرق کو واپس کریں گے۔ `len_rounded_up - len`.
        //
        // ہم ماڈیولر ریاضی میں بھر میں استعمال کرتے ہیں:
        //
        // 1. سیدھ میں 0 کی ضمانت دی جاتی ہے ، لہذا سیدھ کریں ، 1 ہمیشہ درست ہے۔
        //
        // 2.
        // `len + align - 1` زیادہ سے زیادہ `align - 1` پر بہہ سکتا ہے ، لہذا `!(align - 1)` والا&ماسک اس بات کو یقینی بنائے گا کہ اوور فلو کی صورت میں ، `len_rounded_up` خود 0 ہو گا۔
        //
        //    اس طرح واپس شدہ بھرتی ، جب X0 X میں شامل ہوجائے تو ، 0 ملتا ہے ، جو سیدھے `align` کو مطمئن کرتا ہے۔
        //
        // (یقینا ، میموری کے بلاکس کو مختص کرنے کی کوششیں جن کے سائز اور پیڈنگ کا بہاؤ اوپر کے انداز میں ہوتا ہے اس وجہ سے تقسیم کار کو ویسے بھی غلطی پیدا ہوجاتی ہے۔)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// اس ترتیب کے سائز کو لے آؤٹ کی سیدھ میں لانے کے ل multiple ایک سے زیادہ تک گول بناتے ہوئے ایک ترتیب بناتا ہے۔
    ///
    ///
    /// یہ ترتیب کے موجودہ سائز میں `padding_needed_for` کا نتیجہ شامل کرنے کے مترادف ہے۔
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // یہ اتپرواہ نہیں ہوسکتا۔حملہ آور سے لے آؤٹ:
        // > `size`, جب `align` کے قریبی ایک سے زیادہ تک گول ہوجاتا ہے ،
        // > اتپرواہ نہیں ہونا چاہئے (یعنی گول گول قیمت سے کم ہونا چاہئے
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` کے `n` مثال کے ریکارڈ کو بیان کرنے کا ایک نمونہ بناتا ہے ، جس میں ہر ایک کے مابین مناسب مقدار میں بھرنے کے لئے یہ یقینی بناتا ہے کہ ہر مثال کو اس کی درخواست کردہ سائز اور سیدھ دی گئی ہے۔
    /// کامیابی پر ، `(k, offs)` واپس کرتا ہے جہاں `k` سرنی کی ترتیب ہے اور `offs` سرنی میں ہر عنصر کے آغاز کے درمیان فاصلہ ہے۔
    ///
    /// ریاضی کے اوور فلو پر ، `LayoutError` لوٹاتا ہے۔
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // یہ اتپرواہ نہیں ہوسکتا۔حملہ آور سے لے آؤٹ:
        // > `size`, جب `align` کے قریبی ایک سے زیادہ تک گول ہوجاتا ہے ،
        // > اتپرواہ نہیں ہونا چاہئے (یعنی گول گول قیمت سے کم ہونا چاہئے
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // محفوظ: self.align پہلے سے ہی جائز ہے اور الاٹ_سائز رہا ہے
        // پہلے سے ہی بولڈ
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` کے ریکارڈ کی وضاحت کرتے ہوئے ایک ایسی ترتیب تیار کرتا ہے جس کے بعد `next` ہوتا ہے ، جس میں اس بات کا یقین کرنے کے لئے کہ کوئی ضروری پیڈنگ بھی شامل ہو کہ `next` مناسب طریقے سے منسلک ہوجائے گا ، لیکن *پچھلے حصے نہیں*۔
    ///
    /// سی نمائندگی کی ترتیب `repr(C)` سے مماثلت کرنے کے ل order ، آپ کو تمام فیلڈز کے ساتھ لے آؤٹ میں توسیع کرنے کے بعد `pad_to_align` پر فون کرنا چاہئے۔
    /// (پہلے سے طے شدہ Rust نمائندگی کی ترتیب `repr(Rust)`, as it is unspecified.) سے ملنے کا کوئی طریقہ نہیں ہے
    ///
    /// نوٹ کریں کہ دونوں حصوں کی سیدھ کو یقینی بنانے کے ل the نتیجے میں ترتیب کی ترتیب `self` اور `next` کی زیادہ سے زیادہ ہوگی۔
    ///
    /// `Ok((k, offset))` واپس کرتا ہے ، جہاں `k` جمع شدہ ریکارڈ کا خاکہ ہے اور `offset` باضابطہ مقام میں ، `next` کے آغاز کا جوڑا ہوا ریکارڈ کے اندر سرایت شدہ ہے (یہ فرض کرکے کہ ریکارڈ خود آفسیٹ 0 سے شروع ہوتا ہے)۔
    ///
    ///
    /// ریاضی کے اوور فلو پر ، `LayoutError` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ایک `#[repr(C)]` ڈھانچے کی ترتیب اور اس کے کھیتوں کی ترتیب سے کھیتوں کی آفسیٹ کا حساب لگانے کے لئے:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` کے ساتھ حتمی شکل دینا یاد رکھیں!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // یہ کام کرتا ہے کہ ٹیسٹ
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` کے `n` مثالوں کے ریکارڈ کی وضاحت کرنے والا ایک ایسا نمونہ بناتا ہے ، جس میں ہر مثال کے درمیان کوئی گنجائش نہیں ہوتی ہے۔
    ///
    /// نوٹ کریں کہ ، `repeat` کے برعکس ، `repeat_packed` اس بات کی ضمانت نہیں دیتا ہے کہ `self` کی بار بار مثالوں کو مناسب طریقے سے منسلک کیا جائے گا ، یہاں تک کہ اگر `self` کی دی گئی مثال مناسب طور پر منسلک ہو۔
    /// دوسرے لفظوں میں ، اگر `repeat_packed` کی طرف سے واپس کردہ ترتیب کسی سرنی کو مختص کرنے کے لئے استعمال کیا جاتا ہے تو ، اس بات کی ضمانت نہیں ہے کہ صف میں موجود تمام عناصر کو صحیح طریقے سے منسلک کیا جائے گا۔
    ///
    /// ریاضی کے اوور فلو پر ، `LayoutError` لوٹاتا ہے۔
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` کے ریکارڈ کی وضاحت کرنے والا ایک ایسا نمونہ بناتا ہے جس کے بعد `next` کے بعد ان دونوں کے درمیان کوئی اضافی گنجائش نہیں ہوتی ہے۔
    /// چونکہ کوئی بھرتی نہیں ڈالی جاتی ہے ، لہذا `next` کی سیدھ غیر متعلقہ ہے ، اور اس کو نتیجہ خاکہ میں *بالکل* شامل نہیں کیا جاتا ہے۔
    ///
    ///
    /// ریاضی کے اوور فلو پر ، `LayoutError` لوٹاتا ہے۔
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` کے ریکارڈ کو بیان کرنے والی ایک ترتیب تیار کرتا ہے۔
    ///
    /// ریاضی کے اوور فلو پر ، `LayoutError` لوٹاتا ہے۔
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` یا کسی اور `Layout` کنسٹرکٹر کو دیئے گئے پیرامیٹرز اس کی دستاویزی رکاوٹوں کو پورا نہیں کرتے ہیں۔
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait غلطی کو بہاو بنانے کے لئے ہمیں اس کی ضرورت ہے)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}