//! میموری مختص APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` کی خرابی ایک مختص کی ناکامی کی نشاندہی کرتی ہے جو اس مختص کنندہ کے ساتھ دیئے گئے ان پٹ دلائل کو جوڑتے وقت وسائل کی تھکن یا کسی غلط چیز کی وجہ سے ہوسکتی ہے۔
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (trait غلطی کو بہاو بنانے کے لئے ہمیں اس کی ضرورت ہے)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` کا نفاذ [`Layout`][] کے ذریعہ بیان کردہ اعداد و شمار کے غیر منطقی بلاکس کو مختص ، بڑھا ، سکڑ اور ختم کرسکتا ہے۔
///
/// `Allocator` ZSTs ، حوالہ جات ، یا سمارٹ پوائنٹرز پر نفاذ کے لئے ڈیزائن کیا گیا ہے کیونکہ `MyAlloc([u8; N])` جیسے مختص کرنے والے کو منتقل نہیں کیا جاسکتا ، بغیر پوائنٹس کو مختص شدہ میموری میں تازہ کاری کیے۔
///
/// [`GlobalAlloc`][] کے برعکس ، `Allocator` میں صفر سائز کے مختص کرنے کی اجازت ہے۔
/// اگر ایک بنیادی مختص کرنے والا اس کی حمایت نہیں کرتا ہے (جیمالوک کی طرح) یا کوئی کالا پوائنٹر (جیسے `libc::malloc`) واپس نہیں کرتا ہے تو ، اس کو عمل درآمد سے پکڑ لیا جانا چاہئے۔
///
/// ### فی الحال میموری مختص کی گئی ہے
///
/// کچھ طریقوں کا تقاضا ہے کہ ایک میموری بلاک *فی الحال مختص* مختص کنندگان کے ذریعہ کیا جائے۔اس کا مطلب ہے کہ:
///
/// * اس میموری بلاک کا ابتدائی پتہ پہلے [`allocate`] ، [`grow`] ، یا [`shrink`] ، اور کے ذریعہ واپس کیا گیا تھا
///
/// * بعد میں میموری بلاک کو غیر موزوں نہیں کیا گیا ہے ، جہاں بلاکس کو یا تو [`deallocate`] پر منتقل کرکے [`grow`] یا [`shrink`] میں منتقل کرکے تبدیل کردیا گیا تھا جو `Ok` کو واپس کرتا ہے۔
///
/// اگر `grow` یا `shrink` نے `Err` کو لوٹا دیا ہے تو ، منظور شدہ پوائنٹر درست رہتا ہے۔
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### میموری فٹنگ
///
/// کچھ طریقوں میں یہ ضروری ہوتا ہے کہ ایک ترتیب *فٹ* میموری بلاک کو فٹ کرے۔
/// "fit" کے کسی ترتیب کے ل block اس کا کیا مطلب ہے میموری بلاک کا مطلب ہے (یا اس کے مساوی طور پر ، میموری بلاک کے لئے "fit" کو لے آؤٹ) ایک ترتیب یہ ہے کہ درج ذیل شرائط لازمی ہیں۔
///
/// * [`layout.align()`] اور اسی ترتیب کے ساتھ بلاک مختص کیا جانا چاہئے
///
/// * فراہم کردہ [`layout.size()`] رینج `min ..= max` میں ہونا چاہئے ، جہاں:
///   - `min` اس ترتیب کا سائز ہے جو حال ہی میں اس بلاک کو مختص کرنے کے لئے استعمال کیا جاتا ہے ، اور
///   - `max` [`allocate`] ، [`grow`] ، یا [`shrink`] سے لوٹا ہوا تازہ ترین اصل سائز ہے۔
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * مختص کنندگان سے واپس آئے میموری بلاکس کو درست میموری کی طرف اشارہ کرنا چاہئے اور مثال کے طور پر اور اس کے تمام کلون گرانے تک ان کی صداقت برقرار رکھنی چاہئے ،
///
/// * کلوننگ یا مختص کرنے والے کو منتقل کرنے والے کو اس مختص کنندہ سے واپس کردہ میموری بلاکس کو غلط نہیں کرنا چاہئے۔ایک کلونڈ مختص کرنے والے کو ایک ہی مختص کرنے والے کی طرح برتاؤ کرنا چاہئے ، اور
///
/// * میموری بلاک کی طرف اشارہ کرنے والا کوئی بھی جو [*currently allocated*] ہے مختص کرنے والے کے کسی دوسرے طریقے میں منتقل کیا جاسکتا ہے۔
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// میموری کا ایک بلاک مختص کرنے کی کوششیں۔
    ///
    /// کامیابی پر ، `layout` کی سائز اور سیدھ کی ضمانتوں کو پورا کرتے ہوئے ایک `layout` واپس کرتا ہے۔
    ///
    /// واپس کردہ بلاک میں `layout.size()` کے ذریعہ بیان کردہ سے کہیں زیادہ سائز ہوسکتا ہے ، اور ہوسکتا ہے کہ اس کے مشمولات کا آغاز نہ ہو۔
    ///
    /// # Errors
    ///
    /// `Err` کی واپسی سے یہ ظاہر ہوتا ہے کہ یا تو میموری ختم ہوچکی ہے یا `layout` مختص کرنے والے کے سائز یا سیدھ کی رکاوٹوں کو پورا نہیں کرتا ہے۔
    ///
    /// نفاذ کو گھبرانے یا اسقاط حمل کرنے کی بجائے میموری تھکن پر `Err` واپس کرنے کی ترغیب دی جاتی ہے ، لیکن یہ کوئی سخت ضرورت نہیں ہے۔
    /// (خاص طور پر: اس trait کو ایک بنیادی آبائی الاٹریری لائبریری کے اوپر جو عملی طور پر میموری ختم ہونے پر ختم ہوتا ہے ، نافذ کرنا * قانونی ہے۔)
    ///
    /// مختص کی غلطی کے جواب میں کمپیوٹیشن اسقاط کو ختم کرنے کے خواہش مند مؤکلوں کو براہ راست `panic!` یا اس سے ملنے کی بجائے [`handle_alloc_error`] فنکشن کو فون کرنے کی ترغیب دی جاتی ہے۔
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` کی طرح برتاؤ کرتا ہے ، بلکہ یہ بھی یقینی بناتا ہے کہ لوٹی ہوئی میموری صفر-ابتدا کی ہے۔
    ///
    /// # Errors
    ///
    /// `Err` کی واپسی سے یہ ظاہر ہوتا ہے کہ یا تو میموری ختم ہوچکی ہے یا `layout` مختص کرنے والے کے سائز یا سیدھ کی رکاوٹوں کو پورا نہیں کرتا ہے۔
    ///
    /// نفاذ کو گھبرانے یا اسقاط حمل کرنے کی بجائے میموری تھکن پر `Err` واپس کرنے کی ترغیب دی جاتی ہے ، لیکن یہ کوئی سخت ضرورت نہیں ہے۔
    /// (خاص طور پر: اس trait کو ایک بنیادی آبائی الاٹریری لائبریری کے اوپر جو عملی طور پر میموری ختم ہونے پر ختم ہوتا ہے ، نافذ کرنا * قانونی ہے۔)
    ///
    /// مختص کی غلطی کے جواب میں کمپیوٹیشن اسقاط کو ختم کرنے کے خواہش مند مؤکلوں کو براہ راست `panic!` یا اس سے ملنے کی بجائے [`handle_alloc_error`] فنکشن کو فون کرنے کی ترغیب دی جاتی ہے۔
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // محفوظ: `alloc` ایک درست میموری بلاک واپس کرتا ہے
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` کے ذریعہ حوالہ کردہ میموری کو خارج کردیتے ہیں۔
    ///
    /// # Safety
    ///
    /// * `ptr` اس مختص کنندہ کے ذریعہ میموری [*currently allocated*] کے ایک بلاک کو واضح کرنا ضروری ہے ، اور
    /// * `layout` میموری کو مسدود کرنا چاہئے [*fit*].
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// میموری بلاک کو بڑھانے کی کوششیں۔
    ///
    /// ایک نیا [`NonNull<[u8]>`][NonNull] لوٹاتا ہے جس میں ایک پوائنٹر اور مختص شدہ میموری کا اصل سائز ہوتا ہے۔پوائنٹر `new_layout` کے ذریعہ بیان کردہ ڈیٹا کے انعقاد کے لئے موزوں ہے۔
    /// اس کو پورا کرنے کے لئے ، مختص کنندہ `ptr` کے ذریعہ مختص رقم کو نئی ترتیب میں فٹ ہونے کے لئے بڑھا سکتا ہے۔
    ///
    /// اگر یہ `Ok` کو لوٹاتا ہے ، تو `ptr` کے ذریعہ حوالہ کردہ میموری بلاک کی ملکیت اس مختص کرنے والے کو منتقل کردی گئی ہے۔
    /// میموری آزاد ہوسکتی ہے یا نہیں ، اور اسے ناقابل استعمال سمجھا جانا چاہئے جب تک کہ اس طریقے کی واپسی قیمت کے ذریعے اسے دوبارہ کال کرنے والے کے پاس منتقل نہ کیا جائے۔
    ///
    /// اگر یہ طریقہ کار `Err` کو لوٹاتا ہے تو پھر میموری بلاک کی ملکیت اس مختص کرنے والے کو منتقل نہیں کی گئی ہے ، اور میموری بلاک کے مندرجات کو غیر تبدیل شدہ کردیا گیا ہے۔
    ///
    /// # Safety
    ///
    /// * `ptr` اس مختص کنندہ کے ذریعہ میموری [*currently allocated*] کے بلاک کو واضح کرنا چاہئے۔
    /// * `old_layout` میموری کو روکنے والے [*fit*] کو لازمی طور پر (`new_layout` دلیل کو اس کے فٹ ہونے کی ضرورت نہیں ہے۔)
    /// * `new_layout.size()` `old_layout.size()` سے زیادہ یا اس کے برابر ہونا چاہئے۔
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// اگر نیا ترتیب مختص کرنے والے کے سائز اور سیدھ کی سیدھ کو پورا نہیں کرتا ہے ، یا اگر دوسری صورت میں بڑھتا ہے تو ناکام ہوجاتا ہے تو `Err` واپس کرتا ہے۔
    ///
    /// نفاذ کو گھبرانے یا اسقاط حمل کرنے کی بجائے میموری تھکن پر `Err` واپس کرنے کی ترغیب دی جاتی ہے ، لیکن یہ کوئی سخت ضرورت نہیں ہے۔
    /// (خاص طور پر: اس trait کو ایک بنیادی آبائی الاٹریری لائبریری کے اوپر جو عملی طور پر میموری ختم ہونے پر ختم ہوتا ہے ، نافذ کرنا * قانونی ہے۔)
    ///
    /// مختص کی غلطی کے جواب میں کمپیوٹیشن اسقاط کو ختم کرنے کے خواہش مند مؤکلوں کو براہ راست `panic!` یا اس سے ملنے کی بجائے [`handle_alloc_error`] فنکشن کو فون کرنے کی ترغیب دی جاتی ہے۔
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // محفوظ کریں: کیونکہ `new_layout.size()` اس سے زیادہ یا اس کے برابر ہونا چاہئے
        // `old_layout.size()`, پرانی اور نئی دونوں میموری مختص `old_layout.size()` بائٹس کے لئے پڑھنے اور لکھتے ہیں۔
        // نیز ، کیونکہ پرانی الاٹمنٹ ابھی تک ختم نہیں ہوئی تھی ، لہذا یہ `new_ptr` کو اوورلیپ نہیں کرسکتی ہے۔
        // اس طرح ، `copy_nonoverlapping` پر کال محفوظ ہے۔
        // کال کرنے والے کے ذریعہ `dealloc` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` کی طرح برتاؤ کرتا ہے ، بلکہ اس بات کو بھی یقینی بناتا ہے کہ واپس آنے سے پہلے نئے مندرجات صفر پر سیٹ کردیئے جائیں۔
    ///
    /// کامیاب کال کے بعد میموری بلاک میں مندرجہ ذیل مواد شامل ہوں گے
    /// `grow_zeroed`:
    ///   * بائٹس `0..old_layout.size()` اصل مختص سے محفوظ ہیں۔
    ///   * بائٹ `old_layout.size()..old_size` مختص کرنے والے کے نفاذ پر منحصر ہے ، یا تو محفوظ یا صفر ہوگا۔
    ///   `old_size` `grow_zeroed` کال سے پہلے میموری بلاک کے سائز سے مراد ہے ، جو اس سائز سے بڑا ہوسکتا ہے جس کی اصل درخواست کی گئی تھی جب اسے مختص کیا گیا تھا۔
    ///   * بائٹس ایکس 01 ایکس صفر ہیں۔`new_size` `grow_zeroed` کال کے ذریعہ واپس کردہ میموری بلاک کی جسامت کو کہتے ہیں۔
    ///
    /// # Safety
    ///
    /// * `ptr` اس مختص کنندہ کے ذریعہ میموری [*currently allocated*] کے بلاک کو واضح کرنا چاہئے۔
    /// * `old_layout` میموری کو روکنے والے [*fit*] کو لازمی طور پر (`new_layout` دلیل کو اس کے فٹ ہونے کی ضرورت نہیں ہے۔)
    /// * `new_layout.size()` `old_layout.size()` سے زیادہ یا اس کے برابر ہونا چاہئے۔
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// اگر نیا ترتیب مختص کرنے والے کے سائز اور سیدھ کی سیدھ کو پورا نہیں کرتا ہے ، یا اگر دوسری صورت میں بڑھتا ہے تو ناکام ہوجاتا ہے تو `Err` واپس کرتا ہے۔
    ///
    /// نفاذ کو گھبرانے یا اسقاط حمل کرنے کی بجائے میموری تھکن پر `Err` واپس کرنے کی ترغیب دی جاتی ہے ، لیکن یہ کوئی سخت ضرورت نہیں ہے۔
    /// (خاص طور پر: اس trait کو ایک بنیادی آبائی الاٹریری لائبریری کے اوپر جو عملی طور پر میموری ختم ہونے پر ختم ہوتا ہے ، نافذ کرنا * قانونی ہے۔)
    ///
    /// مختص کی غلطی کے جواب میں کمپیوٹیشن اسقاط کو ختم کرنے کے خواہش مند مؤکلوں کو براہ راست `panic!` یا اس سے ملنے کی بجائے [`handle_alloc_error`] فنکشن کو فون کرنے کی ترغیب دی جاتی ہے۔
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // محفوظ کریں: کیونکہ `new_layout.size()` اس سے زیادہ یا اس کے برابر ہونا چاہئے
        // `old_layout.size()`, پرانی اور نئی دونوں میموری مختص `old_layout.size()` بائٹس کے لئے پڑھنے اور لکھتے ہیں۔
        // نیز ، کیونکہ پرانی الاٹمنٹ ابھی تک ختم نہیں ہوئی تھی ، لہذا یہ `new_ptr` کو اوورلیپ نہیں کرسکتی ہے۔
        // اس طرح ، `copy_nonoverlapping` پر کال محفوظ ہے۔
        // کال کرنے والے کے ذریعہ `dealloc` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// میموری بلاک کو سکڑانے کی کوششیں۔
    ///
    /// ایک نیا [`NonNull<[u8]>`][NonNull] لوٹاتا ہے جس میں ایک پوائنٹر اور مختص شدہ میموری کا اصل سائز ہوتا ہے۔پوائنٹر `new_layout` کے ذریعہ بیان کردہ ڈیٹا کے انعقاد کے لئے موزوں ہے۔
    /// اس کو پورا کرنے کے لئے ، نئے ترتیب کو فٹ ہونے کے لئے مختص کنندہ `ptr` کے ذریعہ مختص رقم کو سکڑ سکتا ہے۔
    ///
    /// اگر یہ `Ok` کو لوٹاتا ہے ، تو `ptr` کے ذریعہ حوالہ کردہ میموری بلاک کی ملکیت اس مختص کرنے والے کو منتقل کردی گئی ہے۔
    /// میموری آزاد ہوسکتی ہے یا نہیں ، اور اسے ناقابل استعمال سمجھا جانا چاہئے جب تک کہ اس طریقے کی واپسی قیمت کے ذریعے اسے دوبارہ کال کرنے والے کے پاس منتقل نہ کیا جائے۔
    ///
    /// اگر یہ طریقہ کار `Err` کو لوٹاتا ہے تو پھر میموری بلاک کی ملکیت اس مختص کرنے والے کو منتقل نہیں کی گئی ہے ، اور میموری بلاک کے مندرجات کو غیر تبدیل شدہ کردیا گیا ہے۔
    ///
    /// # Safety
    ///
    /// * `ptr` اس مختص کنندہ کے ذریعہ میموری [*currently allocated*] کے بلاک کو واضح کرنا چاہئے۔
    /// * `old_layout` میموری کو روکنے والے [*fit*] کو لازمی طور پر (`new_layout` دلیل کو اس کے فٹ ہونے کی ضرورت نہیں ہے۔)
    /// * `new_layout.size()` `old_layout.size()` سے چھوٹا یا اس کے برابر ہونا چاہئے۔
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// اگر نیا ترتیب مختص کرنے والے کے سائز اور سیدھ میں آنے والی رکاوٹوں کو پورا نہیں کرتا ہے ، یا اگر دوسری صورت میں سکڑ جاتا ہے تو ، `Err` واپس کرتا ہے۔
    ///
    /// نفاذ کو گھبرانے یا اسقاط حمل کرنے کی بجائے میموری تھکن پر `Err` واپس کرنے کی ترغیب دی جاتی ہے ، لیکن یہ کوئی سخت ضرورت نہیں ہے۔
    /// (خاص طور پر: اس trait کو ایک بنیادی آبائی الاٹریری لائبریری کے اوپر جو عملی طور پر میموری ختم ہونے پر ختم ہوتا ہے ، نافذ کرنا * قانونی ہے۔)
    ///
    /// مختص کی غلطی کے جواب میں کمپیوٹیشن اسقاط کو ختم کرنے کے خواہش مند مؤکلوں کو براہ راست `panic!` یا اس سے ملنے کی بجائے [`handle_alloc_error`] فنکشن کو فون کرنے کی ترغیب دی جاتی ہے۔
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // محفوظ کریں: کیونکہ `new_layout.size()` اس سے کم یا اس کے برابر ہونا چاہئے
        // `old_layout.size()`, پرانی اور نئی دونوں میموری مختص `new_layout.size()` بائٹس کے لئے پڑھنے اور لکھتے ہیں۔
        // نیز ، کیونکہ پرانی الاٹمنٹ ابھی تک ختم نہیں ہوئی تھی ، لہذا یہ `new_ptr` کو اوورلیپ نہیں کرسکتی ہے۔
        // اس طرح ، `copy_nonoverlapping` پر کال محفوظ ہے۔
        // کال کرنے والے کے ذریعہ `dealloc` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` کی اس مثال کے لئے "by reference" اڈاپٹر بناتا ہے۔
    ///
    /// لوٹا ہوا اڈیپٹر `Allocator` کو بھی نافذ کرتا ہے اور اسے آسانی سے ادھار لے گا۔
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // حفاظت: حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // حفاظت: حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // حفاظت: حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // حفاظت: حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}