use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// کسی خام نان الکول `*mut T` کے آس پاس ایک ریپر جو اس بات کی نشاندہی کرتا ہے کہ اس ریپر کا مالک اس کا مالک ہے۔
/// `Box<T>` ، `Vec<T>` ، `String` ، اور `HashMap<K, V>` جیسے خلاصہ بنانے کے لئے کارآمد۔
///
/// `*mut T` کے برعکس ، `Unique<T>` "as if" کے ساتھ سلوک کرتا ہے یہ `T` کی مثال تھی۔
/// اگر `T` `Send`/`Sync` ہے تو یہ `Send`/`Sync` لاگو کرتا ہے۔
/// اس سے یہ بھی اشارہ ملتا ہے کہ `T` کی ایک مثال کی توقع کی جانے والی مضبوط الیسیسنگ گارنٹیوں کی بھی اشارہ ہے:
/// اس اشارے کے مختلف میں اس کی اپنی خصوصیت کے لئے منفرد راستے کے بغیر ترمیم نہیں کی جانی چاہئے۔
///
/// اگر آپ کو اس بات کا یقین نہیں ہے کہ `Unique` کو اپنے مقاصد کے لئے استعمال کرنا درست ہے تو ، `NonNull` کے استعمال پر غور کریں ، جس میں کمزور الفاظ ہیں۔
///
///
/// `*mut T` کے برعکس ، پوائنٹر کو ہمیشہ غیر مستحکم ہونا چاہئے ، یہاں تک کہ اگر پوائنٹر کا کبھی بھی قدر نہیں کیا جاتا ہے۔
/// ایسا اس لئے ہے کہ اینمز اس ممنوع قدر کو امتیازی سلوک کے طور پر استعمال کرسکتے ہیں۔ `Option<Unique<T>>` کی سائز `Unique<T>` کی طرح ہے۔
/// تاہم ، اگر پوائنٹر کی قدر نہیں کی جاتی ہے تو پھر بھی اشارے میں الجھن پڑسکتی ہے۔
///
/// `*mut T` کے برعکس ، `Unique<T>` `T` سے زیادہ ہم آہنگی ہے
/// یہ ہمیشہ کسی بھی قسم کے لئے درست ہونا چاہئے جو منفرد کی الیاسی ضروریات کو برقرار رکھتا ہے۔
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: اس مارکر کے تغیر کے لئے کوئی نتیجہ نہیں ہے ، لیکن ضروری ہے
    // ڈراپ کو سمجھنے کے ل that کہ ہم منطقی طور پر ایک `T` کے مالک ہیں۔
    //
    // تفصیلات کے لئے ، ملاحظہ کریں:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` اگر `T` `Send` ہے تو پوائنٹرز `Send` ہیں کیونکہ جن ڈیٹا کا وہ حوالہ دیتے ہیں وہ غیر موافق ہے۔
/// نوٹ کریں کہ اس ایلیسیس حملہ آور کو ٹائپ سسٹم کے ذریعہ کوئی نقصان نہیں پہنچا ہے۔`Unique` کا استعمال کرتے ہوئے تجرید کو لازمی طور پر نافذ کرنا چاہئے۔
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` اگر `T` `Sync` ہے تو پوائنٹرز `Sync` ہیں کیونکہ جن ڈیٹا کا وہ حوالہ دیتے ہیں وہ غیر موافق ہے۔
/// نوٹ کریں کہ اس ایلیسیس حملہ آور کو ٹائپ سسٹم کے ذریعہ کوئی نقصان نہیں پہنچا ہے۔`Unique` کا استعمال کرتے ہوئے تجرید کو لازمی طور پر نافذ کرنا چاہئے۔
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// ایک نیا `Unique` بناتا ہے جو مسخ ہوتا ہے ، لیکن اچھی طرح سے منسلک ہوتا ہے۔
    ///
    /// یہ ان اقسام کو شروع کرنے کے لئے مفید ہے جو `Vec::new` کی طرح سستے سے مختص کرتے ہیں۔
    ///
    /// نوٹ کریں کہ پوائنٹر ویلیو `T` میں ممکنہ طور پر درست پوائنٹر کی نمائندگی کرسکتی ہے ، جس کا مطلب ہے کہ اسے "not yet initialized" سینٹینل ویلیو کے طور پر استعمال نہیں کرنا چاہئے۔
    /// ان اقسام کو جو بتدریج سے مختص کرتے ہیں ان کو کسی اور ذرائع سے ابتداء کو ٹریک کرنا چاہئے
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // محفوظ: mem::align_of() ایک درست ، غیر الخیال پوائنٹر واپس کرتا ہے۔
        // اس طرح new_unchecked() پر کال کرنے کی شرائط کا احترام کیا جاتا ہے۔
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// ایک نیا `Unique` بناتا ہے۔
    ///
    /// # Safety
    ///
    /// `ptr` لازمی طور پر غیر کالعدم ہونا چاہئے۔
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `ptr` غیر کالع ہے۔
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// اگر `ptr` غیر کالع ہے تو نیا `Unique` بناتا ہے۔
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // سلامتی: پوائنٹر کی جانچ پڑتال پہلے ہی کی جاچکی ہے اور وہ کالعدم نہیں ہے۔
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// بنیادی `*mut` پوائنٹر حاصل کرتا ہے۔
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// مشمولات کا حوالہ دیتے ہیں۔
    ///
    /// نتیجہ اخذ زندگی خود پر پابند ہے لہذا یہ "as if" برتاؤ کرتا ہے یہ دراصل ٹی کی ایک مثال تھی جو ادھار لیا جارہا ہے۔
    /// اگر طویل (unbound) زندگی بھر کی ضرورت ہو تو ، `&*my_ptr.as_ptr()` استعمال کریں۔
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` تمام کو پورا کرتا ہے
        // ایک حوالہ کے لئے ضروریات.
        unsafe { &*self.as_ptr() }
    }

    /// تحریری طور پر مشمولات کا حوالہ دیتے ہیں۔
    ///
    /// نتیجہ اخذ زندگی خود پر پابند ہے لہذا یہ "as if" برتاؤ کرتا ہے یہ دراصل ٹی کی ایک مثال تھی جو ادھار لیا جارہا ہے۔
    /// اگر طویل (unbound) زندگی بھر کی ضرورت ہو تو ، `&mut *my_ptr.as_ptr()` استعمال کریں۔
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` تمام کو پورا کرتا ہے
        // ایک تغیر پزیر حوالہ کی ضروریات۔
        unsafe { &mut *self.as_ptr() }
    }

    /// کسی اور قسم کے پوائنٹر کے لئے ذات۔
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // حفاظت: Unique::new_unchecked() ایک نیا انوکھا اور ضروریات بناتا ہے
        // منسوخ کرنے کے لئے دیئے گئے پوائنٹر.
        // چونکہ ہم خود کو ایک اشارے کے طور پر گزر رہے ہیں ، لہذا یہ کالعدم نہیں ہوسکتا ہے۔
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // حفاظت: ایک تغیر پذیر حوالہ کالعدم نہیں ہوسکتا
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}