#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// کسی بھی نوکدار قسم کی پوائنٹر میٹا ڈیٹا فراہم کرتا ہے۔
///
/// # پوائنٹر میٹا ڈیٹا
///
/// Rust میں خام پوائنٹر کی اقسام اور حوالہ جات کی قسموں کے بارے میں سوچا جاسکتا ہے جیسے دو حصوں سے بنا:
/// ایک ڈیٹا پوائنٹر جس میں ویلیو کا میموری ایڈریس اور کچھ میٹا ڈیٹا ہوتا ہے۔
///
/// اعدادوشمار کی قسم کی اقسام کے لئے (جو `Sized` traits پر عمل درآمد کرتے ہیں) اور ساتھ ہی `extern` اقسام کے لئے بھی ، پوائنٹرز کو "پتلا" کہا جاتا ہے: میٹا ڈیٹا صفر سائز کا ہے اور اس کی قسم `()` ہے۔
///
///
/// [dynamically-sized types][dst] کی طرف اشارہ کرنے والے کو "وسیع" یا "چربی" کہا جاتا ہے ، ان کے پاس صفر کے سائز کا میٹا ڈیٹا ہے:
///
/// * ایسے ڈوروں کے لئے جن کا آخری فیلڈ ڈی ایس ٹی ہے ، میٹا ڈیٹا آخری فیلڈ کا میٹا ڈیٹا ہے
/// * `str` قسم کے لئے ، میٹا ڈیٹا بائٹس میں `usize` کی لمبائی ہے
/// * `[T]` جیسے سلائس کی قسموں کے لئے ، میٹا ڈیٹا `usize` کی طرح آئٹمز کی لمبائی ہے
/// * `dyn SomeTrait` جیسے trait اشیاء کے ل For ، میٹا ڈیٹا [`DynMetadata<Self>`][DynMetadata] ہے (جیسے `DynMetadata<dyn SomeTrait>`)
///
/// future میں ، Rust زبان نئی قسم کی قسمیں حاصل کرسکتی ہے جس میں مختلف پوائنٹر میٹا ڈیٹا ہوتا ہے۔
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// اس trait کا نقطہ اس کی `Metadata` وابستہ قسم ہے ، جو `()` یا `usize` یا `DynMetadata<_>` ہے جیسا کہ اوپر بیان ہوا ہے۔
/// یہ خود بخود ہر قسم کے لئے لاگو ہوتا ہے۔
/// فرض کیا جاسکتا ہے کہ اس کو عام سیاق و سباق میں لاگو کیا جائے ، یہاں تک کہ اس سے وابستہ کوئی پابند نہیں ہے۔
///
/// # Usage
///
/// خام پوائنٹرز کو ڈیٹا ایڈریس اور میٹا ڈیٹا اجزاء میں ان کے [`to_raw_parts`] طریقہ سے گھٹایا جاسکتا ہے۔
///
/// متبادل کے طور پر ، اکیلے میٹا ڈیٹا کو [`metadata`] فنکشن کے ساتھ نکالا جاسکتا ہے۔
/// ایک حوالہ [`metadata`] کو پہنچایا جاسکتا ہے اور اسے زبردستی مجبور کیا جاتا ہے۔
///
/// ایک (possibly-wide) پوائنٹر کو اس کے پتے اور میٹا ڈیٹا سے [`from_raw_parts`] یا [`from_raw_parts_mut`] کے ساتھ ایک ساتھ واپس رکھا جاسکتا ہے۔
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` کے نکات اور حوالہ جات میں میٹا ڈیٹا کی قسم۔
    #[lang = "metadata_type"]
    // NOTE: trait bound کو `static_assert_expected_bounds_for_metadata` میں رکھیں
    //
    // یہاں کے ساتھ مطابقت پذیری میں `library/core/src/ptr/metadata.rs` میں:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// اس trait عرف کو نافذ کرنے والے اقسام کی طرف اشارہ "پتلا" ہے۔
///
/// اس میں مستحکم-سائز کی اقسام اور `extern` اقسام شامل ہیں۔
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait عرفیت زبان میں مستحکم ہونے سے پہلے اس کو مستحکم نہ کریں؟
pub trait Thin = Pointee<Metadata = ()>;

/// پوائنٹر کا میٹا ڈیٹا جزو نکالیں۔
///
/// `*mut T` ، `&T` ، یا `&mut T` قسم کی اقدار کو براہ راست اس فنکشن میں منتقل کیا جاسکتا ہے کیونکہ وہ واضح طور پر `* const T` پر مجبور کرتے ہیں۔
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // محفوظ: `PtrRepr` یونین سے قیمت تک رسائی محفوظ ہے کیونکہ * Const T
    // اور PtrComp اجزاء<T>ایک ہی میموری ترتیب ہے.
    // صرف std ہی اس کی ضمانت دے سکتا ہے۔
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ڈیٹا ایڈریس اور میٹا ڈیٹا سے ایک (possibly-wide) خام پوائنٹر تشکیل دیتا ہے۔
///
/// یہ فنکشن محفوظ ہے لیکن ریٹرنڈ پوائنٹ کے لئے ضروری نہیں کہ محفوظ ہو۔
/// سلائسز کے ل safety ، حفاظت کی ضروریات کے ل X [`slice::from_raw_parts`] کی دستاویزات دیکھیں۔
/// trait آبجیکٹس کے لئے ، میٹا ڈیٹا ایک پوائنٹر سے اسی بنیادی بنیادی شکل پر آنا چاہئے۔
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // محفوظ: `PtrRepr` یونین سے قیمت تک رسائی محفوظ ہے کیونکہ * Const T
    // اور PtrComp اجزاء<T>ایک ہی میموری ترتیب ہے.
    // صرف std ہی اس کی ضمانت دے سکتا ہے۔
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] جیسا ہی فعالیت انجام دیتا ہے ، سوائے اس کے کہ کسی `*mut` پوائنٹر کے خام `* const` پوائنٹر کے برخلاف ، ایک خام `*mut` پوائنٹر واپس کیا جاتا ہے۔
///
///
/// مزید تفصیلات کے لئے [`from_raw_parts`] کی دستاویزات دیکھیں۔
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // محفوظ: `PtrRepr` یونین سے قیمت تک رسائی محفوظ ہے کیونکہ * Const T
    // اور PtrComp اجزاء<T>ایک ہی میموری ترتیب ہے.
    // صرف std ہی اس کی ضمانت دے سکتا ہے۔
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` باؤنڈ سے بچنے کے لئے دستی املا کی ضرورت ہے۔
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` باؤنڈ سے بچنے کے لئے دستی املا کی ضرورت ہے۔
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait آبجیکٹ کی قسم کیلئے میٹا ڈیٹا۔
///
/// یہ ویٹیبل (ورچوئل کال ٹیبل) کا اشارہ ہے جو trait آبجیکٹ کے اندر محفوظ کنکریٹ کی قسم کو جوڑنے کیلئے تمام ضروری معلومات کی نمائندگی کرتا ہے۔
/// vtable قابل ذکر ہے:
///
/// * قسم کا سائز
/// * سیدھ کی قسم
/// * اس قسم کے `drop_in_place` امپیل کی طرف اشارہ کرنے والا (سادہ پرانے ڈیٹا کا انتخاب نہیں کرسکتا ہے)
/// * trait پر اس قسم کے نفاذ کے لئے تمام طریقوں کی طرف اشارہ
///
/// نوٹ کریں کہ پہلا تین خاص ہے کیونکہ انہیں کسی بھی trait آبجیکٹ کو مختص کرنے ، چھوڑنے اور اسے ختم کرنے کے لئے ضروری ہے۔
///
/// اس ڈھانچے کا نام کسی ایسے پیرامیٹر کے ساتھ رکھنا ممکن ہے جو `dyn` trait آبجیکٹ نہیں ہو (مثال کے طور پر `DynMetadata<u64>`) لیکن اس ڈھانچے کی کوئی معنی خیز قدر حاصل کرنے کے لئے نہیں۔
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// تمام vtables کے مشترکہ ماقبل.اس کے بعد trait طریقوں کے لئے فنکشن پوائنٹرز کے بعد ہے۔
///
/// `DynMetadata::size_of` وغیرہ کی نجی عمل درآمد کی تفصیل
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// اس vtable کے ساتھ وابستہ قسم کا سائز لوٹاتا ہے۔
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// اس vtable کے ساتھ وابستہ قسم کی سیدھ میں لوٹاتا ہے۔
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` کے بطور سائز اور سیدھ کو ایک ساتھ لوٹاتا ہے
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // محفوظ: مرتب کنندہ نے اس ویٹیبل کو کسی ٹھوس Rust قسم کے لئے خارج کیا
        // ایک درست ترتیب ہے۔`Layout::for_value` کی طرح ہی عقلی
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` حدود سے بچنے کے لئے دستی امپلس کی ضرورت ہے۔

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}