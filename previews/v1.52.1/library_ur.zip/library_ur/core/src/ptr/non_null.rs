use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` لیکن غیر صفر اور کوارینیٹ۔
///
/// خام پوائنٹروں کا استعمال کرتے ہوئے ڈیٹا ڈھانچے کی تعمیر کرتے وقت یہ اکثر استعمال کرنے میں درست چیز ہے ، لیکن اس کی اضافی خصوصیات کی وجہ سے بالآخر اس کا استعمال زیادہ خطرناک ہوتا ہے۔اگر آپ کو یقین نہیں ہے کہ آپ کو `NonNull<T>` استعمال کرنا چاہئے تو ، صرف `*mut T` استعمال کریں!
///
/// `*mut T` کے برعکس ، پوائنٹر کو ہمیشہ غیر مستحکم ہونا چاہئے ، یہاں تک کہ اگر پوائنٹر کا کبھی بھی قدر نہیں کیا جاتا ہے۔ایسا اس لئے ہے کہ اینمز اس ممنوع قدر کو امتیازی سلوک کے طور پر استعمال کرسکتے ہیں-`Option<NonNull<T>>` کے سائز کا سائز `* mut T` ہے۔
/// تاہم ، اگر پوائنٹر کی قدر نہیں کی جاتی ہے تو پھر بھی اشارے میں الجھن پڑسکتی ہے۔
///
/// `*mut T` کے برعکس ، `NonNull<T>` کو `T` سے زیادہ کوویرانیٹ کرنے کے لئے منتخب کیا گیا تھا۔اس سے یہ معلوم ہوتا ہے کہ کوآورینٹ اقسام کی تعمیر کرتے وقت `NonNull<T>` کا استعمال کیا جاسکتا ہے ، لیکن اگر کسی ایسی قسم میں استعمال کیا جائے جو حقیقت میں ہمہ گیر نہیں ہونا چاہئے تو بے بنیاد ہونے کا خطرہ متعارف کراتا ہے۔
/// (متضاد انتخاب `*mut T` کے لئے کیا گیا تھا حالانکہ تکنیکی طور پر بے بنیادی صرف غیر محفوظ افعال کو کال کرنے کی وجہ سے ہوسکتی ہے۔)
///
/// کوویرینس زیادہ تر محفوظ تجریدوں جیسے `Box` ، `Rc` ، `Arc` ،`Box` اور `LinkedList` کے لئے درست ہے۔یہ معاملہ ہے کیونکہ وہ ایک عوامی API فراہم کرتے ہیں جو Rust کے عام مشترکہ XOR تبادلہ احکام کی پیروی کرتا ہے۔
///
/// اگر آپ کی قسم محفوظ طریقے سے ہم خیال نہیں ہوسکتی ہے ، آپ کو یقینی بنانا ہوگا کہ اس میں انوارینس فراہم کرنے کے لئے کچھ اضافی فیلڈ موجود ہو۔اکثر یہ فیلڈ [`PhantomData`] قسم کا ہوگا جیسے `PhantomData<Cell<T>>` یا `PhantomData<&'a mut T>`۔
///
/// نوٹ کریں کہ `NonNull<T>` میں `&T` کے لئے ایک `From` مثال موجود ہے۔تاہم ، اس حقیقت کو تبدیل نہیں کرتا ہے کہ مشترکہ حوالہ سے (پوائنٹر سے ماخوذ) مشترکہ حوالہ کے ذریعے تغیر پزیر ہونا غیر متعین طرز عمل ہے جب تک کہ [`UnsafeCell<T>`] کے اندر یہ تغیر نہ ہوجائے۔مشترکہ حوالہ سے تغیر پذیر حوالہ پیدا کرنے کے لئے بھی یہی بات ہے۔
///
/// اس `From` مثال کو `UnsafeCell<T>` کے بغیر استعمال کرتے وقت ، یہ آپ کی ذمہ داری ہے کہ `as_mut` کو کبھی بھی نہیں بلایا جاتا ، اور `as_ptr` کبھی بھی اتپریورتن کے لئے استعمال نہیں ہوتا ہے۔
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` پوائنٹرز `Send` نہیں ہیں کیونکہ جن ڈیٹا کا وہ حوالہ دیتے ہیں وہ علانیہ رہ سکتا ہے۔
// NB ، یہ امتیاز غیر ضروری ہے ، لیکن خرابی کے بہتر پیغامات فراہم کرنا چاہئے۔
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` پوائنٹرز `Sync` نہیں ہیں کیونکہ جن ڈیٹا کا وہ حوالہ دیتے ہیں وہ علانیہ رہ سکتا ہے۔
// NB ، یہ امتیاز غیر ضروری ہے ، لیکن خرابی کے بہتر پیغامات فراہم کرنا چاہئے۔
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// ایک نیا `NonNull` بناتا ہے جو مسخ ہوتا ہے ، لیکن اچھی طرح سے منسلک ہوتا ہے۔
    ///
    /// یہ ان اقسام کو شروع کرنے کے لئے مفید ہے جو `Vec::new` کی طرح سستے سے مختص کرتے ہیں۔
    ///
    /// نوٹ کریں کہ پوائنٹر ویلیو `T` میں ممکنہ طور پر درست پوائنٹر کی نمائندگی کرسکتی ہے ، جس کا مطلب ہے کہ اسے "not yet initialized" سینٹینل ویلیو کے طور پر استعمال نہیں کرنا چاہئے۔
    /// ان اقسام کو جو بتدریج سے مختص کرتے ہیں ان کو کسی اور ذرائع سے ابتداء کو ٹریک کرنا چاہئے
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // محفوظ کریں: mem::align_of() غیر صفر استعمال کو واپس کرتا ہے جو اس کے بعد کاسٹ کیا جاتا ہے
        // ایک * mut T.
        // لہذا ، `ptr` کالعدم نہیں ہے اور new_unchecked() پر کال کرنے کی شرائط کا احترام کیا جاتا ہے۔
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// قدر کے مشترکہ حوالوں کو لوٹاتا ہے۔[`as_ref`] کے برعکس ، اس کی ضرورت نہیں ہوتی ہے کہ قدر کو ابتدا کرنا ہو۔
    ///
    /// تغیر پزیر ہم منصب کے لئے دیکھیں [`as_uninit_mut`]۔
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// اس طریقے کو کال کرتے وقت ، آپ کو یہ یقینی بنانا ہوگا کہ درج ذیل میں سے سبھی صحیح ہیں:
    ///
    /// * پوائنٹر کو صحیح طریقے سے منسلک کیا جانا چاہئے۔
    ///
    /// * یہ [the module documentation] میں بیان کردہ معنی میں "dereferencable" ہونا چاہئے۔
    ///
    /// * آپ کو Rust کے الیاسنگ قواعد کو نافذ کرنا ہوگا ، چونکہ واپسی کی زندگی بھر `'a` من مانی طور پر منتخب کیا گیا ہے اور ضروری نہیں ہے کہ اعداد و شمار کی اصل زندگی کی عکاسی کریں۔
    ///
    ///   خاص طور پر ، اس زندگی بھر کے عرصہ کے لئے ، اشارہ کی طرف اشارہ کرنے والی میموری کو تبدیل نہیں ہونا چاہئے (سوائے `UnsafeCell` کے اندر)۔
    ///
    /// اس کا اطلاق یہاں تک کہ اگر اس طریقے کا نتیجہ غیر استعمال شدہ ہے!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` تمام کو پورا کرتا ہے
        // ایک حوالہ کے لئے ضروریات.
        unsafe { &*self.cast().as_ptr() }
    }

    /// قدر کے انوکھے حوالوں کو لوٹاتا ہے۔[`as_mut`] کے برعکس ، اس کی ضرورت نہیں ہوتی ہے کہ قدر کو ابتدا کرنا ہو۔
    ///
    /// مشترکہ ہم منصب کے لئے دیکھیں [`as_uninit_ref`]۔
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// اس طریقے کو کال کرتے وقت ، آپ کو یہ یقینی بنانا ہوگا کہ درج ذیل میں سے سبھی صحیح ہیں:
    ///
    /// * پوائنٹر کو صحیح طریقے سے منسلک کیا جانا چاہئے۔
    ///
    /// * یہ [the module documentation] میں بیان کردہ معنی میں "dereferencable" ہونا چاہئے۔
    ///
    /// * آپ کو Rust کے الیاسنگ قواعد کو نافذ کرنا ہوگا ، چونکہ واپسی کی زندگی بھر `'a` من مانی طور پر منتخب کیا گیا ہے اور ضروری نہیں ہے کہ اعداد و شمار کی اصل زندگی کی عکاسی کریں۔
    ///
    ///   خاص طور پر ، اس زندگی بھر کی مدت کے لئے ، اشارہ کی طرف اشارہ کرنے والی یادداشت کو کسی دوسرے پوائنٹر کے ذریعہ رسائی (پڑھنے یا تحریری) نہیں ہونا چاہئے۔
    ///
    /// اس کا اطلاق یہاں تک کہ اگر اس طریقے کا نتیجہ غیر استعمال شدہ ہے!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` تمام کو پورا کرتا ہے
        // ایک حوالہ کے لئے ضروریات.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// ایک نیا `NonNull` بناتا ہے۔
    ///
    /// # Safety
    ///
    /// `ptr` لازمی طور پر غیر کالعدم ہونا چاہئے۔
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `ptr` غیر کالع ہے۔
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// اگر `ptr` غیر کالع ہے تو نیا `NonNull` بناتا ہے۔
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // محفوظ: اشارے کی جانچ پڑتال پہلے ہی کی گئی ہے اور یہ کالعدم نہیں ہے
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] جیسا ہی فعالیت انجام دیتا ہے ، سوائے اس کے کہ ایک `NonNull` پوائنٹر واپس ہوجاتا ہے ، خام `*const` پوائنٹر کے برخلاف۔
    ///
    ///
    /// مزید تفصیلات کے لئے [`std::ptr::from_raw_parts`] کی دستاویزات دیکھیں۔
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // محفوظ: `ptr::from::raw_parts_mut` کا نتیجہ غیر کالع ہے کیونکہ `data_address` ہے۔
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// ایڈریس اور میٹا ڈیٹا کے اجزاء میں ایک (ممکنہ طور پر وسیع) پوائنٹر کو تحلیل کریں۔
    ///
    /// پوائنٹر کو بعد میں [`NonNull::from_raw_parts`] کے ساتھ دوبارہ تشکیل دیا جاسکتا ہے۔
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// بنیادی `*mut` پوائنٹر حاصل کرتا ہے۔
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// قدر کا مشترکہ حوالہ لوٹاتا ہے۔اگر قدر کو غیر متعل beق کیا جاسکتا ہے تو ، اس کے بجائے [`as_uninit_ref`] استعمال کرنا چاہئے۔
    ///
    /// تغیر پزیر ہم منصب کے لئے دیکھیں [`as_mut`]۔
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// اس طریقے کو کال کرتے وقت ، آپ کو یہ یقینی بنانا ہوگا کہ درج ذیل میں سے سبھی صحیح ہیں:
    ///
    /// * پوائنٹر کو صحیح طریقے سے منسلک کیا جانا چاہئے۔
    ///
    /// * یہ [the module documentation] میں بیان کردہ معنی میں "dereferencable" ہونا چاہئے۔
    ///
    /// * پوائنٹر کو `T` کی ابتدائی مثال کی طرف اشارہ کرنا چاہئے۔
    ///
    /// * آپ کو Rust کے الیاسنگ قواعد کو نافذ کرنا ہوگا ، چونکہ واپسی کی زندگی بھر `'a` من مانی طور پر منتخب کیا گیا ہے اور ضروری نہیں ہے کہ اعداد و شمار کی اصل زندگی کی عکاسی کریں۔
    ///
    ///   خاص طور پر ، اس زندگی بھر کے عرصہ کے لئے ، اشارہ کی طرف اشارہ کرنے والی میموری کو تبدیل نہیں ہونا چاہئے (سوائے `UnsafeCell` کے اندر)۔
    ///
    /// اس کا اطلاق یہاں تک کہ اگر اس طریقے کا نتیجہ غیر استعمال شدہ ہے!
    /// (ابتدائی طور پر شروع کرنے کے بارے میں ابھی تک مکمل طور پر فیصلہ نہیں کیا گیا ہے ، لیکن جب تک یہ نہیں ہے ، صرف محفوظ نقطہ نظر یہ یقینی بنانا ہے کہ وہ واقعتا initial ابتداء میں ہیں۔)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` تمام کو پورا کرتا ہے
        // ایک حوالہ کے لئے ضروریات.
        unsafe { &*self.as_ptr() }
    }

    /// قدر کا ایک انوکھا حوالہ واپس کرتا ہے۔اگر قدر کو غیر متعل beق کیا جاسکتا ہے تو ، اس کے بجائے [`as_uninit_mut`] استعمال کرنا چاہئے۔
    ///
    /// مشترکہ ہم منصب کے لئے دیکھیں [`as_ref`]۔
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// اس طریقے کو کال کرتے وقت ، آپ کو یہ یقینی بنانا ہوگا کہ درج ذیل میں سے سبھی صحیح ہیں:
    ///
    /// * پوائنٹر کو صحیح طریقے سے منسلک کیا جانا چاہئے۔
    ///
    /// * یہ [the module documentation] میں بیان کردہ معنی میں "dereferencable" ہونا چاہئے۔
    ///
    /// * پوائنٹر کو `T` کی ابتدائی مثال کی طرف اشارہ کرنا چاہئے۔
    ///
    /// * آپ کو Rust کے الیاسنگ قواعد کو نافذ کرنا ہوگا ، چونکہ واپسی کی زندگی بھر `'a` من مانی طور پر منتخب کیا گیا ہے اور ضروری نہیں ہے کہ اعداد و شمار کی اصل زندگی کی عکاسی کریں۔
    ///
    ///   خاص طور پر ، اس زندگی بھر کی مدت کے لئے ، اشارہ کی طرف اشارہ کرنے والی یادداشت کو کسی دوسرے پوائنٹر کے ذریعہ رسائی (پڑھنے یا تحریری) نہیں ہونا چاہئے۔
    ///
    /// اس کا اطلاق یہاں تک کہ اگر اس طریقے کا نتیجہ غیر استعمال شدہ ہے!
    /// (ابتدائی طور پر شروع کرنے کے بارے میں ابھی تک مکمل طور پر فیصلہ نہیں کیا گیا ہے ، لیکن جب تک یہ نہیں ہے ، صرف محفوظ نقطہ نظر یہ یقینی بنانا ہے کہ وہ واقعتا initial ابتداء میں ہیں۔)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` تمام کو پورا کرتا ہے
        // ایک تغیر پزیر حوالہ کی ضروریات۔
        unsafe { &mut *self.as_ptr() }
    }

    /// کسی اور قسم کے پوائنٹر کے لئے ذات۔
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // حفاظت: `self` ایک `NonNull` پوائنٹر ہے جو ضروری طور پر غیر کالعدم ہے
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// پتلی پوائنٹر اور لمبائی سے نان الخلاقی خام سلائس بناتا ہے۔
    ///
    /// `len` دلیل **عناصر** کی تعداد ہے ، بائٹس کی تعداد نہیں ہے۔
    ///
    /// یہ فنکشن محفوظ ہے ، لیکن واپسی کی قیمت کو مستحکم کرنا غیر محفوظ ہے۔
    /// سلائس حفاظتی ضروریات کے ل X [`slice::from_raw_parts`] کی دستاویزات دیکھیں۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // پہلے عنصر کی طرف اشارے کے ساتھ شروع کرتے وقت سلائس پوائنٹر بنائیں
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (نوٹ کریں کہ یہ مثال مصنوعی طریقے سے اس طریقہ کار کے استعمال کو ظاہر کرتی ہے ، لیکن `سلائس= NonNull::from(&x[..]);` would be a better way to write code like this.) دیں
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // حفاظت: `data` ایک `NonNull` پوائنٹر ہے جو ضروری طور پر غیر کالعدم ہے
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// نون کالع خام سلائس کی لمبائی لوٹاتا ہے۔
    ///
    /// لوٹی گئی قیمت **عناصر** کی تعداد ہے ، بائٹس کی تعداد نہیں۔
    ///
    /// یہ فنکشن محفوظ ہے ، یہاں تک کہ جب غیر نال خام سلائس کا کسی ٹکڑے سے تعل .ق نہیں کیا جاسکتا ہے کیونکہ اس نکتے کا درست پتہ نہیں ہوتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// سلائس کے بفر میں ایک نان کیل پوائنٹر واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // محفوظ کریں: ہم جانتے ہیں کہ `self` غیر کالعدم ہے۔
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// سلائس کے بفر پر خام پوائنٹر لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ممکنہ طور پر غیر منقولہ اقدار کے ٹکڑے کا مشترکہ حوالہ لوٹاتا ہے۔[`as_ref`] کے برعکس ، اس کی ضرورت نہیں ہوتی ہے کہ قدر کو ابتدا کرنا ہو۔
    ///
    /// تغیر پزیر ہم منصب کے لئے دیکھیں [`as_uninit_slice_mut`]۔
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// اس طریقے کو کال کرتے وقت ، آپ کو یہ یقینی بنانا ہوگا کہ درج ذیل میں سے سبھی صحیح ہیں:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` بہت سارے بائٹس کے پڑھنے کے ل for پوائنٹر [valid] ہونا ضروری ہے ، اور اسے صحیح طور پر سیدھ میں ہونا چاہئے۔اس کا مطلب خاص طور پر ہے:
    ///
    ///     * اس ٹکڑے کی پوری میموری کی حد ایک ہی مختص آبجیکٹ میں ہونی چاہئے۔
    ///       ٹکڑے ٹکڑے کبھی بھی متعدد مختص آبجیکٹ میں نہیں پھیل سکتے ہیں۔
    ///
    ///     * یہاں تک کہ صفر کی لمبائی کے سلائس کے لئے بھی پوائنٹر کی سیدھ میں ہونا چاہئے۔
    ///     اس کی ایک وجہ یہ ہے کہ اینوم لے آؤٹ آپٹیمائزیشن حوالہ جات (جس میں کسی لمبائی کے ٹکڑے بھی شامل ہے) پر منحصر ہوسکتی ہے تاکہ وہ دوسرے ڈیٹا سے ممتاز ہوسکے۔
    ///
    ///     آپ ایک ایسا پوائنٹر حاصل کرسکتے ہیں جو [`NonNull::dangling()`] کا استعمال کرتے ہوئے صفر لمبائی کے سلائس کے لئے `data` کے بطور قابل استعمال ہو۔
    ///
    /// * سلائس کا کل سائز `ptr.len() * mem::size_of::<T>()` `isize::MAX` سے بڑا نہیں ہونا چاہئے۔
    ///   [`pointer::offset`] کی حفاظتی دستاویزات دیکھیں۔
    ///
    /// * آپ کو Rust کے الیاسنگ قواعد کو نافذ کرنا ہوگا ، چونکہ واپسی کی زندگی بھر `'a` من مانی طور پر منتخب کیا گیا ہے اور ضروری نہیں ہے کہ اعداد و شمار کی اصل زندگی کی عکاسی کریں۔
    ///   خاص طور پر ، اس زندگی بھر کے عرصہ کے لئے ، اشارہ کی طرف اشارہ کرنے والی میموری کو تبدیل نہیں ہونا چاہئے (سوائے `UnsafeCell` کے اندر)۔
    ///
    /// اس کا اطلاق یہاں تک کہ اگر اس طریقے کا نتیجہ غیر استعمال شدہ ہے!
    ///
    /// [`slice::from_raw_parts`] بھی دیکھیں۔
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // محفوظ: کال کرنے والے کو `as_uninit_slice` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ممکنہ طور پر غیر منقولہ اقدار کے ٹکڑے کا ایک انوکھا حوالہ لوٹاتا ہے۔[`as_mut`] کے برعکس ، اس کی ضرورت نہیں ہوتی ہے کہ قدر کو ابتدا کرنا ہو۔
    ///
    /// مشترکہ ہم منصب کے لئے دیکھیں [`as_uninit_slice`]۔
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// اس طریقے کو کال کرتے وقت ، آپ کو یہ یقینی بنانا ہوگا کہ درج ذیل میں سے سبھی صحیح ہیں:
    ///
    /// * بہت سارے بائٹس `ptr.len() * mem::size_of::<T>()` کے لئے پڑھنے اور لکھنے کے ل poin پوائنٹر [valid] ہونا ضروری ہے ، اور اسے صحیح طور پر سیدھ میں ہونا چاہئے۔اس کا مطلب خاص طور پر ہے:
    ///
    ///     * اس ٹکڑے کی پوری میموری کی حد ایک ہی مختص آبجیکٹ میں ہونی چاہئے۔
    ///       ٹکڑے ٹکڑے کبھی بھی متعدد مختص آبجیکٹ میں نہیں پھیل سکتے ہیں۔
    ///
    ///     * یہاں تک کہ صفر کی لمبائی کے سلائس کے لئے بھی پوائنٹر کی سیدھ میں ہونا چاہئے۔
    ///     اس کی ایک وجہ یہ ہے کہ اینوم لے آؤٹ آپٹیمائزیشن حوالہ جات (جس میں کسی لمبائی کے ٹکڑے بھی شامل ہے) پر منحصر ہوسکتی ہے تاکہ وہ دوسرے ڈیٹا سے ممتاز ہوسکے۔
    ///
    ///     آپ ایک ایسا پوائنٹر حاصل کرسکتے ہیں جو [`NonNull::dangling()`] کا استعمال کرتے ہوئے صفر لمبائی کے سلائس کے لئے `data` کے بطور قابل استعمال ہو۔
    ///
    /// * سلائس کا کل سائز `ptr.len() * mem::size_of::<T>()` `isize::MAX` سے بڑا نہیں ہونا چاہئے۔
    ///   [`pointer::offset`] کی حفاظتی دستاویزات دیکھیں۔
    ///
    /// * آپ کو Rust کے الیاسنگ قواعد کو نافذ کرنا ہوگا ، چونکہ واپسی کی زندگی بھر `'a` من مانی طور پر منتخب کیا گیا ہے اور ضروری نہیں ہے کہ اعداد و شمار کی اصل زندگی کی عکاسی کریں۔
    ///   خاص طور پر ، اس زندگی بھر کی مدت کے لئے ، اشارہ کی طرف اشارہ کرنے والی یادداشت کو کسی دوسرے پوائنٹر کے ذریعہ رسائی (پڑھنے یا تحریری) نہیں ہونا چاہئے۔
    ///
    /// اس کا اطلاق یہاں تک کہ اگر اس طریقے کا نتیجہ غیر استعمال شدہ ہے!
    ///
    /// [`slice::from_raw_parts_mut`] بھی دیکھیں۔
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // یہ محفوظ ہے کیونکہ `memory` پڑھنے کے لئے موزوں ہے اور `memory.len()` بہت سے بائٹس کے لئے لکھتا ہے۔
    /// // نوٹ کریں کہ یہاں `memory.as_mut()` پر کال کرنے کی اجازت نہیں ہے کیونکہ ہوسکتا ہے کہ اس مواد کو غیر متعل .ق کردیا جائے۔
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // محفوظ: کال کرنے والے کو `as_uninit_slice_mut` کیلئے حفاظتی معاہدہ کو برقرار رکھنا چاہئے۔
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// حد چیکنگ کیے بغیر کسی عنصر یا سبسلائس کو کچا پوائنٹر لوٹاتا ہے۔
    ///
    /// اس طریقہ کار کو حدود سے باہر انڈیکس کے ساتھ کال کرنا یا جب `self` قابل تعزیر نہیں ہے *[[وضاحتی سلوک]]* ہے یہاں تک کہ اگر نتیجے میں آنے والا اشارہ استعمال نہیں کیا جاتا ہے۔
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // محفوظ: کال کرنے والا یقینی بناتا ہے کہ `self` قابل تعزیر ہے اور `index` ان باؤنڈز ہے۔
        // نتیجے کے طور پر ، نتیجے میں پوائنٹر NULL نہیں ہوسکتا ہے۔
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // حفاظت: ایک انوکھا پوائنٹر کالعدم نہیں ہوسکتا ہے ، لہذا شرائط اس کیلئے
        // new_unchecked() قابل احترام ہیں
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // حفاظت: ایک تغیر پذیر حوالہ کالعدم نہیں ہوسکتا۔
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // حفاظت: ایک حوالہ کالعدم نہیں ہوسکتا ، لہذا شرائط اس کے لئے ہیں
        // new_unchecked() قابل احترام ہیں
        unsafe { NonNull { pointer: reference as *const T } }
    }
}