//! ASCII ڈور اور کرداروں پر آپریشن۔
//!
//! Rust میں زیادہ تر سٹرنگ آپریشن UTF-8 تار پر عمل کرتے ہیں۔
//! تاہم ، بعض اوقات یہ زیادہ خاص سمجھ میں آتا ہے کہ صرف ایک مخصوص آپریشن کے ل AS ASCII کیریکٹر سیٹ پر غور کیا جائے۔
//!
//! [`escape_default`] فنکشن دیئے گئے کردار کے فرار ہونے والے ورژن کے بائٹس پر ایک ریڈیٹر فراہم کرتا ہے۔
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// بائٹ کے فرار ورژن پر دوبارہ چلنے والا۔
///
/// یہ `struct` [`escape_default`] فنکشن کے ذریعہ تشکیل دیا گیا ہے۔
/// مزید کے لئے اس کی دستاویزات ملاحظہ کریں۔
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// ایک ایٹریٹر لوٹاتا ہے جو `u8` کا فرار شدہ ورژن تیار کرتا ہے۔
///
/// ڈیفالٹ کا انتخاب لفظی تیار کرنے کی طرف تعصب کے ساتھ کیا جاتا ہے جو مختلف زبانوں میں قانونی ہیں جن میں C++ 11 اور اسی طرح کی سی فیملی زبانیں شامل ہیں۔
/// عین قواعد یہ ہیں:
///
/// * ٹیب `\t` کے طور پر فرار ہوگیا ہے۔
/// * کیریج کی واپسی `\r` کے طور پر فرار ہوگئی ہے۔
/// * لائن فیڈ `\n` کے طور پر فرار ہوگیا ہے۔
/// * ایک حوالہ `\'` کے طور پر فرار ہوگیا ہے۔
/// * ڈبل اقتباس `\"` کے طور پر فرار ہوگیا ہے۔
/// * بیک سلیش `\\` کے طور پر فرار ہوگیا ہے۔
/// * 'پرنٹ ایبل ASCII' رینج `0x20` میں کوئی بھی کردار .. `0x7e` شامل نہیں ہے۔
/// * کسی بھی دوسرے حرف کو '\xNN' کی شکل سے ہیکس بچاؤ دیا جاتا ہے۔
/// * یونیکوڈ فرار کبھی بھی اس فنکشن کے ذریعہ تیار نہیں کیا جاتا ہے۔
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // محفوظ کریں: ٹھیک ہے کیونکہ `escape_default` نے صرف utf-8 کا درست ڈیٹا تشکیل دیا ہے
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}