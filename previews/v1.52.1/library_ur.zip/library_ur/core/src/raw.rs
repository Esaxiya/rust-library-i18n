#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! بلٹ میں اقسام کے مرتب کی ترتیب کے لئے ساخت کی تعریف پر مشتمل ہے۔
//!
//! غیر محفوظ کوڈ میں براہ راست خام نمائندوں کو جوڑ توڑ کے ل They ان کو ٹرانسمیٹ کے ہدف کے طور پر استعمال کیا جاسکتا ہے۔
//!
//!
//! ان کی تعریف کو ہمیشہ A0000 میں `rustc_middle::ty::layout` میں بیان کردہ میچ سے ملنا چاہئے۔
//!

/// trait آبجیکٹ کی نمائندگی جیسے `&dyn SomeTrait`۔
///
/// اس سٹرک میں ایک ہی شکل ہے جیسے `&dyn SomeTrait` اور `Box<dyn AnotherTrait>`۔
///
/// `TraitObject` ترتیب سے مماثل ہونے کی ضمانت ہے ، لیکن یہ trait اشیاء کی قسم نہیں ہے (مثال کے طور پر ، کھیت ایک `&dyn SomeTrait` پر براہ راست قابل رسائی نہیں ہے) اور نہ ہی وہ اس ترتیب کو کنٹرول کرتا ہے (تعریف کو تبدیل کرنے سے `&dyn SomeTrait` کی ترتیب کو تبدیل نہیں کیا جاسکتا ہے)۔
///
/// یہ صرف غیر محفوظ کوڈ کے ذریعہ استعمال کرنے کے لئے ڈیزائن کیا گیا ہے جس میں نچلی سطح کی تفصیلات میں ہیرا پھیری کی ضرورت ہے۔
///
/// تمام trait اشیاء کو عام طور پر حوالہ دینے کا کوئی راستہ نہیں ہے ، لہذا اس نوع کی اقدار پیدا کرنے کا واحد راستہ [`std::mem::transmute`][transmute] جیسے افعال سے ہے۔
/// اسی طرح ، `TraitObject` قدر سے حقیقی trait آبجیکٹ بنانے کا واحد راستہ `transmute` کے ساتھ ہے۔
///
/// [transmute]: crate::intrinsics::transmute
///
/// ایک trait آبجیکٹ کی مماثلت والی اقسام کے ساتھ ترکیب کرنا-ایک وہ جگہ جہاں ویٹیبل قدر کی اس قسم سے مطابقت نہیں رکھتا ہے جس میں ڈیٹا پوائنٹر کی نشاندہی کی جاتی ہے und انتہائی امکان ہے کہ یہ غیر وضاحتی رویے کا باعث بنے۔
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ایک مثال trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // مرتب کو trait آبجیکٹ بنانے دیں
/// let object: &dyn Foo = &value;
///
/// // خام نمائندگی دیکھو
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ڈیٹا پوائنٹر `value` کا پتہ ہے
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // ایک نیا اعتراض بنائیں ، ایک مختلف `i32` کی طرف اشارہ کرتے ہوئے ، `object` سے `i32` وی ٹیبل کو استعمال کرنے میں محتاط رہیں۔
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // اس کو اس طرح کام کرنا چاہئے جیسے `other_value` میں سے ہم نے trait آبجیکٹ کو براہ راست بنایا ہو
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}