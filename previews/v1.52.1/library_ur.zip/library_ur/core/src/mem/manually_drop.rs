use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// wra T` کے ڈسٹرکٹر کو خود بخود کال کرنے سے کمپلر کو روکنے کیلئے ایک ریپر۔
/// یہ ریپر 0 لاگت کا ہے۔
///
/// `ManuallyDrop<T>` `T` کی طرح ایک ہی ترتیب کی اصلاح کے تابع ہے۔
/// اس کے نتیجے میں ، اس مفروضوں پر اس کا *اثر نہیں* پڑتا ہے جو مرتب کرنے والے اپنے مندرجات کے بارے میں کرتا ہے۔
/// مثال کے طور پر ،`ManuallyDrop<&mut T>` کو [`mem::zeroed`] کے ساتھ شروع کرنا غیر متعینہ رویہ ہے۔
/// اگر آپ کو غیر شناختی ڈیٹا کو ہینڈل کرنے کی ضرورت ہے تو ، اس کے بجائے [`MaybeUninit<T>`] استعمال کریں۔
///
/// نوٹ کریں کہ `ManuallyDrop<T>` کے اندر قیمت تک رسائی محفوظ ہے۔
/// اس کا مطلب یہ ہے کہ ایک `ManuallyDrop<T>` جس کا مواد گرا دیا گیا ہے اسے عوامی محفوظ API کے ذریعہ بے نقاب نہیں کیا جانا چاہئے۔
/// اسی کے مطابق ، `ManuallyDrop::drop` غیر محفوظ ہے۔
///
/// # `ManuallyDrop` اور ڈراپ آرڈر۔
///
/// Rust میں قدروں کی ایک بہتر وضاحت شدہ [drop order] ہے۔
/// یہ یقینی بنانے کے لئے کہ کھیتوں یا مقامی افراد کو ایک خاص ترتیب میں گرا دیا گیا ہے ، اعلامیوں کو اس طرح ترتیب دیں کہ ڈراپ آرڈر صحیح ہے۔
///
/// ڈراپ آرڈر کو کنٹرول کرنے کے لئے `ManuallyDrop` کا استعمال کرنا ممکن ہے ، لیکن اس کے لئے غیر محفوظ کوڈ کی ضرورت ہوتی ہے اور ناپسند کی موجودگی میں صحیح طریقے سے کرنا مشکل ہے۔
///
///
/// مثال کے طور پر ، اگر آپ یہ یقینی بنانا چاہتے ہیں کہ دوسروں کے بعد کسی مخصوص فیلڈ کو گرا دیا گیا ہو ، تو اسے کسی ڈھانچے کا آخری فیلڈ بنائیں:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` کے بعد گرا دیا جائے گا۔
///     // Rust ضمانت دیتا ہے کہ اعلامیے کی ترتیب میں کھیتوں کو چھوڑ دیا گیا ہے۔
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// دستی طور پر گرانے والی ایک لپیٹ۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // آپ اب بھی قدر پر محفوظ طریقے سے کام کرسکتے ہیں
    /// assert_eq!(*x, "Hello");
    /// // لیکن `Drop` یہاں نہیں چلائے جائیں گے
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` کنٹینر سے قیمت نکالتا ہے۔
    ///
    /// اس سے دوبارہ قیمت کو گرایا جاسکتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // یہ `Box` گرتا ہے۔
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` کنٹینر سے قیمت لے لیتا ہے۔
    ///
    /// یہ طریقہ بنیادی طور پر اقدار کو چھوڑنے کے ل moving ہے۔
    /// دستی طور پر قیمت گرانے کے لئے [`ManuallyDrop::drop`] کا استعمال کرنے کے بجائے ، آپ اس طریقہ کار کو قیمت لینے کے ل use اور اس کی خواہش کے مطابق استعمال کرسکتے ہیں۔
    ///
    /// جب بھی ممکن ہو تو ، اس کی بجائے [`into_inner`][`ManuallyDrop::into_inner`] استعمال کرنا افضل ہے ، جو `ManuallyDrop<T>` کے مواد کو نقل سے روکتا ہے۔
    ///
    ///
    /// # Safety
    ///
    /// اس فنکشن نے بغیر کسی استعمال کی روک تھام کے اپنے اندر موجود قیمت کو بغیر کسی رکاوٹ کے ، متحرک طور پر منتقل کردیا ہے۔
    /// یہ آپ کی ذمہ داری ہے کہ اس بات کو یقینی بنائیں کہ یہ `ManuallyDrop` دوبارہ استعمال نہیں ہوا ہے۔
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // حفاظت: ہم ایک حوالہ سے پڑھ رہے ہیں ، جس کی ضمانت ہے
        // پڑھنے کے لئے درست ہونا.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// دستی طور پر موجود قدر کو گراتا ہے۔یہ بالکل اسی طرح کے برابر ہے جس میں [`ptr::drop_in_place`] پر مشتمل قیمت کے پوائنٹر کے ساتھ کال کرنا ہے۔
    /// اس طرح ، جب تک موجود قدر ایک بھری ہوئی ڈھانچہ نہیں ہے ، تبتقریب کو قدر کو منتقل کیے بغیر جگہ جگہ بلایا جائے گا ، اور اس طرح [pinned] ڈیٹا کو محفوظ طریقے سے چھوڑنے کے لئے استعمال کیا جاسکتا ہے۔
    ///
    /// اگر آپ کے پاس قدر کی ملکیت ہے تو ، آپ اس کے بجائے [`ManuallyDrop::into_inner`] استعمال کرسکتے ہیں۔
    ///
    /// # Safety
    ///
    /// یہ فنکشن موجود قدر کو ختم کرنے والا چلاتا ہے۔
    /// خود ڈسٹرکٹر کی طرف سے کی گئی تبدیلیوں کے علاوہ ، میموری کو کوئی بدلاؤ نہیں چھوڑ دیا جاتا ہے ، اور اسی طرح جہاں تک کمپائلر کا تعلق ہے وہ ابھی بھی تھوڑا سا نمونہ رکھتا ہے جو `T` قسم کے لئے موزوں ہے۔
    ///
    ///
    /// تاہم ، اس "zombie" قدر کو محفوظ کوڈ کے سامنے نہیں آنا چاہئے ، اور اس فنکشن کو ایک سے زیادہ مرتبہ نہیں کہا جانا چاہئے۔
    /// کسی قدر کو گرانے کے بعد اسے استعمال کرنے کے ل or ، یا ایک سے زیادہ بار قدر گرنے سے ، غیر متعین طرز عمل کا سبب بن سکتا ہے (`drop` کیا کرتا ہے اس پر منحصر ہے)۔
    /// عام طور پر اس کو ٹائپ سسٹم کے ذریعہ روکا جاتا ہے ، لیکن `ManuallyDrop` کے صارفین کو لازمی طور پر ان گارنٹیوں کو مرتب کرنے والے کی مدد کے بغیر برقرار رکھنا چاہئے۔
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // حفاظت: ہم ایک بدلتے ہوئے حوالہ کی طرف اشارہ کردہ قیمت کو چھوڑ رہے ہیں
        // جو تحریروں کے لئے موزوں ہونے کی ضمانت ہے۔
        // فون کرنے والے پر منحصر ہے کہ اس بات کو یقینی بنائے کہ `slot` دوبارہ نہیں گرا ہے۔
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}