//! میموری سے نمٹنے کے لئے بنیادی افعال۔
//!
//! اس ماڈیول میں اقسام کے سائز اور سیدھ کے بارے میں سوالات کرنے ، میموری کو ابتدا اور جوڑتوڑ کرنے کے افعال شامل ہیں۔
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **اس کے ڈسٹرکٹر کو چلانے کے بغیر** قیمت کے بارے میں ملکیت اور "forgets" لیتا ہے۔
///
/// کوئی وسائل جو قدر کا انتظام کرتے ہیں ، جیسے ہیپ میموری یا فائل ہینڈل ، ناقابل رسائ حالت میں ہمیشہ کے لئے رہتا ہے۔تاہم ، اس کی ضمانت نہیں ہے کہ اس میموری کی طرف اشارہ کرنے والے درست رہیں گے۔
///
/// * اگر آپ میموری کو لیک کرنا چاہتے ہیں تو ، [`Box::leak`] دیکھیں۔
/// * اگر آپ میموری کا خام پوائنٹر حاصل کرنا چاہتے ہیں تو ، [`Box::into_raw`] دیکھیں۔
/// * اگر آپ کسی قدر کو ٹھیک طرح سے ضائع کرنا چاہتے ہیں تو اس کے ڈسٹریکٹر کو چلا رہے ہیں تو ، [`mem::drop`] دیکھیں۔
///
/// # Safety
///
/// `forget` `unsafe` کے بطور نشان زد نہیں ہے ، کیوں کہ Rust کی حفاظت کی گارنٹیوں میں اس بات کی گارنٹی شامل نہیں ہے کہ تباہ کن ہمیشہ چلائے گا۔
/// مثال کے طور پر ، ایک پروگرام [`Rc`][rc] کا استعمال کرتے ہوئے ایک حوالہ سائیکل تشکیل دے سکتا ہے ، یا [`process::exit`][exit] کو ڈسٹرکٹور چلائے بغیر باہر نکلنے کے لئے کال کرسکتا ہے۔
/// اس طرح ، `mem::forget` کو سیف کوڈ سے اجازت دینے سے Rust کی حفاظت کی ضمانتیں بنیادی طور پر تبدیل نہیں ہوتی ہیں۔
///
/// اس نے کہا ، میموری یا I/O آبجیکٹ جیسے وسائل کا اخراج عام طور پر ناپسندیدہ ہے۔
/// ضرورت ایف ایف آئی یا غیر محفوظ کوڈ کے ل use کچھ خصوصی استعمال کے معاملات میں بھی سامنے آتی ہے ، لیکن اس کے باوجود بھی ، [`ManuallyDrop`] عام طور پر ترجیح دی جاتی ہے۔
///
/// چونکہ کسی قدر کو فراموش کرنے کی اجازت ہے ، لہذا جو بھی `unsafe` کوڈ آپ لکھتے ہیں اسے اس امکان کے ل allow اجازت دینا ہوگی۔آپ کوئی قیمت واپس نہیں کرسکتے ہیں اور توقع نہیں کرسکتے ہیں کہ کال کرنے والا لازمی طور پر قیمت کو تباہ کرنے والا چلائے گا۔
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` کا عمومی محفوظ استعمال `Drop` trait کے ذریعہ کسی قدر کے ڈسٹریکٹر کو نافذ کرنا ہے۔مثال کے طور پر ، یہ ایک `File` لیک کرے گا ، یعنی
/// متغیر کے ذریعہ لی گئی جگہ پر دوبارہ دعویٰ کریں لیکن نظام کے بنیادی وسائل کو کبھی بند نہ کریں:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// یہ مفید ہے جب بنیادی وسائل کی ملکیت اس سے پہلے Rust سے باہر کے کوڈ میں منتقل کردی گئی تھی ، مثال کے طور پر خام فائل ڈسریکٹر کو C کوڈ میں منتقل کرکے۔
///
/// # `ManuallyDrop` کے ساتھ رشتہ ہے
///
/// جبکہ `mem::forget` کو *میموری* کی ملکیت منتقل کرنے کے لئے بھی استعمال کیا جاسکتا ہے ، ایسا کرنا غلطی کا شکار ہے۔
/// [`ManuallyDrop`] اس کے بجائے استعمال کیا جانا چاہئے۔مثال کے طور پر اس کوڈ پر غور کریں:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` کے مشمولات کا استعمال کرکے ایک `v` بنائیں
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` لیک کریں کیونکہ اس کی میموری کو اب `s` کے ذریعہ انتظام کیا گیا ہے
/// mem::forget(v);  // غلطی ، وی غلط ہے اور اسے کسی فنکشن میں منتقل نہیں کیا جانا چاہئے
/// assert_eq!(s, "Az");
/// // `s` واضح طور پر گرا دیا جاتا ہے اور اس کی میموری ختم ہوجاتی ہے۔
/// ```
///
/// مذکورہ بالا مثال کے ساتھ دو امور ہیں۔
///
/// * اگر `String` کی تعمیر اور `mem::forget()` کی درخواست کے درمیان مزید کوڈ شامل کیا گیا ہے تو ، اس میں موجود panic ایک ڈبل فری کا سبب بنے گی کیونکہ اسی میموری کو `v` اور `s` دونوں ہی سنبھال رہے ہیں۔
/// * `v.as_mut_ptr()` پر کال کرنے اور ڈیٹا کی ملکیت کو `s` پر منتقل کرنے کے بعد ، `v` ویلیو غلط ہے۔
/// یہاں تک کہ جب کسی قدر کو صرف `mem::forget` میں منتقل کردیا جاتا ہے (جو اس کا معائنہ نہیں کرے گا) ، کچھ اقسام کی ان کی اقدار پر سخت تقاضے ہوتے ہیں جو مسخ ہونے پر یا اس کی ملکیت نہیں ہونے پر اسے ناجائز قرار دیتے ہیں۔
/// کسی بھی طرح سے غلط اقدار کا استعمال کرنا ، بشمول انہیں افعال سے واپس کرنا یا ان کو واپس کرنا ، غیر وضاحتی سلوک کو تشکیل دیتا ہے اور مرتب کرنے والے کے ذریعہ کی گئی مفروضوں کو توڑ سکتا ہے۔
///
/// `ManuallyDrop` پر سوئچ کرنا دونوں امور سے گریز کرتا ہے:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // اس سے پہلے کہ ہم `v` کو اس کے خام حصوں میں جدا کریں ، اس بات کو یقینی بنائیں کہ اسے گرایا نہ جائے!
/////
/// let mut v = ManuallyDrop::new(v);
/// // اب `v` کو جدا کریں۔یہ کاروائیاں panic نہیں کر سکتی ہیں ، لہذا وہاں رساو نہیں ہوسکتا ہے۔
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // آخر میں ، ایک `String` بنائیں۔
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` واضح طور پر گرا دیا جاتا ہے اور اس کی میموری ختم ہوجاتی ہے۔
/// ```
///
/// `ManuallyDrop` مضبوطی سے ڈبل فری کو روکتا ہے کیونکہ ہم کچھ بھی کرنے سے پہلے `v` کے ڈسٹرکٹر کو غیر فعال کردیتے ہیں۔
/// `mem::forget()` اس کی اجازت نہیں دیتا ہے کیونکہ یہ اپنی دلیل کو کھا جاتا ہے ، اور ہمیں `v` سے ہماری ضرورت کی کوئی چیز نکالنے کے بعد ہی اسے فون کرنے پر مجبور کرتا ہے۔
/// یہاں تک کہ اگر ایک panic `ManuallyDrop` کی تعمیر اور اسٹرنگ کی تعمیر کے مابین متعارف کرایا گیا تھا (جو ظاہر کردہ کوڈ میں نہیں ہوسکتا ہے) ، اس کا نتیجہ لیک ہوجائے گا اور ڈبل فری نہیں ہوگا۔
/// دوسرے لفظوں میں ، `ManuallyDrop` (ڈبل) ڈراپنگ کی طرف گمراہ ہونے کے بجائے لیک ہونے کی وجہ سے غلطی کرتا ہے۔
///
/// نیز ، `ManuallyDrop` `s` کو ملکیت منتقل کرنے کے بعد "touch" `v` کرنے سے روکتا ہے-اس کے ڈسٹرکٹر کو چلائے بغیر اسے ٹھکانے لگانے کے لئے `v` کے ساتھ بات چیت کا حتمی مرحلہ پوری طرح سے گریز کیا جاتا ہے۔
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] کی طرح ، بلکہ غیر منقولہ اقدار کو بھی قبول کرتا ہے۔
///
/// جب یہ `unsized_locals` خصوصیت مستحکم ہو جاتی ہے تو اس فنکشن کو ہٹانے کا ارادہ کیا جاتا ہے۔
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// بائٹس میں ایک قسم کا سائز لوٹاتا ہے۔
///
/// مزید خاص طور پر ، اس صف میں لگاتار عناصر کے مابین بائٹس میں آفسیٹ ہوتا ہے جس میں اس شے کی قسم شامل ہوتی ہے جس میں سیدھ کی بھرتی شامل ہوتی ہے۔
///
/// اس طرح ، کسی بھی قسم کی `T` اور لمبائی `n` کے لئے ، `[T; n]` کی سائز `n * size_of::<T>()` ہے۔
///
/// عام طور پر ، کسی قسم کا سائز تالیفوں میں مستحکم نہیں ہوتا ہے ، لیکن مخصوص قسمیں جیسے قدیم ہیں۔
///
/// مندرجہ ذیل ٹیبل آدمیوں کے لئے سائز پیش کرتی ہے۔
///
/// قسم |کا سائز: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 ایکس02 ایکس |4 ایکس03 ایکس |8 u128 |16 ایکس04 ایکس |1 i16 |2 ایکس06 ایکس |4 ایکس07 ایکس |8 آئی 128 |16 ایکس08 ایکس |4 ایکس09 ایکس |8 چار |4
///
/// مزید یہ کہ `usize` اور `isize` ایک ہی سائز کے ہیں۔
///
/// `*const T` ، `&T` ، `Box<T>` ، `Option<&T>` ، اور `Option<Box<T>>` قسمیں ایک جیسے ہیں۔
/// اگر `T` سائز کا ہے تو ، ان تمام اقسام کا سائز `usize` جیسا ہے۔
///
/// پوائنٹر کا بدلنے سے اس کا سائز تبدیل نہیں ہوتا ہے۔اس طرح ، `&T` اور `&mut T` ایک ہی سائز کے ہیں۔
/// اسی طرح `*const T` اور `* mut T` کیلئے۔
///
/// # `#[repr(C)]` آئٹمز کا سائز
///
/// آئٹمز کے لئے `C` نمائندگی کی ایک وضاحتی ترتیب ہے۔
/// اس لے آؤٹ کے ساتھ ، جب تک کہ تمام فیلڈ مستحکم ہوں ، آئٹمز کا سائز بھی مستحکم ہے۔
///
/// ## سختی کا سائز
///
/// `structs` کے لئے ، سائز مندرجہ ذیل الگورتھم کے ذریعہ طے کیا جاتا ہے۔
///
/// ڈھانچے میں ہر فیلڈ کے لئے اعلامیہ آرڈر کے ذریعہ آرڈر دیا گیا ہے:
///
/// 1. کھیت کا سائز شامل کریں۔
/// 2. اگلے فیلڈ کے [alignment] کے قریبی ایک سے زیادہ تک موجودہ حجم کی گول کریں۔
///
/// آخر میں ، ڈھانچے کی جسامت کو اس کے [alignment] کے قریبی ایک سے زیادہ تک گول کردیں۔
/// ڈھانچے کی سیدھ عام طور پر اس کے تمام شعبوں کی سب سے بڑی سیدھ ہوتی ہے۔اسے `repr(align(N))` کے استعمال سے تبدیل کیا جاسکتا ہے۔
///
/// `C` کے برعکس ، صفر کے سائز والے ڈور ایک سائز کے بائٹ تک گول نہیں ہوتے ہیں۔
///
/// ## اینومس کا سائز
///
/// جو اینیمز امتیازی سلوک کے علاوہ کوئی اعداد و شمار نہیں رکھتے ہیں ان کے سائز پلیٹ فارم پر C enums کی طرح ہوتے ہیں جس کے لئے وہ مرتب کیے جاتے ہیں۔
///
/// ## یونینوں کا سائز
///
/// کسی یونین کا سائز اس کے سب سے بڑے فیلڈ کا سائز ہوتا ہے۔
///
/// `C` کے برعکس ، صفر سائز کی یونینیں سائز میں ایک بائٹ تک گول نہیں ہوتی ہیں۔
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // کچھ قدیم
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // کچھ ارے
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // پوائنٹر سائز مساوات
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` استعمال کرنا۔
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // پہلے فیلڈ کا سائز 1 ہے ، لہذا سائز میں 1 شامل کریں۔سائز 1 ہے۔
/// // دوسرے فیلڈ کی سیدھ میں 2 ہے ، لہذا بھرتی کے ل 1 1 سائز میں شامل کریں۔سائز 2 ہے۔
/// // دوسرے فیلڈ کا سائز 2 ہے ، لہذا سائز میں 2 شامل کریں۔سائز 4 ہے۔
/// // تیسرے فیلڈ کی سیدھ 1 ہے ، لہذا بھرتی کے ل for 0 سائز میں شامل کریں۔سائز 4 ہے۔
/// // تیسرے فیلڈ کا سائز 1 ہے ، لہذا سائز میں 1 شامل کریں۔سائز 5 ہے۔
/// // آخر میں ، ڈھانچے کی سیدھ 2 ہے (کیونکہ اس کے کھیتوں میں سب سے بڑی سیدھ 2 ہے) ، لہذا بھرتی کے ل 1 1 سائز میں اضافہ کریں۔
/// // سائز 6 ہے۔
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // ٹوپل سٹرکٹس اسی اصولوں پر عمل پیرا ہیں۔
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // نوٹ کریں کہ کھیتوں کو دوبارہ ترتیب دینے سے سائز کم ہوسکتا ہے۔
/// // ہم X001 سے پہلے `third` رکھ کر دونوں بھرتی بائٹس کو ختم کرسکتے ہیں۔
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // یونین کا سائز سب سے بڑے فیلڈ کا سائز ہے۔
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// بائٹس میں پوائنٹس ٹو ویلیو کا سائز لوٹاتا ہے۔
///
/// یہ عام طور پر `size_of::<T>()` جیسا ہی ہوتا ہے۔
/// تاہم ، جب `T`*کا* کوئی مستحکم سائز نہیں ہوتا ہے ، جیسے ، ایک ٹکڑا [`[T]`][slice] یا [trait object] ، تو متحرک طور پر جانا جاتا سائز حاصل کرنے کے لئے `size_of_val` کا استعمال کیا جاسکتا ہے۔
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // محفوظ: `val` ایک حوالہ ہے ، لہذا یہ ایک درست خام پوائنٹر ہے
    unsafe { intrinsics::size_of_val(val) }
}

/// بائٹس میں پوائنٹس ٹو ویلیو کا سائز لوٹاتا ہے۔
///
/// یہ عام طور پر `size_of::<T>()` جیسا ہی ہوتا ہے۔تاہم ، جب `T`*کا* کوئی مستند طور پر معلوم سائز نہیں ہوتا ہے ، جیسے ، ایک ٹکڑا [`[T]`][slice] یا [trait object] ، تو متحرک طور پر جانا جاتا سائز حاصل کرنے کے لئے `size_of_val_raw` استعمال کیا جاسکتا ہے۔
///
/// # Safety
///
/// اگر یہ کام مندرجہ ذیل شرائط میں ہیں تو یہ فون صرف محفوظ ہے:
///
/// - اگر `T` `Sized` ہے تو ، یہ فعل کال کرنے کے لئے ہمیشہ محفوظ ہے۔
/// - اگر `T` کی غیر تسلیم شدہ دم ہے:
///     - [slice] ، پھر سلائس دم کی لمبائی ابتدائی عددی عددی ہونی چاہئے ، اور *پوری ویلیو*(متحرک دم کی لمبائی + مستحکم سائز کا سابقہ) `isize` میں فٹ ہونا چاہئے۔
///     - ایک [trait object] ، پھر اس پوائنٹر کے ویٹیبل حصے کو کسی غیر مستحکم زبردستی کے ذریعہ حاصل کردہ ایک درست vtable کی طرف اشارہ کرنا چاہئے ، اور *پوری قیمت*(متحرک دم کی لمبائی + مستحکم سائز کا سابقہ) `isize` میں فٹ ہونا چاہئے۔
///
///     - ایک (unstable) [extern type] ، پھر یہ فنکشن ہمیشہ کال کرنے کے لئے محفوظ ہے ، لیکن panic یا دوسری صورت میں غلط قدر واپس کرسکتا ہے ، کیونکہ بیرونی قسم کی ترتیب معلوم نہیں ہے۔
///     یہ وہی سلوک ہے جو [`size_of_val`] کی طرح کسی خارجی قسم کی دم کے ساتھ کسی قسم کے حوالے سے ہے۔
///     - بصورت دیگر ، اسے قدامت پسندی سے اس فنکشن کو فون کرنے کی اجازت نہیں ہے۔
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // محفوظ: کال کرنے والے کو لازمی خام پوائنٹر فراہم کرنا ہوگا
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI]-کسی قسم کی مطلوبہ کم سے کم سیدھ کو واپس کرتا ہے۔
///
/// قسم `T` کی قدر کا ہر حوالہ اس تعداد میں ایک سے زیادہ ہونا ضروری ہے۔
///
/// یہ سیدھ ہے جو ڈھانچے کے شعبوں میں استعمال کیا جاتا ہے۔یہ ترجیحی سیدھ سے چھوٹا ہوسکتا ہے۔
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` کی طرف اشارہ کرتے ہوئے اس قدر کی [ABI] کی مطلوبہ کم از کم سیدھ کو لوٹاتا ہے۔
///
/// قسم `T` کی قدر کا ہر حوالہ اس تعداد میں ایک سے زیادہ ہونا ضروری ہے۔
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // حفاظت: ویل ایک حوالہ ہے ، لہذا یہ ایک درست خام پوائنٹر ہے
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI]-کسی قسم کی مطلوبہ کم سے کم سیدھ کو واپس کرتا ہے۔
///
/// قسم `T` کی قدر کا ہر حوالہ اس تعداد میں ایک سے زیادہ ہونا ضروری ہے۔
///
/// یہ سیدھ ہے جو ڈھانچے کے شعبوں میں استعمال کیا جاتا ہے۔یہ ترجیحی سیدھ سے چھوٹا ہوسکتا ہے۔
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` کی طرف اشارہ کرتے ہوئے اس قدر کی [ABI] کی مطلوبہ کم از کم سیدھ کو لوٹاتا ہے۔
///
/// قسم `T` کی قدر کا ہر حوالہ اس تعداد میں ایک سے زیادہ ہونا ضروری ہے۔
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // حفاظت: ویل ایک حوالہ ہے ، لہذا یہ ایک درست خام پوائنٹر ہے
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` کی طرف اشارہ کرتے ہوئے اس قدر کی [ABI] کی مطلوبہ کم از کم سیدھ کو لوٹاتا ہے۔
///
/// قسم `T` کی قدر کا ہر حوالہ اس تعداد میں ایک سے زیادہ ہونا ضروری ہے۔
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// اگر یہ کام مندرجہ ذیل شرائط میں ہیں تو یہ فون صرف محفوظ ہے:
///
/// - اگر `T` `Sized` ہے تو ، یہ فعل کال کرنے کے لئے ہمیشہ محفوظ ہے۔
/// - اگر `T` کی غیر تسلیم شدہ دم ہے:
///     - [slice] ، پھر سلائس دم کی لمبائی ابتدائی عددی عددی ہونی چاہئے ، اور *پوری ویلیو*(متحرک دم کی لمبائی + مستحکم سائز کا سابقہ) `isize` میں فٹ ہونا چاہئے۔
///     - ایک [trait object] ، پھر اس پوائنٹر کے ویٹیبل حصے کو کسی غیر مستحکم زبردستی کے ذریعہ حاصل کردہ ایک درست vtable کی طرف اشارہ کرنا چاہئے ، اور *پوری قیمت*(متحرک دم کی لمبائی + مستحکم سائز کا سابقہ) `isize` میں فٹ ہونا چاہئے۔
///
///     - ایک (unstable) [extern type] ، پھر یہ فنکشن ہمیشہ کال کرنے کے لئے محفوظ ہے ، لیکن panic یا دوسری صورت میں غلط قدر واپس کرسکتا ہے ، کیونکہ بیرونی قسم کی ترتیب معلوم نہیں ہے۔
///     یہ وہی سلوک ہے جو [`align_of_val`] کی طرح کسی خارجی قسم کی دم کے ساتھ کسی قسم کے حوالے سے ہے۔
///     - بصورت دیگر ، اسے قدامت پسندی سے اس فنکشن کو فون کرنے کی اجازت نہیں ہے۔
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // محفوظ: کال کرنے والے کو لازمی خام پوائنٹر فراہم کرنا ہوگا
    unsafe { intrinsics::min_align_of_val(val) }
}

/// اگر `T` قسم کی اقدار کو چھوڑنا ہو تو `true` واپس کرتا ہے۔
///
/// یہ خالصتا an ایک اصلاحی اشارہ ہے ، اور اسے قدامت پسندی سے نافذ کیا جاسکتا ہے:
/// یہ ایسی اقسام کے لئے `true` واپس کرسکتا ہے جنہیں اصل میں گرنے کی ضرورت نہیں ہے۔
/// چونکہ اس طرح ہمیشہ `true` کو لوٹانا اس فنکشن کا درست نفاذ ہوگا۔تاہم ، اگر یہ فنکشن اصل میں `false` کو لوٹاتا ہے ، تو آپ کو یقین ہوسکتا ہے کہ `T` کو چھوڑنے کا کوئی مضر اثر نہیں ہوگا۔
///
/// چیزوں جیسے نچلے درجے پر عمل درآمد ، جن کو دستی طور پر اپنا ڈیٹا ڈراپ کرنے کی ضرورت ہے ، کو اس فنکشن کا استعمال غیر ضروری طور پر اپنے تمام مندرجات کو تباہ ہونے پر چھوڑنے کی کوشش سے بچنے کے ل. استعمال کرنا چاہئے۔
///
/// ممکن ہے اس سے ریلیز کی تعمیر میں فرق نہ پڑے (جہاں ایک لوپ جس میں کوئی ضمنی اثرات نہ ہوں آسانی سے اس کا پتہ لگانے اور اسے ختم کردیا جاتا ہو) ، لیکن اکثر ڈیبگ بلڈز کے لئے یہ ایک بڑی جیت ہوتی ہے۔
///
/// نوٹ کریں کہ [`drop_in_place`] پہلے ہی یہ چیک انجام دیتا ہے ، لہذا اگر آپ کے کام کا بوجھ [`drop_in_place`] کالوں کی کچھ چھوٹی تعداد میں کم ہوسکتا ہے تو ، اس کا استعمال غیر ضروری ہے۔
/// خاص طور پر نوٹ کریں کہ آپ سلائس [`drop_in_place`] کرسکتے ہیں ، اور اس سے تمام اقدار کی جانچ پڑتال کی جاسکتی ہے۔
///
/// Vec جیسے اقسام لہذا `needs_drop` کو واضح طور پر استعمال کیے بغیر صرف `drop_in_place(&mut self[..])`۔
/// دوسری طرف ، [`HashMap`] جیسے اقسام کو ایک وقت میں ایک ایک اقدار کو چھوڑنا پڑتا ہے اور اس API کو استعمال کرنا چاہئے۔
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// یہاں ایک مثال ہے کہ کس طرح ایک مجموعہ `needs_drop` کا استعمال کرسکتا ہے:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ڈیٹا چھوڑیں
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// X-X قسم کی قدر کو زیرو بائٹ نمونہ کے ذریعہ نمائندگی کرتا ہے۔
///
/// اس کا مطلب یہ ہے کہ ، مثال کے طور پر ، `(u8, u16)` میں بھرتی بائٹ کو صفر کرنا ضروری نہیں ہے۔
///
/// اس میں کوئی گارنٹی نہیں ہے کہ تمام صفر بائٹ نمونہ کسی قسم کی `T` کی درست قدر کی نمائندگی کرتا ہے۔
/// مثال کے طور پر ، آل صفر بائٹ پیٹرن حوالہ کی اقسام (`&T` ، `&mut T`) اور افعال اشارے کیلئے ایک درست قدر نہیں ہے۔
/// اس طرح کی اقسام پر `zeroed` کا استعمال فوری طور پر [undefined behavior][ub] کا سبب بنتا ہے کیونکہ [the Rust compiler assumes][inv] کہ متغیر میں ہمیشہ مستند قدر ہوتی ہے جسے ابتدائی سمجھا جاتا ہے۔
///
///
/// اس کا اثر [`MaybeUninit::zeroed().assume_init()`][zeroed] جیسا ہے۔
/// یہ کبھی کبھی FFI کے لئے مفید ہے ، لیکن عام طور پر اس سے پرہیز کیا جانا چاہئے۔
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// اس فنکشن کا درست استعمال: صفر کے ساتھ کسی انٹیجر کا آغاز کرنا۔
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *اس فنکشن کا غلط* استعمال: ایک حوالہ کو صفر سے شروع کرنا۔
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // غیر متعینہ سلوک!
/// let _y: fn() = unsafe { mem::zeroed() }; // اور ایک بار پھر!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینی ہوگی کہ ایک صفر کی قیمت `T` کے لئے درست ہے۔
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// `T` کی قسم کی قدر پیدا کرنے کا بہانہ کرکے بائی پاسز Rust کی معمول کی میموری-ابتدا کی جانچ پڑتال کرتے ہیں ، جبکہ کچھ بھی نہیں کرتے ہیں۔
///
/// **اس فنکشن کو فرسودہ کردیا گیا ہے۔** اس کے بجائے [`MaybeUninit<T>`] استعمال کریں۔
///
/// فرسودگی کی وجہ یہ ہے کہ بنیادی طور پر فنکشن کو صحیح طریقے سے استعمال نہیں کیا جاسکتا: اس کا ایک ہی اثر [`MaybeUninit::uninit().assume_init()`][uninit] ہے۔
///
/// جیسا کہ [`assume_init` documentation][assume_init] وضاحت کرتا ہے ، [the Rust compiler assumes][inv] جو قدروں کو مناسب طریقے سے شروع کیا جاتا ہے۔
/// نتیجہ کے طور پر ، کال کرنا جیسے
/// `mem::uninitialized::<bool>()` `bool` کو واپس کرنے کے ل immediate فوری غیر متعینہ سلوک کا سبب بنتا ہے جو یقینی طور پر یا تو `true` یا `false` نہیں ہے۔
/// اس سے بھی بدتر بات یہ ہے کہ واقعی غیر منطقی میموری جیسی واپس آجاتی ہے اس میں یہ خاص ہے کہ مرتب کرنے والا جانتا ہے کہ اس کی کوئی مقررہ قیمت نہیں ہے۔
/// اس سے یہ متغیر میں غیر اعلانیہ ڈیٹا رکھنا غیر متعینہ سلوک بنتا ہے یہاں تک کہ اگر اس متغیر کی عددی قسم ہو۔
/// (نوٹس کریں کہ انٹریٹلیٹائزڈ انٹیجر کے ارد گرد کے قواعد کو ابھی تک حتمی شکل نہیں دی گئی ہے ، لیکن جب تک یہ نہیں ہوجاتے ہیں ، ان سے پرہیز کرنے کا مشورہ دیا جاتا ہے۔)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ ایک یونٹائزڈ ویلیو `T` کے لئے درست ہے۔
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// دونوں میں سے کسی ایک کو بھی غیر منطبع کیے بغیر ، دو تبدیل ہونے والے مقامات پر اقدار کو بدل دیتا ہے۔
///
/// * اگر آپ کسی ڈیفالٹ یا ڈمی قدر کے ساتھ تبادلہ کرنا چاہتے ہیں تو ، [`take`] دیکھیں۔
/// * اگر آپ کسی قدیم قیمت کو واپس کرتے ہوئے ، قدیم قیمت کو واپس کرنا چاہتے ہیں تو ، [`replace`] دیکھیں۔
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // حفاظت: خام پوائنٹر محفوظ تبادلہ خیالات سے تیار کیے گئے ہیں جو تمام کو مطمئن کرتے ہیں
    // `ptr::swap_nonoverlapping_one` پر پابندیاں
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` کو `T` کی پہلے سے طے شدہ قدر کے ساتھ بدل دیتا ہے ، پچھلی `dest` قدر کو لوٹاتا ہے۔
///
/// * اگر آپ دو متغیرات کی اقدار کو تبدیل کرنا چاہتے ہیں تو ، [`swap`] دیکھیں۔
/// * اگر آپ پہلے سے طے شدہ قیمت کے بجائے منظور شدہ قیمت سے تبدیل کرنا چاہتے ہیں تو ، [`replace`] دیکھیں۔
///
/// # Examples
///
/// ایک سادہ مثال:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` کسی "empty" قدر کی جگہ لے کر کسی اسٹرک فیلڈ کی ملکیت لینے کی اجازت دیتا ہے۔
/// `take` کے بغیر آپ ان جیسے ایشوز میں حصہ لے سکتے ہیں۔
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// نوٹ کریں کہ `T` لازمی طور پر [`Clone`] لاگو نہیں کرتا ہے ، لہذا یہ `self.buf` کو کلون اور دوبارہ سیٹ بھی نہیں کرسکتا ہے۔
/// لیکن `take` کا استعمال `self.buf` کی اصل قدر کو `self` سے الگ کرنے کے ل can ، اسے واپس کرنے کی اجازت دی جاسکتی ہے:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` کو حوالہ `dest` میں منتقل کرتا ہے ، پچھلی `dest` قدر کو لوٹاتا ہے۔
///
/// نہ ہی قیمت گرا دی گئی ہے۔
///
/// * اگر آپ دو متغیرات کی اقدار کو تبدیل کرنا چاہتے ہیں تو ، [`swap`] دیکھیں۔
/// * اگر آپ پہلے سے طے شدہ قدر کے ساتھ تبدیل کرنا چاہتے ہیں تو ، [`take`] دیکھیں۔
///
/// # Examples
///
/// ایک سادہ مثال:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` اسٹرکٹ فیلڈ کو کسی اور ویلیو کی جگہ لے کر کھپت کرنے کی اجازت دیتا ہے۔
/// `replace` کے بغیر آپ ان جیسے ایشوز میں حصہ لے سکتے ہیں۔
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// نوٹ کریں کہ `T` ضروری طور پر [`Clone`] لاگو نہیں کرتا ہے ، لہذا ہم اس اقدام سے بچنے کے لئے `self.buf[i]` بھی کلون نہیں کرسکتے ہیں۔
/// لیکن `replace` کو اس انڈیکس میں اصل قدر کو `self` سے الگ کرنے کے لئے استعمال کیا جاسکتا ہے ، اسے واپس کرنے کی اجازت:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // محفوظ کریں: ہم `dest` سے پڑھتے ہیں لیکن اس کے بعد براہ راست `src` لکھیں ،
    // اس طرح کہ پرانی قیمت نقل نہیں ہے۔
    // کچھ بھی نہیں گرایا جاتا ہے اور یہاں کچھ بھی panic نہیں کرسکتا ہے۔
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// ایک قیمت کو ضائع کرنا
///
/// یہ دلیل کے [`Drop`][drop] پر عمل درآمد کا مطالبہ کرکے ایسا کرتا ہے۔
///
/// یہ مؤثر طریقے سے ایسی اقسام کے لئے کچھ نہیں کرتا جو `Copy` کو نافذ کرتی ہے ، جیسے
/// integers.
/// اس طرح کی اقدار کاپی کی جاتی ہیں اور _then_ کو فنکشن میں منتقل کردیا جاتا ہے ، لہذا اس فنکشن کال کے بعد ویلیو برقرار رہتی ہے۔
///
///
/// یہ فنکشن جادو نہیں ہے۔یہ لفظی طور پر بیان کیا گیا ہے
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// چونکہ `_x` کو فنکشن میں منتقل کردیا گیا ہے ، لہذا یہ فنکشن واپس آنے سے پہلے خود بخود گرا دیا جاتا ہے۔
///
/// [drop]: Drop
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector کو واضح طور پر چھوڑیں
/// ```
///
/// چونکہ [`RefCell`] رن وقت کے وقت قرض لینے کے قواعد کو نافذ کرتا ہے ، لہذا `drop` [`RefCell`] قرض جاری کرسکتا ہے:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // اس سلاٹ پر متغیر قرض سے دستبرداری کریں
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] پر عمل درآمد کرنے والے انٹیجرز اور دیگر اقسام `drop` سے متاثر نہیں ہوتے ہیں۔
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` کی ایک کاپی منتقل اور گرا دی گئی ہے
/// drop(y); // `y` کی ایک کاپی منتقل اور گرا دی گئی ہے
///
/// println!("x: {}, y: {}", x, y.0); // ابھی تک دستیاب
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` کی قسم `&U` ہونے کی ترجمانی کرتا ہے ، اور پھر بغیر موجود قدر کو آگے بڑھے بغیر `src` پڑھتا ہے۔
///
/// یہ فنکشن غیر محفوظ طور پر فرض کرے گا کہ `src` `&T` کو `&U` میں تبدیل کرکے اور پھر `&U` کو پڑھ کر [`size_of::<U>`][size_of] بائٹس کے لئے `src` درست ہے (سوائے اس کے کہ یہ اس طریقے سے کیا گیا ہے جب کہ `&U` `&T` سے سخت سیدھے کی ضروریات کرتا ہے)۔
/// یہ غیر محفوظ طریقے سے `src` سے باہر جانے کے بجائے موجود قدر کی ایک کاپی بھی بنائے گا۔
///
/// اگر یہ `T` اور `U` کے مختلف سائز ہیں تو یہ مرتب شدہ وقت کی غلطی نہیں ہے ، لیکن صرف اس تقریب کو شروع کرنے کی انتہائی حوصلہ افزائی کی جاتی ہے جہاں `T` اور `U` ایک ہی سائز کے ہیں۔اگر `U` `T` سے بڑا ہے تو یہ فنکشن [undefined behavior][ub] کو متحرک کرتا ہے۔
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' سے ڈیٹا کاپی کریں اور اسے 'Foo' کی طرح سلوک کریں
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // کاپی شدہ ڈیٹا میں ترمیم کریں
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' کے مندرجات کو تبدیل نہیں ہونا چاہئے
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // اگر آپ کی سیدھ میں صف بندی کی اعلی ضرورت ہے تو ، src مناسب طریقے سے منسلک نہیں ہوسکتا ہے۔
    if align_of::<U>() > align_of::<T>() {
        // حفاظت: `src` ایک ایسا حوالہ ہے جو پڑھنے کے لئے موزوں ہونے کی ضمانت ہے۔
        // کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ اصل ترسیل محفوظ ہے۔
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // حفاظت: `src` ایک ایسا حوالہ ہے جو پڑھنے کے لئے موزوں ہونے کی ضمانت ہے۔
        // ہم نے ابھی چیک کیا کہ `src as *const U` کو صحیح طریقے سے منسلک کیا گیا ہے۔
        // کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ اصل ترسیل محفوظ ہے۔
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// مبہم قسم انوم کے امتیازی سلوک کی نمائندگی کرتا ہے۔
///
/// مزید معلومات کے ل this اس ماڈیول میں [`discriminant`] فنکشن دیکھیں۔
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. یہ trait نفاذات کو حاصل نہیں کیا جاسکتا ہے کیونکہ ہم ٹی پر کوئی حد نہیں چاہتے ہیں۔

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` میں انوم کی مختلف شکل کی شناخت کرنے والی ایک ایسی قیمت واپس کرتا ہے۔
///
/// اگر `T` انم نہیں ہے تو ، اس فنکشن کو کال کرنے سے غیر وضاحتی سلوک نہیں ہوگا ، لیکن واپسی کی قیمت غیر متعینہ ہے۔
///
///
/// # Stability
///
/// اگر انوم تعریف میں تبدیلی آجائے تو انوم کے فرق کا امتیاز بدل سکتا ہے۔
/// کچھ متغیر کا امتیاز ایک ہی مرتب کرنے والی تالیفوں کے مابین نہیں بدلے گا۔
///
/// # Examples
///
/// اصل اعداد و شمار کو نظرانداز کرتے ہوئے ، اعداد و شمار کو لے جانے والے اناموں کا موازنہ کرنے کے لئے اس کا استعمال کیا جاسکتا ہے:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// اینوم قسم `T` میں مختلف حالتوں کی تعداد لوٹاتا ہے۔
///
/// اگر `T` انم نہیں ہے تو ، اس فنکشن کو کال کرنے سے غیر وضاحتی سلوک نہیں ہوگا ، لیکن واپسی کی قیمت غیر متعینہ ہے۔
/// یکساں طور پر ، اگر `T` `usize::MAX` سے زیادہ مختلف حالتوں والا ایک انوم ہے تو واپسی کی قیمت غیر مخصوص ہے۔
/// غیرآباد قسموں کی گنتی کی جائے گی۔
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}