use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` کی بلا تعل .ق مثالوں کو بنانے کے ل A ایک ریپر کی قسم۔
///
/// # ابتداء ناگوار
///
/// عام طور پر ، مرتب یہ فرض کرتا ہے کہ متغیر کی قسم کی ضروریات کے مطابق ایک متغیر کی ابتداء صحیح طور پر کی جاتی ہے۔مثال کے طور پر ، حوالہ کی قسم کا ایک متغیر ہونا چاہئے اور سیدھا ہونا چاہئے۔
/// یہ ناگوار ہے جسے غیر محفوظ کوڈ میں بھی *ہمیشہ* برقرار رکھنا چاہئے۔
/// نتیجہ کے طور پر ، حوالہ کی قسم کے متغیر کو صفر سے شروع کرنا فوری [undefined behavior][ub] کا سبب بنتا ہے ، چاہے اس حوالہ سے میموری تک رسائی حاصل نہ ہو۔
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // غیر متعینہ سلوک!⚠️
/// // `MaybeUninit<&i32>` کے ساتھ مساوی کوڈ:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // غیر متعینہ سلوک!⚠️
/// ```
///
/// اس کا اختصار مختلف اصلاح کے ل comp مرتب کنندہ کے ذریعہ کیا جاتا ہے ، جیسے رن ٹائم چیکوں کی مدد کرنا اور `enum` لے آؤٹ کو بہتر بنانا۔
///
/// اسی طرح ، پوری طرح انیٹائلیزش میموری میں کوئی بھی مواد ہوسکتا ہے ، جبکہ ایک `false` ہمیشہ `true` یا `false` ہونا چاہئے۔لہذا ، ایک غیر متعل Xق `bool` بنانا غیر متعین سلوک ہے:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // غیر متعینہ سلوک!⚠️
/// // `MaybeUninit<bool>` کے ساتھ مساوی کوڈ:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // غیر متعینہ سلوک!⚠️
/// ```
///
/// مزید یہ کہ ، انیٹینیشنائزڈ میموری خاص ہے اس میں کہ اس کی کوئی مقررہ قیمت نہیں ہے ("fixed" معنی "it won't change without being written to")۔ایک ہی بلاضرورت بائٹ کو متعدد بار پڑھنے سے مختلف نتائج مل سکتے ہیں۔
/// اس سے یہ متغیر میں غیر اعلانیہ ڈیٹا رکھنا غیر متعین سلوک ہوتا ہے یہاں تک کہ اگر اس متغیر کی ایک انٹیجر قسم ہو ، جو دوسری صورت میں کوئی بھی *طے شدہ* بٹ پیٹرن رکھ سکتی ہے۔
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // غیر متعینہ سلوک!⚠️
/// // `MaybeUninit<i32>` کے ساتھ مساوی کوڈ:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // غیر متعینہ سلوک!⚠️
/// ```
/// (نوٹس کریں کہ انٹریٹلیٹائزڈ انٹیجر کے ارد گرد کے قواعد کو ابھی تک حتمی شکل نہیں دی گئی ہے ، لیکن جب تک یہ نہیں ہوجاتے ہیں ، ان سے پرہیز کرنے کا مشورہ دیا جاتا ہے۔)
///
/// اس کے اوپری حصے میں ، یہ یاد رکھیں کہ زیادہ تر اقسام میں اضافی حملہ آور ہوتے ہیں اس سے زیادہ کہ قسم کی سطح پر ابتداء سمجھا جاتا ہے۔
/// مثال کے طور پر ، ایک `1`-ابتدا شدہ [`Vec<T>`] کو ابتدائی سمجھا جاتا ہے (موجودہ عمل کے تحت this یہ مستحکم گارنٹی نہیں تشکیل دیتا ہے) کیونکہ صرف ضرورت جس کے مرتب کرنے والے کو اس کے بارے میں معلوم ہوتا ہے وہ یہ ہے کہ ڈیٹا پوائنٹر غیر کالعدم ہونا چاہئے۔
/// اس طرح کے `Vec<T>` کی تخلیق کرنے سے *فوری* غیر وضاحتی سلوک نہیں ہوتا ہے ، لیکن زیادہ تر محفوظ کاروائیاں (جس میں اسے چھوڑ دینا بھی ہوتا ہے) کے ساتھ غیر وضاحتی رویے کا سبب بنیں گے۔
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` غیر اعداد و شمار کے اعداد و شمار سے نمٹنے کے لئے غیر محفوظ کوڈ کو قابل بناتا ہے۔
/// یہ مرتب کرنے والا ایک اشارہ ہے جس سے یہ ظاہر ہوتا ہے کہ یہاں کے کوائف کو شروع نہیں کیا جاسکتا ہے:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // ایک واضح طور پر غیر ترجیحی حوالہ بنائیں۔
/// // مرتب جانتا ہے کہ `MaybeUninit<T>` کے اندر موجود ڈیٹا غلط ہوسکتا ہے ، اور اس وجہ سے یہ UB نہیں ہے:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // اسے ایک درست قدر پر مقرر کریں۔
/// unsafe { x.as_mut_ptr().write(&0); }
/// // شروع شدہ ڈیٹا کو نکالیں-اس کی اجازت صرف *کے بعد* مناسب طریقے سے `x` کو شروع کرنا ہے!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// تبھی مرتب کرنے والا جانتا ہے کہ اس کوڈ پر کوئی غلط مفروضات اور اصلاح نہیں کی جاسکتی ہے۔
///
/// آپ `MaybeUninit<T>` کے بارے میں `Option<T>` کی طرح سوچ سکتے ہیں لیکن رن ٹائم ٹریکنگ کے بغیر اور بغیر کسی حفاظتی چیک کے۔
///
/// ## out-pointers
///
/// آپ "out-pointers" کو لاگو کرنے کے لئے `MaybeUninit<T>` کا استعمال کرسکتے ہیں: کسی فنکشن سے اعداد و شمار کو واپس کرنے کے بجائے ، نتیجہ کو سامنے رکھنے کے لئے اسے کسی (uninitialized) میموری پر ایک پوائنٹر منتقل کریں۔
/// یہ فائدہ مند ثابت ہوسکتا ہے جب فون کرنے والے کے لئے یہ قابو رکھنا ضروری ہے کہ نتیجہ کس طرح میموری میں محفوظ ہوتا ہے مختص ہوجاتا ہے ، اور آپ غیر ضروری حرکت سے بچنا چاہتے ہیں۔
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` پرانے مندرجات کو نہیں چھوڑتا ، جو اہم ہے۔
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // اب ہم جانتے ہیں کہ `v` کی ابتدا کی گئی ہے!اس سے یہ بھی یقینی بنتا ہے کہ vector مناسب طریقے سے گرا ہوا ہے۔
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## عنصر بہ عنصر ایک صف شروع کرنا
///
/// `MaybeUninit<T>` ایک بڑے سرے عنصر بہ عنصر شروع کرنے کے لئے استعمال کیا جاسکتا ہے:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` کی ایک بلا تعل .ق صف بنائیں۔
///     // `assume_init` محفوظ ہے کیوں کہ جس قسم کے ہم یہاں دعوی کرنے کا دعویٰ کر رہے ہیں وہ `ہو سکتا ہے کہ یونٹ کا ایک گروپ ہے ، جس کو ابتدا کی ضرورت نہیں ہے۔
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // ایک `MaybeUninit` کو چھوڑنا کچھ نہیں کرتا ہے۔
///     // اس طرح `ptr::write` کی بجائے کچی پوائنٹر اسائنمنٹ کا استعمال کرنے سے پرانی بنٹی ہوئی قیمت کو گرانے کا سبب نہیں بنتا ہے۔
/////
///     // نیز اگر اس لوپ کے دوران panic ہوتا ہے تو ، ہمارے پاس میموری لیک ہوجاتا ہے ، لیکن میموری کی حفاظت کا کوئی مسئلہ نہیں ہے۔
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // سب کچھ شروع کیا گیا ہے۔
///     // سرنی کو ابتدائی قسم میں منتقل کریں۔
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// آپ جزوی طور پر شروع کی جانے والی صفوں کے ساتھ بھی کام کر سکتے ہیں ، جو کم سطح کے ڈیٹا سٹرکچر میں پایا جاسکتا ہے۔
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` کی ایک بلا تعل .ق صف بنائیں۔
/// // `assume_init` محفوظ ہے کیوں کہ جس قسم کے ہم یہاں دعوی کرنے کا دعویٰ کر رہے ہیں وہ `ہو سکتا ہے کہ یونٹ کا ایک گروپ ہے ، جس کو ابتدا کی ضرورت نہیں ہے۔
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ہمارے پاس تفویض کردہ عناصر کی تعداد گنیں۔
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // صف میں موجود ہر آئٹم کے ل For ، اگر ہم نے اسے مختص کیا تو چھوڑیں۔
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ایک فیلڈ بہ بہ میدان ایک اسٹارکٹ شروع کرنا
///
/// آپ فیلڈ بذریعہ اسٹریکس فیلڈ شروع کرنے کے لئے `MaybeUninit<T>` ، اور `MaybeUninit<T>` میکرو استعمال کرسکتے ہیں۔
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` فیلڈ کا آغاز ہو رہا ہے
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` فیلڈ کا آغاز کرنا اگر یہاں panic ہے تو ، `name` فیلڈ میں `String` لیک ہوجاتا ہے۔
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // تمام فیلڈز ابتداء میں ہیں ، لہذا ہم ابتدائی فو حاصل کرنے کے لئے `assume_init` پر کال کریں۔
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` جیسا ہی سائز ، سیدھ اور ABI رکھنے کی ضمانت ہے:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// تاہم یاد رکھیں کہ * ایک `MaybeUninit<T>` پر مشتمل ایک قسم ضروری نہیں کہ ایک ہی ترتیب ہو۔Rust عام طور پر اس بات کی ضمانت نہیں دیتا ہے کہ `Foo<T>` کے فیلڈز میں `Foo<U>` جیسا ہی آرڈر ہے چاہے `T` اور `U` ایک ہی سائز اور سیدھ میں ہوں۔
///
/// مزید برآں کیونکہ `MaybeUninit<T>` کے لئے کوئی قدر قدر درست ہے مرتب non-zero/niche-filling کی اصلاح کو لاگو نہیں کرسکتا ہے ، جس کے نتیجے میں بڑے سائز کا امکان ہے:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// اگر `T` FFI محفوظ ہے ، تو `MaybeUninit<T>` بھی ہے۔
///
/// جبکہ `MaybeUninit` `#[repr(transparent)]` ہے (جس سے یہ اشارہ ہوتا ہے کہ وہ اسی سائز ، سیدھ اور ABI کو `T` کی طرح ہے) ، اس سے * کسی بھی سابقہ انتباہ کو تبدیل نہیں کیا جاسکتا ہے۔
/// `Option<T>` اور `Option<MaybeUninit<T>>` میں اب بھی مختلف سائز ہوسکتے ہیں ، اور قسمیں `T` کے فیلڈ پر مشتمل قسمیں (اور سائز) مختلف طریقے سے رکھی جاسکتی ہیں اس کے بجائے اگر یہ فیلڈ `MaybeUninit<T>` ہوتا۔
/// `MaybeUninit` یونین کی قسم ہے ، اور یونینوں میں `#[repr(transparent)]` غیر مستحکم ہے (دیکھیں [the tracking issue](https://github.com/rust-lang/rust/issues/60405))۔
/// وقت گزرنے کے ساتھ ، یونینوں پر `#[repr(transparent)]` کی صحیح ضمانتیں تیار ہوسکتی ہیں ، اور `MaybeUninit` `#[repr(transparent)]` رہ سکتا ہے یا نہیں رہ سکتا ہے۔
/// اس نے کہا ، `MaybeUninit<T>`*ہمیشہ* اس بات کی ضمانت دیتا ہے کہ اس کا سائز ، سیدھ ، اور ABI `T` جیسا ہے۔بس اتنا ہی ہے کہ `MaybeUninit` کے ذریعہ جو ضمانت دیتا ہے اس کا ارتقا ممکن ہے۔
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// لینگ آئٹم تاکہ ہم اس میں دوسری قسمیں لپیٹ سکیں۔یہ جنریٹرز کے لئے مفید ہے۔
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` پر کال نہیں کرنا ، ہم نہیں جان سکتے کہ کیا ہم اس کے لئے کافی ابتداء کر رہے ہیں۔
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// دی گئی قدر کے ساتھ شروع کردہ ایک نیا `MaybeUninit<T>` تخلیق کرتا ہے۔
    /// اس فنکشن کی واپسی قیمت پر [`assume_init`] پر کال کرنا محفوظ ہے۔
    ///
    /// نوٹ کریں کہ `MaybeUninit<T>` کو چھوڑنے سے کبھی بھی `T drop کے ڈراپ کوڈ پر کال نہیں ہوگی۔
    /// یہ یقینی بنانا آپ کی ذمہ داری ہے کہ `T` شروع ہوجائے تو اسے چھوڑ دیا جائے۔
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// غیر متعل .ق حالت میں نیا `MaybeUninit<T>` بناتا ہے۔
    ///
    /// نوٹ کریں کہ `MaybeUninit<T>` کو چھوڑنے سے کبھی بھی `T drop کے ڈراپ کوڈ پر کال نہیں ہوگی۔
    /// یہ یقینی بنانا آپ کی ذمہ داری ہے کہ `T` شروع ہوجائے تو اسے چھوڑ دیا جائے۔
    ///
    /// کچھ مثالوں کے لئے [type-level documentation][MaybeUninit] دیکھیں۔
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// ایک غیر متعل stateق حالت میں ، `MaybeUninit<T>` اشیاء کی ایک نئی صف تیار کریں۔
    ///
    /// Note: future Rust ورژن میں یہ طریقہ غیر ضروری ہوسکتا ہے جب صفی لفظی نحو [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) کی اجازت دیتا ہے۔
    ///
    /// نیچے دی گئی مثال کے بعد `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` استعمال کرسکتی ہے۔
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// اعداد و شمار کا ایک (ممکنہ طور پر چھوٹا) ٹکڑا واپس کرتا ہے جو حقیقت میں پڑھا گیا تھا
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // محفوظ کریں: ایک بنائے ہوئے `[MaybeUninit<_>; LEN]` درست ہے۔
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// `0` بائٹس کے ساتھ میموری کو بھرنے کے ساتھ ، ایک غیر متعل stateق حالت میں نیا `MaybeUninit<T>` بناتا ہے۔یہ `T` پر منحصر ہے چاہے وہ پہلے سے ہی مناسب ابتدا کرے۔
    ///
    /// مثال کے طور پر ، `MaybeUninit<usize>::zeroed()` کی ابتدا کی گئی ہے ، لیکن `MaybeUninit<&'static i32>::zeroed()` ایسا نہیں ہے کیونکہ حوالہ جات کالعدم نہیں ہونا چاہئے۔
    ///
    /// نوٹ کریں کہ `MaybeUninit<T>` کو چھوڑنے سے کبھی بھی `T drop کے ڈراپ کوڈ پر کال نہیں ہوگی۔
    /// یہ یقینی بنانا آپ کی ذمہ داری ہے کہ `T` شروع ہوجائے تو اسے چھوڑ دیا جائے۔
    ///
    /// # Example
    ///
    /// اس فنکشن کا صحیح استعمال: کسی ڈھانچے کو صفر سے شروع کرنا ، جہاں ڈھانچے کے تمام فیلڈ بٹ پیٹرن 0 کو ایک درست قدر کے طور پر روک سکتے ہیں۔
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *اس فعل کا غلط* استعمال: جب `0` قسم کے لئے درست بٹ پیٹرن نہیں ہے تو `x.zeroed().assume_init()` پر کال کرنا:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ایک جوڑے کے اندر ، ہم ایک `NotZero` تیار کرتے ہیں جس میں کوئی معقول امتیازی سلوک نہیں ہوتا ہے۔
    /// // یہ غیر متعین سلوک ہے۔⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // محفوظ: مختص شدہ میموری کی طرف `u.as_mut_ptr()` پوائنٹس۔
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` کی قدر کا تعین کرتا ہے۔
    /// اس سے کسی بھی پچھلی قیمت کو اسے گرائے بغیر ختم کردیتا ہے ، لہذا محتاط رہیں کہ جب تک آپ ڈسٹرکٹر کو چلنا چھوڑنا نہیں چاہتے ہیں تو اس کو دو بار استعمال نہ کریں۔
    ///
    /// آپ کی سہولت کے ل this ، یہ `self` کے (اب محفوظ طریقے سے شروع شدہ) مشمولات کا ایک متغیر حوالہ بھی واپس کرتا ہے۔
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // محفوظ: ہم نے ابھی اس قدر کی ابتدا کی ہے۔
        unsafe { self.assume_init_mut() }
    }

    /// موجود قدر کی نشاندہی کرتا ہے۔
    /// اس نکتے سے پڑھنا یا اسے کسی حوالہ میں تبدیل کرنا غیر متعین سلوک ہے جب تک کہ `MaybeUninit<T>` شروع نہ ہوجائے۔
    /// میموری پر لکھنا کہ یہ پوائنٹر (non-transitively) جس کی طرف اشارہ کرتا ہے غیر متعین سلوک ہے (سوائے ایک `UnsafeCell<T>` کے اندر)۔
    ///
    /// # Examples
    ///
    /// اس طریقے کا درست استعمال:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` میں ایک حوالہ بنائیں۔یہ ٹھیک ہے کیونکہ ہم نے ابتدا کی ہے۔
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *اس طریقہ کا غلط* استعمال:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ہم نے ایک بنائے ہوئے vector کا حوالہ تیار کیا ہے!یہ غیر متعین سلوک ہے۔⚠️
    /// ```
    ///
    /// (نوٹ کریں کہ غیر منقولہ اعداد و شمار کے حوالے کے قواعد کو ابھی حتمی شکل نہیں دی گئی ہے ، لیکن جب تک یہ نہ ہوں تب تک ان سے پرہیز کیا جائے گا۔)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` اور `ManuallyDrop` دونوں `repr(transparent)` ہیں تاکہ ہم پوائنٹر کاسٹ کرسکیں۔
        self as *const _ as *const T
    }

    /// موجود قدر کے لئے ایک متغیر پوائنٹر حاصل کرتا ہے۔
    /// اس نکتے سے پڑھنا یا اسے کسی حوالہ میں تبدیل کرنا غیر متعین سلوک ہے جب تک کہ `MaybeUninit<T>` شروع نہ ہوجائے۔
    ///
    /// # Examples
    ///
    /// اس طریقے کا درست استعمال:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` میں ایک حوالہ بنائیں۔
    /// // یہ ٹھیک ہے کیونکہ ہم نے ابتدا کی ہے۔
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *اس طریقہ کا غلط* استعمال:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ہم نے ایک بنائے ہوئے vector کا حوالہ تیار کیا ہے!یہ غیر متعین سلوک ہے۔⚠️
    /// ```
    ///
    /// (نوٹ کریں کہ غیر منقولہ اعداد و شمار کے حوالے کے قواعد کو ابھی حتمی شکل نہیں دی گئی ہے ، لیکن جب تک یہ نہ ہوں تب تک ان سے پرہیز کیا جائے گا۔)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` اور `ManuallyDrop` دونوں `repr(transparent)` ہیں تاکہ ہم پوائنٹر کاسٹ کرسکیں۔
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` کنٹینر سے قیمت نکالتا ہے۔یہ یقینی بنانے کا ایک زبردست طریقہ ہے کہ اعداد و شمار گرا دی جائیں گے ، کیوں کہ نتیجے میں `T` معمول کے ڈراپ ہینڈلنگ کے تابع ہے۔
    ///
    /// # Safety
    ///
    /// اس بات کی ضمانت دینے والے پر منحصر ہے کہ `MaybeUninit<T>` واقعی ابتدا کی حالت میں ہے۔جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا فوری طور پر غیر وضاحتی رویے کا سبب بنتا ہے۔
    /// [type-level documentation][inv] میں اس ابتداء ناگوار کے بارے میں مزید معلومات ہیں۔
    ///
    /// [inv]: #initialization-invariant
    ///
    /// اس کے اوپری حصے میں ، یہ یاد رکھیں کہ زیادہ تر اقسام میں اضافی حملہ آور ہوتے ہیں اس سے زیادہ کہ قسم کی سطح پر ابتداء سمجھا جاتا ہے۔
    /// مثال کے طور پر ، ایک `1`-ابتدا شدہ [`Vec<T>`] کو ابتدائی سمجھا جاتا ہے (موجودہ عمل کے تحت this یہ مستحکم گارنٹی نہیں تشکیل دیتا ہے) کیونکہ صرف ضرورت جس کے مرتب کرنے والے کو اس کے بارے میں معلوم ہوتا ہے وہ یہ ہے کہ ڈیٹا پوائنٹر غیر کالعدم ہونا چاہئے۔
    ///
    /// اس طرح کے `Vec<T>` کی تخلیق کرنے سے *فوری* غیر وضاحتی سلوک نہیں ہوتا ہے ، لیکن زیادہ تر محفوظ کاروائیاں (جس میں اسے چھوڑ دینا بھی ہوتا ہے) کے ساتھ غیر وضاحتی رویے کا سبب بنیں گے۔
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// اس طریقے کا درست استعمال:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *اس طریقہ کا غلط* استعمال:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ابھی ابتداء نہیں کی گئی تھی ، لہذا اس آخری سطر کی وجہ سے غیر وضاحتی سلوک ہوا۔⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` شروع ہوچکا ہے۔
        // اس کا یہ مطلب بھی ہے کہ `self` `value` مختلف حالت میں ہونا چاہئے۔
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` کنٹینر سے قیمت پڑھتا ہے۔نتیجہ `T` معمول کے ڈراپ ہینڈلنگ کے تابع ہے۔
    ///
    /// جب بھی ممکن ہو تو ، اس کی بجائے [`assume_init`] استعمال کرنا افضل ہے ، جو `MaybeUninit<T>` کے مواد کو نقل سے روکتا ہے۔
    ///
    /// # Safety
    ///
    /// اس بات کی ضمانت دینے والے پر منحصر ہے کہ `MaybeUninit<T>` واقعی ابتدا کی حالت میں ہے۔جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا غیر وضاحتی رویے کا سبب بنتا ہے۔
    /// [type-level documentation][inv] میں اس ابتداء ناگوار کے بارے میں مزید معلومات ہیں۔
    ///
    /// مزید یہ کہ اس میں `MaybeUninit<T>` میں ایک ہی اعداد و شمار کی ایک کاپی رہ جاتی ہے۔
    /// جب اعداد و شمار کی متعدد کاپیاں (ایک بار `assume_init_read` پر کال کرکے ، یا پہلے `assume_init_read` اور پھر [`assume_init`] پر کال کرکے) استعمال کریں ، تو یہ آپ کی ذمہ داری ہے کہ اس بات کو یقینی بنائیں کہ واقعی اعداد و شمار کی نقل ہوسکتی ہے۔
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// اس طریقے کا درست استعمال:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` ہے ، لہذا ہم ایک سے زیادہ بار پڑھ سکتے ہیں۔
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` قدر کی نقل تیار کرنا ٹھیک ہے ، لہذا ہم متعدد بار پڑھ سکتے ہیں۔
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *اس طریقہ کا غلط* استعمال:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // اب ہم نے ایک ہی vector کی دو کاپیاں تیار کیں ، جس سے ڈبل فری ہو! جب وہ دونوں خارج ہوجائیں گی!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` شروع ہوچکا ہے۔
        // `self.as_ptr()` سے پڑھنا محفوظ ہے کیونکہ `self` کو شروع کیا جانا چاہئے۔
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// موجود قدر کو جگہ پر گرادیں۔
    ///
    /// اگر آپ کے پاس `MaybeUninit` کی ملکیت ہے تو ، آپ اس کے بجائے [`assume_init`] استعمال کرسکتے ہیں۔
    ///
    /// # Safety
    ///
    /// اس بات کی ضمانت دینے والے پر منحصر ہے کہ `MaybeUninit<T>` واقعی ابتدا کی حالت میں ہے۔جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// اس کے اوپری حصے میں ، `T` قسم کے تمام اضافی حملہ آوروں کو مطمئن ہونا ضروری ہے ، کیونکہ `T` (یا اس کے ممبران) کے `Drop` نفاذ اس پر بھروسہ کرسکتے ہیں۔
    /// مثال کے طور پر ، ایک `1`-ابتدا شدہ [`Vec<T>`] کو ابتدائی سمجھا جاتا ہے (موجودہ عمل کے تحت this یہ مستحکم گارنٹی نہیں تشکیل دیتا ہے) کیونکہ صرف ضرورت جس کے مرتب کرنے والے کو اس کے بارے میں معلوم ہوتا ہے وہ یہ ہے کہ ڈیٹا پوائنٹر غیر کالعدم ہونا چاہئے۔
    ///
    /// اس طرح کے `Vec<T>` کو گرنا غیر وضاحتی رویے کا سبب بنے گا۔
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // محفوظ: کال کرنے والے کو اس بات کی گارنٹی ضرور دینی چاہئے کہ `self` کی شروعات کی گئی ہے اور
        // `T` کے تمام حملہ آوروں کو مطمئن کرتا ہے۔
        // اگر معاملہ ہے تو جگہ پر گرنا محفوظ ہے۔
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// موجود قدر کا مشترکہ حوالہ ملتا ہے۔
    ///
    /// یہ کارآمد ثابت ہوسکتا ہے جب ہم کسی `MaybeUninit` تک رسائی حاصل کرنا چاہتے ہیں جو ابتداء میں ہوچکا ہے لیکن اس میں `MaybeUninit` کی ملکیت نہیں ہے (`.assume_init()`) کے استعمال کو روکنا ہے۔
    ///
    /// # Safety
    ///
    /// جب مواد کو ابھی تک مکمل طور پر ابتدا نہیں کیا گیا ہے تو اس کو کال کرنا غیر متعینہ رویے کا سبب بنتا ہے: یہ بات کرنے والے پر منحصر ہے کہ `MaybeUninit<T>` واقعی ابتدا کی حالت میں ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ### اس طریقے کا درست استعمال:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` شروع کریں:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // اب چونکہ ہمارا `MaybeUninit<_>` ابتدا میں جانا جاتا ہے ، لہذا اس کا مشترکہ حوالہ بنانا ٹھیک ہے:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // محفوظ: `x` شروع کیا گیا ہے۔
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *غلط* اس طریقہ کار کے استعمال:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ہم نے ایک بنائے ہوئے vector کا حوالہ تیار کیا ہے!یہ غیر متعین سلوک ہے۔⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` کا استعمال کرتے ہوئے `MaybeUninit` کو شروع کریں:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // ایک بنائے ہوئے `Cell<bool>` کا حوالہ: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` شروع ہوچکا ہے۔
        // اس کا یہ مطلب بھی ہے کہ `self` `value` مختلف حالت میں ہونا چاہئے۔
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// موجود قیمت کا ایک متغیر (unique) حوالہ ملتا ہے۔
    ///
    /// یہ کارآمد ثابت ہوسکتا ہے جب ہم کسی `MaybeUninit` تک رسائی حاصل کرنا چاہتے ہیں جو ابتداء میں ہوچکا ہے لیکن اس میں `MaybeUninit` کی ملکیت نہیں ہے (`.assume_init()`) کے استعمال کو روکنا ہے۔
    ///
    /// # Safety
    ///
    /// جب مواد کو ابھی تک مکمل طور پر ابتدا نہیں کیا گیا ہے تو اس کو کال کرنا غیر متعینہ رویے کا سبب بنتا ہے: یہ بات کرنے والے پر منحصر ہے کہ `MaybeUninit<T>` واقعی ابتدا کی حالت میں ہے۔
    /// مثال کے طور پر ،`MaybeUninit` کو `MaybeUninit` شروع کرنے کے لئے استعمال نہیں کیا جاسکتا ہے۔
    ///
    /// # Examples
    ///
    /// ### اس طریقے کا درست استعمال:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ان پٹ بفر کے *تمام* بائٹس کو شروع کرتا ہے۔
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` شروع کریں:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // اب ہم جانتے ہیں کہ `buf` کی شروعات کی گئی ہے ، لہذا ہم اسے `.assume_init()` کرسکتے ہیں۔
    /// // تاہم ، `.assume_init()` کا استعمال 2048 بائٹس میں سے `memcpy` کو متحرک کرسکتا ہے۔
    /// // یہ ثابت کرنے کے لئے کہ ہمارے بفر کو کاپی کیے بغیر شروع کیا گیا ہے ، ہم `&mut MaybeUninit<[u8; 2048]>` کو `&mut [u8; 2048]` میں اپ گریڈ کرتے ہیں:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // محفوظ: `buf` شروع کیا گیا ہے۔
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // اب ہم ایک عام سلائس کے بطور `buf` استعمال کرسکتے ہیں۔
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *غلط* اس طریقہ کار کے استعمال:
    ///
    /// کسی قدر کو شروع کرنے کے لئے آپ `.assume_init_mut()` استعمال نہیں کرسکتے ہیں:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ہم نے ایک بنائے ہوئے `bool` کا (mutable) حوالہ تشکیل دیا ہے!
    ///     // یہ غیر متعین سلوک ہے۔⚠️
    /// }
    /// ```
    ///
    /// مثال کے طور پر ، آپ [`Read`] کو غیر بنائے ہوئے بفر میں نہیں کرسکتے ہیں:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) غیر منسلک میموری کا حوالہ!
    ///                             // یہ غیر متعین سلوک ہے۔
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// اور نہ ہی آپ فیلڈ بذریعہ فیلڈ آہستہ آہستہ ابتدا کرنے کیلئے براہ راست فیلڈ رسائی کا استعمال کرسکتے ہیں:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) غیر منسلک میموری کا حوالہ!
    ///                  // یہ غیر متعین سلوک ہے۔
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) غیر منسلک میموری کا حوالہ!
    ///                  // یہ غیر متعین سلوک ہے۔
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ہم فی الحال مذکورہ بالا کے غلط ہونے پر انحصار کرتے ہیں ، یعنی ہمارے پاس غیرمتعلقہ اعداد و شمار کے حوالہ جات ہیں (جیسے ، `libcore/fmt/float.rs` میں)۔
    // استحکام سے پہلے ہمیں قواعد کے بارے میں کوئی حتمی فیصلہ کرنا چاہئے۔
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `self` شروع ہوچکا ہے۔
        // اس کا یہ مطلب بھی ہے کہ `self` `value` مختلف حالت میں ہونا چاہئے۔
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` کنٹینر کی ایک صف سے قدریں نکالتا ہے۔
    ///
    /// # Safety
    ///
    /// اس بات کی ضمانت دینے والے پر منحصر ہے کہ سرنی کے تمام عناصر ابتدائی حالت میں ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // حفاظت: اب محفوظ ہے جیسا کہ ہم نے تمام عناصر کو شروع کیا
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * کالر اس بات کی ضمانت دیتا ہے کہ سرنی کے تمام عناصر کو ابتداء کر دی گئی ہے
        // * `MaybeUninit<T>` اور ٹی کو ایک ہی ترتیب کی ضمانت دی گئی ہے
        // * ہوسکتا ہے کہ یونٹ نہیں گرتا ، لہذا کوئی ڈبل فری نہیں ہے اور اس طرح تبادلہ محفوظ ہے
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// فرض کریں کہ تمام عناصر ابتدا میں ہیں ، ان میں ایک ٹکڑا حاصل کریں۔
    ///
    /// # Safety
    ///
    /// اس بات کی ضمانت دینے والے پر منحصر ہے کہ `MaybeUninit<T>` عناصر واقعی ابتدا کی حالت میں ہیں۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// مزید تفصیلات اور مثالوں کے لئے [`assume_init_ref`] دیکھیں۔
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // محفوظ: ایک `*const [T]` پر ٹکڑا ڈالنا محفوظ ہے کیونکہ کالر اس کی ضمانت دیتا ہے
        // `slice` ابتدا کی گئی ہے ، اور `MaybeUninit` کی ضمانت ہے کہ وہی ترتیب `T` کی ہے۔
        // حاصل کردہ پوائنٹر درست ہے کیونکہ اس سے مراد `slice` کی ملکیت میموری ہے جو ایک حوالہ ہے اور اس طرح اس کی ضمانت دی جاتی ہے کہ وہ پڑھنے کے لئے موزوں ہوں۔
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// یہ فرض کرتے ہوئے کہ تمام عناصر ابتدا میں ہیں ، ان میں تبدیلی کا ٹکڑا حاصل کریں۔
    ///
    /// # Safety
    ///
    /// اس بات کی ضمانت دینے والے پر منحصر ہے کہ `MaybeUninit<T>` عناصر واقعی ابتدا کی حالت میں ہیں۔
    ///
    /// جب مواد ابھی پوری طرح سے شروع نہیں ہوا ہے تو اس کو کال کرنا غیر وضاحتی رویے کا سبب بنتا ہے۔
    ///
    /// مزید تفصیلات اور مثالوں کے لئے [`assume_init_mut`] دیکھیں۔
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // حفاظت: `slice_get_ref` کے حفاظتی نوٹوں کی طرح ، لیکن ہمارے پاس ایک ہے
        // بدلنے والا حوالہ جو تحریروں کے لئے بھی درست ہونے کی ضمانت ہے۔
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// سرنی کے پہلے عنصر کی طرف اشارہ ملتا ہے۔
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// سرنی کے پہلے عنصر کی طرف بدلاؤ کا اشارہ ملتا ہے۔
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` سے `this` پر عناصر کی کاپی کرتا ہے ، `this` کے اب انیجلیٹڈ ماد toوں کا ایک تغیر پذیر حوالہ واپس کرتا ہے۔
    ///
    /// اگر `T` `Copy` پر عمل درآمد نہیں کرتا ہے تو ، [`write_slice_cloned`] استعمال کریں
    ///
    /// یہ [`slice::copy_from_slice`] کی طرح ہے۔
    ///
    /// # Panics
    ///
    /// اگر یہ دونوں ٹکڑوں کی لمبائی مختلف ہیں تو یہ فنکشن panic کرے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // محفوظ کریں: ہم نے صرف لین کے تمام عناصر کو اسپیئر گنجائش میں کاپی کیا ہے
    /// // Vec کے پہلے src.len() عنصر ابھی درست ہیں۔
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // حفاظت: &[T] اور&[شایدUninit<T>] ایک ہی ترتیب ہے
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // محفوظ کریں: درست عنصروں کو ابھی `this` میں کاپی کیا گیا ہے لہذا اس کی نشاندہی کی جائے
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` سے `this` تک کے عناصر کا کلون کرتا ہے ، `this` کے اب انیجلیٹڈ ماد toوں کے متغیر حوالہ کی واپسی کرتا ہے۔
    /// پہلے سے ہی کسی بھی عناصر کو گرایا نہیں جائے گا۔
    ///
    /// اگر `T` `Copy` لاگو کرتا ہے تو ، [`write_slice`] استعمال کریں
    ///
    /// یہ [`slice::clone_from_slice`] کی طرح ہے لیکن موجودہ عناصر کو نہیں چھوڑتا ہے۔
    ///
    /// # Panics
    ///
    /// اگر یہ دونوں ٹکڑوں کی لمبائی مختلف ہیں یا `Clone` panics کا نفاذ ہے تو یہ فنکشن panic کرے گا۔
    ///
    /// اگر وہاں panic ہے تو پہلے ہی کلونڈ عناصر کو گرا دیا جائے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // حفاظت: ہم نے فالتوکی کی صلاحیت میں لین کے تمام عناصر کو کلون کیا ہے
    /// // Vec کے پہلے src.len() عنصر ابھی درست ہیں۔
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice کے برعکس اس ٹکڑے پر clone_from_slice نہیں کہتے ہیں کیونکہ یہ `MaybeUninit<T: Clone>` کلون کو لاگو نہیں کرتا ہے۔
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // محفوظ: اس خام ٹکڑے میں صرف ابتدائی اشیاء شامل ہوں گی
                // اسی لئے ، اسے چھوڑنے کی اجازت ہے۔
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: ہمیں انہیں واضح طور پر ایک ہی لمبائی میں ٹکڑا کرنے کی ضرورت ہے
        // حد کی جانچ پڑتال کے لئے ، اور آپٹائائزر عام کیسوں (مثال کے طور پر T= u8) کیلئے میمسی پیدا کرے گا۔
        //
        let len = this.len();
        let src = &src[..len];

        // گارڈ کی ضرورت ہے b/c panic ایک کلون کے دوران ہوسکتا ہے
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // محفوظ کریں: ابھی تک درست عنصروں کو `this` لکھا گیا ہے لہذا اس کی نشاندہی کی جائے
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}