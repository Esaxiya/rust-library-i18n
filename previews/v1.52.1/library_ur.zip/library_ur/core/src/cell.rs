//! قابل تبادلہ کنٹینر
//!
//! Rust میموری کی حفاظت اسی اصول پر مبنی ہے: ایک شے `T` کے پیش نظر ، مندرجہ ذیل میں سے کسی ایک کا حاصل کرنا ہی ممکن ہے:
//!
//! - اعتراض کے لئے متعدد ناقابل تذکرہ حوالہ جات (`&T`) ہونے سے (جسے **ایلیسنگ** بھی کہا جاتا ہے)۔
//! - آبجیکٹ کے لئے ایک متغیر حوالہ (`&mut T`)(جس کو **بدلاؤ** بھی کہا جاتا ہے) ہونا۔
//!
//! یہ Rust مرتب کرنے والے کے ذریعہ نافذ ہے۔تاہم ، ایسے حالات موجود ہیں جہاں یہ اصول کافی حد تک لچکدار نہیں ہے۔بعض اوقات اس کی ضرورت ہوتی ہے کہ کسی شے کے متعدد حوالہ جات ہوں اور پھر بھی اس کو تبدیل کریں۔
//!
//! تبادلوں کی موجودگی میں بھی ، قابل تبادلہ تدوین کنٹینر کنٹرول انداز میں اجازت دینے کے لئے موجود ہیں۔[`Cell<T>`] اور [`RefCell<T>`] دونوں ہی اسے ایک ہی تھریڈ والے طریقے سے کرنے کی اجازت دیتے ہیں۔
//! تاہم ، نہ ہی `Cell<T>` اور نہ ہی `RefCell<T>` دھاگے سے محفوظ ہیں (وہ [`Sync`] پر عمل درآمد نہیں کرتے ہیں)۔
//! اگر آپ کو ایک سے زیادہ تھریڈز کے مابین ایلیسنگ اور تغیرات کرنے کی ضرورت ہے تو [`Mutex<T>`] ، [`RwLock<T>`] یا [`atomic`] اقسام کا استعمال ممکن ہے۔
//!
//! `Cell<T>` اور `RefCell<T>` اقسام کی اقدار مشترکہ حوالوں (جیسے) کے ذریعہ تبدیل کی جاسکتی ہیں
//! عام `&T` قسم) ، جبکہ زیادہ تر Rust اقسام کو صرف انوکھا (`&mut T re) حوالہ جات کے ذریعہ تبدیل کیا جاسکتا ہے۔
//! ہم کہتے ہیں کہ `Cell<T>` اور `RefCell<T>` عام طور پر Rust اقسام کے مابین 'داخلی تغیرات' مہیا کرتے ہیں جو 'وراثت میں بدلاؤ' کی نمائش کرتی ہیں۔
//!
//! سیل کی اقسام دو ذائقوں میں آتی ہیں: `Cell<T>` اور `RefCell<T>`۔`Cell<T>` اقدار کو `Cell<T>` میں اور باہر منتقل کرکے داخلی تغیرات کا نفاذ کرتا ہے۔
//! اقدار کی بجائے حوالہ جات کو استعمال کرنے کے ل one ، کسی کو `RefCell<T>` قسم کا استعمال کرنا چاہئے ، تبدیلی کرنے سے پہلے تحریری تالا حاصل کرنا۔`Cell<T>` موجودہ داخلی قیمت کو بازیافت اور تبدیل کرنے کے طریقے مہیا کرتا ہے۔
//!
//!  - ایسی اقسام کے لئے جو [`Copy`] پر عمل درآمد کرتے ہیں ، [`get`](Cell::get) طریقہ موجودہ داخلی قیمت کو بازیافت کرتا ہے۔
//!  - ایسی اقسام کے لئے جو [`Default`] پر عمل درآمد کرتے ہیں ، [`take`](Cell::take) کا طریقہ کار موجودہ داخلی قیمت کو [`Default::default()`] کے ساتھ بدل دیتا ہے اور تبدیل شدہ قیمت کو واپس کرتا ہے۔
//!  - تمام اقسام کے لئے ، [`replace`](Cell::replace) طریقہ موجودہ داخلی قیمت کی جگہ لے لیتا ہے اور تبدیل شدہ قیمت کو واپس کرتا ہے اور [`into_inner`](Cell::into_inner) طریقہ `Cell<T>` کھاتا ہے اور داخلی قیمت واپس کرتا ہے۔
//!  اضافی طور پر ، [`set`](Cell::set) طریقہ داخلہ قیمت کی جگہ لے لیتا ہے ، بدل کی گئی قیمت کو چھوڑ دیتا ہے۔
//!
//! `RefCell<T>` 'متحرک قرضے' کے نفاذ کے لئے Rust کی زندگی بھر کا استعمال ہوتا ہے ، ایک ایسا عمل جس کے تحت کوئی اندرونی قدر تک عارضی ، خصوصی ، متغیر رسائی کا دعویٰ کرسکتا ہے۔
//! `ریفیسیل کے ل. قرض لیتے ہیں<T>Z s کو 'رن ٹائم کے وقت' ٹریک کیا جاتا ہے ، Rust کی مقامی حوالہ اقسام کے برعکس جو مکمل طور پر جامد طور پر ٹریک کیے جاتے ہیں ، مرتب وقت پر۔
//! چونکہ `RefCell<T>` قرضے متحرک ہیں اس لئے ممکن ہے کہ پہلے سے باہمی طور پر قرض لیا گیا ہو ،جب ایسا ہوتا ہے تو اس کا نتیجہ panic میں آجاتا ہے۔
//!
//! # داخلہ بدلنے کا انتخاب کب کریں
//!
//! زیادہ عام طور پر وراثت میں بدلاؤ ، جہاں کسی کو کسی قدر میں تبدیلی کرنے کے ل unique انفرادی رسائی حاصل ہونا ضروری ہے ، زبان کے ایک کلیدی عنصر میں سے ایک Rust کو قابل بناتا ہے کہ پوائنٹر ایلیسائز کے بارے میں سختی سے استدلال کرے ، حادثے کیڑے کو مستقل طور پر روکتا ہے۔
//! اس کی وجہ سے ، وراثت میں بدلاؤ کو ترجیح دی جاتی ہے ، اور داخلی تغیر پذیری آخری حل کی چیز ہے۔
//! چونکہ خلیے کی قسمیں تغیر پزیر کو قابل بناتی ہیں جہاں سے دوسری صورت میں اس کی اجازت نہیں ہوگی ، ایسے مواقع موجود ہیں جب داخلی تغیر مناسب ہوسکتے ہیں ، یا یہاں تک کہ * کا استعمال بھی ضروری ہے ، جیسے۔
//!
//! * غیر منقولہ چیز کا متعارف کرانا 'inside'
//! * منطقی طور پر ناقابل عمل طریقوں کی نفاذ کی تفصیلات۔
//! * [`Clone`] کی تبدیلیوں کو تبدیل کرنا۔
//!
//! ## غیر منقولہ چیز کا متعارف کرانا 'inside'
//!
//! متعدد مشترکہ سمارٹ پوائنٹر اقسام ، بشمول [`Rc<T>`] اور [`Arc<T>`] ، ایسے کنٹینر مہیا کرتے ہیں جن کو کلون کیا جاسکتا ہے اور متعدد فریقوں کے درمیان اشتراک کیا جاسکتا ہے۔
//! چونکہ موجود اقدار ضرب الیاس ہوسکتی ہیں ، لہذا وہ صرف `&` کے ذریعہ قرض لیا جاسکتا ہے ، نہ کہ `&mut`۔
//! سیلوں کے بغیر ان سمارٹ پوائنٹرز کے اندر موجود ڈیٹا کو بالکل تبدیل کرنا ناممکن ہوگا۔
//!
//! بدلاؤ کو دوبارہ پیش کرنے کے لئے مشترکہ پوائنٹر کی اقسام کے اندر `RefCell<T>` ڈالنا پھر بہت عام ہے۔
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // متحرک قرضے کے دائرہ کار کو محدود کرنے کے لئے ایک نیا بلاک بنائیں
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // نوٹ کریں کہ اگر ہم نے کیشے کے پچھلے قرضے کو دائرہ کار سے باہر نہیں جانے دیا تھا تو بعد میں لینا ایک متحرک تھریڈ panic کا سبب بنے گا۔
//!     //
//!     // یہ `RefCell` استعمال کرنے کا سب سے بڑا خطرہ ہے۔
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! نوٹ کریں کہ اس مثال میں `Rc<T>` استعمال کیا گیا ہے ، `Arc<T>` نہیں۔`ریفیل<T>single s سنگل تھریڈڈ منظرناموں کے لئے ہیں۔اگر آپ کو کثیر جہتی صورتحال میں مشترکہ طور پر بدلنے کی ضرورت ہو تو [`RwLock<T>`] یا [`Mutex<T>`] استعمال کرنے پر غور کریں۔
//!
//! ## منطقی طور پر ناقابل عمل طریقوں کی نفاذ کی تفصیلات
//!
//! کبھی کبھار یہ ضروری ہے کہ کسی ایسے API میں یہ نہ ظاہر کرنا پڑے کہ "under the hood" میں اتپریورتن ہو رہی ہے۔
//! اس کی وجہ یہ ہوسکتی ہے کہ منطقی طور پر یہ آپریشن غیر منقولہ ہے ، لیکن مثال کے طور پر ، کیچنگ عمل درآمد کو اتپریورتنما کرنے پر مجبور کرتا ہے۔یا اس وجہ سے کہ آپ کو trait طریقہ کو لاگو کرنے کے لئے اتپریورتن کو ملازمت کرنا لازمی ہے جو `&self` لینے کے لئے اصل میں بیان کیا گیا تھا۔
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // مہنگا حساب کتاب یہاں جاتا ہے
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` کی تبدیلیوں کو تبدیل کرنا
//!
//! یہ صرف ایک خاص ، لیکن عام ، پچھلے کا معاملہ ہے: ان کارروائیوں کے لئے بدلاؤ چھپانا جو غیر منقول دکھائی دیتے ہیں۔
//! توقع کی جاتی ہے کہ [`clone`](Clone::clone) طریقہ کار سے ماخذ کی قیمت کو تبدیل نہیں کیا جائے گا ، اور اعلان کیا گیا ہے کہ `&self` ، `&mut self` نہیں۔
//! لہذا ، `clone` کے طریقہ کار میں پائے جانے والے کسی بھی تغیر کو سیل کی اقسام کا استعمال کرنا چاہئے۔
//! مثال کے طور پر ، [`Rc<T>`] ایک `Cell<T>` میں اپنے حوالہ شمار کو برقرار رکھتا ہے۔
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// ایک متغیر میموری کا مقام۔
///
/// # Examples
///
/// اس مثال میں ، آپ دیکھ سکتے ہیں کہ `Cell<T>` غیر تبدیل شدہ ڈھانچے کے اندر تغیر پزیر کو اہل بناتا ہے۔
/// دوسرے الفاظ میں ، یہ "interior mutability" کو قابل بناتا ہے۔
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // غلطی: `my_struct` ناقابل تبدیلی ہے
/// // my_struct.regular_field =new_value؛
///
/// // کام: اگرچہ `my_struct` ناقابل تبدیلی ہے ، `special_field` ایک `Cell` ہے ،
/// // جو ہمیشہ بدل سکتا ہے
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// مزید کے لئے [module-level documentation](self) دیکھیں۔
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// ٹی کے لئے `Default` قدر کے ساتھ ، ایک `Cell<T>` بناتا ہے۔
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// ایک نیا `Cell` بناتا ہے جس میں دی گئی قیمت شامل ہو۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// موجود قیمت کا تعین کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// دو سیلوں کی قدروں کو تبدیل کرتا ہے۔
    /// `std::mem::swap` کے ساتھ فرق یہ ہے کہ اس فنکشن میں `&mut` حوالہ کی ضرورت نہیں ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // حفاظت: اگر یہ الگ الگ تھریڈز سے منگوایا جاتا ہے تو یہ پرخطر ہوسکتا ہے ، لیکن `Cell`
        // `!Sync` ہے لہذا ایسا نہیں ہوگا۔
        // اس سے کسی بھی نکات کو بھی باطل نہیں کیا جائے گا کیونکہ `Cell` اس بات کو یقینی بناتا ہے کہ ان `سیلز میں سے کسی میں بھی کوئی اور اشارہ نہیں کرے گا۔
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// `val` کے ساتھ موجود قدر کو بدل دیتا ہے ، اور پرانی موجود قدر کو لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // محفوظ کریں: اس سے اعداد و شمار کی دوڑ کا سبب بن سکتا ہے اگر کسی الگ تھریڈ سے کہا گیا ہے ،
        // لیکن `Cell` `!Sync` ہے لہذا ایسا نہیں ہوگا۔
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// قدر کو کھولنا۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// موجود قدر کی ایک کاپی لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // محفوظ کریں: اس سے اعداد و شمار کی دوڑ کا سبب بن سکتا ہے اگر کسی الگ تھریڈ سے کہا گیا ہے ،
        // لیکن `Cell` `!Sync` ہے لہذا ایسا نہیں ہوگا۔
        unsafe { *self.value.get() }
    }

    /// فنکشن کا استعمال کرتے ہوئے موجود قدر کو اپ ڈیٹ کرتا ہے اور نئی ویلیو واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// اس سیل میں بنیادی اعداد و شمار کے لئے ایک خام پوائنٹر لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// بنیادی اعداد و شمار کا ایک متغیر حوالہ واپس کرتا ہے۔
    ///
    /// اس کال نے `Cell` کو باہمی طور پر (مرتب وقت) قرض لیا ہے جو اس بات کی ضمانت دیتا ہے کہ ہمارے پاس صرف حوالہ موجود ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` سے `&Cell<T>` لوٹاتا ہے
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // محفوظ: `&mut` منفرد رسائی کو یقینی بناتا ہے۔
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// `Default::default()` کو اپنی جگہ چھوڑ کر سیل کی قدر لیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` سے `&[Cell<T>]` لوٹاتا ہے
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // محفوظ: `Cell<T>` کے پاس `T` جیسی میموری ترتیب ہے۔
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// متحرک میموری کے مقام پر متحرک طور پر چیک کیے گئے قرض کے قواعد
///
/// مزید کے لئے [module-level documentation](self) دیکھیں۔
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] کے ذریعہ ایک خامی لوٹ آئی۔
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] کے ذریعہ ایک خامی لوٹ آئی۔
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// مثبت اقدار فعال `Ref` کی تعداد کی نمائندگی کرتے ہیں۔منفی قدریں فعال `RefMut` کی تعداد کی نمائندگی کرتی ہیں۔
// ایک سے زیادہ `ریف میٹس صرف ایک وقت میں متحرک ہوسکتے ہیں اگر وہ ایک `RefCell` (جیسے ، ٹکڑے کے مختلف حدود) کے الگ الگ ، نانو لیپٹنگ اجزاء کا حوالہ دیتے ہیں۔
//
// `Ref` اور `RefMut` دونوں سائز کے دو الفاظ ہیں ، اور اس ل likely امکان ہے کہ کبھی بھی `usize` کی حد کے آدھے بہاؤ کے ل enough کافی `ریفریز یا` ریف می`س وجود میں نہ ہوں۔
// اس طرح ، ایک `BorrowFlag` شاید کبھی بہاو یا زیر بہاؤ نہیں ہوگا۔
// تاہم ، اس کی ضمانت نہیں ہے ، کیونکہ ایک روگولوجیکل پروگرام بار بار تشکیل دے سکتا ہے اور پھر mem::forget `ریفریز یا` ریف میٹس۔
// اس طرح ، کسی بھی طرح سے بچنے کے ل to ، تمام کوڈ کو واضح طور پر اوور فلو اور انڈر فلو کی جانچ پڑتال کرنی ہوگی ، یا اس واقعے میں کم سے کم صحیح طور پر برتاؤ کرنا چاہ over کہ بہاو یا زیر بہاو واقع ہوجائے (جیسے ، دیکھیں BorrowRef::new)
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` پر مشتمل ایک نیا `RefCell` بناتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// لپیٹی ہوئی قیمت لوٹاتے ہوئے ، `RefCell` استعمال کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // چونکہ یہ فنکشن `self` (`RefCell`) قدر کے لحاظ سے لیتا ہے ، مرتب اعدادوشمار کی تصدیق کرتا ہے کہ یہ فی الحال قرض نہیں لیا گیا ہے۔
        //
        self.value.into_inner()
    }

    /// لپیٹے ہوئے قدر کو ایک نئے سے بدل دیتا ہے ، پرانا ویلیو لوٹاتا ہے ، جس میں سے کسی کو بھی بغیر تشخیص کیے رکھا جاتا ہے۔
    ///
    ///
    /// یہ فنکشن [`std::mem::replace`](../mem/fn.replace.html) کے مساوی ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر قیمت فی الحال ادھار لی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// لپیٹے ہوئے قدر کی جگہ `f` سے کسی نئی گنتی کے ساتھ ، پرانے ویلیو کو واپس کرتے ہوئے ، کسی کو بھی بغیر کسی وضاحت کے تبدیل کریں۔
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر قیمت فی الحال ادھار لی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// ایکس ایک سو ایکس کی لپیٹی ہوئی قدر کو ایکس00 ایکس کی لپیٹی ہوئی قدر کے ساتھ بدل دیتا ہے ، بغیر کسی ایک کو واضح کیا۔
    ///
    ///
    /// یہ فنکشن [`std::mem::swap`](../mem/fn.swap.html) کے مساوی ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// لپٹی ہوئی قدر کو فوری طور پر ادھار لیتے ہیں۔
    ///
    /// قرض اس وقت تک برقرار رہتا ہے جب تک کہ `Ref` واپس نہ ہوسکے۔
    /// ایک ہی وقت میں متعدد غیر مستقل قرضے لئے جاسکتے ہیں۔
    ///
    /// # Panics
    ///
    /// Panics اگر قیمت فی الحال باہمی قرض لی گئی ہے۔
    /// گھبراہٹ کے متغیر کے لئے ، [`try_borrow`](#method.try_borrow) استعمال کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic کی ایک مثال:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// لپٹی ہوئی قدر کو فوری طور پر ادھار لیتے ہیں ، اگر اس وقت قیمت باہمی طور پر قرض لیا جاتا ہے تو ایک غلطی واپس کرنا۔
    ///
    ///
    /// قرض اس وقت تک برقرار رہتا ہے جب تک کہ `Ref` واپس نہ ہوسکے۔
    /// ایک ہی وقت میں متعدد غیر مستقل قرضے لئے جاسکتے ہیں۔
    ///
    /// یہ [`borrow`](#method.borrow) کا غیر گھبرانے والا متغیر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // محفوظ کریں: `BorrowRef` اس بات کو یقینی بناتا ہے کہ صرف ناقابل رسائی رسائی ہے
            // ادھار کے وقت قیمت میں
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// باہمی طور پر لپیٹی ہوئی قیمت پر قرض لیا جاتا ہے۔
    ///
    /// یہ قرض اس وقت تک جاری رہتا ہے جب تک کہ واپس کردہ `RefMut` یا اس سے حاصل کردہ تمام `FFMut`s دائرہ کار سے باہر نہیں نکل جاتا ہے۔
    ///
    /// قیمت ادھار نہیں لی جاسکتی ہے جبکہ یہ قرضہ فعال ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر قیمت فی الحال ادھار لی گئی ہے۔
    /// گھبراہٹ کے متغیر کے لئے ، [`try_borrow_mut`](#method.try_borrow_mut) استعمال کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic کی ایک مثال:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// موزوں طور پر لپیٹی ہوئی قدر سے قرض لیتا ہے ، اگر قیمت فی الحال مستعار لی گئی ہے تو ایک غلطی لوٹ رہی ہے۔
    ///
    ///
    /// یہ قرض اس وقت تک جاری رہتا ہے جب تک کہ واپس کردہ `RefMut` یا اس سے حاصل کردہ تمام `FFMut`s دائرہ کار سے باہر نہیں نکل جاتا ہے۔
    /// قیمت ادھار نہیں لی جاسکتی ہے جبکہ یہ قرضہ فعال ہے۔
    ///
    /// یہ [`borrow_mut`](#method.borrow_mut) کا غیر گھبرانے والا متغیر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // محفوظ: `BorrowRef` منفرد رسائی کی ضمانت دیتا ہے۔
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// اس سیل میں بنیادی اعداد و شمار کے لئے ایک خام پوائنٹر لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// بنیادی اعداد و شمار کا ایک متغیر حوالہ واپس کرتا ہے۔
    ///
    /// یہ کال ایکس00 ایکس کو باہمی طور پر (مرتب کرتے وقت) قرض لیتی ہے لہذا متحرک چیکس کی ضرورت نہیں ہے۔
    ///
    /// تاہم ، محتاط رہیں: یہ طریقہ `self` کی تبدیلی کی توقع کرتا ہے ، جو عام طور پر `RefCell` استعمال کرتے وقت ایسا نہیں ہوتا ہے۔
    ///
    /// اس کے بجائے [`borrow_mut`] کے طریقہ کار پر ایک نظر ڈالیں اگر `self` متغیر نہیں ہے۔
    ///
    /// نیز ، براہ کرم آگاہ رہیں کہ یہ طریقہ صرف خاص حالات کے لئے ہے اور عام طور پر وہ نہیں ہوتا ہے جو آپ چاہتے ہیں۔
    /// شک کی صورت میں ، اس کے بجائے [`borrow_mut`] استعمال کریں۔
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` کی قرض لینے والی ریاست پر لیک گارڈز کے اثر کو کالعدم کریں۔
    ///
    /// یہ کال [`get_mut`] کی طرح ہے لیکن زیادہ مہارت حاصل ہے۔
    /// یہ یقینی بناتا ہے کہ کوئی قرض نہیں ہے اور پھر ریاست سے باخبر رہتے ہوئے مشترکہ قرضوں کو دوبارہ ترتیب دیتا ہے۔
    /// یہ متعلقہ ہے اگر کچھ `Ref` یا `RefMut` قرض لیا گیا ہے۔
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// لپٹی ہوئی قدر کو فوری طور پر ادھار لیتے ہیں ، اگر اس وقت قیمت باہمی طور پر قرض لیا جاتا ہے تو ایک غلطی واپس کرنا۔
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` کے برعکس ، یہ طریقہ غیر محفوظ ہے کیونکہ یہ `Ref` واپس نہیں کرتا ہے ، اس طرح قرضے والے پرچم کو اچھوتا چھوڑ دیا جاتا ہے۔
    /// باہمی طور پر `RefCell` کا قرض لینا جبکہ اس طریقہ کار کے ذریعہ موصولہ حوالہ زندہ ہے غیر متعینہ طرز عمل ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // حفاظت: ہم چیک کرتے ہیں کہ اب کوئی بھی فعال طور پر لکھ نہیں رہا ہے ، لیکن ایسا ہے
            // کال کرنے والے کی ذمہ داری ہے کہ وہ اس بات کو یقینی بنائے کہ جب تک واپس شدہ حوالہ استعمال میں نہ آجائے اس وقت تک کوئی نہیں لکھتا ہے۔
            // نیز ، `self.value.get()` سے مراد `self` کی ملکیت والی قدر ہے اور اس طرح `self` کی زندگی بھر کے لئے موزوں ہونے کی ضمانت دی جاتی ہے۔
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// لپیٹی ہوئی قدر لیتا ہے ، `Default::default()` کو اپنی جگہ چھوڑ دیتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر قیمت فی الحال ادھار لی گئی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر قیمت فی الحال باہمی قرض لی گئی ہے۔
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// ٹی کے لئے `Default` قدر کے ساتھ ، ایک `RefCell<T>` بناتا ہے۔
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر `RefCell` میں سے کسی کی قیمت فی الحال ادھار لی گئی ہے۔
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // قرضوں میں اضافے کے نتیجے میں ان معاملات میں غیر پڑھنے والی قیمت (<=0) پیدا ہوسکتی ہے۔
            // 1. یہ <0 تھا ، یعنی لکھنے کے قرضے موجود ہیں ، لہذا ہم Rust کے حوالہ سے علسی سازی کے قواعد کے سبب پڑھنے کے قرض کی اجازت نہیں دے سکتے ہیں۔
            // 2.
            // یہ isize::MAX (قرض لینے کی زیادہ سے زیادہ رقم) تھا اور یہ isize::MIN (تحریری قرضوں کی زیادہ سے زیادہ رقم) میں بہہ گیا ہے لہذا ہم اضافی پڑھنے کے قرض کی اجازت نہیں دے سکتے ہیں کیونکہ آئسائز بہت سارے پڑھے ہوئے قرضوں کی نمائندگی نہیں کرسکتا ہے (یہ تب ہی ہوسکتا ہے اگر آپ 0 ریفریز کی ایک چھوٹی سی مستقل مقدار سے زیادہ mem::forget کرتے ہیں ، جو اچھا عمل نہیں ہے)
            //
            //
            //
            //
            None
        } else {
            // قرضوں میں اضافے کے نتیجے میں ان معاملات میں پڑھنے کی قیمت (> 0) پیدا ہوسکتی ہے۔
            // 1. یہ=0 تھا ، یعنی یہ ادھار نہیں لیا گیا تھا ، اور ہم پہلا پڑھا ہوا قرض لے رہے ہیں
            // 2. یہ> 0 اور <isize::MAX ، یعنی تھا
            // پڑھے ہوئے قرضے تھے ، اور اسائز اتنا بڑا ہے کہ ایک اور پڑھے ہوئے قرضے کی نمائندگی کرسکے
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // چونکہ یہ ریف موجود ہے ، ہم جانتے ہیں کہ قرض کا جھنڈا پڑھنے والا قرض ہے۔
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // تحریری قرض میں اضافے سے بائون کاؤنٹر کو روکیں۔
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// ایک `RefCell` باکس میں کسی قدر کے لئے مستعار حوالہ لپیٹتا ہے۔
/// `RefCell<T>` سے غیر مستقل قرضے لینے والی قیمت کے ل A ریپر کی قسم۔
///
/// مزید کے لئے [module-level documentation](self) دیکھیں۔
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// ایک `Ref` کاپیاں۔
    ///
    /// `RefCell` پہلے ہی عارضی طور پر ادھار لیا ہوا ہے ، لہذا یہ ناکام نہیں ہوسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `Ref::clone(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// `Clone` پر عمل درآمد یا ایک طریقہ `r.borrow().clone()` کے وسیع پیمانے پر استعمال میں `RefCell` کے مندرجات کو کلون کرنے میں مداخلت کرے گا۔
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// قرضے لینے والے ڈیٹا کے جزو کے ل a ایک نیا `Ref` بناتا ہے۔
    ///
    /// `RefCell` پہلے ہی عارضی طور پر ادھار لیا ہوا ہے ، لہذا یہ ناکام نہیں ہوسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `Ref::map(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// قرضے لینے والے ڈیٹا کے اختیاری اجزا کے ل a ایک نیا `Ref` بناتا ہے۔
    /// اصل گارڈ ایک `Err(..)` کے طور پر واپس آ جاتا ہے اگر بند ہونے سے `None` واپس آجاتا ہے۔
    ///
    /// `RefCell` پہلے ہی عارضی طور پر ادھار لیا ہوا ہے ، لہذا یہ ناکام نہیں ہوسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `Ref::filter_map(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// قرضے لینے والے ڈیٹا کے مختلف اجزاء کے لئے ایک `Ref` کو ایک سے زیادہ `ریفریز میں تقسیم کرتا ہے۔
    ///
    /// `RefCell` پہلے ہی عارضی طور پر ادھار لیا ہوا ہے ، لہذا یہ ناکام نہیں ہوسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `Ref::map_split(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// بنیادی اعداد و شمار کے حوالہ میں تبدیل کریں۔
    ///
    /// بنیادی `RefCell` کبھی بھی باہمی طور پر دوبارہ سے قرض نہیں لیا جاسکتا ہے اور ہمیشہ ہی عارضی طور پر مستعار لیا ہوا دکھایا جائے گا۔
    ///
    /// حوالوں کی مستقل تعداد سے زیادہ لیک کرنا اچھا خیال نہیں ہے۔
    /// اگر صرف مجموعی طور پر صرف ایک چھوٹی سی تعداد میں رسا ہوا ہو تو `RefCell` غیر مستقل طور پر دوبارہ ادھار لیا جاسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `Ref::leak(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // اس ریف کو فراموش کرکے ہم اس بات کو یقینی بناتے ہیں کہ ریف سیل میں لون کاؤنٹر زندگی بھر `'b` میں غیر استعمال شدہ پر واپس نہیں جاسکتا ہے۔
        // حوالہ سے باخبر رہنے کی حالت کو دوبارہ ترتیب دینے کے ل the قرضے لینے والے ریف سیل کے ایک منفرد حوالہ کی ضرورت ہوگی۔
        // اصل سیل سے مزید کوئی تغیر پذیر حوالہ پیدا نہیں کیا جاسکتا ہے۔
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// قرضے لینے والے ڈیٹا کے جزو کے ل a ایک نیا `RefMut` بناتا ہے ، مثلا en ، ایک اینوم مختلف قسم۔
    ///
    /// `RefCell` پہلے ہی باہمی قرض لیا گیا ہے ، لہذا یہ ناکام نہیں ہوسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `RefMut::map(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): قرضہ چیک ٹھیک کریں
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// قرضے لینے والے ڈیٹا کے اختیاری اجزا کے ل a ایک نیا `RefMut` بناتا ہے۔
    /// اصل گارڈ ایک `Err(..)` کے طور پر واپس آ جاتا ہے اگر بند ہونے سے `None` واپس آجاتا ہے۔
    ///
    /// `RefCell` پہلے ہی باہمی قرض لیا گیا ہے ، لہذا یہ ناکام نہیں ہوسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `RefMut::filter_map(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): قرضہ چیک ٹھیک کریں
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // حفاظت: تقریب کی مدت کے لئے ایک خصوصی حوالہ رکھتا ہے
        // `orig` کے ذریعہ اس کی کال کی ، اور اس اشارے کو صرف فنکشن کال کے اندر ہی غیر حوالہ دیا گیا ہے جو خصوصی حوالہ کو کبھی بھی فرار ہونے کی اجازت نہیں دیتا ہے۔
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // حفاظت: اوپر کی طرح.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// قرضے لینے والے ڈیٹا کے مختلف اجزاء کے لئے ایک `RefMut` کو ایک سے زیادہ ریفمیٹ میں تقسیم کرتا ہے۔
    ///
    /// بنیادی `RefCell` اس وقت تک باہمی طور پر مستعار لیا جائے گا جب تک کہ دونوں واپس نہیں آسکتے ہیں `ریفمو`س دائرہ کار سے ہٹ جاتے ہیں۔
    ///
    /// `RefCell` پہلے ہی باہمی قرض لیا گیا ہے ، لہذا یہ ناکام نہیں ہوسکتا ہے۔
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `RefMut::map_split(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// بنیادی اعداد و شمار کے متغیر حوالہ میں تبدیل کریں۔
    ///
    /// بنیادی `RefCell` دوبارہ سے قرض نہیں لیا جاسکتا ہے اور ہمیشہ ہی باہمی طور پر ادھار لیا ہوا دکھائی دے گا ، جس سے واپسی حوالہ صرف داخلہ کا ہی ہوگا۔
    ///
    ///
    /// یہ ایک وابستہ فنکشن ہے جسے `RefMut::leak(...)` کے طور پر استعمال کرنے کی ضرورت ہے۔
    /// ایک طریقہ `Deref` کے ذریعے استعمال ہونے والے `RefCell` کے مندرجات پر ایک ہی نام کے طریقوں میں مداخلت کرے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // اس بورن ریف میٹ کو فراموش کرکے ہم اس بات کو یقینی بناتے ہیں کہ ریفसेल میں لون کاؤنٹر تاحیات `'b` کے اندر واپس غیر استعمال نہیں ہوسکتا ہے۔
        // حوالہ سے باخبر رہنے کی حالت کو دوبارہ ترتیب دینے کے ل the قرضے لینے والے ریف سیل کے ایک منفرد حوالہ کی ضرورت ہوگی۔
        // اس اصل زندگی میں اصل سیل سے مزید کوئی حوالہ تخلیق نہیں کیا جاسکتا ، جس سے موجودہ قرضے بقیہ زندگی کا واحد حوالہ بن جاتا ہے۔
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone کے برعکس ، ابتدائی بنانے کے لئے نیا کہا جاتا ہے
        // تغیر پزیر حوالہ ، اور اس لئے فی الحال کوئی موجودہ حوالہ موجود نہیں ہونا چاہئے۔
        // اس طرح ، جبکہ کلون انکاریمٹیٹیوٹ ریفاؤنٹ میں اضافہ کرتا ہے ، یہاں ہم واضح طور پر صرف غیر استعمال شدہ سے غیر استعمال شدہ ، 1 جانے کی اجازت دیتے ہیں۔
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // کلون ایک `BorrowRefMut`۔
    //
    // یہ تب ہی درست ہے جب ہر `BorrowRefMut` اصلی چیز کی ایک الگ ، نون لیورپیننگ حد کے تغیر پزیر حوالہ کو ٹریک کرنے کے لئے استعمال ہوتا ہے۔
    //
    // یہ کلون امپیل میں نہیں ہے تاکہ کوڈ اسے واضح طور پر کال نہ کرے۔
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // قرض کے کاؤنٹر کو بہاؤ سے روکیں۔
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` سے باہمی قرضے لینے والی قیمت کے ل wra ریپر کی قسم۔
///
/// مزید کے لئے [module-level documentation](self) دیکھیں۔
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust میں داخلہ بدلاؤ کے ل for بنیادی بنیادی۔
///
/// اگر آپ کے پاس `&T` کا حوالہ ہے تو ، پھر عام طور پر Rust میں مرتب علم کی بنیاد پر اصلاح کرتا ہے جو `&T` غیر منقول اعداد و شمار کی طرف اشارہ کرتا ہے۔مثال کے طور پر کسی عرف کے ذریعہ یا `&T` کو `&mut T` میں تبدیل کرتے ہوئے اس ڈیٹا کو تبدیل کرنا ، غیر وضاحتی سلوک سمجھا جاتا ہے۔
/// `UnsafeCell<T>` `&T` کے لئے ناقابل تبدیلی کی ضمانت سے باہر نکلنا: مشترکہ حوالہ `&UnsafeCell<T>` اس ڈیٹا کی طرف اشارہ کرسکتا ہے جو تبدیل کیا جارہا ہے۔اسے "interior mutability" کہا جاتا ہے۔
///
/// دوسری تمام اقسام جو `Cell<T>` اور `RefCell<T>` جیسے اندرونی تغیرات کی اجازت دیتی ہیں ، اپنے اعداد و شمار کو لپیٹنے کے لئے اندرونی طور پر `UnsafeCell` کا استعمال کرتے ہیں۔
///
/// نوٹ کریں کہ مشترکہ حوالوں کی صرف تغیر پزیر کی ضمانت `UnsafeCell` سے متاثر ہوتی ہے۔تغیر پزیر حوالوں کی انفرادیت کی گارنٹی متاثر نہیں ہے۔ایلیسنگ `&mut` حاصل کرنے کا *کوئی* قانونی طریقہ نہیں ہے ، یہاں تک کہ `UnsafeCell<T>` کے ساتھ بھی نہیں۔
///
/// `UnsafeCell` API خود تکنیکی طور پر بہت آسان ہے: [`.get()`] آپ کو اس کے مندرجات پر خام پوائنٹر `*mut T` دیتا ہے۔اس خام پوائنٹر کو صحیح طریقے سے استعمال کرنے کے لئے یہ خلاصہ ڈیزائنر کی حیثیت سے _you_ پر منحصر ہے۔
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Rust علیحدہ کرنے کے عین مطابق قوانین کچھ حد تک بہاؤ میں ہیں ، لیکن اہم نکات متنازعہ نہیں ہیں۔
///
/// - اگر آپ زندگی بھر `'a` (یا تو ایک `&T` یا `&mut T` حوالہ) کے ساتھ ایک محفوظ حوالہ تیار کرتے ہیں جو محفوظ کوڈ کے ذریعہ قابل رسائی ہے (مثال کے طور پر ، کیونکہ آپ نے اسے لوٹا دیا ہے) ، تو آپ کو کسی بھی طرح سے ڈیٹا تک رسائی حاصل نہیں کرنا چاہئے جو باقی حوالہ کے حوالہ سے متصادم ہے۔ `'a` کا۔
/// مثال کے طور پر ، اس کا مطلب یہ ہے کہ اگر آپ `*mut T` کو `UnsafeCell<T>` سے X `&T` پر لے جاتے ہیں ، تو `T` میں موجود ڈیٹا لازمی نہیں رہ سکتا (`T` کے اندر موجود `UnsafeCell` کا کوئی ڈیٹا ، ضرور) اس حوالہ کی زندگی کی میعاد ختم ہونے تک۔
/// اسی طرح ، اگر آپ ایک `&mut T` حوالہ بناتے ہیں جو سیف کوڈ کے لئے جاری کیا جاتا ہے ، تو آپ کو `UnsafeCell` کے اندر موجود ڈیٹا تک اس حوالہ کی میعاد ختم ہونے تک رسائی نہیں کرنی چاہئے۔
///
/// - ہر وقت ، آپ کو ڈیٹا ریس سے اجتناب کرنا چاہئے۔اگر ایک سے زیادہ تھریڈز کو ایک ہی `UnsafeCell` تک رسائی حاصل ہے ، تو پھر کسی بھی تحریر کو مناسب انداز میں ہونا ضروری ہے-اس سے پہلے کہ دیگر تمام رسائوں (یا atomics کے استعمال) سے متعلق ہو۔
///
/// مناسب ڈیزائن کی مدد کے لئے ، درج ذیل منظرناموں کو واضح طور پر سنگل تھریڈ کوڈ کے لئے قانونی قرار دیا گیا ہے۔
///
/// 1. ایک `&T` حوالہ محفوظ کوڈ کے لئے جاری کیا جاسکتا ہے اور وہاں یہ `&T` دیگر حوالوں کے ساتھ شریک ہوسکتا ہے ، لیکن `&mut T` کے ساتھ نہیں
///
/// 2. کسی `&mut T` کا حوالہ محفوظ کوڈ پر جاری کیا جاسکتا ہے بشرطیکہ اس کے ساتھ نہ ہی کوئی دوسرا `&mut T` اور نہ ہی `&T` ہم آہنگ ہو۔ایک `&mut T` ہمیشہ منفرد ہونا چاہئے۔
///
/// نوٹ کریں کہ جب بھی `&UnsafeCell<T>` کے مندرجات میں تبدیلی کرنا (دوسرے `&UnsafeCell<T>` حوالہ جات عرف سیل کے باوجود) ٹھیک ہے (بشرطیکہ آپ مذکورہ حملہ آوروں کو کسی اور طرح سے نافذ کردیں) ، یہ ابھی بھی متعدد `&mut UnsafeCell<T>` عرفی ناموں کا متعین طرز عمل ہے۔
/// یعنی ، `UnsafeCell` ایک ریپر ہے جو _shared_ accesses (_i.e._ کے ساتھ `&UnsafeCell<_>` حوالہ کے ذریعہ خصوصی تعامل کرنے کے لئے تیار کیا گیا ہے)؛_exclusive_ accesses (_e.g._ کے ساتھ ، ایک `&mut UnsafeCell<_>` کے ذریعہ معاملت کرتے وقت کوئی جادو نہیں ہے): نہ ہی سیل اور نہ ہی لپیٹی ہوئی قیمت اس `&mut` قرضے کی مدت کے لi علانیہ رہ سکتی ہے۔
///
/// یہ [`.get_mut()`] رسولی کی نمائش میں ہے ، جو _safe_ getter ہے جو `&mut T` حاصل کرتا ہے۔
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// یہاں ایک مثال دی جارہی ہے جس میں ایک `UnsafeCell<_>` کے مندرجات کو صوتی طور پر تبدیل کرنے کے طریقہ کی نمائش کی جارہی ہے۔
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // اسی `x` پر متعدد/ہم آہنگی/مشترکہ حوالہ جات حاصل کریں۔
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // محفوظ: اس دائرہ کار میں `x` کے مندرجات کے بارے میں کوئی دوسرا حوالہ نہیں ہے ،
///     // تو ہمارا مؤثر طریقے سے انوکھا ہے۔
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- قرض-+
///     *p1_exclusive += 27; // |
/// } // <---------- اس نقطہ سے آگے نہیں بڑھ سکتے -------------------+
///
/// unsafe {
///     // حفاظت: اس دائرہ کار میں کسی کو بھی `x` کے مواد تک خصوصی رسائی حاصل ہونے کی توقع نہیں ،
///     // تاکہ ہم بیک وقت متعدد مشترکہ رسائی حاصل کرسکیں۔
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// مندرجہ ذیل مثال اس حقیقت کی نمائش کرتی ہے کہ `UnsafeCell<T>` تک خصوصی رسائی کا مطلب اس کے `T` تک خصوصی رسائی ہے:
///
/// ```rust
/// #![forbid(unsafe_code)] // خصوصی رسائی کے ساتھ ،
///                         // `UnsafeCell` ایک شفاف اوپری ریپر ہے ، لہذا یہاں `unsafe` کی ضرورت نہیں ہے۔
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` کے لئے مرتب وقت سے متعلق جانچنے والا انوکھا حوالہ حاصل کریں۔
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // ایک خصوصی حوالہ کے ساتھ ، ہم مشمولات مفت میں بدل سکتے ہیں۔
/// *p_unique.get_mut() = 0;
/// // یا ، مساوی:
/// x = UnsafeCell::new(0);
///
/// // جب ہمارے پاس قیمت ہے ، ہم مفت میں مواد نکال سکتے ہیں۔
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` کی ایک نئی مثال تیار کرتا ہے جو مخصوص قیمت کو سمیٹ دے گا۔
    ///
    ///
    /// طریقوں کے ذریعہ داخلی قیمت تک تمام رسائی `unsafe` ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// قدر کو کھولنا۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// لپیٹی ہوئی قدر کے ل mut ایک متغیر پوائنٹر حاصل کرتا ہے۔
    ///
    /// یہ کسی بھی قسم کے اشارے پر ڈال سکتا ہے۔
    /// اس بات کو یقینی بنائیں کہ `&mut T` پر کاسٹ کرتے وقت رسائ منفرد ہے (کوئی فعال حوالہ نہیں ہے ، متغیر ہے یا نہیں) ، اور اس بات کو یقینی بنائیں کہ `&T` پر کاسٹ کرتے وقت کوئی اتپریورتن یا میوٹیبل ایلیس موجود نہیں ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // ہم صرف X001 کی وجہ سے `UnsafeCell<T>` سے `T` تک پوائنٹر کاسٹ کرسکتے ہیں۔
        // اس سے لیبسٹڈی کی خصوصی حیثیت کا استحصال ہوتا ہے ، صارف کے کوڈ کی کوئی گارنٹی نہیں ہے کہ یہ کمپائلر کے زیڈ فیوچر0 زیڈ ورژن میں کام کرے گا!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// بنیادی اعداد و شمار کا ایک متغیر حوالہ واپس کرتا ہے۔
    ///
    /// یہ کال `UnsafeCell` کو باہمی طور پر (مرتب کرتے وقت) قرض لیتی ہے جو ضمانت دیتا ہے کہ ہمارے پاس صرف حوالہ موجود ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// لپیٹی ہوئی قدر کے ل mut ایک متغیر پوائنٹر حاصل کرتا ہے۔
    /// [`get`] میں فرق یہ ہے کہ یہ فنکشن ایک خام پوائنٹر کو قبول کرتا ہے ، جو عارضی حوالوں کی تخلیق سے بچنے کے لئے مفید ہے۔
    ///
    /// نتیجہ کسی بھی قسم کے اشارے پر ڈال سکتا ہے۔
    /// اس بات کو یقینی بنائیں کہ `&mut T` پر کاسٹ کرتے وقت رسائ منفرد ہے (کوئی فعال حوالہ نہیں ہے ، متغیر ہے یا نہیں) ، اور اس بات کو یقینی بنائیں کہ `&T` پر کاسٹ کرتے وقت کوئی اتپریورتن یا میوٹیبل ایلیسس نہیں چل رہے ہیں۔
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// کسی `UnsafeCell` کی تدریجی ابتدا میں `raw_get` کی ضرورت ہوتی ہے ، کیونکہ `get` پر کال کرنے سے انٹریٹائزڈ ڈیٹا کا کوئی حوالہ پیدا کرنے کی ضرورت ہوگی۔
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // ہم صرف X001 کی وجہ سے `UnsafeCell<T>` سے `T` تک پوائنٹر کاسٹ کرسکتے ہیں۔
        // اس سے لیبسٹڈی کی خصوصی حیثیت کا استحصال ہوتا ہے ، صارف کے کوڈ کی کوئی گارنٹی نہیں ہے کہ یہ کمپائلر کے زیڈ فیوچر0 زیڈ ورژن میں کام کرے گا!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// ٹی کے لئے `Default` قدر کے ساتھ ، ایک `UnsafeCell` بناتا ہے۔
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}