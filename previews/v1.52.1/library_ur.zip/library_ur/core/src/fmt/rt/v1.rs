//! یہ آئی ایم ایم ٹی کے ذریعہ استعمال ہونے والا ایک داخلی ماڈیول ہے!رن ٹائمیہ ڈھانچے وقت سے پہلے کی شکل کے تاروں کو مرتب کرنے کے لئے جامد صفوں میں خارج ہوتے ہیں۔
//!
//! یہ تعریفیں ان کے `ct` مساویوں سے ملتی جلتی ہیں ، لیکن اس میں فرق ہے کہ یہ مستحکم طور پر مختص کی جاسکتی ہیں اور رن ٹائم کے لئے قدرے بہتر ہوجاتی ہیں
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ممکنہ صف بندی جس سے فارمیٹنگ ہدایت کے حصے کے طور پر درخواست کی جاسکتی ہے۔
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// اشارہ ہے کہ مشمولات کو بائیں سیدھا ہونا چاہئے۔
    Left,
    /// اشارہ ہے کہ مشمولات کو سیدھا ہونا چاہئے۔
    Right,
    /// اشارہ ہے کہ مشمولات درمیانہ منسلک ہونا چاہئے۔
    Center,
    /// کسی صف بندی کی درخواست نہیں کی گئی تھی۔
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) اور [precision](https://doc.rust-lang.org/std/fmt/#precision) تفصیلات کے ذریعہ استعمال کیا جاتا ہے۔
#[derive(Copy, Clone)]
pub enum Count {
    /// لغوی نمبر کے ساتھ بیان کردہ ، قیمت کو محفوظ کرتا ہے
    Is(usize),
    /// `$` اور `*` نحو کو استعمال کرتے ہوئے بیان کردہ ، انڈیکس کو `args` میں اسٹور کرتا ہے
    Param(usize),
    /// مخصوص نہیں
    Implied,
}