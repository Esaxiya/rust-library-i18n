//! ڈور فارمیٹنگ اور پرنٹنگ کے لئے افادیت۔

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// ممکنہ صف بندی `Formatter::align` کے ذریعہ لوٹائی گئی
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشارہ ہے کہ مشمولات کو بائیں سیدھا ہونا چاہئے۔
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشارہ ہے کہ مشمولات کو سیدھا ہونا چاہئے۔
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشارہ ہے کہ مشمولات درمیانہ منسلک ہونا چاہئے۔
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// قسم فارمیٹر طریقوں کے ذریعہ لوٹائی گئی۔
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// غلطی کی قسم جو کسی پیغام کو کسی دھارے میں فارمیٹ کرنے سے لوٹی ہے۔
///
/// اس قسم میں غلطی پیش آنے کے علاوہ کسی اور کی غلطی کی منتقلی کی حمایت نہیں کرتی ہے۔
/// کسی بھی اضافی معلومات کو کسی دوسرے ذرائع سے منتقل کرنے کا اہتمام کرنا ضروری ہے۔
///
/// یاد رکھنے والی ایک اہم بات یہ ہے کہ `fmt::Error` قسم کو [`std::io::Error`] یا [`std::error::Error`] کے ساتھ الجھن میں نہیں ڈالنا چاہئے ، جو آپ کے دائرہ کار میں بھی ہوسکتا ہے۔
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// یونیکوڈ قبول کرنے والے بفرز یا ندیوں میں لکھنے یا فارمیٹنگ کے لئے ایک trait۔
///
/// یہ trait صرف UTF-8 - انکوڈ شدہ ڈیٹا کو قبول کرتا ہے اور [flushable] نہیں ہے۔
/// اگر آپ صرف یونیکوڈ قبول کرنا چاہتے ہیں اور آپ کو فلش کرنے کی ضرورت نہیں ہے تو ، آپ کو اس trait پر عمل درآمد کرنا چاہئے۔
/// بصورت دیگر آپ کو [`std::io::Write`] لاگو کرنا چاہئے۔
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// اس مصنف میں سٹرنگ سلائس لکھتا ہے ، واپس آیا کہ لکھنے میں کامیاب ہوا۔
    ///
    /// یہ طریقہ صرف تب ہی کامیاب ہوسکتا ہے جب پوری سٹرنگ سلائس کامیابی کے ساتھ لکھی گئی ہو ، اور یہ طریقہ اس وقت تک واپس نہیں آئے گا جب تک کہ تمام ڈیٹا لکھا نہیں جاتا یا کوئی غلطی واقع نہیں ہوتی ہے۔
    ///
    ///
    /// # Errors
    ///
    /// یہ فنکشن غلطی پر [`Error`] کی مثال واپس کرے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// اس مصنف میں ایک [`char`] لکھتا ہے ، واپس آیا کہ لکھنے میں کامیاب ہوا۔
    ///
    /// ایک ہی [`char`] کو ایک سے زیادہ بائٹ کے بطور انکوڈ کیا جاسکتا ہے۔
    /// یہ طریقہ تبھی کامیاب ہوسکتا ہے جب پورا بائٹ تسلسل کامیابی کے ساتھ لکھا گیا ہو ، اور یہ طریقہ اس وقت تک واپس نہیں آئے گا جب تک کہ تمام ڈیٹا لکھا نہیں جاتا یا کوئی غلطی واقع نہیں ہوتی ہے۔
    ///
    ///
    /// # Errors
    ///
    /// یہ فنکشن غلطی پر [`Error`] کی مثال واپس کرے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// اس trait کے نفاذ کاروں کے ساتھ [`write!`] میکرو کے استعمال کیلئے گلو۔
    ///
    /// اس طریقہ کار کو عام طور پر دستی طور پر نہیں کہا جانا چاہئے ، بلکہ خود [`write!`] میکرو کے ذریعے ہونا چاہئے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// فارمیٹنگ کیلئے تشکیل۔
///
/// ایک `Formatter` مختلف ترتیبات کی نمائش سے متعلق نمائندگی کرتا ہے۔
/// صارفین براہ راست فارمیٹر کی تعمیر نہیں کرتے ہیں۔ایک کے لئے ایک تغیر پزیر حوالہ [`Debug`] اور [`Display`] جیسے traits جیسے تمام فارمیٹنگ کے `fmt` طریقہ کار کو منظور کیا جاتا ہے۔
///
///
/// `Formatter` کے ساتھ بات چیت کرنے کے ل you'll ، آپ فارمیٹنگ سے متعلق مختلف اختیارات کو تبدیل کرنے کے ل various مختلف طریقوں پر کال کریں گے۔
/// مثال کے طور پر ، براہ کرم ذیل میں `Formatter` پر بیان کردہ طریقوں کی دستاویزات دیکھیں۔
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// دلیل بنیادی طور پر ایک بہتر جزوی طور پر اطلاق شدہ فارمیٹنگ فنکشن ہے ، جو `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` کے برابر ہے۔

extern "C" {
    type Opaque;
}

/// یہ ڈھانچہ عام "argument" کی نمائندگی کرتا ہے جو ایکس پرنٹف فیملی کے ذریعہ لیا جاتا ہے۔اس میں دی گئی قیمت کو فارمیٹ کرنے کے لئے ایک فنکشن ہوتا ہے۔
/// مرتب وقت پر یہ یقینی بنایا جاتا ہے کہ فنکشن اور ویلیو کی صحیح اقسام ہیں ، اور پھر اس ڈھانچے کو ایک قسم میں دلائل کیننالائز کرنے کے لئے استعمال کیا جاتا ہے۔
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// یہ فارمیٹنگ انفراسٹرکچر میں indices/counts سے وابستہ فنکشن پوائنٹر کے لئے ایک واحد مستحکم قیمت کی ضمانت دیتا ہے۔
//
// نوٹ کریں کہ اس طرح کی کوئی تقریب درست نہیں ہوگی کیونکہ افعال کو ہمیشہ نامعلوم_ایڈر کو ٹیگ کرکے موجودہ ایل ایل وی ایم آئر کے ساتھ ٹیگ کیا جاتا ہے ، لہذا ان کا پتہ ایل ایل وی ایم کے ل important اہم نہیں سمجھا جاتا ہے اور جیسا کہ اس_ایسائز کاسٹ کو غلط مرتب کیا جاسکتا ہے۔
//
// عملی طور پر ، ہم کبھی بھی غیر استعمال شدہ اعداد و شمار پر (as فارمیٹنگ دلائل کی جامد نسل کے معاملے پر) as_usize نہیں کہتے ہیں ، لہذا یہ محض ایک اضافی چیک ہے۔
//
// ہم بنیادی طور پر یہ یقینی بنانا چاہتے ہیں کہ `USIZE_MARKER` پر فنکشن پوائنٹ کا ایک پتہ صرف *صرف* افعال سے ہے جو `&usize` کو بھی اپنی پہلی دلیل سمجھتے ہیں۔
// یہاں پڑھی جانے والی_ضروری اس بات کو یقینی بناتی ہے کہ ہم منظور شدہ حوالہ سے کسی صارف کو بحفاظت تیار کرسکیں اور یہ پتہ کسی غیر استعمال شدہ تقریب میں اشارہ نہیں کرے گا۔
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // حفاظت: ptr ایک حوالہ ہے
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // محفوظ کریں: `mem::transmute(x)` محفوظ ہے کیونکہ
        //     1. `&'b T` زندگی بھر جس کی ابتدا `'b` کے ساتھ ہوتی ہے (تا کہ بے حد زندگی گزار نہ سکے)
        //     2.
        //     `&'b T` اور `&'b Opaque` کی میموری کی ترتیب ایک ہی ہے (جب `T` `Sized` ہے ، جیسا کہ یہ یہاں موجود ہے) `mem::transmute(f)` محفوظ ہے کیونکہ `fn(&T, &mut Formatter<'_>) -> Result` اور `fn(&Opaque, &mut Formatter<'_>) -> Result` میں ایک ہی ABI ہے (جب تک کہ `T` `Sized` ہے)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // محفوظ: `formatter` فیلڈ صرف USIZE_MARKER پر سیٹ ہے اگر
            // قیمت ایک استعمال کی شکل ہے ، لہذا یہ محفوظ ہے
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// فارمیٹ_آرگس کے v1 فارمیٹ میں دستیاب جھنڈے
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// format_args! () میکرو کا استعمال کرتے وقت ، یہ فنکشن استدلال کے ڈھانچے کو تیار کرنے کے لئے استعمال ہوتا ہے۔
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// یہ فنکشن غیر معیاری فارمیٹنگ پیرامیٹرز کی وضاحت کرنے کے لئے استعمال کیا جاتا ہے۔
    /// ایک معقول دلائل کی تشکیل کے ل The `pieces` سرنی کم از کم طویل عرصے تک `fmt` ہونی چاہئے۔
    /// نیز ، `fmt` کے اندر موجود کسی بھی `Count` جو `CountIsParam` یا `CountIsNextParam` ہے اسے `argumentusize` کے ساتھ بنی دلیل کی طرف اشارہ کرنا پڑتا ہے۔
    ///
    /// تاہم ، ایسا کرنے میں ناکامی سے عدم استحکام پیدا نہیں ہوتا ہے ، لیکن وہ غلط کو نظر انداز کردیں گے۔
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// فارمیٹڈ ٹیکسٹ کی لمبائی کا اندازہ لگاتا ہے۔
    ///
    /// `format!` کا استعمال کرتے وقت ابتدائی `String` کی اہلیت طے کرنے کیلئے اس کا استعمال کرنا ہے۔
    /// Note: یہ نہ تو نچلا ہے اور نہ ہی بالائی حد۔
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // اگر فارمیٹ کی تار کسی دلیل سے شروع ہوتی ہے تو ، کسی بھی چیز کو پہلے سے پیش نہ کریں ، جب تک کہ ٹکڑوں کی لمبائی اہم نہ ہو۔
            //
            //
            0
        } else {
            // کچھ دلائل موجود ہیں ، لہذا کوئی بھی اضافی پش اس تار کو دوبارہ سے لے لے گا۔
            //
            // اس سے بچنے کے ل we're ، ہم یہاں کی صلاحیت "pre-doubling" کر رہے ہیں۔
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// یہ ڈھانچہ کسی فارمیٹ کے تار اور اس کے دلائل کے محفوظ طریقے سے پیش گوئی شدہ ورژن کی نمائندگی کرتا ہے۔
/// رن ٹائم کے وقت اس کو پیدا نہیں کیا جاسکتا ہے کیوں کہ یہ محفوظ طریقے سے نہیں ہوسکتا ہے ، لہذا ترمیم کو روکنے کے لئے کوئی کنسٹرکٹر نہیں دیا جاتا ہے اور کھیت نجی ہیں۔
///
///
/// [`format_args!`] میکرو محفوظ طریقے سے اس ڈھانچے کی ایک مثال قائم کرے گا۔
/// میکرو مرتب وقت پر فارمیٹ کی تار کی توثیق کرتا ہے لہذا [`write()`] اور [`format()`] افعال کا استعمال محفوظ طریقے سے انجام پائے۔
///
/// آپ `Arguments<'a>` استعمال کرسکتے ہیں جو [`format_args!`] واپس کرتا ہے `Debug` اور `Display` سیاق و سباق میں۔
/// مثال سے یہ بھی ظاہر ہوتا ہے کہ `Debug` اور `Display` فارمیٹ کو ایک ہی چیز کے لئے: `format_args!` میں انٹرپولٹیٹ فارمیٹ کی تار۔
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // پرنٹ کرنے کے لئے تار کے ٹکڑوں کو فارمیٹ کریں۔
    pieces: &'a [&'static str],

    // پلیس ہولڈر چشمی ، یا `None` اگر سارے چشمے پہلے سے طے شدہ ہیں (جیسا کہ "{}{}")۔
    fmt: Option<&'a [rt::v1::Argument]>,

    // انٹرپولیشن کے لئے متحرک دلائل ، تار کے ٹکڑوں کے ساتھ بین کرنے کے لئے۔
    // (ہر دلیل سے پہلے تار کا ٹکڑا ہوتا ہے۔)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// فارمیٹڈ سٹرنگ حاصل کریں ، اگر اس میں فارمیٹ ہونے کے لئے دلائل نہیں ہیں۔
    ///
    /// یہ انتہائی چھوٹی سی صورت میں مختص کرنے سے بچنے کے لئے استعمال کیا جاسکتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` آؤٹ پٹ کو پروگرامر کا سامنا کرنے والے ، ڈیبگنگ سیاق و سباق میں شکل دینا چاہئے۔
///
/// عام طور پر ، آپ کو `derive` ایک `Debug` عمل درآمد کرنا چاہئے۔
///
/// جب متبادل فارمیٹ وضاحت کنندہ `#?` کے ساتھ استعمال کیا جاتا ہے تو ، آؤٹ پٹ خوبصورت چھپی ہوئی ہے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// یہ trait `#[derive]` کے ساتھ استعمال کیا جاسکتا ہے اگر تمام فیلڈز `Debug` لاگو کریں۔
/// جب اسٹرکٹس کو تیار کیا جاتا ہے تو ، یہ `struct` ، پھر `{` ، پھر ہر فیلڈ کے نام اور `Debug` قدر کی کوما سے الگ فہرست ، پھر `}` کا نام استعمال کرے گا۔
/// `enum`s کے ل it ، وہ مختلف حالت کا نام استعمال کریں گے اور ، اگر قابل اطلاق ہیں تو ، `(` ، پھر کھیتوں کی `Debug` اقدار ، پھر `)`۔
///
/// # Stability
///
/// اخذ کردہ `Debug` فارمیٹس مستحکم نہیں ہیں ، اور اس طرح future Rust ورژن کے ساتھ تبدیل ہوسکتے ہیں۔
/// مزید برآں ، معیاری لائبریری (b libstd` ، `libcore` ، `liballoc` ، وغیرہ) کے ذریعہ فراہم کردہ اقسام کی `Debug` نفاذ مستحکم نہیں ہیں ، اور future Rust ورژن کے ساتھ بھی تبدیل ہوسکتی ہیں۔
///
///
/// # Examples
///
/// ایک عمل درآمد:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// دستی طور پر لاگو:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`Formatter`] ڈھانچے پر دستی عملدرآمد ، جیسے [`debug_struct`] جیسے آپ کی مدد کرنے کے لئے بہت سارے مددگار طریقے ہیں۔
///
/// `Debug` `derive` پر ڈیبگ بلڈر API یا تو `derive` کا استعمال کرتے ہوئے نفاذات متبادل پرچم کا استعمال کرکے خوبصورت پرنٹنگ کی حمایت کرتے ہیں۔ `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` کے ساتھ خوبصورت چھپائی:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` کے بغیر preolve سے میکرو `Debug` کو دوبارہ برآمد کرنے کے لئے ماڈیول الگ کریں۔
pub(crate) mod macros {
    /// trait `Debug` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// خالی شکل کیلئے trait کو فارمیٹ کریں ، `{}`.
///
/// `Display` [`Debug`] کی طرح ہے ، لیکن `Display` صارف کے سامنے آؤٹ پٹ کے لئے ہے ، اور اس سے اخذ نہیں کیا جاسکتا ہے۔
///
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ایک قسم پر `Display` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait کو اپنی آؤٹ پٹ کو base-8 میں بطور نمبر فارمیٹ کرنا چاہئے۔
///
/// قدیم دستخط کیے ہوئے انٹیجرز (`i8` سے `i128` ، اور `isize`) کے لئے ، منفی قدریں دونوں کی تکمیل نمائندگی کے طور پر وضع کی جاتی ہیں۔
///
///
/// متبادل پرچم ، `#` ، آؤٹ پٹ کے سامنے `0o` جوڑتا ہے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` کے ساتھ بنیادی استعمال:
///
/// ```
/// let x = 42; // اکٹیل میں 42 '52' ہے
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ایک قسم پر `Octal` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 کے نفاذ کے لئے مندوب بھیجیں
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait اس کی پیداوار کو بائنری میں ایک نمبر کی شکل میں بنائے۔
///
/// قدیم دستخط کیے ہوئے انٹیجرز ([`i8`] سے [`i128`] ، اور [`isize`]) کے لئے ، منفی قدریں دونوں کی تکمیل نمائندگی کے طور پر وضع کی جاتی ہیں۔
///
///
/// متبادل پرچم ، `#` ، آؤٹ پٹ کے سامنے `0b` جوڑتا ہے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] کے ساتھ بنیادی استعمال:
///
/// ```
/// let x = 42; // بائنری میں 42 '101010' ہے
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ایک قسم پر `Binary` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 کے نفاذ کے لئے مندوب بھیجیں
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait کو اپنی پیداوار کو ہیکساڈیسمل میں ایک نمبر کی شکل میں بنانا چاہئے ، `a` کے ذریعہ `f` کے ذریعہ کم صورت میں۔
///
/// قدیم دستخط کیے ہوئے انٹیجرز (`i8` سے `i128` ، اور `isize`) کے لئے ، منفی قدریں دونوں کی تکمیل نمائندگی کے طور پر وضع کی جاتی ہیں۔
///
///
/// متبادل پرچم ، `#` ، آؤٹ پٹ کے سامنے `0x` جوڑتا ہے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` کے ساتھ بنیادی استعمال:
///
/// ```
/// let x = 42; // ہیکس میں 42 ایکس ایکس ایکس ہے
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// ایک قسم پر `LowerHex` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 کے نفاذ کے لئے مندوب بھیجیں
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait کو اپنی پیداوار کو ہیکساڈیسمل میں ایک نمبر کی شکل میں بنانا چاہئے ، `A` کے ذریعے `F` کے اوپری کیس میں۔
///
/// قدیم دستخط کیے ہوئے انٹیجرز (`i8` سے `i128` ، اور `isize`) کے لئے ، منفی قدریں دونوں کی تکمیل نمائندگی کے طور پر وضع کی جاتی ہیں۔
///
///
/// متبادل پرچم ، `#` ، آؤٹ پٹ کے سامنے `0x` جوڑتا ہے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` کے ساتھ بنیادی استعمال:
///
/// ```
/// let x = 42; // ہیکس میں 42 ایکس ایکس ایکس ہے
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// ایک قسم پر `UpperHex` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 کے نفاذ کے لئے مندوب بھیجیں
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait اس کے آؤٹ پٹ کو میموری کے مقام کی شکل میں بنائے۔
/// یہ عام طور پر ہیکساڈیسیمل کے طور پر پیش کیا جاتا ہے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` کے ساتھ بنیادی استعمال:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // اس سے '0x7f06092ac6d0' کی طرح کچھ پیدا ہوتا ہے
/// ```
///
/// ایک قسم پر `Pointer` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `*const T` کو `* const T` میں تبدیل کرنے کے لئے استعمال کریں ، جو اشارہ نافذ کرتا ہے ، جسے ہم استعمال کرسکتے ہیں
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait کو سائنسی علامت میں اس کی پیداوار کو کم کیس `e` کے ساتھ فارمیٹ کرنا چاہئے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` کے ساتھ بنیادی استعمال:
///
/// ```
/// let x = 42.0; // 42.0 سائنسی اشارے میں '4.2e1' ہے
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ایک قسم پر `LowerExp` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // F64 کے نفاذ کے لئے مندوب بھیجیں
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait کو اس کی پیداوار سائنسی اشارے میں اوپری کیس `E` کے ساتھ وضع کرنا چاہئے۔
///
/// فارمیٹرز کے بارے میں مزید معلومات کے ل X ، [the module-level documentation][module] دیکھیں۔
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` کے ساتھ بنیادی استعمال:
///
/// ```
/// let x = 42.0; // 42.0 سائنسی اشارے میں '4.2E1' ہے
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// ایک قسم پر `UpperExp` لاگو کرنا:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // F64 کے نفاذ کے لئے مندوب بھیجیں
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// دیئے گئے فارمیٹر کا استعمال کرکے قدر کو فارمیٹ کریں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` فنکشن ایک آؤٹ پٹ اسٹریم ، اور ایک `Arguments` ڈھانچہ لیتا ہے جسے `format_args!` میکرو کے ساتھ پیش کیا جاسکتا ہے۔
///
///
/// دلائل کو فراہم کردہ آؤٹ پٹ اسٹریم میں مخصوص فارمیٹ کے تار کے مطابق فارمیٹ کیا جائے گا۔
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// براہ کرم نوٹ کریں کہ [`write!`] استعمال کرنا افضل ہوگا۔مثال:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // ہم تمام دلائل کے لئے پہلے سے طے شدہ فارمیٹنگ پیرامیٹرز استعمال کرسکتے ہیں۔
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ہر ایک قیاس آرائی کی دلیل ہوتی ہے جس سے پہلے اسٹرنگ ٹکڑا ہوتا ہے۔
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // محفوظ: دلیل اور args.args ایک ہی دلائل سے آئے ہیں ،
                // جو اشاریہ کی ہمیشہ ضمانت میں رہتا ہے۔
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // صرف ایک پچھلے سٹرنگ کا ٹکڑا بچ سکتا ہے۔
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // محفوظ: دلیل اور دلیلیں ایک ہی دلیل سے آئیں ،
    // جو اشاریہ کی ہمیشہ ضمانت میں رہتا ہے۔
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // صحیح دلیل نکالیں
    debug_assert!(arg.position < args.len());
    // محفوظ: دلیل اور دلیلیں ایک ہی دلیل سے آئیں ،
    // جو اس کی اشاریہ کی ضمانت دیتا ہے وہ ہمیشہ حدود میں رہتا ہے۔
    let value = unsafe { args.get_unchecked(arg.position) };

    // پھر واقعی کچھ پرنٹنگ کریں
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // حفاظت: cnt اور آرگس ایک ہی دلائل سے آتے ہیں ،
            // جو اس اشاریہ کی ضمانت دیتا ہے وہ ہمیشہ حدود میں رہتا ہے۔
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// کسی چیز کے خاتمے کے بعد بھرنا۔`Formatter::padding` کے ذریعہ واپس آیا۔
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// اس پوسٹ کو بھرتی کریں۔
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // ہم اسے تبدیل کرنا چاہتے ہیں
            buf: wrap(self.buf),

            // اور ان کو محفوظ رکھیں
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // بھرتی کرنے اور فارمیٹنگ فارمیٹنگ دلائل کو استعمال کرنے میں معاون مددگار طریقے جو تمام فارمیٹنگ traits استعمال کرسکتے ہیں۔
    //

    /// ایک عدد کے لئے صحیح بھرتی انجام دیتا ہے جو پہلے سے ہی ایک str میں خارج ہوچکا ہے۔
    /// اسٹر str میں *عدد* نہیں ہونا چاہئے جو عدد کے لئے ہوتا ہے ، جو اس طریقے سے شامل ہوگا۔
    ///
    /// # Arguments
    ///
    /// * is_nonnegative ، چاہے اصلی عدد صحیح یا مثبت تھا یا صفر۔
    /// * صیغہ ، اگر '#' حرف (Alternate) فراہم کیا گیا ہے ، تو نمبر کے سامنے رکھنا یہ ایک ماقبل ہے۔
    ///
    /// * BUF ، بائٹ سرنی جو نمبر میں فارمیٹ ہوچکی ہے
    ///
    /// یہ فنکشن مناسب طریقے سے فراہم کردہ جھنڈوں کے ساتھ ساتھ کم از کم چوڑائی کا محاسبہ کرے گا۔
    /// اس میں درستگی کو مدنظر نہیں رکھا جائے گا۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // ہمیں نمبر آؤٹ پٹ سے "-" کو ہٹانے کی ضرورت ہے۔
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // سائن موجود ہے تو سائن لکھتا ہے ، اور پھر اگر اس کی درخواست کی گئ ہو تو پریفکس لکھتا ہے
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // اس مقام پر `width` فیلڈ میں ایک `min-width` پیرامیٹر زیادہ ہے۔
        match self.width {
            // اگر لمبائی کی کم سے کم ضرورت نہیں ہے تو ہم صرف بائٹس لکھ سکتے ہیں۔
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // چیک کریں کہ آیا ہم کم سے کم چوڑائی سے زیادہ ہیں ، اگر ایسا ہے تو ہم صرف بائٹس بھی لکھ سکتے ہیں۔
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // اگر بھرنے کا کردار صفر ہو تو نشان اور سابقہ بھرنے سے پہلے جاتا ہے
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // بصورت دیگر ، نشان اور سابقہ بھرنے کے بعد چلا جاتا ہے
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// یہ فنکشن سٹرنگ سلائس لیتا ہے اور متعلقہ فارمیٹنگ کے جھنڈوں کو متعین کرنے کے بعد اسے اندرونی بفر پر خارج کرتا ہے۔
    /// عام تار کے لئے پہچانے والے جھنڈے یہ ہیں:
    ///
    /// * چوڑائی ، کیا خارج کرنا ہے اس کی کم از کم چوڑائی
    /// * fill/align - اگر اسٹرنگ کو پیڈ کرنے کی ضرورت ہو تو کیا خارج کرنا ہے اور کہاں خارج کرنا ہے
    /// * صحت سے متعلق ، جس میں زیادہ سے زیادہ لمبائی خارج ہوتی ہے ، اگر تار اس لمبائی سے لمبا ہو تو چھوٹا جاتا ہے
    ///
    /// خاص طور پر یہ فنکشن `flag` پیرامیٹرز کو نظرانداز کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // یقینی بنائیں کہ سامنے کا تیز رفتار راستہ ہے
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` فیلڈ کی ترجمانی `max-width` کے طور پر اسٹرنگ کی شکل میں ہوسکتی ہے۔
        //
        let s = if let Some(max) = self.precision {
            // اگر ہمارے تار لمبے لمبے لمبے لمبے ہیں تو ہمیں لازمی طور پر تراشنا چاہئے۔
            // تاہم ، دوسرے جھنڈوں جیسے `fill` ، `width` اور `align` کو ہمیشہ کی طرح کام کرنا ہوگا۔
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // یہاں LLVM یہ ثابت نہیں کرسکتا ہے کہ `..i` panic `&s[..i]` نہیں کرے گا ، لیکن ہم جانتے ہیں کہ یہ panic نہیں کرسکتا ہے۔
                // `unsafe` سے بچنے کے لئے `get` + `unwrap_or` کا استعمال کریں اور بصورت دیگر یہاں panic سے متعلق کوڈ کا اخراج نہ کریں۔
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // اس مقام پر `width` فیلڈ میں ایک `min-width` پیرامیٹر زیادہ ہے۔
        match self.width {
            // اگر ہم زیادہ سے زیادہ لمبائی کے نیچے ہیں ، اور لمبائی کی کوئی کم سے کم ضرورت نہیں ہے تو ہم صرف تار کا اخراج کرسکتے ہیں
            //
            None => self.buf.write_str(s),
            // اگر ہم زیادہ سے زیادہ چوڑائی کے نیچے ہیں تو ، چیک کریں کہ آیا ہم کم سے کم چوڑائی سے زیادہ ہیں ، اگر ایسا ہے تو یہ تار کی طرح اتنا ہی آسان ہے۔
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // اگر ہم زیادہ سے زیادہ اور کم سے کم چوڑائی دونوں کے نیچے ہیں تو ، پھر مخصوص تار + کچھ سیدھ میں کم از کم چوڑائی بھریں۔
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// پہلے سے بھرنا لکھیں اور غیر تحریری پوسٹ کو بھریں۔
    /// کال کرنے والے اس بات کو یقینی بناتے ہیں کہ پوسٹ پیڈنگ کو اس چیز کے بعد لکھا گیا ہے جس کو پیڈ کیا جارہا ہے۔
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// فارمیٹڈ حصے لیتا ہے اور بھرتی پر لگاتا ہے۔
    /// فرض کریں کہ کال کرنے والے نے پہلے سے ہی حصوں کو مطلوبہ صحت سے متعلق پیش کیا ہے ، تاکہ `self.precision` کو نظرانداز کیا جاسکے۔
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // نشانی واقف صفر پیڈنگ کے ل we ، ہم سب سے پہلے اس علامت کو پیش کرتے ہیں اور ایسا سلوک کرتے ہیں جیسے شروع سے ہی ہماری کوئی علامت نہیں ہے۔
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ایک علامت ہمیشہ پہلے رہتی ہے
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // فارمیٹڈ حصوں سے نشان کو ہٹا دیں
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // باقی حصے عام بھرنے کے عمل سے گزرتے ہیں۔
            let len = formatted.len();
            let ret = if width <= len {
                // بھرتی نہیں
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // یہ عام معاملہ ہے اور ہم ایک شارٹ کٹ لیتے ہیں
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // محفوظ کریں: یہ `flt2dec::Part::Num` اور `flt2dec::Part::Copy` کے لئے استعمال کیا جاتا ہے۔
            // `flt2dec::Part::Num` کے لئے استعمال کرنا محفوظ ہے کیونکہ ہر چار `c` `b'0'` اور `b'9'` کے درمیان ہوتا ہے ، جس کا مطلب ہے `s` درست UTF-8 ہے۔
            // یہ عملی طور پر `flt2dec::Part::Copy(buf)` کے لئے استعمال کرنا بھی محفوظ ہے کیونکہ `buf` سادہ ASCII ہونا چاہئے ، لیکن یہ ممکن ہے کہ کسی کے لئے `buf` کے لئے خراب قدر میں `flt2dec::to_shortest_str` میں منتقل ہونا چونکہ یہ عوامی فعل ہے۔
            //
            // FIXME: معلوم کریں کہ آیا اس کا نتیجہ UB میں ہوسکتا ہے۔
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 زیرو
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// اس فارمیٹر میں شامل بنیادی بفر پر کچھ ڈیٹا لکھتے ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // اس کے برابر ہے:
    ///         // لکھیں! (فارمیٹر ، "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// اس مثال کے لئے کچھ فارمیٹڈ معلومات لکھتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// فارمیٹنگ کے لئے جھنڈے
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// جب بھی صف بندی ہو تو 'fill' کے طور پر استعمال کردہ کردار۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ہم ">" کے ساتھ دائیں سیدھ میں لائیں۔
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// جھنڈے سے پتہ چلتا ہے کہ سیدھ کی کس شکل کی درخواست کی گئی تھی۔
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// اختیاری طور پر مختص عددی چوڑائی جس کی پیداوار ہونی چاہئے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // اگر ہمیں چوڑائی ملی ہے ، تو ہم اسے استعمال کرتے ہیں
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // ورنہ ہم کچھ خاص نہیں کرتے ہیں
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// عددی اقسام کے لئے اختیاری طور پر مخصوص صحت سے متعلق۔
    /// متبادل کے طور پر ، تار کی قسموں کے لئے زیادہ سے زیادہ چوڑائی۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // اگر ہمیں صحت سے متعلق موصول ہوا تو ہم اسے استعمال کرتے ہیں۔
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // بصورت دیگر ہم ڈیفالٹ 2۔
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` پرچم کی وضاحت کی گئی تھی تو اس کا تعین کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` پرچم کی وضاحت کی گئی تھی تو اس کا تعین کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // کیا آپ مائنس سائن چاہتے ہیں؟ایک ہے!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` پرچم کی وضاحت کی گئی تھی تو اس کا تعین کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` پرچم کی وضاحت کی گئی تھی تو اس کا تعین کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // ہم فارمیٹر کے اختیارات کو نظرانداز کرتے ہیں۔
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: فیصلہ کریں کہ ان دو جھنڈوں کے لئے ہم کون سا عوامی API چاہتے ہیں۔
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// ایک [`DebugStruct`] بلڈر تیار کرتا ہے جس کے ذریعہ ڈھانچے کے لئے [`fmt::Debug`] پر عمل درآمد کرنے میں مدد کے لئے ڈیزائن کیا گیا ہے۔
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ایک `DebugTuple` بلڈر تخلیق کرتا ہے جس میں ٹوپل سٹرک کے لئے `fmt::Debug` نفاذات کی تخلیق میں مدد کے لئے ڈیزائن کیا گیا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// ایک `DebugList` بلڈر تیار کرتا ہے جو فہرست جیسے ڈھانچے کے ل X `fmt::Debug` نفاذ کی تشکیل میں مدد کے لئے ڈیزائن کیا گیا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// ایک `DebugSet` بلڈر تیار کرتا ہے جو سیٹ جیسے ڈھانچے کے لئے `fmt::Debug` نفاذ کی تشکیل میں مدد کے لئے ڈیزائن کیا گیا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// اس سے زیادہ پیچیدہ مثال میں ، ہم میچ بازو کی ایک فہرست بنانے کیلئے [`format_args!`] اور `.debug_set()` استعمال کرتے ہیں۔
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// `DebugMap` بلڈر تیار کرتا ہے جو نقشہ نما ڈھانچے کے لئے `fmt::Debug` نفاذ کی تخلیق میں مدد کے لئے ڈیزائن کیا گیا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// کور فارمیٹنگ traits کی نفاذ

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // اگر چار کو فرار ہونے کی ضرورت ہے تو ، ابھی تک بیک فلگ فلش کریں اور لکھیں ، ورنہ اچٹیں
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // متبادل پرچم کا پہلے ہی لوئر ہیکس کے ساتھ خاص سلوک کیا جاتا ہے۔ اس سے یہ ظاہر ہوتا ہے کہ آیا 0x کے ساتھ سابقہ لگانا ہے یا نہیں۔
        // ہم اسے صفر میں توسیع کرنے یا نہ کرنے پر کام کرنے کے لئے استعمال کرتے ہیں ، اور پھر اسے غیر مشروط طور پر پیش کرتے ہیں۔
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// مختلف بنیادی اقسام کے لئے Display/Debug کا نفاذ

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // ریف سکیل باہمی قرض لیا گیا ہے لہذا ہم یہاں اس کی قدر نہیں دیکھ سکتے ہیں۔
                // اس کے بجائے ایک پلیس ہولڈر دکھائیں۔
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// اگر آپ کو یہاں ٹیسٹ ہونے کی توقع ہے تو ، اس کے بجائے core/tests/fmt.rs فائل کو دیکھیں ، یہاں کی تمام rt::Piece ڈھانچے بنانے سے کہیں زیادہ آسان ہے۔
//
// crate میں مختص ٹیسٹ بھی ہیں ، ان لوگوں کے لئے جو مختص کرنے کی ضرورت ہے۔