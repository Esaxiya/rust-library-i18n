//! اختیاری اقدار
//!
//! قسم [`Option`] ایک اختیاری قدر کی نمائندگی کرتا ہے: ہر [`Option`] یا تو [`Some`] ہوتا ہے اور اس میں ایک قدر ، یا [`None`] ہوتا ہے ، اور ایسا نہیں ہوتا ہے۔
//! [`Option`] Rust کوڈ میں اقسام بہت عام ہیں ، کیونکہ ان کے بہت سے استعمال ہوتے ہیں:
//!
//! * ابتدائی اقدار
//! * ان افعال کے ل values قیمتیں واپس کردیں جو ان کی پوری ان پٹ رینج (جزوی افعال) پر تعریف نہیں کی گئیں
//! * دوسری صورت میں سادہ غلطیوں کی اطلاع دینے کیلئے واپسی کی قیمت ، جہاں [`None`] غلطی پر واپس آ جاتا ہے
//! * اختیاری ڈھانچے کے فیلڈز
//! * ایسے فیلڈس کو بنائیں جن پر قرض لیا جاسکے یا "taken"
//! * اختیاری تقریب دلائل
//! * ناقص اشارے
//! * مشکل حالات سے باہر چیزوں کو تبدیل کرنا
//!
//! [`آپشن`] کو عام طور پر کسی قدر کی موجودگی کے بارے میں سوال کرنے اور کارروائی کرنے کیلئے پیٹرن میچنگ کے ساتھ جوڑا بنایا جاتا ہے ، ہمیشہ ہی [`None`] کیس کا محاسب ہوتا ہے۔
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // فنکشن کی واپسی کی قیمت ایک آپشن ہے
//! let result = divide(2.0, 3.0);
//!
//! // قدر بازیافت کرنے کے لئے پیٹرن میچ
//! match result {
//!     // ڈویژن درست تھا
//!     Some(x) => println!("Result: {}", x),
//!     // ڈویژن غلط تھا
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: یہ بتائیں کہ بہت سارے طریقوں کے ساتھ ، `Option` کو عملی طور پر کس طرح استعمال کیا جاتا ہے
//
//! # اختیارات اور پوائنٹر ("nullable" پوائنٹر)
//!
//! Rust کی پوائنٹر کی اقسام کو ہمیشہ کسی درست مقام کی طرف اشارہ کرنا ضروری ہے۔یہاں "null" حوالہ جات موجود نہیں ہیں۔اس کے بجائے ، Rust کے پاس *اختیاری* پوائنٹر ہیں ، جیسے اختیاری ملکیت والے باکس ، [`آپشن`]`<`[`باکس<T>`]`>`۔
//!
//! مندرجہ ذیل مثال میں [`i32`] کا اختیاری باکس بنانے کے لئے [`Option`] کا استعمال کیا گیا ہے۔
//! نوٹ کریں کہ پہلے اندرونی [`i32`] قدر کو استعمال کرنے کے ل، ، `check_optional` فنکشن کو پیٹرن مماثل استعمال کرنے کی ضرورت ہے تاکہ اس بات کا تعین کیا جا سکے کہ باکس کی کوئی اہمیت ہے (یعنی ، یہ [`Some(...)`][`Some`]) ہے یا ([`None`]) نہیں۔
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust مندرجہ ذیل اقسام `T` کو بہتر بنانے کی ضمانت دیتا ہے جیسے [`Option<T>`] کے سائز کا سائز `T` ہے:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` اس فہرست میں سے ایک قسم کے ارد گرد ڈھانچہ بنائیں۔
//!
//! اس کی مزید ضمانت دی گئی ہے کہ ، مذکورہ بالا معاملات کے ل one ،[`mem::transmute`] X کی XL2X سے `Option<T>` اور X0X X سے `T` تک کی تمام جائز اقدار سے [`mem::transmute`] (لیکن `None::<T>` کو `T` میں منتقل کرنا غیر متعینہ طرز عمل ہے)۔
//!
//! # Examples
//!
//! [`Option`] پر ملاوٹ کا بنیادی نمونہ:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // موجود تار کا حوالہ لیں
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // آپشن کو تباہ کرتے ہوئے موجود سٹرنگ کو ہٹائیں
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! لوپ سے پہلے کسی نتیجے کو [`None`] پر شروع کریں:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // تلاش کرنے کے لئے اعداد و شمار کی ایک فہرست۔
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // ہم سب سے بڑے جانور کا نام تلاش کرنے جارہے ہیں ، لیکن اس کے ساتھ شروع کرنے کے لئے ہمارے پاس ابھی `None` ہے۔
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // اب ہمیں کسی بڑے جانور کا نام مل گیا ہے
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` قسم۔مزید کے لئے [the module level documentation](self) دیکھیں۔
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// کوئی قدر نہیں
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// کچھ قدر `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// قسم کا نفاذ
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // موجود اقدار سے استفسار کرنا
    /////////////////////////////////////////////////////////////////////////

    /// اگر اختیار [`Some`] قدر کا ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// اگر اختیار [`None`] قدر کا ہے تو `true` کو لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// اگر آپشن میں دی گئی قدر پر مشتمل [`Some`] ویلیو ہو تو `true` کو لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // حوالوں کے ساتھ کام کرنے کے ل Ad اڈاپٹر
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` سے `Option<&T>` میں تبدیل ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// اصل کو محفوظ رکھتے ہوئے `آپشن <` [`اسٹرنگ]`> `کو` آپشن <`[` usize`]`>` میں تبدیل کرتا ہے۔
    /// [`map`] کا طریقہ `self` دلیل کو قدر کے ذریعہ لے جاتا ہے ، اصل کو کھا جاتا ہے ، لہذا یہ تکنیک `as_ref` کا استعمال کرتا ہے پہلے `Option` کو اصل کے اندر کی قیمت کے حوالے سے لے جائے۔
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // پہلے ، `Option<String>` کو `as_ref` کے ساتھ `Option<&String>` پر کاسٹ کریں ، پھر `map` کے ساتھ اسٹیک پر `text` چھوڑ کر *جو* کھائیں۔
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` سے `Option<&mut T>` میں تبدیل ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`Pin`]`<اور آپشن سے تبدیل ہوتا ہے<T>>`سے`آپشن <`[`پن`] `<&T>>`۔
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // محفوظ: `x` کی پن کی ضمانت دی گئی ہے کیونکہ یہ `self` سے آتی ہے
        // جو پنڈ ہے۔
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`Pin`]`<&mut آپشن سے تبدیل ہوتا ہے<T>>`سے`آپشن <`[`Pin`] `<&mut T>>`۔
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // محفوظ: `get_unchecked_mut` کو `self` کو `self` کے اندر منتقل کرنے کے لئے کبھی استعمال نہیں کیا جاتا ہے۔
        // `x` پن کی ضمانت دی جاتی ہے کیونکہ یہ `self` سے آتی ہے جو پن ہے۔
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // پر مشتمل اقدار کو حاصل کرنا
    /////////////////////////////////////////////////////////////////////////

    /// [`Some`] ایکس قدر استعمال کرتے ہوئے ، موجود [`Some`] قدر لوٹاتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر قدر X001 ہے جس میں `msg` کے ذریعہ فراہم کردہ ایک کسٹم panic پیغام ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// [`Some`] ایکس قدر استعمال کرتے ہوئے ، موجود [`Some`] قدر لوٹاتا ہے۔
    ///
    /// چونکہ یہ فنکشن panic ہوسکتا ہے ، لہذا عام طور پر اس کے استعمال کی حوصلہ شکنی کی جاتی ہے۔
    /// اس کے بجائے ، پیٹرن میچنگ کو استعمال کرنے اور [`None`] کیس کو واضح طور پر سنبھالنے کو ترجیح دیں ، یا [`unwrap_or`] ، [`unwrap_or_else`] ، یا [`unwrap_or_default`] پر کال کریں۔
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics اگر سیلف ویلیو [`None`] کے برابر ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// شامل [`Some`] قدر یا فراہم کردہ پہلے سے طے شدہ کو لوٹاتا ہے۔
    ///
    /// `unwrap_or` کو منظور دلائل کا بے تابی سے جائزہ لیا جاتا ہے۔اگر آپ کسی فنکشن کال کا نتیجہ پاس کر رہے ہیں تو ، آپ کو [`unwrap_or_else`] استعمال کرنے کی سفارش کی جاتی ہے ، جس کا سست انداز میں اندازہ کیا جاتا ہے۔
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// موجود [`Some`] قدر لوٹاتا ہے یا بند ہونے سے اس کی گنتی کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// `self` ویلیو کو استعمال کرتے ہوئے ، پر مشتمل [`Some`] قدر لوٹاتا ہے ، بغیر جانچ پڑتال کے کہ ویلیو [`None`] نہیں ہے۔
    ///
    ///
    /// # Safety
    ///
    /// اس طریقہ کو [`None`] پر کال کرنا *[غیر وضاحتی سلوک]* ہے۔
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // غیر متعینہ سلوک!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // حفاظت: حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے۔
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // تبدیلیوں پر مشتمل اقدار
    /////////////////////////////////////////////////////////////////////////

    /// کسی فنکشن کو موجود قدر پر لاگو کرکے ایک `Option<T>` سے `Option<U>` کا نقشہ بنائیں۔
    ///
    /// # Examples
    ///
    /// اصل کو استعمال کرتے ہوئے ، کسی `آپشن <` [`اسٹرنگ]`> `کو` آپشن <`[` usize`]`>` میں تبدیل کرتا ہے:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` استعمال کرتے ہوئے ، خود *قیمت کے لحاظ سے* لیتا ہے
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// موجود قیمت (اگر کوئی ہے) پر ایک فنکشن لاگو کریں ، یا فراہم کردہ ڈیفالٹ (اگر نہیں تو) واپس کردیں۔
    ///
    /// `map_or` کو منظور دلائل کا بے تابی سے جائزہ لیا جاتا ہے۔اگر آپ کسی فنکشن کال کا نتیجہ پاس کر رہے ہیں تو ، آپ کو [`map_or_else`] استعمال کرنے کی سفارش کی جاتی ہے ، جس کا سست انداز میں اندازہ کیا جاتا ہے۔
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// موجود قیمت (اگر کوئی ہے) پر ایک فنکشن لاگو کریں ، یا پہلے سے طے شدہ (اگر نہیں) کی گنتی کریں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` کو [`Result<T, E>`] میں `Option<T>` ، [`Ok(v)`] اور [`None`] کو [`Err(err)`] میں `Option<T>` کا نقشہ بناتا ہے۔
    ///
    /// `ok_or` کو منظور دلائل کا بے تابی سے جائزہ لیا جاتا ہے۔اگر آپ کسی فنکشن کال کا نتیجہ پاس کر رہے ہیں تو ، آپ کو [`ok_or_else`] استعمال کرنے کی سفارش کی جاتی ہے ، جس کا سست انداز میں اندازہ کیا جاتا ہے۔
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` کو [`Result<T, E>`] میں `Option<T>` ، [`Ok(v)`] اور [`None`] کو [`Err(err())`] میں `Option<T>` کا نقشہ بناتا ہے۔
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// آپشن میں `value` داخل کرتا ہے اور پھر اس میں تبدیلی کا حوالہ دیتا ہے۔
    ///
    /// اگر آپشن میں پہلے سے ہی ایک قیمت موجود ہے تو ، پرانی قدر گرا دی جاتی ہے۔
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // محفوظ کریں: اوپر والے کوڈ نے صرف آپشن کو پُر کیا
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Iterator تعمیرات
    /////////////////////////////////////////////////////////////////////////

    /// ممکنہ طور پر موجود قدر پر ایک آئریٹر لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// ممکنہ طور پر موجود قدر پر ایک بدلنے والا دوبارہ چلاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // قدروں پر بولین آپریشن ، بے چین اور سست
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] واپس کرتا ہے اگر آپشن [`None`] ہے ، بصورت دیگر `optb` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// [`None`] لوٹاتا ہے اگر آپشن [`None`] ہے ، بصورت دیگر `f` کو لپیٹے ہوئے قدر کے ساتھ کال کرتا ہے اور نتیجہ لوٹاتا ہے۔
    ///
    ///
    /// کچھ زبانیں اس آپریشن کو فلیٹ میپ کہتے ہیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// اگر اختیار [`None`] ہے تو [`None`] کو لوٹاتا ہے ، بصورت دیگر `predicate` کو لپٹی ہوئی قیمت کے ساتھ کال کرتا ہے اور واپس آتا ہے:
    ///
    ///
    /// - [`Some(t)`] اگر `predicate` `true` (جہاں `t` لپیٹی ہوئی قیمت ہے) ، اور
    /// - [`None`] اگر `predicate` `false` واپس کرتا ہے۔
    ///
    /// یہ فنکشن [`Iterator::filter()`] کی طرح کام کرتا ہے۔
    /// آپ تصور کرسکتے ہیں کہ `Option<T>` ایک یا صفر عناصر سے زیادہ ہونے والا ہے۔
    /// `filter()` کون سے عناصر کو رکھنا ہے اس کا فیصلہ کرنے دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// اگر اس میں کوئی قدر شامل ہو تو اختیار کو لوٹاتا ہے ، بصورت دیگر `optb` لوٹاتا ہے۔
    ///
    /// `or` کو منظور دلائل کا بے تابی سے جائزہ لیا جاتا ہے۔اگر آپ کسی فنکشن کال کا نتیجہ پاس کر رہے ہیں تو ، آپ کو [`or_else`] استعمال کرنے کی سفارش کی جاتی ہے ، جس کا سست انداز میں اندازہ کیا جاتا ہے۔
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// اگر اس میں کوئی قدر شامل ہو تو اختیار کو لوٹاتا ہے ، بصورت دیگر `f` پر کال کردیتا ہے اور نتیجہ لوٹاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// [`Some`] واپس کرتا ہے اگر `self` میں سے ایک ، `optb` [`Some`] ہے ، ورنہ [`None`] واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // اندراج کی طرح کی کارروائیوں کو داخل کرنے کیلئے اور کوئی نہیں تو حوالہ واپس کریں
    /////////////////////////////////////////////////////////////////////////

    /// اگر یہ [`None`] ہے تو `value` کو اختیار میں داخل کرتا ہے ، پھر اس میں موجود قدر کا ایک تبادلہ حوالہ واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// ڈیفالٹ ویلیو کو آپشن میں داخل کرتا ہے اگر یہ [`None`] ہے ، تو پھر رکھی ہوئی ویلیو کو ایڈجسٹ ریفرنس واپس کرے گا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` سے گنتی والی قدر کو آپشن میں داخل کرتا ہے اگر یہ [`None`] ہے تو ، اس میں موجود قدر کا ایک تبادلہ حوالہ واپس کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // محفوظ: `self` کے لئے ایک `None` مختلف حالت میں `Some` کی جگہ لینا چاہئے
            // مندرجہ بالا کوڈ میں مختلف
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// ایک [`None`] کو اپنی جگہ پر چھوڑ کر ، اختیار کو ختم کرنے میں مدد لیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// پیرامیٹر میں دی گئی قدر سے آپشن میں اصل قدر کی جگہ لے لیتی ہے ، اگر موجود ہو تو پرانی قدر لوٹائے ، ایک [`Some`] کو اپنی جگہ پر چھوڑ کر کسی ایک کو بھی نمایاں بنائے بغیر۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// ایک اور `Option` کے ساتھ زپ `self`۔
    ///
    /// اگر `self` `Some(s)` ہے اور `other` `Some(o)` ہے ، تو یہ طریقہ `Some((s, o))` واپس کرتا ہے۔
    /// ورنہ ، `None` لوٹ گیا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// فنکشن `f` کے ساتھ زپ `self` اور دوسرا `Option`۔
    ///
    /// اگر `self` `Some(s)` ہے اور `other` `Some(o)` ہے ، تو یہ طریقہ `Some(f(s, o))` واپس کرتا ہے۔
    /// ورنہ ، `None` لوٹ گیا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// آپشن کے مندرجات کی نقل کرکے ایک `Option<&T>` کو `Option<T>` کا نقشہ بنائیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// آپشن کے مندرجات کی نقل کرکے ایک `Option<&mut T>` کو `Option<T>` کا نقشہ بنائیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// آپشن کے مندرجات کی کلوننگ کرکے ایک `Option<&T>` کو `Option<T>` کا نقشہ بنائیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// آپشن کے مندرجات کی کلوننگ کرکے ایک `Option<&mut T>` کو `Option<T>` کا نقشہ بنائیں۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// `self` کی توقع کرتے ہوئے اور کچھ نہیں لوٹاتے ہوئے `self` استعمال کرتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر قیمت [`Some`] ہے ، جس میں panic پیغام ، بشمول منظور شدہ پیغام ، اور [`Some`] کا مواد ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // یہ panic نہیں کرے گا ، کیوں کہ سبھی چابیاں الگ الگ ہیں۔
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// `self` کی توقع کرتے ہوئے اور کچھ نہیں لوٹاتے ہوئے `self` استعمال کرتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر قیمت [`Some`] ہے ، تو ، اپنی مرضی کے مطابق panic پیغام کے ساتھ [`Some`] کی قدر۔
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // یہ panic نہیں کرے گا ، کیوں کہ سبھی چابیاں الگ الگ ہیں۔
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// موجود [`Some`] قدر یا پہلے سے طے شدہ کو لوٹاتا ہے
    ///
    /// پھر `self` دلیل لیتا ہے ، اگر [`Some`] ، موجود قیمت کو واپس کرتا ہے ، بصورت دیگر اگر [`None`] ، اس قسم کے لئے [default value] لوٹاتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ناقص بنائے ہوئے تاروں کو 0 میں بدل دیتا ہے ، اعداد کو اعداد و شمار میں بدل دیتا ہے (عددیوں کے لئے پہلے سے طے شدہ قدر)۔
    /// [`parse`] اسٹرنگ کو کسی دوسری قسم میں تبدیل کرتا ہے جو [`FromStr`] پر عمل درآمد کرتا ہے ، غلطی پر [`None`] کو لوٹاتا ہے۔
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (یا `&Option<T>`) سے `Option<&T::Target>` میں تبدیل ہوتا ہے۔
    ///
    /// اصل آپشن کو جگہ جگہ چھوڑ دیتا ہے ، اصل کے حوالے سے ایک نیا تیار کرتا ہے ، اور اضافی طور پر [`Deref`] کے ذریعے مندرجات پر جبر کرتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (یا `&mut Option<T>`) سے `Option<&mut T::Target>` میں تبدیل ہوتا ہے۔
    ///
    /// اصل `Option` کو جگہ جگہ چھوڑ دیتا ہے ، جس سے ایک نیا تیار ہوتا ہے جس میں داخلی قسم کی `Deref::Target` قسم کا تغیر پذیر حوالہ ہوتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] کے `Option` کو `Option` کے [`Result`] میں تبدیل کرتا ہے۔
    ///
    /// [`None`] [`Ok`]`(`[`No``] `)` پر نقشہ سازی کی جائے گی۔
    /// [`کچھ`]`(`[`Ok`] `(_))` اور [`کچھ`]`(`[`غلطی]`(_)) کو [`Ok`] `(`[`کچھ`] `(_))` اور [`ایرر]` (_) `۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// خود .expect() کے کوڈ سائز کو کم کرنے کے لئے یہ ایک الگ فنکشن ہے۔
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// خود .expect_none() کے کوڈ سائز کو کم کرنے کے لئے یہ ایک الگ فنکشن ہے۔
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait نفاذات
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ممکنہ طور پر موجود قدر سے زیادہ ایک کھپت کرنے والا دوبارہ کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` کو ایک نئے `Some` میں کاپی کریں۔
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` سے `Option<&T>` میں تبدیل ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// اصل کو محفوظ رکھتے ہوئے `آپشن <` [`اسٹرنگ]`> `کو` آپشن <`[` usize`]`>` میں تبدیل کرتا ہے۔
    /// [`map`] کا طریقہ `self` دلیل کو قدر کے ذریعہ لے جاتا ہے ، اصل کو کھا جاتا ہے ، لہذا یہ تکنیک `as_ref` کا استعمال کرتا ہے پہلے `Option` کو اصل کے اندر کی قیمت کے حوالے سے لے جائے۔
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` سے `Option<&mut T>` میں تبدیل ہوتا ہے
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// آپشن آئٹریٹر
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// ایک [`Option`] کے [`Some`] مختلف حالت کے حوالہ پر ایک تکرار کرنے والا۔
///
/// اگر [`Option`] ایک [`Some`] ہے تو ، دوبارہ کرنے والے کو ایک قیمت ملتی ہے ، ورنہ کچھ بھی نہیں۔
///
/// یہ `struct` [`Option::iter`] فنکشن کے ذریعہ تشکیل دیا گیا ہے۔
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// ایک [`Option`] کے [`Some`] مختلف حالت میں بدلنے والے حوالہ سے زیادہ ایک تکرار کرنے والا۔
///
/// اگر [`Option`] ایک [`Some`] ہے تو ، دوبارہ کرنے والے کو ایک قیمت ملتی ہے ، ورنہ کچھ بھی نہیں۔
///
/// یہ `struct` [`Option::iter_mut`] فنکشن کے ذریعہ تشکیل دیا گیا ہے۔
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// ایک [`Option`] کے [`Some`] مختلف شکل میں ایک قدر کرنے والا۔
///
/// اگر [`Option`] ایک [`Some`] ہے تو ، دوبارہ کرنے والے کو ایک قیمت ملتی ہے ، ورنہ کچھ بھی نہیں۔
///
/// یہ `struct` [`Option::into_iter`] فنکشن کے ذریعہ تشکیل دیا گیا ہے۔
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// ہر عنصر کو [`Iterator`] میں لے جاتا ہے: اگر یہ [`None`][Option::None] ہے تو ، مزید عناصر نہیں لئے جاتے ہیں ، اور [`None`][Option::None] واپس کردیتا ہے۔
    /// اگر کوئی [`None`][Option::None] واقع نہیں ہوتا ہے تو ، ہر [`Option`] کی اقدار والا کنٹینر واپس کردیا جاتا ہے۔
    ///
    /// # Examples
    ///
    /// یہاں ایک مثال ہے جو vector میں ہر عدد کو بڑھا دیتی ہے۔
    /// ہم `add` کی جانچ شدہ حالت کا استعمال کرتے ہیں جو `None` کو واپس کرتا ہے جب حساب کتاب کا بہاؤ ہوجائے گا۔
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// جیسا کہ آپ دیکھ سکتے ہیں ، اس سے متوقع ، جائز اشیاء واپس آئیں گی۔
    ///
    /// یہاں ایک اور مثال ہے جو انٹیجرز کی ایک اور فہرست سے کسی کو گھٹانے کی کوشش کرتی ہے ، اس بار زیر بہا تلاش کررہے ہیں:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// چونکہ آخری عنصر صفر ہے ، لہذا یہ بہہ جائے گا۔اس طرح ، نتیجہ کی قیمت `None` ہے۔
    ///
    /// یہاں پچھلی مثال کے بارے میں ایک تغیرات دی جارہی ہیں ، اس سے یہ ظاہر ہوتا ہے کہ پہلے `None` کے بعد `iter` سے مزید عناصر نہیں لئے گئے ہیں۔
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// چونکہ تیسرے عنصر کی وجہ سے پانی کی روانی پھیل گئی ، لہذا مزید عناصر نہیں لائے گئے ، لہذا `shared` کی حتمی قیمت 6 (= `3 + 2 + 1`) ہے ، 16 نہیں۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): جب اس کارکردگی کا بگ بند ہو تو اسے Iterator::scan کے ساتھ تبدیل کیا جاسکتا ہے۔
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// غلطی کی قسم جو ٹرپ آپریٹر (`?`) کو `None` قدر پر لاگو کرنے کے نتیجے میں نکلتی ہے۔
/// اگر آپ `x?` (جہاں `x` ایک `Option<T>` ہے) کو اپنی غلطی کی قسم میں تبدیل کرنے کی اجازت دینا چاہتے ہیں تو ، آپ `YourErrorType` کیلئے `impl From<NoneError>` لاگو کرسکتے ہیں۔
///
/// اس صورت میں ، ایک فنکشن کے اندر جو `x?` جو `Result<_, YourErrorType>` کو واپس کرتا ہے وہ `None` قدر کو `Err` کے نتیجے میں ترجمہ کرے گا۔
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` سے `Option<T>` میں تبدیل ہوتا ہے
    ///
    /// # Examples
    ///
    /// بنیادی استعمال:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// چاپلوسی کرنا ایک وقت میں گھوںسلا کے صرف ایک درجے کو ہٹا دیتا ہے:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}