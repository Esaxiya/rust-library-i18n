//! ایسی اقسام کے لئے `Default` trait جس میں بامعنی طے شدہ اقدار ہوسکتی ہیں۔

#![stable(feature = "rust1", since = "1.0.0")]

/// ایک قسم کو مفید ڈیفالٹ قدر دینے کے لئے ایک trait۔
///
/// بعض اوقات ، آپ کسی قسم کی پہلے سے طے شدہ قیمت پر واپس آنا چاہتے ہیں ، اور خاص طور پر اس کی پرواہ نہیں کرتے کہ یہ کیا ہے۔
/// یہ اکثر `ڈھانچے کے ساتھ سامنے آتا ہے جو اختیارات کی ایک سیٹ کی وضاحت کرتا ہے:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// ہم کچھ طے شدہ اقدار کی وضاحت کیسے کرسکتے ہیں؟آپ `Default` استعمال کرسکتے ہیں:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// اب ، آپ کو تمام طے شدہ اقدار مل جاتی ہیں۔Rust مختلف ابتدائی اقسام کے لئے `Default` لاگو کرتا ہے۔
///
/// اگر آپ کسی خاص آپشن کو اوور رائڈ کرنا چاہتے ہیں ، لیکن پھر بھی دوسرے ڈیفالٹس کو برقرار رکھیں۔
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// یہ trait `#[derive]` کے ساتھ استعمال کیا جاسکتا ہے اگر تمام قسم کے فیلڈز `Default` کو لاگو کریں۔
/// جب اخذ کیا جاتا ہے تو ، یہ ہر فیلڈ کی قسم کے لئے پہلے سے طے شدہ قدر کا استعمال کرے گا۔
///
/// ## میں `Default` کو کس طرح نافذ کرسکتا ہوں؟
///
/// `default()` طریقہ کے ل an عمل درآمد فراہم کریں جو آپ کی قسم کی قیمت واپس کردے جو پہلے سے طے شدہ ہونا چاہئے:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// ایک قسم کے لئے "default value" لوٹاتا ہے۔
    ///
    /// پہلے سے طے شدہ قدریں کسی نہ کسی طرح کی ابتدائی قدر ، شناخت کی قیمت ، یا کوئی اور چیز ہوتی ہیں جو بطور ڈیفالٹ سمجھ میں آسکتی ہیں۔
    ///
    ///
    /// # Examples
    ///
    /// بلٹ ان ڈیفالٹ قدروں کا استعمال:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// اپنا بنانا:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait کے مطابق کسی قسم کی ڈیفالٹ ویلیو واپس کریں۔
///
/// واپسی کی قسم سیاق و سباق سے قیاس کی گئی ہے۔یہ `Default::default()` کے برابر ہے لیکن اس سے چھوٹا ٹائپ کرنا۔
///
/// مثال کے طور پر:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }