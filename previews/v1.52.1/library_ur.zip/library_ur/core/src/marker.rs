//! قدیم traits اور اقسام کی بنیادی خصوصیات کی نمائندگی کرنے والی اقسام۔
//!
//! Rust اقسام کو ان کی اندرونی خصوصیات کے مطابق مختلف مفید طریقوں میں درجہ بندی کیا جاسکتا ہے۔
//! یہ درجہ بندی traits کی نمائندگی کی جاتی ہے۔
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// اقسام جو دھاگوں کی حدود میں منتقل ہوسکتی ہیں۔
///
/// یہ trait خود کار طریقے سے لاگو ہوتا ہے جب کمپلر طے کرتا ہے کہ یہ مناسب ہے۔
///
/// غیر `Send` قسم کی ایک مثال حوالہ گنتی پوائنٹر [`rc::Rc`][`Rc`] ہے۔
/// اگر دو دھاگے [`Rc`] s کو کلون کرنے کی کوشش کرتے ہیں جو ایک ہی حوالہ سے گنتی والی قدر کی طرف اشارہ کرتے ہیں تو ، وہ ایک ہی وقت میں حوالہ گنتی کو اپ ڈیٹ کرنے کی کوشش کر سکتے ہیں ، جو [undefined behavior][ub] ہے کیونکہ X01 ایکس جوہری کارروائیوں کا استعمال نہیں کرتا ہے۔
///
/// اس کا کزن [`sync::Arc`][arc] جوہری آپریشن (کچھ اوور ہیڈ پر مشتمل) کا استعمال کرتا ہے اور اس طرح `Send` ہے۔
///
/// مزید تفصیلات کے لئے [the Nomicon](../../nomicon/send-and-sync.html) دیکھیں۔
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// مستقل سائز والی اقسام جس کو مرتب وقت پر جانا جاتا ہے۔
///
/// تمام قسم کے پیرامیٹرز میں `Sized` کی باہمی پابندی ہوتی ہے۔خصوصی نحو `?Sized` اس پابند کو دور کرنے کے لئے استعمال کیا جاسکتا ہے اگر یہ مناسب نہیں ہے۔
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // سٹرک X01 ایکس؛//غلطی: [i32] کے لئے سائز نافذ نہیں کیا گیا ہے
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ایک رعایت trait کی ضمیمہ `Self` قسم ہے۔
/// trait کا کوئی `Sized` پابند نہیں ہوتا ہے کیونکہ یہ [trait آبجیکٹ] s سے مطابقت نہیں رکھتا جہاں ، تعریف کے مطابق ، trait کو ہر ممکنہ نفاذ کاروں کے ساتھ کام کرنے کی ضرورت ہوتی ہے ، اور اس طرح اس کا سائز بھی ہوسکتا ہے۔
///
///
/// اگرچہ Rust آپ `Sized` کو trait پر پابند کرنے دے گا ، آپ بعد میں اسے trait آبجیکٹ بنانے کے ل use استعمال نہیں کرسکیں گے:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // چلو y: &dyn بار= &Impl؛//خرابی: trait `Bar` کو کسی شے میں نہیں بنایا جاسکتا
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // پہلے سے طے شدہ کے لئے ، مثال کے طور پر ، جس میں `[T]: !Default` کی جانچ پڑتال کی ضرورت ہوتی ہے
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// اقسام جو متحرک سائز کی قسم میں "unsized" ہوسکتی ہیں۔
///
/// مثال کے طور پر ، سائز کی سرنی قسم `[i8; 2]` `Unsize<[i8]>` اور `Unsize<dyn fmt::Debug>` لاگو کرتی ہے۔
///
/// `Unsize` کے تمام نفاذ کمپلر خود بخود فراہم کرتے ہیں۔
///
/// `Unsize` کے لئے لاگو کیا جاتا ہے:
///
/// - `[T; N]` `Unsize<[T]>` ہے
/// - `T` `Unsize<dyn Trait>` ہے جب `T: Trait`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` ہے اگر:
///   - `T: Unsize<U>`
///   - فو ایک ڈھانچہ ہے
///   - صرف `Foo` کے آخری فیلڈ میں ایک قسم ہے جس میں `T` شامل ہے
///   - `T` کسی دوسرے فیلڈ کی قسم کا حصہ نہیں ہے
///   - `Bar<T>: Unsize<Bar<U>>`, اگر `Foo` کے آخری فیلڈ میں `Bar<T>` کی قسم ہے
///
/// `Unsize` [`ops::CoerceUnsized`] کے ساتھ ساتھ استعمال کیا جاتا ہے تاکہ "user-defined" کنٹینرز جیسے [`Rc`] متحرک سائز کی اقسام پر مشتمل ہو۔
/// مزید تفصیلات کے لئے [DST coercion RFC][RFC982] اور [the nomicon entry on coercion][nomicon-coerce] دیکھیں۔
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// پیٹرن میچوں میں مستقل طور پر استعمال ہونے والے trait کی ضرورت ہے۔
///
/// کسی بھی قسم کی جو X01 کو حاصل کرتی ہے وہ خود کار طریقے سے اس trait پر عمل درآمد کرتی ہے ، چاہے اس کے پیرامیٹرز `Eq` کو لاگو کریں۔
///
/// اگر کسی `const` آئٹم پر کچھ قسم ہے جو اس trait پر عمل درآمد نہیں کرتی ہے ، تو پھر اس قسم میں سے (1.) `PartialEq` کو لاگو نہیں کرتا ہے (جس کا مطلب ہے کہ مستقل موازنہ کا طریقہ فراہم نہیں کرے گا ، جس کوڈ جنریشن کا فرض ہے کہ وہ دستیاب ہے) ، یا (2.) اس کی اپنی اطلاق کرتا ہے * *`PartialEq` کا ورژن (جو ہم فرض کرتے ہیں کہ ساختی مساوات کے موازنہ کے مطابق نہیں ہے)۔
///
///
/// مذکورہ بالا دونوں میں سے کسی ایک صورت میں ، ہم پیٹرن میچ میں اس طرح کے مستقل استعمال کو مسترد کرتے ہیں۔
///
/// [structural match RFC][RFC1445] ، اور [issue 63438] بھی دیکھیں جس نے وصف پر مبنی ڈیزائن سے اس trait میں منتقل ہونے کی تحریک کی۔
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// پیٹرن میچوں میں مستقل طور پر استعمال ہونے والے trait کی ضرورت ہے۔
///
/// کسی بھی قسم کی جو X01 کو حاصل کرتی ہے وہ اس trait کو خود بخود لاگو کرتی ہے ، * قطع نظر اس کے کہ اس کے پیرامیٹرز `Eq` کو لاگو کرتے ہیں۔
///
/// ہمارے ٹائپ سسٹم میں حدود کے گرد کام کرنے کیلئے یہ ایک ہیک ہے۔
///
/// # Background
///
/// ہم اس کی ضرورت کرنا چاہتے ہیں کہ پیٹرن میچوں میں استعمال ہونے والی اقسام کی خصوصیات میں `#[derive(PartialEq, Eq)]` کی صفت ہونی چاہئے۔
///
/// زیادہ مثالی دنیا میں ، ہم اس کی ضرورت کو صرف یہ دیکھ کر جانچ سکتے ہیں کہ دی گئی قسم `StructuralPartialEq` trait *اور*`Eq` trait دونوں پر عمل درآمد کرتی ہے۔
/// تاہم ، آپ کے پاس ADTs ہوسکتے ہیں جو *X* 1X کرتے ہیں ، اور ایسا معاملہ ہو جس کو ہم مرتب کرنے والے کو قبول کرنا چاہتے ہیں ، اور اس کے باوجود مستقل کی قسم `Eq` کو لاگو کرنے میں ناکام ہوجاتی ہے۔
///
/// یعنی ، اس طرح کا ایک کیس:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (مذکورہ کوڈ میں مسئلہ یہ ہے کہ `Wrap<fn(&())>` `PartialEq` پر عمل نہیں کرتا ہے ، اور نہ ہی `Eq` ، کیونکہ `<'a> fn(&'a _)` does not implement those traits.)
///
/// لہذا ، ہم `StructuralPartialEq` اور محض `Eq` کیلئے بولی چیک پر انحصار نہیں کرسکتے ہیں۔
///
/// اس کے آس پاس کام کرنے کے ل، ، ہم دو الگ الگ (`#[derive(PartialEq)]` اور `#[derive(Eq)]`) کے ذریعہ انجکشن لگانے والے دو الگ الگ traits استعمال کرتے ہیں اور چیک کرتے ہیں کہ یہ دونوں ساختی میچ کی جانچ کے حصے کے طور پر موجود ہیں۔
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ان اقسام کی جن کی اقدار کو بٹس کاپی کرکے آسانی سے نقل کیا جاسکتا ہے۔
///
/// بطور ڈیفالٹ ، متغیر پابندیوں میں 'موومنٹ سینڈینکس' ہوتا ہے۔دوسرے الفاظ میں:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` میں چلا گیا ہے ، اور اسی طرح استعمال نہیں کیا جاسکتا ہے
///
/// // println! ("{: ؟}"، x)؛//خرابی: منتقل شدہ قیمت کا استعمال
/// ```
///
/// تاہم ، اگر ایک قسم `Copy` لاگو کرتی ہے تو ، اس کی بجائے اس میں 'کاپی سیمنٹکس' ہوتا ہے:
///
/// ```
/// // ہم `Copy` پر عمل درآمد کر سکتے ہیں۔
/// // `Clone` یہ بھی ضروری ہے ، کیوں کہ یہ `Copy` کا ایک سپر اسٹریٹ ہے۔
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` کی ایک کاپی ہے
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// یہ نوٹ کرنا ضروری ہے کہ ان دو مثالوں میں ، فرق صرف اتنا ہے کہ آپ کو اسائنمنٹ کے بعد `x` تک رسائی حاصل کرنے کی اجازت ہے یا نہیں۔
/// ڈاکو کے تحت ، نقل اور اقدام دونوں ہی بٹس کو میموری میں کاپی کرنے کا نتیجہ بن سکتے ہیں ، حالانکہ یہ بعض اوقات بہتر ہوجاتا ہے۔
///
/// ## میں `Copy` کو کس طرح نافذ کرسکتا ہوں؟
///
/// آپ کی قسم پر `Copy` لاگو کرنے کے دو طریقے ہیں۔`derive` استعمال کرنا آسان ہے۔
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// آپ دستی طور پر `Copy` اور `Clone` بھی نافذ کرسکتے ہیں۔
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// دونوں کے مابین ایک چھوٹا سا فرق ہے: `derive` حکمت عملی XP1X کو بھی قسم کے پیرامیٹرز پر پابند کرے گی ، جو ہمیشہ مطلوبہ نہیں ہوتا ہے۔
///
/// ## `Copy` اور `Clone` میں کیا فرق ہے؟
///
/// کاپیاں واضح طور پر ہوتی ہیں ، مثال کے طور پر اسائنمنٹ `y = x` کے ایک حصے کے طور پر۔`Copy` کا برتاؤ حد سے زیادہ قابل نہیں ہے۔یہ ہمیشہ ایک سادہ سا وار وار کاپی ہے۔
///
/// کلوننگ ایک واضح کارروائی ، `x.clone()` ہے۔[`Clone`] کا نفاذ اقدار کو محفوظ طریقے سے نقل کرنے کے لئے ضروری ہر قسم کے مخصوص سلوک فراہم کرسکتا ہے۔
/// مثال کے طور پر ،[`Clone`] کے لئے [`Clone`] کے نفاذ کے لئے ڈھیر میں نوکیلے ٹو اسٹرنگ بفر کو کاپی کرنے کی ضرورت ہے۔
/// [`String`] اقدار کی ایک سیدھی سی کاپی محض پوائنٹر کی کاپی کرے گی ، جس کی وجہ سے لائن نیچے ڈبل فری ہوجائے گی۔
/// اس وجہ سے ، [`String`] [`Clone`] ہے لیکن `Copy` نہیں ہے۔
///
/// [`Clone`] `Copy` کا ایک سپر اسٹریٹ ہے ، لہذا ہر وہ چیز جو `Copy` ہے اسے بھی [`Clone`] لاگو کرنا چاہئے۔
/// اگر ایک قسم `Copy` ہے تو پھر اس کے [`Clone`] نفاذ میں صرف `*self` واپس کرنا ہوگا (اوپر کی مثال ملاحظہ کریں)۔
///
/// ## جب میری قسم `Copy` ہوسکتی ہے؟
///
/// ایک قسم `Copy` پر عمل درآمد کر سکتی ہے اگر اس کے تمام اجزاء `Copy` پر عمل درآمد کرتے ہیں۔مثال کے طور پر ، یہ ڈھانچہ `Copy` ہوسکتا ہے:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ایک ڈھانچہ `Copy` ہوسکتا ہے ، اور [`i32`] `Copy` ہے ، لہذا `Point` `Copy` ہونے کا اہل ہے۔
/// اس کے برعکس ، غور کریں
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// سٹرک `PointList` `Copy` پر عمل درآمد نہیں کرسکتا ، کیونکہ [`Vec<T>`] `Copy` نہیں ہے۔اگر ہم `Copy` پر عمل درآمد کرنے کی کوشش کرتے ہیں تو ہمیں ایک غلطی ہوگی۔
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// مشترکہ حوالے (`&T`) بھی `Copy` ہیں ، لہذا ایک قسم `Copy` بھی ہوسکتی ہے ، یہاں تک کہ جب اس میں `T` اقسام کے مشترکہ حوالہ جات موجود ہوں جو *نہیں*`Copy` ہیں۔
/// مندرجہ ذیل ڈھانچے پر غور کریں ، جو `Copy` پر عمل درآمد کرسکتا ہے ، کیونکہ اس میں صرف ایک غیر مشترکہ حوالہ * ہمارے غیر above کاپی قسم `PointList` کے پاس ہے۔
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## جب * میری قسم `Copy` نہیں ہوسکتی ہے؟
///
/// کچھ اقسام کو محفوظ طریقے سے کاپی نہیں کیا جاسکتا۔مثال کے طور پر ، `&mut T` کی کاپی کرنے سے علasedیز شدہ بدلاؤ والا حوالہ پیدا ہوگا۔
/// [`String`] کی کاپی کرنے سے [`سٹرنگ] کے بفر کو سنبھالنے کی ذمہ داری کی نقل تیار ہوجائے گی ، جس کی وجہ ڈبل فری ہوگی۔
///
/// مؤخر الذکر کیس کو عام بناتے ہوئے ، [`Drop`] پر عمل درآمد کرنے والی کسی بھی قسم کی `Copy` نہیں ہوسکتی ہے ، کیونکہ یہ اپنے [`size_of::<T>`] بائٹس کے علاوہ کچھ وسائل کا بھی انتظام کررہی ہے۔
///
/// اگر آپ اسٹرک یا این پی سی پر مشتمل ڈیٹا پر مشتمل اینوم پر `Copy` لاگو کرنے کی کوشش کرتے ہیں تو ، آپ کو غلطی [E0204] مل جائے گی۔
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## جب * میری قسم `Copy` ہونی چاہئے؟
///
/// عام طور پر ، اگر آپ کی قسم _can_ `Copy` پر عمل درآمد کرتی ہے تو ، اسے ہونا چاہئے۔
/// اگرچہ ، یہ بات ذہن میں رکھیں کہ `Copy` کو لاگو کرنا آپ کی قسم کے عوامی API کا حصہ ہے۔
/// اگر قسم future میں غیر op کاپی` بن سکتی ہے تو ، XIX کا نفاذ چھوڑنا بہتر ہوگا ، تاکہ API میں تبدیلی نہ آئیں۔
///
/// ## اضافی عمل درآمد کرنے والے
///
/// [implementors listed below][impls] کے علاوہ ، درج ذیل اقسام بھی `Copy` کو نافذ کرتی ہیں۔
///
/// * فنکشن آئٹم کی اقسام (یعنی ، ہر فنکشن کے لئے الگ الگ قسم کی وضاحت)
/// * فنکشن پوائنٹر کی اقسام (جیسے ، `fn() -> i32`)
/// * اشارے کی اقسام ، ہر سائز کے ل if ، اگر آئٹم کی قسم `Copy` کو بھی نافذ کرتی ہے (جیسے ، `[i32; 123456]`)
/// * مختلف اقسام ، اگر ہر جز `Copy` (جیسے ، `()` ، `(i32, bool)`) بھی نافذ کرتا ہے
/// * بندش کی اقسام ، اگر وہ ماحول سے کوئی قیمت حاصل نہیں کرتے ہیں یا اگر اس طرح کی تمام اقدار خود `Copy` پر عمل درآمد کرتی ہیں۔
///   نوٹ کریں کہ مشترکہ حوالہ کے ذریعہ پکڑے جانے والے متغیرات ہمیشہ `Copy` پر عمل درآمد کرتے ہیں (چاہے وہ مختلف نہ ہوں) ، جبکہ متغیر حوالہ سے حاصل کردہ متغیرات کبھی بھی `Copy` پر عمل درآمد نہیں کرتے ہیں۔
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) یہ ایسی قسم کی کاپی کرنے کی اجازت دیتا ہے جو `Copy` پر عمل درآمد نہ ہونے کی وجہ سے زندگی کے عدم اطمینان کی حد (`A<'_>` کی کاپی کرتا ہے جب صرف `A<'static>: Copy` اور `A<'_>: Clone` ہوتا ہے)۔
// ہمارے پاس ابھی یہ وصف صرف اس لئے موجود ہے کیونکہ معیاری لائبریری میں `Copy` پر پہلے سے موجود کچھ خاص تخصیصات موجود ہیں ، اور ابھی اس طرز عمل کو محفوظ طریقے سے رکھنے کا کوئی راستہ نہیں ہے۔
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// وہ اقسام جن کے لئے تھریڈز کے مابین حوالہ جات بانٹنا محفوظ ہے۔
///
/// یہ trait خود کار طریقے سے لاگو ہوتا ہے جب کمپلر طے کرتا ہے کہ یہ مناسب ہے۔
///
/// قطعی تعریف یہ ہے کہ: ایک قسم `T` [`Sync`] ہے اگر اور صرف اس صورت میں اگر `&T` [`Send`] ہے۔
/// دوسرے الفاظ میں ، اگر دھاگوں کے درمیان `&T` حوالوں کو پاس کرتے وقت [undefined behavior][ub] (ڈیٹا ریس سمیت) کا کوئی امکان نہیں ہے۔
///
/// جیسا کہ کسی کی توقع ہوگی ، قدیم قسمیں جیسے [`u8`] اور [`f64`] تمام [`Sync`] ہیں ، اور اسی طرح کی مجموعی اقسام ہیں جن میں ان پر مشتمل ہے ، جیسے ٹیپلس ، تار اور اینومس۔
/// بنیادی [`Sync`] اقسام کی مزید مثالوں میں "immutable" اقسام جیسے `&T` ، اور ان میں سادہ وراثت میں بدلاؤ شامل ہے جیسے [`Box<T>`][box] ، [`Vec<T>`][vec] اور زیادہ تر دیگر اقسام کی اقسام شامل ہیں۔
///
/// (جنریٹر پیرامیٹرز کو ان کے کنٹینر [`Sync`] ہونے کے ل X [`Sync`] ہونے کی ضرورت ہے۔)
///
/// اس تعریف کا کسی حد تک حیرت انگیز نتیجہ یہ ہے کہ `&mut T` `Sync` ہے (اگر `T` `Sync` ہے) حالانکہ ایسا لگتا ہے کہ اس سے غیر مطابقت پذیر ميوشن مل سکتا ہے۔
/// چال یہ ہے کہ مشترکہ حوالہ کے پیچھے ایک متغیر حوالہ (یعنی `& &mut T`) صرف پڑھنے کے قابل ہوجاتا ہے ، گویا یہ `& &T` ہے۔
/// لہذا ڈیٹا ریس کا کوئی خطرہ نہیں ہے۔
///
/// اقسام جو `Sync` نہیں ہیں وہ ہیں جو "interior mutability" کو غیر تھریڈ سیف شکل میں رکھتے ہیں ، جیسے [`Cell`][cell] اور [`RefCell`][refcell]۔
/// یہ اقسام غیر منقولہ ، مشترکہ حوالہ کے ذریعہ بھی ان کے مندرجات میں تبدیلی کی اجازت دیتی ہیں۔
/// مثال کے طور پر [`Cell<T>`][cell] پر `set` کا طریقہ `&self` لیتا ہے ، لہذا اس میں صرف مشترکہ حوالہ کی ضرورت ہوتی ہے [`&Cell<T>`][cell]۔
/// طریقہ کوئی مطابقت پذیری نہیں کرتا ہے ، اس طرح [`Cell`][cell] `Sync` نہیں ہوسکتا ہے۔
///
/// غیر ySync` قسم کی ایک اور مثال حوالہ گنتی پوائنٹر [`Rc`][rc] ہے۔
/// کسی بھی حوالہ [`&Rc<T>`][rc] کو دیکھتے ہوئے ، آپ کسی نئے [`Rc<T>`][rc] کو کلون کرسکتے ہیں ، غیر جوہری طریقے سے حوالہ شمار میں ترمیم کرسکتے ہیں۔
///
/// ایسے معاملات میں جب کسی کو دھاگے سے محفوظ داخلہ تغیر پزیرت کی ضرورت ہو ، Rust [atomic data types] فراہم کرتا ہے ، نیز [`sync::Mutex`][mutex] اور [`sync::RwLock`][rwlock] کے ذریعے واضح تالا لگا دیتا ہے۔
/// ان اقسام کو یقینی بناتا ہے کہ کسی بھی تغیر کی وجہ سے اعداد و شمار کی دوڑ نہیں ہوسکتی ہے ، لہذا یہ اقسام `Sync` کی ہیں۔
/// اسی طرح ، [`sync::Arc`][arc] [`Rc`][rc] کا تھریڈ سیف ینالاگ فراہم کرتا ہے۔
///
/// داخلی تغیر پذیر ہونے والی کسی بھی قسم میں [`cell::UnsafeCell`][unsafecell] X کے ارد گرد [`cell::UnsafeCell`][unsafecell] ریپر کا بھی استعمال کرنا چاہئے جسے مشترکہ حوالہ کے ذریعہ تبدیل کیا جاسکتا ہے۔
/// ایسا کرنے میں ناکامی [undefined behavior][ub] ہے۔
/// مثال کے طور پر ، [`transmute`][transmute]-ing `&T` سے `&mut T` تک غلط ہے۔
///
/// `Sync` کے بارے میں مزید تفصیلات کے لئے [the Nomicon][nomicon-send-and-sync] دیکھیں۔
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ایک بار بیٹا میں `rustc_on_unimplemented` زمینوں میں نوٹ شامل کرنے کی حمایت کریں ، اور یہ توسیع کرنے کے لئے توسیع کردی گئی ہے کہ آیا ضرورت کے سلسلے میں کوئی بندش موجود ہے یا نہیں ، اس طرح کی (#48534) کی توسیع کریں:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// زیرو سائز کی قسم ان چیزوں کو نشان زد کرنے کے لئے استعمال کی جاتی ہے جن کے پاس وہ "act like" کے پاس ایک `T` ہے۔
///
/// آپ کی قسم میں ایک `T` فیلڈ کا اضافہ کرنا اس مرتب کرنے والے کو بتاتا ہے کہ آپ کی قسم ایسا کام کرتی ہے گویا یہ `T` کی قسم کی قیمت رکھتا ہے ، حالانکہ یہ واقعی میں نہیں ہے۔
/// یہ معلومات کچھ حفاظتی خصوصیات کی گنتی کے وقت استعمال کی جاتی ہیں۔
///
/// `PhantomData<T>` استعمال کرنے کے طریقے کی مزید گہرائی سے وضاحت کے لئے ، براہ کرم [the Nomicon](../../nomicon/phantom-data.html) دیکھیں۔
///
/// # ایک لرزہ خیز نوٹ 👻👻👻
///
/// اگرچہ ان دونوں کے خوفناک نام ہیں ، `PhantomData` اور 'پریت کی اقسام' کا تعلق ہے ، لیکن ایک جیسی نہیں۔فینٹم ٹائپ پیرامیٹر محض ایک قسم کا پیرامیٹر ہوتا ہے جو کبھی استعمال نہیں ہوتا ہے۔
/// Rust میں ، یہ اکثر مرتب کرنے والے کو شکایت کرنے کا سبب بنتا ہے ، اور حل یہ ہے کہ `PhantomData` کے ذریعہ "dummy" استعمال شامل کریں۔
///
/// # Examples
///
/// ## استعمال شدہ زندگی بھر کے پیرامیٹرز
///
/// شاید `PhantomData` کے لئے عام استعمال کا معاملہ ایک ایسا ڈھانچہ ہے جس میں غیر استعمال شدہ زندگی بھر کا پیرامیٹر ہوتا ہے ، عام طور پر کچھ غیر محفوظ کوڈ کے حصے کے طور پر۔
/// مثال کے طور پر ، یہاں ایک ڈھانچہ `Slice` ہے جس میں X پوائنٹس کی طرح کے دو پوائنٹر ہیں ، شاید کہیں اور کسی صف میں اشارہ کریں:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// نیت یہ ہے کہ بنیادی اعداد و شمار صرف زندگی بھر `'a` کے لئے موزوں ہے ، لہذا `Slice` کو `'a` کو آؤٹ لک نہیں کرنا چاہئے۔
/// تاہم ، ضابطے میں اس ارادے کا اظہار نہیں کیا گیا ہے ، کیوں کہ زندگی بھر `'a` کے کوئی استعمال نہیں ہیں اور اس وجہ سے یہ واضح نہیں ہے کہ یہ کس ڈیٹا پر لاگو ہوتا ہے۔
/// ہم اس کو مرتب کرنے والے کو *کام کرنے کے لئے کہہ کے اسے درست کرسکتے ہیں گویا*`Slice` ڈھانچے میں ایک حوالہ `&'a T` موجود ہے:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// اس کے بدلے میں بھی تشریح `T: 'a` کی ضرورت ہوتی ہے ، اس سے یہ ظاہر ہوتا ہے کہ `T` میں کوئی بھی حوالہ عمر `'a` کے دوران درست ہے۔
///
/// جب `Slice` کا آغاز کرتے ہو تو آپ فیلڈ `phantom` کیلئے `PhantomData` ویلیو کو آسانی سے فراہم کرتے ہیں۔
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## غیر استعمال شدہ قسم کے پیرامیٹرز
///
/// یہ کبھی کبھی ایسا ہوتا ہے کہ آپ کے پاس غیر استعمال شدہ قسم کے پیرامیٹرز موجود ہیں جو اس بات کی نشاندہی کرتے ہیں کہ ایک ڈھانچے میں کس قسم کا ڈیٹا "tied" ہے ، حالانکہ یہ ڈٹا حقیقت میں ڈھانچے میں ہی نہیں پایا جاتا ہے۔
/// یہاں ایک مثال ہے جہاں یہ [FFI] کے ساتھ پیدا ہوتا ہے۔
/// غیر ملکی انٹرفیس مختلف قسم کی Rust قدروں کا حوالہ دینے کے لئے `*mut ()` قسم کے ہینڈل استعمال کرتا ہے۔
/// ہم ڈھانچے `ExternalResource` پر پریت ٹائپ پیرامیٹر کا استعمال کرتے ہوئے Rust ٹائپ کو ٹریک کرتے ہیں جو ایک ہینڈل کو سمیٹتا ہے۔
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ملکیت اور ڈراپ چیک
///
/// قسم `PhantomData<T>` کا ایک فیلڈ شامل کرنا اس بات کی نشاندہی کرتا ہے کہ آپ کی قسم `T` قسم کے ڈیٹا کا مالک ہے۔اس کے نتیجے میں یہ ظاہر ہوتا ہے کہ جب آپ کی قسم کو گرایا جاتا ہے تو ، اس سے `T` قسم کی ایک یا زیادہ مثالیں گر سکتی ہیں۔
/// اس کا اثر Rust کمپائلر کے [drop check] تجزیہ پر پڑتا ہے۔
///
/// اگر آپ کے ڈھانچے میں حقیقت میں `T` قسم کا ڈیٹا *نہیں* ہے تو ، بہتر ہے کہ کسی حوالہ کی قسم کا استعمال کریں ، جیسے `PhantomData<&'a T>` (ideally) یا `PhantomData<*const T>` (اگر زندگی بھر کا اطلاق نہیں ہوتا ہے) ، تاکہ ملکیت کی نشاندہی نہ کی جاسکے۔
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// کمپلر اندرونی trait انوم امتیازی سلوک کی قسم کی نشاندہی کرنے کے لئے استعمال کیا جاتا ہے۔
///
/// یہ trait خود بخود ہر قسم کے لئے لاگو ہوتا ہے اور [`mem::Discriminant`] میں کوئی ضمانت نہیں دیتا ہے۔
/// `DiscriminantKind::Discriminant` اور `mem::Discriminant` کے درمیان منتقل کرنا **غیر وضاحتی سلوک** ہے۔
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// امتیازی سلوک کرنے والے کی قسم ، جس میں `mem::Discriminant` کے ذریعہ مطلوبہ trait bound کو پورا کرنا چاہئے۔
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// مرتب اندرونی trait اس بات کا تعین کرنے کے لئے استعمال کیا جاتا ہے کہ آیا کسی قسم میں کوئی `UnsafeCell` اندرونی طور پر موجود ہے ، لیکن کسی سمت کے ذریعے نہیں۔
///
/// اس سے متاثر ہوتا ہے ، مثال کے طور پر ، چاہے اس قسم کا `static` صرف پڑھنے کے لئے جامد میموری میں یا قابل تحریر جامد میموری میں رکھا جائے۔
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// اقسام جو پن سے محفوظ رہنے کے بعد منتقل ہوسکتی ہیں۔
///
/// Rust میں خود غیر منقولہ اقسام کا کوئی تصور نہیں ہے ، اور ہمیشہ محفوظ رہنے کے ل moves حرکتوں (جیسے تفویض یا [`mem::replace`] کے ذریعے) پر غور کرتا ہے۔
///
/// ٹائپ سسٹم کے ذریعے چلنے سے بچنے کے ل The [`Pin`][Pin] ٹائپ استعمال کی جاتی ہے۔[`Pin<P<T>>`][Pin] ریپر میں لپیٹے ہوئے پوائنٹرز `P<T>` کو باہر سے منتقل نہیں کیا جاسکتا ہے۔
/// پن سے متعلق مزید معلومات کے ل X [`pin` module] دستاویزات دیکھیں۔
///
/// `T` کے لئے `Unpin` trait پر عمل درآمد سے قسم کو ختم کرنے کی پابندیاں ختم ہوجاتی ہیں ، جس کے بعد [`mem::replace`] کو X004 جیسے [`mem::replace`] جیسے افعال کے ساتھ منتقل کرنے کی اجازت ملتی ہے۔
///
///
/// `Unpin` غیر پن شدہ ڈیٹا کا کوئی نتیجہ نہیں ہے۔
/// خاص طور پر ، [`mem::replace`] خوشی سے `!Unpin` ڈیٹا کو منتقل کرتا ہے (یہ کسی بھی `&mut T` کے ل works کام کرتا ہے ، صرف اس وقت نہیں جب `T: Unpin`)۔
/// تاہم ، آپ [`Pin<P<T>>`][Pin] کے اندر لپٹے ڈیٹا پر [`mem::replace`] استعمال نہیں کرسکتے ہیں کیونکہ آپ کو اس کے لئے درکار `&mut T` نہیں مل سکتا ہے ، اور * وہ ہے جس سے یہ نظام کام کرتا ہے۔
///
/// لہذا ، مثال کے طور پر ، صرف `Unpin` پر عمل درآمد کرنے والی اقسام پر ہی کیا جاسکتا ہے:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // ہمیں `mem::replace` پر کال کرنے کے لئے ایک تغیر پزیر حوالہ درکار ہے۔
/// // ہم اس طرح کا حوالہ (implicitly) کے ذریعہ `Pin::deref_mut` کی طرف سے حاصل کرسکتے ہیں ، لیکن یہ صرف اسی لئے ممکن ہے کیونکہ `String` `Unpin` کو نافذ کرتا ہے۔
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// یہ trait خود بخود تقریبا ہر قسم کے لئے لاگو ہوتا ہے۔
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// ایک مارکر کی قسم جو `Unpin` پر عمل درآمد نہیں کرتی ہے۔
///
/// اگر کسی قسم میں ایک `PhantomPinned` ہے ، تو یہ `Unpin` کو بطور ڈیفالٹ نافذ نہیں کرے گی۔
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// آدم اقسام کے لئے `Copy` کا نفاذ۔
///
/// Rust میں بیان نہیں کی جاسکتی ہیں کہ `rustc_trait_selection` میں `traits::SelectionContext::copy_clone_conditions()` میں لاگو کیا جاتا ہے۔
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// مشترکہ حوالوں کو کاپی کیا جاسکتا ہے ، لیکن تغیر پزیر حوالہ جات *نہیں* کر سکتے ہیں!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}