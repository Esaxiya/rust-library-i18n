#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// ایک `RawWaker` ٹاسک ایگزیکٹر کے نفاذ کنندہ کو [`Waker`] بنانے کی اجازت دیتا ہے جو اپنی مرضی کے مطابق ویک اپ رویہ فراہم کرتا ہے۔
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// اس میں ڈیٹا پوائنٹر اور [virtual function pointer table (vtable)][vtable] ہوتا ہے جو `RawWaker` کے طرز عمل کو اپنی مرضی کے مطابق بناتا ہے۔
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// اعداد و شمار کا اشارہ ، جو استعمال کنندہ کے ذریعہ مطلوبہ صوابدیدی ڈیٹا کو اسٹور کرنے کے لئے استعمال کیا جاسکتا ہے۔
    /// یہ مثال کے طور پر ہو سکتا ہے
    /// ایک `Arc` کی طرف سے ٹائپ مٹ پوائٹر جو کام سے وابستہ ہے۔
    /// اس فیلڈ کی قدر ان تمام افعال تک پہنچ جاتی ہے جو پہلے پیرامیٹر کے طور پر ویٹیبل کا حصہ ہیں۔
    ///
    data: *const (),
    /// ورچوئل فنکشن پوائنٹ پوائنٹر ٹیبل جو اس واکر کے رویے کو کسٹمائز کرتی ہے۔
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// فراہم کردہ `data` پوائنٹر اور `vtable` سے نیا `RawWaker` بناتا ہے۔
    ///
    /// `data` پوائنٹر کو صوابدیدی اعداد و شمار کو ذخیرہ کرنے کے لئے استعمال کیا جاسکتا ہے جیسا کہ ایگزیکٹر کی ضرورت ہے۔یہ مثال کے طور پر ہو سکتا ہے
    /// ایک `Arc` کی طرف سے ٹائپ مٹ پوائٹر جو کام سے وابستہ ہے۔
    /// اس پوائنٹر کی قدر ان تمام افعال تک پہنچ جائے گی جو پہلے پیرامیٹر کے طور پر `vtable` کا حصہ ہیں۔
    ///
    /// `vtable` `Waker` کے طرز عمل کو کسٹمائز کرتا ہے جو `RawWaker` سے تخلیق ہوتا ہے۔
    /// `Waker` پر ہر ایک عمل کیلئے ، بنیادی `RawWaker` کے `vtable` میں وابستہ فنکشن طلب کیا جائے گا۔
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// ایک ورچوئل فنکشن پوائنٹ پوائنٹر ٹیبل (vtable) جو [`RawWaker`] کے طرز عمل کی وضاحت کرتا ہے۔
///
/// ویٹیبل کے اندر تمام افعال تک پہنچنے والا پوائنٹر ، [`RawWaker`] آبجیکٹ سے منسلک `data` پوائنٹر ہے۔
///
/// اس ڈھانچے کے اندر موجود افعال کا مقصد صرف [`RawWaker`] نفاذ کے اندر سے مناسب طریقے سے تعمیر شدہ [`RawWaker`] آبجیکٹ کے `data` پوائنٹر پر کال کرنا ہے۔
/// کسی بھی دوسرے `data` پوائنٹر کا استعمال کرتے ہوئے موجود افعال میں سے ایک کو کال کرنا غیر وضاحتی رویے کا سبب بنے گا۔
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// جب [`RawWaker`] کلون ہوجائے گا ، تو یہ فنکشن کہا جائے گا ، جیسے جب [`Waker`] جس میں [`RawWaker`] اسٹور کیا گیا ہے کلون ہوجائے۔
    ///
    /// اس فنکشن کے نفاذ کے ل resources تمام وسائل کو برقرار رکھنا ہوگا جو [`RawWaker`] اور اس سے وابستہ ٹاسک کی اس اضافی مثال کے لئے درکار ہیں۔
    /// `wake` کو نتیجے میں ہونے والے [`RawWaker`] پر کال کرنے کے نتیجے میں وہی کام شروع ہونا چاہئے جو اصل [`RawWaker`] کے ذریعہ جاگ گیا ہو۔
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// جب `wake` کو [`Waker`] پر بلایا جائے تو یہ فنکشن کہا جائے گا۔
    /// اسے اس [`RawWaker`] سے وابستہ کام کو بیدار کرنا چاہئے۔
    ///
    /// اس فنکشن کے نفاذ کے ل any کسی ایسے وسائل کی رہائی یقینی بنانی ہوگی جو [`RawWaker`] اور اس سے وابستہ ٹاسک کے اس واقعہ سے وابستہ ہوں۔
    ///
    ///
    wake: unsafe fn(*const ()),

    /// جب `wake_by_ref` کو [`Waker`] پر بلایا جائے تو یہ فنکشن کہا جائے گا۔
    /// اسے اس [`RawWaker`] سے وابستہ کام کو بیدار کرنا چاہئے۔
    ///
    /// یہ فنکشن `wake` کی طرح ہے ، لیکن فراہم کردہ ڈیٹا پوائنٹر کو استعمال نہیں کرنا چاہئے۔
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// جب [`RawWaker`] ڈراپ ہوجائے تو یہ فنکشن کہا جاتا ہے۔
    ///
    /// اس فنکشن کے نفاذ کے ل any کسی ایسے وسائل کی رہائی یقینی بنانی ہوگی جو [`RawWaker`] اور اس سے وابستہ ٹاسک کے اس واقعہ سے وابستہ ہوں۔
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// فراہم کردہ `clone` ، `wake` ، `wake_by_ref` ، اور `drop` افعال سے ایک نیا `RawWakerVTable` تخلیق کرتا ہے۔
    ///
    /// # `clone`
    ///
    /// جب [`RawWaker`] کلون ہوجائے گا ، تو یہ فنکشن کہا جائے گا ، جیسے جب [`Waker`] جس میں [`RawWaker`] اسٹور کیا گیا ہے کلون ہوجائے۔
    ///
    /// اس فنکشن کے نفاذ کے ل resources تمام وسائل کو برقرار رکھنا ہوگا جو [`RawWaker`] اور اس سے وابستہ ٹاسک کی اس اضافی مثال کے لئے درکار ہیں۔
    /// `wake` کو نتیجے میں ہونے والے [`RawWaker`] پر کال کرنے کے نتیجے میں وہی کام شروع ہونا چاہئے جو اصل [`RawWaker`] کے ذریعہ جاگ گیا ہو۔
    ///
    /// # `wake`
    ///
    /// جب `wake` کو [`Waker`] پر بلایا جائے تو یہ فنکشن کہا جائے گا۔
    /// اسے اس [`RawWaker`] سے وابستہ کام کو بیدار کرنا چاہئے۔
    ///
    /// اس فنکشن کے نفاذ کے ل any کسی ایسے وسائل کی رہائی یقینی بنانی ہوگی جو [`RawWaker`] اور اس سے وابستہ ٹاسک کے اس واقعہ سے وابستہ ہوں۔
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// جب `wake_by_ref` کو [`Waker`] پر بلایا جائے تو یہ فنکشن کہا جائے گا۔
    /// اسے اس [`RawWaker`] سے وابستہ کام کو بیدار کرنا چاہئے۔
    ///
    /// یہ فنکشن `wake` کی طرح ہے ، لیکن فراہم کردہ ڈیٹا پوائنٹر کو استعمال نہیں کرنا چاہئے۔
    ///
    /// # `drop`
    ///
    /// جب [`RawWaker`] ڈراپ ہوجائے تو یہ فنکشن کہا جاتا ہے۔
    ///
    /// اس فنکشن کے نفاذ کے ل any کسی ایسے وسائل کی رہائی یقینی بنانی ہوگی جو [`RawWaker`] اور اس سے وابستہ ٹاسک کے اس واقعہ سے وابستہ ہوں۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// ایک غیر سنجیدہ کام کا `Context`۔
///
/// فی الحال ، `Context` صرف `&Waker` تک رسائی فراہم کرتا ہے جسے موجودہ کام کو بیدار کرنے کے لئے استعمال کیا جاسکتا ہے۔
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // اس بات کو یقینی بنائیں کہ ہم زندگی بھر کو متغیر بننے پر تغیر بخش تبدیلیوں کے خلاف future-ثبوت (استدلال کی حیثیت سے زندگی بھر ناگوار گذار ہیں جبکہ واپسی کی زندگی کی زندگی کاوینئرٹ ہیں)۔
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` سے نیا `Context` بنائیں۔
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// موجودہ کام کیلئے `Waker` کا حوالہ لوٹاتا ہے۔
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// ایک `Waker` کام کو بیدار کرنے کے لئے ایک ہینڈل ہے جس میں اس کے ایگزیکٹر کو مطلع کیا جاتا ہے کہ وہ چلانے کے لئے تیار ہے۔
///
/// یہ ہینڈل ایک [`RawWaker`] مثال فراہم کرتا ہے ، جو ایگزیکٹر سے متعلق مخصوص ویک اپ رویہ کی وضاحت کرتا ہے۔
///
///
/// [`Clone`] ، [`Send`] ، اور [`Sync`] نافذ کرتا ہے۔
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// اس `Waker` سے وابستہ کام کو اٹھاو۔
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // اصل ویک اپ کال کو عملی شکل میں ورچوئل فنکشن کال کے ذریعے تفویض کیا جاتا ہے جس کی وضاحت ایگزیکٹر نے کی ہے۔
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` پر کال نہ کریں-ویکٹر `wake` استعمال کرے گا۔
        crate::mem::forget(self);

        // محفوظ کریں: یہ محفوظ ہے کیونکہ `Waker::from_raw` واحد راستہ ہے
        // `wake` اور `data` کو شروع کرنے کیلئے جس میں صارف کو یہ تسلیم کرنے کی ضرورت ہوتی ہے کہ `RawWaker` کا معاہدہ برقرار ہے۔
        //
        unsafe { (wake)(data) };
    }

    /// اس `Waker` سے وابستہ کام کو `Waker` استعمال کیے بغیر اٹھائیں۔
    ///
    /// یہ `wake` کی طرح ہے ، لیکن اس معاملے میں جہاں قدرے `Waker` دستیاب ہے اس میں قدرے کم موثر ہوسکتا ہے۔
    /// اس طریقہ کو `waker.clone().wake()` پر کال کرنے پر ترجیح دی جانی چاہئے۔
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // اصل ویک اپ کال کو عملی شکل میں ورچوئل فنکشن کال کے ذریعے تفویض کیا جاتا ہے جس کی وضاحت ایگزیکٹر نے کی ہے۔
        //

        // محفوظ کریں: دیکھیں `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// اگر یہ `Waker` اور دوسرا `Waker` ایک ہی کام سے کام لے گیا ہے تو ، `true` واپس کرتا ہے۔
    ///
    /// یہ فنکشن بہترین کوشش کی بنیاد پر کام کرتا ہے ، اور باطل کو بھی واپس آجاتا ہے جب ویکرز اسی کام کو بیدار کردیں گے۔
    /// تاہم ، اگر یہ فنکشن `true` کو لوٹاتا ہے تو ، اس بات کی ضمانت دی جاتی ہے کہ `واکر` اسی کام کو بیدار کردیں گے۔
    ///
    /// یہ فنکشن بنیادی طور پر اصلاح کے مقاصد کے لئے استعمال کیا جاتا ہے۔
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] سے ایک نیا `Waker` بناتا ہے۔
    ///
    /// اگر [`RawWaker`] کے اور [`RawWakerVTable`] کی دستاویزات میں معاہدہ کو برقرار نہیں رکھا گیا تو واپس شدہ `Waker` کے طرز عمل کی وضاحت نہیں کی جاسکتی ہے۔
    ///
    /// لہذا یہ طریقہ غیر محفوظ ہے۔
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // محفوظ کریں: یہ محفوظ ہے کیونکہ `Waker::from_raw` واحد راستہ ہے
            // `clone` اور `data` کو شروع کرنے کیلئے جس میں صارف کو یہ تسلیم کرنے کی ضرورت ہوتی ہے کہ [`RawWaker`] کا معاہدہ برقرار ہے۔
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // محفوظ کریں: یہ محفوظ ہے کیونکہ `Waker::from_raw` واحد راستہ ہے
        // `drop` اور `data` کو شروع کرنے کیلئے جس میں صارف کو یہ تسلیم کرنے کی ضرورت ہوتی ہے کہ `RawWaker` کا معاہدہ برقرار ہے۔
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}