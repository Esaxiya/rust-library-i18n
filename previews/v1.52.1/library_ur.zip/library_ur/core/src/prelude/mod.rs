//! libcore prelude
//!
//! یہ ماڈیول لیبکور کے صارفین کے لئے ہے جو لئبسٹڈی کے ساتھ بھی نہیں جڑتے ہیں۔
//! یہ ماڈیول ڈیفالٹ کے ذریعہ درآمد کیا جاتا ہے جب `#![no_std]` اسی طرح استعمال کیا جاتا ہے جیسے معیاری لائبریری کے prelude کی طرح ہے۔
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// کور prelude کا 2015 ورژن۔
///
/// مزید کے لئے [module-level documentation](self) دیکھیں۔
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// کور prelude کا 2018 ورژن۔
///
/// مزید کے لئے [module-level documentation](self) دیکھیں۔
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// کور prelude کا 2021 ورژن۔
///
/// مزید کے لئے [module-level documentation](self) دیکھیں۔
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: مزید چیزیں شامل کریں۔
}