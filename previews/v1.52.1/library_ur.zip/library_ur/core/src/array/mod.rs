//! ایک خاص لمبائی تک طے شدہ لمبائی کے اشاروں کیلئے `Eq` جیسی چیزوں کے نفاذ۔
//! آخر کار ، ہمیں ہر لمبائی کو عام کرنے کے قابل ہونا چاہئے۔
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` کے ایک حوالہ کو لمبائی 1 (کاپی کیے بغیر) کے ایک صف کے حوالہ میں بدل دیتا ہے۔
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // محفوظ: `&T` کو `&[T; 1]` میں تبدیل کرنا ٹھیک ہے۔
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` کے ایک تغیر پزیر حوالہ کو لمبائی 1 (کسی کاپی کے بغیر) کی ایک صف میں تبدیل کرنے کے قابل بنائیں۔
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // محفوظ: `&mut T` کو `&mut [T; 1]` میں تبدیل کرنا ٹھیک ہے۔
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// یوٹیلٹی trait صرف مقررہ سائز کی صفوں پر ہی نافذ ہے
///
/// اس trait کو زیادہ میٹا ڈیٹا پھولنے کا سبب بنائے بغیر دیگر traits کو طے شدہ سائز کی صفوں پر عمل کرنے کے لئے استعمال کیا جاسکتا ہے۔
///
/// عمل درآمد کرنے والوں کو طے شدہ سائز کی صفوں تک محدود رکھنے کے لئے trait پر غیر محفوظ نشان لگا دیا گیا ہے۔
/// اس trait کا صارف یہ فرض کرسکتا ہے کہ عمل درآمد کرنے والوں کے پاس ایک مقررہ سائز کی صف کی یاد میں بالکل صحیح ترتیب موجود ہے (مثال کے طور پر ، غیر محفوظ آغاز کے لئے)۔
///
///
/// نوٹ کریں کہ traits [`AsRef`] اور [`AsMut`] ایسی اقسام کے ل similar اسی طرح کے طریقے مہیا کرتے ہیں جو ممکنہ طور پر طے شدہ سائز کی صفوں میں نہ ہوں۔
/// نفاذ کرنے والوں کو ان کی بجائے ان traits کو ترجیح دینی چاہئے۔
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// سرنی کو ناقابل تبدیل ٹکڑوں میں بدل دیتا ہے
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// سرنی کو بدلنے والی سلائس میں بدل دیتا ہے
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// جب سلائس سے کسی سرنی میں تبادلہ ناکام ہوجاتا ہے تو غلطی کی قسم واپس آ جاتی ہے۔
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // محفوظ کریں: ٹھیک ہے کیونکہ ہم نے ابھی جانچ کیا ہے کہ لمبائی فٹ بیٹھتی ہے
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // محفوظ کریں: ٹھیک ہے کیونکہ ہم نے ابھی جانچ کیا ہے کہ لمبائی فٹ بیٹھتی ہے
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: کوڈ بلوٹ کو کم کرنے کے ل less کچھ کم اہم نقول کو چھوڑ دیا گیا ہے
// ___مپل_سلائز_ق 2!{ [A; $N], &'b [B; $N] }___ll_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// ارای [lexicographically](Ord#lexicographical-comparison) کا موازنہ نافذ کرتا ہے۔
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// ڈیفالٹ امپلسٹ مستحکم جنرک کے ساتھ نہیں کی جاسکتی ہے کیونکہ `[T; 0]` کو ڈیفالٹ کو لاگو کرنے کی ضرورت نہیں ہوتی ہے ، اور مختلف نمبروں کے ل different مختلف امپلس بلاکس رکھنے کی حمایت نہیں کی جاتی ہے۔
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// `self` جیسا ہی سائز کا ایک سرہ واپس کرتا ہے ، جس میں ہر ایک عنصر پر ترتیب کے مطابق `f` فنکشن لاگو ہوتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // محفوظ: ہم یقین کے ساتھ جانتے ہیں کہ اس تکرار کرنے والے کو بالکل `N` ملے گا
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// جوپس کی ایک صف میں دو صفیں 'زپ اپ' کریں۔
    ///
    /// `zip()` ایک نئی صف کو لوٹاتا ہے جہاں ہر عنصر ایک ٹیپل ہوتا ہے جہاں پہلا عنصر پہلی صف سے آتا ہے ، اور دوسرا عنصر دوسری صف سے آتا ہے۔
    ///
    /// دوسرے لفظوں میں ، یہ ایک دوسرے میں ایک ساتھ دو صفوں کو زپ کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // محفوظ: ہم یقین کے ساتھ جانتے ہیں کہ اس تکرار کرنے والے کو بالکل `N` ملے گا
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// پوری صف میں مشتمل ایک ٹکڑا واپس کرتا ہے۔`&s[..]` کے برابر ہے۔
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// ایک تبدیل شدہ سلائس کو واپس کرتا ہے جس میں پوری صف شامل ہوتی ہے۔
    /// `&mut s[..]` کے برابر ہے۔
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ہر عنصر کو ادھار لیتے ہیں اور `self` جیسا ہی سائز کے حوالوں کی ایک صف واپس کرتے ہیں۔
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// یہ طریقہ خاص طور پر مفید ہے اگر [`map`](#method.map) جیسے دیگر طریقوں کے ساتھ مل جائے۔
    /// اس طرح ، آپ اصل صف کو منتقل کرنے سے بچ سکتے ہیں اگر اس کے عناصر `Copy` نہیں ہیں۔
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // ہم اب بھی اصل صف تک رسائی حاصل کرسکتے ہیں: اسے منتقل نہیں کیا گیا ہے۔
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // محفوظ: ہم یقین کے ساتھ جانتے ہیں کہ اس تکرار کرنے والے کو بالکل `N` ملے گا
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// ہر عنصر کو باہمی طور پر قرضہ دیتا ہے اور اسی سائز کے ساتھ `self` کے ساتھ بدلنے والے حوالوں کی ایک صف واپس کرتا ہے۔
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // محفوظ: ہم یقین کے ساتھ جانتے ہیں کہ اس تکرار کرنے والے کو بالکل `N` ملے گا
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `N` آئٹموں کو `iter` سے کھینچ کر لے جاتا ہے اور انہیں ایک صف کے بطور لوٹاتا ہے۔
/// اگر تکرار کرنے والا `N` سے کم اشیاء حاصل کرتا ہے تو ، یہ فنکشن غیر وضاحتی رویے کی نمائش کرتا ہے۔
///
///
/// مزید معلومات کے لئے [`collect_into_array`] دیکھیں۔
///
/// # Safety
///
/// اس بات کی ضمانت دینے والے پر منحصر ہے کہ `iter` کم از کم `N` آئٹمز حاصل کرتا ہے۔
/// اس حالت کی خلاف ورزی غیر وضاحتی رویے کا سبب بنتی ہے۔
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` یہاں کچھ تجربہ ہے۔یہ صرف ایک ہے
    // اندرونی فعل ، لہذا اگر یہ پابند کوئی برا خیال نکلا تو اسے ہٹانے کے لئے آزاد محسوس کریں۔
    // اس صورت میں ، نیچے دیے جانے والے `debug_assert!` کو بھی دور کرنا یاد رکھیں!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // حفاظت: تقریب کے معاہدے کے ذریعے احاطہ کرتا ہے۔
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `N` آئٹمز کو `iter` سے کھینچ کر لے جاتا ہے اور انہیں ایک صف کے بطور لوٹاتا ہے۔اگر آئٹرٹر `N` آئٹمز سے کم پیداوار حاصل کرتا ہے تو ، `None` واپس کردیتا ہے اور پہلے ہی حاصل شدہ تمام اشیاء کو چھوڑ دیا جاتا ہے۔
///
/// چونکہ ایٹریٹر ایک متغیر حوالہ کے بطور منظور ہوا ہے اور یہ فنکشن `next` کو زیادہ سے زیادہ `N` اوقات پر کال کرتا ہے ، اس کے بعد بھی باقی اشیاء کو بازیافت کرنے کے ل ite اسٹرٹر کو پھر بھی استعمال کیا جاسکتا ہے۔
///
///
/// اگر `iter.next()` گھبراتا ہے تو ، آئٹرٹر کے ذریعہ پہلے ہی حاصل کردہ سبھی چیزیں گرا دی جاتی ہیں۔
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // سلامتی: خالی صف میں ہمیشہ آباد رہتا ہے اور اس میں کوئی صداقت نہیں ہے۔
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // محفوظ: اس خام ٹکڑے میں صرف ابتدائی اشیاء شامل ہوں گی۔
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // محفوظ: `guard.initialized` 0 سے شروع ہوتا ہے ، میں ایک میں اضافہ ہوتا ہے
        // ایک بار N (جو `array.len()`) ہے) تک پہنچنے کے بعد لوپ اور لوپ کو ختم کردیا جاتا ہے۔
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // چیک کریں کہ آیا پوری صف شروع کی گئی تھی۔
        if guard.initialized == N {
            mem::forget(guard);

            // حفاظت: اوپر کی گئی شرط پر زور دیا گیا ہے کہ تمام عناصر ہیں
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // یہ تب ہی پہنچا جاسکتا ہے جب `guard.initialized` `N` تک پہنچنے سے پہلے ہی اگر دوبارہ کرنے والا ختم ہوجائے۔
    //
    // یہ بھی نوٹ کریں کہ `guard` کو یہاں پہلے ہی تمام ابتدائی عنصروں کو گرا کر گرایا جاتا ہے۔
    None
}