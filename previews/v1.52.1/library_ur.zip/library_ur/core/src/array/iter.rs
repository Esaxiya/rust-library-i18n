//! ارایوں کے لئے `IntoIter` کے ملکیت والے ریڈیٹر کی وضاحت کرتا ہے۔

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// ایک بائی ویلیو [array] ریٹرٹر۔
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// یہ وہ صف ہے جس پر ہم دوبارہ چل رہے ہیں۔
    ///
    /// انڈیکس `i` والے عناصر جہاں ابھی `alive.start <= i < alive.end` برآمد نہیں ہوا ہے اور وہ درست سرے اندراجات ہیں۔
    /// انڈیکس `i < alive.start` یا `i >= alive.end` والے عناصر پہلے ہی حاصل ہوچکے ہیں اور اب ان تک رسائی حاصل نہیں ہونی چاہئے!ہوسکتا ہے کہ وہ مردہ عناصر مکمل طور پر بلا شبہ حالت میں ہوں!
    ///
    ///
    /// تو حملہ آور یہ ہیں:
    /// - `data[alive]` زندہ ہے (یعنی درست عنصر پر مشتمل ہے)
    /// - `data[..alive.start]` اور `data[alive.end..]` فوت ہوچکے ہیں (یعنی عنصر پہلے ہی پڑھ چکے تھے اور اب اسے چھونے کی ضرورت نہیں ہے!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` میں موجود عناصر جو ابھی تک برآمد نہیں ہوئے ہیں۔
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// دیئے گئے `array` پر نیا ریٹر تیار کرتا ہے۔
    ///
    /// *نوٹ*: [`IntoIterator` is implemented for arrays][array-into-iter] کے بعد ، اس طریقہ کو future میں فرسودہ کیا جاسکتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` کی قسم یہاں `&i32` کی بجائے `i32` ہے
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // محفوظ: یہاں ٹرانسمیٹ دراصل محفوظ ہے۔`MaybeUninit` کے دستاویزات
        // promise:
        //
        // > `MaybeUninit<T>` ایک ہی سائز اور سیدھ رکھنے کی ضمانت ہے
        // > بطور `T`
        //
        // یہاں تک کہ دستاویزات `MaybeUninit<T>` کے ایک سرے سے `T` کی ایک صف میں بھی ایک ٹرانسمیٹ دکھاتی ہیں۔
        //
        //
        // اس کے ساتھ ، یہ ابتداء حملہ آوروں کو مطمئن کرتی ہے۔

        // FIXME(LukasKalbertodt): اصل میں یہاں `mem::transmute` کا استعمال کریں ، ایک بار جب یہ عام جنرکس کے ساتھ کام کرتا ہے:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // تب تک ، ہم `mem::transmute_copy` کو بٹ سائڈ کاپی بنانے کے ل can مختلف قسم کی طرح استعمال کرسکتے ہیں ، پھر `array` کو بھول جائیں تاکہ اسے گرایا نہ جائے۔
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// ان تمام عناصر کا ایک ناقابل تلافی ٹکڑا واپس کرتا ہے جو ابھی تک برآمد نہیں ہوئے ہیں۔
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // محفوظ کریں: ہم جانتے ہیں کہ `alive` کے اندر موجود تمام عناصر کو صحیح طریقے سے شروع کیا گیا ہے۔
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// ان تمام عناصر کی ایک تبدیلی کا ٹکڑا واپس کرتا ہے جو ابھی تک برآمد نہیں ہوئے ہیں۔
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // محفوظ کریں: ہم جانتے ہیں کہ `alive` کے اندر موجود تمام عناصر کو صحیح طریقے سے شروع کیا گیا ہے۔
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // اگلی انڈیکس سامنے سے حاصل کریں۔
        //
        // `alive.start` کو 1 کے ذریعہ بڑھانا `alive` کے بارے میں جارحیت کو برقرار رکھتا ہے۔
        // تاہم ، اس تبدیلی کی وجہ سے ، تھوڑی دیر کے لئے ، زندہ زون اب `data[alive]` نہیں ، بلکہ `data[idx..alive.end]` ہے۔
        //
        self.alive.next().map(|idx| {
            // صف سے عنصر پڑھیں۔
            // محفوظ: `idx` کے سابق "alive" خطے میں ایک انڈیکس ہے
            // سرنی۔اس عنصر کو پڑھنے کا مطلب یہ ہے کہ `data[idx]` کو اب مردہ سمجھا جاتا ہے (یعنی چھوئے نہیں)۔
            // چونکہ `idx` زندہ زون کا آغاز تھا ، زندہ زون اب ایک بار پھر `data[alive]` ہے ، تمام حملہ آوروں کو بحال کررہا ہے۔
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // پیچھے سے اگلا انڈیکس حاصل کریں۔
        //
        // `alive.end` کو 1 سے کم کرنا `alive` کے بارے میں جارحیت کو برقرار رکھتا ہے۔
        // تاہم ، اس تبدیلی کی وجہ سے ، تھوڑی دیر کے لئے ، زندہ زون اب `data[alive]` نہیں ، بلکہ `data[alive.start..=idx]` ہے۔
        //
        self.alive.next_back().map(|idx| {
            // صف سے عنصر پڑھیں۔
            // محفوظ: `idx` کے سابق "alive" خطے میں ایک انڈیکس ہے
            // سرنی۔اس عنصر کو پڑھنے کا مطلب یہ ہے کہ `data[idx]` کو اب مردہ سمجھا جاتا ہے (یعنی چھوئے نہیں)۔
            // چونکہ `idx` زندہ زون کا اختتام تھا ، زندہ زون اب ایک بار پھر `data[alive]` ہے ، تمام حملہ آوروں کو بحال کررہا ہے۔
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // محفوظ کریں: یہ محفوظ ہے: `as_mut_slice` بالکل ذیلی سلائس واپس کرتا ہے
        // ان عناصر کی جو ابھی تک باہر نہیں ہٹائے گئے ہیں اور جنہیں چھوڑ دیا جانا باقی ہے۔
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // حملہ آور `live.start <=کی وجہ سے کبھی انڈر فلو نہیں ہوگا
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// تکرار کرنے والا در حقیقت صحیح لمبائی کی اطلاع دیتا ہے۔
// "alive" عناصر کی تعداد (جو اب بھی برآمد ہوگی) `alive` کی حد کی لمبائی ہے۔
// اس رینج کی لمبائی میں `next` یا `next_back` میں سے کسی ایک میں کم کیا گیا ہے۔
// ان طریقوں میں اس میں ہمیشہ 1 کی کمی واقع ہوتی ہے ، لیکن صرف اس صورت میں جب `Some(_)` واپس ہوجائے۔
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // نوٹ ، ہمیں واقعی عین مطابق زندہ رینج سے میل کھونے کی ضرورت نہیں ہے ، لہذا ہم صرف 100 آفسیٹ میں کلون کرسکتے ہیں اس سے قطع نظر کہ `self` کہاں ہے۔
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // تمام زندہ عناصر کو کلون کریں۔
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // نئی صف میں کلون لکھیں ، پھر اس کی زندہ رینج کو اپ ڈیٹ کریں۔
            // اگر panics کو کلون کرنا ہے تو ، ہم پچھلے آئٹمز کو صحیح طریقے سے چھوڑیں گے۔
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // صرف ان عناصر کو پرنٹ کریں جو ابھی تک برآمد نہیں ہوئے تھے: ہم اب برآمد شدہ عناصر تک رسائی حاصل نہیں کرسکتے ہیں۔
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}