/// غیر منقولہ dereferences کے کاموں کے لئے استعمال کیا جاتا ہے ، جیسے `*v`۔
///
/// غیر منقولہ سیاق و سباق میں (unary) `*` آپریٹر کے ساتھ واضح dereferences کے کاموں کے لئے استعمال ہونے کے علاوہ ، `Deref` بھی بہت سے حالات میں مرتب کے ذریعہ واضح طور پر استعمال ہوتا ہے۔
/// اس میکانزم کو ['`Deref` coercion'][more] کہا جاتا ہے۔
/// تغیر پزیر سیاق و سباق میں ، [`DerefMut`] استعمال کیا جاتا ہے۔
///
/// سمارٹ پوائنٹرز کے لئے `Deref` کو نافذ کرنے سے ان کے پیچھے والے اعداد و شمار تک رسائی آسان ہوجاتی ہے ، یہی وجہ ہے کہ وہ `Deref` لاگو کرتے ہیں۔
/// دوسری طرف ، `Deref` اور [`DerefMut`] کے بارے میں قواعد خاص طور پر سمارٹ پوائنٹرز کو ایڈجسٹ کرنے کے لئے تیار کیے گئے تھے۔
/// اس کی وجہ سے ،**re ڈیریف کو صرف سمارٹ پوائنٹرز** کے لئے لاگو کیا جانا چاہئے تاکہ الجھن سے بچا جاسکے۔
///
/// اسی طرح کی وجوہات کی بناء پر ،**یہ trait کبھی ناکام نہیں ہونا چاہئے**۔ڈیفرانسنگ کے دوران ناکامی انتہائی الجھن ہوسکتی ہے جب `Deref` کو واضح طور پر طلب کیا جاتا ہے۔
///
/// # `Deref` جبر کے بارے میں مزید
///
/// اگر `T` `Deref<Target = U>` لاگو کرتا ہے ، اور `x` `T` قسم کی قدر ہے ، تو:
///
/// * غیر منقولہ سیاق و سباق میں ، `*x` (جہاں `T` نہ تو حوالہ ہے اور نہ ہی خام پوائنٹر) `* Deref::deref(&x)` کے برابر ہے۔
/// * قسم `&T` کی اقدار کو `&U` قسم کی اقدار پر مجبور کیا جاتا ہے
/// * `T` `U` قسم کے تمام (immutable) طریقوں کو واضح طور پر نافذ کرتا ہے۔
///
/// مزید تفصیلات کے لئے ، [the chapter in *The Rust Programming Language*][book] کے ساتھ ساتھ [the dereference operator][ref-deref-op] ، [method resolution] اور [type coercions] پر حوالہ حصے دیکھیں۔
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ایک ڈھانچہ جس میں ایک ہی فیلڈ ہو جس کو ڈریکٹ کر کے قابل رسائی ہے۔
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// تعیfereن کے بعد نتیجے میں آنے والی قسم۔
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// قدر کی قدر کرتی ہے۔
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// قابل تبادلہ ڈیفرانسیسی کارروائیوں کے لئے استعمال کیا جاتا ہے ، جیسے `*v = 1;` میں۔
///
/// تغیر پزیر سیاق و سباق میں (unary) `*` آپریٹر کے ساتھ واضح dereferences کے کاموں کے لئے استعمال ہونے کے علاوہ ، `DerefMut` بھی بہت سے حالات میں مرتب کے ذریعہ واضح طور پر استعمال ہوتا ہے۔
/// اس میکانزم کو ['`Deref` coercion'][more] کہا جاتا ہے۔
/// غیر منقولہ سیاق و سباق میں ، [`Deref`] استعمال کیا جاتا ہے۔
///
/// سمارٹ پوائنٹرز کے لئے `DerefMut` کو نافذ کرنے سے ان کے پیچھے والے ڈیٹا کو تبدیل کرنا آسان ہوجاتا ہے ، یہی وجہ ہے کہ وہ `DerefMut` لاگو کرتے ہیں۔
/// دوسری طرف ، [`Deref`] اور `DerefMut` کے بارے میں قواعد خاص طور پر سمارٹ پوائنٹرز کو ایڈجسٹ کرنے کے لئے تیار کیے گئے تھے۔
/// اس کی وجہ سے ،**`DerefMut` صرف اسمارٹ پوائنٹرز** کے لئے لاگو ہونا چاہئے تاکہ الجھن سے بچا جاسکے۔
///
/// اسی طرح کی وجوہات کی بناء پر ،**یہ trait کبھی ناکام نہیں ہونا چاہئے**۔ڈیفرانسنگ کے دوران ناکامی انتہائی الجھن ہوسکتی ہے جب `DerefMut` کو واضح طور پر طلب کیا جاتا ہے۔
///
/// # `Deref` جبر کے بارے میں مزید
///
/// اگر `T` `DerefMut<Target = U>` لاگو کرتا ہے ، اور `x` `T` قسم کی قدر ہے ، تو:
///
/// * تغیر پزیر سیاق و سباق میں ، `*x` (جہاں `T` نہ تو حوالہ ہے اور نہ ہی خام پوائنٹر) `* DerefMut::deref_mut(&mut x)` کے برابر ہے۔
/// * قسم `&mut T` کی اقدار کو `&mut U` قسم کی اقدار پر مجبور کیا جاتا ہے
/// * `T` `U` قسم کے تمام (mutable) طریقوں کو واضح طور پر نافذ کرتا ہے۔
///
/// مزید تفصیلات کے لئے ، [the chapter in *The Rust Programming Language*][book] کے ساتھ ساتھ [the dereference operator][ref-deref-op] ، [method resolution] اور [type coercions] پر حوالہ حصے دیکھیں۔
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ایک ڈھانچہ جس میں ایک ہی فیلڈ ہے جو اس ڈرافٹ کو ڈیرایفرسن کر کے قابل اصلاحی ہے۔
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// باہمی طور پر قدر کا حوالہ دیتے ہیں۔
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// اس بات کی نشاندہی کرتا ہے کہ اسٹریک کو `arbitrary_self_types` خصوصیت کے بغیر ، ایک طریقہ وصول کرنے والے کے طور پر استعمال کیا جاسکتا ہے۔
///
/// یہ stdlib پوائنٹر اقسام جیسے `Box<T>` ، `Rc<T>` ، `&T` ، اور `Pin<P>` کے ذریعہ نافذ کیا جاتا ہے۔
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}