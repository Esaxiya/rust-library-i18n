/// `?` آپریٹر کے طرز عمل کو کسٹمائز کرنے کیلئے ایک trait۔
///
/// ایک قسم کا نفاذ `Try` ایک ہے جس میں success/failure ڈائکوٹومی کے لحاظ سے دیکھنے کا عمومی طریقہ ہے۔
/// یہ trait دونوں کامیابی یا ناکامی کی اقدار کو موجودہ مثال سے نکالنے اور کامیابی یا ناکامی کی قدر سے ایک نئی مثال پیدا کرنے کی اجازت دیتا ہے۔
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// جب کامیابی کے طور پر دیکھا جائے تو اس قدر کی قسم۔
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// اس قدر کی قسم جب ناکام کے طور پر دیکھا جائے۔
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" آپریٹر کا اطلاق ہوتا ہے۔`Ok(t)` کی واپسی کا مطلب یہ ہے کہ عملدرآمد عام طور پر جاری رہنا چاہئے ، اور `?` کا نتیجہ `t` کی قدر ہے۔
    /// `Err(e)` کی واپسی کا مطلب یہ ہے کہ پھانسی کو branch کو اندرونی اندر بند `catch` پر جانا چاہئے ، یا فنکشن سے واپس ہونا چاہئے۔
    ///
    /// اگر `Err(e)` کا نتیجہ واپس ہو جاتا ہے تو ، منسلک گنجائش کی واپسی قسم میں `e` کی قیمت "wrapped" ہوگی (جس میں خود `Try` لاگو ہونا چاہئے)۔
    ///
    /// خاص طور پر ، `X::from_error(From::from(e))` کی قیمت واپس کردی گئی ہے ، جہاں `X` انکلوزنگ فنکشن کی واپسی کی قسم ہے۔
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// جامع نتیجہ تیار کرنے کے لئے ایک غلطی کی قیمت لپیٹیں۔
    /// مثال کے طور پر ، `Result::Err(x)` اور `Result::from_error(x)` برابر ہیں۔
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// جامع نتیجہ تیار کرنے کے لئے ایک ٹھیک قدر کو لپیٹیں۔
    /// مثال کے طور پر ، `Result::Ok(x)` اور `Result::from_ok(x)` برابر ہیں۔
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}