use crate::marker::Unsize;

/// Trait جو اشارہ کرتا ہے کہ یہ ایک پوائنٹر یا کسی کے ل wra ریپر ہے ، جہاں پوائنٹ پوائنٹس پر انائزنگ کی جاسکتی ہے۔
///
/// مزید تفصیلات کے لئے [DST coercion RFC][dst-coerce] اور [the nomicon entry on coercion][nomicon-coerce] دیکھیں۔
///
/// بلٹ ان پوائنٹر کی قسموں کے لئے ، `T` پر پوائنٹر `U` کی طرف اشارہ کرنے پر مجبور کریں گے اگر `T: Unsize<U>` پتلی پوائنٹر سے چربی پوائنٹر میں تبدیل کرکے۔
///
/// اپنی مرضی کے مطابق اقسام کے لئے ، یہاں جبر `Foo<T>` کو `Foo<U>` پر زور دے کر کام کرتا ہے بشرطیکہ `CoerceUnsized<Foo<U>> for Foo<T>` کی امپائر موجود ہو۔
/// اس طرح کی امپیل صرف اس وقت لکھی جاسکتی ہے جب `Foo<T>` میں صرف ایک واحد غیر فینٹمڈاٹا فیلڈ ہو جس میں `T` شامل ہو۔
/// اگر اس فیلڈ کی قسم `Bar<T>` ہے تو ، `CoerceUnsized<Bar<U>> for Bar<T>` پر عمل درآمد موجود ہونا ضروری ہے۔
/// جبر `Bar<T>` فیلڈ کو `Bar<U>` پر مجبور کرکے اور `Foo<T>` سے باقی فیلڈز کو `Foo<U>` بنانے کے ل create کام کرے گا۔
/// یہ مؤثر طریقے سے ایک پوائنٹر فیلڈ میں ڈرل کرے گا اور اس پر مجبور کرے گا۔
///
/// عام طور پر ، سمارٹ پوائنٹرز کے ل you ، آپ `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` پر عمل درآمد کروائیں گے ، اختیاری `?Sized` کے ساتھ ہی `T` پر پابند ہوں گے۔
/// ریپر اقسام کے لئے جو `T` جیسے `Cell<T>` اور `RefCell<T>` کو براہ راست سرایت کرتے ہیں ، آپ براہ راست `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` لاگو کرسکتے ہیں۔
///
/// اس سے `Cell<Box<T>>` جیسے قسم کے جبر کو کام کرنے دیا جائے گا۔
///
/// [`Unsize`][unsize] ان اقسام کو نشان زد کرنے کے لئے استعمال کیا جاتا ہے جو پوائنٹر کے پیچھے اگر DSTs پر مجبور ہوسکتے ہیں۔اس کو مرتب کرنے والا خود بخود نافذ کرتا ہے۔
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * کانسٹ یو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * کانسٹ یو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *کونٹ ٹی->* کانسٹ یو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// اس کا استعمال آبجیکٹ سیفٹی کے لئے کیا جاتا ہے ، یہ جانچنے کے لئے کہ کسی طریقہ کے وصول کنندہ کی قسم کو بھیجا جاسکتا ہے۔
///
/// trait کی ایک مثال کے نفاذ:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *کونٹ ٹی->* کانسٹ یو
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}