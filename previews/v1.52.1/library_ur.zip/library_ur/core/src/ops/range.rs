use crate::fmt;
use crate::hash::Hash;

/// ایک بے حد رینج (`..`)۔
///
/// `RangeFull` بنیادی طور پر [slicing index] کے طور پر استعمال ہوتا ہے ، اس کا شارٹ ہینڈ `..` ہے۔
/// یہ [`Iterator`] کے طور پر کام نہیں کرسکتا کیونکہ اس میں نقطہ اغاز نہیں ہے۔
///
/// # Examples
///
/// `..` نحو ایک `RangeFull` ہے:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// اس میں [`IntoIterator`] نفاذ نہیں ہے ، لہذا آپ اسے `for` لوپ میں براہ راست استعمال نہیں کرسکتے ہیں۔
/// یہ مرتب نہیں ہوگا:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] کے طور پر استعمال کیا جاتا ہے ، `RangeFull` سلائس کی طرح پوری صف تیار کرتا ہے۔
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // یہ `RangeFull` ہے
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// ایک (half-open) رینج جامع طور پر نیچے اور خصوصی طور پر (`start..end`) سے اوپر کی پابند ہے۔
///
///
/// `start..end` کی حد میں `start <= x < end` والی تمام اقدار ہیں۔
/// یہ خالی ہے اگر `start >= end`۔
///
/// # Examples
///
/// `start..end` نحو ایک `Range` ہے:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // یہ ایک `Range` ہے
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // کاپی نہیں-#27186 دیکھیں
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// رینج (inclusive) کی نچلی حد۔
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// رینج (exclusive) کی اوپری حد۔
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// اگر `item` رینج میں موجود ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// اگر رینج میں آئٹمز نہ ہوں تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// اگر دونوں طرف کی کوئی چیز قابل تقلید ہو تو حد اطلاق خالی ہے۔
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// ایک حد جس میں صرف (`start..`) کے نیچے شامل ہے۔
///
/// `RangeFrom` `start..` میں `x >= start` والی تمام اقدار ہیں۔
///
/// *نوٹ*: [`Iterator`] نفاذ میں اوور فلو (جب پر مشتمل ڈیٹا ٹائپ اپنی عددی حد تک پہنچ جائے) panic ، لپیٹ ، یا مطمئن کرنے کی اجازت ہے۔
/// اس طرز عمل کی وضاحت [`Step`] trait پر عمل درآمد سے کی گئی ہے۔
/// قدیم عددی عدد کے ل For ، یہ عام اصولوں پر عمل کرتا ہے ، اور اتپرواہ چیک پروفائل کا احترام کرتا ہے (ڈیبگ میں panic ، رہائی میں لپیٹ)۔
/// یہ بھی نوٹ کریں کہ آپ کے سمجھنے سے پہلے بہاؤ ہوتا ہے: اوور فلو `next` پر کال میں ہوتا ہے جس سے زیادہ سے زیادہ قیمت ملتی ہے ، کیونکہ اگلی قیمت برآمد کرنے کے لئے حد کو کسی ریاست میں طے کرنا ہوگا۔
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` نحو ایک `RangeFrom` ہے:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // یہ ایک `RangeFrom` ہے
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // کاپی نہیں-#27186 دیکھیں
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// رینج (inclusive) کی نچلی حد۔
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// اگر `item` رینج میں موجود ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// ایک حد صرف خصوصی طور پر (`..end`) سے اوپر ہے۔
///
/// `RangeTo` `..end` میں `x < end` والی تمام اقدار ہیں۔
/// یہ [`Iterator`] کے طور پر کام نہیں کرسکتا کیونکہ اس میں نقطہ اغاز نہیں ہے۔
///
/// # Examples
///
/// `..end` نحو ایک `RangeTo` ہے:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// اس میں [`IntoIterator`] نفاذ نہیں ہے ، لہذا آپ اسے `for` لوپ میں براہ راست استعمال نہیں کرسکتے ہیں۔
/// یہ مرتب نہیں ہوگا:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// جب [slicing index] کے طور پر استعمال کیا جاتا ہے تو ، `RangeTo` اشارے کے اشارے سے پہلے `end` کے اشارے سے پہلے تمام صف عناصر کا ایک ٹکڑا تیار کرتا ہے۔
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // یہ ایک `RangeTo` ہے
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// رینج (exclusive) کی اوپری حد۔
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// اگر `item` رینج میں موجود ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// ایک حد جس میں (`start..=end`) کے نیچے اور اس سے زیادہ شامل ہے۔
///
/// `RangeInclusive` `start..=end` `x >= start` اور `x <= end` کے ساتھ تمام اقدار پر مشتمل ہے۔یہ خالی ہے جب تک کہ `start <= end` نہ ہو۔
///
/// یہ ریڈیٹر [fused] ہے ، لیکن `start` اور `end` کی مخصوص اقدار آئوٹریشن ختم ہونے کے بعد **غیر متعین** ہیں ، [`.is_empty()`] کے علاوہ کوئی اور اقدار تیار نہیں ہونے کے بعد `true` واپس کردیں گے۔
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` نحو ایک `RangeInclusive` ہے:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // یہ ایک `RangeInclusive` ہے
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // کاپی نہیں-#27186 دیکھیں
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // نوٹ کریں کہ یہاں کے فیلڈز عوامی نہیں ہیں تاکہ وہ future میں نمائندگی کو تبدیل کرسکیں۔خاص طور پر ، جبکہ ہم start/end کو واضح طور پر بے نقاب کرسکتے ہیں ، (future/current) نجی فیلڈز کو تبدیل کیے بغیر ان میں ترمیم کرنا غلط سلوک کا سبب بن سکتا ہے ، لہذا ہم اس موڈ کی حمایت نہیں کرنا چاہتے ہیں۔
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // یہ فیلڈ ہے:
    //  - `false` تعمیر پر
    //  - `false` جب تکرار سے ایک عنصر برآمد ہوا ہو اور آئٹرٹر ختم نہیں ہوتا ہے
    //  - `true` جب تکرار کرنے والا استعمال کرنے والے کو ختم کرنے کے ل. استعمال ہوتا ہے
    //
    // جزوی طور پر پابند یا تخصص کے بغیر جزویہایق اور ہیش کی حمایت کرنا ضروری ہے۔
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// ایک نئی شمولیت کی حد بناتا ہے۔`start..=end` لکھنے کے مساوی ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// رینج (inclusive) کی نچلی حد کو لوٹاتا ہے۔
    ///
    /// تکرار کے ل an ایک جامع رینج کا استعمال کرتے وقت ، `start()` اور [`end()`] کی قدریں تکرار ختم ہونے کے بعد غیر متعینہ کردی گئیں۔
    /// اس بات کا تعین کرنے کے لئے کہ کیا شامل رینج خالی ہے ، `start() > end()` کا موازنہ کرنے کے بجائے [`is_empty()`] طریقہ استعمال کریں۔
    ///
    /// Note: حد کی تکرار کے بعد اس کی حد سے تکرار کرنے کے بعد اس طریقے سے واپس کی گئی قیمت کی وضاحت نہیں کی گئی ہے۔
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) رینج کے اوپری حد کو لوٹاتا ہے۔
    ///
    /// تکرار کے ل an ایک جامع رینج کا استعمال کرتے وقت ، [`start()`] اور `end()` کی قدریں تکرار ختم ہونے کے بعد غیر متعینہ کردی گئیں۔
    /// اس بات کا تعین کرنے کے لئے کہ کیا شامل رینج خالی ہے ، `start() > end()` کا موازنہ کرنے کے بجائے [`is_empty()`] طریقہ استعمال کریں۔
    ///
    /// Note: حد کی تکرار کے بعد اس کی حد سے تکرار کرنے کے بعد اس طریقے سے واپس کی گئی قیمت کی وضاحت نہیں کی گئی ہے۔
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` (نچلے باؤنڈ ، اوپری (inclusive) پابند) میں تعمیر کرتا ہے۔
    ///
    /// Note: حد کی تکرار کے بعد اس کی حد سے تکرار کرنے کے بعد اس طریقے سے واپس کی گئی قیمت کی وضاحت نہیں کی گئی ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` پر عمل درآمد کیلئے خصوصی `Range` میں تبدیل ہوتا ہے۔
    /// کال کرنے والا `end == usize::MAX` سے نمٹنے کے لئے ذمہ دار ہے۔
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // اگر ہم ختم نہیں ہوئے ہیں تو ، ہم صرف `start..end + 1` ٹکڑا کرنا چاہتے ہیں۔
        // اگر ہم تھک چکے ہیں ، تو `end + 1..end + 1` کے ساتھ ٹکرانے سے ہمیں ایک خالی رینج ملتی ہے جو اب بھی اس اختتامی نقطہ کے حدود کی جانچ کے تابع ہے۔
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// اگر `item` رینج میں موجود ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// تکرار ختم ہونے کے بعد یہ طریقہ ہمیشہ `false` کی واپسی کرتا ہے۔
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // قطعی فیلڈ قدریں یہاں غیر مخصوص ہیں
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// اگر رینج میں آئٹمز نہ ہوں تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// اگر دونوں طرف کی کوئی چیز قابل تقلید ہو تو حد اطلاق خالی ہے۔
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// یہ طریقہ `true` واپس کرتا ہے جب تکلیف ختم ہوجائے:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // قطعی فیلڈ قدریں یہاں غیر مخصوص ہیں
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// ایک حد جس میں صرف (`..=end`) سے زیادہ شامل ہے۔
///
/// `RangeToInclusive` `..=end` میں `x <= end` والی تمام اقدار ہیں۔
/// یہ [`Iterator`] کے طور پر کام نہیں کرسکتا کیونکہ اس میں نقطہ اغاز نہیں ہے۔
///
/// # Examples
///
/// `..=end` نحو ایک `RangeToInclusive` ہے:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// اس میں [`IntoIterator`] نفاذ نہیں ہے ، لہذا آپ اسے `for` لوپ میں براہ راست استعمال نہیں کرسکتے ہیں۔یہ مرتب نہیں ہوگا:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// جب [slicing index] کے طور پر استعمال کیا جاتا ہے ، تو `RangeToInclusive` تمام صف عناصر کا ایک ٹکڑا تیار کرتا ہے اور اس میں `end` کے ذریعہ اشارہ کردہ انڈیکس بھی شامل ہے۔
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // یہ ایک `RangeToInclusive` ہے
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// رینج (inclusive) کی اوپری حد
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// اگر `item` رینج میں موجود ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// رینج ٹو انکلیو<Idx>سے درخواست نہیں کر سکتے ہیں <RangeTo<Idx>> کیونکہ انڈر فلو (..0).into() کے ساتھ ممکن ہوگا
//

/// کلیدوں کی ایک حد کا اختتامی نقطہ۔
///
/// # Examples
///
/// `حدود آخری حدود ہیں۔
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] پر بطور دلیل `باؤنڈز کا ایک ٹول استعمال کرنا۔
/// نوٹ کریں کہ زیادہ تر معاملات میں ، اس کی بجائے رینج کا نحو (`1..5`) استعمال کرنا بہتر ہے۔
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// ایک جامع پابند.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ایک خصوصی پابند۔
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ایک لامحدود اختتامی نقطہ۔اشارہ کرتا ہے کہ اس سمت کا کوئی پابند نہیں ہے۔
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` سے `Bound<&T>` میں تبدیل ہوتا ہے۔
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` سے `Bound<&T>` میں تبدیل ہوتا ہے۔
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// حد کے مندرجات کو کلون کرکے ایک `Bound<&T>` کو `Bound<T>` کا نقشہ بنائیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` Rust کی بلٹ ان رینج اقسام کے ذریعہ لاگو کیا جاتا ہے ، جو `..` ، `a..` ، `..b` ، `..=c` ، `d..e` ، یا `f..=g` جیسے رینج ترکیب کے ذریعہ تیار کیا جاتا ہے۔
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// انڈیکس پابند ہوں۔
    ///
    /// `Bound` کی حیثیت سے ابتدائی قدر لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// انڈیکس پابند ہے۔
    ///
    /// `Bound` کے بطور آخری قیمت لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// اگر `item` رینج میں موجود ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// زور! ((3..5).contains(&4))؛
    /// assert!(!(3..5).contains(&2));
    ///
    /// زور! ((0.0..1.0).contains(&0.5))؛
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // جب ایریٹر ختم ہوجاتا ہے ، تو ہم عام طور پر شروع==اختتام پزیر ہوتے ہیں ، لیکن ہم چاہتے ہیں کہ رینج خالی دکھائی دے ، جس میں کچھ بھی نہیں ہوگا۔
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}