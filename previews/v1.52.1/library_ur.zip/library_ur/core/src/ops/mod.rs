//! اوور لوڈ ایبل آپریٹرز
//!
//! ان traits پر عمل درآمد آپ کو کچھ آپریٹرز کو اوورلوڈ کرنے کی سہولت دیتا ہے۔
//!
//! ان میں سے کچھ traits preolve کے ذریعہ درآمد کیا جاتا ہے ، لہذا وہ ہر Rust پروگرام میں دستیاب ہیں۔صرف traits کے تعاون سے چلنے والے آپریٹروں کو اوورلوڈ کیا جاسکتا ہے۔
//! مثال کے طور پر ، اضافی آپریٹر (`+`) کو [`Add`] trait کے ذریعے اوورلوڈ کیا جاسکتا ہے ، لیکن چونکہ اسائنمنٹ آپریٹر (`=`) کی trait کی پشت پناہی نہیں ہے ، لہذا اس کے الفاظ کو اوورلوڈ کرنے کا کوئی طریقہ نہیں ہے۔
//! مزید برآں ، یہ ماڈیول نئے آپریٹرز بنانے کے ل any کوئی میکانزم فراہم نہیں کرتا ہے۔
//! اگر ٹریٹ لیس اوورلوڈنگ یا کسٹم آپریٹرز کی ضرورت ہوتی ہے تو ، آپ کو Rust کے ترکیب کو بڑھانے کے لئے میکروز یا مرتب کرنے والے پلگ ان کی طرف دیکھنا چاہئے۔
//!
//! آپریٹر traits کے نفاذ کو اپنے معمول کے معنی اور [operator precedence] کو مدنظر رکھتے ہوئے ، ان کے متعلقہ سیاق و سباق میں حیرت انگیز نہیں ہونا چاہئے۔
//! مثال کے طور پر ، جب [`Mul`] کو نافذ کرتے ہو تو ، اس کارروائی میں ضرب کے ساتھ کچھ مشابہت ہونی چاہئے (اور اس کی توقع پراپرٹی جیسے اشتراک کی)۔
//!
//! نوٹ کریں کہ `&&` اور `||` آپریٹرز شارٹ سرکٹ ، یعنی ، وہ صرف اپنے دوسرے کام کا جائزہ لیتے ہیں اگر یہ نتیجہ میں حصہ ڈالے۔چونکہ یہ سلوک traits کے ذریعہ قابل عمل نہیں ہے ، لہذا `&&` اور `||` اوورلوڈ آپریٹرز کے بطور تعاون یافتہ نہیں ہیں۔
//!
//! بہت سارے آپریٹر اپنی مالیت کو قیمت کے حساب سے لیتے ہیں۔غیر عام سیاق و سباق میں بلٹ میں شامل اقسام میں ، یہ عام طور پر کوئی مسئلہ نہیں ہوتا ہے۔
//! تاہم ، ان آپریٹرز کو جنرک کوڈ میں استعمال کرنے کے ل some ، کچھ توجہ دینے کی ضرورت ہے اگر آپریٹرز کو استعمال کرنے کی اجازت دینے کے برخلاف اقدار کو دوبارہ استعمال کرنا پڑے۔ایک اختیار یہ ہے کہ کبھی کبھار [`clone`] استعمال کریں۔
//! دوسرا آپشن یہ ہے کہ حوالوں کے ل additional آپریٹر کے اضافی عمل کو فراہم کرنے میں شامل اقسام پر انحصار کرنا ہے۔
//! مثال کے طور پر ، صارف کی وضاحت شدہ قسم `T` کے لئے جس میں اضافے کی حمایت کی جانی چاہئے ، `T` اور `&T` دونوں کو traits [`Add<T>`][`Add`] اور [`Add<&T>`][`Add`] پر عمل درآمد کرنا شاید ایک اچھا خیال ہے تاکہ عام کوڈ کو غیر ضروری کلوننگ کے بغیر لکھا جا سکے۔
//!
//!
//! # Examples
//!
//! یہ مثال ایک `Point` ڈھانچے کی تشکیل کرتی ہے جو [`Add`] اور [`Sub`] پر عمل درآمد کرتی ہے ، اور پھر دو پوائنٹس` کو جوڑنے اور گھٹانے کا مظاہرہ کرتی ہے۔
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! مثال کے نفاذ کے لئے ہر trait کیلئے دستاویزات دیکھیں۔
//!
//! [`Fn`] ، [`FnMut`] ، اور [`FnOnce`] traits ان قسموں کے ذریعہ نافذ کیا جاتا ہے جن کو افعال کی طرح منایا جاسکتا ہے۔نوٹ کریں کہ [`Fn`] نے `&self` ، [`FnMut`] نے `&mut self` اور [`FnOnce`] نے `self` لیتا ہے۔
//! یہ ان تین طرح کے طریقوں سے مشابہ ہے جن کو مثال کے طور پر استعمال کیا جاسکتا ہے: کال بائی ریفرنس ، کال بہ بہ متغیر حوالہ ، اور کال بہ قدر۔
//! ان traits کا سب سے عام استعمال اعلی سطح کے افعال کی حدود کے طور پر کام کرنا ہے جو افعال یا بندش کو دلائل کے طور پر پیش کرتے ہیں۔
//!
//! پیرامیٹر کے طور پر [`Fn`] لینا:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! پیرامیٹر کے طور پر [`FnMut`] لینا:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! پیرامیٹر کے طور پر [`FnOnce`] لینا:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` اس کے قبضہ شدہ متغیرات کو کھاتا ہے ، لہذا اسے ایک سے زیادہ بار نہیں چلایا جاسکتا
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // دوبارہ `func()` پر زور دینے کی کوشش کرنا `func` کے لئے `use of moved value` غلطی پھینک دے گا
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` اس مقام پر اب مزید مدد نہیں دی جاسکتی ہے
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;