/// کال آپریٹر کا وہ ورژن جو غیر منقولہ وصول کرتا ہے۔
///
/// `Fn` کی مثالوں میں تغیر پذیر حالت کے بغیر بار بار کہا جاسکتا ہے۔
///
/// *یہ trait (`Fn`) [function pointers] (`fn`) کے ساتھ الجھن میں نہیں پڑنا چاہئے۔*
///
/// `Fn` بندشوں کے ذریعہ خود بخود عمل میں لایا جاتا ہے جو صرف قبضہ شدہ متغیرات کا غیر متزلزل حوالہ لیتے ہیں یا بالکل بھی کچھ حاصل نہیں کرتے ہیں ، نیز (safe) [function pointers] (کچھ احتیاط کے ساتھ ، مزید تفصیلات کے لئے ان کی دستاویزات دیکھیں)۔
///
/// مزید برآں ، کسی بھی قسم کے `F` کے لئے جو `Fn` لاگو کرتا ہے ، `&F` بھی `Fn` پر عمل درآمد کرتا ہے۔
///
/// چونکہ [`FnMut`] اور [`FnOnce`] دونوں ہی `Fn` کی سپر ٹرین ہیں ، `Fn` کی کسی بھی مثال کو پیرامیٹر کے طور پر استعمال کیا جاسکتا ہے جہاں [`FnMut`] یا [`FnOnce`] کی توقع کی جاتی ہے۔
///
/// جب آپ فنکشن جیسی قسم کے پیرامیٹر کو قبول کرنا چاہتے ہو اور اسے بار بار اور بدلتے ہوئے حالت کے بغیر کال کرنے کی ضرورت ہو تو `Fn` کو بائونڈ کے طور پر استعمال کریں (مثال کے طور پر ، جب اسے بیک وقت کہتے ہیں)۔
/// اگر آپ کو ایسی سخت ضرورتوں کی ضرورت نہیں ہے تو ، [`FnMut`] یا [`FnOnce`] کو حدود کے طور پر استعمال کریں۔
///
/// اس عنوان سے متعلق کچھ اور معلومات کے لئے [chapter on closures in *The Rust Programming Language*][book] دیکھیں۔
///
/// نوٹ کرنا `Fn` traits کے لئے خصوصی ترکیب ہے (جیسے
/// `Fn(usize, bool) -> usize`)۔جو لوگ اس کی تکنیکی تفصیلات میں دلچسپی رکھتے ہیں وہ [the relevant section in the *Rustonomicon*][nomicon] کا حوالہ دے سکتے ہیں۔
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## بندش کا مطالبہ کرنا
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` پیرامیٹر کا استعمال کرنا
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // تاکہ regex اس `&str: !FnMut` پر بھروسہ کرسکے
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// کال آپریشن انجام دیتا ہے۔
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// کال آپریٹر کا وہ ورژن جو ایک تبدیل شدہ وصول کنندہ لیتا ہے۔
///
/// `FnMut` کی مثالوں کو بار بار کہا جاسکتا ہے اور حالت بدل سکتی ہے۔
///
/// `FnMut` بندش کے ذریعہ خود بخود لاگو ہوتا ہے جو قبضہ شدہ متغیرات کے متغیر حوالہ جات لیتے ہیں ، اسی طرح ہر قسم کی جو [`Fn`] پر عمل درآمد کرتے ہیں ، جیسے ، (safe) [function pointers] (چونکہ `FnMut` [`Fn`] کا ایک سپرٹرایٹ ہے)۔
/// مزید برآں ، کسی بھی قسم کے `F` کے لئے جو `FnMut` لاگو کرتا ہے ، `&mut F` بھی `FnMut` پر عمل درآمد کرتا ہے۔
///
/// چونکہ [`FnOnce`] `FnMut` کا ایک سپر اسٹریٹ ہے ، لہذا `FnMut` کی کوئی بھی مثال استعمال کی جاسکتی ہے جہاں ایک [`FnOnce`] کی توقع کی جاتی ہے ، اور چونکہ [`Fn`] `FnMut` کا سب ٹرائٹ ہے لہذا [`Fn`] کی کوئی بھی مثال استعمال کی جاسکتی ہے جہاں `FnMut` کی توقع کی جاتی ہے۔
///
/// جب آپ فنکشن جیسی قسم کے پیرامیٹر کو قبول کرنا چاہتے ہو اور X-ایکس کو بائونڈ کے طور پر استعمال کریں ، اور اسے بار بار فون کرنے کی ضرورت ہوگی ، جبکہ اس میں تبدیل ہوجائیں۔
/// اگر آپ پیرامیٹر کو تبدیل کرنے کی حالت میں نہیں چاہتے ہیں تو ، [`Fn`] کو بطور حدود استعمال کریں۔اگر آپ کو بار بار فون کرنے کی ضرورت نہیں ہے تو ، [`FnOnce`] استعمال کریں۔
///
/// اس عنوان سے متعلق کچھ اور معلومات کے لئے [chapter on closures in *The Rust Programming Language*][book] دیکھیں۔
///
/// نوٹ کرنا `Fn` traits کے لئے خصوصی ترکیب ہے (جیسے
/// `Fn(usize, bool) -> usize`)۔جو لوگ اس کی تکنیکی تفصیلات میں دلچسپی رکھتے ہیں وہ [the relevant section in the *Rustonomicon*][nomicon] کا حوالہ دے سکتے ہیں۔
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## باہم گرفتاری بند کرنا
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` پیرامیٹر کا استعمال کرنا
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // تاکہ regex اس `&str: !FnMut` پر بھروسہ کرسکے
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// کال آپریشن انجام دیتا ہے۔
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// کال آپریٹر کا وہ ورژن جو بائی ویلیو وصول کرتا ہے۔
///
/// `FnOnce` کی مثال طلب کی جاسکتی ہے ، لیکن ہوسکتا ہے کہ متعدد بار کال کرنے کے قابل نہ ہوں۔اس کی وجہ سے ، اگر کسی قسم کے بارے میں صرف ایک ہی چیز یہ معلوم ہوتی ہے کہ وہ `FnOnce` لاگو کرتی ہے ، تو اسے صرف ایک بار کہا جاسکتا ہے۔
///
/// `FnOnce` بندش کے ذریعہ خود بخود لاگو کیا جاتا ہے جس میں قبضہ شدہ متغیرات کا استعمال ہوسکتا ہے ، اور ساتھ ہی ایسی تمام اقسام جو [`FnMut`] پر عمل درآمد کرتی ہیں ، جیسے ، (safe) [function pointers] (چونکہ `FnOnce` [`FnMut`] کا ایک سپرٹراٹ ہے)۔
///
///
/// چونکہ [`Fn`] اور [`FnMut`] دونوں `FnOnce` کے سب ٹرائٹس ہیں ، لہذا [`Fn`] یا [`FnMut`] کی کوئی بھی مثال استعمال کی جاسکتی ہے جہاں ایک `FnOnce` کی توقع کی جاتی ہے۔
///
/// جب آپ فنکشن جیسی قسم کے پیرامیٹر کو قبول کرنا چاہتے ہو تو `FnOnce` کو بائونڈ کے طور پر استعمال کریں اور اسے صرف ایک بار کال کرنے کی ضرورت ہوگی۔
/// اگر آپ کو پیرامیٹر کو بار بار فون کرنے کی ضرورت ہو تو ، [`FnMut`] کو بطور حد تک استعمال کریں۔اگر آپ کو بھی حالت تبدیل نہ کرنے کی ضرورت ہو تو ، [`Fn`] استعمال کریں۔
///
/// اس عنوان سے متعلق کچھ اور معلومات کے لئے [chapter on closures in *The Rust Programming Language*][book] دیکھیں۔
///
/// نوٹ کرنا `Fn` traits کے لئے خصوصی ترکیب ہے (جیسے
/// `Fn(usize, bool) -> usize`)۔جو لوگ اس کی تکنیکی تفصیلات میں دلچسپی رکھتے ہیں وہ [the relevant section in the *Rustonomicon*][nomicon] کا حوالہ دے سکتے ہیں۔
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` پیرامیٹر کا استعمال کرنا
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` اس کے قبضہ شدہ متغیرات کو کھاتا ہے ، لہذا اسے ایک سے زیادہ بار نہیں چلایا جاسکتا۔
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // دوبارہ `func()` پر زور دینے کی کوشش کرنا `func` کے لئے `use of moved value` غلطی پھینک دے گا۔
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` اس مقام پر اب مزید مدد نہیں دی جاسکتی ہے
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // تاکہ regex اس `&str: !FnMut` پر بھروسہ کرسکے
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// کال آپریٹر استعمال ہونے کے بعد لوٹی ہوئی قسم۔
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// کال آپریشن انجام دیتا ہے۔
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}