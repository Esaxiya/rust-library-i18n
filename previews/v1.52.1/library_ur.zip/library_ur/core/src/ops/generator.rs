use crate::marker::Unpin;
use crate::pin::Pin;

/// جنریٹر کی بحالی کا نتیجہ۔
///
/// یہ اینوم `Generator::resume` طریقہ سے لوٹا ہے اور جنریٹر کی واپسی کی ممکنہ اقدار کی نشاندہی کرتا ہے۔
/// فی الحال یہ معطلی نقطہ (`Yielded`) یا ایک اختتامی نقطہ (`Complete`) سے مساوی ہے۔
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// جنریٹر ایک قیمت کے ساتھ معطل.
    ///
    /// یہ ریاست اشارہ کرتی ہے کہ جنریٹر کو معطل کردیا گیا ہے ، اور عام طور پر `yield` کے بیان سے مماثل ہے۔
    /// اس متغیر میں فراہم کردہ قیمت `yield` پر پہنچے گئے اظہار کے مساوی ہے اور جنریٹروں کو ہر بار قیمت پیش کرنے کی اجازت دیتی ہے۔
    ///
    ///
    Yielded(Y),

    /// جنریٹر واپسی کی قیمت کے ساتھ مکمل ہوا۔
    ///
    /// یہ ریاست اشارہ کرتی ہے کہ جنریٹر نے فراہم کردہ قیمت کے ساتھ عملدرآمد ختم کردیا ہے۔
    /// ایک بار جب ایک جنریٹر نے `Complete` لوٹا دیا تو اسے `resume` پر دوبارہ کال کرنا ایک پروگرامر کی غلطی سمجھا جاتا ہے۔
    ///
    Complete(R),
}

/// trait بلٹ جنریٹر کی اقسام کے ذریعہ نافذ کیا گیا ہے۔
///
/// جنریٹر ، جنہیں عام طور پر کورٹین بھی کہا جاتا ہے ، فی الحال Rust میں زبان کی ایک تجرباتی خصوصیت ہیں۔
/// [RFC 2033] جنریٹرز میں شامل کیا گیا فی الحال async/await نحو کے لئے بنیادی طور پر ایک بلڈنگ بلاک فراہم کرنا ہے لیکن اس کا امکان توثیق کرنے والے اور دوسرے قدیم طبقات کے لئے ایک ارگونومک تعریف بھی فراہم کرے گا۔
///
///
/// جنریٹرز کے لئے نحو اور الفاظ کا اشارہ غیر مستحکم ہے اور استحکام کے ل. مزید آر ایف سی کی ضرورت ہوگی۔اس وقت ، اگرچہ ، نحو بند ہونے کی طرح ہے:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// غیر مستحکم کتاب میں جنریٹرز کی مزید دستاویزات مل سکتی ہیں۔
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// اس جنریٹر کی قیمت کی قسم۔
    ///
    /// اس سے وابستہ قسم `yield` اظہار اور ان اقدار سے مطابقت رکھتی ہے جن کو ہر بار جنریٹر کی پیداوار کے وقت واپس کرنے کی اجازت ہے۔
    ///
    /// مثال کے طور پر ایک جنریٹر کے بطور ایک جنریٹر اس نوعیت کا امکان `T` کے طور پر پائے گا ، اس قسم کا اعادہ کیا جارہا ہے۔
    ///
    type Yield;

    /// اس جنریٹر کی قیمت کی قسم۔
    ///
    /// یہ جنریٹر سے `return` کے بیان کے ساتھ یا کسی جنریٹر کے لفظی الفاظ کے آخری اظہار کے طور پر جنریٹر سے واپس کی گئی قسم سے مماثل ہے۔
    /// مثال کے طور پر futures اسے `Result<T, E>` کے طور پر استعمال کرے گا کیونکہ یہ ایک future کی نمائندگی کرتا ہے۔
    ///
    ///
    type Return;

    /// اس جنریٹر پر عملدرآمد دوبارہ شروع کرتا ہے۔
    ///
    /// یہ فنکشن جنریٹر پر عملدرآمد دوبارہ شروع کردے گا یا عمل درآمد شروع کردے گا اگر یہ پہلے سے موجود نہیں ہے۔
    /// یہ کال جنریٹر کے آخری معطلی نقطہ پر واپس آئے گی ، اور تازہ ترین `yield` سے دوبارہ عمل درآمد شروع کرے گی۔
    /// جنریٹر اس وقت تک عملدرآمد جاری رکھے گا جب تک کہ وہ برآمد نہیں کرے گا یا واپس نہیں ہوگا ، اس مقام پر یہ فنکشن واپس آجائے گا۔
    ///
    /// # واپسی کی قیمت
    ///
    /// اس فنکشن سے لوٹا ہوا `GeneratorState` اینوم اشارہ کرتا ہے کہ واپس آنے پر جنریٹر کس حالت میں ہے۔
    /// اگر `Yielded` مختلف حالت واپس کردی گئی ہے تو پھر جنریٹر معطلی کے مقام پر پہنچ گیا ہے اور ایک قیمت نکل گئی ہے۔
    /// اس ریاست میں جنریٹر بعد میں دوبارہ شروع کرنے کے لئے دستیاب ہیں۔
    ///
    /// اگر `Complete` لوٹ گیا ہے تو پھر فراہم کردہ قیمت کے ساتھ جنریٹر مکمل طور پر ختم ہو گیا ہے۔جنریٹر کے لئے دوبارہ کام شروع کرنا غلط ہے۔
    ///
    /// # Panics
    ///
    /// یہ فنکشن panic ہوسکتا ہے اگر اسے `Complete` مختلف حالت میں واپس کرنے کے بعد بلایا گیا ہو۔
    /// اگرچہ زبان میں جنریٹر لٹریز کی ضمانت `Complete` کے بعد دوبارہ شروع کرنے پر panic کی ضمانت ہے ، لیکن اس کی `Generator` trait کے تمام نفاذ کی ضمانت نہیں ہے۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}