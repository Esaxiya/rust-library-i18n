//! آرڈر اور موازنہ کے لئے فعالیت.
//!
//! اس ماڈیول میں قدروں کو ترتیب دینے اور موازنہ کرنے کے لئے مختلف ٹولز شامل ہیں۔خلاصہ:
//!
//! * [`Eq`] اور [`PartialEq`] traits ہیں جو آپ کو بالترتیب اقدار کے مابین کل اور جزوی مساوات کی وضاحت کرنے کی اجازت دیتی ہیں۔
//! ان کو نافذ کرنے سے `==` اور `!=` آپریٹرز اوورلوڈز ہوسکتے ہیں۔
//! * [`Ord`] اور [`PartialOrd`] traits ہیں جو آپ کو بالترتیب اقدار کے مابین کل اور جزوی ترتیب کو بیان کرنے کی اجازت دیتے ہیں۔
//!
//! ان کو نافذ کرنے سے `<` ، `<=` ، `>` ، اور `>=` آپریٹرز اوورلوڈز۔
//! * [`Ordering`] ایک ایسا اینم ہے جو [`Ord`] اور [`PartialOrd`] کے اہم کاموں کے ذریعہ واپس آیا ہے ، اور آرڈر کی وضاحت کرتا ہے۔
//! * [`Reverse`] ایک ایسا ڈھانچہ ہے جو آپ کو آسانی سے آرڈر کو تبدیل کرنے کی سہولت دیتا ہے۔
//! * [`max`] اور [`min`] وہ افعال ہیں جو [`Ord`] سے دور بنتے ہیں اور آپ کو زیادہ سے زیادہ یا کم سے کم دو اقدار تلاش کرنے کی اجازت دیتے ہیں۔
//!
//! مزید تفصیلات کے ل، ، فہرست میں موجود ہر شے کی متعلقہ دستاویزات دیکھیں۔
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// مساوات کے موازنہ کے لئے Trait جو [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ہیں۔
///
/// یہ trait جزوی مساوات کے لئے اجازت دیتا ہے ، ایسی اقسام کے لئے جن کا برابری کا مکمل تعلق نہیں ہے۔
/// مثال کے طور پر ، فلوٹنگ پوائنٹ نمبر `NaN != NaN` میں ، لہذا فلوٹنگ پوائنٹ کی قسمیں `PartialEq` کو لاگو کرتی ہیں لیکن [`trait@Eq`] نہیں۔
///
/// عام طور پر ، مساوات ہونی چاہئے (تمام `a` ، `b` ، `A` قسم کے `c` ، `B` ، `C`):
///
/// - **توازن**: اگر `A: PartialEq<B>` اور `B: PartialEq<A>` ، تو پھر **`a==b` کا مطلب ہے`b==a`**؛اور
///
/// - **عبارت**: اگر `A: PartialEq<B>` اور `B: PartialEq<C>` اور `A:
///   جزویہ<C>`، پھر **` a==b`اور `b == c` پر مشتمل ہے`a==c`**۔
///
/// نوٹ کریں کہ `B: PartialEq<A>` (symmetric) اور `A: PartialEq<C>` (transitive) امپلس کو وجود پر مجبور نہیں کیا جاتا ہے ، لیکن یہ ضروریات جب بھی موجود ہوتی ہیں لاگو ہوتی ہیں۔
///
/// ## Derivable
///
/// یہ trait `#[derive]` کے ساتھ استعمال کیا جا سکتا ہے۔جب اسٹرکٹس پر ماخوذ ہوجاتے ہیں تو ، جب تمام فیلڈز برابر ہوں تو دو واقعات برابر ہوں گے ، اور اگر برابر کوئی فیلڈ برابر نہیں ہے تو۔جب اناموں پر مشتق ہوتا ہے تو ، ہر مختلف حالت خود کے برابر ہوتی ہے اور دوسری مختلف حالتوں کے برابر نہیں۔
///
/// ## میں `PartialEq` کو کس طرح نافذ کرسکتا ہوں؟
///
/// `PartialEq` صرف [`eq`] طریقہ کو نافذ کرنے کی ضرورت ہے۔[`ne`] پہلے سے طے شدہ طور پر اس کے لحاظ سے تعریف کی جاتی ہے۔[`ne`]*کے کسی دستی نفاذ کو* اس اصول کا احترام کرنا ضروری ہے کہ [`eq`] [`ne`] کا سخت الٹا ہے۔یہ ہے ، `!(a == b)` اگر اور صرف `a != b`۔
///
/// `PartialEq` ، [`PartialOrd`] ، اور [`Ord`]*کے نفاذ کو* ایک دوسرے کے ساتھ متفق ہونا ضروری ہے۔traits میں سے کچھ اخذ کرکے اور دوسروں کو دستی طور پر لاگو کرکے اتفاقی طور پر ان سے اتفاق رائے پیدا کرنا آسان ہے۔
///
/// ایک ڈومین کے لئے مثال کے طور پر عمل درآمد جس میں دو کتابیں ایک ہی کتاب سمجھی جاتی ہیں اگر ان کی آئی ایس بی این مماثلت رکھتی ہے ، یہاں تک کہ اگر اس کی شکل مختلف ہو تو:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## میں دو مختلف اقسام کا موازنہ کیسے کرسکتا ہوں؟
///
/// جس قسم کے ساتھ آپ موازنہ کرسکتے ہیں اس کا اطلاق E جزویہقسمی قسم کے پیرامیٹر کے ذریعے ہوتا ہے۔
/// مثال کے طور پر ، ہم اپنے پچھلے کوڈ کو تھوڑا سا موافقت کرتے ہیں:
///
/// ```
/// // اخذ کرنے والے اوزار<BookFormat>==<BookFormat>موازنہ
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // نافذ کریں<Book>==<BookFormat>موازنہ
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // نافذ کریں<BookFormat>==<Book>موازنہ
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` کو `impl PartialEq<BookFormat> for Book` میں تبدیل کرکے ، ہم `Bookformat`s کو`Book`s کے ساتھ موازنہ کرنے کی اجازت دیتے ہیں۔
///
/// اوپر کی طرح کا موازنہ ، جو ڈھانچے کے کچھ شعبوں کو نظرانداز کرتا ہے ، خطرناک ہوسکتا ہے۔یہ جزوی مساوات کے رشتے کے ل requirements تقاضوں کی آسانی سے بلاجواز خلاف ورزی کا باعث بن سکتا ہے۔
/// مثال کے طور پر ، اگر ہم `PartialEq<Book>` کے لئے `PartialEq<Book>` کا مندرجہ بالا عمل درآمد رکھتے ہیں اور `Book` کے لئے `PartialEq<Book>` کا نفاذ شامل کرتے ہیں (یا تو ایک `#[derive]` کے ذریعے یا پہلی مثال سے دستی عمل درآمد کے ذریعہ) تو نتیجہ منتقلی کی خلاف ورزی کرے گا:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// یہ طریقہ `self` اور `other` اقدار کے مساوی ہونے کے لئے ٹیسٹ کرتا ہے ، اور `==` کے ذریعہ استعمال ہوتا ہے۔
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// یہ طریقہ `!=` کے لئے ٹیسٹ کرتا ہے۔
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// مساوات کے موازنہ کے لئے Trait جو [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) ہیں۔
///
/// اس کا مطلب یہ ہے کہ ، `a == b` اور `a != b` کے سخت الٹ ہونے کے علاوہ ، مساوات بھی ہونی چاہئے (تمام `a` ، `b` اور `c` کے لئے):
///
/// - reflexive: `a == a`;
/// - توازن: `a == b` کا مطلب `b == a` ہے۔اور
/// - عارضی: `a == b` اور `b == c` کا مطلب `a == c` ہے۔
///
/// اس پراپرٹی کو کمپائلر کے ذریعہ چیک نہیں کیا جاسکتا ہے ، اور اسی وجہ سے `Eq` نے [`PartialEq`] کو ظاہر کیا ہے ، اور اس کے پاس کوئی اضافی طریقے نہیں ہیں۔
///
/// ## Derivable
///
/// یہ trait `#[derive]` کے ساتھ استعمال کیا جا سکتا ہے۔
/// جب اخذ کیا گیا ، کیونکہ `Eq` کے کوئی اضافی طریقے نہیں ہیں ، یہ صرف مرتب کرنے والے کو مطلع کررہا ہے کہ یہ جزوی مساوات کے رشتے کی بجائے برابری کا رشتہ ہے۔
///
/// نوٹ کریں کہ `derive` حکمت عملی میں تمام شعبوں کی ضرورت ہوتی ہے `Eq` ، جو ہمیشہ مطلوبہ نہیں ہوتا ہے۔
///
/// ## میں `Eq` کو کس طرح نافذ کرسکتا ہوں؟
///
/// اگر آپ `derive` حکمت عملی استعمال نہیں کرسکتے ہیں تو ، اس کی وضاحت کریں کہ آپ کی قسم `Eq` لاگو کرتی ہے ، جس کے کوئی طریقے نہیں ہیں:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // اس طریقہ کو مکمل طور پر#[اخذ کرنے] کے ذریعہ استعمال کیا جاتا ہے تاکہ یہ معلوم کیا جاسکے کہ ایک قسم کا ہر جزو خود کو#[مشتق] کرتا ہے ، موجودہ مشتق بنیادی ڈھانچے کا مطلب یہ ہے کہ اس trait پر کوئی طریقہ استعمال کیے بغیر اس دعوے کو کرنا تقریبا ناممکن ہے۔
    //
    //
    // اسے کبھی بھی ہاتھ سے استعمال نہیں کیا جانا چاہئے۔
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: اس ڈھانچے کو مکمل طور پر#[اخذ کردہ] بطور استعمال کیا جاتا ہے
// اس بات پر زور دیں کہ ایک قسم کا ہر جزو Eq کو نافذ کرتا ہے۔
//
// یہ ڈھانچہ کبھی بھی صارف کوڈ میں ظاہر نہیں ہونا چاہئے۔
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ایک `Ordering` دو اقدار کے موازنہ کا نتیجہ ہے۔
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// ایک آرڈر جہاں موازنہ قدر دوسرے سے کم ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// ایک آرڈر جہاں موازنہ قدر دوسرے کے برابر ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// ایک آرڈر جہاں موازنہ قدر دوسرے سے زیادہ ہے۔
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// اگر آرڈرنگ `Equal` مختلف حالت میں ہے تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// اگر آرڈرنگ `Equal` مختلف حالت میں نہیں ہے تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// اگر آرڈرنگ `Less` مختلف حالت میں ہے تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// اگر آرڈرنگ `Greater` مختلف حالت میں ہے تو `true` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// اگر آرڈرنگ `Less` یا `Equal` مختلف حالت میں ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// اگر آرڈرنگ `Greater` یا `Equal` مختلف حالت میں ہو تو `true` واپس کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` کو تبدیل کرتا ہے۔
    ///
    /// * `Less` `Greater` بن جاتا ہے۔
    /// * `Greater` `Less` بن جاتا ہے۔
    /// * `Equal` `Equal` بن جاتا ہے۔
    ///
    /// # Examples
    ///
    /// بنیادی سلوک:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// اس موازنہ کو موازنہ کو تبدیل کرنے کے لئے استعمال کیا جاسکتا ہے:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // سب سے چھوٹے سے چھوٹے کو ترتیب دیں۔
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// زنجیریں دو آرڈر۔
    ///
    /// جب `Equal` نہیں ہے تو `self` لوٹاتا ہے۔بصورت دیگر `other` لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// دیئے ہوئے فنکشن کے ساتھ ترتیب دینے کی زنجیریں۔
    ///
    /// جب `Equal` نہیں ہے تو `self` لوٹاتا ہے۔
    /// بصورت دیگر `f` پر کال کریں اور نتیجہ لوٹائیں۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ریورس آرڈرنگ کے لئے ایک مددگار ڈھانچہ۔
///
/// یہ ڈھانچہ ایک مددگار ہے جو [`Vec::sort_by_key`] جیسے افعال کے ساتھ استعمال کیا جاسکتا ہے اور اسے کسی چابی کے کسی حصے کو آرڈر کرنے کے لئے استعمال کیا جاسکتا ہے۔
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// X0Trait0Z ان اقسام کے لئے جو [total order](https://en.wikipedia.org/wiki/Total_order) بناتے ہیں۔
///
/// آرڈر کل آرڈر ہے اگر یہ (تمام `a` ، `b` اور `c` کیلئے):
///
/// - کل اور غیر متناسب: بالکل `a < b` ، `a == b` یا `a > b` میں سے ایک سچ ہے۔اور
/// - ٹرانزیوٹک ، `a < b` اور `b < c` کا مطلب `a < c` ہے۔`==` اور `>` دونوں کے ل The یکساں ہونا ضروری ہے۔
///
/// ## Derivable
///
/// یہ trait `#[derive]` کے ساتھ استعمال کیا جا سکتا ہے۔
/// جب اسٹرکٹس پر اخذ کیا جاتا ہے ، تو یہ ڈھانچے کے ممبروں کے نیچے سے نیچے اعلان آرڈر پر مبنی ایک [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) آرڈرنگ تیار کرے گا۔
///
/// جب اناموں پر اخذ کیا جاتا ہے تو ، مختلف حالتوں کا ان کے اوپر نیچے سے امتیازی سلوک کے ذریعہ حکم دیا جاتا ہے۔
///
/// ## لغو گرافیکل موازنہ
///
/// لغو گرافیکل موازنہ مندرجہ ذیل خصوصیات کے ساتھ ایک کاروائی ہے۔
///  - عنصر کے ذریعہ دو تسلسل کا موازنہ کیا جاتا ہے۔
///  - پہلا مطابقت پذیر عنصر اس بات کی وضاحت کرتا ہے کہ کون سا تسلسل لغت کے لحاظ سے دوسرے سے کم یا زیادہ ہے۔
///  - اگر ایک تسلسل دوسرے کا ایک سابقہ ہے تو ، مختصر تسلسل دوسرے کے مقابلے میں لغت کے لحاظ سے کم ہے۔
///  - اگر دو تسلسل میں مساوی عنصر ہوں اور ایک ہی لمبائی کے ہوں ، تو یہ ترتیب علامات کے لحاظ سے برابر ہیں۔
///  - خالی ترتیب کسی خالی ترتیب کے مقابلے میں لغت کے لحاظ سے کم ہے۔
///  - دو خالی ترتیب علامات کے برابر ہیں۔
///
/// ## میں `Ord` کو کس طرح نافذ کرسکتا ہوں؟
///
/// `Ord` اس کی ضرورت ہوتی ہے کہ قسم بھی [`PartialOrd`] اور [`Eq`] (جس کیلئے [`PartialEq`] کی ضرورت ہو) ہو۔
///
/// پھر آپ کو [`cmp`] کے لئے عمل درآمد کی وضاحت کرنی ہوگی۔آپ کو اپنی نوعیت کے کھیتوں میں [`cmp`] استعمال کرنا مفید ہوسکتا ہے۔
///
/// [`PartialEq`] ، [`PartialOrd`] ، اور `Ord`*کے نفاذ کو* ایک دوسرے کے ساتھ متفق ہونا ضروری ہے۔
/// یعنی ، `a.cmp(b) == Ordering::Equal` اگر اور صرف `a == b` اور `Some(a.cmp(b)) == a.partial_cmp(b)` تمام `a` اور `b` کیلئے۔
/// traits میں سے کچھ اخذ کرکے اور دوسروں کو دستی طور پر لاگو کرکے اتفاقی طور پر ان سے اتفاق رائے پیدا کرنا آسان ہے۔
///
/// یہاں ایک مثال ہے جہاں آپ لوگوں کو صرف اونچائی کے لحاظ سے ترتیب دینا چاہتے ہیں ، `id` اور `name` کو نظر انداز کرتے ہوئے:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// یہ طریقہ `self` اور `other` کے درمیان [`Ordering`] واپس کرتا ہے۔
    ///
    /// کنونشن کے ذریعہ ، `self.cmp(&other)` آرڈرنگ کو واپس کرتا ہے جو `self <operator> other` کے اظہار کے مطابق ہے اگر یہ سچ ہے تو۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// زیادہ سے زیادہ دو اقدار کا موازنہ اور واپسی
    ///
    /// دوسرا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// کم سے کم دو اقدار کا موازنہ اور واپسی
    ///
    /// پہلا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// کسی خاص وقفے تک قدر کو محدود رکھیں۔
    ///
    /// اگر `self` `max` سے زیادہ ہے تو `max` ، اور اگر `self` `min` سے کم ہے تو `max` لوٹاتا ہے۔
    /// بصورت دیگر یہ `self` لوٹاتا ہے۔
    ///
    /// # Panics
    ///
    /// Panics اگر `min > max` ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait ان اقدار کے لئے جن کا موازنہ ترتیب کے مطابق کیا جاسکتا ہے۔
///
/// X101 X ، `b` اور `c` کے لئے ، موازنہ کو پورا کرنا چاہئے:
///
/// - غیر متناسب: اگر `a < b` تو `!(a > b)` ، نیز `a > b` پر مشتمل `!(a < b)` lyingاور
/// - ٹرانزیکٹیٹی: `a < b` اور `b < c` کا مطلب `a < c` ہے۔`==` اور `>` دونوں کے ل The یکساں ہونا ضروری ہے۔
///
/// نوٹ کریں کہ ان تقاضوں کا مطلب یہ ہے کہ trait خود کو متوازی اور عبوری طور پر لاگو کیا جانا چاہئے: اگر `T: PartialOrd<U>` اور `U: PartialOrd<V>` تو `U: PartialOrd<T>` اور `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// یہ trait `#[derive]` کے ساتھ استعمال کیا جا سکتا ہے۔جب اسٹرکٹس کو ماخوذ کیا جاتا ہے ، تو یہ ڈھانچے کے ممبروں کے اوپر سے نیچے تک اعلامیہ آرڈر کی بنیاد پر ایک لاکسٹوگرافک آرڈرنگ تیار کرے گا۔
/// جب اناموں پر اخذ کیا جاتا ہے تو ، مختلف حالتوں کا ان کے اوپر نیچے سے امتیازی سلوک کے ذریعہ حکم دیا جاتا ہے۔
///
/// ## میں `PartialOrd` کو کس طرح نافذ کرسکتا ہوں؟
///
/// `PartialOrd` صرف [`partial_cmp`] طریقہ پر عمل درآمد کرنا ہوتا ہے ، دوسرے کے ساتھ طے شدہ نفاذ سے پیدا ہوتا ہے۔
///
/// تاہم ، یہ ممکن ہے کہ ان اقسام کے ل separately دوسروں کو الگ سے نافذ کیا جاسکیں جن کی مکمل ترتیب نہیں ہے۔
/// مثال کے طور پر ، فلوٹنگ پوائنٹ نمبر کے لئے ، `NaN < 0 == false` اور `NaN >= 0 == false` (cf.
/// آئی ای ای ای 754-2008 سیکشن ایکس00 ایکس)۔
///
/// `PartialOrd` آپ کی قسم [`PartialEq`] ہونے کی ضرورت ہے۔
///
/// [`PartialEq`] ، `PartialOrd` ، اور [`Ord`]*کے نفاذ کو* ایک دوسرے کے ساتھ متفق ہونا ضروری ہے۔
/// traits میں سے کچھ اخذ کرکے اور دوسروں کو دستی طور پر لاگو کرکے اتفاقی طور پر ان سے اتفاق رائے پیدا کرنا آسان ہے۔
///
/// اگر آپ کی قسم [`Ord`] ہے تو ، آپ [`cmp`] استعمال کرکے [`partial_cmp`] لاگو کرسکتے ہیں:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// آپ اپنی قسم کے کھیتوں میں [`partial_cmp`] استعمال کرنا بھی مفید محسوس کرسکتے ہیں۔
/// یہاں `Person` اقسام کی ایک مثال ہے جس کے پاس فلوٹنگ پوائنٹ `height` فیلڈ ہے جو ترتیب دینے کے لئے استعمال ہونے والا واحد فیلڈ ہے۔
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// یہ طریقہ `self` اور `other` اقدار کے درمیان آرڈر واپس کرتا ہے اگر کوئی موجود ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// جب موازنہ ناممکن ہے:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// یہ طریقہ (`self` اور `other` کے لئے) سے کم کی جانچ کرتا ہے اور `<` آپریٹر کے ذریعہ استعمال ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// یہ طریقہ (`self` اور `other` کیلئے) سے کم یا مساوی ٹیسٹ کرتا ہے اور `<=` آپریٹر کے ذریعہ استعمال ہوتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// یہ طریقہ (`self` اور `other` کے لئے) سے زیادہ کی جانچ کرتا ہے اور `>` آپریٹر کے ذریعہ استعمال ہوتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// یہ طریقہ (`self` اور `other` کیلئے) سے زیادہ یا اس کے مساوی ٹیسٹ کرتا ہے اور `>=` آپریٹر کے ذریعہ استعمال ہوتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// کم سے کم دو اقدار کا موازنہ اور واپسی
///
/// پہلا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
///
/// اندرونی طور پر ایک عرف کا استعمال [`Ord::min`] کرنا ہے۔
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// موازنہ تقریب کے حوالے سے کم سے کم دو اقدار کی واپسی کرتا ہے۔
///
/// پہلا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// عنصر کو لوٹاتا ہے جو مخصوص فنکشن سے کم سے کم قیمت دیتا ہے۔
///
/// پہلا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// زیادہ سے زیادہ دو اقدار کا موازنہ اور واپسی
///
/// دوسرا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
///
/// اندرونی طور پر ایک عرف کا استعمال [`Ord::max`] کرنا ہے۔
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// موازنہ فعل کے حوالے سے زیادہ سے زیادہ دو اقدار لوٹاتا ہے۔
///
/// دوسرا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// عنصر کو لوٹاتا ہے جو مخصوص فنکشن سے زیادہ سے زیادہ قیمت دیتا ہے۔
///
/// دوسرا دلیل لوٹاتا ہے اگر موازنہ ان کے مساوی ہونے کا تعین کرتا ہے۔
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// ابتدائی اقسام کے لئے جزویقم ، ایکق ، جزوی آرڈ اور آرڈ کا نفاذ
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // زیادہ سے زیادہ اسمبلی پیدا کرنے کے لئے یہاں آرڈر ضروری ہے۔
                    // مزید معلومات کے لئے <https://github.com/rust-lang/rust/issues/63758> دیکھیں۔
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // آئی 8 کو ڈالنا اور فرق کو آرڈر میں تبدیل کرنا زیادہ سے زیادہ اسمبلی پیدا کرتا ہے۔
            //
            // مزید معلومات کے لئے <https://github.com/rust-lang/rust/issues/66780> دیکھیں۔
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // محفوظ کریں: bool جیسا کہ i8 0 یا 1 کی واپسی کرتا ہے ، لہذا فرق کچھ اور نہیں ہوسکتا ہے
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &پوائنٹرز

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}