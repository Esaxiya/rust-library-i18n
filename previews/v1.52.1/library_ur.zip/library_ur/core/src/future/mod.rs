#![stable(feature = "futures_api", since = "1.36.0")]

//! غیر متوازن اقدار۔

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// اس قسم کی ضرورت ہے کیونکہ:
///
/// a) جنریٹر `for<'a, 'b> Generator<&'a mut Context<'b>>` لاگو نہیں کرسکتے ہیں ، لہذا ہمیں خام پوائنٹر (<https://github.com/rust-lang/rust/issues/68923> دیکھیں) کو منتقل کرنے کی ضرورت ہے۔
///
/// b) را پوائنٹر اور `NonNull` X 2 X یا `Sync` نہیں ہیں ، تاکہ یہ ہر future non-Send/Sync کو بھی بنائے ، اور ہم یہ نہیں چاہتے ہیں۔
///
/// یہ `.await` کے HIR کو کم کرنے کو بھی آسان بناتا ہے۔
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// future میں ایک جنریٹر لپیٹ دیں۔
///
/// یہ فنکشن نیچے ایک `GenFuture` لوٹاتا ہے ، لیکن بہتر خامی پیغامات دینے کے لئے اسے `impl Trait` میں چھپا دیتا ہے (`GenFuture<[closure.....]>` کے بجائے `GenFuture`)۔
///
// `const async fn` سے بازیافت ہونے کے بعد اضافی غلطیوں سے بچنے کے لئے یہ `const` ہے
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // ہم اس حقیقت پر انحصار کرتے ہیں کہ async/await futures بنیادی جنریٹر میں خود حوالہ قرض لینے کے ل create عدم استحکام کا شکار ہے۔
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // محفوظ: محفوظ ہے کیونکہ ہم !Unpin + !Drop ہیں ، اور یہ صرف ایک فیلڈ پروجیکشن ہے۔
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context` کو `NonNull` خام پوائنٹر میں تبدیل کرتے ہوئے ، جنریٹر کو دوبارہ شروع کریں۔
            // `.await` کم کرنے سے یہ محفوظ طور پر ایک `&mut Context` پر ڈال دیا جائے گا۔
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // محفوظ: کال کرنے والے کو اس بات کی ضمانت دینا ہوگی کہ `cx.0` ایک درست پوائنٹر ہے
    // جو ایک تغیر پزیر حوالہ کی تمام ضروریات کو پورا کرتا ہے۔
    unsafe { &mut *cx.0.as_ptr().cast() }
}