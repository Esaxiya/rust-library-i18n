use crate::future::Future;

/// ایک `Future` میں تبدیلی۔
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future تکمیل ہونے پر آؤٹ پٹ تیار کرے گا۔
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// ہم اسے کس قسم کا زیڈ فیوچر0 زیڈ میں تبدیل کررہے ہیں؟
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// کسی قدر سے زیڈ فیوچر0 زیڈ تیار کرتا ہے۔
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}