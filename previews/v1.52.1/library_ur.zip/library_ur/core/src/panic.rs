//! Panic معیاری لائبریری میں معاونت۔

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic کے بارے میں معلومات فراہم کرنے والا ایک ڈھانچہ۔
///
/// `PanicInfo` ڈھانچے کو ایک panic hook پر منتقل کیا گیا ہے جو [`set_hook`] فنکشن کے ذریعہ مرتب کیا گیا ہے۔
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic کے ساتھ وابستہ پے لوڈ کو لوٹاتا ہے۔
    ///
    /// یہ عام طور پر ، لیکن ہمیشہ نہیں ، `&'static str` یا [`String`] ہوگا۔
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// اگر `core` crate (`std` سے نہیں) کا `panic!` میکرو فارمیٹنگ سٹرنگ اور کچھ اضافی دلائل کے ساتھ استعمال کیا گیا تھا تو ، وہ پیغام موصول کرتا ہے مثال کے طور پر [`fmt::write`] کے ساتھ استعمال کرنے کے لئے
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// اگر دستیاب ہو تو ، اس جگہ کے بارے میں معلومات لوٹاتا ہے جہاں سے panic شروع ہوا تھا۔
    ///
    /// یہ طریقہ فی الحال ہمیشہ [`Some`] کو لوٹائے گا ، لیکن یہ future ورژن میں تبدیل ہوسکتا ہے۔
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: اگر اسے تبدیل کیا جاتا ہے تو کبھی کبھی واپس نہیں ہوتا ہے ،
        // std::panicking::default_hook اور std::panicking::begin_panic_fmt میں اس معاملے سے نمٹیں۔
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ہم ڈاؤن لوڈ_کا_ استعمال نہیں کرسکتے: <String>() یہاں
        // چونکہ سٹرنگ لیبکور میں دستیاب نہیں ہے!
        // پے لوڈ ایک سٹرنگ ہے جب متعدد دلائل کے ساتھ `std::panic!` بلایا جاتا ہے ، لیکن اس صورت میں یہ پیغام بھی دستیاب ہوتا ہے۔
        //

        self.location.fmt(formatter)
    }
}

/// panic کے مقام کے بارے میں معلومات پر مشتمل ایک ڈھانچہ۔
///
/// یہ ڈھانچہ [`PanicInfo::location()`] کے ذریعہ تشکیل دیا گیا ہے۔
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// مساوات اور ترتیب دینے کے لئے موازنہ فائل ، لائن ، پھر کالم ترجیح میں کیا جاتا ہے۔
/// فائلوں کا موازنہ `Path` کی بجائے ، تار کے طور پر کیا جاتا ہے ، جو غیر متوقع طور پر ہوسکتا ہے۔
/// مزید گفتگو کیلئے [`مقام: : فائل`] کی دستاویزات دیکھیں۔
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// اس فنکشن کے کالر کا ماخذ مقام لوٹاتا ہے۔
    /// اگر اس فنکشن کا کالر تشریح کیا جاتا ہے تو پھر اس کی کال لوکیشن واپس کردی جائے گی ، اور اسی طرح غیر ٹریک شدہ فنکشن باڈی میں پہلی کال پر اسٹیک اپ رکھنا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] لوٹاتا ہے جس پر یہ کہا جاتا ہے۔
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// اس فنکشن کی تعریف میں سے [`Location`] لوٹاتا ہے۔
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // کسی دوسرے مقام پر بغیر اسی رکھے ہوئے فنکشن کو چلانے سے ہمیں وہی نتیجہ ملتا ہے
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ٹریک کردہ فنکشن کو مختلف مقام پر چلانے سے ایک مختلف قدر ملتی ہے
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// سورس فائل کا نام لوٹاتا ہے جہاں سے panic شروع ہوا تھا۔
    ///
    /// # `&str`, `&Path` نہیں
    ///
    /// لوٹا ہوا نام سے مرتب کرنے والے سسٹم کے ذریعہ کا راستہ ہوتا ہے ، لیکن اس کی نمائندگی `&Path` کے طور پر درست نہیں ہے۔
    /// مرتب شدہ کوڈ ایک مختلف سسٹم پر چل سکتا ہے جس میں مندرجات فراہم کرنے والے نظام سے مختلف `Path` نفاذ ہے اور اس لائبریری میں فی الحال مختلف "host path" نوعیت نہیں ہے۔
    ///
    /// سب سے حیرت انگیز سلوک اس وقت ہوتا ہے جب "the same" فائل ماڈیول سسٹم میں متعدد راستوں (عام طور پر `#[path = "..."]` وصف یا اسی طرح کا استعمال کرتے ہوئے) کے ذریعے قابل رسا ہوجاتی ہے ، جو اس فعل سے مختلف اقدار کو واپس کرنے کے لئے ایک جیسے کوڈ کے ظاہر ہونے کا سبب بن سکتی ہے۔
    ///
    ///
    /// # Cross-compilation
    ///
    /// جب یہ میزبان پلیٹ فارم اور ہدف کے پلیٹ فارم میں فرق ہے تو یہ قدر `Path::new` یا اسی طرح کے تعمیر کنندگان کو منتقل کرنے کے لئے موزوں نہیں ہے۔
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// وہ لائن نمبر واپس کرتا ہے جہاں سے panic شروع ہوا تھا۔
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// وہ کالم واپس کرتا ہے جہاں سے panic کا آغاز ہوا تھا۔
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// libstd سے `panic_unwind` اور دیگر panic رن ٹائم پر ڈیٹا منتقل کرنے کے لئے libstd کے ذریعہ استعمال کردہ ایک اندرونی trait۔
/// جلد ہی کسی بھی وقت مستحکم ہونے کا ارادہ نہیں ، استعمال نہ کریں۔
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// مندرجات کی مکمل ملکیت لیں۔
    /// واپسی کی قسم دراصل `Box<dyn Any + Send>` ہے ، لیکن ہم لیبکور میں `Box` استعمال نہیں کرسکتے ہیں۔
    ///
    /// اس طریقہ کار کے پکارنے کے بعد ، `self` میں صرف کچھ ڈمی ڈیفالٹ ویلیو باقی ہے۔
    /// اس طریقے کو دو بار کال کرنا ، یا اس طریقہ کو کال کرنے کے بعد `get` پر کال کرنا ، ایک غلطی ہے۔
    ///
    /// دلیل ادھار لی گئی ہے کیونکہ panic رن ٹائم (`__rust_start_panic`) صرف ایک ادھار `dyn BoxMeUp` حاصل کرتا ہے۔
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// بس مشمولات ادھار لیں۔
    fn get(&mut self) -> &(dyn Any + Send);
}