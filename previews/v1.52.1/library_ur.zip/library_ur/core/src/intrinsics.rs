//! کمپائلر انٹرنس۔
//!
//! متعلقہ تعریفیں `compiler/rustc_codegen_llvm/src/intrinsic.rs` میں ہیں۔
//! اس سے متعلقہ تطبیق `compiler/rustc_mir/src/interpret/intrinsics.rs` میں ہیں
//!
//! # سازوسامان
//!
//! Note: انٹرنکسکس کی استحکام میں ہونے والی کسی بھی تبدیلی سے زبان کی ٹیم کے ساتھ تبادلہ خیال کیا جانا چاہئے۔
//! اس میں استحکام میں استحکام شامل ہیں۔
//!
//! مرتب وقت پر اندرونی استعمال کے قابل بنانے کے ل one ، کسی کو <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> سے `compiler/rustc_mir/src/interpret/intrinsics.rs` پر عمل درآمد کی کاپی کرنے اور `#[rustc_const_unstable(feature = "foo", issue = "01234")]` کو اندرونی میں شامل کرنے کی ضرورت ہے۔
//!
//!
//! اگر سمجھا جاتا ہے کہ `const fn` سے `rustc_const_stable` وصف کے ساتھ کوئی انٹرنسک استعمال کیا جائے تو ، اندرونی خصوصیت بھی `rustc_const_stable` ہونی چاہئے۔
//! اس طرح کی تبدیلی کو ٹی لینگ مشاورت کے بغیر نہیں کیا جانا چاہئے ، کیونکہ یہ زبان میں ایسی خصوصیت بناتا ہے جس کو صارف کے کوڈ میں مرتب کی حمایت کے بغیر نقل نہیں کیا جاسکتا۔
//!
//! # Volatiles
//!
//! غیر مستحکم انٹرنکس I/O میموری پر عمل کرنے کا ارادہ رکھتے ہیں ، جن کی ضمانت ہے کہ کمپلر کے ذریعہ دیگر غیر مستحکم انٹرنکس کو دوبارہ ترتیب دینے کی ضمانت نہیں ہے۔[[volatile]] پر LLVM دستاویزات دیکھیں۔
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! جوہری اندرونی مشین کے الفاظ پر عام جوہری کارروائی فراہم کرتے ہیں ، جس میں متعدد ممکن میموری ترتیب ہوتے ہیں۔وہ اسی الفاظ کی تعمیل کرتے ہیں جیسے C++ 11۔[[atomics]] پر LLVM دستاویزات دیکھیں۔
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! میموری آرڈر پر ایک فوری ریفریشر:
//!
//! * تالا حاصل کرنے میں رکاوٹ حاصل کریں۔بعد میں پڑھنے لکھنے رکاوٹ کے بعد ہوتا ہے۔
//! * رہائی ، ایک تالا جاری کرنے میں رکاوٹ۔رکاوٹ سے پہلے پڑھنا لکھنے سے پہلے کی جگہ۔
//! * ترتیب مطابق ، تسلسل کے ساتھ مستقل کاروائیوں کی ترتیب میں ہونے کی ضمانت ہے۔یہ جوہری اقسام کے ساتھ کام کرنے کے لئے معیاری وضع ہے اور Java کے `volatile` کے برابر ہے۔
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// یہ درآمدات انٹرا ڈاک لنکس کو آسان بنانے کے لئے استعمال کی جاتی ہیں
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // محفوظ کریں: دیکھیں `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB ، یہ انٹرینکس خام پوائنٹر لیتے ہیں کیونکہ وہ ایلیسائزڈ میموری کو تبدیل کرتے ہیں ، جو `&` یا `&mut` میں سے کسی کے لئے بھی درست نہیں ہے۔
    //

    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] ایکس طریقوں کے ذریعے X0X ایکس طریقوں کے ذریعے [`Ordering::SeqCst`] اور `failure` دونوں پیرامیٹرز کے طور پر دستیاب ہے۔
    ///
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] ایکس طریقوں کے ذریعے X0X ایکس طریقوں کے ذریعے [`Ordering::Acquire`] اور `failure` دونوں پیرامیٹرز کے طور پر دستیاب ہے۔
    ///
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::Release`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::Release`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::AcqRel`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::AcqRel`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] ایکس طریقوں کے ذریعے X0X ایکس طریقوں کے ذریعے [`Ordering::Relaxed`] اور `failure` دونوں پیرامیٹرز کے طور پر دستیاب ہے۔
    ///
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::SeqCst`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::SeqCst`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::SeqCst`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::SeqCst`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::Acquire`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::Acquire`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::AcqRel`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::AcqRel`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] ایکس طریقوں کے ذریعے X0X ایکس طریقوں کے ذریعے [`Ordering::SeqCst`] اور `failure` دونوں پیرامیٹرز کے طور پر دستیاب ہے۔
    ///
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] ایکس طریقوں کے ذریعے X0X ایکس طریقوں کے ذریعے [`Ordering::Acquire`] اور `failure` دونوں پیرامیٹرز کے طور پر دستیاب ہے۔
    ///
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::Release`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::Release`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange_weak` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::AcqRel`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::AcqRel`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange_weak` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] ایکس طریقوں کے ذریعے X0X ایکس طریقوں کے ذریعے [`Ordering::Relaxed`] اور `failure` دونوں پیرامیٹرز کے طور پر دستیاب ہے۔
    ///
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::SeqCst`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::SeqCst`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange_weak` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::SeqCst`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::SeqCst`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange_weak` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::Acquire`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::Acquire`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange_weak` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر موجودہ قیمت `old` ویلیو جیسا ہے تو کوئی قیمت اسٹور کرتا ہے۔
    ///
    /// [`Ordering::AcqRel`] کو `success` اور `failure` پیرامیٹرز کے بطور [`Ordering::AcqRel`] گزر کر اس انٹرنس کا مستحکم ورژن [`atomic`] اقسام پر `compare_exchange_weak` طریقہ کار کے ذریعہ دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// پوائنٹر کی موجودہ قیمت لوڈ کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `load` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// پوائنٹر کی موجودہ قیمت لوڈ کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `load` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// پوائنٹر کی موجودہ قیمت لوڈ کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `load` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// مخصوص میموری کے مقام پر قیمت ذخیرہ کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `store` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// مخصوص میموری کے مقام پر قیمت ذخیرہ کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `store` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// مخصوص میموری کے مقام پر قیمت ذخیرہ کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `store` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// پرانی میموری کو لوٹاتے ہوئے ، قیمت کو مخصوص میموری والے مقام پر اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `swap` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// پرانی میموری کو لوٹاتے ہوئے ، قیمت کو مخصوص میموری والے مقام پر اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `swap` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// پرانی میموری کو لوٹاتے ہوئے ، قیمت کو مخصوص میموری والے مقام پر اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `swap` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// پرانی میموری کو لوٹاتے ہوئے ، قیمت کو مخصوص میموری والے مقام پر اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `swap` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// پرانی میموری کو لوٹاتے ہوئے ، قیمت کو مخصوص میموری والے مقام پر اسٹور کرتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `swap` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجودہ قدر میں اضافہ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_add` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر میں اضافہ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_add` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر میں اضافہ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_add` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر میں اضافہ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_add` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر میں اضافہ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_add` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجودہ قیمت سے منہا کریں ، پچھلی قیمت کو لوٹائیں۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_sub` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت سے منہا کریں ، پچھلی قیمت کو لوٹائیں۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_sub` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت سے منہا کریں ، پچھلی قیمت کو لوٹائیں۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_sub` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت سے منہا کریں ، پچھلی قیمت کو لوٹائیں۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_sub` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت سے منہا کریں ، پچھلی قیمت کو لوٹائیں۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_sub` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// بہرحال اور موجودہ قیمت کے ساتھ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_and` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// بہرحال اور موجودہ قیمت کے ساتھ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_and` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// بہرحال اور موجودہ قیمت کے ساتھ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_and` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بہرحال اور موجودہ قیمت کے ساتھ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_and` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بہرحال اور موجودہ قیمت کے ساتھ ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_and` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجودہ قیمت کے ساتھ بٹویژن نند ، پچھلی ویلیو کو لوٹاتے ہوئے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`AtomicBool`] قسم پر `fetch_nand` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت کے ساتھ بٹویژن نند ، پچھلی ویلیو کو لوٹاتے ہوئے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`AtomicBool`] قسم پر `fetch_nand` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت کے ساتھ بٹویژن نند ، پچھلی ویلیو کو لوٹاتے ہوئے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`AtomicBool`] قسم پر `fetch_nand` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت کے ساتھ بٹویژن نند ، پچھلی ویلیو کو لوٹاتے ہوئے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`AtomicBool`] قسم پر `fetch_nand` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قیمت کے ساتھ بٹویژن نند ، پچھلی ویلیو کو لوٹاتے ہوئے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`AtomicBool`] قسم پر `fetch_nand` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// بٹ وائز یا موجودہ قیمت کے ساتھ ، پچھلی ویلیو کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_or` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// بٹ وائز یا موجودہ قیمت کے ساتھ ، پچھلی ویلیو کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_or` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// بٹ وائز یا موجودہ قیمت کے ساتھ ، پچھلی ویلیو کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_or` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بٹ وائز یا موجودہ قیمت کے ساتھ ، پچھلی ویلیو کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_or` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بٹ وائز یا موجودہ قیمت کے ساتھ ، پچھلی ویلیو کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_or` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجودہ قدر کے ساتھ بٹ وائی زور ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_xor` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر کے ساتھ بٹ وائی زور ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_xor` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر کے ساتھ بٹ وائی زور ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_xor` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر کے ساتھ بٹ وائی زور ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_xor` طریقہ کے ذریعہ [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر کے ساتھ بٹ وائی زور ، پچھلی قیمت کو لوٹانا۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] اقسام پر `fetch_xor` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کر کے دستیاب ہے۔
    /// مثال کے طور پر، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعہ [`Ordering::SeqCst`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعہ [`Ordering::Acquire`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعہ [`Ordering::Release`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعہ [`Ordering::AcqRel`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجودہ قدر کے ساتھ زیادہ سے زیادہ
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعہ [`Ordering::Relaxed`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ کم از کم۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعہ [`Ordering::SeqCst`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ کم از کم۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعہ [`Ordering::Acquire`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ کم از کم۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعہ [`Ordering::Release`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ کم از کم۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعہ [`Ordering::AcqRel`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// دستخط شدہ موازنہ کا استعمال کرتے ہوئے موجودہ قدر کے ساتھ کم از کم۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعہ [`Ordering::Relaxed`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// بغیر دستخط شدہ موازنہ استعمال کرکے کم از کم موجودہ قدر کے ساتھ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے کم از کم موجودہ قدر کے ساتھ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ انٹیجر اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے کم از کم موجودہ قدر کے ساتھ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے کم از کم موجودہ قدر کے ساتھ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے کم از کم موجودہ قدر کے ساتھ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_min` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// بغیر دستخط شدہ موازنہ استعمال کرکے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعے [`Ordering::SeqCst`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعے [`Ordering::Acquire`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعے [`Ordering::Release`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعے [`Ordering::AcqRel`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بغیر دستخط شدہ موازنہ استعمال کرکے موجودہ قدر کے ساتھ زیادہ سے زیادہ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic`] دستخط شدہ عددی اقسام پر دستیاب ہے `fetch_max` طریقہ کے ذریعے [`Ordering::Relaxed`] کو `order` بطور پاس کرکے۔
    /// مثال کے طور پر، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` انٹرنسک کوڈ جنریٹر کے لئے اشارہ ہے اگر سپورٹ ہو تو پریفیکچ انسٹرکشن داخل کریں۔بصورت دیگر ، یہ کوئی آپٹ نہیں ہے۔
    /// پریفیچس کا پروگرام کے طرز عمل پر کوئی اثر نہیں ہوتا ہے لیکن وہ اس کی کارکردگی کی خصوصیات کو تبدیل کرسکتا ہے۔
    ///
    /// `locality` دلیل مستقل عدد ہونا ضروری ہے اور (0) سے لے کر (3) تک انتہائی محل وقوع کا مقام ہے ، انتہائی محل وقوع میں رکھنا ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` انٹرنسک کوڈ جنریٹر کے لئے اشارہ ہے اگر سپورٹ ہو تو پریفیکچ انسٹرکشن داخل کریں۔بصورت دیگر ، یہ کوئی آپٹ نہیں ہے۔
    /// پریفیچس کا پروگرام کے طرز عمل پر کوئی اثر نہیں ہوتا ہے لیکن وہ اس کی کارکردگی کی خصوصیات کو تبدیل کرسکتا ہے۔
    ///
    /// `locality` دلیل مستقل عدد ہونا ضروری ہے اور (0) سے لے کر (3) تک انتہائی محل وقوع کا مقام ہے ، انتہائی محل وقوع میں رکھنا ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` انٹرنسک کوڈ جنریٹر کے لئے اشارہ ہے اگر سپورٹ ہو تو پریفیکچ انسٹرکشن داخل کریں۔بصورت دیگر ، یہ کوئی آپٹ نہیں ہے۔
    /// پریفیچس کا پروگرام کے طرز عمل پر کوئی اثر نہیں ہوتا ہے لیکن وہ اس کی کارکردگی کی خصوصیات کو تبدیل کرسکتا ہے۔
    ///
    /// `locality` دلیل مستقل عدد ہونا ضروری ہے اور (0) سے لے کر (3) تک انتہائی محل وقوع کا مقام ہے ، انتہائی محل وقوع میں رکھنا ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` انٹرنسک کوڈ جنریٹر کے لئے اشارہ ہے اگر سپورٹ ہو تو پریفیکچ انسٹرکشن داخل کریں۔بصورت دیگر ، یہ کوئی آپٹ نہیں ہے۔
    /// پریفیچس کا پروگرام کے طرز عمل پر کوئی اثر نہیں ہوتا ہے لیکن وہ اس کی کارکردگی کی خصوصیات کو تبدیل کرسکتا ہے۔
    ///
    /// `locality` دلیل مستقل عدد ہونا ضروری ہے اور (0) سے لے کر (3) تک انتہائی محل وقوع کا مقام ہے ، انتہائی محل وقوع میں رکھنا ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// ایک ایٹم باڑ
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::fence`] میں [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    pub fn atomic_fence();
    /// ایک ایٹم باڑ
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::fence`] میں [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    pub fn atomic_fence_acq();
    /// ایک ایٹم باڑ
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::fence`] میں [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    pub fn atomic_fence_rel();
    /// ایک ایٹم باڑ
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::fence`] میں [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// صرف ایک مرتب میموری میموری۔
    ///
    /// مرتب کرنے والے کے ذریعہ یادداشت تک رسائی کبھی بھی رکاوٹ نہیں بنے گی ، لیکن اس کے لئے کوئی ہدایات خارج نہیں کی جائیں گی۔
    /// یہ اسی تھریڈ پر کارروائیوں کے لئے موزوں ہے جو پہلے سے بڑھا ہوا ہوسکتا ہے ، جیسے سگنل ہینڈلرز کے ساتھ بات چیت کرتے وقت۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::compiler_fence`] میں [`Ordering::SeqCst`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// صرف ایک مرتب میموری میموری۔
    ///
    /// مرتب کرنے والے کے ذریعہ یادداشت تک رسائی کبھی بھی رکاوٹ نہیں بنے گی ، لیکن اس کے لئے کوئی ہدایات خارج نہیں کی جائیں گی۔
    /// یہ اسی تھریڈ پر کارروائیوں کے لئے موزوں ہے جو پہلے سے بڑھا ہوا ہوسکتا ہے ، جیسے سگنل ہینڈلرز کے ساتھ بات چیت کرتے وقت۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::compiler_fence`] میں [`Ordering::Acquire`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// صرف ایک مرتب میموری میموری۔
    ///
    /// مرتب کرنے والے کے ذریعہ یادداشت تک رسائی کبھی بھی رکاوٹ نہیں بنے گی ، لیکن اس کے لئے کوئی ہدایات خارج نہیں کی جائیں گی۔
    /// یہ اسی تھریڈ پر کارروائیوں کے لئے موزوں ہے جو پہلے سے بڑھا ہوا ہوسکتا ہے ، جیسے سگنل ہینڈلرز کے ساتھ بات چیت کرتے وقت۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::compiler_fence`] میں [`Ordering::Release`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// صرف ایک مرتب میموری میموری۔
    ///
    /// مرتب کرنے والے کے ذریعہ یادداشت تک رسائی کبھی بھی رکاوٹ نہیں بنے گی ، لیکن اس کے لئے کوئی ہدایات خارج نہیں کی جائیں گی۔
    /// یہ اسی تھریڈ پر کارروائیوں کے لئے موزوں ہے جو پہلے سے بڑھا ہوا ہوسکتا ہے ، جیسے سگنل ہینڈلرز کے ساتھ بات چیت کرتے وقت۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`atomic::compiler_fence`] میں [`Ordering::AcqRel`] کو `order` بطور پاس کر کے دستیاب ہے۔
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// جادو کا اندرونی جو فعل سے وابستہ صفات سے اس کے معنی اخذ کرتا ہے۔
    ///
    /// مثال کے طور پر ، ڈیٹا فلو اس کا استعمال جامد دعووں کو انجیکشن کرنے کے ل. کرتا ہے تاکہ `rustc_peek(potentially_uninitialized)` واقعی اس بات کی دوبارہ جانچ کرے کہ ڈیٹا فلو نے واقعی اس بات کی گنجائش کی ہے کہ کنٹرول فلو کے اس مقام پر اسے غیر منطقی شکل دی گئی ہے۔
    ///
    ///
    /// یہ اندرونی مرتب کرنے والے کے باہر استعمال نہیں ہونا چاہئے۔
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// عمل پر عملدرآمد کو روکتا ہے۔
    ///
    /// اس آپریشن کا ایک زیادہ صارف دوست اور مستحکم ورژن [`std::process::abort`](../../std/process/fn.abort.html) ہے۔
    ///
    pub fn abort() -> !;

    /// آپٹیمائزر کو مطلع کیا کہ کوڈ میں یہ نقطہ قابل رسائ نہیں ہے ، مزید اصلاحات کو چالو کرتا ہے۔
    ///
    /// NB ، یہ `unreachable!()` میکرو سے بہت مختلف ہے: میکرو کے برخلاف ، جس کو panics پر عمل درآمد کرتے وقت ، اس فنکشن کے ساتھ کوڈ کوڈ تک پہنچنا *غیر وضاحتی سلوک* ہے۔
    ///
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) ہے۔
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// آپٹیمائزر کو مطلع کریں کہ ایک شرط ہمیشہ سچی ہوتی ہے۔
    /// اگر حالت غلط ہے تو ، طرز عمل کی وضاحت نہیں ہوگی۔
    ///
    /// اس اندرونی کے لئے کوئی کوڈ تیار نہیں کیا گیا ہے ، لیکن اصلاح کنندہ اس (اور اس کی حالت) کو پاس کے درمیان محفوظ رکھنے کی کوشش کرے گا ، جو آس پاس کے کوڈ کی اصلاح میں مداخلت کرسکتا ہے اور کارکردگی کو کم کرسکتا ہے۔
    /// اس کا استعمال نہیں کیا جانا چاہئے اگر ناگوار کو خود ہی اصلاح کنندہ کے ذریعہ دریافت کیا جاسکتا ہے ، یا اگر یہ کوئی قابل قدر اصلاح نہیں کرتا ہے۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// مرتب کو اشارے کہ branch حالت ممکنہ طور پر درست ہے۔
    /// اس کو دی گئی قیمت لوٹاتا ہے۔
    ///
    /// `if` بیانات کے علاوہ کسی بھی استعمال کا شاید اثر نہیں پڑے گا۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// مرتب کرنے والے کو اشارے کہ branch حالت غلط ہونے کا امکان ہے۔
    /// اس کو دی گئی قیمت لوٹاتا ہے۔
    ///
    /// `if` بیانات کے علاوہ کسی بھی استعمال کا شاید اثر نہیں پڑے گا۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// ڈیبگر کے ذریعہ معائنے کے ل a ، بریک پوائنٹ ٹریپ پر عمل درآمد کرتا ہے۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn breakpoint();

    /// بائٹس میں ایک قسم کا سائز۔
    ///
    /// خاص طور پر یہ ، اسی طرح کی یکے بعد دیگرے آئٹمز کے مابین بائٹس میں آفسیٹ ہوتا ہے ، جس میں سیدھ میں بھرنے شامل ہیں۔
    ///
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::mem::size_of`](crate::mem::size_of) ہے۔
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// کسی قسم کی کم از کم سیدھ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::mem::align_of`](crate::mem::align_of) ہے۔
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// ایک قسم کی ترجیحی سیدھ۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// بائٹس میں حوالہ جاتی قدر کا سائز۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`mem::size_of_val`] ہے۔
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// حوالہ کردہ قدر کی مطلوبہ سیدھ۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::mem::align_of_val`](crate::mem::align_of_val) ہے۔
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// ایک مستحکم سٹرنگ سلائس ملتی ہے جس میں ایک قسم کا نام ہوتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::any::type_name`](crate::any::type_name) ہے۔
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// ایک شناخت کنندہ ملتا ہے جو عالمی سطح پر مخصوص قسم سے منفرد ہے۔
    /// یہ فنکشن ایک ہی قسم کی قیمت کے ل return واپس آئے گا ، قطع نظر اس سے قطع نظر کہ جس میں crate اس میں شامل ہے۔
    ///
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::any::TypeId::of`](crate::any::TypeId::of) ہے۔
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// غیر محفوظ افعال کا محافظ جو `T` کو غیر آباد بنا ہوا ہے تو اسے کبھی بھی عمل میں نہیں لایا جاسکتا ہے۔
    /// یہ مستحکم یا تو panic کرے گا ، یا کچھ نہیں کرے گا۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// غیر محفوظ افعال کا نگہبان جو کبھی بھی عمل میں نہیں آسکتا اگر `T` صفر-ابتدا کی اجازت نہیں دیتا ہے: اس سے اعداد و شمار panic ، یا کچھ نہیں کریں گے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn assert_zero_valid<T>();

    /// غیر محفوظ افعال کا محافظ جس پر عمل درآمد نہیں کیا جاسکتا اگر `T` میں غلط بٹ پیٹرن ہوں تو: یہ panic یا تو کچھ بھی نہیں کرے گا۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn assert_uninit_valid<T>();

    /// ایک مستحکم `Location` کا حوالہ ملتا ہے جس میں یہ اشارہ کیا جاتا ہے کہ اسے کہاں بلایا گیا ہے۔
    ///
    /// اس کے بجائے [`core::panic::Location::caller`](crate::panic::Location::caller) استعمال کرنے پر غور کریں۔
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ڈراپ گلو کو چلائے بغیر کسی قدر کو دائرہ کار سے ہٹاتا ہے۔
    ///
    /// یہ صرف [`mem::forget_unsized`] کے لئے موجود ہے۔عام `forget` بجائے `ManuallyDrop` استعمال کرتا ہے۔
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// ایک قسم کی قدر کے بٹس کو دوسری قسم کی طرح سے تعبیر کرتا ہے۔
    ///
    /// دونوں اقسام میں ایک ہی سائز کا ہونا ضروری ہے۔
    /// اصل اور نہ ہی کوئی نتیجہ [invalid value](../../nomicon/what-unsafe-does.html) ہوسکتا ہے۔
    ///
    /// `transmute` ایک طرح کے تھوڑا سا دوسری طرف جانے کے مترادف ہے۔یہ منبع کی قیمت سے بٹس کو منزل کی قیمت میں کاپی کرتا ہے ، پھر اصل کو بھول جاتا ہے۔
    /// یہ `transmute_copy` کی طرح ہیڈ کے نیچے C کے `memcpy` کے برابر ہے۔
    ///
    /// چونکہ `transmute` ایک بائی ویلیو آپریشن ہے ، لہذا * خود منتقل کردہ اقدار کی سیدھ میں لانا کوئی تشویش نہیں ہے۔
    /// کسی بھی دوسرے فنکشن کی طرح ، مرتب کرنے والے نے پہلے ہی `T` اور `U` دونوں کو صحیح طریقے سے منسلک کرنے کو یقینی بنایا ہے۔
    /// تاہم ، جب اقدار کو *دوسری جگہ* منتقل کرنا * (جیسے پوائنٹر ، حوالہ جات ، خانوں…) ، فون کرنے والے کو نشاندہی کرنے والی اقدار کی مناسب سیدھ کو یقینی بنانا ہوتا ہے۔
    ///
    /// `transmute` **ناقابل یقین حد تک** غیر محفوظ ہے۔اس فنکشن کے ساتھ [undefined behavior][ub] پیدا کرنے کے بہت سارے طریقے ہیں۔`transmute` مطلق آخری سہارا ہونا چاہئے۔
    ///
    /// [nomicon](../../nomicon/transmutes.html) کے پاس اضافی دستاویزات ہیں۔
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// کچھ چیزیں ایسی ہیں جن کے لئے `transmute` واقعی مفید ہے۔
    ///
    /// فنکشن پوائنٹر میں کسی پوائنٹر کو تبدیل کرنا۔یہ مشینوں کے لئے *قابل* قابل نہیں ہے جہاں فنکشن پوائنٹرز اور ڈیٹا پوائنٹرز مختلف سائز کے ہوتے ہیں۔
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// زندگی بھر میں اضافہ ، یا ناگوار زندگی گزارنا۔یہ جدید ، انتہائی غیر محفوظ Rust ہے!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// مایوس نہ ہوں: `transmute` کے بہت سے استعمال دوسرے ذرائع سے حاصل کیے جاسکتے ہیں۔
    /// ذیل میں `transmute` کی عمومی ایپلی کیشنز ہیں جنہیں محفوظ تعمیرات کے ساتھ تبدیل کیا جاسکتا ہے۔
    ///
    /// خام bytes(`&[u8]`) کو `u32` ، `f64` ، وغیرہ میں تبدیل کرنا۔
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // اس کے بجائے `u32::from_ne_bytes` استعمال کریں
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // یا اختتام کو واضح کرنے کیلئے `u32::from_le_bytes` یا `u32::from_be_bytes` استعمال کریں
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// ایک پوائنٹر کو `usize` میں تبدیل کرنا:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // اس کے بجائے ایک `as` کاسٹ استعمال کریں
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` کو `&mut T` میں تبدیل کرنا:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // اس کے بجائے ایک بوربرو استعمال کریں
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` کو `&mut U` میں تبدیل کرنا:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // اب ، `as` اور دوبارہ متحرک ہو کر ، نوٹ کریں کہ `as` `as` کی زنجیر عبوری نہیں ہے
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` کو `&[u8]` میں تبدیل کرنا:
    ///
    /// ```
    /// // یہ کرنے کا یہ ایک اچھا طریقہ نہیں ہے۔
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // آپ `str::as_bytes` استعمال کرسکتے ہیں
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // یا ، صرف بائٹ ڈور استعمال کریں ، اگر آپ کے سٹرنگ پر لفظی کنٹرول ہے
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` کو `Vec<Option<&T>>` میں تبدیل کرنا۔
    ///
    /// کسی کنٹینر کے اندرونی قسم کے مندرجات کی ترسیل کے ل you ، آپ کو یہ یقینی بنانا ہوگا کہ کنٹینر کے کسی بھی حملہ آور کی خلاف ورزی نہ کی جائے۔
    /// `Vec` کے ل this ، اس کا مطلب یہ ہے کہ اندرونی اقسام کے سائز *اور سیدھ* دونوں کو میچ کرنا ہوگا۔
    /// دوسرے کنٹینرز قسم ، صف بندی ، یا حتی کہ `TypeId` پر بھی انحصار کرسکتے ہیں ، ایسی صورت میں کنٹینر حملہ آوروں کی خلاف ورزی کیے بغیر ٹرانسمیشن بالکل بھی ممکن نہیں ہوگی۔
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector کو کلون کریں کیونکہ ہم ان کو بعد میں دوبارہ استعمال کریں گے
    /// let v_clone = v_orig.clone();
    ///
    /// // ٹرانسمیٹ کا استعمال: یہ `Vec` کے غیر طے شدہ ڈیٹا لے آؤٹ پر انحصار کرتا ہے ، جو ایک برا خیال ہے اور یہ غیر متعین رویے کا سبب بن سکتا ہے۔
    /////
    /// // تاہم ، یہ کوئی کاپی نہیں ہے۔
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // یہ تجویز کردہ ، محفوظ راستہ ہے۔
    /// // یہ پورے vector کی کاپی کرتا ہے ، حالانکہ ، ایک نئی صف میں۔
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // یہ ڈیٹا لے آؤٹ پر بھروسہ کیے بغیر ، مناسب نان کاپی ، "transmuting" ایک `Vec` کا غیر محفوظ طریقہ ہے۔
    /// // `transmute` کو لفظی طور پر کال کرنے کے بجائے ، ہم ایک پوائنٹر کاسٹ انجام دیتے ہیں ، لیکن اصل اندرونی قسم (`&i32`) کو ایک نئے (`Option<&i32>`) میں تبدیل کرنے کے معاملے میں ، اس میں تمام ایک جیسے انتشارات ہیں۔
    /////
    /// // اوپر دی گئی معلومات کے علاوہ ، [`from_raw_parts`] دستاویزات سے بھی مشورہ کریں۔
    /////
    /// let v_from_raw = unsafe {
    ///     // درست کریں جب vec_into_raw_parts مستحکم ہو۔
    ///     // یقینی بنائیں کہ اصل vector کو گرایا نہیں گیا ہے۔
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` لاگو کرنا:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ایسا کرنے کے متعدد طریقے ہیں ، اور مندرجہ ذیل (transmute) راستے میں ایک سے زیادہ دشواری ہیں۔
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // پہلے: ٹرانسمیٹ محفوظ قسم نہیں ہے۔یہ سب چیک اور T ہے
    ///         // یو ایک ہی سائز کے ہیں۔
    ///         // دوسرا ، یہاں ، آپ کے پاس دو تبادلہ خیالات ایک ہی میموری کی طرف اشارہ کرتے ہیں۔
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // اس سے حفاظت سے متعلق مسائل سے نجات مل جاتی ہے۔`&mut *` صرف* آپ کو `&mut T` یا `*mut T` سے `&mut T` دے گا۔
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // تاہم ، آپ کے پاس ابھی بھی دو متغیر حوالہ جات موجود ہیں جو اسی میموری کی طرف اشارہ کرتے ہیں۔
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // معیاری لائبریری اس طرح کرتی ہے۔
    /// // اگر آپ کو کچھ ایسا کرنے کی ضرورت ہو تو یہ بہترین طریقہ ہے
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // اب اس میں ایک ہی میموری کی طرف اشارہ کرنے والے تین متغیر حوالہ جات ہیں۔`slice` ، قدیم ret.0 ، اور قدر ret.1۔
    ///         // `slice` `let ptr = ...` کے بعد کبھی استعمال نہیں ہوتا ہے ، اور لہذا کوئی بھی اسے "dead" کی طرح سلوک کرسکتا ہے ، اور اس وجہ سے ، آپ کے پاس صرف دو اصلی بدلنے والے ٹکڑے ہیں۔
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: اگرچہ یہ اندرونی کانسٹیج مستحکم بناتا ہے ، لیکن ہمارے پاس کانسٹیفن ایف این میں کچھ کسٹم کوڈ ہے
    // وہ چیک جو `const fn` کے اندر اس کے استعمال کو روکتے ہیں۔
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// اگر `T` کے طور پر دی گئی اصل قسم کو ڈراپ گلو کی ضرورت ہو تو `true` واپس کرتا ہے۔اگر `T` کے لئے فراہم کردہ اصل قسم نے `Copy` لاگو کیا تو `false` واپس کرتا ہے۔
    ///
    ///
    /// اگر اصل قسم میں نہ تو ڈراپ گلو کی ضرورت ہوتی ہے اور نہ ہی `Copy` لاگو ہوتا ہے ، تو اس فنکشن کی واپسی کی قیمت غیر متعینہ ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`mem::needs_drop`](crate::mem::needs_drop) ہے۔
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// پوائنٹر سے آفسیٹ کا حساب لگاتا ہے۔
    ///
    /// اس کو کسی انٹیجر کے طور پر لاگو کیا جاتا ہے تاکہ وہ کسی عدد کو تبدیل اور اس سے بدلا جا سکے ، کیوں کہ یہ تبادلہ علانیہ معلومات کو پھینک دے گا۔
    ///
    /// # Safety
    ///
    /// شروع کرنے اور نتیجہ دینے والا دونوں اشارہ یا تو حدود میں ہونا چاہئے یا مختص آبجیکٹ کے اختتام پر ایک بائٹ ہونا چاہئے۔
    /// اگر یا تو پوائنٹر حد سے باہر ہے یا ریاضی کا زیادہ فلو ہوتا ہے تو پھر لوٹی گئی قیمت کے کسی اور استعمال کے نتیجے میں غیر متعینہ سلوک ہوگا۔
    ///
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`pointer::offset`] ہے۔
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ممکنہ طور پر ریپنگ ، پوائنٹر سے آفسیٹ کا حساب لگاتا ہے۔
    ///
    /// اس کو کسی انٹیجر کے طور پر لاگو کیا جاتا ہے تاکہ وہ عدد میں تبدیل ہوجائے اور اس سے بدلا جا سکے ، کیونکہ تبادلوں سے کچھ اصلاحات کو روکتا ہے۔
    ///
    /// # Safety
    ///
    /// `offset` انٹرنس کے برعکس ، یہ اندرونی نتیجے کے اشارے کو کسی مختص چیز کے اختتام پر اشارہ کرنے یا ایک بائٹ کی پابندی نہیں کرتا ہے ، اور یہ دو کی تکمیل ریاضی کے ساتھ لپیٹ دیتا ہے۔
    /// اصل میں میموری تک رسائی کے ل used استعمال شدہ قدر لازمی طور پر درست نہیں ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`pointer::wrapping_offset`] ہے۔
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` کے سائز اور اس کی سیدھ کے ساتھ ، مناسب `llvm.memcpy.p0i8.0i8.*` اندرونی کے برابر
    ///
    /// `min_align_of::<T>()`
    ///
    /// اتار چڑھاؤ کا پیرامیٹر `true` پر سیٹ ہے ، لہذا جب تک سائز صفر کے برابر نہ ہو تب تک اس کو بہتر نہیں بنایا جائے گا۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// مناسب `llvm.memmove.p0i8.0i8.*` اندرونی کے برابر ، جس میں `count* size_of::<T>()` سائز اور ایک سیدھ میں شامل ہو
    ///
    /// `min_align_of::<T>()`
    ///
    /// اتار چڑھاؤ کا پیرامیٹر `true` پر سیٹ ہے ، لہذا جب تک سائز صفر کے برابر نہ ہو تب تک اس کو بہتر نہیں بنایا جائے گا۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` سائز اور `min_align_of::<T>()` کی سیدھ کے ساتھ ، مناسب `llvm.memset.p0i8.*` انٹرنک کے برابر ہے۔
    ///
    ///
    /// اتار چڑھاؤ کا پیرامیٹر `true` پر سیٹ ہے ، لہذا جب تک سائز صفر کے برابر نہ ہو تب تک اس کو بہتر نہیں بنایا جائے گا۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` پوائنٹر سے ایک مستحکم بوجھ انجام دیتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::ptr::read_volatile`](crate::ptr::read_volatile) ہے۔
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` پوائنٹر پر ایک مستحکم اسٹور انجام دیتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::ptr::write_volatile`](crate::ptr::write_volatile) ہے۔
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` پوائنٹر سے ایک مستحکم بوجھ انجام دیتا ہے۔ پوائنٹر کو سیدھ میں رکھنے کی ضرورت نہیں ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` پوائنٹر پر ایک مستحکم اسٹور انجام دیتا ہے۔
    /// پوائنٹر کو سیدھ میں رکھنے کی ضرورت نہیں ہے۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` کا مربع جڑ لوٹاتا ہے
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` کا مربع جڑ لوٹاتا ہے
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// ایک مکمل طاقت کے لئے `f32` اٹھاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// ایک مکمل طاقت کے لئے `f64` اٹھاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// ایک `f32` کا سائن واپس کرتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// ایک `f64` کا سائن واپس کرتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` کا کوسائن لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` کا کوسائن لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// ایک `f32` کو `f32` طاقت میں بڑھاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// ایک `f64` کو `f64` طاقت میں بڑھاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// ایک `f32` کی کفایت شعاری لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// ایک `f64` کی کفایت شعاری لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// ایک `f32` کی طاقت میں اٹھائے گئے 2 کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// ایک `f64` کی طاقت میں اٹھائے گئے 2 کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// ایک `f32` کا قدرتی لوگارڈم لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// ایک `f64` کا قدرتی لوگارڈم لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// ایک `f32` کے بیس 10 لوگرتھم کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// ایک `f64` کے بیس 10 لوگرتھم کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// ایک `f32` کے بیس 2 لوگرتھم کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// ایک `f64` کے بیس 2 لوگرتھم کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` قدروں کیلئے `a * b + c` لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` قدروں کیلئے `a * b + c` لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` کی مطلق قدر لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` کی مطلق قدر لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// کم از کم دو `f32` قدروں کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// کم از کم دو `f64` قدروں کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// زیادہ سے زیادہ دو `f32` قدروں کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// زیادہ سے زیادہ دو `f64` قدروں کو لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` قدروں کیلئے `y` سے `x` تک علامت کاپی کرتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` قدروں کیلئے `y` سے `x` تک علامت کاپی کرتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` سے کم یا اس کے برابر سب سے بڑا عدد لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` سے کم یا اس کے برابر سب سے بڑا عدد لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` سے زیادہ یا اس کے برابر سب سے چھوٹا عددی لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` سے زیادہ یا اس کے برابر سب سے چھوٹا عددی لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` کا پورا عدد حصہ لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` کا پورا عدد حصہ لوٹاتا ہے۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// ایک `f32` پر قریبی عددی کو لوٹاتا ہے۔
    /// اگر دلیل عدد صحیح نہیں ہے تو فلوٹنگ پوائنٹ مستثنیٰ استثنیٰ پیدا کرسکتا ہوں۔
    pub fn rintf32(x: f32) -> f32;
    /// ایک `f64` پر قریبی عددی کو لوٹاتا ہے۔
    /// اگر دلیل عدد صحیح نہیں ہے تو فلوٹنگ پوائنٹ مستثنیٰ استثنیٰ پیدا کرسکتا ہوں۔
    pub fn rintf64(x: f64) -> f64;

    /// ایک `f32` پر قریبی عددی کو لوٹاتا ہے۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn nearbyintf32(x: f32) -> f32;
    /// ایک `f64` پر قریبی عددی کو لوٹاتا ہے۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn nearbyintf64(x: f64) -> f64;

    /// ایک `f32` پر قریبی عددی کو لوٹاتا ہے۔آدھے راستوں کے معاملات صفر سے دور ہوتے ہیں۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// ایک `f64` پر قریبی عددی کو لوٹاتا ہے۔آدھے راستوں کے معاملات صفر سے دور ہوتے ہیں۔
    ///
    /// اس اندرونی کا مستحکم ورژن ہے
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// فلوٹ ایڈیشن جو الجبری قوانین پر مبنی اصلاح کو قابل بناتا ہے۔
    /// فرض کر سکتے ہو کہ ان پٹ محدود ہیں۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// فلوٹ گھٹاؤ جو الجبری قوانین کی بنیاد پر اصلاح کی اجازت دیتا ہے۔
    /// فرض کر سکتے ہو کہ ان پٹ محدود ہیں۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// فلوٹ ضرب جو الجبری قوانین پر مبنی اصلاح کو قابل بناتا ہے۔
    /// فرض کر سکتے ہو کہ ان پٹ محدود ہیں۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// فلوٹ ڈویژن جو الجبری قوانین کی بنیاد پر اصلاح کی اجازت دیتا ہے۔
    /// فرض کر سکتے ہو کہ ان پٹ محدود ہیں۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// فلوٹ بقیہ جو الجبری قوانین کی بنیاد پر اصلاح کی اجازت دیتا ہے۔
    /// فرض کر سکتے ہو کہ ان پٹ محدود ہیں۔
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM کے fptoui/fptosi کے ساتھ بدلاؤ ، جو حد سے باہر کی قدروں کے لئے ناقابل واپسی واپس آسکتا ہے
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] اور [`f64::to_int_unchecked`] کے طور پر مستحکم ہوا۔
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// عددی قسم `T` میں سیٹ کردہ بٹس کی تعداد لوٹاتا ہے
    ///
    /// اس انٹرنک کے مستحکم ورژن `count_ones` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// انٹیجر قسم `T` میں معروف سیٹ سیٹ بٹس (zeroes) کی تعداد لوٹاتا ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `leading_zeros` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` ویلیو والا `x` `T` کی تھوڑا سا چوڑائی واپس کرے گا۔
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` کی طرح ، لیکن اضافی غیر محفوظ اس طرح کہ جب `undef` کو `0` ویلیو کے ساتھ `undef` دیا جائے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// (zeroes) بٹیر انٹریجر قسم میں ٹریلنگ ان سیٹ بٹس کی تعداد واپس کرتا ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `trailing_zeros` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` ویلیو والا `x` `T` کی تھوڑا سا چوڑائی واپس کرے گا:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` کی طرح ، لیکن اضافی غیر محفوظ اس طرح کہ جب `undef` کو `0` ویلیو کے ساتھ `undef` دیا جائے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// باٹیر کو ایک مکمل قسم `T` میں تبدیل کرتا ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `swap_bytes` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// بٹ کو اعداد انفرادی قسم `T` میں تبدیل کرتا ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `reverse_bits` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// جانچ پڑتال کامل اعداد شامل کرتا ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `overflowing_add` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// جانچ پڑتال والے عدد اعدادوشمار کو انجام دیتا ہے
    ///
    /// اس انٹرنک کے مستحکم ورژن `overflowing_sub` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// جانچ پڑا عددی ضرب کو انجام دیتا ہے
    ///
    /// اس انٹرنک کے مستحکم ورژن `overflowing_mul` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ایک عین مطابق ڈویژن انجام دیتا ہے ، جس کے نتیجے میں غیر متعینہ سلوک ہوتا ہے جہاں `x % y != 0` یا `y == 0` یا `x == T::MIN && y == -1`
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// ایک غیر چیک شدہ ڈویژن انجام دیتا ہے ، جس کے نتیجے میں غیر متعینہ سلوک ہوتا ہے جہاں `y == 0` یا `x == T::MIN && y == -1`
    ///
    ///
    /// اس انٹرنس کے لئے محفوظ لفافے `checked_div` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` یا `x == T::MIN && y == -1` جب غیر متعین سلوک کے نتیجے میں غیر چیک شدہ ڈویژن کا بقیہ حصہ لوٹاتا ہے
    ///
    ///
    /// اس انٹرنس کے لئے محفوظ لفافے `checked_rem` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// `y < 0` یا `y >= N` ، جہاں N بٹس میں T کی چوڑائی ہے تو ، غیر متعین سلوک کے نتیجے میں ، ایک غیر چیک شدہ بائیں شفٹ انجام دیتا ہے۔
    ///
    ///
    /// اس انٹرنس کے لئے محفوظ لفافے `checked_shl` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// `y < 0` یا `y >= N` ، جہاں N بٹس میں T کی چوڑائی ہے تو ، غیر متعین سلوک کے نتیجے میں ، ایک غیر چیک شدہ دائیں شفٹ انجام دیتا ہے۔
    ///
    ///
    /// اس انٹرنس کے لئے محفوظ لفافے `checked_shr` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// جب کوئی `x + y > T::MAX` یا `x + y < T::MIN` ہوتا ہے تو غیر متعینہ سلوک کے نتیجے میں ، بغیر کسی جانچ پڑتال کے اضافے کا نتیجہ لوٹاتا ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// `x - y > T::MAX` یا `x - y < T::MIN` جب غیر متعین سلوک کے نتیجے میں ، بغیر جانچے ہوئے ذلت کا نتیجہ لوٹاتا ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// `x *y > T::MAX` یا `x* y < T::MIN` جب غیر متعین سلوک کے نتیجے میں ، بغیر جانچے ہوئے ضرب کا نتیجہ لوٹاتا ہے۔
    ///
    ///
    /// اس اندرونی میں مستحکم ہم منصب نہیں ہے۔
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// باری باری دکھائے گا۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `rotate_left` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// باری باری دائیں انجام دیتا ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `rotate_right` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// واپسی (a + b) Mod 2 <sup>N</sup> ، جہاں N بٹس میں T کی چوڑائی ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `wrapping_add` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// واپسی (a ، b) Mod 2 <sup>N</sup> ، جہاں N بٹس میں T کی چوڑائی ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `wrapping_sub` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// واپسی (a * b) Mod 2 <sup>N</sup> ، جہاں N بٹس میں T کی چوڑائی ہے۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `wrapping_mul` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// شماریات `a + b` ، عددی حدود میں سنترت۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `saturating_add` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// شماریات `a - b` ، عددی حدود میں سنترت۔
    ///
    /// اس انٹرنک کے مستحکم ورژن `saturating_sub` طریقہ کے ذریعے عددی آدم پر دستیاب ہیں۔
    /// مثال کے طور پر،
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' میں مختلف حالت کے ل the امتیازی سلوک کی قدر لوٹاتا ہے۔
    /// اگر `T` میں کوئی امتیازی سلوک نہیں ہے تو ، `0` واپس کردیتا ہے۔
    ///
    /// اس انٹرنسک کا مستحکم ورژن [`core::mem::discriminant`](crate::mem::discriminant) ہے۔
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` قسم کے متغیرات کی تعداد کو `usize` پر واپس کرتا ہے۔
    /// اگر `T` کی کوئی مختلف حالت نہیں ہے تو ، `0` واپس کردیتی ہے۔غیرآباد قسموں کی گنتی کی جائے گی۔
    ///
    /// اس انٹرنس کا مستحکم ورژن [`mem::variant_count`] ہے۔
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust کی "try catch" تعمیراتی ہے جو ڈیٹا پوائنٹر `data` کے ساتھ فنکشن پوائنٹر `try_fn` کو طلب کرتی ہے۔
    ///
    /// تیسری دلیل ایک فنکشن ہے جسے panic ہوتا ہے۔
    /// یہ فنکشن ڈیٹا پوائنٹر اور پوائنٹر کو ٹارگٹ سے متعلق مخصوص استثناء آبجیکٹ پر لے جاتا ہے جو پکڑا گیا تھا۔
    ///
    /// مزید معلومات کے لئے مرتب کنندہ کے ماخذ کے ساتھ ساتھ std کے کیچ پر عمل درآمد دیکھیں۔
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// ایل ایل وی ایم کے مطابق `!nontemporal` اسٹور خارج کرتا ہے (ان کے دستاویزات دیکھیں)۔
    /// شاید کبھی مستحکم نہیں ہوگا۔
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// تفصیلات کے لئے `<*const T>::offset_from` کی دستاویزات دیکھیں۔
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// تفصیلات کے لئے `<*const T>::guaranteed_eq` کی دستاویزات دیکھیں۔
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// تفصیلات کے لئے `<*const T>::guaranteed_ne` کی دستاویزات دیکھیں۔
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// مرتب وقت پر مختص کریں۔رن ٹائم پر نہیں بلایا جانا چاہئے۔
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// کچھ افعال کی وضاحت یہاں کی گئی ہے کیونکہ وہ حادثاتی طور پر مستحکم پر اس ماڈیول میں دستیاب ہوجاتے ہیں۔
// <https://github.com/rust-lang/rust/issues/15702> دیکھیں۔
// (`transmute` بھی اس زمرے میں آتا ہے ، لیکن `T` اور `U` ایک ہی سائز کی جانچ پڑتال کی وجہ سے اس کو لپیٹ نہیں سکتا۔)
//

/// جانچ پڑتال کرتا ہے کہ `ptr` `align_of::<T>()` کے سلسلے میں مناسب طریقے سے منسلک ہے۔
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` سے `dst` تک `count* size_of::<T>()` بائٹس کاپیاں۔ماخذ اور منزل مقصود کو *اوورلپ نہیں* ہونا چاہئے۔
///
/// میموری کے ان علاقوں میں جو اوورلیپ ہوسکتے ہیں ، اس کے بجائے [`copy`] استعمال کریں۔
///
/// `copy_nonoverlapping` Semant [`memcpy`] کے مترادف ہے ، لیکن دلیل کے آرڈر کے ساتھ ہی تبدیل ہو گیا۔
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// اگر مندرجہ ذیل شرائط میں سے کسی کی خلاف ورزی ہوتی ہے تو طرز عمل کی وضاحت نہیں کی جاتی ہے۔
///
/// * `src` `count * size_of::<T>()` بائٹس کے پڑھنے کے لئے [valid] ہونا ضروری ہے۔
///
/// * `dst` `count * size_of::<T>()` بائٹس کی تحریر کے لئے [valid] ہونا ضروری ہے۔
///
/// * دونوں `src` اور `dst` مناسب طریقے سے منسلک ہونا چاہئے۔
///
/// * `src` پر شروع ہونے والی میموری کا علاقہ a گنتی کے سائز کے ساتھ *
///   کا سائز: :<T>() `بائٹس کو ایک ہی سائز کے ساتھ `dst` پر میموری کے خطے کے ساتھ اوورلپ نہیں * ہونا چاہئے۔
///
/// [`read`] کی طرح ، `copy_nonoverlapping` `T` کی تھوڑی سی نقل تیار کرتا ہے ، قطع نظر اس سے قطع نظر کہ `T` [`Copy`] ہے۔
/// اگر `T` [`Copy`] نہیں ہے تو ،*دونوں* کا استعمال کرتے ہوئے خطے میں اقدار `*src` سے شروع ہونے والے خطے اور `* dst` سے شروع ہونے والے خطے [violate memory safety][read-ownership] کر سکتے ہیں۔
///
///
/// نوٹ کریں یہاں تک کہ اگر مؤثر طریقے سے کاپی شدہ سائز (`شمار * سائز_ سے: :<T>()`) `0` ہے ، پوائنٹرز کو غیر NULL ہونا چاہئے اور مناسب طریقے سے منسلک ہونا چاہئے۔
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// دستی طور پر [`Vec::append`] لاگو کریں:
///
/// ```
/// use std::ptr;
///
/// /// `src` کے تمام عناصر کو `dst` میں منتقل کرتا ہے ، `src` کو خالی چھوڑ دیتا ہے۔
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // اس بات کو یقینی بنائیں کہ `dst` میں تمام `src` رکھنے کی کافی صلاحیت ہے۔
///     dst.reserve(src_len);
///
///     unsafe {
///         // آفسیٹ کال ہمیشہ محفوظ رہتی ہے کیونکہ `Vec` کبھی بھی `isize::MAX` بائٹ سے زیادہ مختص نہیں کرے گا۔
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // اس کے مندرجات کو چھوڑے بغیر `src` کو چھوٹیں۔
///         // ہم panics میں مزید کچھ کرنے کی صورت میں پریشانیوں سے بچنے کے ل this ، پہلے یہ کام کرتے ہیں۔
///         src.set_len(0);
///
///         // دونوں خطوں کو پارہ پارہ نہیں کر سکتا کیونکہ تغیر پزیر حوالہ جات عرف نہیں رکھتے ہیں ، اور دو مختلف vectors ایک ہی میموری کے مالک نہیں ہوسکتے ہیں۔
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` کو اطلاع دیں کہ اب اس میں `src` کا مواد موجود ہے۔
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: یہ چیک صرف رن ٹائم پر کریں
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // کوڈجن اثر کو چھوٹا رکھنے کے لئے گھبرانا نہیں۔
        abort();
    }*/

    // محفوظ: `copy_nonoverlapping` کیلئے حفاظتی معاہدہ ہونا چاہئے
    // کال کرنے والے کی طرف سے برقرار.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count *size_of::<T>()` سے `dst` تک `count* size_of::<T>()` بائٹس کاپیاں۔ذریعہ اور منزل مقصود ہوسکتی ہے۔
///
/// اگر ذریعہ اور منزل مقصود *کبھی* اوورلپ نہیں ہوتی ہے تو ، اس کی بجائے [`copy_nonoverlapping`] استعمال کیا جاسکتا ہے۔
///
/// `copy` Semant [`memmove`] کے مترادف ہے ، لیکن دلیل کے آرڈر کے ساتھ ہی تبدیل ہو گیا۔
/// کاپی کرنا اس وقت ہوتا ہے جیسے بائٹس کو `src` سے عارضی سرنی میں کاپی کیا گیا تھا اور پھر سرنی سے `dst` پر کاپی کیا گیا تھا۔
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// اگر مندرجہ ذیل شرائط میں سے کسی کی خلاف ورزی ہوتی ہے تو طرز عمل کی وضاحت نہیں کی جاتی ہے۔
///
/// * `src` `count * size_of::<T>()` بائٹس کے پڑھنے کے لئے [valid] ہونا ضروری ہے۔
///
/// * `dst` `count * size_of::<T>()` بائٹس کی تحریر کے لئے [valid] ہونا ضروری ہے۔
///
/// * دونوں `src` اور `dst` مناسب طریقے سے منسلک ہونا چاہئے۔
///
/// [`read`] کی طرح ، `copy` `T` کی تھوڑی سی نقل تیار کرتا ہے ، قطع نظر اس سے قطع نظر کہ `T` [`Copy`] ہے۔
/// اگر `T` [`Copy`] نہیں ہے تو ، `*src` سے شروع ہونے والے خطے اور `* dst` سے شروع ہونے والے خطے میں دونوں اقدار کا استعمال کرتے ہوئے [violate memory safety][read-ownership] کر سکتے ہیں۔
///
///
/// نوٹ کریں یہاں تک کہ اگر مؤثر طریقے سے کاپی شدہ سائز (`شمار * سائز_ سے: :<T>()`) `0` ہے ، پوائنٹرز کو غیر NULL ہونا چاہئے اور مناسب طریقے سے منسلک ہونا چاہئے۔
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// غیر محفوظ بفر سے ایک Rust vector کو موثر انداز میں تشکیل دیں۔
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` اس کی قسم اور غیر صفر کے لئے لازمی طور پر سیدھ میں ہونا چاہئے۔
/// /// * `ptr` قسم `T` کے مت elementsثر عناصر `elts` کے پڑھنے کے ل for درست ہونا چاہئے۔
/// /// * ان عناصر کو اس فنکشن کو کال کرنے کے بعد استعمال نہیں کرنا چاہئے جب تک کہ `T: Copy` نہ ہو۔
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // سیکیورٹی: ہماری پیش گوئی یقینی بناتی ہے کہ منبع سیدھ میں ہے اور درست ہے ،
///     // اور `Vec::with_capacity` یقینی بناتا ہے کہ ہمارے پاس ان کو لکھنے کے لئے قابل استعمال جگہ ہے۔
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // محفوظ کریں: ہم نے اسے پہلے اتنی گنجائش سے پیدا کیا ،
///     // اور پچھلے `copy` نے ان عناصر کو شروع کیا ہے۔
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: یہ چیک صرف رن ٹائم پر کریں
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // کوڈجن اثر کو چھوٹا رکھنے کے لئے گھبرانا نہیں۔
        abort();
    }*/

    // محفوظ: `copy` کیلئے حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے۔
    unsafe { copy(src, dst, count) }
}

/// `count *size_of::<T>()` سے `val` پر شروع ہونے والے میموری کے `count* size_of::<T>()` بائٹس کا تعین کرتا ہے۔
///
/// `write_bytes` سی کے [`memset`] کی طرح ہے ، لیکن `count * size_of::<T>()` بائٹس کو `val` پر سیٹ کرتا ہے۔
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// اگر مندرجہ ذیل شرائط میں سے کسی کی خلاف ورزی ہوتی ہے تو طرز عمل کی وضاحت نہیں کی جاتی ہے۔
///
/// * `dst` `count * size_of::<T>()` بائٹس کی تحریر کے لئے [valid] ہونا ضروری ہے۔
///
/// * `dst` مناسب طریقے سے سیدھ میں رکھنا چاہئے۔
///
/// مزید برآں ، کال کرنے والے کو یہ یقینی بنانا ہوگا کہ `count * size_of::<T>()` بائٹس کو میموری کے دیئے گئے خطے میں لکھنا `T` کی ایک درست قدر میں ہے۔
/// `T` کے بطور ٹائپ شدہ میموری کے ایسے خطے کا استعمال جس میں `T` کی غلط قدر ہو۔
///
/// نوٹ کریں یہاں تک کہ اگر مؤثر طریقے سے کاپی شدہ سائز (`شمار * سائز_ سے: :<T>()`) `0` ہے ، پوائنٹر لازمی طور پر غیر NULL اور مناسب طریقے سے منسلک ہونا چاہئے۔
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// بنیادی استعمال:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// ایک غلط قدر پیدا کرنا:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>` کو کالعدم اشارے کے ساتھ اوور رائٹ کرکے پہلے کی گئی قدر کو لیک کریں۔
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // اس مرحلے پر ، `v` کا استعمال کرتے ہوئے یا گرنے سے نتیجہ غیر متعینہ سلوک ہوتا ہے۔
/// // drop(v); // ERROR
///
/// // یہاں تک کہ `v` "uses" کو بھی لیک کرنا ، اور اس لئے یہ غیر متعینہ طرز عمل ہے۔
/// // mem::forget(v); // ERROR
///
/// // دراصل ، `v` بنیادی نوعیت کے ترتیب والے حملہ آوروں کے مطابق باطل ہے ، لہذا *اس کو چھونے والا* کوئی بھی عمل غیر متعینہ رویہ ہے۔
/////
/// // چلیں v2 =v؛//غلطی
///
/// unsafe {
///     // آئیے اس کے بجائے ایک درست قدر ڈالیں
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // اب باکس ٹھیک ہے
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // محفوظ: `write_bytes` کیلئے حفاظتی معاہدہ کال کرنے والے کے ذریعہ برقرار رکھنا چاہئے۔
    unsafe { write_bytes(dst, val, count) }
}