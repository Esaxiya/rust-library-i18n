//! اقسام کے لئے `Clone` trait جن کی 'واضح طور پر کاپی نہیں کی جا سکتی'۔
//!
//! Rust میں ، کچھ آسان اقسام "implicitly copyable" ہیں اور جب آپ انہیں تفویض کرتے ہیں یا انہیں دلائل کے طور پر منتقل کرتے ہیں تو وصول کنندہ کو ایک کاپی مل جائے گی ، اصل قیمت کو جگہ پر چھوڑ کر۔
//! ان اقسام کو کاپی کرنے کے لئے مختص کی ضرورت نہیں ہوتی ہے اور اس میں حتمی شکل دینے والوں کی ضرورت نہیں ہوتی ہے (جیسے ، ان میں ملکیت والے خانوں پر مشتمل نہیں ہوتا ہے یا [`Drop`] لاگو نہیں ہوتا ہے) ، لہذا مرتب ان کو سستا اور کاپی کرنا محفوظ سمجھتا ہے۔
//!
//! دوسری قسم کے لئے [`Clone`] trait پر عمل درآمد اور [`clone`] طریقہ پر کال کرکے کنونشن کے ذریعہ ، کاپیاں واضح طور پر بنانی چاہئیں۔
//!
//! [`clone`]: Clone::clone
//!
//! بنیادی استعمال کی مثال:
//!
//! ```
//! let s = String::new(); // سٹرنگ کی قسم کلون کو لاگو کرتی ہے
//! let copy = s.clone(); // لہذا ہم اس کا کلون کرسکتے ہیں
//! ```
//!
//! کلون trait آسانی سے نافذ کرنے کے لئے ، آپ `#[derive(Clone)]` بھی استعمال کرسکتے ہیں۔مثال:
//!
//! ```
//! #[derive(Clone)] // ہم مورفیس ڈھانچے میں کلون trait شامل کرتے ہیں
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // اور اب ہم اسے کلون کر سکتے ہیں!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// کسی چیز کو واضح طور پر نقل کرنے کی اہلیت کے لئے ایک عام trait۔
///
/// اس میں [`Copy`] سے مختلف ہے کہ [`Copy`] مضمحل اور انتہائی سستا ہے ، جبکہ `Clone` ہمیشہ واضح ہوتا ہے اور ہوسکتا ہے اور مہنگا بھی نہیں ہوسکتا ہے۔
/// ان خصوصیات کو نافذ کرنے کے لئے ، Rust آپ کو [`Copy`] کو دوبارہ نافذ کرنے کی اجازت نہیں دیتا ہے ، لیکن آپ `Clone` کو بہتر بنائیں اور صوابدیدی کوڈ کو چلائیں۔
///
/// چونکہ `Clone` [`Copy`] سے زیادہ عام ہے ، لہذا آپ خود بخود [`Copy`] کو `Clone` بھی بنا سکتے ہیں۔
///
/// ## Derivable
///
/// یہ trait `#[derive]` کے ساتھ استعمال کیا جاسکتا ہے اگر تمام فیلڈز `Clone` ہیں۔[`Clone`] کا وسیع پیمانے پر عمل درآمد ہر شعبے میں [`clone`] پر کال کرتا ہے۔
///
/// [`clone`]: Clone::clone
///
/// عام ڈھانچے کے ل X ، `#[derive]` عام پیرامیٹرز پر پابند `Clone` شامل کرکے `Clone` کو مشروط طور پر نافذ کرتا ہے۔
///
/// ```
/// // `derive` پڑھنے کے لئے کلون نافذ کرتا ہے<T>جب T کلون ہوتا ہے۔
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## میں `Clone` کو کس طرح نافذ کرسکتا ہوں؟
///
/// اقسام جو [`Copy`] ہیں ان میں `Clone` کا چھوٹا سا نفاذ ہونا چاہئے۔مزید باضابطہ:
/// اگر `T: Copy` ، `x: T` ، اور `y: &T` ، تو `let x = y.clone();` `let x = *y;` کے برابر ہے۔
/// دستی عملدرآمد کو اس ناگوار کو برقرار رکھنے کے لئے محتاط رہنا چاہئے۔تاہم ، میموری کی حفاظت کو یقینی بنانے کے لئے غیر محفوظ کوڈ کو اس پر انحصار نہیں کرنا چاہئے۔
///
/// اس کی ایک مثال ایک عمومی ڈھانچہ ہے جس میں ایک فنکشن پوائنٹر ہوتا ہے۔اس معاملے میں ، `Clone` پر عمل درآمد کو مشتق نہیں کیا جاسکتا ہے ، لیکن اس پر عملدرآمد اس طرح کیا جاسکتا ہے:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## اضافی عمل درآمد کرنے والے
///
/// [implementors listed below][impls] کے علاوہ ، درج ذیل اقسام بھی `Clone` کو نافذ کرتی ہیں۔
///
/// * فنکشن آئٹم کی اقسام (یعنی ، ہر فنکشن کے لئے الگ الگ قسم کی وضاحت)
/// * فنکشن پوائنٹر کی اقسام (جیسے ، `fn() -> i32`)
/// * اشارے کی اقسام ، ہر سائز کے ل if ، اگر آئٹم کی قسم `Clone` کو بھی نافذ کرتی ہے (جیسے ، `[i32; 123456]`)
/// * مختلف اقسام ، اگر ہر جز `Clone` (جیسے ، `()` ، `(i32, bool)`) بھی نافذ کرتا ہے
/// * بندش کی اقسام ، اگر وہ ماحول سے کوئی قیمت حاصل نہیں کرتے ہیں یا اگر اس طرح کی تمام اقدار خود `Clone` پر عمل درآمد کرتی ہیں۔
///   نوٹ کریں کہ مشترکہ حوالہ کے ذریعہ پکڑے جانے والے متغیرات ہمیشہ `Clone` پر عمل درآمد کرتے ہیں (چاہے وہ مختلف نہ ہوں) ، جبکہ متغیر حوالہ سے حاصل کردہ متغیرات کبھی بھی `Clone` پر عمل نہیں کرتے ہیں۔
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// قدر کی ایک کاپی لوٹاتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str کلون کو نافذ کرتا ہے
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` سے کاپی تفویض انجام دیتا ہے۔
    ///
    /// `a.clone_from(&b)` فعالیت میں `a = b.clone()` کے مساوی ہے ، لیکن غیر ضروری تخصیصوں سے بچنے کے لئے `a` کے وسائل کو دوبارہ استعمال کرنے کے لئے اسے زیر کیا جاسکتا ہے۔
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): یہ ترکیبیں مکمل طور پر#[اخذ] کے ذریعہ استعمال کیا جاتا ہے تاکہ یہ ثابت کیا جا سکے کہ ایک قسم کا ہر جزو کلون یا کاپی پر عمل درآمد کرتا ہے۔
//
//
// یہ ترکیبیں صارف کے کوڈ میں کبھی بھی ظاہر نہیں ہونی چاہئیں۔
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// آدم اقسام کے لئے `Clone` کا نفاذ۔
///
/// Rust میں بیان نہیں کی جاسکتی ہیں کہ `rustc_trait_selection` میں `traits::SelectionContext::copy_clone_conditions()` میں لاگو کیا جاتا ہے۔
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// مشترکہ حوالوں کو کلون کیا جاسکتا ہے ، لیکن تغیر پزیر حوالہ جات *نہیں* کر سکتے ہیں!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// مشترکہ حوالوں کو کلون کیا جاسکتا ہے ، لیکن تغیر پزیر حوالہ جات *نہیں* کر سکتے ہیں!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}