//! جنریک ہیشنگ سپورٹ۔
//!
//! یہ ماڈیول کسی قدر کے [hash] کی گنتی کرنے کا ایک عمومی طریقہ فراہم کرتا ہے۔
//! ہیشز [`HashMap`] اور [`HashSet`] کے ساتھ عام طور پر استعمال ہوتے ہیں۔
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! قسم کو ہینشبل بنانے کا آسان ترین طریقہ `#[derive(Hash)]` استعمال کرنا ہے:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! اگر آپ کو قیمت ہیس ہونے کے طریقہ کار پر مزید قابو پانے کی ضرورت ہے تو ، آپ کو [`Hash`] trait لاگو کرنے کی ضرورت ہے۔
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// ایک ہیشبل قسم
///
/// اقسام `Hash` پر عمل درآمد کرنے کے قابل ہیں [X X hash`] ایڈ 100 X کی مثال کے ساتھ۔
///
/// ## `Hash` لاگو کیا جا رہا ہے
///
/// اگر تمام فیلڈز `Hash` لاگو کرتے ہیں تو آپ `Hash` کے ساتھ `Hash` اخذ کرسکتے ہیں۔
/// نتیجے میں ہیش ہر فیلڈ پر [`hash`] کال کرنے سے اقدار کا مجموعہ ہوگا۔
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// اگر آپ کو قیمت ہیس ہونے کے طریقہ کار پر مزید قابو پانے کی ضرورت ہے تو ، آپ یقینا `Hash` trait خود لاگو کرسکتے ہیں:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` اور `Eq`
///
/// `Hash` اور [`Eq`] دونوں کو نافذ کرتے وقت ، یہ ضروری ہے کہ درج ذیل پراپرٹی رکھے:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// دوسرے الفاظ میں ، اگر دو چابیاں برابر ہیں تو ، ان کی ہیشیں بھی برابر ہونی چاہئیں۔
/// [`HashMap`] اور [`HashSet`] دونوں اس طرز عمل پر انحصار کرتے ہیں۔
///
/// شکر ہے ، جب `#[derive(PartialEq, Eq, Hash)]` کے ساتھ [`Eq`] اور `Hash` دونوں اخذ کرتے وقت آپ کو اس پراپرٹی کو برقرار رکھنے کی فکر کرنے کی ضرورت نہیں ہوگی۔
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// اس قدر کو دیئے گئے [`Hasher`] میں کھلانا۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// دیئے گئے [`Hasher`] میں اس قسم کا ایک ٹکڑا کھلا دیتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// trait `Hash` کے بغیر preolve سے میکرو `Hash` کو دوبارہ برآمد کرنے کے لئے ماڈیول الگ کریں۔
pub(crate) mod macros {
    /// trait `Hash` کی ایک امپلیری تیار کرتے ہوئے اخذ کریں۔
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// بائٹس کے من مانی سلسلے کو چلانے کے لئے ایک trait۔
///
/// `Hasher` کے واقعات عام طور پر اس ریاست کی نمائندگی کرتے ہیں جو ڈیٹا ہیس کرتے وقت تبدیل کردی جاتی ہے۔
///
/// `Hasher` پیدا شدہ ہیش ([`finish`] کے ساتھ) کو بازیافت کرنے ، اور انٹیجرز لکھنے کے ساتھ ساتھ بائٹس کے سلائسس (مثال کے طور پر [`write`] اور [`write_u8`] وغیرہ) کے ل a کافی بنیادی انٹرفیس فراہم کرتا ہے۔
/// زیادہ تر وقت ، `Hasher` مثالوں کو [`Hash`] trait کے ساتھ مل کر استعمال کیا جاتا ہے۔
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// اب تک لکھی گئی اقدار کے لئے ہیش کی قیمت لوٹاتا ہے۔
    ///
    /// اس کے نام کے باوجود ، یہ طریقہ ہیشر کی داخلی حالت کو دوبارہ ترتیب نہیں دیتا ہے۔
    /// اضافی [`Writ`] s موجودہ قیمت سے جاری رہیں گی۔
    /// اگر آپ کو نئی ہیش ویلیو شروع کرنے کی ضرورت ہے تو آپ کو نیا ہیشر بنانا ہوگا۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// اس `Hasher` میں کچھ ڈیٹا لکھتا ہے۔
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// اس ہیشر میں ایک ہی `u8` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// اس ہیشر میں ایک ہی `u16` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// اس ہیشر میں ایک ہی `u32` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// اس ہیشر میں ایک ہی `u64` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// اس ہیشر میں ایک ہی `u128` لکھتا ہے۔
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// اس ہیشر میں ایک ہی `usize` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// اس ہیشر میں ایک ہی `i8` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// اس ہیشر میں ایک ہی `i16` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// اس ہیشر میں ایک ہی `i32` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// اس ہیشر میں ایک ہی `i64` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// اس ہیشر میں ایک ہی `i128` لکھتا ہے۔
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// اس ہیشر میں ایک ہی `isize` لکھتا ہے۔
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// [`Hasher`] کی مثال بنانے کے لئے ایک trait۔
///
/// ایک `BuildHasher` کو عام طور پر ([`HashMap`] بذریعہ) ہر کلید کے لئے [`ہیشر`] s بنانے کے لئے استعمال کیا جاتا ہے تاکہ وہ ایک دوسرے سے آزادانہ طور پر چھا جائیں ، چونکہ [`ہیشر`] کی ریاست پر مشتمل ہے۔
///
///
/// `BuildHasher` کی ہر مثال کے ل X ، [`build_hasher`] کے ذریعہ تیار کردہ [`ہیشر`] یکساں ہونا چاہئے۔
/// یعنی ، اگر بائٹس کے ایک ہی دھارے کو ہر ایک ہیشر میں کھلایا جائے تو وہی آؤٹ پٹ بھی تیار ہوگا۔
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// حشر کی قسم جو تخلیق کی جائے گی۔
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// ایک نیا ہیشر بناتا ہے۔
    ///
    /// ایک ہی مثال پر `build_hasher` پر آنے والی ہر کال میں ایک جیسی [`ہاشر`] کی پیداوار ہونی چاہئے۔
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// [`Hasher`] اور [`Default`] پر عمل درآمد کرنے والی اقسام کے لئے پہلے سے طے شدہ [`BuildHasher`] مثال بنانے کیلئے استعمال ہوتا ہے۔
///
/// `BuildHasherDefault<H>` جب ایک قسم `H` [`Hasher`] اور [`Default`] لاگو کرتا ہے ، اور آپ کو اسی طرح کے [`BuildHasher`] مثال کی ضرورت ہے ، لیکن اس کی کوئی وضاحت نہیں کی جاسکتی ہے۔
///
///
/// کوئی `BuildHasherDefault` [zero-sized] ہے۔یہ [`default`][method.default] کے ساتھ تشکیل دیا جاسکتا ہے۔
/// `BuildHasherDefault` کو [`HashMap`] یا [`HashSet`] کے ساتھ استعمال کرتے وقت ، ایسا کرنے کی ضرورت نہیں ہے ، کیونکہ وہ مناسب [`Default`] مثالوں کو خود نافذ کرتے ہیں۔
///
/// # Examples
///
/// `BuildHasherDefault` کا استعمال کرکے اپنی مرضی کے مطابق [`BuildHasher`] کی وضاحت کریں
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // آپ کا ہیشنگ الگورتھم یہاں جاتا ہے!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // آپ کا ہیشنگ الگورتھم یہاں جاتا ہے!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // محفوظ: `ptr` درست اور منسلک ہے ، کیونکہ یہ میکرو صرف استعمال ہوتا ہے
                    // عددی آدمیوں کے لئے جن کی کوئی گنجائش نہیں ہے۔
                    // نئی سلائس صرف `data` میں پھیلی ہوئی ہے اور کبھی تبدیل نہیں کی جاتی ہے ، اور اس کا کل سائز اصلی `data` جیسا ہوتا ہے لہذا یہ `isize::MAX` سے زیادہ نہیں ہوسکتا ہے۔
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // پتلا پوائنٹر
                    state.write_usize(*self as *const () as usize);
                } else {
                    // موٹی پوائنٹر محفوظ: ہم `self` کے زیر قبضہ میموری تک رسائی حاصل کر رہے ہیں جس کی ضمانت کی ضمانت ہے۔
                    // یہ فرض کرتا ہے کہ ایک چربی پوائنٹر کی نمائندگی `(usize, usize)` کے ذریعہ کی جاسکتی ہے ، جو `std` میں کرنا محفوظ ہے کیونکہ اسے بھیج دیا جاتا ہے اور `rustc` میں چربی پوائنٹر کے نفاذ کے ساتھ ہم آہنگی میں رکھا جاتا ہے۔
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // پتلا پوائنٹر
                    state.write_usize(*self as *const () as usize);
                } else {
                    // موٹی پوائنٹر محفوظ: ہم `self` کے زیر قبضہ میموری تک رسائی حاصل کر رہے ہیں جس کی ضمانت کی ضمانت ہے۔
                    // یہ فرض کرتا ہے کہ ایک چربی پوائنٹر کی نمائندگی `(usize, usize)` کے ذریعہ کی جاسکتی ہے ، جو `std` میں کرنا محفوظ ہے کیونکہ اسے بھیج دیا جاتا ہے اور `rustc` میں چربی پوائنٹر کے نفاذ کے ساتھ ہم آہنگی میں رکھا جاتا ہے۔
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}