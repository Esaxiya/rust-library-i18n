//! جب میکرو مصنفین کے ل A ایک سپورٹ لائبریری جب نئے میکرو کی تعریف کرتے ہیں۔
//!
//! یہ لائبریری ، معیاری تقسیم کے ذریعہ فراہم کردہ ، طریق کار کی طرح میکرو `#[proc_macro]` ، میکرو اوصاف `#[proc_macro_attribute]` اور اپنی مرضی کے مطابق اخذ کردہ خصوصیات `#[proc_macro_derive] as جیسی عمل سے طے شدہ میکرو تعریفوں کے انٹرفیس میں استعمال شدہ اقسام مہیا کرتی ہے۔
//!
//!
//! مزید کے لئے [the book] دیکھیں۔
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// اس بات کا تعین کرتا ہے کہ آیا اس وقت چلائے جانے والے پروگرام تک پرو_ میکرو قابل رسائی بنایا گیا ہے۔
///
/// proc_macro crate صرف طریقہ کار میکرو کے نفاذ کے اندر استعمال کے لئے ہے۔اس crate panic میں موجود تمام افعال اگر کسی پروسیشنل میکرو کے باہر سے منگوائے جاتے ہیں ، جیسے کسی بلڈ اسکرپٹ یا یونٹ ٹیسٹ یا عام Rust بائنری سے۔
///
/// Rust لائبریریوں کے بارے میں غور کے ساتھ جو میکرو اور نان میکرو دونوں استعمال کے معاملات کی حمایت کے لئے بنائے گئے ہیں ، `proc_macro::is_available()` ایک گھبراہٹ کا راستہ فراہم کرتا ہے کہ آیا پرو_ماکرو کے API کو استعمال کرنے کے لئے درکار بنیادی ڈھانچہ موجود ہے یا نہیں۔
/// اگر کسی دوسرے بائنری سے درخواست کی گئی ، کسی پروسیشنل میکرو کے اندر سے کال کی گئی ہو تو صحیح لوٹاتا ہے۔
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// اس crate کے ذریعہ فراہم کردہ اہم قسم ، tokens کے خلاصہ دھارے کی نمائندگی کرتی ہے ، یا خاص طور پر token درختوں کا ایک سلسلہ ہے۔
/// قسم ان token درختوں پر تکرار کرنے کے ل for اور اس کے برعکس ، token درختوں کی ایک بڑی تعداد کو ایک ندی میں جمع کرتے ہیں۔
///
///
/// یہ دونوں `#[proc_macro]` ، `#[proc_macro_attribute]` اور `#[proc_macro_derive]` تعریفوں کا ان پٹ اور آؤٹ پٹ ہے۔
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` سے غلطی لوٹ آئی۔
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// ایک خالی `TokenStream` لوٹاتا ہے جس میں token درخت نہیں ہوتے ہیں۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// چیک کرتا ہے کہ اگر یہ `TokenStream` خالی ہے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// تار کو tokens میں توڑنے اور tokens کو token ندی میں پارس کرنے کی کوششیں۔
/// متعدد وجوہات کی بناء پر ناکام ہوسکتے ہیں ، مثال کے طور پر ، اگر اس تار میں متوازن حد بند کرنے والے یا زبان میں موجود حروف موجود نہ ہوں۔
///
/// پارسیڈ اسٹریم میں موجود تمام tokens `Span::call_site()` اسپین حاصل کرتے ہیں۔
///
/// NOTE: کچھ غلطیاں `LexError` کو واپس کرنے کے بجائے panics کا سبب بن سکتی ہیں۔ہم ان غلطیوں کو بعد میں `لیکس ایرر` میں تبدیل کرنے کا حق محفوظ رکھتے ہیں۔
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB ، پل صرف `to_string` مہیا کرتا ہے ، اس کی بنیاد پر `fmt::Display` کو نافذ کرتا ہے (دونوں کے مابین معمول کے تعلقات کو الٹا)۔
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token ندی کو اس تار کے بطور پرنٹ کرتا ہے جو سمجھا جاتا ہے کہ وہ اسی token ندی (ماڈیولو اسپین) میں بغیر کسی نقصان کے بدل سکتا ہے ، سوائے ممکنہ طور پر `ٹوکن ٹری: : `Delimiter::None` ڈلیمیٹر اور منفی عددی لفظی والے گروپس کے۔
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ڈبگنگ کے ل for آسان فارم میں token پرنٹ کریں۔
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ایک token درخت پر مشتمل ایک token تیار کرتا ہے۔
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// token درختوں کی ایک بڑی تعداد کو ایک ندی میں جمع کرتا ہے۔
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token ندیوں پر ایک "flattening" آپریشن ، token درختوں کو ایک سے زیادہ token ندیوں سے ایک ندی میں جمع کرتا ہے۔
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ممکنہ طور پر ایک بہتر اصلاحی if/when استعمال کریں۔
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` قسم کیلئے عوامی عمل درآمد کی تفصیلات ، جیسے تکرار کرنے والے۔
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// ite ٹوکن اسٹریم`کے`ٹوکن ٹری over سے زیادہ تعیratorن کرنے والا۔
    /// تکرار "shallow" ہے ، مثال کے طور پر ، تکرار کرنے والے فرد کو محدود شدہ گروپوں میں نہیں کرتا ہے ، اور token درختوں کی طرح پورے گروپس کو لوٹاتا ہے۔
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` tokens کو صوابدیدی قبول کرتا ہے اور ان پٹ کو بیان کرنے والے `TokenStream` میں توسیع کرتا ہے۔
/// مثال کے طور پر ، `quote!(a + b)` ایک تاثر پیدا کرے گا ، جب اس کا اندازہ کیا جائے تو ، `TokenStream` `[Ident("a") ، Punct('+', Alone) ، Ident("b")]`.
///
///
/// انکاؤٹنگ `$` کے ساتھ کی جاتی ہے ، اور ایک ہی اگلی شناخت کو بے قید اصطلاح کے طور پر لے کر کام کرتی ہے۔
/// خود `$` کے حوالہ کرنے کے لئے ، `$$` استعمال کریں۔
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// میکرو توسیع کی معلومات کے ساتھ ، ماخذ کوڈ کا ایک خطہ۔
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// اسپین `self` پر دیئے گئے `message` کے ساتھ ایک نیا `Diagnostic` تخلیق کرتا ہے۔
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// ایک مدت جس میں میکرو تعریف سائٹ پر حل ہوتا ہے۔
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// موجودہ طریقہ کار میکرو کی درخواست کا دورانیہ۔
    /// اس مدت کے ساتھ پیدا کردہ شناخت کاروں کو حل کیا جائے گا جیسے وہ براہ راست میکرو کال لوکیشن (کال سائٹ حفظان صحت) پر لکھے گئے تھے اور میکرو کال سائٹ پر موجود دیگر کوڈ بھی ان کا حوالہ دے سکیں گے۔
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// ایک ایسا دورانیہ جو `macro_rules` حفظان صحت کی نمائندگی کرتا ہے ، اور کبھی میکرو ڈیفینیشن سائٹ (مقامی متغیرات ، لیبلز ، X01 ایکس) اور کبھی میکرو کال سائٹ (ہر چیز) پر حل ہوتا ہے۔
    ///
    /// دورانیے کا مقام کال سائٹ سے لیا گیا ہے۔
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// اصل وسیلہ فائل جس میں یہ دورانیہ ہے۔
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// پچھلے میکرو توسیع میں tokens کے لئے `Span` جس سے `self` تیار کیا گیا تھا ، اگر کوئی ہے تو۔
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// اصل ماخذ کوڈ کی مدت جس میں `self` تیار کیا گیا تھا۔
    /// اگر یہ `Span` دوسرے میکرو پھیلاؤ سے پیدا نہیں ہوا تھا تو واپسی کی قیمت `*self` جیسی ہے۔
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// اس دورانیے کے لئے ماخذ فائل میں line/column سے شروع ہوتا ہے۔
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// اس مدت کے لئے ماخذ فائل میں اختتام پذیر line/column حاصل کرتا ہے۔
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` اور `other` پر مشتمل ایک نیا دورانیہ تشکیل دیتا ہے۔
    ///
    /// اگر `self` اور `other` مختلف فائلوں سے ہیں تو `None` واپس کرتا ہے۔
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` جیسی ہی line/column معلومات کے ساتھ ایک نیا دورانیہ تشکیل دیتا ہے لیکن یہ علامتوں کو حل کرتا ہے گویا یہ `other` پر ہے۔
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` جیسے نام کے ریزولوشن سلوک کے ساتھ لیکن `other` کی line/column معلومات کے ساتھ ایک نیا دورانیہ تشکیل دیتا ہے۔
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// یہ دیکھنے کے لئے کہ وہ برابر ہیں یا نہیں ، اس پر موازنہ کریں۔
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ایک مدت کے پیچھے ماخذ کا متن لوٹاتا ہے۔
    /// اس سے اصلی ماخذ کوڈ کو محفوظ کیا جاتا ہے ، جس میں خالی جگہ اور تبصرے شامل ہیں۔
    /// یہ صرف اس کے بعد ہی کوئی نتیجہ لوٹائے گا جب پھیلاؤ اصلی وسیلہ کوڈ سے مساوی ہے۔
    ///
    /// Note: میکرو کا قابل مشاہدہ نتیجہ صرف tokens پر انحصار کرنا چاہئے نہ کہ اس ماخذ کے متن پر۔
    ///
    /// اس فنکشن کا نتیجہ بہترین تشخیص ہے کہ وہ صرف تشخیص کے ل used استعمال ہو۔
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ڈیبگنگ کے لئے موزوں فارم میں ایک مدت کا پرنٹ کریں۔
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ایک لائن کالم جوڑی جو `Span` کے آغاز یا اختتام کی نمائندگی کرتی ہے۔
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// ماخذ فائل میں 1 اشاریہ والی لائن جس پر دورانیہ (inclusive) شروع ہوتا ہے یا ختم ہوتا ہے۔
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ماخذ فائل میں 0 اشاریہ کردہ کالم (UTF-8 حروف میں) جس پر (inclusive) X شروع ہوتا ہے یا ختم ہوتا ہے۔
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// دیئے گئے `Span` کی سورس فائل۔
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// اس سورس فائل کا راستہ حاصل کرتا ہے۔
    ///
    /// ### Note
    /// اگر اس `SourceFile` سے وابستہ کوڈ اسپین کسی بیرونی میکرو ، اس میکرو کے ذریعہ تیار کیا گیا تھا ، تو یہ فائل سسٹم میں اصل راہ نہیں ہوسکتی ہے۔
    /// چیک کرنے کے لئے [`is_real`] استعمال کریں۔
    ///
    /// یہ بھی نوٹ کریں کہ یہاں تک کہ اگر `is_real` `true` کو واپس کرتا ہے ، اگر `--remap-path-prefix` کمانڈ لائن پر گزر گیا تھا تو ، شاید دیا ہوا راستہ درست نہیں ہوگا۔
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// اگر یہ سورس فائل ایک حقیقی سورس فائل ہو ، اور کسی بیرونی میکرو کی توسیع کے ذریعہ تیار نہیں کی گئی ہو تو `true` کو لوٹاتا ہے۔
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // یہ ایک ہیک ہے جب تک کہ انٹریکٹریٹ اسپینز کو نافذ نہیں کیا جاتا ہے اور ہمارے پاس بیرونی میکرو میں پیدا ہونے والی اسپینوں کے ل real حقیقی سورس فائلیں ہوسکتی ہیں۔
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token درختوں کی ایک واحد token یا ایک محدود ترتیب (جیسے ، `[1, (), ..]`)۔
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// ایک token ندی بریکٹ ڈلییمٹرز سے گھرا ہوا ہے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ایک شناخت کار۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// ایک ہی رموز اوقاف (character + `، `,` ، `$` ، وغیرہ)۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// ایک لفظی کردار (`'a'`) ، اسٹرنگ (`"hello"`) ، نمبر (`2.3`) ، وغیرہ۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// اس درخت کی مدت کو لوٹاتا ہے ، موجود token کے `span` طریقہ یا کسی حد بندی شدہ ندی کو تفویض کرتا ہے۔
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// مدت *صرف اس token* کیلئے تشکیل کرتی ہے۔
    ///
    /// نوٹ کریں کہ اگر یہ token ایک `Group` ہے تو پھر یہ طریقہ کار ہر tokens کی مدت کو تشکیل نہیں دیتا ہے ، یہ ہر مختلف حالت کے `set_span` طریقہ کو آسانی سے نمائندگی کرے گا۔
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// token درخت کو ڈیبگ کرنے کے لئے آسان فارم میں چھپاتا ہے۔
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // اخذ کردہ ڈیبگ میں ان میں سے ہر ایک کا نام اسٹرک ٹائپ میں ہے ، لہذا اندیشی کی ایک اضافی پرت سے پریشان نہ ہوں
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB ، پل صرف `to_string` مہیا کرتا ہے ، اس کی بنیاد پر `fmt::Display` کو نافذ کرتا ہے (دونوں کے مابین معمول کے تعلقات کو الٹا)۔
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token درخت کو اس تار کے بطور پرنٹ کریں جو سمجھا جاتا ہے کہ وہ اسی token درخت (ماڈیولو اسپینز) میں بغیر کسی نقصان کے تبدیل ہوسکتا ہے ، سوائے ممکنہ طور پر `ٹوکن ٹری: : `Delimiter::None` حد بندی اور منفی عددی لفظی والے گروپس کے۔
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ایک حد بند token ندی۔
///
/// ایک `Group` اندرونی طور پر ایک `TokenStream` پر مشتمل ہوتا ہے جس کے چاروں طرف `ڈیلی میٹرٹر ہوتا ہے۔
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token درختوں کی ترتیب کو کس طرح محدود کردیا گیا ہے اس کی وضاحت کرتا ہے۔
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ایک ضمیم حد بندی ، جو ، مثال کے طور پر ، tokens کے ارد گرد ظاہر ہوسکتی ہے جو "macro variable" `$var` سے آرہی ہے۔
    /// `$var * 3` جیسے معاملات میں آپریٹر کی ترجیحات کا تحفظ ضروری ہے جہاں `$var` `1 + 2` ہے۔
    /// ضمیم ڈلیمیٹرس سٹرنگ کے ذریعہ token ندی کے راؤنڈ ٹریپ سے زندہ نہیں رہ سکتے ہیں۔
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// دیئے گئے حد اور token ندی کے ساتھ ایک نیا `Group` تخلیق کرتا ہے۔
    ///
    /// یہ کنسٹرکٹر اس گروپ کے لئے اسپین `Span::call_site()` پر مرتب کرے گا۔
    /// مدت کو تبدیل کرنے کے لئے آپ نیچے `set_span` طریقہ استعمال کرسکتے ہیں۔
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// اس `Group` کا ڈیلیمیٹر لوٹاتا ہے
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// tokens کا `TokenStream` واپس کرتا ہے جو اس `Group` میں محدود کردیئے گئے ہیں۔
    ///
    /// نوٹ کریں کہ لوٹائے گئے ٹوکن سلسلہ میں اوپر واپس ہونے والا حد بندی شامل نہیں ہے۔
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// پورے 0to0 ندی کے پجاریوں کے لئے دورانیہ واپس کرتا ہے ، پورے `Group` پر پھیلا ہوا ہے۔
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// اس گروپ کی افتتاحی حد بندی کی طرف اشارہ کرنے والا موڑ لوٹاتا ہے۔
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// اس گروپ کے اختتامی حد بندی کی طرف اشارہ کرنے والا موڑ لوٹاتا ہے۔
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// اس `گروپ` کے حد بندی کرنے والے کے لئے وقفہ ترتیب دیتا ہے ، لیکن اس کے اندرونی زیڈ ٹو ٹکن00 زیڈ نہیں۔
    ///
    /// یہ طریقہ **نہیں** اس گروپ کے ذریعہ پھیلائے گئے تمام داخلی tokens کا دورانیہ طے کرے گا ، بلکہ اس سے صرف ڈلیمیٹر tokens کا دورانیہ `Group` کی سطح پر طے ہوگا۔
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB ، پل صرف `to_string` مہیا کرتا ہے ، اس کی بنیاد پر `fmt::Display` کو نافذ کرتا ہے (دونوں کے مابین معمول کے تعلقات کو الٹا)۔
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// اس گروپ کو اسٹر stringنگ کے بطور پرنٹس کرتا ہے جو ایک ہی گروپ (ماڈیولو اسپین) میں بغیر کسی نقصان کے تبدیل ہونا چاہئے ، سوائے ممکنہ طور پر `ٹوکن ٹری: : گروپ`s کے ساتھ `Delimiter::None` ڈلیمیٹرس۔
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// ایک `Punct` ایک واحد اوقافی کردار ہے جیسے `+` ، `-` یا `#`۔
///
/// `+=` جیسے ملٹی کریکٹر آپریٹرز کو `Punct` کی دو مثالوں کے طور پر دکھایا گیا ہے جس میں `Spacing` کی مختلف شکلیں موصول ہوئی ہیں۔
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// چاہے ایک `Punct` کا فورا بعد دوسرا `Punct` ہو یا اس کے بعد دوسرا token یا وائٹ اسپیس ہو۔
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// مثال کے طور پر ، `+` `+ =` ، `+ident` یا `+()` میں `Alone` ہے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// مثال کے طور پر ، `+` `+=` یا `'#` میں `'#` ہے۔
    /// اضافی طور پر ، ایک حوالہ `'` شناخت کنندگان کے ساتھ شامل ہوسکے تا تا تا عمر `'ident` تشکیل پائے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// دیئے ہوئے کردار اور وقفہ کاری سے ایک نیا `Punct` تخلیق کرتا ہے۔
    /// `ch` دلیل زبان کے ذریعہ اجازت دینے والا ایک درست اوقاف کا حامل ہونا ضروری ہے ، بصورت دیگر یہ فعل panic پر مشتمل ہوگا۔
    ///
    /// واپس شدہ `Punct` میں `Span::call_site()` کا پہلے سے طے شدہ دورانیہ ہوگا جس کو مزید نیچے `set_span` طریقہ کے ساتھ تشکیل دیا جاسکتا ہے۔
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// اس اوقافی کردار کی قدر کو `char` کی طرح لوٹاتا ہے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// اس اوقاف کی خصوصیت کی واپسی ، اشارہ کرتا ہے کہ آیا token ندی میں فوری طور پر اس کے بعد کسی اور `Punct` کی پیروی کی جاتی ہے ، لہذا انھیں ممکنہ طور پر ملٹی کریکٹر آپریٹر (`Joint`) میں جوڑا جاسکتا ہے ، یا اس کے بعد کسی اور token یا وائٹ اسپیس (`Alone`) کی پیروی کی جاسکتی ہے ختم
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// اس وقفے وقفے سے متعلق کردار کو موڑ دیتا ہے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// اس اوقافی کردار کے لئے اسپین تشکیل دیں۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB ، پل صرف `to_string` مہیا کرتا ہے ، اس کی بنیاد پر `fmt::Display` کو نافذ کرتا ہے (دونوں کے مابین معمول کے تعلقات کو الٹا)۔
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// اوقافی کردار کو اسٹرنگ کی طرح پرنٹس کرتا ہے جو بغیر کسی نقصان کے واپس اسی کردار میں تبدیل ہونا چاہئے۔
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ایک شناخت کنندہ (`ident`)۔
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// دیئے گئے `string` کے ساتھ ساتھ مخصوص `span` کے ساتھ ایک نیا `Ident` تخلیق کرتا ہے۔
    /// `string` دلیل زبان کے ذریعہ اجازت شدہ ایک درست شناخت کنندہ ہونا ضروری ہے (بشمول کلیدی الفاظ ، جیسے `self` یا `fn`)ورنہ ، تقریب panic کرے گی۔
    ///
    /// نوٹ کریں کہ `span` ، فی الحال rustc میں ، اس شناخت کنندہ کے لئے حفظان صحت کی معلومات کو مرتب کرتا ہے۔
    ///
    /// اس وقت تک ، `Span::call_site()` واضح طور پر "call-site" حفظان صحت کا انتخاب کرتا ہے مطلب یہ ہے کہ اس مدت کے ساتھ تخلیق کردہ شناخت کنندگان کو حل کیا جائے گا جیسے وہ براہ راست میکرو کال کے مقام پر لکھے گئے ہوں ، اور میکرو کال سائٹ پر موجود دیگر کوڈ کا حوالہ دے سکیں گے۔ انہیں بھی۔
    ///
    ///
    /// بعد میں `Span::def_site()` جیسے اسپینز "definition-site" حفظان صحت کا آپٹ ان کرنے کی اجازت دیں گے اس کا مطلب یہ ہے کہ اس مدت کے ساتھ تخلیق کردہ شناخت کار میکرو تعریف کی جگہ پر حل ہوجائے گا اور میکرو کال سائٹ پر موجود دیگر کوڈ ان کا حوالہ نہیں دے پائیں گے۔
    ///
    /// حفظان صحت کی موجودہ اہمیت کی وجہ سے ، اس تعمیر کنندہ کو ، دوسرے tokens کے برعکس ، تعمیر میں `Span` کی وضاحت کی ضرورت ہے۔
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` کی طرح ، لیکن ایک خام شناخت کنندہ (`r#ident`) تخلیق کرتا ہے۔
    /// `string` دلیل زبان کے ذریعہ اجازت دینے والا ایک درست شناخت کنندہ ہو (بشمول کلیدی الفاظ ، جیسے `fn`)۔
    /// مطلوبہ الفاظ جو راستے کے حصوں میں استعمال کے قابل ہیں (جیسے
    /// `self`, `سپر`) تعاون یافتہ نہیں ہیں ، اور یہ panic کا سبب بنے گا۔
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// اس `Ident` کا دورانیہ واپس کرتا ہے ، [`to_string`](Self::to_string) کے ذریعہ واپس آنے والی پوری سٹرنگ کو احاطہ کرتا ہے۔
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ممکنہ طور پر اس کی حفظان صحت کے سیاق و سباق کو تبدیل کرتے ہوئے ، اس `Ident` کا دورانیہ ترتیب دیتا ہے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB ، پل صرف `to_string` مہیا کرتا ہے ، اس کی بنیاد پر `fmt::Display` کو نافذ کرتا ہے (دونوں کے مابین معمول کے تعلقات کو الٹا)۔
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// شناخت کنندہ کو اس تار کے بطور پرنٹس کرتا ہے جو بغیر کسی نقصان کے واپس اسی شناخت کنندہ میں تبدیل ہونا چاہئے۔
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// ایک لغوی سٹرنگ (`"hello"`) ، بائٹ سٹرنگ (`b"hello"`) ، کریکٹر (`'a'`) ، بائٹ کریکٹر (`b'a'`) ، ایک عدد یا فلوٹنگ پوائنٹ نمبر جس میں بغیر کسی لاحقہ (`1` ، `1u8` ، `2.3` ، `2.3f32`) ہے۔
///
/// `true` اور `false` جیسے بولین لٹریبل یہاں سے تعلق نہیں رکھتے ہیں ، وہ. شناختی ہیں۔
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// مخصوص قدر کے ساتھ ایک نیا لاحقہ عددی لفظی تخلیق کرتا ہے۔
        ///
        /// یہ فنکشن `1u32` کی طرح ایک عددی شکل پیدا کرے گا جہاں وضاحت کی گئی انٹیگر ویلیو token کا پہلا حصہ ہے اور انٹیگرل بھی آخر میں لاحق ہوجاتا ہے۔
        /// منفی نمبروں سے تیار کردہ لٹریولز `TokenStream` یا ڈور کے ذریعے دور دور تک زندہ نہیں رہ سکتے ہیں اور اسے دو tokens (`-` اور مثبت لفظی شکل) میں توڑا جاسکتا ہے۔
        ///
        ///
        /// اس طریقہ کار کے ذریعہ تخلیق کردہ لٹریلوں میں `Span::call_site()` کا دورانیہ بطور ڈیفالٹ ہوتا ہے ، جسے ذیل میں `set_span` طریقہ سے تشکیل دیا جاسکتا ہے۔
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// مخصوص قدر کے ساتھ ایک نیا غیر منقسم عددی لفظی تخلیق کرتا ہے۔
        ///
        /// یہ فنکشن `1` جیسا عدد بنائے گا جہاں بیان کردہ انٹیجر ویلیو token کا پہلا حصہ ہے۔
        /// اس token پر کوئی لاحقہ متعین نہیں کیا گیا ہے ، مطلب یہ ہے کہ `Literal::i8_unsuffixed(1)` جیسی درخواستیں `Literal::u32_unsuffixed(1)` کے برابر ہیں۔
        /// منفی نمبروں سے تخلیق کردہ لٹریولز `TokenStream` یا ڈور کے ذریعہ rountrips سے زندہ نہیں رہ سکتے ہیں اور اسے دو tokens (`-` اور مثبت لفظی) میں توڑا جاسکتا ہے۔
        ///
        ///
        /// اس طریقہ کار کے ذریعہ تخلیق کردہ لٹریلوں میں `Span::call_site()` کا دورانیہ بطور ڈیفالٹ ہوتا ہے ، جسے ذیل میں `set_span` طریقہ سے تشکیل دیا جاسکتا ہے۔
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// ایک نیا غیر تسلی بخش فلوٹنگ پوائنٹ لفظی تخلیق کرتا ہے۔
    ///
    /// یہ کنسٹرکٹر `Literal::i8_unsuffixed` جیسے لوگوں کی طرح ہے جہاں فلوٹ کی قدر براہ راست token میں خارج ہوتی ہے لیکن کوئی لاحقہ استعمال نہیں ہوتا ہے ، لہذا یہ مرتب کرنے والے کے بعد `f64` ہونے کا اندازہ لگایا جاسکتا ہے۔
    ///
    /// منفی نمبروں سے تخلیق کردہ لٹریولز `TokenStream` یا ڈور کے ذریعہ rountrips سے زندہ نہیں رہ سکتے ہیں اور اسے دو tokens (`-` اور مثبت لفظی) میں توڑا جاسکتا ہے۔
    ///
    /// # Panics
    ///
    /// اس فنکشن کے لئے ضروری ہے کہ مخصوص فلوٹ محدود ہے ، مثال کے طور پر اگر یہ لامحدود ہے یا NAN ہے تو یہ فنکشن panic کرے گا۔
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ایک نیا لاحقہ فلوٹنگ پوائنٹ لفظی تخلیق کرتا ہے۔
    ///
    /// یہ کنسٹرکٹر `1.0f32` جیسا لٹریچر تشکیل دے گا جہاں بیان کردہ قیمت token کا سابقہ حصہ ہے اور `f32` token کا لاحقہ ہے۔
    /// اس token ہمیشہ مرتب میں `f32` ہونے کا اندازہ لگایا جائے گا۔
    /// منفی نمبروں سے تخلیق کردہ لٹریولز `TokenStream` یا ڈور کے ذریعہ rountrips سے زندہ نہیں رہ سکتے ہیں اور اسے دو tokens (`-` اور مثبت لفظی) میں توڑا جاسکتا ہے۔
    ///
    ///
    /// # Panics
    ///
    /// اس فنکشن کے لئے ضروری ہے کہ مخصوص فلوٹ محدود ہے ، مثال کے طور پر اگر یہ لامحدود ہے یا NAN ہے تو یہ فنکشن panic کرے گا۔
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// ایک نیا غیر تسلی بخش فلوٹنگ پوائنٹ لفظی تخلیق کرتا ہے۔
    ///
    /// یہ کنسٹرکٹر `Literal::i8_unsuffixed` جیسے لوگوں کی طرح ہے جہاں فلوٹ کی قدر براہ راست token میں خارج ہوتی ہے لیکن کوئی لاحقہ استعمال نہیں ہوتا ہے ، لہذا یہ مرتب کرنے والے کے بعد `f64` ہونے کا اندازہ لگایا جاسکتا ہے۔
    ///
    /// منفی نمبروں سے تخلیق کردہ لٹریولز `TokenStream` یا ڈور کے ذریعہ rountrips سے زندہ نہیں رہ سکتے ہیں اور اسے دو tokens (`-` اور مثبت لفظی) میں توڑا جاسکتا ہے۔
    ///
    /// # Panics
    ///
    /// اس فنکشن کے لئے ضروری ہے کہ مخصوص فلوٹ محدود ہے ، مثال کے طور پر اگر یہ لامحدود ہے یا NAN ہے تو یہ فنکشن panic کرے گا۔
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ایک نیا لاحقہ فلوٹنگ پوائنٹ لفظی تخلیق کرتا ہے۔
    ///
    /// یہ کنسٹرکٹر `1.0f64` جیسا لٹریچر تخلیق کرے گا جہاں کی قیمت token کا سابقہ حصہ ہے اور `1.0f64` token کا لاحقہ ہے۔
    /// اس token ہمیشہ مرتب میں `f64` ہونے کا اندازہ لگایا جائے گا۔
    /// منفی نمبروں سے تخلیق کردہ لٹریولز `TokenStream` یا ڈور کے ذریعہ rountrips سے زندہ نہیں رہ سکتے ہیں اور اسے دو tokens (`-` اور مثبت لفظی) میں توڑا جاسکتا ہے۔
    ///
    ///
    /// # Panics
    ///
    /// اس فنکشن کے لئے ضروری ہے کہ مخصوص فلوٹ محدود ہے ، مثال کے طور پر اگر یہ لامحدود ہے یا NAN ہے تو یہ فنکشن panic کرے گا۔
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// لفظی سٹرنگ۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// لفظی لفظی۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// بائٹ ڈور لفظی۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// اس لفظی کو گھیرے میں پھیلا ہوا دورانیہ۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// اس لفظی سے وابستہ اسپین کی تشکیل کرتا ہے۔
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` واپس کرتا ہے جو `self.span()` کا ایک سبسیٹ ہے جس میں `range` رینج میں صرف سورس بائٹس ہوتے ہیں۔
    /// اگر X-X X کی حد سے باہر ہے تو ، `None` واپس کرتا ہے۔
    ///
    // FIXME(SergioBenitez): چیک کریں کہ بائٹ کی حد ماخذ کی UTF-8 حد سے شروع ہوتی ہے اور اختتام پذیر ہوتی ہے۔
    // بصورت دیگر ، یہ امکان ہے کہ panic کہیں اور واقع ہو جب سورس ٹیکسٹ پرنٹ ہوگا۔
    // FIXME(SergioBenitez): صارف کے لئے یہ جاننے کے لئے کوئی راستہ نہیں ہے کہ `self.span()` دراصل نقشہ جات کی تشکیل کرتا ہے ، لہذا اس طریقہ کو فی الحال صرف آنکھیں بند کیا جاسکتا ہے۔
    // مثال کے طور پر ، 'c' کردار کے لئے `to_string()` "'\u{63}'" کی واپسی کرتا ہے۔صارف کے لئے یہ جاننے کا کوئی طریقہ نہیں ہے کہ آیا ماخذ کا متن 'c' تھا یا یہ '\u{63}' تھا۔
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` کے مترادف کچھ ، لیکن `Bound<&T>` کے لئے۔
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB ، پل صرف `to_string` مہیا کرتا ہے ، اس کی بنیاد پر `fmt::Display` کو نافذ کرتا ہے (دونوں کے مابین معمول کے تعلقات کو الٹا)۔
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// لغوی کو اس تار کے بطور پرنٹس کرتا ہے جو ایک ہی لغوی شکل میں بغیر کسی نقصان کے بدلنا پڑے۔ (سواں نقطہ لٹریلز کے لئے ممکنہ گول کے علاوہ)۔
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ماحول کے متغیر تک رسائی حاصل کی۔
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ماحول کے متغیر کو بازیافت کریں اور انحصار کی معلومات کی تعمیر کے ل. اس میں شامل کریں۔
    /// مرتب کرنے والے بلڈ سسٹم کو پتہ چل جائے گا کہ تغیر کے دوران متغیر تک رسائی حاصل کی گئی تھی ، اور جب اس متغیر کی قدر میں تبدیلی آتی ہے تو وہ دوبارہ تشکیل دینے میں کامیاب ہوجائے گا۔
    ///
    /// انحصار سے باخبر رہنے کے علاوہ اس فنکشن کو معیاری لائبریری سے `env::var` کے برابر ہونا چاہئے ، سوائے اس کے کہ یہ دلیل UTF-8 کا ہونا ضروری ہے۔
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}