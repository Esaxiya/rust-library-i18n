//! `Cell` (scoped) وجودی زندگی کے مختلف حالتوں میں

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// زندگی بھر کے ساتھ لیمبڈا ایپلی کیشن ٹائپ کریں۔
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// زندگی بھر کا لیمبڈا ٹائپ کریں ، یعنی ، `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) newtype FIXME(#52812) کے ساتھ پروجیکشن کی حدود کے بارے میں `&'a mut <T as ApplyL<'b>>::Out` کی جگہ لے لے
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` چلاتے ہوئے `self` میں ویلیو `replacement` پر سیٹ کرتا ہے ، جو پرانی قیمت مل جاتی ہے ، باہمی طور پر۔
    /// پرانی قدر `f` کے اخراج کے بعد بحال ہوجائے گی ، یہاں تک کہ panic بھی ، بشمول `f` کے ذریعہ اس میں کی گئی ترمیم بھی شامل ہے۔
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// ریپر جو یہ یقینی بناتا ہے کہ سیل ہمیشہ پُر ہوجائے (اصل حالت کے ساتھ ، `f` کے ذریعہ اختیاری طور پر تبدیل کیا گیا ہے) ، یہاں تک کہ اگر `f` گھبرا گیا ہو۔
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` چلاتے ہوئے `self` میں ویلیو `value` پر سیٹ کریں۔
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}