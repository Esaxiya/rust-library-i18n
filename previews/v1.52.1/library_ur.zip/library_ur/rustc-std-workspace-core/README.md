# `rustc-std-workspace-core` crate

یہ crate ایک چمک اور خالی crate ہے جو صرف `libcore` پر منحصر ہے اور اس کے تمام مشمولات کی بازیافت کرتا ہے۔
زیڈ0 کریٹ0 زیڈ crates.io سے crates پر انحصار کرنے کے لئے معیاری لائبریری کو بااختیار بنانے کا چال ہے

crates.io پر Crates کہ معیاری لائبریری crates.io سے `rustc-std-workspace-core` crate پر انحصار کرنے کی ضرورت پر منحصر ہے ، جو خالی ہے۔

ہم اس ذخیرے میں اس crate پر اسے اوور رائڈ کرنے کے لئے `[patch]` استعمال کرتے ہیں۔
نتیجہ کے طور پر ، crates.io پر crates X0Xge0Z پر `libcore` پر انحصار کرے گا ، جو اس ذخیرے میں بیان کردہ ورژن ہے۔
Cargo کامیابی کے ساتھ crates بناتا ہے اس بات کو یقینی بنانے کے لئے انحصار کے سارے کناروں کو کھینچنا چاہئے!

نوٹ کریں کہ crates.io پر crates کو ہر کام کے صحیح طریقے سے کام کرنے کیلئے `core` نام کے ساتھ اس crate پر انحصار کرنے کی ضرورت ہے۔ایسا کرنے کے لئے کہ وہ استعمال کرسکتے ہیں:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` کلید کے استعمال کے ذریعے ، crate کا نام تبدیل کرکے `core` کردیا گیا ، مطلب یہ ہوگا کہ ایسا ہی ہوگا۔

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

جب Cargo کمپلر کی درخواست کرتا ہے ، تالیف دہندگان کے ذریعہ انجکشن کردہ `extern crate core` ہدایت کو مطمئن کرتے ہوئے۔




