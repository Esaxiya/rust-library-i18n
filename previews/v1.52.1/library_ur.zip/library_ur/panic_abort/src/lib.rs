//! عمل ضائع ہونے کے ذریعے Rust panics کا نفاذ
//!
//! جب انوائنڈنگ کے ذریعے عمل درآمد سے موازنہ کیا جائے تو ، یہ crate *بہت زیادہ* آسان ہے!یہ کہا جارہا ہے ، یہ اتنا زیادہ ورسٹائل نہیں ہے ، لیکن یہاں جاتا ہے!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" سوال میں پلیٹ فارم پر متعلقہ اسقاط حمل پر پے لوڈ اور شیم۔
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal پر کال کریں
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows پر ، پروسیسر کے لئے مخصوص __festfail میکانزم کا استعمال کریں۔Windows 8 اور بعد میں ، اس میں بغیر کسی عمل میں رعایت کے ہینڈلر چلائے عمل کو فوری طور پر ختم کردے گا۔
            // Windows کے سابقہ ورژن میں ، ہدایات کے اس سلسلے کو عمل کی تکمیل کرتے ہوئے ، رسائی کی خلاف ورزی کے طور پر سمجھا جائے گا لیکن بغیر کسی استثناء کے تمام ہینڈلرز کو نظرانداز کئے بغیر۔
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: یہ وہی عمل ہے جس کی طرح لِبسٹڈی کے `abort_internal` ہے
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// یہ ... ایک عجیب سی بات ہےٹی ایل؛ ڈاکٹر؛یہ ہے کہ اس کو صحیح طریقے سے جوڑنا ضروری ہے ، طویل وضاحت نیچے ہے۔
//
// ابھی ہم libcore/libstd کی بائنریز جو ہم بھیجتے ہیں وہ سب `-C panic=unwind` کے ساتھ مرتب کیے گئے ہیں۔یہ یقینی بنانے کے ل is کیا جاتا ہے کہ بائنری زیادہ سے زیادہ حالات کے مطابق زیادہ سے زیادہ مطابقت پذیر ہوں۔
// تاہم ، مرتب کرنے والے کو `-C panic=unwind` کے ساتھ مرتب تمام افعال کے لئے "personality function" کی ضرورت ہے۔یہ شخصیت کا فعل `rust_eh_personality` کی علامت پر مشتمل ہے اور اس کی وضاحت `eh_personality` لینگ آئٹم کے ذریعہ کی گئی ہے۔
//
// So...
// کیوں نہیں صرف اس لینگ آئٹم کی وضاحت؟اچھا سوال!جس طرح سے panic رن ٹائم سے جڑا ہوا ہے وہ دراصل تھوڑا سا لطیف ہے جس میں وہ کمپلر کے crate اسٹور میں "sort of" ہیں ، لیکن صرف اس صورت میں منسلک ہوتا ہے جب دوسرا اصل میں لنک نہیں ہوتا ہے۔
//
// اس کا مطلب یہ ہے کہ یہ crate اور panic_unwind crate دونوں ہی مرتب کرنے والے crate اسٹور میں ظاہر ہوسکتے ہیں ، اور اگر دونوں `eh_personality` لینگ آئٹم کی وضاحت کریں تو اس سے غلطی ہوگی۔
//
// اس کو سنبھالنے کے لئے صرف `eh_personality` کی وضاحت کی ضرورت ہوتی ہے اگر panic رن ٹائم منسلک کیا جارہا ہے جب ناپسندیدہ رن ٹائم ہوتا ہے ، اور بصورت دیگر اس کی وضاحت کرنے کی ضرورت نہیں ہوتی ہے (بجا طور پر)۔
// تاہم ، اس معاملے میں ، یہ لائبریری صرف اس علامت کی وضاحت کرتی ہے لہذا کہیں نہ کہیں کم از کم کوئی شخصیت آجائے۔
//
// بنیادی طور پر یہ علامت صرف libcore/libstd بائنریز تک وائر لانے کے ل is بیان کی گئی ہے ، لیکن اسے کبھی بھی نہیں بلایا جانا چاہئے کیوں کہ ہم کسی ناپسندیدہ رن ٹائم کے ساتھ جڑتے نہیں ہیں۔
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // x86_64-pc-Windows-gnu پر ہم اپنی شخصیت کا فنکشن استعمال کرتے ہیں جس میں `ExceptionContinueSearch` کو واپس کرنے کی ضرورت ہوتی ہے کیونکہ ہم اپنے تمام فریموں پر گزر رہے ہیں۔
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // مذکورہ بالا کی طرح ، یہ `eh_catch_typeinfo` لینگ آئٹم سے مطابقت رکھتا ہے جو فی الحال صرف اسیم سکرین پر استعمال ہوتا ہے۔
    //
    // چونکہ panics استثنا پیدا نہیں کرتا ہے اور غیر ملکی استثناء فی الحال -C panic=اسقاط کے ساتھ UB ہیں (حالانکہ اس میں تبدیلی لائی جا سکتی ہے) ، لہذا کوئی بھی کیچ_ ونڈ کال اس ٹائپ انفو کا استعمال نہیں کرے گا۔
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // ان دونوں کو ہمارے شروعاتی اشیاء نے i686-pc-Windows-gnu پر کہا ہے ، لیکن ان کو کچھ کرنے کی ضرورت نہیں ہے لہذا لاشیں بند ہو گئیں۔
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}