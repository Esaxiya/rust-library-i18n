# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate کے لئے دستاویزات دیکھیں۔