//! panics پر عمل درآمد libgcc/libunwind (کسی نہ کسی شکل میں) کی حمایت حاصل ہے۔
//!
//! استثناء کو سنبھالنے اور غیر منسلک کرنے کے پس منظر کے لئے ، براہ کرم "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) اور اس سے منسلک دستاویزات دیکھیں۔
//! یہ بھی اچھے پڑھے لکھے ہیں:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## ایک مختصر خلاصہ
//!
//! استثناء کی ہینڈلنگ دو مراحل میں ہوتی ہے: تلاش کا مرحلہ اور صفائی کا مرحلہ۔
//!
//! دونوں مراحل میں انویندر اسٹیک فریم سے موجودہ عمل کے ماڈیولز کے حصwہ کو کھولنے والی معلومات کا استعمال کرتے ہوئے اوپر سے نیچے تک اسٹیک فریموں کو چلتا ہے (یہاں "module" ایک OS ماڈیول سے مراد ہے ، یعنی ایک قابل عمل یا متحرک لائبریری)۔
//!
//!
//! ہر اسٹیک فریم کے ل it ، اس سے وابستہ "personality routine" کا مطالبہ کیا جاتا ہے ، جس کا پتہ بھی ان ونڈ انفارمیشن سیکشن میں اسٹور کیا جاتا ہے۔
//!
//! تلاش کے مرحلے میں ، شخصیت کے معمول کا کام مستثنیٰ چیز کو پھینک دینے کی جانچ کرنا ہے اور فیصلہ کرنا ہے کہ آیا اس اسٹیک فریم میں اسے پکڑا جانا چاہئے یا نہیں۔ایک بار ہینڈلر فریم کی شناخت ہوجانے کے بعد ، صفائی کا مرحلہ شروع ہوجاتا ہے۔
//!
//! صفائی کے مرحلے میں ، انویندر ہر شخصی شخصیت کو دوبارہ معمول پر لاتا ہے۔
//! اس بار یہ فیصلہ کرتا ہے کہ موجودہ اسٹیک فریم کے لئے کون سا (اگر کوئی ہے) صفائی کوڈ چلانے کی ضرورت ہے۔اگر ایسا ہے تو ، کنٹرول کو فنکشن باڈی ، "landing pad" میں ایک خصوصی branch میں منتقل کردیا گیا ہے ، جو تباہ کنوں کو طلب کرتا ہے ، میموری کو آزاد کرتا ہے ، وغیرہ۔
//! لینڈنگ پیڈ کے اختتام پر ، کنٹرول کو انویندر اور ناپسندیدہ ریزیومیس میں واپس منتقل کردیا گیا ہے۔
//!
//! ایک بار جب اسٹیک ہینڈلر فریم لیول تک بے حد ہوجاتا ہے تو ، ناپسندیدہ رک جاتا ہے اور شخصیت کی آخری معمولات کا کنٹرول کیچ بلاک میں منتقل ہوتا ہے۔
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust کا استثناء کلاس شناخت کنندہ۔
// یہ شخصیت کے معمولات کے ذریعہ استعمال کیا جاتا ہے اس بات کا تعین کرنے کے لئے کہ آیا رعایت ان کے اپنے رن ٹائم کے ذریعہ پھینک دی گئی ہے۔
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-فروش ، زبان
    0x4d4f5a_00_52555354
}

// رجسٹرڈ آئی ڈی ایل ایل وی ایم کے TargetLowering::getExceptionPointerRegister() اور TargetLowering::getExceptionSelectorRegister() سے ہر فن تعمیر کے ل lifted اٹھایا گیا ، پھر رجسٹریشن ڈیبلز (عام طور پر رجسٹر ڈیفینیشن ٹیبلز) کے ذریعہ ڈورف رجسٹر نمبروں پر نقش ہوجائے<arch>RegisterInfo.td ، "DwarfRegNum" کی تلاش کریں)۔
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register بھی دیکھیں۔
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX ، EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX ، RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0 ، X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3 ، X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// مندرجہ ذیل کوڈ GCC کے C اور C++ شخصیت کے معمولات پر مبنی ہے۔حوالہ کے لئے ، دیکھیں:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI کی شخصیت کا معمول۔
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS اس کے بجائے پہلے سے طے شدہ روٹین کا استعمال کرتا ہے کیونکہ اس میں SjLj ان ونڈنگ کا استعمال ہوتا ہے۔
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // اے آر ایم پر بیک ٹریس شخصیت کے معمول کو ریاست کے ساتھ کہتے ہیں==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND۔
                // ان معاملات میں ہم اسٹیک کو ختم کرنا جاری رکھنا چاہتے ہیں ، بصورت دیگر ہمارے تمام پچھلے نشانات __rust_try پر ختم ہوجائیں گے
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // ڈی او آر ایف انویندر یہ فرض کرتا ہے کہ _ ان ونڈ_کنسٹکس فنکشن اور ایل ایس ڈی اے پوائنٹرز جیسی چیزوں کو تھامے ہوئے ہے ، تاہم آرمی ایہابی ان کو استثناء آبجیکٹ میں رکھ دیتی ہے۔
            // _Unwind_GetLanguageSpecificData() جیسے افعال کے دستخطوں کو محفوظ رکھنے کے ل which ، جو صرف سیاق و سباق کا اشارہ ہی لیتے ہیں ، GCC شخصیت کے معمولات اشارے میں ایک اشارے کو استثناء_موجودہ کرکے ، ARM کے "scratch register" (r12) کے لئے مختص جگہ کا استعمال کرتے ہوئے اسٹش کرتے ہیں۔
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... ایک اور اصولی نقطہ نظر یہ ہوگا کہ ہماری آزادانہ منسلک پابندیوں میں اے آر ایم کے _ یونٹ ونڈ_کے متن کی مکمل تعریف فراہم کی جائے اور وہاں سے مطلوبہ اعداد و شمار کو براہ راست ڈورٹ مطابقت کے افعال کو نظرانداز کیا جائے۔
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI استثناء آبجیکٹ کی رکاوٹ کیشے میں ایس پی ویلیو کو اپ ڈیٹ کرنے کے لئے شخصیت کے معمولات کی ضرورت ہوتی ہے۔
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // آرم EHABI پر ، شخصیت کی روٹین واپسی سے پہلے دراصل کسی ایک اسٹیک فریم کو ختم کرنے کے لئے ذمہ دار ہے۔ (آرمی ایہابی سیکنڈ)
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc میں بیان ہوا
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // پہلے سے طے شدہ شخصیت کا معمول ، جو زیادہ تر اہداف پر اور بالواسطہ SEH کے ذریعے Windows x86_64 پر استعمال ہوتا ہے۔
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW اہداف پر ، انوائنڈنگ میکانزم SEH ہے تاہم ان ونڈ ہینڈلر ڈیٹا (عرف LSDA) GCC-کے موافق موافقت پذیری کو استعمال کرتا ہے۔
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // ہمارے بیشتر اہداف کے لئے شخصیت کا معمول۔
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // واپسی ایڈریس پوائنٹس 1 بائٹ کال انسٹرکشن سے گذشتہ ، جو ایل ایس ڈی اے رینج ٹیبل میں اگلی آئی پی رینج میں ہوسکتی ہے۔
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// فریم unwind معلومات کے اندراج
//
// ہر ماڈیول کی شبیہہ میں ایک فریم انوائنڈ انفارمیشن سیکشن ہوتا ہے (عام طور پر ".eh_frame")۔جب ایک ماڈیول اس عمل میں loaded/unloaded ہے تو ، انویندر کو میموری میں اس حصے کے مقام کے بارے میں آگاہ کرنا ضروری ہے۔پلیٹ فارم کے ذریعہ مختلف ہونے کے حصول۔
// کچھ (مثال کے طور پر ، Linux) پر ، انویندر اپنے طور پر ان ونڈ انفارمیشن سیکشنز دریافت کرسکتے ہیں (dl_iterate_phdr() API and finding their ".eh_frame" sections) کے ذریعہ موجودہ طور پر بھری ہوئی ماڈیولوں کی متحرک طور پر گنتی کرتے ہیں Others دوسرے ، Windows کی طرح ، انوندر API کے ذریعہ ان ونڈ انفارمیشن سیکشن کو فعال طور پر رجسٹر کرنے کے لئے ماڈیول کی ضرورت ہوتی ہے۔
//
//
// یہ ماڈیول دو علامتوں کی وضاحت کرتا ہے جن کا حوالہ دیتے ہوئے 0GCC رن ٹائم کے ساتھ ہماری معلومات کو رجسٹر کرنے کے لئے rsbegin.rs سے بلایا جاتا ہے۔
// اسٹیک ان ونڈنگ کے نفاذ کو (ابھی کے ل)) لیبگ سی سی_ح کے لئے موخر کردیا گیا ہے ، تاہم Rust crates کسی بھی GCC رن ٹائم کے ساتھ ممکنہ جھڑپوں سے بچنے کے لئے ان Rust سے متعلق مخصوص داخلی نکات کا استعمال کرتا ہے۔
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}