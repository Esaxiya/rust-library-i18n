//! میری کیلئے panics کو ختم نہیں کرنا۔
use alloc::boxed::Box;
use core::any::Any;

// میٹری انجن ہمارے ل un بغیر رکاوٹ کے ذریعے پے لوڈ کی جس قسم کا تشہیر کرتا ہے۔
// پوائنٹر سائز کا ہونا ضروری ہے۔
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// مائنی فراہم کردہ بیرونی فنکشن غیر منسلک ہونا شروع کرنے کے لئے۔
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // ہم `miri_start_panic` پر جو پے لوڈ گزرتے ہیں وہی دلیل ہوگی جو ہمارے نیچے `cleanup` میں ملتی ہے۔
    // لہذا ہم کچھ پوائنٹر سائز کے ل get ، ایک بار صرف اس کا باکس بناتے ہیں۔
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // بنیادی `Box` بازیافت کریں۔
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}