//! Windows SEH
//!
//! Windows پر (فی الحال صرف MSVC پر) ، پہلے سے طے شدہ استثناء کو سنبھالنے کا طریقہ کار اسٹرکچرڈ استثنا ہینڈلنگ (SEH) ہے۔
//! یہ کمپارٹر انٹرنلز کے معاملے میں بونے پر مبنی استثنا سے متعلق ہینڈلنگ (جیسے ،unix X کے دوسرے پلیٹ فارم کیا استعمال کرتے ہیں) سے بالکل مختلف ہے ، لہذا ایل ایل وی ایم کو ایس ای ایچ کے لئے اضافی معاونت کا ایک اچھا سودا حاصل کرنے کی ضرورت ہے۔
//!
//! مختصر طور پر ، یہاں جو ہوتا ہے وہ یہ ہے:
//!
//! 1. ایکس 100 ایکس فنکشن معیاری Windows فنکشن `_CxxThrowException` کو C++ پھینکنے کے لئے کال کرتا ہے-جیسے استثناء کی طرح ، ناپسندیدہ عمل کو متحرک کرتا ہے۔
//! 2.
//! مرتب کرنے والے کے ذریعہ تیار کردہ تمام لینڈنگ پیڈس شخصی فنکشن `__CxxFrameHandler3` ، CRT میں ایک فنکشن ، اور Windows میں غیر منسلک کوڈ کا استعمال کرتے ہیں تاکہ اسٹیک پر موجود تمام صفائی کوڈ کو پھانسی دے سکے۔
//!
//! 3. `invoke` پر بھیجنے والی تمام کمپلرز میں `cleanuppad` LLVM انسٹرکشن کی حیثیت سے لینڈنگ پیڈ لگا ہوا ہے ، جو صفائی کے معمول کے آغاز کی طرف اشارہ کرتا ہے۔
//! شخصیت (مرحلہ 2 میں ، CRT میں بیان کردہ) صفائی معمولات کو چلانے کے لئے ذمہ دار ہے۔
//! 4. آخر کار `try` انٹرنک (کمپائلر کے ذریعہ تیار کردہ) میں "catch" کوڈ کو پھانسی دے دی گئی ہے اور اس بات کا اشارہ ہے کہ کنٹرول Rust پر واپس آنا چاہئے۔
//! یہ LLVM IR اصطلاحات میں `catchswitch` کے علاوہ `catchpad` ہدایات کے ذریعے کیا جاتا ہے ، اور آخر میں `catchret` کی ہدایت کے ساتھ پروگرام میں معمول کا کنٹرول واپس کرتا ہے۔
//!
//! gcc پر مبنی استثناء ہینڈلنگ سے کچھ مخصوص اختلافات یہ ہیں:
//!
//! * Rust میں اپنی مرضی کے مطابق شخصیت کا کوئی فنکشن نہیں ہے ، اس کی بجائے ہمیشہ * `__CxxFrameHandler3` ہوتا ہے۔مزید برآں ، کوئی اضافی فلٹرنگ نہیں کی جاتی ہے ، لہذا ہم کسی بھی C++ استثناء کو پکڑ لیتے ہیں جو اس طرح دکھائی دیتا ہے جیسے ہم پھینک رہے ہو۔
//! نوٹ کریں کہ Rust میں ایک استثنا پھینکنا ویسے بھی غیر متعین سلوک ہے ، لہذا یہ ٹھیک ہونا چاہئے۔
//! * ہمارے پاس غیر منسلک حدود کو منتقل کرنے کے لئے کچھ اعداد و شمار مل چکے ہیں ، خاص طور پر ایک `Box<dyn Any + Send>`۔بونے مستثنیات کی طرح ، یہ بھی دو نکتہ استثناء میں ہی ایک تنخواہ کے طور پر ذخیرہ ہوتے ہیں۔
//! ایم ایس وی سی پر ، تاہم ، اضافی ڈھیر مختص کرنے کی ضرورت نہیں ہے کیونکہ کال اسٹیک محفوظ ہے جبکہ فلٹر کے کام انجام دے رہے ہیں۔
//! اس کا مطلب یہ ہے کہ پوائنٹس کو براہ راست `_CxxThrowException` پر منتقل کیا جاتا ہے جو اس کے بعد فلٹر فنکشن میں برآمد ہوجاتے ہیں تاکہ اسے `try` انٹرنس کے اسٹیک فریم میں لکھا جاسکے۔
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // اس کا آپشن ہونے کی ضرورت ہے کیونکہ ہم حوالہ کے لحاظ سے رعایت کو پکڑتے ہیں اور اس کا ڈسٹرکٹر C++ رن ٹائم کے ذریعہ سرانجام دیتا ہے۔
    // جب ہم باکس کو استثناء سے ہٹاتے ہیں تو ، ہمیں اس استثناء کو کسی صحیح حالت میں چھوڑنے کی ضرورت ہے تاکہ اس کے ڈسٹرکٹر کے پاس باکس کو ڈبل ڈراپ کیے بغیر چلائے جا run۔
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// سب سے پہلے ، پوری طرح کی تعریفوں کا ایک مجموعہ۔یہاں پلیٹ فارم سے متعلق مخصوص عجیب و غریب کیفیتیں ہیں ، اور بہت ساری باتیں جن کا صرف LLVM سے صریحا cop نقل کیا گیا ہے۔اس سب کا مقصد X001 پر کال کے ذریعے نیچے `panic` فنکشن کو نافذ کرنا ہے۔
//
// یہ فنکشن دو دلائل لیتا ہے۔سب سے پہلے اس اعداد و شمار کی نشاندہی کی جاتی ہے جس میں ہم گزر رہے ہیں ، جو اس معاملے میں ہماری trait آبجیکٹ ہے۔بہت آسان تلاش کرنے کے لئے!اگلا ، تاہم ، زیادہ پیچیدہ ہے۔
// یہ ایک `_ThrowInfo` ڈھانچے کی طرف اشارہ ہے ، اور عام طور پر اس کا مقصد صرف پھینک دی جانے والی رعایت کی وضاحت کرنا ہے۔
//
// فی الحال اس قسم کی [1] کی تعریف تھوڑا سا بالوں والی ہے ، اور بنیادی عجیبیت (اور آن لائن آرٹیکل سے فرق) یہ ہے کہ 32 بٹ پر پوائنٹس پوائنٹر ہیں لیکن 64 بٹ پر پوائنٹرز کو 32 بٹ آفسیٹس کے طور پر ظاہر کیا گیا ہے `__ImageBase` علامت۔
//
// اس کے اظہار کے لئے نیچے دیئے گئے ماڈیولز میں `ptr_t` اور `ptr!` میکرو استعمال کیے گئے ہیں۔
//
// قسم کی تعریف کی بھولبلییا بھی قریب سے اس کی پیروی کرتی ہے جو ایل ایل وی ایم اس طرح کے آپریشن کے لئے خارج کرتا ہے۔مثال کے طور پر ، اگر آپ MSVC پر یہ C++ کوڈ مرتب کرتے ہیں اور LLVM IR کو خارج کرتے ہیں:
//
//      #include <stdint.h>
//
//      ڈھانچہ مورچا_پانیک {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2]؛}؛
//
//      باطل foo() { rust_panic a = {0, 1}؛
//          پھینک دو؛}
//
// یہی بنیادی طور پر ہم تقلید کرنے کی کوشش کر رہے ہیں۔ذیل میں زیادہ تر مستقل اقدار صرف ایل ایل وی ایم سے کاپی کی گئیں ،
//
// بہرحال ، یہ ڈھانچے سب اسی طرح سے تعمیر کیے گئے ہیں ، اور یہ ہمارے لئے کچھ حد تک زبانی ہے۔
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// نوٹ کریں کہ ہم جان بوجھ کر یہاں نام ملنگ کے قواعد کو نظرانداز کرتے ہیں: ہم نہیں چاہتے ہیں کہ C++ Rust panics کو صرف `struct rust_panic` کا اعلان کرکے پکڑ سکے۔
//
//
// ترمیم کرتے وقت ، اس بات کو یقینی بنائیں کہ ٹائپ نیم سٹرنگ `compiler/rustc_codegen_llvm/src/intrinsic.rs` میں استعمال ہونے والے ونڈو سے بالکل مماثل ہے۔
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // یہاں کا معروف `\x01` بائٹ دراصل LLVM کا جادوئی سگنل ہے * `_` حرف کے ساتھ کسی دوسرے طرح کے منگلنگ کی طرح لگانا نہیں۔
    //
    //
    // یہ علامت vtable ہے جو C++ s `std::type_info` کے ذریعہ استعمال ہوتا ہے۔
    // قسم `std::type_info` ، ٹائپ ڈسکریپٹر کے آبجیکٹ میں اس جدول کا اشارہ ہے۔
    // قسم کی وضاحت کرنے والوں کا حوالہ C++ EH ڈھانچے کے ذریعہ دیا گیا ہے جو اوپر بیان کی گئی ہیں اور جو ہم ذیل میں بناتے ہیں۔
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// اس قسم کا ڈسریکٹر صرف اس صورت میں استعمال ہوتا ہے جب استثناء پھینک دیں۔
// کیچ کے حصے کو ٹیس انٹریسک نے سنبھالا ہے ، جو اپنا ٹائپ ڈیسکرپٹر تیار کرتا ہے۔
//
// یہ ٹھیک ہے کیوں کہ ایم ایس وی سی رن ٹائم پوائنٹر مساوات کے بجائے ٹائپ ڈیسکرپٹرس سے ملنے کے لئے ٹائپ نام پر سٹرنگ موازنہ استعمال کرتا ہے۔
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// ڈسٹرکٹر استعمال کیا جاتا ہے اگر C++ کوڈ اس رعایت پر قبضہ کرنے کا فیصلہ کرتا ہے اور اسے پھیلائے بغیر چھوڑ دیتا ہے۔
// کوشش کے اندرونی حصے کا کیچ والا حصہ استثناء آبجیکٹ کا پہلا لفظ 0 پر مرتب کرے گا تاکہ اسے ڈسٹرکٹر کے ذریعہ چھوڑ دیا جائے۔
//
// نوٹ کریں کہ x86 Windows پہلے سے طے شدہ "C" کالنگ کنونشن کے بجائے C++ ممبر کے افعال کے لئے "thiscall" کالنگ کنونشن کا استعمال کرتا ہے۔
//
// رعایت_کاپی فنکشن یہاں تھوڑا خاص ہے: یہ ایک try/catch بلاک کے تحت MSVC رن ٹائم کے ذریعہ شروع کیا گیا ہے اور panic جو ہم یہاں پیدا کرتے ہیں اسے استثنیٰ کاپی کے نتیجے میں استعمال کیا جائے گا۔
//
// یہ C++ رن ٹائم کے ذریعہ std::exception_ptr کے ساتھ مستثنیات کی گرفتاری کی حمایت کرنے کے لئے استعمال ہوتا ہے ، جس کی ہم حمایت نہیں کرسکتے کیونکہ باکس<dyn Any>کلونبل نہیں ہے
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException اس اسٹیک فریم پر مکمل طور پر عملدرآمد کرتا ہے ، لہذا `data` کو ڈھیر میں منتقل کرنے کی ضرورت نہیں ہے۔
    // ہم صرف اس فنکشن میں اسٹیک پوائنٹر منتقل کرتے ہیں۔
    //
    // یہاں دستی ڈراپ کی ضرورت ہے کیونکہ ہم نہیں چاہتے ہیں کہ جب رعایت نہیں ہوتی تو استثناء گرایا جائے۔
    // اس کے بجائے اسے استثناء_کلین اپ کے ذریعہ چھوڑ دیا جائے گا جسے C++ رن ٹائم کے ذریعہ طلب کیا گیا ہے۔
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // یہ ... حیرت انگیز لگ سکتا ہے ، اور جواز کے مطابق بھی۔32 بٹ ایم ایس وی سی پر ان ڈھانچے کے مابین پوائنٹرز صرف وہی ہیں ، جو پوائنٹر ہیں۔
    // تاہم ، 64 بٹ ایم ایس وی سی پر ، ڈھانچوں کے مابین پوائنٹر کو `__ImageBase` سے 32 بٹ آفسیٹس کے بجا. ظاہر کیا جاتا ہے۔
    //
    // اس کے نتیجے میں ، 32 بٹ ایم ایس وی سی پر ہم مذکورہ بالا جامد میں ان تمام نکات کا اعلان کرسکتے ہیں۔
    // -64 بٹ ایم ایس وی سی پر ، ہمیں اعدادوشمار میں پوائنٹس کے گھٹاؤ کا اظہار کرنا پڑے گا ، جس کی Rust فی الحال اجازت نہیں دیتی ہے ، لہذا ہم واقعتا یہ نہیں کرسکتے ہیں۔
    //
    // اگلی سب سے اچھی چیز ، اس کے بعد رن ٹائم پر ان ڈھانچے کو پُر کرنا ہے (گھبرانا پہلے سے ہی "slow path" ہے۔)
    // لہذا یہاں ہم ان تمام پوائنٹر فیلڈز کو 32 بٹ انٹیجر کے طور پر دوبارہ تشریح کرتے ہیں اور پھر اس میں متعلقہ ویلیو اسٹور کرتے ہیں (ایٹمی طور پر ، جیسا کہ ہم آہنگ panics ہو رہا ہے)۔
    //
    // تکنیکی طور پر رن ٹائم ممکنہ طور پر ان شعبوں کو ایک غیر فطری مطالعہ کرے گا ، لیکن نظریہ میں انہوں نے کبھی بھی *غلط* قدر کو نہیں پڑھا لہذا یہ زیادہ خراب نہیں ہونا چاہئے ...
    //
    // کسی بھی صورت میں ، ہمیں بنیادی طور پر ایسا کچھ کرنے کی ضرورت ہے جب تک کہ ہم اعدادوشمار میں زیادہ کاموں کا اظہار نہ کرسکیں (اور ہم کبھی بھی اس قابل نہیں ہوسکتے ہیں)۔
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // یہاں ایک NULL پے لوڈ کا مطلب ہے کہ ہم یہاں ____ rust_try کے (...) کیچ سے آئے ہیں۔
    // ایسا ہوتا ہے جب Rust غیر غیر معمولی رعایت پکڑی جاتی ہے۔
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// یہ مرتب کرنے والے کے پاس موجود رہنے کے لئے ضروری ہے (مثال کے طور پر ، یہ ایک لینگ آئٹم ہے) ، لیکن اس کو مرتب کرنے والے نے حقیقت میں کبھی نہیں کہا کیونکہ __C_specific_handler یا _except_handler3 وہ شخصیت کا فعل ہے جو ہمیشہ استعمال ہوتا ہے۔
//
// لہذا یہ صرف اسقاط ضد ہے۔
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}