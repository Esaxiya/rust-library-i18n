//! panics نفاذ اسٹیک کے ذریعے عمل درآمد
//!
//! یہ crate Rust میں panics پر عمل درآمد ہے جس کے لئے "most native" اسٹیک غیر منسلک طریقہ کار استعمال کیا جارہا ہے۔
//! اس کو فی الحال تین بالٹیوں میں درجہ بندی کرنا پڑتا ہے۔
//!
//! 1. ایم ایس وی سی اہداف `seh.rs` فائل میں SEH کا استعمال کرتے ہیں۔
//! 2. ایمسکریپٹن `emcc.rs` فائل میں C++ مستثنیات کا استعمال کرتا ہے۔
//! 3. `gcc.rs` فائل میں دوسرے تمام اہداف libunwind/libgcc کا استعمال کرتے ہیں۔
//!
//! ہر عمل کے بارے میں مزید دستاویزات متعلقہ ماڈیول میں مل سکتی ہیں۔
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` میری کے ساتھ غیر استعمال شدہ ہے ، لہذا خاموشی کا انتباہ۔
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust رن ٹائم کے آغاز کی چیزیں ان علامتوں پر منحصر ہوتی ہیں ، لہذا انہیں عوامی بنائیں۔
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // اہداف جو ناپسندیدہ کی حمایت نہیں کرتے ہیں۔
        // - arch=wasm32
        // - OS=کوئی نہیں ("bare metal" اہداف)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // میری رن ٹائم کا استعمال کریں۔
        // ہمیں ابھی بھی اوپر کا معمول رن ٹائم لوڈ کرنے کی ضرورت ہے ، کیونکہ rustc توقع کرتا ہے کہ وہاں سے کچھ لینگ آئٹمز کی وضاحت کی جائے۔
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // اصل رن ٹائم کا استعمال کریں۔
        use real_imp as imp;
    }
}

extern "C" {
    /// جب panic آبجیکٹ کو `catch_unwind` سے باہر چھوڑ دیا جاتا ہے تو libstd میں ہینڈلر کہا جاتا ہے۔
    ///
    fn __rust_drop_panic() -> !;

    /// غیر ملکی استثناء پکڑے جانے پر لیبلسٹ ہینڈلر کو فون کیا جاتا ہے۔
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// کسی استثنا کو بڑھانے کے لئے داخلہ نقطہ ، صرف پلیٹ فارم سے مخصوص نفاذ کے نمائندے۔
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}