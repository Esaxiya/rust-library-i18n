//! Ny trano famakiam-boky ho an'ny macro fanohanana mpanoratra rehefa mamaritra macros vaovao.
//!
//! Ity trano famakiam-boky ity, izay omen'ny fizarana mahazatra, dia manome ireo karazana lanin'ny famaritana ny famaritana makrônika voafaritra toy ny macros `#[proc_macro]`, ny toetran'ny makro `#[proc_macro_attribute]` ary ny toetra azo avy amin'ny fanao mahazatra#[proc_macro_derive] `.
//!
//!
//! Jereo [the book] kokoa.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Famaritana raha efa natao azo idirana amin'ilay programa mandeha izao ny proc_macro.
///
/// Ny proc_macro crate ihany no natao ho ampiasaina ao anatin'ny ny fampiharana ny fomba fanatanterahana indray macros.Ny miasa eo crate ity panic raha hampiharina avy any ivelany ny fomba fanatanterahana indray macro, toy ny avy amin'ny manaova soratra, na fitsapana, na olon-tsotra tarika Rust mimari-droa.
///
/// Miaraka amin'ny fandinihana ireo trano famakiam-boky Rust izay natao hanohanana ny tranga fampiasana makro sy tsy fampiasana makro, ny `proc_macro::is_available()` dia manome fomba tsy hikoropahana hamantarana raha misy izao fotodrafitrasa ilaina hampiasa ny API an'ny proc_macro izao.
/// Marina raha toa ka miverina hampiharina avy ao anatiny ny fomba fanatanterahana indray macro, diso raha hampiharina avy mimari-droa hafa.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Ny tena karazana omen'ny crate ity, misolo tena ny saro-takarina renirano tokens, na, mihoatra manokana, fisesin-token hazo.
/// Ny karazana iterating manome interface ho eo amin 'ireo hazo sy token, mifanohitra amin'izany, manangona maromaro token hazo ho renirano iray.
///
///
/// Izy io dia sady input sy output an'ny famaritana `#[proc_macro]`, `#[proc_macro_attribute]` ary `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Hadisoana niverina avy `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Miverina `TokenStream` foana tsy misy hazo token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Manamarina raha foana ity `TokenStream` ity.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Fiezahana hanapaka ny tadiny mankany tokens ary hamaky ireo tokens ho any amin'ny fantsakana token.
/// Enga anie tsy ho maro ny antony, ohatra, raha misy mifandanja amin'ny kofehy delimiters na tarehin-tsoratra tsy misy amin'ny fiteny.
///
/// tokens rehetra ao amin'ny riandrano parsed dia mahazo vanim-potoana `Span::call_site()`.
///
/// NOTE: fahadisoana sasantsasany dia mety hahatonga panics fa tsy niverina `LexError`.Izahay dia manan-jo hanova ireo hadisoana ireo ho lasa `LexError` any aoriana.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ny tetezana ihany no manome `to_string`, ny fampiharana ny `fmt::Display` miorina eo aminy (ny mifanohitra ny mahazatra fifandraisana misy eo amin'ny roa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Manonta ny renirano token ho tadin-dokanga heverina fa tsy azo ahodin-tsy miverina miverina amin'ny renirano token (faran'ny modulo), afa-tsy ny mety ho `TokenTree: : Vondrona misy delimiters `Delimiter::None` sy litera nomerika ratsy.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Prints token amin'ny endrika mety ho an'ny debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Mamorona renirano token misy hazo token tokana.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Manangona maromaro token hazo ho renirano iray.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// A "flattening" token miasa tamin'ny renirano, manangona token hazo avy amin'ny renirano maro token ho renirano iray.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Mampiasà fanatanterahana if/when azo hatsaraina azo atao.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Ny antsipirian'ny fampiharana ampahibemaso ho an'ny karazana `TokenStream`, toy ny iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Mpiverina amin'ny 'TokenStream`'s`TokenTree`s.
    /// Ny iteration dia "shallow", ohatra, ny iterator tsy recurse ho delimited vondrona, ary miverina vondrona rehetra toy ny hazo token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` manaiky jadona tokens sy mampivelatra ho `TokenStream` mamaritra ny fahan'ny.
/// Ohatra, `quote!(a + b)` dia hamokatra ny teny, fa rehefa fizahana, constructs ny `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting dia atao amin'ny `$`, ary miasa amin'ny alalan'ny fanaovana ny tokana ident manaraka toy ny unquoted teny.
/// Raha hanonona `$` tenany dia ampiasao `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Ny faritra ny mari-tomboky, miaraka amin'ny vaovao fanitarana macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Mamorona vaovao `Diagnostic` amin'ny nomena `message` amin'ny androm `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Sehatra iray izay mamaha amin'ny tranokala famaritana.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Ny halavan'ny fiantsoana ny tononkalo ankehitriny.
    /// Identifiers noforonina tamin'ny zehiny izany dia ho tapa-kevitra toy ny raha voasoratra mivantana amin'ny antso macro toerana (antso an-toerana ny fahadiovana) sy ny fehezan amin'ny macro antso toerana dia ho afaka miresaka ny azy ireo ihany koa.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Ny androm `macro_rules` izay maneho ny fahadiovana, ary indraindray ny macro mamaha amin'ny famaritana toerana (an-toerana hiovaova, marika, `$crate`) ary indraindray tao amin'ny macro antso toerana (zavatra hafa rehetra).
    ///
    /// Ny androm toerana dia nalaina avy amin'ny antso-toerana.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Tany am-boalohany izay loharano rakitra ho androm ity hevitra.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Ny `Span` ho an'ny tokens in teo aloha fanitarana macro izay `self` dia niteraka avy, raha misy.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Ny halavan'ny kaody loharano niavian'ny `self`.
    /// Raha izany dia tsy niteraka `Span` amin'ny hafa avy eo ny fitomboan'ny macro miverina vidy dia toy `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Mahazo ny nanomboka line/column ao amin'ny loharano ho an'ity rakitra androm.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Mahazo ny faran'ny line/column ao amin'ny rakitra loharano amin'ity vanim-potoana ity.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Mamorona sehatra vaovao manodidina ny `self` sy `other`.
    ///
    /// Miverina `None` raha `self` sy `other` dia avy amina rakitra samihafa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Mamorona vaovao amin'ny androm ihany `self` line/column vaovao toy ny fanapahan-kevitra fa marika toy tany `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Mamorona vaovao amin'ny androm mitovy anarana résolution fihetsika toy `self` fa tamin'ny line/column vaovao ny `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Dia mampitaha ny sakan'ny mba hahitana raha ry zareo mitovy.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Miverina ny loharanom-baovao lahatsoratra ambadiky ny androm.
    /// Ity dia mitahiry ny kaody loharano tany am-boalohany, ao anatin'izany ny habaka sy ny hevitra.
    /// Tsy niverina ihany noho ny androm raha mifanaraka amin'ny tena mari-tomboky.
    ///
    /// Note: Ny azo dinihina vokatry ny macro dia tokony miantehitra amin'ny tokens fa tsy amin'ny loharanom-baovao io andinin-teny.
    ///
    /// Ny vokatry ny asany io dia ezaka tsara indrindra mba ho ampiasaina amin'ny diagnostics ihany.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Dian irain-jehy amin'ny endrika mety ho an'ny debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Mpivady tsanganana tsipika maneho ny fiandohana na faran'ny `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1-indexed Ny andalana ao amin'ny antontan-taratasy loharano izay ny androm manomboka na faran'ny (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Ny tsanganana misy fanondro 0 (amin'ny tarehintsoratra UTF-8) ao amin'ny rakitra loharano izay manomboka na mifarana (inclusive) ny elanelam-potoana.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Ny loharanom-baovao iray nomena antontan `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Mahazo ny lalana mankany amin'ity rakitra loharano ity.
    ///
    /// ### Note
    /// Raha ny fehezan-dalàna androm mifandray amin'ny `SourceFile` io no niteraka ny iray ivelany macro, macro izany, mety tsy ho tena lalana eo amin'ny filesystem.
    /// Mampiasà [`is_real`] hanamarinana.
    ///
    /// Naoty ihany koa fa na dia miverina `is_real` `true`, raha `--remap-path-prefix` dia nandroso ny baiko tsipika, ny lalana araka ny nomena mety tsy tena ho manan-kery.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Miverina `true` raha loharano io rakitra dia tena loharanom-baovao rakitra, fa tsy niteraka iray ivelany ny fanitarana macro.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Izany dia Hack mandra-intercrate sakan'ny no ampiharina ary afaka manana loharano tena antontan-taratasy ho an'ny any ivelany sakan'ny Niteraka macros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token tokana na filaharana z0token0Z tokana voafetra (oh: `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Rano token voahodidin'ny delimitera bracket.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Mpamaritra
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Ny mari-piatoana toetra tokana (`+`, `,`, `$`, sns).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Toetra ara-bakiteny (`'a'`), tady (`"hello"`), isa (`2.3`), sns.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Miverina ny sakan'ity hazo ity, mandefa ny fomba `span` amin'ilay token misy na renirano voafetra.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Manamboatra ny elanelam-potoana hahitana ny *an'ity token* ity ihany.
    ///
    /// Mariho fa raha izany dia `Group` token avy eo dia tsy fomba izany ampiendrehina ny androm ny tsirairay tokens ny anatiny, izany fotsiny dia solontena any amin'ny `set_span` fomba Variant tsirairay.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Prints hazo token amin'ny endrika mety ho an'ny debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Tsirairay ireo dia manana ny anarana ao amin'ny struct karazana ao amin'ny homarinana debug, noho izany aza manahirana amin'ny fanampiny sosona indirection
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ny tetezana ihany no manome `to_string`, ny fampiharana ny `fmt::Display` miorina eo aminy (ny mifanohitra ny mahazatra fifandraisana misy eo amin'ny roa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Manonta ny hazo token ho toy ny tady izay heverina fa tsy azo fodiana hiverina amin'ny hazo token mitovy (modulo spans), afa-tsy ny mety ho `TokenTree: : Vondrona misy delimiters `Delimiter::None` sy litera nomerika ratsy.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// A delimited token Stream.
///
/// `Group` ao anatiny dia misy `TokenStream` izay voahodidin'ny `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Mamaritra ny fomba fisesin-token hazo no delimited.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// An delimiter tanteraka, izay mety, ohatra, hita manodidina tokens avy amin'ny "macro variable" `$var`.
    /// Zava-dehibe ny hiarovana mpandraharaha laharam-pahamehana eo amin'ny toe-javatra toy ny `$var * 3` izay `$var` no `1 + 2`.
    /// Ny delimiters implicit dia mety tsy ho tafavoaka amin'ny fihodinan'ny z0token0Z amin'ny alàlan'ny tadiny.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Mamorona `Group` vaovao miaraka amin'ny delimiter nomena sy ny stream token.
    ///
    /// Mpanao ity no hametraka ny androm ho an'ity vondrona `Span::call_site()`.
    /// Raha hanova ny halavany dia azonao atao ny mampiasa ny fomba `set_span` etsy ambany.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Miverina ny delimiter ity `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Miverina ny `TokenStream` ny tokens izay delimited amin'ity `Group`.
    ///
    /// Mariho fa ny niverina token renirano tsy ahitana ny delimiter niverina ambony.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Miverina ny androm ho an'ny delimiters ity token ony, naharitra `Group` iray manontolo.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Miverina ny elanelam-potoana manondro ny delimiter fanokafana an'ity vondrona ity.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Miverina ny androm manondro ny famaranana delimiter vondrona ity.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Manamboatra ny halavany ho an'ny delimiters an'ity vondrona ity, fa tsy ny tokens anatiny.
    ///
    /// Ity fomba ity dia tsy ** hametraka ny sakan'ny tokens anatiny rehetra izay nilahatra tamin'ity vondrona ity, fa kosa hametraka ny sakan'ny delimiter tokens amin'ny haavon'ny `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ny tetezana ihany no manome `to_string`, ny fampiharana ny `fmt::Display` miorina eo aminy (ny mifanohitra ny mahazatra fifandraisana misy eo amin'ny roa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Manonta ny vondrona ho tadiny izay tokony hiova fo tsy miova ho lasa vondrona mitovy (fatra modulo), afa-tsy ny mety ho `TokenTree: : Vondrona misy delimiters `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Ny `Punct` dia toetra manonona teboka tokana toa `+`, `-` na `#`.
///
/// Multi-toetra toy ny `+=` mpandraharaha no mifanitsy toy ny toe-javatra roa samy hafa ny `Punct` amin'ny endrika `Spacing` niverina.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Na ny `Punct` dia nanaraka avy hatrany ny iray hafa, na nanaraka `Punct` token-kafa na whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ohatra, dia `Alone` `+` in `+ =`, `+ident` na `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ohatra, dia `Joint` `+` in `+=` na `'#`.
    /// Ankoatra izany, mpitovo Dahatsoratra `'` afaka hiaraka amin'ny identifiers ny endrika `'ident` lifetimes.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Mamorona `Punct` vaovao avy amin'ny toetra amam-panahy sy ny elanelana nomena.
    /// Ny tohan-kevitra dia tsy maintsy `ch` ho marim-pototra mari-piatoana toetra navela ny teny, raha tsy izany dia ny asa panic.
    ///
    /// Ny niverina `Punct` dia hanana ny toerana misy anao androm ny `Span::call_site()` izay azo voaendrika bebe kokoa amin'ny fomba `set_span` eto ambany.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Miverina ny lanjan'ny mari-tsoratra io toetra toy ny `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Miverina ny elanelan'ity mari-tsoratra ity, manondro raha manaraka azy avy hatrany ny `Punct` hafa ao amin'ny renirano token, mba hahafahan'izy ireo mitambatra ho mpikirakira marolafy (`Joint`), na arahin'n'ny token hafa na ny fotsy fotsy (`Alone`) ka azo antoka fa ilay mpandraharaha nifarana.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Miverina ny androm ho mari-tsoratra io toetra.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ampifanaraho ny elanelam-panahin'ity mari-tsoratra ity.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ny tetezana ihany no manome `to_string`, ny fampiharana ny `fmt::Display` miorina eo aminy (ny mifanohitra ny mahazatra fifandraisana misy eo amin'ny roa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Atao pirinty ho toy ny tady ny tarehin-tsoratra miaraka amina tadiny izay tokony hiova tsy misy fatiantoka ho lasa toetra mitovy.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// An Solon'anarana (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Mamorona vaovao miaraka amin'ny nomena `Ident` `string` ary koa ny mazava `span`.
    /// Ny tohan-kevitra `string` dia tokony ho mpamantatra marina eken'ny fiteny (ao anatin'izany ny teny lakile, ohatra `self` na `fn`).Raha tsy izany, ny asa ho panic.
    ///
    /// Mariho fa `span`, ao amin'ny rustc, dia manamboatra ny mombamomba ny fahadiovana ho an'ity mpamaritra ity.
    ///
    /// Toy ny tamin'ity indray mitoraka ity `Span::call_site()` mazava opts-in ho "call-site" fahadiovana dikany fa identifiers namorona izany zehiny, dia ho tapa-kevitra toy ny raha voasoratra mivantana tao amin'ny toerana misy ny macro antso, sy ny kaody amin'ny macro antso toerana dia ho afaka hilazana izy ireo koa.
    ///
    ///
    /// Sakan'ny tatỳ aoriana toy ny `Span::def_site()` dia hanome fahafahana ny misafidy-in ho "definition-site" fahadiovana izay midika fa identifiers namorona izany zehiny, dia ho tapa-kevitra eo amin'ny toerana misy ny macro famaritana sy ny fehezan amin'ny macro antso toerana dia tsy ho afaka ny miresaka ny azy ireo.
    ///
    /// Noho ny maha-zava-dehibe ny fahadiovana amin'izao fotoana izao ity mpanorina ity, tsy toy ny tokens hafa, dia mitaky `Span` voatondro amin'ny fanamboarana.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Mitovy amin'ny `Ident::new`, fa mamorona (`r#ident`) mampiavaka azy.
    /// Ny tohan-kevitra `string` ho marim-pototra Solon'anarana navela ny teny (anisan'izany ny teny fanalahidy, ohatra `fn`).
    /// Teny lakile izay azo ampiasaina amin'ny sehatry ny làlana (oh
    /// `self`, `super`) dia tsy tohanana, ary hiteraka panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Miverina ny sakan'ity `Ident` ity, izay mandrakotra ny tady iray manontolo naverin'i [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures ny androm `Ident` ity, angamba ny fanovana ny teny manodidina ny fahadiovana.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ny tetezana ihany no manome `to_string`, ny fampiharana ny `fmt::Display` miorina eo aminy (ny mifanohitra ny mahazatra fifandraisana misy eo amin'ny roa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Diam Ny mpamantatra toy ny tady izay tokony ho losslessly convertible niverina ho any amin'ny Solon'anarana ihany.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Ny ara-bakiteny (`"hello"`) kofehy, tady byte (`b"hello"`), toetra (`'a'`), byte toetra (`b'a'`), ny integer na mitsingevana hevitra isa miaraka na tsy misy tovana (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Boolean literals toy ny `true` sy `false` tsy an'ny eto, izy ireo: Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Mamorona integer integer vaovao ara-bakiteny miaraka amin'ny sanda voafaritra.
        ///
        /// Izany dia hamorona asa ny integer tahaka `1u32` izay integer sanda voafaritra dia ny tapany voalohany amin'ny token sy ny tafiditra tanteraka ihany koa ny tsy ampy amin'ny farany.
        /// Literals Avy ratsy mety tsy velona isa-nivezivezy manodidina amin'ny alalan'ny `TokenStream` na tady, ary mety ho torotoro roa tokens (`-` sy ny tsara ara-bakiteny).
        ///
        ///
        /// Literals nahariana ny fomba io dia manana ny `Span::call_site()` zehiny amin'ny toerana misy anao, izay azo voaendrika amin'ny fomba `set_span` eto ambany.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Mamorona vaovao integer unsuffixed voafaritra ara-bakiteny amin'ny vidiny.
        ///
        /// Izany dia hamorona asa ny integer tahaka `1` izay integer sanda voafaritra dia ny tapany voalohany amin'ny token.
        /// Tsy misy tovana no faritana ity token, izay midika fa invocations toy ny `Literal::i8_unsuffixed(1)` dia mitovy amin'ny `Literal::u32_unsuffixed(1)`.
        /// Ny litera noforonina avy amin'ny isa ratsy dia mety tsy ho tafavoaka velona amin'ny alàlan'ny `TokenStream` na tadiny ary azo zaraina ho tokens (`-` ary ara-bakiteny ara-bakiteny).
        ///
        ///
        /// Literals nahariana ny fomba io dia manana ny `Span::call_site()` zehiny amin'ny toerana misy anao, izay azo voaendrika amin'ny fomba `set_span` eto ambany.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Mamorona teboka ara-bakiteny vaovao tsy voafafy.
    ///
    /// Mpanao ity dia mitovy amin'ny an'ireo tahaka `Literal::i8_unsuffixed` izay float ny lanjan'izy ireo dia namirapiratra tao an-token mivantana fa tsy misy tovana no ampiasaina, dia mety ho inferred ho `f64` tatỳ aoriana tao amin'ny compiler.
    ///
    /// Ny litera noforonina avy amin'ny isa ratsy dia mety tsy ho tafavoaka velona amin'ny alàlan'ny `TokenStream` na tadiny ary azo zaraina ho tokens (`-` ary ara-bakiteny ara-bakiteny).
    ///
    /// # Panics
    ///
    /// Izany asa izany dia mitaky ny voafaritra float dia voafetra, ohatra raha Nan Infinity na asa izany no panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Mamorona vaovao teboka tsy ampy mitsingevana-bakiteny.
    ///
    /// Ity mpanorina ity dia hamorona ara-bakiteny toy ny `1.0f32` izay ny sanda voatondro dia ny ampahany teo alohan'ilay token ary ny `f32` no tovana ny token.
    /// Izany foana token ho inferred ho `f32` amin'ny compiler.
    /// Ny litera noforonina avy amin'ny isa ratsy dia mety tsy ho tafavoaka velona amin'ny alàlan'ny `TokenStream` na tadiny ary azo zaraina ho tokens (`-` ary ara-bakiteny ara-bakiteny).
    ///
    ///
    /// # Panics
    ///
    /// Izany asa izany dia mitaky ny voafaritra float dia voafetra, ohatra raha Nan Infinity na asa izany no panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Mamorona teboka ara-bakiteny vaovao tsy voafafy.
    ///
    /// Mpanao ity dia mitovy amin'ny an'ireo tahaka `Literal::i8_unsuffixed` izay float ny lanjan'izy ireo dia namirapiratra tao an-token mivantana fa tsy misy tovana no ampiasaina, dia mety ho inferred ho `f64` tatỳ aoriana tao amin'ny compiler.
    ///
    /// Ny litera noforonina avy amin'ny isa ratsy dia mety tsy ho tafavoaka velona amin'ny alàlan'ny `TokenStream` na tadiny ary azo zaraina ho tokens (`-` ary ara-bakiteny ara-bakiteny).
    ///
    /// # Panics
    ///
    /// Izany asa izany dia mitaky ny voafaritra float dia voafetra, ohatra raha Nan Infinity na asa izany no panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Mamorona vaovao teboka tsy ampy mitsingevana-bakiteny.
    ///
    /// Ity mpanorina ity dia hamorona ara-bakiteny toy ny `1.0f64` izay ny sanda voatondro dia ny ampahany teo alohan'ilay token ary ny `f64` no tovana ny token.
    /// Izany foana token ho inferred ho `f64` amin'ny compiler.
    /// Ny litera noforonina avy amin'ny isa ratsy dia mety tsy ho tafavoaka velona amin'ny alàlan'ny `TokenStream` na tadiny ary azo zaraina ho tokens (`-` ary ara-bakiteny ara-bakiteny).
    ///
    ///
    /// # Panics
    ///
    /// Izany asa izany dia mitaky ny voafaritra float dia voafetra, ohatra raha Nan Infinity na asa izany no panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String ara-bakiteny.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Toetra ara-bakiteny.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte string ara-bakiteny.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Miverina ny androm mahafaoka izany ara-bakiteny.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures ny androm mifandray noho izany ara-bakiteny.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Miverina ny `Span` izay dia subset ny `self.span()` misy ihany ny loharanom-baovao isan-karazany oktety amin'ny `range`.
    /// Miverina `None` raha toa ka te-ho voakarakara androm dia ivelan'ny faritry ny `self`.
    ///
    // FIXME(SergioBenitez): jereo fa ny byte isan-karazany sy ny faran'ny manomboka amin'ny UTF-8 sisin 'ny loharanom-baovao.
    // raha tsy izany, dia azo inoana fa panic hisy ny loharanom-baovao any an-kafa, rehefa lahatsoratra ny atonta izy.
    // FIXME(SergioBenitez): tsy misy lalana ho ny mpampiasa hahalala izay tena `self.span()` Maps raha, ka izany dia afaka amin'izao fotoana izao ihany no fomba hatao hoe an-jambany.
    // Ohatra, ho an'ny toetra `to_string()` 'c' hiverina "'\u{63}'";tsy misy lalana ho ny mpampiasa mba hahafantarany na ny loharanom-baovao dia 'c' na soratra na i '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) zavatra mitovy amin'ny `Option::cloned`, fa ho an'ny `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ny tetezana ihany no manome `to_string`, ny fampiharana ny `fmt::Display` miorina eo aminy (ny mifanohitra ny mahazatra fifandraisana misy eo amin'ny roa).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Manontana ny ara-bakiteny ho tady izay tokony hiova tsy misy fatiantoka ho lasa ara-bakiteny (afa-tsy ny fihodinana mety ho litera mitsingevana).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Fantarina mahazo tontolo iainana hiovaova.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Raiso ny fiovan'ny tontolo iainana ary ampio izy hananganana fampahalalana fiankinan-doha.
    /// Manaova rafitra famonoana ny compiler dia ho fantatrareo fa ny miova dia jerena nandritra ny fanangonana, ary dia ho afaka ny rerun ny manaova raha ny hasarobidin'ny miova miova izany.
    ///
    /// Ankoatra ny fiankinan-doha izany asa fanaraha-maso dia tokony ho mitovy amin'ny `env::var` avy amin'ny fitsipika fitehirizam-boky, afa-tsy ny tohan-kevitra fa tsy maintsy ho UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}