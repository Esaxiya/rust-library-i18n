//! Fampiharana ny Rust panics amin'ny alàlan'ny fanalan-jaza
//!
//! Raha ampitahaina amin'ny fampiharana amin'ny alàlan'ny fialana sasatra dia tsotra kokoa *ity* crate ity!Ny amin'ilay efa nanao hoe, tsy tena toy ny zavatra maro, fa eto mandeha!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ny payload sy shim ny mifanaraka abort eo amin'ny sehatra amin'ny fanontaniana.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // miantso std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Amin'ny Windows, ampiasao ny mekanisma __fastfail voafaritra manokana.Ao amin'ny Windows 8 sy aoriana, ity dia hamarana ny fizotrany avy hatrany nefa tsy mihazakazaka mpikirakira ankanavaka ao anaty dingana.
            // Ao aloha ny dika Windows, izany filaharan'ireo ny toromarika dia ho raisina ho toy ny fanitsakitsahana fidirana, fampijanonana ny dingana fa tsy voatery nandika afa rehetra entany.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ity dia fampiharana sahala amin'ny an'ny `abort_internal` libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Izany ... dia kely iray oddity.Ny TL; Dr;dia izany no ilaina mba manana rohy mankany tsara, ny fanazavana intsony dia eto ambany.
//
// Amin'izao fotoana izao ny binaries ny libcore/libstd fa an-tsambo rehetra amin'ny `-C panic=unwind` voangona.Izany dia natao mba hahazoana antoka fa mifanaraka tsara indrindra amin'ny toe-javatra maro araka izay tratra ireo mimari-droa.
// Ny compiler kosa dia mitaky "personality function" ho an'ny fiasa rehetra atambatra amin'ny `-C panic=unwind`.Ity fiasan'ny toetra ity dia kambana amin'ny marika `rust_eh_personality` ary faritan'ny singa `eh_personality` lang.
//
// So...
// Maninona moa Aho Raha atao hoe Lang zavatra eto?Fanontaniana tsara!Ny fomba ampifandraisan'ny runtime panic dia somary misimisy ihany amin'ny faha-"sort of" azy ireo ao amin'ny magazay crate an'ny compiler, fa raha ny tena izy kosa tsy mifandray.
//
// Ity faran'ny ka izay midika fa na izany crate sy ny panic_unwind crate dia afaka hita ao amin'ny ny crate compiler fivarotana, ary raha samy mamaritra ny `eh_personality` Lang zavatra avy eo fa namely Ho fahadisoana.
//
// Mba hiatrehana izany ny compiler ihany no mitaky ny `eh_personality` dia faritana raha toa ny panic runtime rehefa mifandray ao dia ny fanajanonana runtime, ary raha tsy izany dia tsy maintsy ho faritana (ara-drariny izany).
// Amin'ity tranga ity, na izany aza, famaritana ity marika ity fotsiny ity tranomboky ity ka farafaharatsiny misy olona sasany any ho any.
//
// Indrindra marika io dia voafaritra fotsiny hatao nampifandraisina mivantana ho any libcore/libstd binaries, fa tokony tsy ho antsoina hoe toy ny tsy manana rohy amin'ny fanajanonana runtime mihitsy.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Ao amin'ny x86_64-PC-varavarankely-gnu mampiasa ny maha-miasa ihany fa ilaina mba hiverina `ExceptionContinueSearch` toy isika dia mandalo ny zana-kazo rehetra.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Mitovy amin'ny etsy ambony, io dia mifanaraka amin'ny singa `eh_catch_typeinfo` lang izay tsy ampiasaina amin'ny Emscripten amin'izao fotoana izao.
    //
    // Koa satria dia tsy hiteraka panics maningana sy ny vahiny amin'izao fotoana izao ankoatra ny tranga miavaka Ub amin'ny -C panic=abort (na mety ho foto-kevitra ny hanova), izay antso catch_unwind tsy hampiasa izany typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ireo roa efa nantsoina ny startup zavatra amin'ny i686-PC-varavarankely-gnu, fa tsy mila na inona na inona toy izany koa ny vatana dia nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}