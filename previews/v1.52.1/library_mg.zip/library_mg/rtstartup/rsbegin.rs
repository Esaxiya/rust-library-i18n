// rsbegin.o ary rsend.o no antsoina hoe "compiler runtime startup objects".
// Mitahiry tsara ny fehezan-dalàna Nila initialize ny compiler runtime.
//
// Raha misy tanterahina na dylib sary dia mifandray, mpampiasa rehetra fehezan-dalàna sy ny trano famakiam-boky dia "sandwiched" eo anelanelan 'ireo zavatra antontan-taratasy, ka kaody na ny angona avy rsbegin.o ho voalohany ao amin'ny fizarana tsirairay ny sary, kosa kaody sy ny angona avy rsend.o ho tonga ny farany ireo.
// Zavatra vokatry Azo ampiasaina toerana fanehoana an'ohatra am-piandohana, na any amin'ny faran'ny fizarana iray, ary koa ny mba ampidiro izay lohapejy na tongopejy ilaina.
//
// Mariho fa ny tena Module fotoana fidirana no misy ao amin'ny C runtime startup zavatra (matetika antsoina hoe `crtX.o`), izay avy eo mitalaho initialization callbacks hafa runtime singa (voasoratra anarana hafa amin'ny alalan'ny fizarana sary manokana).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Manamarika ny fiatombohan'ny tsanganana fampahalalana momba ny famelabelarana
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Scratch toerana ho an'ny unwinder ny boky-anatiny ny fitandremana ny.
    // Izany dia faritana ho toy `struct object` in $ GCC/sorisory-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Sorisory Info registration/deregistration tapaka.
    // Jereo ny tahirin-kevitrao ny libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // hisoratra anarana sorisory Info amin'ny Module startup
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unregister amin'ny fanakatonana
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-fisoratana anarana mahazatra init/uninit manokana
    pub mod mingw_init {
        // Ny zavatra fanombohana MinGW (crt0.o/dllcrt0.o) dia hiantso ireo mpanangana manerantany ao amin'ny faritra .ctors sy .dtors amin'ny fanombohana sy fivoahana.
        // Amin'ny tranga DLL, dia atao izany rehefa fenoina sy alaina ny DLL.
        //
        // Ny linker dia manatsara ny fizarana, izay miantoka fa ny callbacks dia hita any amin'ny faran'ny ny lisitra.
        // Koa satria constructors dia nihazakazaka mba mifanohitra, io antoka fa ny callbacks no voalohany sy farany ireo novonoina ho faty.
        //
        //

        #[link_section = ".ctors.65535"] // .ctor. *: Fiantsoana callback an'ny C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C famaranana callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}