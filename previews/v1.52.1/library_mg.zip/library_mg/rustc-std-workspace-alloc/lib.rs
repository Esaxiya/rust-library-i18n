#![feature(no_core)]
#![no_core]

// Jereo ny rustc-std-workspace-core amin'ny antony ilana an'ity crate ity.

// Ovao ny anarana hoe crate mba tsy hifanohitra amin'ny maodely fizarana ao amin'ny liballoc.
extern crate alloc as foo;

pub use foo::*;