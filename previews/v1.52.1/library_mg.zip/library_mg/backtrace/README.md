# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Tranomboky iray hahazoana fahazoana miverina amin'ny fotoana maharitra ho an'ny Rust.
Ity trano famakiam-boky ity dia mikendry ny hanatsara ny fanohanan'ny tranomboky mahazatra amin'ny alàlan'ny fanomezana sehatrasa fandaharana hiasa, fa manohana tsotra izao ny fanontana tsotra izao ny backtrace ankehitriny toa ny libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

To misambotra tsotra izao ny ela Hianao backtrace ary rehefa mifandray amin'ny ho tra Tatỳ aoriana kokoa, dia afaka mampiasa ny ambaratonga ambony `Backtrace`-karazana.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Raha toa kosa ka tianao ny fidirana manta bebe kokoa amin'ilay fiasa tena izy dia azonao ampiasaina mivantana ny asan'ny `trace` sy `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Vahao amin'ny anarana marika ity tondro torolalana ity
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // mandehana hatrany amin'ny tabilao manaraka
    });
}
```

# License

Ity tetikasa ity dia nahazo alalana tamin'ny alàlan'ny iray amin'izy ireo

 * Apache Lisansa, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) na http://www.apache.org/licenses/LICENSE-2.0)
 * Fahazoan-dàlana na MIT ([LICENSE-MIT](LICENSE-MIT) http://opensource.org/licenses/MIT)

araka ny safidinao.

### Contribution

Raha tsy milaza mazava ianao amin'ny fomba hafa, ny anjara biriky niniana nampidirina hampidirina ao anaty backtrace-rs anao, araka ny voafaritry ny fahazoan-dàlana Apache-2.0, dia hanana fahazoan-dàlana roa voalaza etsy ambony, tsy misy fe-potoana na fepetra fanampiny.







