use backtrace::Backtrace;

// Ity fitsapana ity dia tsy miasa afa-tsy amin'ny lampihazo izay misy fiasan'ny `symbol_address` miasa ho an'ny zana-kazo izay mitatitra ny adiresy fanombohana marika iray.
// Noho izany ihany no afaka eo amin'ny sehatra vitsivitsy.
//
const ENABLED: bool = cfg!(all(
    // Windows mbola tsy voasedra, ary ny OSX dia tsy manohana ny tena fahitana takelaka fonosina, ka vonoy ity
    //
    target_os = "linux",
    // Ao amin'ny ARM nahita ny hihodidina ny asa dia miverina fotsiny ny: ip mihitsy.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}