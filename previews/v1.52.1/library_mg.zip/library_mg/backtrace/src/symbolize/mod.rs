use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Mamaha adiresy amin'ny marika iray, alefaso amin'ilay marika ilay fanakatonana voatondro.
///
/// Izany asa Hijery ny nanome adiresy ao amin'ny faritra toy ny marika eo an-toerana latabatra, mavitrika marika latabatra, na ny sahozanina debug Info (arakaraka ny mampandeha fampiharana) mba hahita tandindona mba hilefitra.
///
///
/// Ny fanidiana dia mety tsy hantsoina raha tsy azo tanterahina ny famahana, ary mety hantsoina mihoatra ny indray mandeha ihany koa izy raha misy laharana miasa.
///
/// Ny mari-pamantarana azo dia maneho ny famonoana amin'ny `addr` voafaritra, mamerina tsiroaroa file/line ho an'io adiresy io (raha misy).
///
/// Mariho fa raha manana `Frame` ianao dia asaina mampiasa ny fiasa `resolve_frame` fa tsy ity iray ity.
///
/// # Endri-javatra ilaina
///
/// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
///
/// # Panics
///
/// Izany asa Miezaka tsy panic, fa raha ny `cb` panics dia nanome sehatra sasany dia hanery-droa panic mba abort ny dingana.
/// Ny sehatr'asa sasany dia mampiasa tranomboky C izay mampiasa callbacks ao anatiny izay tsy azo vahana, ka ny fikojakojana avy amin'ny `cb` dia mety hiteraka fanalan-jaza.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // jereo fotsiny ny eo amboniny
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Mamaha ny sary fisamborana teo aloha ho marika, mampita ilay marika amin'ny fanidiana mihidy.
///
/// Izany functin manao mitovy asa araka ny `resolve` afa-tsy ny mitaky ny `Frame` ho toy ny fandresen-dahatra fa tsy ny adiresy.
/// Ity dia ahafahana mampihatra sehatra sasany amin'ny famerenana amin'ny laoniny mba hanomezana fampahalalana marimarina kokoa na fampahalalana momba ny tsipika mitsivalana ohatra.
///
/// Izany dia midika hoe kevitra ny hampiasa izany raha atao.
///
/// # Endri-javatra ilaina
///
/// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
///
/// # Panics
///
/// Izany asa Miezaka tsy panic, fa raha ny `cb` panics dia nanome sehatra sasany dia hanery-droa panic mba abort ny dingana.
/// Ny sehatr'asa sasany dia mampiasa tranomboky C izay mampiasa callbacks ao anatiny izay tsy azo vahana, ka ny fikojakojana avy amin'ny `cb` dia mety hiteraka fanalan-jaza.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // jereo fotsiny ny eo amboniny
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Ny sanda IP avy amin'ny frame stack dia mazàna (always?) ny torolàlana *aorian'ny* ilay antso izay ilay tena dian-tongotra.
// Mampiseho izany amin'ny isan'ny antony mahatonga ny filename/line mba ho iray mialoha ary angamba any an-foana raha toa izany akaikin'ny faran'ny ny asa.
//
// Toa izany foana no mitranga amin'ny sehatra rehetra, noho izany dia esorinay hatrany amin'ny ip tapaka ny iray mba hamahana azy amin'ny torolàlana antso taloha fa tsy ny torolàlana haverina.
//
//
// Raha ny tokony ho izy dia tsy hanao an'io isika.
// Ny tena tsara dia mitaky mpiantso ny `resolve` APIs eto tanana hanao ny -1 sy ny tantara fa te toerana vaovao ho an'ny fampianarana * * teo aloha, fa tsy ny amin'izao fotoana izao.
// Raha ny tokony ho izy dia hampiharihary ny `Frame` koa isika raha ny adiresin'ny torolàlana manaraka na ny ankehitriny.
//
// Fa na dia ankehitriny izao dia tsara tarehy akany fiahiana toy izany no analana foana anatiny fotsiny ny iray.
// Ny mpanjifa dia tokony hiasa hatrany ary hahazo vokatra tsara, ka tokony ho ampy tsara isika.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Mitovy amin'ny `resolve`, tsy azo antoka ihany satria tsy mifandrindra.
///
/// Io asa tsy manana synchronization guarentees fa tsy ampy raha ny `std` endri-javatra io dia tsy natambatra crate in.
/// Jereo ny fiasan'ny `resolve` raha mila tahirin-kevitra sy ohatra bebe kokoa.
///
/// # Panics
///
/// Jereo ny vaovao momba ny fampitandremana aorina amin'ny `resolve` ho an'ny `cb` panicking.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Mitovy amin'ny `resolve_frame`, tsy azo antoka ihany satria tsy mifandrindra.
///
/// Io asa tsy manana synchronization guarentees fa tsy ampy raha ny `std` endri-javatra io dia tsy natambatra crate in.
/// Jereo ny `resolve_frame` asa bebe kokoa antontan-taratasy sy ny ohatra.
///
/// # Panics
///
/// Jereo ny fampahalalana momba ny `resolve_frame` ho an'ny fampandrenesana momba ny fikorontanana `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait misolo tena ny famahana ny marika ao anaty rakitra.
///
/// Ity trait ity dia naterina ho zavatra trait amin'ny fanakatonana nomena ny asan'ny `backtrace::resolve`, ary saika nalefa izy io satria tsy fantatra izay fampiharana ao aoriany.
///
///
/// Ny mari-pamantarana iray dia afaka manome fampahalalana momba ny asa, ohatra ny anarana, filename, nomeraon'ny tsipika, adiresy marina, sns.
/// Tsy ny fampahalalana rehetra dia misy amin'ny marika foana, na izany aza, dia miverina `Option` daholo ny fomba rehetra.
///
///
pub struct Symbol {
    // TODO: ity fiainana mandritra ny androm-piainana ity dia mila tohizina hatramin'ny `Symbol`,
    // fa ny amin'izao fotoana izao ny famakiana fiovana.
    // Amin'izao fotoana izao dia milamina io satria ny `Symbol` dia zaraina amin'ny alàlan'ny referansa fotsiny ary tsy azo ekena.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Mamerina ny anaran'ny fiasan'ity.
    ///
    /// Ny rafitra naverina dia azo ampiasaina hanontaniana fananana isan-karazany momba ny anaran'ny marika:
    ///
    ///
    /// * Ny fampiharana `Display` dia hanonta ny marika tandindona.
    /// * Ny manta `str` sarobidy ny famantarana azo jerena (raha ny manan-kery utf-8).
    /// * Ny oktety manta ho an'ny famantarana anarana azo jerena.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Mamerina ny adiresy fanombohana an'io asa io.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Mamerina ny filename manta ho slice.
    /// Io dia ilaina indrindra amin'ny tontolo `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Mamerina ny laharan'ny tsanganana amin'ny toerana fampiharana an'io tandindona io amin'izao fotoana izao.
    ///
    /// Gimli ihany no manome sanda eto ary raha izany dia raha `filename` no mamerina `Some`, ary noho izany dia iharan'ny fampitandremana mitovy amin'izany.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Avereno ny laharana andalana ny toerana fampiharana an'io marika io amin'izao fotoana izao.
    ///
    /// Ity sanda miverina ity dia mazàna `Some` raha miverina `Some` ny `filename`, ary noho izany dia iharan'ny fampitandremana mitovy amin'izany.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Mamerina ny anaran'ny fisie izay nofaritana io fiasa io.
    ///
    /// Tsy misy io raha tsy rehefa misy libbacktrace na gimli ampiasaina (ohatra
    /// unix sehatra hafa) ary rehefa atambatra miaraka amin'ny debuginfo ny mimari-droa.
    /// Raha tsy ny toe-javatra ireo dia nihaona dia izany dia azo inoana fa hiverina `None`.
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Angamba ny parsed C++ famantarana, raha parsing ny mangled Rust famantarana ho tsy nahomby.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Hamarino tsara ny hitazonana an'io habe aotra io, mba tsy hisy vidiny ny endri-javatra `cpp_demangle` rehefa tsy mandeha izy.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Fonosana manodidina ny anarana marika hanomezana mpahazo ergonomika ilay anarana simba, ny bytes manta, ny tady manta, sns.
///
// Avelao maty kaody ho an'ny rehefa `cpp_demangle` endri-javatra dia tsy alefa.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Mamorona anarana marika vaovao amin'ny bytes ambanin'ny fototra.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Miverina ny manta famantarana (mangled) anarana ho toy ny `str` raha ny marika tsy manan-kery utf-8.
    ///
    /// Ampiasao ny fampiharana `Display` raha tianao ny demangled dikan-.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Miverina famantarana ny manta anarana ho toy ny lisitry ny oktety
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Mety pirinty raha demangled marika dia tsy tena manan-kery, ka mitana ny fahadisoana eto amin'ny soa ny molony tsy propagating izany outwards.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Miezaka mba hitaky fa fahatsiarovana Voatakona zatra symbolicate adiresy.
///
/// Ity fomba ity dia hanandrana hamoaka ireo angona angon-drakitra manerantany izay tsy voafaoka amin'ny cache manerantany na amin'ny kofehy izay maneho matetika ny fampahalalana DWARF na mitovy aminy.
///
///
/// # Caveats
///
/// Na dia misy foana aza io asa io dia tsy manao na inona na inona amin'ny ankamaroan'ny fampiharana.
/// Tranomboky toy ny dbghelp na libbacktrace tsy manome toerana ho deallocate fanjakana sy hitantana ny natokana fahatsiarovana.
/// Fa ankehitriny ny `gimli-symbolize` endri-javatra io no hany crate endri-javatra izay asa ity manam-kery.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}