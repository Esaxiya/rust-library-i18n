// tao amin'ny Linux ihany no nampiasaina izao, ka avelao ny kaody maty any an-kafa
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Mpizara tsotra amin'ny buffer byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Manokana buffer amin'ny habe voalaza ary mamerina referansy miovaova momba azy.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: ity no hany fiasa izay manamboatra miovaova
        // firesahana momba `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: tsy manala singa velively amin'ny `self.buffers` izahay, noho izany ny fanovozan-kevitra
        // ny tahirin-kevitra misy ao buffer ho velona raha mbola `self` no.
        &mut buffers[i]
    }
}