//! Paikady fanoharana amin'ny alàlan'ny kaody DWARF-parsing amin'ny libbacktrace.
//!
//! Ny libbacktrace C trano famakiam-boky, matetika zaraina amin'ny gcc, fanohanana tsy niteraka ny backtrace (izay tsy tena mampiasa) fa koa ny backtrace symbolicating sy ny debug botry kely manazava momba ny zavatra toy ny zana-kazo sy whatnot inlined.
//!
//!
//! Somary sarotra izany noho ny ahiahy maro samihafa eto, fa ny hevitra fototra dia:
//!
//! * Voalohany isika dia midera `backtrace_syminfo`.Ity dia mahazo fampahalalana mariky ny latabatra marika mavitrika raha vitantsika.
//! * Manaraka izany dia miantso ny `backtrace_pcinfo` isika.Izany dia hadihadiana debuginfo latabatra raha misy ry zareo ary mamela antsika indray vaovao momba inline zana-kazo, filenames, andalana isa, sns
//!
//! Betsaka ny fitaky ny fametahana ireo latabatra dwarf ho lasa libbacktrace, saingy antenaina fa tsy mbola faran'ny izao tontolo izao ary mazava tsara rehefa mamaky etsy ambany.
//!
//! Ity ny paikady tandindona default ho an'ny sehatra tsy MSVC sy tsy OSX.In libstd anefa izao no toerana misy anao paikady ho an'ny OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Raha azo atao kokoa ny `function` anarana izay avy any debuginfo ary matetika mety ho marina kokoa noho ny inline zana-kazo ohatra.
                // Raha tsy eo izany dia miverina amin'ny anaran'ny latabatra marika voafaritra ao amin'ny `symname`.
                //
                // Mariho fa indraindray dia afaka mahatsapa somary `function` tsy araka ny marina, ohatra ho voatanisa ho `try<i32,closure>` isntead ny `std::panicking::try::do_call`.
                //
                // Tsy dia mazava ny antony, fa amin'ny ankapobeny ny anarana `function` dia toa marina kokoa.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // aza manao na inona na inona amin'izao
}

/// Ny karazan'ilay tondro `data` dia nandalo `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Raha vantany vao nantsoina avy tao `backtrace_syminfo` ity antso miverina ity rehefa manomboka mamaha dia mandeha lavitra kokoa miantso `backtrace_pcinfo`.
    // Ny asa dia mijery `backtrace_pcinfo` debug vaovao sy attemp tto manao zavatra toy sitrana file/line vaovao ary koa ny zana-kazo inlined.
    // Mariho na izany aza fa `backtrace_pcinfo` dia mety tsy mahomby na tsy mahavita zavatra betsaka raha tsy misy ny fampahafantarana debug, ka raha izany dia azo antoka fa hiantso ny callback isika miaraka amina marika iray farafaharatsiny avy amin'ny `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Karazana manondro ny `data` lasa ho any `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Ny libbacktrace API dia manohana ny famoronana fanjakana, saingy tsy manohana ny fanimbana fanjakana izany.
// Izaho manokana handray izany midika fa ny fanjakana dia natao ho noforonina ary avy eo dia ho velona mandrakizay.
//
// Tiako mba hisoratra anarana iray at_exit() Handler izay manadio ny fanjakana ity, fa tsy manome fomba libbacktrace hanao izany.
//
// Raha ireo faneren'ny, io asany manana fitohy Voatakona fanjakana izay kajy ny voalohany izany dia nangataka.
//
// Aza adino fa mihemotra daholo ny fitsangatsanganana rehetra (hidin-trano iray izao).
//
// Mariho ny tsy fisian'ny synchronization eto dia noho ny fepetra takiana dia ny ety ivelany `resolve` no nampiarahina.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Aza mampihatra fahaiza-manao libsafe amin'ny libbacktrace satria antsoinay foana amin'ny fomba namboarina.
        //
        0,
        error_cb,
        ptr::null_mut(), // tsy misy angona fanampiny
    );

    return STATE;

    // Mariho fa ny libbacktrace hiasa mihitsy dia mila mahita ny botry kely debug Info ho an'ny tanterahina amin'izao fotoana izao.Matetika izy io dia manao izany amin'ny alàlan'ny mekanisma maromaro ao anatin'izany, saingy tsy ferana amin'ny:
    //
    // * /proc/self/exe amin'ny sehatra tohanan'ny
    // * Navoaka tamin'ny fomba mazava ny filename rehefa namorona fanjakana
    //
    // Ny tranomboky libbacktrace dia kaody C lehibe.Izany dia midika mazava ho azy ny nahazo fiarovana fitadidiana fahalementsika, indrindra rehefa mandamina malformed debuginfo.
    // Libstd dia nihaona tamin'ny ankamaroan'ireo tantara ireo.
    //
    // Raha /proc/self/exe no ampiasaina dia azontsika atao matetika ny tsy miraharaha ireo satria mieritreritra isika fa ny libbacktrace dia "mostly correct" ary raha tsy izany dia tsy manao zavatra hafahafa amin'ny fampahalalana momba ny debug "attempted to be correct".
    //
    //
    // Raha mandalo ao amin'ny filename, na izany aza, dia azo atao izany eo amin'ny sehatra sasany (toy ny BSDs) izay iray mpilalao mampidi-doza mety ny jadona rakitra mba hapetraka amin'izany toerana.
    // Midika izany fa raha milaza libbacktrace momba ny filename dia mety ho fampiasana ny antontan-taratasy jadona, mety mahatonga segfaults.
    // Raha tsy milaza libbacktrace na inona na inona isika dia tsy hanao na inona na inona amin'ny sehatra tsy manohana ny làlana toa ny /proc/self/exe!
    //
    // Raha jerena izay rehetra ezahintsika fatratra araka izay azo atao mba *tsy* handalo amin'ny filename, fa tsy maintsy amin'ny sehatra tsy manohana /proc/self/exe mihitsy isika.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Mariho fa tsara raha hampiasa `std::env::current_exe` isika, saingy tsy mila `std` eto.
            //
            // Ampiasao ny `_NSGetExecutablePath` hampidirana ny lalana azo tanterahina ankehitriny mankany amin'ny faritra mijanona (izay raha kely loatra dia kivy fotsiny).
            //
            //
            // Mariho fa matoky tanteraka ny libbacktrace eto izahay mba tsy ho faty amin'ny fanatanterahana asa ratsy, saingy azo antoka fa ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows manana fomba fanokafana rakitra izay aorian'ny fisokafana azy dia tsy afaka hofafana.
            // Izany amin'ny ankapobeny ny zavatra tiantsika eto satria te mba ho azo antoka fa ny tanterahina tsy miova mivoaka ho afaka amin'ny antsika araka isika hanolotra azy ho any libbacktrace, manantena fanalefahana ny fahafahana handeha ho any amin'ny tahirin-kevitra jadona libbacktrace (izay azo ampijalina).
            //
            //
            // Raha jerena izay ataontsika ho kely ny dihy eto raha miezaka hahazo karazana hidin-trano eo amin'ny endriny:
            //
            // * Makà tantanana amin'ny fizotran'ny ankehitriny, ampidiro ny filename.
            // * Manokatra fisie ho an'io filename io miaraka amin'ny sainam-pirenena ankavanana.
            // * Avereno jerena ny anaran'ny filaharana ankehitriny, ataovy izay hitovizany
            //
            // Raha izany rehetra izany dia mandalo isika, raha ny teoria, dia nanokatra ny rakitra fisainantsika tokoa ary manome toky izahay fa tsy hiova izany.FWIW ny bunch izany no nadika avy libstd ara-tantara, ka izany no tsara indrindra fandikana ny zava-nitranga.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Miaina anaty tsianjery tsy miovaova io mba hahafahantsika mamerina azy io ..
                static mut BUF: [i8; N] = [0; N];
                // ... ary mivelona amin'ny stack io satria vetivety ihany
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // fanahy iniana mamoaka `handle` eto satria ny fisokafan'izany dia tokony hitahiry ny hidin'ity anaran'ny fisie ity.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Tianay ny mamerina ny sombin-tsofina nul-nul, ka raha feno ny zavatra rehetra ary mitovy ny halavany dia ampitahaina amin'ny tsy fahombiazana.
                //
                //
                // Raha tsy izany rehefa miverina fahombiazana dia alao antoka fa tafiditra ao anaty silaka ilay nul byte.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Ny lesoka backtrace dia voafafa ambanin'ny karipetra ankehitriny
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Antsoy ny `backtrace_syminfo` API izay (amin'ny famakiana ny kaody) dia tokony hiantso ny `syminfo_cb` indray mandeha (na tsy mety misy lesoka angamba).
    // Izahay dia mitazona bebe kokoa ao anatin'ny `syminfo_cb`.
    //
    // Mariho fa manao izany isika satria `syminfo` dia hijery ny latabatra famantarana, mahita anarana marika na dia tsy misy fampahalalana debug ao amin'ny binary aza.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}