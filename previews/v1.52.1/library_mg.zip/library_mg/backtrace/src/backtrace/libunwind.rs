//! Fanohanana backtrace mampiasa libunwind/gcc_s/etc API.
//!
//! Ity modely ity dia misy ny fahafaha-miala sasatra amin'ny alàlan'ny API style libunwind.
//! Mariho fa misy bunch manontolo ny implementations ny libunwind-toy ny API, ary izany no marina miezaka ny ho mifanaraka amin'ny ankamaroan'izy ireo indray mandeha, fa tsy ho picky.
//!
//!
//! Ny libunwind API dia Powered by `_Unwind_Backtrace` ary amin'ny fomba fanao tena azo antoka amin'ny backtrace niteraka iray.
//! Tsy dia mazava tsara ny fomba fanaovany azy (pointes frame? Eh_frame info? Samy?) Fa toa mandeha io!
//!
//! Ny ankamaroan'ny fahasarotan'ity maodely ity dia ny fikirakirana ny fahasamihafana eo amin'ny sehatra samihafa amin'ny fampiharana libunwind.
//! Raha tsy izany dia Rust mahitsy mahitsy mifamatotra amin'ireo API libunwind.
//!
//! Ity no API tsy misy famafana tsy misy fotony ho an'ireo sehatra tsy Windows rehetra amin'izao fotoana izao.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Miaraka amin'ny fanondroana libunwind manta dia tokony hiditra amin'ny fomba mora vidy fotsiny izy io, ka `Sync`.
// Rehefa mandefa ireo kofehy hafa amin'ny alàlan'ny `Clone` dia mifamadika amin'ny kinova tsy mitazona tondro anatiny foana isika, ka tokony ho `Send` ihany koa.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Toa ny OSX `_Unwind_FindEnclosingFunction` dia mamerina tondro iray ... zavatra tsy mazava.
        // Azo antoka fa tsy ny fonosana foana no antony na antony inona na inona.
        // Tsy mazava amiko tanteraka ny zava-mitranga eto, ka pessimize izany amin'izao fotoana izao, ary vao hiverina foana ny: ip.
        //
        // Mariho fa ny fitsapana `skip_inner_frames.rs` dia nesorina tamin'ny OSX noho io fehezan-dalàna io, ary raha raikitra io dia azo atao amin'ny OSX ny fitsapana amin'ny teôria!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Esory ny atiny famakiam-boky ampiasaina amin'ny backtraces
///
/// Mariho fa ny maty no namela toy ny fehezan-dalàna eto no marina bindings iOS tsy mampiasa azy rehetra izany, fa manampy kokoa ny sehatra-configs manokana fametavetana ny fehezan-dalàna be loatra
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ampiasain'ny ARM EABI ihany
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Tsy misy tompon-tany_Unwind_Backtrace amin'ny iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // misy hatramin'ny GCC 4.2.0, dia tokony hilamina amin'ny tanjontsika
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Ity fiasa ity dia tsy mandeha amin'ny laoniny: fa tsy mahazo ny adiresy Canonical Frame (aka SP ny mpiantso) dia mamerina ny SP azy.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x mampiasa sanda CFA mitanila, noho izany dia mila mampiasa_Unwind_GetGR izahay hahazoana ny fisoratana anarana pointer (%r15) fa tsy hiankina amin'ny_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Ao amin'ny android sy ny sandrinao, ny asa sy ny bunch `_Unwind_GetIP` ny olon-kafa no macros, noho izany dia mamaritra ny asa misy ny fanitarana ny macros.
    //
    //
    // TODO: rohy mankany amin'ny rakitra lohateny mamaritra ireo makrô ireo, raha hitanao izany.
    // (I, fitzgen, tsy afaka mahita ilay rakitra lohateny izay nindrana tamin'ireny ny sasany tamin'ireo fanitarana makro ireo.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 dia ny tondro mpanondro amin'ny sandry.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Ity fampiasa ity koa dia tsy misy amin'ny Android na ARM/Linux, ka ataovy izay tsy-op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}