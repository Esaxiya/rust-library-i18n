use core::ffi::c_void;
use core::fmt;

/// Manamarina ny stack-call ankehitriny, mamindra ny frame mavitrika rehetra ao amin'ny fanidiana natokana hikajiana ny soritry ny stack.
///
/// Ity asa ity dia ny workhorse an'ity tranomboky ity amin'ny fikajiana ireo soritry ny stack ho an'ny programa.Ny `cb` fanakatonana nomena dia nomena tranga `Frame` izay maneho ny vaovao momba izany fehezam-piantsoana eo amin'ny stack izany.
/// Ny fanakatonana dia nanolotra zana-kazo amin'ny ambony-midina lamaody (vao haingana indrindra antsoina hoe asa aloha).
///
/// Ny sandan'ny fiverenan'ny fanidiana dia fampisehoana raha tokony hitohy ny backtrace.Fiverenana hasarobidin'ny `false` dia mamarana ny backtrace ka hiverina avy hatrany.
///
/// Indray andro nisy `Frame` no azony dia azo inoana fa te-hiantso `backtrace::resolve` mba hampiova finoana ny `ip` (fampianarana manondro) na ny famantarana ny adiresy amin'ny `Symbol` alalan 'izany ny anarana sy/na filename/tsipika isa azo ianarana.
///
///
/// Mariho fa fiasa ambany dia ambany izany ary raha tianao, ohatra, makà backtrace hozahana rehefa avy eo, dia mety kokoa ny karazany `Backtrace`.
///
/// # Endri-javatra ilaina
///
/// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
///
/// # Panics
///
/// Izany asa Miezaka tsy panic, fa raha ny `cb` panics dia nanome sehatra sasany dia hanery-droa panic mba abort ny dingana.
/// Ny sehatr'asa sasany dia mampiasa tranomboky C izay mampiasa callbacks ao anatiny izay tsy azo vahana, ka ny fikojakojana avy amin'ny `cb` dia mety hiteraka fanalan-jaza.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // tohizo ny backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Mitovy amin'ny `trace`, tsy azo antoka ihany satria tsy mifandrindra.
///
/// Io asa tsy manana synchronization guarentees fa tsy ampy raha ny `std` endri-javatra io dia tsy natambatra crate in.
/// Jereo ny fiasan'ny `trace` raha mila tahirin-kevitra sy ohatra bebe kokoa.
///
/// # Panics
///
/// Jereo ny fampahalalana momba ny `trace` ho an'ny fampandrenesana momba ny fikorontanana `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait iray misolo tena ny toe-backtrace, nanolotra ny `trace` crate asa ity.
///
/// Ny asa hay fantarina ny fanakatonana ho nanolotra zana-kazo, ary ny toetsika dia saika Naniraka ho toy ny fototra fanatanterahana tsy fantatra foana mandra-runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Miverina ny tondro fibaikoana an'ity rafitra ity ankehitriny.
    ///
    /// Ity no torolàlana manaraka ho fampiharana ao anaty frame, saingy tsy ny fampiharana rehetra no mitanisa an'io amin'ny 100% (fa amin'ny ankapobeny dia akaiky).
    ///
    ///
    /// Efa nitranga izany nanolorana azy ho zava-dehibe ny `backtrace::resolve` hampiakatra azy ho mariky ny anarany.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Miverina ny pointer stack ankehitriny.
    ///
    /// Raha toa ka tsy afaka mamerina ny tondro fantson'ity rafitra ity ny backend dia averina ny pointer null.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Miverina ny adiresy marika fanombohana ny endrik'ity fiasa ity.
    ///
    /// Izany dia miezaka rewind ny fampianarana niverina avy `ip` manondro ny fanombohan'ny asa ny, niverina fa tena ilaina.
    ///
    /// Amin'ny tranga sasany, na izany aza, ny backends dia hiverina `ip` fotsiny avy amin'ity fiasa ity.
    ///
    /// Ny sanda miverina dia azo ampiasaina indraindray raha toa ka tsy nahomby `backtrace::resolve` tamin'ny `ip` voalaza etsy ambony.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Miverina ny base adiresy ny Module izay ny filanjana an'i.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Tokony ho lohalaharana izany, mba hahazoana antoka fa mahazo laharam-pahamehana i Miri noho ny sehatra fampiantranoana
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ampiasaina amin'ny dbghelp fotsiny
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}