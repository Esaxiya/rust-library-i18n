use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr maka callback izay hahazo pointer dl_phdr_info isaky ny DSO izay nampifandraisina tao anatin'ilay fizotrany.
    // dl_iterate_phdr miantoka ihany koa fa ny mahery dia mihidy linker amin'ny voalohany ka hatramin'ny farany ny iteration.
    // Raha hiverina ny callback aotra iray tsy sarobidy ny iteration dia faranana tany am-boalohany.
    // 'data' halefa ho toy ny ady hevitra fahatelo amin'ny fiantsoana isaky ny antso.
    // 'size' manome ny haben'ny dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Mila manafoana ny fananganana ID sy ny angon-drakitra lohan-dohan'ny programa izay midika fa mila zavatra kely ihany koa isika avy amin'ny spec'ny ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ankehitriny isika dia tsy maintsy mamerina, mandika kely, ny firafitry ny karazana dl_phdr_info ampiasain'ny mpampifandray mavitrika an'i fuchsia ankehitriny.
// Chromium koa dia manana ity faritry ny ABI ity ary koa ny crashpad.
// Hatramin'izao dia te-hamindra ireo tranga ireo izahay mba hampiasa fikarohana elf fa mila manome izany izahay ao amin'ny SDK ary mbola tsy vita izany.
//
// Noho izany isika (sy izy ireo) dia mikatso ka mila mampiasa an'io fomba io izay miteraka fifamatorana henjana amin'ny fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Tsy misy fomba hahafantarana ny mijery raha toa ka e_phnum e_phoff dia marim-pototra.
    // libc dia tokony hiantoka antsika ho antsika, noho izany azo antoka ny mamorona silaka eto.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr dia maneho lozisialy lozisialy ELF 64-end amin'ny fahatanterahan'ny maritrano lasibatra.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr dia maneho lohateny fandaharana ELF manan-kery sy izay ao anatiny.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Tsy manana fomba hijerena raha marina ny p_addr na ny p_memsz.
    // Fuchsia ny libc parses ny fanamarihana na izany aza aloha dia miorina amin'ny maha eto lohapejy ireo dia tsy maintsy ho manan-kery.
    //
    // NoteIter tsy mitaky ny fototra tahirin-kevitra ho manan-kery fa tsy mitaky ny faritry ho manan-kery.
    // Matoky izahay fa libc no antoka fa izany no mitranga ho antsika eto.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Ny karazana taratasy ho an'ny manaova ID.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr maneho ny ELF lohapejy naoty ao amin'ny endianness ny lasibatra.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Ny naoty dia maneho an-tsoratra ELF (lohateny + atiny).
// Ny anarana dia tavela ho sombin-tsarimihetsika u8 satria tsy foana ny famaranana azy ary rust dia manamora ny fijerena raha mifanaraka na tsia ireo bytes.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter dia mamela anao hiverimberina soa aman-tsara amin'ny ampahan'ny naoty.
// Tapitra io raha vantany vao misy lesoka na tsy misy naoty intsony.
// Raha tsy manan-kery ianao iterate ny antontan-kevitra dia hiasa toy ny hoe tsy misy hita an-tsoratra.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Izany dia invariant ny asa fa manondro sy ny habe dia maneho ny manan-kery nomena ny oktety isan-karazany izay afaka vakiana rehetra.
    // Ny atin'ny an'ireny byte ireny dia mety misy, fa ny elanelam-potoana dia tsy maintsy mitombina mba ho azo antoka.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to fampifanarahana 'x' ho 'to'-byte fampifanarahana mihevitra 'to' dia herin'ny 2.
// Izany dia manaraka lamina iray fitsipika ao amin'ny C/C ++ ELF parsing fehezan-dalàna izay (x + to, 1)&-to no ampiasaina.
// Rust tsy mamela anao hanafoana ny fampiasana azy ka ampiasaiko
// Fiovan'ny 2-famenony hamerina izany.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 manimba Nom oktety avy amin'ny silaka (raha ankehitriny), ary koa miantoka fa ny farany dia properlly silaka mifanaraka.
// Raha ny habetsaky ny bytes nangatahina dia be loatra na ny silaka dia tsy azo ahitsy avy eo noho ny tsy fahampian'ny bytes sisa, Tsy misy miverina ary tsy miova ny silaka.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ity asa ity dia tsy misy mpanamory tena izy fa tsy maintsy tohanan'ny mpiantso hafa fa angamba ny 'bytes' dia tokony hampifanarahana amin'ny fampisehoana (sy ny fahamendrehan'ny maritrano).
// Ny soatoavina ao amin'ny sahan'ny Elf_Nhdr dia mety tsy misy dikany fa io fiasa io dia miantoka tsy misy zavatra toa izany.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Tsy mampidi-doza io raha mbola misy toerana malalaka ary nohamafisinay fotsiny fa raha ilay fanambarana etsy ambony dia tsy tokony hilamina izany.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Mariho fa sice_of: :<Elf_Nhdr>() dia mifanaraka hatrany amin'ny 4-byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Jereo raha efa tonga ny farany.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmute avy isika fa ny nhdr Diniho tsara ny vokatry struct.
        // Tsy matoky ny namesz na descsz ary mampidi-doza aza fanapahan-kevitra miorina amin'ny karazana.
        //
        // Koa na dia mialà tanteraka isika fako tokony mbola ho soa aman-tsara.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Dia midika fa ny ampahany no tanterahina.
const PERM_X: u32 = 0b00000001;
/// Manondro fa azo zahana ny ampahany.
const PERM_W: u32 = 0b00000010;
/// Manondro fa azo vakiana ny fizarana iray.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Maneho ny fizarana ELF mandritra ny fotoana maharitra.
struct Segment {
    /// Manome ny adiresy virtoaly runtime momba ny atiny amin'ity fizarana ity.
    addr: usize,
    /// Manome ny fahatsiarovana ny haben'ny ity ny ampahany anatiny.
    size: usize,
    /// Omeo ny adiresy virtoaly amin'ity fizarana ity miaraka amin'ny fisie ELF.
    mod_rel_addr: usize,
    /// Manome alalana hita ao amin'ny rakitra ELF.
    /// Ireo fahazoan-dàlana ireo dia tsy voatery ny alalana misy ankehitriny.
    flags: Perm,
}

/// Mamela iterate iray amin'ny Segments avy amin'ny DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Maneho ny ELF DSO (Objective Dynamic Shared).
/// Ity karazana ity dia manondro ireo angon-drakitra voatahiry ao amin'ny DSO tena izy fa tsy manao kopia azy manokana.
struct Dso<'a> {
    /// Ny mpampifandray mavitrika dia manome anarana antsika foana, na dia foana aza ilay anarana.
    /// Raha misy ny fanatanterahana lehibe dia foana io anarana io.
    /// Kanefa kosa raha ny iray nizara zavatra izany dia ho ny soname (jereo ny DT_SONAME).
    name: &'a str,
    /// Amin'ny Fuchsia dia saika manana ID manangana daholo ny mimari-droa fa tsy fangatahana hentitra izany.
    /// Tsy misy fomba fampitahana ny fampahalalana DSO amin'ny tena rakitra ELF aorian'izay raha tsy misy ny build_id ka takianay ny DSO tsirairay eto.
    ///
    /// Tsy raharahiana ny an'ny DSO raha tsy misy build_id.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Miverina iterator amin'ny Segments amin'ity DSO ity.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ireo lesoka ireo dia mametaka olana izay mipoitra mandritra ny famoahana vaovao momba ny DSO tsirairay avy.
///
enum Error {
    /// NameError dia midika fa nisy lesoka nitranga rehefa nanova ny tadin'ny style C ho tady rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError dia midika fa tsy nahita ID fananganana izahay.
    /// Mety ho satria na ny DSO tsy nanana manaova ID na noho ny ampahany misy ny manaova ID dia malformed.
    ///
    BuildIDError,
}

/// Miantso 'dso' na 'error' isaky ny DSO mifandray amin'ny fizotran'ny mpampifandray mavitrika.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter izay hanana iray amin'ireo fomba fihinana antsoina hoe mua DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr dia manome antoka fa hanondro toerana mety i info.name.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Izany asa ny fuchsia symbolizer Mamoaka ny fanamarihana ho an'ny rehetra ny vaovao hita ao amin'ny DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}