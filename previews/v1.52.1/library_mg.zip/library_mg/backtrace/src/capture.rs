use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Fanehoana backtrace fananana sy an'ny tena.
///
/// Ity rafitra Azo ampiasaina hisambotra ny backtrace amin'ny hevitra isan-karazany ao amin'ny fandaharana, ary tatỳ aoriana mba ampiasaina maso izay backtrace dia tamin'izany andro izany.
///
///
/// `Backtrace` manohana tsara tarehy-pirinty ny backtraces amin'ny alalan'ny fampiharana ny `Debug`.
///
/// # Endri-javatra ilaina
///
/// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Zana-kazo eto dia tononina avy eo ambony-to-ambany ny stack
    frames: Vec<BacktraceFrame>,
    // Ny index izay inoantsika no tena fiandohan'ny backtrace, manala ireo frame toa ny `Backtrace::new` sy `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Dikan-tsary misy sary iray ao anaty backtrace.
///
/// Ity karazana ity dia miverina toy ny lisitra iray avy amin'ny `Backtrace::frames` ary maneho frame stack iray ao anaty backtrace voasambotra.
///
/// # Endri-javatra ilaina
///
/// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Dikan-tsary iray azo alaina ao anaty backtrace.
///
/// Io karazana dia niverina ho toy ny lisitra avy any `BacktraceFrame::symbols` sy maneho ny Metadata ho famantarana eo amin'ny backtrace.
///
/// # Endri-javatra ilaina
///
/// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Hoe nambabo ny backtrace amin'ny callsite ity asa, niverina ny nanana solontena.
    ///
    /// Ilaina ity fiasa ity amin'ny fisolo tena ny backtrace ho zavatra ao amin'ny Rust.Zavatra tsy niverina sanda azo nalefa manerana kofehy sy pirinty tany an-kafa, sy ny zava-kendren'ny sanda io dia ho hita tena tanteraka.
    ///
    /// Mariho fa amin'ny sehatra sasany ny fahazoana backtrace feno sy famahana azy dia mety ho lafo be.
    /// Raha ny vola be loatra noho ny fampiharana azy io fa tsy ny nanolorana azy ho mampiasa ny `Backtrace::new_unresolved()` izay fialana ny famantarana résolution dingana (izay matetika maka ny lava indrindra), ary mamela deferring fa ny taty aoriana kely.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // te-hahazo antoka fa misy fefy eto esorina
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Mitovy amin'ny `new` ihany fa tsy mahavaha marika izany, ity dia misintona ny backtrace ho lisitry ny adiresy.
    ///
    /// Amin'ny manaraka ny `resolve` asa dia azo antsoina mba hamaha izany backtrace ny marika ho vakiana anarana.
    /// Misy io fiasa io satria ny fizotran'ny famahana dia mety maharitra fotoana be dia be fa ny dian-damosina rehetra dia mety tsy dia vita pirinty.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // tsy misy anarana marika
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // anarana marika ankehitriny
    /// ```
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    ///
    ///
    #[inline(never)] // te-hahazo antoka fa misy fefy eto esorina
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Miverina ny zana-kazo tamin'ny fotoana nisamborana an'ity backtrace ity.
    ///
    /// Ny fidirana voalohany amin'ity sombin-tsakafo ity dia mety ho ny fiasa `Backtrace::new`, ary ny sary farany dia toa zavatra momba ny nanombohan'ity kofehy ity na ny lahasa lehibe.
    ///
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Raha noforonina avy amin'ny `new_unresolved` ity backtrace ity dia hamaha ny adiresy rehetra ao ambadika mankany amin'ireo anarany ara-panoharana io fiasa io.
    ///
    ///
    /// Raha backtrace efa tapa-kevitra teo aloha, na noforonina ny alalan `new`, io no asa na inona na inona.
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Mitovy amin'ny `Frame::ip`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Mitovy amin'ny `Frame::symbol_address`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Same as `Frame::module_base_address`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Mamerina ny lisitry ny tandindona izay mifanitsy amin'ity frame ity.
    ///
    /// Raha ny mahazatra dia tsy misy afa-tsy famantarana iray isaky ny endriny, fa indraindray raha maro ny asa dia inlined ho iray marika toetsika dia maro no niverina.
    /// Ny marika voalohany voatanisa dia ny "innermost function", fa ny mariky ny farany dia ny ivelany (mpiantso farany).
    ///
    /// Mariho fa raha avy amina backtrace mbola tsy voavaha ity frame ity dia hiverina lisitra foana ity.
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Mitovy amin'ny `Symbol::name`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Same as `Symbol::addr`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Same as `Symbol::filename`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Mitovy amin'ny `Symbol::lineno`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Same as `Symbol::colno`
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Rehefa manonta lalana isika dia manandrana manala ny cwd raha misy izany, raha tsy izany dia manonta ny lalana fotsiny izahay.
        // Mariho fa amin'ny endrika fohy ihany koa no anaovantsika izany, satria raha feno izany dia azo inoana fa te-hanonta ny zava-drehetra isika.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}