#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// A formatter for backtraces.
///
/// Ity karazana Azo ampiasaina pirinty ny backtrace na aiza na aiza mihitsy ny backtrace avy.
/// Raha manana karazana `Backtrace` ianao dia efa ampiasain'ny fampiharana `Debug` ity endrika fanontana ity.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Ny randram-pirinty fa afaka pirinty
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Dian ny terser Ny tena tsara ihany backtrace izay ahitana fampahalalana manan-danja
    Short,
    /// Manonta backtrace izay misy ny fampahalalana azo atao rehetra
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Mamorona vaovao `BacktraceFmt` izay hanoratra Output any amin'ny nanome `fmt`.
    ///
    /// Ny tohan-kevitra `format` no hifehy ny fomba izay ny backtrace ny atonta izy, ary ny tohan-kevitra `print_path` dia hampiasaina mba pirinty ny `BytesOrWideString` ohatra ny filenames.
    /// Ity karazana ity dia tsy manao pirinty filenames akory, fa ity fiantsoana miverina ity dia takiana mba hanaovana izany.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Manao pirinty ny sasin-teny ho an'ny backtrace momba ny hatao pirinty.
    ///
    /// Izany dia takiana amin'ny sehatra sasany ho an'ny backtraces mba hanehoana endrika feno rehefa avy eo, ary raha tsy izany dia io no tokony ho fomba voalohany antsoinao aorian'ny namoronana `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Manampy ny toetsika ho an'ny backtrace output.
    ///
    /// Ity komity ity dia mamerina ohatra RAII amin'ny `BacktraceFrameFmt` izay azo ampiasaina hanonta sary iray, ary rehefa simba dia hampitombo ny kaonteran'ny frame.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Mamita ny vokatra azo avy any aoriana.
    ///
    /// Ity dia tsy misy op-op amin'izao fotoana izao fa ampiana ho an'ny mifanentana future miaraka amina endrika backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Amin'izao fotoana izao dia tsy misy op-- anisan'izany ity hook ahafahana manampy ny future.
        Ok(())
    }
}

/// A formatter ho an'ny iray fotsiny ny toe-backtrace.
///
/// Ity karazana ity dia noforonin'ny fiasa `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Manonta `BacktraceFrame` miaraka amin'ity mpandrafitra endrika ity.
    ///
    /// Hatao pirinty miverimberina ireo tranga `BacktraceSymbol` ao anatin'ny `BacktraceFrame`.
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Manonta `BacktraceSymbol` ao anatin'ny `BacktraceFrame`.
    ///
    /// # Endri-javatra ilaina
    ///
    /// Ity fiasa ity dia mitaky ny fampisehoana `std` an'ny `backtrace` crate alefa, ary ny fampiasa `std` dia alefa amin'ny toerana misy anao.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: tsy tsara izany satria tsy miafara amin'ny fanontana na inona na inona isika
            // miaraka amin'ny filename tsy utf8.
            // Soa ihany fa efa ho ny zava-drehetra no utf8 ka tsy tokony ho izany loatra ratsy loatra.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Manonta `Frame` sy `Symbol` tranainy manta, mazàna avy ao anatin'ny antso an-tariby manta an'ity crate ity.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Manampy fefy manta amin'ny famoahana backtrace.
    ///
    /// Zavatra tsy fomba, tsy toy ny teo aloha, mandray ny manta kevitra raha-dry zareo ho loharanom-baovao avy amin'ny toerana samy hafa.
    /// Mariho fa mety antsoina imbetsaka amin'ny frame iray izy io.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Manampy ny manta toetsika ny backtrace Output, anisan'izany ny tsangana vaovao.
    ///
    /// Ity fomba ity, toy ny teo aloha ihany, dia mandray ny tohan-kevitra raha tsy avy amin'ny toerana samihafa izy ireo.
    /// Mariho fa mety antsoina imbetsaka amin'ny frame iray izy io.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia dia tsy afaka maneho sary ao anaty fizotrany ka manana endrika manokana izay azo ampiasaina hanohanana azy avy eo.
        // Ataovy pirinty izany fa tsy manonta adiresy amin'ny endritsika manokana eto.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Tsy mila manonta ny frame "null", midika fotsiny izany fa somary naniry ny hiverina any lavitra be ny rafitra backtrace.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Mba hampihenana ny haben'ny TCB amin'ny enclave Sgx dia tsy te-hampihatra ny fiasan'ny famahana ny marika izahay.
        // Fa kosa, azontsika atao ny manonta ny offset an'ny adiresy eto, izay azo alaina an-tsarintany mba hanitsiana ny asany.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Ataovy pirinty ny index an'ny frame ary koa ny tondro fanoroana tsy voatery ho an'ny frame.
        // Raha mihoatra ny marika voalohany an'ity frame ity isika dia manonta ny fotsy fotsy ihany.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Manaraka izany, soraty ny anaran'ny marika, ampiasao ny fanovana endrika hafa raha mila fampahalalana misimisy kokoa isika.
        // Eto koa izahay dia mandray an-tanana ireo sary famantarana izay tsy manana anarana,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ary farany, amboary ny isa filename/line raha misy izy ireo.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line no atao pirinty ao amin'ny andalana eo ambanin'ny mariky anarana, ka pirinty sasany mety ho karazana whitespace tsara-mampifanaraka ny toetrantsika.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Solontena ho an'ny anatiny callback mba pirinty ny filename pirinty, ary avy eo ny isan'ny tsipika.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Manampia nomeraon'ny tsanganana, raha misy.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Tsy miahy afa-tsy ny marika voalohany amin'ny frame isika
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}