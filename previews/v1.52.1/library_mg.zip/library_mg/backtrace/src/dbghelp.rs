//! Module hanampy amin'ny fitantanana ny fatorana dbghelp amin'ny Windows
//!
//! Backtraces amin'ny Windows (farafahakeliny ho an'ny MSVC) no tena Powered amin'ny alalan'ny `dbghelp.dll` sy ny asa isan-karazany fa misy.
//! Ireo fampiasa ireo dia mavesatra *mavitrika* izao fa tsy mampifandray amin'ny `dbghelp.dll` mijanona.
//! Ity dia tanteraky ny tranomboky mahazatra (ary misy ny teôria takiana ao), saingy fiezahana manampy amin'ny fampihenana ny fiankinan-doha amin'ny statika sns amin'ny tranomboky satria matetika dia tsy voatery ny backtraces.
//!
//! Ny amin'ilay efa nanao hoe: `dbghelp.dll` foana entana soa aman-tsara ao amin'ny Windows.
//!
//! Mariho fa na dia mampiditra an-tsehatra an'ity fanohanana ity aza izahay dia tsy afaka mampiasa ny famaritana manta amin'ny `winapi`, fa mila mamaritra ireo karazana mpanondro asa ary mampiasa izany.
//! Tsy tena te hiditra amin'ny fandrindrana winapi izahay, noho izany manana Cargo endri-javatra `verify-winapi` izay manamafy fa ny fatorana rehetra dia mifanaraka amin'ny an'ny winapi ary ity endri-javatra ity dia azo atao ao amin'ny CI.
//!
//! Farany, mariho eto ianao fa ny dll tsy ho `dbghelp.dll` dia namaha ny entana, ary izany no iniana amin'izao fotoana izao.
//! Ny mieritreritra izany fa afaka manerantany Cache izy sy mampiasa izany eo amin'ny antso ho amin'ny API, fialana lafo loads/unloads.
//! Raha izany no olana ho an'ny mandefa detectors na zavatra toy izany isika dia afaka miampita ny tetezana rehefa tonga any.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Miasà manodidina ny `SymGetOptions` sy `SymSetOptions` tsy eo amin'ny winapi tenany.
// Raha tsy izany dia tsy ampiasaina izany raha tsy misy karazany roa ny manamarina manohitra ny winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Tsy voafaritra amin'ny winapi aloha
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Izany dia voafaritra ao amin'ny winapi, saingy diso (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Tsy voafaritra amin'ny winapi aloha
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ity makro ity dia ampiasaina hamaritana ny rafitra `Dbghelp` izay misy ao anatiny ireo tondro rehetra izay mety ho entintsika.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Ny DLL fenoina ho an'ny `dbghelp.dll`
            dll: HMODULE,

            // Toro-làlana tsirairay ho an'ny asa tsirairay azontsika ampiasaina
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Tamin'ny voalohany dia tsy nampiditra ny DLL izahay
            dll: 0 as *mut _,
            // Initiall ny fiasa rehetra dia napetraka ho aotra milaza fa mila entina mavitrika izy ireo.
            //
            $($name: 0,)*
        };

        // Typedef mora azo isaky ny karazana fiasa.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Fiezahana hanokatra `dbghelp.dll`.
            /// Mamerina ny fahombiazana raha toa ka mandeha na diso raha tsy mahomby i `LoadLibraryW`.
            ///
            /// Panics raha efa feno ny tranomboky.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fampiasana ho an'ny fomba tsirairay izay tianay hampiasaina.
            // Rehefa antsoina izy dia hamaky ilay tondro ampiasaina amin'ny cache na hampiditra azy ary hamerina ny sanda entina.
            // Voalaza fa mahomby ny entana.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy ara-dalàna hampiasana ny hidin-trano fanadiovana hanondroana ny asan'ny dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Atombohy aloha ny fanampiana rehetra ilaina amin'ny fidirana amin'ny asan'ny `dbghelp` API amin'ity crate ity.
///
///
/// Mariho fa ity no asa azo antoka ** **, dia anatiny manana ny synchronization.
/// Mariho koa fa azo antoka ny miantso izany fotoana maro recursively asa.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Ny zavatra voalohany tokony hataontsika dia ny fampifanarahana an'io asa io.Izy io dia azo antsoina miaraka amin'ny kofehy hafa na recursively ao anaty kofehy iray.
        // Mariho fa sarotra noho izany ny izy satria ny ampiasaintsika eto, `dbghelp`,*koa* dia mila ampifanarahina amin'ireo miantso hafa rehetra mankany `dbghelp` amin'ity dingana ity.
        //
        // Matetika dia tsy dia misy antso firy mankany `dbghelp` ao anatin'io dingana io ary azontsika atao tsara ny mieritreritra fa isika irery no mahazo azy.
        // Saingy, misy ihany ny mpampiasa voalohany iray hafa izay tsy maintsy atahorantsika momba ny maha-izy antsika, fa ao amin'ny tranomboky mahazatra.
        // Miankina amin'ity crate ity ny famakiam-boky Rust ho an'ny fanohanana backtrace, ary io crate io koa dia misy amin'ny crates.io.
        // Midika izany fa raha manonta backtrace panic ny tranomboky mahazatra dia mety hifaninana amin'ity crate ity avy amin'ny crates.io, ka miteraka segfault.
        //
        // Mba hanampiana amin'ny famahana ity olan'ny fampifanarahana ity dia mampiasa tetika voafaritra Windows eto izahay (izany rehetra izany, fameperana voafaritra manokana momba ny Windows).
        // Mamorona mutex antsoina hoe *session-local* izahay hiarovana an'ity antso ity.
        // Ny eritreritra eto dia ny fitsipika sy ny fitehirizam-boky crate io tsy voatery hizara Rust-ambaratonga APIs mba synchronize eto fa asa fa tsy afaka ambadiky ny sehatra mba ho azo antoka synchronizing-dry zareo amin'ny namany avy.
        //
        // Izany raha asa izany dia antsoina hoe ny alalan 'ny fitsipika famakiam-boky, na amin'ny alalan'ny crates.io azo antoka fa toy izany koa mutex no ho azony.
        //
        // Dia rehetra izany hoe fa ny zavatra voalohany ataontsika eto dia isika atomically mamorona `HANDLE` izay ny atao hoe mutex amin'ny Windows.
        // Izahay dia mampifandray kely ny kofehy hafa mizara ity fiasa ity manokana ary miantoka fa tokana iray ihany no noforonina isaky ny fiasa.
        // Mariho fa tsy nikatona velively ny tahony rehefa voatahiry manerantany.
        //
        // Rehefa avy efa tena handeha ilay hidin-trano fotsiny isika mahazo azy, ary ny `Init` mitana hanolotra avy isika, dia ho tompon'andraikitra amin'ny nandatsaka azy io amin'ny farany.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Ary satria efa narahina fampandrenesana soa aman-tsara isika rehetra, dia andao hanomboka handamina ny zava-drehetra.
        // Voalohany dia mila mahazo antoka isika fa ny `dbghelp.dll` dia tena mavesatra amin'ity dingana ity.
        // Izahay dia manao izany mavitrika mba hisorohana ny fiankinan-doha maharitra.
        // Natao izany teo amin'ny tantara mba hiasa amin'ny olana mampifandray hafahafa ary natao hanamboarana bizina kely kokoa ny binary satria io dia fitaovana fampiasana debugging fotsiny.
        //
        //
        // Vantany vao nosokafantsika ny `dbghelp.dll` dia mila miantso fiasa fanombohana ao isika, ary etsy ambany izany antsipiriany izany.
        // Isika ihany no manao izany indray mandeha anefa, noho izany dia efa nahazo eran-boolean milaza isika raha mbola nanao na tsia.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Hamarino fa napetraka ny sainam-pirenena `SYMOPT_DEFERRED_LOADS`, satria araka ny antontan-taratasin'i MSVC momba an'io: "This is the fastest, most efficient way to use the symbol handler.", ka andao hanao izany!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Ampiasao am-boalohany miaraka amin'ireo MSVC.Mariho fa mety tsy hahomby izany, fa tsy raharahiantsika izany.
        // Misy Tsy iray taonina mialoha kanto noho izany isan-se, fa LLVM anatiny toa tsy miraharaha ny zava-dehibe miverina eto ary iray amin'ireo trano famakiam-boky ao amin'ny LLVM sanitizer Mamoaka ny iray fampitandremana mampatahotra raha ho levona mandrakizay izany fa tsy miraharaha izany ankapobeny izany any aoriana any.
        //
        //
        // Tranga iray izay mipoitra be io ho an'ny Rust dia ny tranomboky mahazatra sy ity crate amin'ny crates.io ity dia samy te hifaninana amin'ny `SymInitializeW`.
        // Ny trano famakiam-boky mahazatra dia te-hanomboka tamin'ny voalohany ny fanadiovana matetika, fa rehefa mampiasa an'ity crate ity dia midika izany fa hisy olona ho tonga voalohany ary ny iray kosa haka ilay fanombohana.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}