//! Ny fanajanonana ny *emscripten* lasibatra.
//!
//! Raha ny fampiharana tsy mahazatra an'ny Rust ho an'ny sehatra Unix dia miantso mivantana amin'ireo API libunwind, ao amin'ny Emscripten kosa dia miantso ireo API C++ miala voly isika.
//! Tombontsoa fotsiny io satria ny fotoana naharetan'i Emscripten dia nampihatra ireo API ireo foana ary tsy nametraka libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Izany dia mifanaraka amin'ny fisehon'ny std::type_info ao amin'ny C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Ny mpitarika `\x01` byte eto raha ny marina dia famantarana mahagaga ho LLVM mba *tsy* hampihatra mangling hafa toy ny prefixing amin'ny `_` toetra.
    //
    //
    // Ity marika ity dia ilay latabatra ampiasain'ny C++ `std::type_info`.
    // Ireo zavatra manana ny karazany `std::type_info`, karazana mpanazava, dia manana tondro amin'ity latabatra ity.
    // Type descriptors dia hanovozan-kevitra ny C++ EH rafitra voafaritra etsy ambony sy ambany isika hanorina.
    //
    // Mariho fa ny tena habe dia lehibe kokoa noho ny 3 usize, fa ny varetantsika ihany no mila manondro ny singa fahatelo.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info ho an'ny kilasy rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Mazava ho azy fa hampiasa .as_ptr().add(2) izahay saingy tsy mandeha amin'ny sahan-kevitra voafetra izany.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Ity fanahy iniana ity dia tsy mampiasa ny drafitra mangling anarana mahazatra satria tsy tianay ny C++ afaka mamokatra na misambotra Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Ilaina izany satria ny kaody C++ dia afaka misambotra ny execption-tsika amin'ny std::exception_ptr ary mamerina azy imbetsaka, angamba na amin'ny kofehy hafa aza.
    //
    //
    caught: AtomicBool,

    // Mila Safidy ity satria manaraka ny semantika C++ ny androm-piainan'ilay zavatra: rehefa manosika ny Box ny catch_unwind dia tokony mbola hamela ilay zavatra maningana amin'ny fanjakana manan-kery satria ny mpandrava azy dia mbola hiantsoan'ny __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try raha ny marina dia manome antsika manondro ny rafitra ity.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Koa satria tsy avela ho panic ny cleanup() dia esorinay fotsiny.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}