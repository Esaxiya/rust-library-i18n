//! Ny fanajanonana ny *wasm32* lasibatra.
//!
//! Amin'izao fotoana izao dia tsy manohana an'io izahay, ka izany dia vongana fotsiny.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}