//! Amin'ny alalan'ny fampiharana ny panics stack Ny fanajanonana
//!
//! crate ity dia fampiharana panics ao amin'ny Rust mampiasa rafitra "most native" stack uninding ny sehatra izay anamboarana azy.
//! Izany indrindra sokajy vokany ho telo siny amin'izao fotoana izao:
//!
//! 1. MSVC lasibatra mampiasa `seh.rs` SEH ao amin'ny rakitra.
//! 2. Emscripten dia mampiasa fanafoanana C++ ao amin'ny fisie `emcc.rs`.
//! 3. Tanjona hafa rehetra mampiasa `gcc.rs` libunwind/libgcc ao amin'ny rakitra.
//!
//! Ny antontan-taratasy bebe kokoa momba ny fampiharana tsirairay dia azo jerena ao amin'ny maody tsirairay.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` dia maromaro amin'ny Miri, ka fahanginana fampitandremana.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Ny zavatra startup Rust runtime dia miankina amin'ireo tandindona ireo, koa ataovy ampahibemaso.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Tanjona izay tsy manohana ny famahorana.
        // - arch=wasm32
        // - diritti=tsy misy ("bare metal" lasibatra)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Ampiasao ny fe-potoana feon'ny Miri.
        // Mbola mila mavesatra ny fe-potoana fanao mahazatra etsy ambony ihany koa isika, satria manantena ny hamaritana entana vitsivitsy avy any rustc.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Ampiasao ny tena fotoana maharitra.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler in libstd antsoina hoe rehefa misy zavatra panic dia nandatsaka ivelan'i `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler in libstd antsoina hoe vahiny, rehefa afa-tsy tratra.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Teboka fidirana amin'ny fanondrotana faningana, solontena fotsiny amin'ny fampiharana manokana ny sehatra.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}