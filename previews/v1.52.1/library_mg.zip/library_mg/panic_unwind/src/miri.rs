//! Manala ny panics ho an'i Miri.
use alloc::boxed::Box;
use core::any::Any;

// Ny karazana enta-mavesatra aelin'ny motera Miri amin'ny alàlan'ny fialàny ho antsika.
// Tsy maintsy refesina pointer.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Nanome extern Miri-miasa hanomboka Ny fanajanonana.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Ny payload handeha ho any `miri_start_panic` isika dia ho tanteraka ny tohan-kevitra azontsika ao `cleanup` eto ambany.
    // Ka dia atsofokay indray mandeha monja izy io, hahazoana zavatra marobe fanondroana.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Indray ny fototra `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}