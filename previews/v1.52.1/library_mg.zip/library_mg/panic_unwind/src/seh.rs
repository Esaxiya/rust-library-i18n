//! Windows SEH
//!
//! Ao amin'ny Windows (amin'izao fotoana izao ihany ny MSVC), afa-tsy ny toerana misy anao dia voarafitra rafitra mikirakira Exception manazava (SEH).
//! Hafa mihitsy izany noho ny fikirakirana fanandramana miorina amin'ny Dwarf (oh: izay ampiasain'ny sehatra unix hafa) amin'ny resaka compiler interns, ka ny LLVM dia takiana mba hanohanana bebe kokoa amin'ny SEH.
//!
//! Ao Raha tsorina, inona no mitranga eto:
//!
//! 1. Ny asa `panic` miantso ny faneva asa Windows `_CxxThrowException` hitora-C++ -toy ny kanavaka, niteraka ny fanajanonana dingana.
//! 2.
//! Fiantsonana rehetra fisaka sy mivelatra ny compiler niteraka mampiasa ny toetra miasa `__CxxFrameHandler3`, dia miasa ao amin'ny CRT, ary ny fanajanonana fehezan-in Windows hampiasa izany toetra miasa mba hamono fanadiovana ny fehezan-dalàna an-stack.
//!
//! 3. Rehetra compiler-niteraka antso ho `invoke` manana fipetrahana pad Mametraha ho `cleanuppad` LLVM ny fampianarana, izay manondro ny fanombohan'ny fahazarana ny fanadiovana.
//! Ny toetra (amin'ny dingana 2, voafaritra ao amin'ny CRT) no tompon'andraikitra nihazakazaka ny fanadiovana tapaka.
//! 4. Taty aoriana ny fehezan-"catch" ao amin'ny `try` anaty (niteraka ny compiler) no novonoina, ary manondro fa fanaraha-maso dia tokony hiverina Rust.
//! Izany dia atao amin'ny alalan'ny ny `catchswitch` `catchpad` miampy ny fampianarana ao LLVM IR teny, fanaraha-maso ara-dalàna, rehefa niverina tamin'ny farany ny fandaharana amin'ny `catchret` fampianarana.
//!
//! Misy fahasamihafana manokana avy amin'ny gcc miorina afa-tsy fikirakirana dia:
//!
//! * Rust dia tsy manana fomban-toetra manokana, fa kosa * `__CxxFrameHandler3` foana.Ho fanampin'izany, tsy misy sivana fanampiny atao, noho izany dia manenjika ireo fanavakavahana C++ izay mitranga toa ny karazany manipy anay izahay.
//! Mariho fa ny fanipihana ankanavaka ao amin'ny Rust dia fihetsika tsy voafaritra ihany, ka tokony ho tsara izany.
//! * Efa nahazo ny sasany isika angon-drakitra mba mamindra manerana ny fanajanonana sisin, indrindra ny `Box<dyn Any + Send>`.Toy ny faningana Dwarf, ireto tondro roa ireto dia voatahiry ho karama ankoatr'izay ihany.
//! Ao amin'ny MSVC, na izany aza, tsy ilaina ny fizarana antontam-bola fanampiny satria voatahiry ny stack stack raha eo am-pamonoana ny asan'ny sivana.
//! Midika izany fa ny sahaza dia lasa mivantana amin'ny `_CxxThrowException` izay avy eo indray ao amin'ny sivana miasa mba hisy soratra amin'ny niisa toe ny `try` anaty.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ity dia mila safidy iray satria tratrantsika ny fanavakavahana amin'ny alàlan'ny fanovozan-kevitra ary ny mpandrava azy dia tanteraky ny fizotran'ny C++ .
    // Rehefa raiso ny tavoara avy tao an-kanavaka, dia mila ny hiala afa-tsy ao amin'ny fanjakana marim-pototra noho ny destructor mihazakazaka tsy misy avo roa heny-nandatsaka ny Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Voalohany, famaritana karazany maromaro.Misy karazana hafahafa manokana momba ny sehatra eto, ary betsaka izay namboarina tamim-pahanginana avy tamin'ny LLVM.Ny tanjon'izany rehetra izany dia ny fampiharana ny lahasa `panic` etsy ambany amin'ny alàlan'ny antso mankany `_CxxThrowException`.
//
// Mitaky asa io hevitra roa.Ny voalohany dia manondro ireo angon-drakitra ampiasainay, izay amin'ity tranga ity dia ny trait no tanjontsika.Mora hita!Manaraka, na izany aza, dia sarotra kokoa.
// Ity dia tondro ho an'ny rafitra `_ThrowInfo`, ary amin'ny ankapobeny dia natao hilazana ny fanavahana natsipy fotsiny.
//
// Amin'izao fotoana izao ny famaritana ny karazana [1] dia kely mitafy volom-biby, ary ny tena oddity (sy ny hafa avy amin'ny aterineto lahatsoratra) dia fa, pejy 32-bit ny sahaza dia sahaza fa ny teny 64-nanaikitra ny sahaza dia naneho ho 32-bit maivana avy amin'ny `__ImageBase` tandindona.
//
// Ny makro `ptr_t` sy `ptr!` ao amin'ireo maody etsy ambany dia ampiasaina hanehoana izany.
//
// Ny maze an'ny famaritana karazana dia manaraka akaiky izay navoakan'ny LLVM ho an'io karazana asa io.Ohatra, raha manangona izany C++ ao amin'ny fehezan-dalàna MSVC sy ataon-drizareo ny LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      mahafoana foo() { rust_panic a = {0, 1};
//          manipy a;}
//
// Izany ankapobeny ny zavatra isika dia miezaka ny haka tahaka.Maro amin'ireo soatoavina atolotra tsy tapaka eto ambany dia vao nadika avy LLVM,
//
// Na ahoana na ahoana, ireo rafitra rehetra naorina ao Toy izany koa, ary somary verbose fotsiny ho antsika.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Mariho fa ninia tsy niraharaha ny lalànan'ny mangling eto isika: tsy mila C++ afaka misambotra Rust panics amin'ny fanambaràna `struct rust_panic` fotsiny.
//
//
// Rehefa manova, ho azo antoka fa ny karazana kofehy anarana mifanaraka marina ilay nampiasaina tao `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Ny mpitarika `\x01` byte eto raha ny marina dia famantarana mahagaga ho LLVM mba *tsy* hampihatra mangling hafa toy ny prefixing amin'ny `_` toetra.
    //
    //
    // Ity marika ity dia ilay latabatra ampiasain'ny C++ `std::type_info`.
    // Ireo zavatra manana ny karazany `std::type_info`, karazana mpanazava, dia manana tondro amin'ity latabatra ity.
    // Type descriptors dia hanovozan-kevitra ny C++ EH rafitra voafaritra etsy ambony sy ambany isika hanorina.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Io karazana descriptor ihany no ampiasaina rehefa manipy ny maningana.
// Ny trondro anjara dia ampiasaina ny try anaty, izay miteraka ny azy TypeDescriptor.
//
// Tsara izany satria ny runtime MSVC dia mampiasa fampitahana tadiny amin'ny anaran'ny karazana mba hifanaraka amin'ny TypeDescriptors fa tsy ny fitovian'ny mpanondro.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Nampiasaina ny mpanimba raha nanapa-kevitra ny kaody C++ hisambotra ny maningana ary hampidina azy nefa tsy hanaparitaka azy.
// Ny ampahany amin'ny tratra intrinsika andrana dia hametraka ny teny voalohany amin'ny zavatra maningana ho 0 ka hialan'ny mpandringana azy.
//
// Mariho fa mampiasa ny x86 Windows "thiscall" miantso fivoriambe for C++ fiasan'ny mpikambana fa tsy ny toerana misy anao "C" miantso fivoriambe.
//
// Nyfomba manokana_copy dia somary miavaka eto: izy io dia antsoin'ny fotoana fohy MSVC eo ambanin'ny sakana try/catch ary ny panic izay amboarintsika eto dia hampiasaina ho valin'ny kopia tokana.
//
// Izany no ampiasaina ny C++ runtime ho fanohanana fakàna ankoatra ny tranga miavaka amin'ny std::exception_ptr, izay tsy afaka manohana, satria Box<dyn Any>tsy azo zahana.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException manome tanteraka amin'ny toe niisa ity, ka tsy misy tokony hamindra `data` raha tsy izany ny antontan-javatra.
    // Mandalo fotsiny isika niisa manondro izany asany.
    //
    // Ilaina eto ny ManallyDrop satria tsy tianay ny hilatsaka ny Exception rehefa miala sasatra.
    // Kosa dia ho latsaka amin'ny exception_cleanup izay hampiharina ny C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Izany ... mety toa mahagaga, ary Rariny izany.Ao amin'ny MSVC 32-bit, ny tondro eo anelanelan'ireo firafitra ireo dia izany ihany, tondro.
    // Ao amin'ny MSVC 64-bit kosa, ny tondro eo anelanelan'ny rafitra dia aseho ho offset 32-bit avy amin'ny `__ImageBase`.
    //
    // Noho izany, amin'ny 32-bit MSVC afaka manambara rehetra sahaza izany ao amin'ny: static`s ambony.
    // On 64-bit MSVC, dia tsy maintsy maneho subtraction ny sahaza in statics, izay Rust tsy mamela amin'izao fotoana izao, noho izany dia tsy afaka manao izany raha ny marina.
    //
    // Ny zavatra tsara indrindra manaraka, ary no mameno trano ireo amin'ny runtime (panicking dia efa tonga izao ny "slow path" ihany).
    // Ka eto izahay dia mandika indray ireo saha manondro ireo ho integer 32-bit ary avy eo mitahiry ny sanda mifandraika amin'izany (atomika, satria mety hisy panics miaraka).
    //
    // Ara-teknika ny runtime dia mety hanao nonatomic hamaky ireo saha, fa amin'ny teoria izy ireo tsy namaky ny *ratsy* danja noho izany tsy tokony ho dia ratsy loatra ...
    //
    // Na izany na tsy izany dia mila manao zavatra toy izany isika amin'ny ankapobeny mandra-pahatongantsika maneho ny asantsika bebe kokoa amin'ny statics (ary mety tsy ho vitantsika mihitsy izany).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // A tohivakana foana payload eto dia midika hoe tonga eto avy ny haben'ny (...) ny __rust_try.
    // Izany dia mitranga rehefa tratra ny fanavakavahana vahiny tsy Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Takiana amin'ny compiler ny misy (oh: lang lang item izy io), saingy tsy antsoin'ny compiler mihitsy satria ny __C_specific_handler na_except_handler3 no fiasan'ny toetra ampiasaina foana.
//
// Ka noho izany dia fotaka fanalana zaza fotsiny izy io.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}