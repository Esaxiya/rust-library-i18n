# The `rustc-std-workspace-std` crate

Jereo ny tahirin-kevitra ho an'ny `rustc-std-workspace-core` crate.