# The `rustc-std-workspace-core` crate

crate ity dia crate shim sy foana izay miankina amin'ny `libcore` fotsiny ary mamoaka indray ny atiny rehetra.
Ny crate no crux ny hery ny fitsipika famakiam-boky mba miankina crates avy any crates.io

Crates amin'ny crates.io fa ny fitsipika miankina amin'ny tranomboky mba mila miankina amin'ny `rustc-std-workspace-core` crate avy any crates.io, izay foana tsy mitondra fanatitra.

Mampiasa `[patch]` mba ho voasazy azy ity eto amin'ity crate repository.
Ho vokany, crates amin'ny crates.io dia hitaona ny fiankinan-doha edge ho `libcore`, ny dikan voafaritra ato amin'ity repository.
Izany dia tokony hisarika ny sisin'ny fiankinan-doha rehetra hahazoana antoka fa hanangana Cargo crates soa aman-tsara!

Mariho fa ny crates amin'ny crates.io dia mila miankina amin'ity crate ity miaraka amin'ny anarana `core` mba hiasa tsara ny zava-drehetra.Afaka manao izany izy ireo dia afaka mampiasa:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Amin'ny alalan'ny fampiasana ny `package` manan-danja ny crate dia nantsoin'Andriamanitra hoe tany `core`, midika izany Ho mitovy

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

rehefa miantso ny mpamorona ny Cargo, manome fahafaham-po ny torolàlana `extern crate core` voatondron'antoka nampidirin'ny mpamongady.




