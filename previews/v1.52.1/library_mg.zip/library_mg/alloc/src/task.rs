#![stable(feature = "wake_trait", since = "1.51.0")]
//! Types sy Traits ho niara-niasa tamin'ny asynchronous asa.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ny fametrahana ny taitra ny asa eo amin'ny mpanatanteraka.
///
/// Ity trait ity dia azo ampiasaina hamoronana [`Waker`].
/// An-mpanatanteraka dia afaka mamaritra ny fampiharana ity trait, ary mampiasa izany mba hanorina Waker mba handeha ho any amin'ny andraikitra izay novonoina tamin'izany-mpanatanteraka.
///
/// Ity trait dia safidy azo antoka sy azo antoka ergonomika amin'ny fananganana [`RawWaker`].
/// Tsy manohana ny mahazatra famolavolana-mpanatanteraka ny tahirin-kevitra izay ampiasaina mba hifoha ny asa dia voatahiry ao anatin'ny [`Arc`].
/// Executors sasany (indrindra fa ireo fa nandinika lalina rafitra) tsy afaka mampiasa API io, izay no nahatonga [`RawWaker`] misy toy ny safidy iray ho an 'ireo rafitra.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// A fototra `block_on` asa izay maka future ka nihazakazaka ho vita amin'ny kofehy amin'izao fotoana izao.
///
/// **Note:** Ity ohatra ny mpivarotra correct ho tsotra.
/// Mba hisorohana ny deadlocks, famokarana-implementations kilasy ihany koa ny tokony hiatrehana kafa antso ho `thread::unpark` ary koa ny nested invocations.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// A waker izay nanaitra ny amin'izao fotoana izao raha hoe kofehy.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Mihazakazaha future hahavita ny kofehy ankehitriny.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Kitiho ny future hahafahana mandoto azy.
///     let mut fut = Box::pin(fut);
///
///     // Mamorona vaovao teny manodidina mba ho lasa any amin'ny future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Mihazakazaha ny future mandra-pahavitany.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Mamoha io asa io.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Mifohaza io asa io nefa tsy mandany ny mifoha.
    ///
    /// Raha misy-mpanatanteraka manohana ny mora vidy kokoa mba hamoha fomba tsy mandevona ny waker, dia tokony handresy ny fomba io.
    /// Amin'ny alàlan'ny default, mamaky ny [`Arc`] izy ary miantso [`wake`] amin'ny clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // Famonjena, satria azo antoka izany soa aman-tsara raw_waker constructs
        // RawWaker avy amin'ny Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Io asa manokana io amin'ny fananganana RawWaker dia ampiasaina fa tsy
// mampiditra an'io amin'ny `From<Arc<W>> for RawWaker` impl, hahazoana antoka fa ny fiarovana ny `From<Arc<W>> for Waker` dia tsy miankina amin'ny fandefasana trait marina, fa kosa ny impls dia miantso an'io asa io mivantana sy mazava.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ampitomboy ny fanisana ny arc mba hanefy azy.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Mifohaza ny vidiny, mifindra ny Arc ho any amin'ny Wake::wake asa
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Mifohaza ny reference, mamatotra ny waker in ManuallyDrop mba tsy nandatsaka azy io
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Mampihena ny isa fanovozan-kevitra momba ny Arc araraka
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}