#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Ny atin'ny fahatsiarovana vaovao dia tsy voatanisa.
    Uninitialized,
    /// Ny fahatsiarovana vaovao dia azo antoka fa ho aotra.
    Zeroed,
}

/// Fampiasana ambaratonga ambany amin'ny fizarana, famerenana ary fanodinam-bokatra fahatsiarovana bebe kokoa eo amin'ny antontam-bato raha tsy manahy momba ireo tranga fehizoro rehetra tafiditra amin'izany.
///
/// Ity karazana ity dia tena tsara amin'ny fananganana rafitry ny angon-drakitrao toa ny Vec sy VecDeque.
/// Manokana:
///
/// * Mamokatra `Unique::dangling()` amin'ny karazana zero-habe.
/// * Mamokatra `Unique::dangling()` amin'ny vola omena aotra-lava.
/// * Misoroka ny fanafahana `Unique::dangling()`.
/// * Mahatratra ny tondra-drano rehetra amin'ny computations de capacité (mampiroborobo azy ireo hatramin'ny "capacity overflow" panics).
/// * Mpiambina amin'ny rafitra 32-bit manome mihoatra ny isize::MAX bytes.
/// * Mpiambina tsy hanitatra ny halavanao.
/// * Miantso `handle_alloc_error` ho an'ny fizarana fallible.
/// * Misy `ptr::Unique` ka manome ny mpampiasa tombony rehetra mifandraika amin'izany.
/// * Mampiasa ny fihoaram-pefy naverina avy amin'ny mpizara mba hampiasa ny fahaiza-manao lehibe indrindra misy.
///
/// Ity karazana ity dia tsy mandinika akory ny fahatsiarovana tantaniny.Rehefa nilatsaka izy dia *hanafaka* ny fitadidiany, saingy tsy hanandrana mandatsaka ny ao anatiny izy.
/// Anjaran'ny mpampiasa `RawVec` no mitantana ny tena zavatra *voatahiry* ao anaty `RawVec` iray.
///
/// Mariho fa ny mihoatra ny karazana zero dia tsy manam-petra foana, ka `capacity()` dia mamerina `usize::MAX` hatrany.
/// Midika izany fa mila mitandrina ianao rehefa mandingana an'io karazana io amin'ny `Box<[T]>`, satria tsy hanome ny halavany i `capacity()`.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Misy izany satria ny `#[unstable]` `const fn`s dia tsy mila mifanaraka amin'ny `min_const_fn` ary noho izany dia tsy azo antsoina amin'ny`min_const_fn`s koa izy ireo.
    ///
    /// Raha manova `RawVec<T>::new` na fiankinan-doha ianao dia mitandrema mba tsy hampiditra zavatra izay tena mandika ny `min_const_fn`.
    ///
    /// NOTE: Azontsika atao ny misoroka an'ity hack ity ary manamarina ny fampifanarahana amin'ny toetra `#[rustc_force_min_const_fn]` sasany izay mitaky fanajana ny `min_const_fn` fa tsy voatery hamela azy hiantso azy amin'ny `stable(...) const fn`/kaody mpampiasa tsy ahafahan'ny `foo` raha misy `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Mamorona `RawVec` lehibe indrindra (eo amin'ny antontam-baravarankely) nefa tsy mizara.
    /// Raha manana tsara `T` habeny, dia manao izany amin'ny fahaizana `RawVec` `0`.
    /// Raha `T` dia zero-habe, dia manao `RawVec` manana `usize::MAX` fahaizana.
    /// Ilaina amin'ny fampiharana ny fizarana tara.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Mamorona `RawVec` (eo amin'ny antontam-bolan'ny rafitra) miaraka amin'ny fepetra takiana amin'ny fahaiza-manao sy ny fampifanarahana amin'ny `[T; capacity]`.
    /// Io dia mitovy amin'ny fiantsoana `RawVec::new` raha `capacity` dia `0` na `T` dia mitovy habe.
    /// Mariho fa raha `T` dia aotra-habe dia midika izany fa tsy *hahazo*`RawVec` manana fahaiza-manao angatahina ianao.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra ny `isize::MAX` bytes ny fahaiza-mangataka.
    ///
    /// # Aborts
    ///
    /// Aborts amin'ny OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Toy ny `with_capacity`, fa manome toky ny buffer dia aotra.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Reconstitutes ny `RawVec` avy amin'ny manondro sy ny fahafahana.
    ///
    /// # Safety
    ///
    /// Ny `ptr` dia tsy maintsy atokana (eo amin'ny antontam-bolan'ny rafitra), ary amin'ny `capacity` nomena.
    /// Ny `capacity` dia tsy afaka mihoatra ny `isize::MAX` ho an'ny karazana habe.(Afa-tsy ny olana, pejy 32-bit rafitra).
    /// ZST vectors dia mety manana fahaiza-manao hatramin'ny `usize::MAX`.
    /// Raha ny `ptr` sy `capacity` dia avy amin'ny `RawVec` dia azo antoka izany.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Moana ny Vec kely.Hankany:
    // - 8 raha ny haben'ny singa dia 1, satria misy allocators antontam-bato dia mety manodidina ny fangatahana ny latsaky ny 8 oktety ho, fara fahakeliny, 8 oktety.
    //
    // - 4 raha singa antonony (<=1 KiB).
    // - 1 raha tsy izany, hialana amin'ny fandanindaniam-poana toerana ho an'ny Vec tena fohy.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Toy ny `new`, saingy voafetra ho fisafidianana ny mpanokana ho an'ny `RawVec` tafaverina.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` midika hoe "unallocated".ny karazana mavesatra aotra dia tsy raharahina.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Toy ny `with_capacity`, saingy voafetra ho fisafidianana ny mpanokana ho an'ny `RawVec` tafaverina.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Toa an'i `with_capacity_zeroed`, fa parameterized noho ny safidy ny allocator ho an'ny niverina `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Manova `Box<[T]>` ho `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Manova ny buffer manontolo ho `Box<[MaybeUninit<T>]>` miaraka amin'ny `len` voafaritra.
    ///
    /// Mariho fa ity dia hamerina manolo ny fanovana `cap` mety ho natao.(Jereo ny famaritana ny karazana raha mila fanazavana.)
    ///
    /// # Safety
    ///
    /// * `len` dia tokony ho lehibe kokoa na mitovy amin'ny fahaiza-manao nangatahina farany indrindra, ary
    /// * `len` dia tokony ho latsaka na mitovy amin'ny `self.capacity()`.
    ///
    /// Mariho fa ny fahaiza-manao nangatahina sy ny `self.capacity()` dia mety tsy hitoviana, satria ny mpizara dia afaka mandanjalanja be loatra ary mamerina sakana fahatsiarovana lehibe kokoa noho ny nangatahina.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Hamarino ny fahadiovan'ny antsasaky ny fepetra takian'ny fiarovana (tsy azontsika atao ny manamarina ny antsasany).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Sorohintsika ny `unwrap_or_else` eto satria mamontsina ny habetsaky ny LLVM IR novokarina.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Mamerina manamboatra `RawVec` avy amin'ny tondro, fahaiza-manao ary mpizara.
    ///
    /// # Safety
    ///
    /// Ny `ptr` dia tsy maintsy atokana (amin'ny alàlan'ny `alloc` mpizara), ary amin'ny `capacity` nomena.
    /// Ny `capacity` dia tsy afaka mihoatra ny `isize::MAX` ho an'ny karazana habe.
    /// (ahiahy fotsiny amin'ireo rafitra 32-bit).
    /// ZST vectors dia mety manana fahaiza-manao hatramin'ny `usize::MAX`.
    /// Raha ny `ptr` sy `capacity` dia avy amin'ny `RawVec` noforonina tamin'ny alàlan'ny `alloc`, dia azo antoka izany.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Mahazo mpanondro manta amin'ny fanombohana ny fizarana.
    /// Mariho fa `Unique::dangling()` ity raha `capacity == 0` na `T` dia mitovy habe aotra.
    /// Amin'ny tranga teo aloha, tokony hitandrina ianao.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Mahazo ny fahaizan'ny fizarana.
    ///
    /// Ho `usize::MAX` foana io raha toa ka zero ny haben'ny `T`.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Miverina referansa iraisana amin'ny mpizara izay manohana an'ity `RawVec` ity.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Manana sombim-pahatsiarovana natokana ho azy isika, hahafahantsika mandingana ny fizahana fizahana fotoana hahitana ny lamina misy antsika ankehitriny.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Manome toky fa ny buffer dia misy habaka farafaharatsiny hitazonana singa `len + additional`.
    /// Raha mbola tsy manana fahaiza-manao ampy izy dia hamindra toerana malalaka sy toerana mangorakoraka ahazoana mihetsika *O*(1).
    ///
    /// Hoferana io fihetsika io raha toa ka miteraka panic.
    ///
    /// Raha mihoatra ny `self.capacity()` ny `len` dia mety tsy hahavita hanome ilay habaka nangatahina izany.
    /// Tsy tena tsy azo antoka io, fa ny kaody tsy azo antoka *soratanao* izay miankina amin'ny fihetsik'ity fiasa ity dia mety ho tapaka.
    ///
    /// Izy io dia mety amin'ny fampiharana ny tsindry bokotra lehibe toy ny `extend`.
    ///
    /// # Panics
    ///
    /// Panics raha mihoatra ny `isize::MAX` bytes ny fahaiza-manao vaovao.
    ///
    /// # Aborts
    ///
    /// Aborts amin'ny OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Ny tahiry dia tokony nanala na hikorontana raha nihoatra ny `isize::MAX` ny len ka azo antoka izany raha tsy voamarina izao.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Mitovy amin'ny `reserve`, fa miverina amin'ny hadisoana fa tsy mikoropaka na manala.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Manome toky fa ny buffer dia misy habaka farafaharatsiny hitazonana singa `len + additional`.
    /// Raha mbola tsy izany dia hamindra ny farafahakeliny farafahakeliny ilaina amin'ny fitadidiana.
    /// Amin'ny ankapobeny dia io no mety ho habetsaky ny fitadidy ilaina, fa amin'ny ankapobeny, ny mpanokana dia afaka mamerina mihoatra ny nangatahinay.
    ///
    ///
    /// Raha mihoatra ny `self.capacity()` ny `len` dia mety tsy hahavita hanome ilay habaka nangatahina izany.
    /// Tsy tena tsy azo antoka io, fa ny kaody tsy azo antoka *soratanao* izay miankina amin'ny fihetsik'ity fiasa ity dia mety ho tapaka.
    ///
    /// # Panics
    ///
    /// Panics raha mihoatra ny `isize::MAX` bytes ny fahaiza-manao vaovao.
    ///
    /// # Aborts
    ///
    /// Aborts amin'ny OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Toy izany koa tahaka ny `reserve_exact`, fa miverina eo amin'ny fahadisoana fa tsy panicking na aborting.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Mamintina ny fizarana midina amin'ny vola voalaza.
    /// Raha 0 ny vola nomena, dia mifamadika tanteraka.
    ///
    /// # Panics
    ///
    /// Panics raha ny habetsaky ny nomena dia *lehibe kokoa* noho ny fahaiza-manao ankehitriny.
    ///
    /// # Aborts
    ///
    /// Aborts amin'ny OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Miverina raha mila mitombo ny buffer mba hanatanterahana ny fahaiza-manao fanampiny ilaina.
    /// Ampiasaina indrindra hanaovana ny inlining Reserve-antso azo atao raha tsy inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ity fomba ity dia matetika apetraka imbetsaka.Ka tianay ho kely araka izay azo atao izany, hanatsara ny fotoana fanangonana.
    // Saingy izahay koa dia maniry ny habetsaky ny atiny ho azo fikajiana araka izay azo atao mba hampandehanana haingana kokoa ny kaody novokarina.
    // Noho izany, ity fomba ity dia voasoratra am-pitandremana ka ny kaody rehetra miankina amin'ny `T` dia ao anatiny, raha toa ka ny ankamaroan'ny kaody izay tsy miankina amin'ny `T` araka izay azo atao dia ireo fiasa tsy generic mihoatra ny `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Azo antoka izany amin'ny alàlan'ny toe-javatra iantsoana.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Hatramin'ny namerenantsika ny fahafaha-`usize::MAX` rehefa `elem_size` no
            // 0, ny fahazoana ny eto voatery midika ny `RawVec` dia overfull.
            return Err(CapacityOverflow);
        }

        // Mampalahelo fa tsy misy azontsika atao marina momba ireo fanamarinana ireo.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Izy io dia manome antoka ny fitomboana mitombo.
        // Ny doble dia tsy afaka misondrotra satria `cap <= isize::MAX` sy ny karazana `cap` dia `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` dia tsy generic mihoatra ny `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ny teritery amin'ity fomba ity dia mitovy amin'ny an'ny `grow_amortized`, saingy matetika io fomba io dia matetika no kely loatra ka tsy dia manakiana.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Hatramin'ny namerenantsika ny fahafaha-`usize::MAX` raha ny haben'ny karazany
            // 0, ny fahazoana ny eto voatery midika ny `RawVec` dia overfull.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` dia tsy generic mihoatra ny `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ity fiasa ity dia ivelan'ny `RawVec` hampihenana ny fotoana fanangonana.Jereo ny hevitra etsy ambony `RawVec::grow_amortized` raha mila fanazavana.
// (Ny paramètre `A` dia tsy misy dikany, satria ny isan'ny karazana `A` samihafa hita amin'ny fampiharana dia kely kokoa noho ny isan'ny karazana `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Zahao eto ny lesoka hampihenana ny haben'ny `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Ny mpizara dia manamarina ny fitoviana fitoviana
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Manafaka ny memoakan'ny `RawVec`*tsy* manandrana mandatsaka ny atiny.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Asa afovoany ho an'ny fikirakirana hadisoana.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Mila antoka izao manaraka izao:
// * Izahay dia tsy manome zavatra X-`> isize::MAX` X byte-habe mihitsy.
// * Izahay dia tsy mihoatra ny `usize::MAX` ary manome kely dia kely.
//
// Ao amin'ny 64-bit dia mila manamarina fotsiny ny fihoaran'ny rano isika satria tsy hahomby ny fiezahana hametraka by00 `> isize::MAX`.
// Amin'ny 32-bit sy 16-bit dia mila manampy mpiambina fanampiny isika raha toa ka mihazakazaka eo amin'ny lampihazo isika izay afaka mampiasa ny 4GB rehetra eny amin'ny habakabaka ampiasain'ny mpampiasa, ohatra, PAE na x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Asa foibe iray tompon'andraikitra amin'ny fitaterana ny fihoaran'ny rano.
// Izany Ho azo antoka fa ny fehezan-dalàna ireo taranaka mifandray panics dia kely dia kely toy ny misy afa-tsy toerana iray, izay panics fa tsy ny bunch manerana ny Module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}