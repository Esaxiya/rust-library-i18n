//! Tady UtF-8 - voahodidin'ny
//!
//! Zavatra tsy mikendry ny [`String`] ahitana karazana, ny [`ToString`] trait noho ny niovany ho kofehy, ary maro karazana fahadisoana izay mety vokatry ny niara-niasa tamin'ny [: String`] s.
//!
//!
//! # Examples
//!
//! Misy fomba maro hamoronana [`String`] vaovao amin'ny tady ara-bakiteny:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Azonao atao ny mamorona [`String`] vaovao amin'ny efa misy amin'ny alàlan'ny fifanarahana
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Raha manana vector bytes UTF-8 manan-kery ianao dia afaka manao [`String`] iray amin'izany.Azonao atao koa ny manao ny mifamadika.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Fantatray fa manan-kery ireo byte ireo, ka `unwrap()` no hampiasainay.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Tady UtF-8 - voahodidin'ny
///
/// Ny karazany `String` no karazana tadin-dokotra mahazatra indrindra izay manana ny tompony amin'ny atin'ny kofehy.Izy io dia manana fifandraisana akaiky amin'ireo mpiara-miasa aminy indram-bola nindramina, dia ny [`str`] voalohany.
///
/// # Examples
///
/// Afaka mamorona `String` avy [a literal string][`str`] amin'ny [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Afaka append ny [`char`] ny `String` tamin'ny fomba [`push`], ary append ny [`&str`] amin'ny fomba [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Raha manana byte vector UTF-8 ianao dia azonao atao ny mamorona `String` avy aminy amin'ny fomba [`from_utf8`]:
///
/// ```
/// // bytes sasany, ao amin'ny vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Fantatray fa manan-kery ireo byte ireo, ka `unwrap()` no hampiasainay.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Strings dia manan-kery UTF-8 foana.Izany dia manana fiantraikany vitsivitsy, ny voalohany izay fa raha mila tsy UTF-8 kofehy, Diniho [`OsString`].Mitovy izy io, fa tsy misy ny teritery UTF-8.Ny dikany faharoa dia ny tsy ahafahanao manondro `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Nirakitra anarana dia natao ho tsy tapaka amin'ny fotoana fandidiana, nefa UTF-8 karazana litera dia tsy mamela antsika hanao izany.Ankoatra izany, dia tsy mazava ny ahoana ny zavatra tokony hiverina ny Fanondroana: a byte, ny codepoint, na grapheme sampahom-boaloboka.
/// Ny fomba [`bytes`] sy [`chars`] dia mamerina iteratera mandritra ny roa voalohany.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s fampiharana [`Deref`]`<Target=str>`, ary mandova ny fomba rehetra ['str`].Ho fanampin'izany, midika izany fa afaka mandefa `String` amina lahasa izay mila [`&str`] ianao amin'ny alàlan'ny ampersand (`&`) iray:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Izany dia mamorona [`&str`] avy amin'ny `String` dia mandroso azy eo. Fiovam-po io no lafo be, sy ny sisa amin'ny ankapobeny, no asa hanaiky [`&str`] S toy ny fanehoan-kevitra raha tsy mila `String` nandritra ny antony manokana.
///
/// Amin'ny toe-javatra sasany tsy manana Rust ampy fanazavana mba ho fiovam-po izany, fantatra amin'ny anarana hoe [`Deref`] fanerena.Ao amin'ny ohatra manaraka ity ny tady silaka [`&'a str`][`&str`] manatanteraka ny trait `TraitExample`, ary ny asa `example_func` mandray na inona na inona fa ny fitaovana ny trait.
/// Amin'ity tranga ity, ny Rust dia mila manova fiovam-po tanteraka roa, izay tsy azon'ny Rust atao.
/// Noho izany antony izany, ohatra manaraka ity dia tsy manangona.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Misy safidy roa mety miasa fa tsy.Ny voalohany dia ny fanovana ny tsipika `example_func(&example_string);` ho `example_func(example_string.as_str());`, amin'ny fampiasana ny fomba [`as_str()`] hamoahana mazava tsara ny tapa-kofehy misy ny kofehy.
/// Ny fomba faharoa miova `example_func(&example_string);` ho any `example_func(&*example_string);`.
/// Amin'ity tranga ity dia manadino `String` mankany [`str`][`&str`] izahay, avy eo manondro ny [`str`][`&str`] hiverina any [`&str`].
/// Ny fomba faharoa kosa dia idiomatika kokoa, na izany aza dia samy miasa ny manao ny fanovana mazava tsara fa tsy miantehitra amin'ny fiovam-po miharihary.
///
/// # Representation
///
/// Ny `String` dia misy singa telo: tondro iray amin'ny bytes sasany, ny halavany ary ny fahaizany.Manondro manondro ny anatiny `String` buffer mampiasa mba hitahiry ny tahirin-kevitra.Ny halavany dia ny isan'ny oktety amin'izao fotoana izao voatahiry ao amin'ny buffer, ary ny fahaiza-manao dia ny haben'ny ny buffer amin'ny oktety.
///
/// Araka izany, ny lavany dia ho foana latsaka na mitovy amin'ny fahafahana.
///
/// Izany buffer voatahiry foana ny antontan-javatra.
///
/// Azonao atao ny mijery ireo amin'ny fomba [`as_ptr`], [`len`], ary [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Ampivoary izany rehefa miorina tsara ny vector_into_raw_parts.
/// // Sakano ny fandatsahana ny angon-drakitra String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ny tantara dia manana bytes sivy ambin'ny folo
/// assert_eq!(19, len);
///
/// // Azontsika atao ny manangana String avy amin'ny ptr, len ary ny fahaiza-manao.
/// // Tsy azo antoka izany rehetra izany satria tompon'andraikitra amin'ny fanaovana antoka fa mitombina ireo singa ireo:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Raha misy `String` manana fahafahana ampy, singa ho fanampiana dia zarao tsy indray.Ohatra, diniho ity programa ity:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ity dia hamoaka izao manaraka izao:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Tamin'ny voalohany, tsy misy fahatsiarovana omena mihitsy, fa tahaka ny append ny kofehy, dia mampitombo ny fahafahany araka ny tokony ho.Raha toa isika fa mampiasa ny fomba [`with_capacity`] mba zarao ny fahafahana marina am-boalohany:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Mifarana amin'ny famoahana hafa isika:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Eto, tsy mila mizara fahatsiarovana bebe kokoa ao anaty loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Tombam-bidy mety hitranga rehefa manova `String` amin'ny byte UTF-8 by vector.
///
/// Ity karazana ity dia karazana lesoka amin'ny fomba [`from_utf8`] amin'ny [`String`].
/// Izany dia natao toy izany ho tsara mba tsy reallocations: ny fomba [`into_bytes`] hanome indray ny byte vector izay ampiasaina ao amin'ny fiovam-po ezaka.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Ny karazana [`Utf8Error`] nomen'i [`std::str`] dia maneho ny lesoka mety hitranga rehefa manova ny sombin'ny [`u8`] s ho [`&str`].
/// Amin'izay heviny izay, fa ny analogue ho `FromUtf8Error`, ary afaka mahazo ny iray avy amin'ny `FromUtf8Error` alalan'ny fomba [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// // bytes tsy mety sasany, ao amin'ny vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Tombam-bidy mety hitranga rehefa manova `String` avy amin'ny sombin-by by UTF-16.
///
/// Ity karazana ity dia karazana lesoka amin'ny fomba [`from_utf16`] amin'ny [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Mamorona `String` poakaty vaovao.
    ///
    /// Raha jerena fa foana ny `String`, dia tsy hanome buffer voalohany io.Na dia midika aza izany fa tsy dia lafo loatra ity fiasa voalohany ity, dia mety hiteraka fizarazarana be loatra izany rehefa ampiana data.
    ///
    /// Raha manana hevitra tena tahirin-kevitra ny `String` no mitantana, dia diniho ny fomba hisorohana [`with_capacity`] tafahoatra indray fanomezana.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Mamorona vaovao `String` foana amin'ny fahaizana manokana.
    ///
    /// `String`s dia manana buffer anatiny hitazona ny angon-drakitra.
    /// Ny fahafahana no halavan'ny buffer izany, ary azo queried amin'ny fomba [`capacity`].
    /// Izany dia miteraka ny fomba `String` foana, fa ny iray miaraka amin'ny voalohany buffer izay afaka hanao `capacity` oktety.
    /// Ilaina izany rehefa mety mampiditra antontan-kevitra marobe amin'ny `String` ianao, mampihena ny isan'ny reallocations tokony hataony.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Raha `0` ny fahaiza-manao nomena dia tsy misy fizarana hitranga, ary ity fomba ity dia mitovy amin'ny fomba [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Ny String dia tsy misy karatra, na dia manana fahaizana bebe kokoa aza izy
    /// assert_eq!(s.len(), 0);
    ///
    /// // Vita daholo ireo fa tsy mizaha toerana ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... fa izany dia mety hahatonga ny tadiny hitodika
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): miaraka cfg(test) ny fomba `[T]::to_vec` voajanahary, izay takiana amin'ity famaritana fomba ity dia tsy misy.
    // Koa satria tsy mitaky fomba ity noho ny hakany fanahy tanjona, ary tokony hofenoina fotsiny aho dia mahita ny slice::hack NB Module in slice.rs Raha mila fanazavana fanampiny
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Manova ny byte vector ho `String`.
    ///
    /// Tady ([`String`]) dia vita amin'ny bytes ([`u8`]), ary vector bytes ([`Vec<u8>`]) dia vita amin'ny bytes, ka io asa io dia mivadika eo anelanelan'ny roa.
    /// Tsy ny rehetra dia manan-kery byte slices: String`s, na izany aza: `String` dia mitaky fa manan-kery UTF-8.
    /// `from_utf8()` fanamarinana mba hahazoana antoka fa marina ny bytes UTF-8, ary avy eo manao ny fiovam-po.
    ///
    /// Raha toa ianao ka antoka fa ny byte silaka dia manan-kery UTF-8, nefa tsy te-iharan 'ny ambony ny mampanankery maso, misy mampidi-doza ity dika asa, [`from_utf8_unchecked`], izay manana fihetsika toy izany koa fa skips ny maso.
    ///
    ///
    /// Izany no fomba tokony hitandrina mba tsy handika ny vector, noho ny fahaiza izay nofidiko.
    ///
    /// Raha toa ka mila ny [`&str`] fa tsy ny `String`, Diniho [`str::from_utf8`].
    ///
    /// Ny mifanohitra amin'ity fomba ity dia [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Miverina [`Err`] raha tsy UTF-8 ny sombin-kazo misy famaritana ny antony tsy UTF-8 ny bytes omena.Ny vector nifindranao dia tafiditra ao koa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // bytes sasany, ao amin'ny vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Fantatray fa manan-kery ireo byte ireo, ka `unwrap()` no hampiasainay.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Diso bytes:
    ///
    /// ```
    /// // bytes tsy mety sasany, ao amin'ny vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Jereo ny tahirin-kevitrao for [`FromUtf8Error`] ho an'ny antsipirihany bebe kokoa momba izay azonao atao amin'ny fahadisoana izany.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Mamadika sombin-bytes amin'ny tadiny, ao anatin'izany ireo endri-tsoratra tsy mety.
    ///
    /// Ny tadiny dia vita amin'ny bytes ([`u8`]), ary ny byte ([`&[u8]`][byteslice]) dia vita amin'ny bytes, ka io asa io dia mivadika eo anelanelan'ny roa.Tsy ny rehetra dia manan-kery byte slices tady, na izany aza: tady no takiana mba hampanan-kery UTF-8.
    /// Nandritra izany fiovam-po, `from_utf8_lossy()` no hisolo izay tsy manan-kery UTF-8 sequences amin'ny [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], izay manatrika toy izao:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Raha toa ianao ka antoka fa ny byte silaka dia manan-kery UTF-8, nefa tsy te-iharan 'ny ambony ny fiovam-po, misy mampidi-doza ity dika asa, [`from_utf8_unchecked`], izay manana fihetsika toy izany koa fa skips ny taratasim-bola.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Miverina [`Cow<'a, str>`] ity fiasa ity.Raha ny byte silaka dia tsy manan-kery UTF-8, dia mila ampidiro eto ny fanoloana endri-tsoratra, izay hanova ny haben'ny amin'ny kofehy, ka noho izany, mila ny `String`.
    /// Fa raha efa manan-kery UTF-8 dia tsy mila fizarana vaovao.
    /// Ity karazana fiverenana ity dia ahafahantsika miatrika ireo tranga roa ireo.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // bytes sasany, ao amin'ny vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Diso bytes:
    ///
    /// ```
    /// // ny sasany tsy mety oktety
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Decode ny UTF-16-voafango vector `v` ho `String`, niverina [`Err`] raha misy tsy manan-kery `v` misy angon-drakitra.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Tsy vita amin'ny alàlan'ny fanangonana: : <Result<_, _>> () noho ny antony fampisehoana.
        // FIXME: azo tsorina indray ny fiasa rehefa mikatona ny #48994.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Arotsaho amin'ny fehezan-dalàna `v` UTF-16 - voahodina ho `String`, soloina [the replacement character (`U+FFFD`)][U+FFFD] ny angona tsy marina.
    ///
    /// Tsy toy ny [`from_utf8_lossy`] izay miverina ny [`Cow<'a, str>`], `from_utf16_lossy` niverina ny `String` hatramin'ny UTF-16 ho UTF-8 fiovam-po dia mitaky fanomezana fahatsiarovana.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Mamolavola `String` ho singa fototra.
    ///
    /// Mamerina ny tondro masaka amin'ny angona ifotony, ny halavan'ny tady (amin'ny bytes), ary ny fahafaha-manokana natokana ho an'ny angona (amin'ny bytes).
    /// Ireo dia mitovy hevitra amin'ny filaharana mitovy amin'ny tohan-kevitra mankany [`from_raw_parts`].
    ///
    /// Rehefa avy niantso izany ny asa, ny mpiantso no tompon'andraikitra mitantana ny fahatsiarovana teo aloha ny `String`.
    /// Ny hany fomba ahafahana manao izany dia ny hampiova finoana ny manta manondro, ny halavany, sy ny fahafahana miverina an-`String` ny [`from_raw_parts`] asa, mamela ny destructor mba hanatanteraka ny fanadiovana.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Mamorona vaovao `String` avy amin'ny lavany, fahaizana, ary manondro.
    ///
    /// # Safety
    ///
    /// Izany no tena azo antoka, noho ny isan'ny invariants izay tsy avy amin'ny teny anglisy:
    ///
    /// * Ny fahatsiarovana ao amin'ny `buf` dia tokony ho natolotry ny mpizara iray mitovy amin'ny ampiasain'ny tranomboky mahazatra, miaraka amina fampifanarahana takiana 1 marina.
    /// * `length` mila latsaky ny na mitovy amin'ny `capacity`.
    /// * `capacity` mila ny sandany marina.
    /// * Ny bytes `length` voalohany amin'ny `buf` dia mila UTF-8 manan-kery.
    ///
    /// Ny fandikana izany dia mety hiteraka olana toy ny fanimbana ny firafitry ny angon-drakitra anatiny.
    ///
    /// Ny tompon'ny `buf` dia afindra amin'ny `String` mahomby izay mety hifampiraharaha, hamindra na hanova ny atin'ny fahatsiarovana notondroin'ilay mpanondro araka ny sitrapony.
    /// Hamarino tsara fa tsy misy zavatra hafa mampiasa ny tondro rehefa niantso ity asa ity.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Ampivoary izany rehefa miorina tsara ny vector_into_raw_parts.
    ///     // Sakano ny fandatsahana ny angon-drakitra String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Manova ny byte vector mankany `String` nefa tsy manamarina fa misy UTF-8 manan-kery io tady io.
    ///
    /// Jereo ny kinova azo antoka, [`from_utf8`], raha mila fanazavana fanampiny.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity satria tsy manamarina raha mitentina UTF-8 ny bytes nolalovana tamin'io.
    /// Raha voahitsakitsaka io faneriterena io dia mety hiteraka olana tsy fahatsiarovan-tena amin'ireo mpampiasa future an'ny `String`, satria ny sisa amin'ny famakiam-boky mahazatra dia mihevitra fa UTF-8 manan-kery no tady.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // bytes sasany, ao amin'ny vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Manova `String` ho byte vector.
    ///
    /// Mandany ny `String` ity, ka tsy mila maka tahaka ny atiny izahay.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Manala sombin-tadiny misy ny `String` manontolo.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Manova `String` ho tsipika azo ahodina.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Manampy silaka tadiny omena eo amin'ny faran'ity `String` ity.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Miverina ity fahafahan'ny `String` ity, amin'ny bytes.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Manome toky fa ny fahaizan'ity `String` ity dia farafaharatsiny `additional` bytes lehibe kokoa noho ny halavany.
    ///
    /// Ny fahafahana azo Nitombo mihoatra noho `additional` Bytes raha mifidy, mba tsy reallocations matetika.
    ///
    ///
    /// Raha tsy tianao ity fihetsika "at least" ity dia jereo ny fomba [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics raha ny vaovao Tondraka [`usize`] fahafahana.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Mety tsy hampiakatra ny fahaiza-manao izany raha ny marina.
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ankehitriny manana halavan'ny 2 sy ny fananana fahafahana ny 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Satria efa manana fahaizana 8 fanampiny isika, miantso an'ity ...
    /// s.reserve(8);
    ///
    /// // ... tsy mitombo.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Manome toky fa ny fahaizan'ny `String` dia `additional` bytes lehibe kokoa noho ny halavany.
    ///
    /// Diniho ny fampiasana ny fomba [`reserve`] raha tsy hoe fantatrao tsara kokoa noho ilay mpanome.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra `usize` ny fahafaha-manao vaovao.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Mety tsy hampiakatra ny fahaiza-manao izany raha ny marina.
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ankehitriny manana halavan'ny 2 sy ny fananana fahafahana ny 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Satria efa manana fahaizana 8 fanampiny isika, miantso an'ity ...
    /// s.reserve_exact(8);
    ///
    /// // ... tsy mitombo.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Miezaka mitahiry fahaiza-manao farafahakeliny `additional` singa bebe kokoa hampidirina ao amin'ny `String` nomena.
    /// Ny famoriam-bola dia mety hitahiry toerana bebe kokoa hisorohana ny fizahana toerana matetika.
    /// Aorian'ny fiantsoana `reserve`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional`.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// # Errors
    ///
    /// Raha mihoa-pefy ny fahafaha-manao, na mitatitra ny tsy fahombiazan'ny mpizara, dia niverina ny lesoka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Arovy mialoha ny fahatsiarovana, mivoaka raha tsy vitantsika
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Fantatsika izao fa tsy afaka OOM eo afovoan'ny asa sarotra ataontsika
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Miezaka ny hitehirizany ny kely indrindra afaka ho marina kokoa ny singa `additional` ho nakambana ao amin'ny nomena `String`.
    ///
    /// Aorian'ny fiantsoana `reserve_exact`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional`.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// Mariho fa ny mpizara dia mety hanome toerana betsaka kokoa noho ny angatahany.
    /// Noho izany, ny fahaiza-manao dia tsy azo atokisana ho kely indrindra.
    /// Aleo `reserve` raha andrasana ny fampidirana future.
    ///
    /// # Errors
    ///
    /// Raha mihoa-pefy ny fahafaha-manao, na mitatitra ny tsy fahombiazan'ny mpizara, dia niverina ny lesoka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Arovy mialoha ny fahatsiarovana, mivoaka raha tsy vitantsika
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Fantatsika izao fa tsy afaka OOM eo afovoan'ny asa sarotra ataontsika
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Mamintina ny fahaizan'ity `String` ity hifanaraka amin'ny halavany.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Mampihena ny fahafahan'ny `String` ity miaraka amin'ny fatorana ambany.
    ///
    /// Ny fahaiza-manao dia hijanona farafahakeliny lehibe toy ny halavany sy ny sanda omena.
    ///
    ///
    /// Raha toa ka ambany noho ny fetra ambany ny fahafaha-miasa ankehitriny dia tsy misy izany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Manampy ny [`char`] nomena amin'ny faran'ity `String` ity.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Miverina sombin-tsoratra byte an'ny 'String` atiny.
    ///
    /// Ny mifanohitra amin'ity fomba ity dia [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Shortens `String` ity ho any amin'ny halavan'ny voafaritra.
    ///
    /// Raha `new_len` dia lehibe noho ny amin'izao fotoana izao amin'ny kofehy ny halavany, tsy misy vokany izany.
    ///
    ///
    /// Mariho fa ity fomba ity dia tsy misy fiatraikany amin'ny fahaiza-manao natokana ho an'ny kofehy
    ///
    /// # Panics
    ///
    /// Panics `new_len` raha tsy mitoetra eo amin'ny sisin [`char`].
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Esorina ny endri-tsoratra farany amin'ny buffer string ary avereno.
    ///
    /// Miverina [`None`] raha foana ity `String` ity.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Manala [`char`] amin'ity `String` ity amin'ny toerana byte ary hamerina azy.
    ///
    /// Hetsika *O*(*n*) ity, satria mila maka tahaka ny singa rehetra ao anaty buffer izy io.
    ///
    /// # Panics
    ///
    /// Panics raha `idx` dia lehibe kokoa noho ny na mitovy amin'ny: String` ny lavany, na raha tsy mitoetra eo amin'ny sisin [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Esory daholo ny lalao `pat` ao amin'ny `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Matches dia tsikaritra dia nesoriny tsy iteratively, izany amin'ny toe-javatra misy fomba roa, dia ny voalohany ihany dia hesorina lamina:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SAFETY: ny manomboka sy ny fiafarana dia amin'ny fetra utf8 byte isaky ny
        // ny Searcher docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Ireo endri-tsoratra notondroin'ny predicate ihany no tazonina.
    ///
    /// Amin'ny teny hafa, mpandray anjara rehetra `c` hanala izany fa hiverina `f(c)` `false`.
    /// Ity fomba ity dia miasa amin'ny toerany, mitsidika ny tarehin-tsoratra tsirairay avy indray mandeha amin'ny filaharana tany am-boalohany, ary mitahiry ny filaharan'ny tarehin-tsoratra notanana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Ny filaharana tena izy dia mety ilaina amin'ny fanarahana ny fanjakana ivelany, toy ny index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Arotsaho amin'ny char manaraka ny idx
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Mampidira toetra ao amin'ity `String` ity amin'ny toerana byte.
    ///
    /// Izany dia *O*(*n*) mila fandidiana araka ny maka singa rehetra ao amin'ny buffer.
    ///
    /// # Panics
    ///
    /// Panics raha `idx` lehibe kokoa noho ny halavan'ny `String`, na raha tsy mipetraka amin'ny fetran'ny [`char`] izy.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Atsofohy ao amin'ity `String` ity ny tadin'ny tadiny.
    ///
    /// Izany dia *O*(*n*) mila fandidiana araka ny maka singa rehetra ao amin'ny buffer.
    ///
    /// # Panics
    ///
    /// Panics raha `idx` lehibe kokoa noho ny halavan'ny `String`, na raha tsy mipetraka amin'ny fetran'ny [`char`] izy.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Miverina fanovana azo ovaina amin'ny atin'ny `String` ity.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity satria tsy manamarina raha mitentina UTF-8 ny bytes nolalovana tamin'io.
    /// Raha voahitsakitsaka io faneriterena io dia mety hiteraka olana tsy fahatsiarovan-tena amin'ireo mpampiasa future an'ny `String`, satria ny sisa amin'ny famakiam-boky mahazatra dia mihevitra fa UTF-8 manan-kery no tady.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Miverina ny halavan'ity `String` ity, amin'ny bytes, fa tsy [`char`] s na graphemes.
    /// Raha atao teny hafa, dia mety tsy ilay fiheveran'ny olombelona ny halavan'ny kofehy.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Miverina `true` raha ity `String` ity dia manana halavan'ny aotra, ary `false` raha tsy izany.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Mamaky ny kofehy roa amin'ny nomena byte tondro.
    ///
    /// Miverina `String` vao natokana.
    /// `self` misy bytes `[0, at)`, ary ny `String` niverina dia misy bytes `[at, len)`.
    /// `at` dia tokony ho eo amin'ny fari-kevitry ny kaody UTF-8.
    ///
    /// Mariho fa ny fahafahan'ny `self` tsy miova.
    ///
    /// # Panics
    ///
    /// Panics raha tsy eo amin'ny fari-kaody `UTF-8` ny `at`, na raha mihoatra ny faran'ny kaody farany amin'ny kofehy izy io.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Mametaka an'ity `String` ity, manala ny atiny rehetra.
    ///
    /// Na dia midika aza izany fa hanana lava aotra ny `String`, tsy mikasika ny fahaizany izany.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Mamorona iterator mitsika izay manala ny elanelam-potoana voatondro ao amin'ny `String` ary manome ny `chars` nesorina.
    ///
    ///
    /// Note: Ny elanelan'ny singa dia nesorina na dia tsy levona hatramin'ny farany aza ilay miverina.
    ///
    /// # Panics
    ///
    /// Panics raha ny teboka fanombohana na ny fiafarana dia tsy mitoetra amin'ny fari-tany [`char`], na raha toa ka ivelan'ny fetra izy ireo.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Esory ny isan-karazany ka mandra-β avy amin'ny kofehy
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ny faritra feno dia manadio ny tadiny
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Fiarovana amin'ny fahatsiarovana
        //
        // Ny String dikan-Drain tsy manana olana fiarovana ny fahatsiarovana ny vector dikan-.
        // Ny tahirin-kevitra tsotra fotsiny oktety.
        // Satria isan-karazany mitranga ao amin'ny Drop namaboana, raha ny Drain iterator no tafaporitsaka, ny fanesorana dia tsy ho tanteraka.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Makà indram-bola indroa miaraka.
        // Ny &mut String dia tsy ho tafiditra raha tsy vita ny famerenana, ao amin'ny Drop.
        let self_ptr = self as *mut _;
        // Famonjena, `slice::range` sy `is_char_boundary` hanao ny taratasim-bola mety fetra.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Esorina ny elanelam-potoana voalaza ao amin'ny kofehy, ary soloina ny tady nomena azy.
    /// Ny tadiny nomena dia tsy tokony hitovy halava amin'ny elanelam-potoana.
    ///
    /// # Panics
    ///
    /// Panics raha ny teboka fanombohana na ny fiafarana dia tsy mitoetra amin'ny fari-tany [`char`], na raha toa ka ivelan'ny fetra izy ireo.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Sasao ny elanelana mandra-pahatongan'ny β amin'ilay tady
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Fiarovana amin'ny fahatsiarovana
        //
        // Change_range dia tsy manana olana momba ny fiarovana ny fahatsiarovana an'ny vector Splice.
        // ny vector dikan-.Ny data dia bytes tsotra fotsiny.

        // FAMPITANDREMANA: Ny fametrahana an'io fanovana io dia mety ho (#81138) tsy mitombina
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // FAMPITANDREMANA: Ny fametrahana an'io fanovana io dia mety ho (#81138) tsy mitombina
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ny fampiasana `range` indray dia ho tsy marim-pototra (#81138) Heverinay fa ny fari-tany notaterin'i `range` dia mijanona ho iray ihany, saingy ny fampiharana ny fahavalo dia mety hiova eo anelanelan'ny antso
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Niova fo io `String` ho [`Box`]: <: [`str`]> `.
    ///
    /// Hampihena ny fahafaha-manao tafahoatra izany.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Miverina sombin-by by [`u8`] s izay noezahina navadika ho `String`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // bytes tsy mety sasany, ao amin'ny vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Miverina ny oktety izay niezaka niova ho amin'ny `String`.
    ///
    /// Izany no fomba tsara naorina mba tsy fanomezana.
    /// Handany ny lesoka izy, mamindra ny bytes, ka tsy mila atao kopian'ny bytes.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // bytes tsy mety sasany, ao amin'ny vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Manangàna `Utf8Error` hahazoana tsipiriany bebe kokoa momba ny tsy fahombiazan'ny fiovam-po.
    ///
    /// Ny karazana [`Utf8Error`] nomen'i [`std::str`] dia maneho ny lesoka mety hitranga rehefa manova ny sombin'ny [`u8`] s ho [`&str`].
    /// Amin'io lafiny io dia fampitahana amin'ny `FromUtf8Error`.
    /// Jereo ny antontan-taratasiny raha mila fanazavana fanampiny momba ny fampiasana azy.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // bytes tsy mety sasany, ao amin'ny vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ny byte voalohany dia tsy mety eto
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Satria miverimberina amin'ny `String`s isika, afaka misoroka farafahakeliny fizarana iray amin'ny alàlan'ny fahazoana ny tadiny voalohany amin'ilay iterator ary ampidiro ao aminy ireo tadina manaraka rehetra.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Satria miverimberina amin'ny CoWs izahay, azontsika atao ny misoroka (potentially) farafaharatsiny fividianana iray amin'ny alàlan'ny fahazoana ny entana voalohany ary mampiditra izany amin'ireo entana manaraka rehetra.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Fitaovana mora ampiasaina izay manolo-tena ho an'ny `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Mamorona `String` foana.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Mampihatra ny mpandraharaha `+` amin'ny famolavolana kofehy roa.
///
/// Izany manimba ny `String` eo amin'ny ankaviany-tanana sy ny lafiny indray mampiasa ny buffer (mitombo izany raha ilaina).
/// Atao io mba hisorohana ny fizarana `String` vaovao sy ny fanaovana kopia ny atiny rehetra isaky ny asa, izay mety hitarika amin'ny *O*(*n*^ 2) fotoana fandehanana rehefa manamboatra kofehy *n*-byte amin'ny alàlan'ny fanamafisana miverimberina.
///
///
/// Ny kofehy amin'ny ilany ankavanana dia indramina ihany;ny atiny dia adika amin'ny `String` niverina.
///
/// # Examples
///
/// Ny roa string `string` dia maka ny voalohany isa ary mampindrana ny faharoa:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` afindra ary tsy azo ampiasaina intsony eto.
/// ```
///
/// Raha te hampiasa ny `String` voalohany ianao dia azonao atao ny manangona azy ary mampiditra ilay clone ho solony:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` mbola manan-kery eto.
/// ```
///
/// Concatenating `&str` slices azo atao amin'ny alalan'ny mamelombelona ny voalohany ny `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Mampihatra ny mpandraharaha `+=` amin'ny fampidirana ao amin'ny `String`.
///
/// Izany dia manana fihetsika toy izany koa ho toy ny fomba [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Ny karazana antsoina for [`Infallible`].
///
/// Io solonanarana io dia misy ho an'ny fampifanarahana mihemotra, ary mety ho lany andro amin'ny farany.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait noho ny hanova ny zava-dehibe ho an'ny `String`.
///
/// Izany trait dia ampiharina avy hatrany na inona na inona karazana izay manatanteraka ny [`Display`] trait.
/// Araka izany, `ToString` dia tsy tokony hampiharina mivantana:
/// [`Display`] fa tsy tokony ho ampiharina, ary mahazo ny `ToString` fampiharana maimaim-poana.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Manova ny sanda nomena ho `String`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Ao amin'io fampiharana, ny `to_string` panics raha ny fomba fampiharana ny `Display` hiverina fahadisoana.
/// Ity dia manondro fampiharana `Display` tsy mety satria `fmt::Write for String` tsy mamerina hadisoana velively.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Ny mahazatra tondrozotra dia ny tsy inline levitra asany.
    // Na izany aza, manala `#[inline]` avy amin'izany fomba mahatonga tsy regressions tsinontsinona.
    // Jereo ny <https://github.com/rust-lang/rust/pull/74852>, ny farany fanandramana mba miezaka ny hanala izany.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Niova fo ny `&mut str` ho `String`.
    ///
    /// Ny valiny dia atokana eny amin'ny antontam-bato.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ny fitsapana dia misintona libstd, izay miteraka lesoka eto
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Mivadika ilay sombin-boaty `str` nomena `String`.
    /// Marihina fa manana ny silaka `str`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Mamadika ny `String` nomena ho an'ny tapa-`str` boaty izay tompony.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Manova ny tapa-tady ho lasa variana indramina.
    /// Tsy misy fanomezana antontam-bato dia tanterahina, ary ny kofehy tsy nadika.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Niova fo ho String ho any an-Owned Variant.
    /// Tsy misy fanomezana antontam-bato dia tanterahina, ary ny kofehy tsy nadika.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Manova ny tadin'ny String ho lasa variana indramina.
    /// Tsy misy fanomezana antontam-bato dia tanterahina, ary ny kofehy tsy nadika.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Niova fo ny nomena ny vector `String` `Vec` izay mihazona soatoavin'ny karazana `u8`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Famerenana miverimberina ho an'ny `String`.
///
/// Ity estr ity dia noforonina tamin'ny alàlan'ny [`drain`] amin'ny [`String`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Hampiasaina ho&'a mut String ao amin'ny mpanimba
    string: *mut String,
    /// Fanombohana ampahany hanesorana
    start: usize,
    /// Hisy Intsony ny anjara mba hanala
    end: usize,
    /// Isan-karazany amin'izao fotoana sisa tavela mba hanala
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Mampiasà Vec::drain.
            // "Reaffirm" ny fisafoana ny fetra mba hisorohana ny kaody panic atsofoka ao indray.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Miverina ny sisa (zana) iterator tady izany ho toy ny silaka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef impls etsy ambany rehefa filaminana.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Tsy fahampiana rehefa miorina amin'ny `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>ho an'ny Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ho an'ny Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}