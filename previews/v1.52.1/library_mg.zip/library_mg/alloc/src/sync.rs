#![stable(feature = "rust1", since = "1.0.0")]

//! Thread-azo antoka reference-Ny fisiana ara-sahaza.
//!
//! Zahao ny rakitra [`Arc<T>`][Arc] raha mila fanazavana fanampiny.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Fepetra malefaka amin'ny habetsaky ny referansa mety hatao amin'ny `Arc`.
///
/// Ny fandehanana ambonin'ity fetra ity dia hanafoana ny programa (na dia tsy voatery hatao aza) amin'ny referansa _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer tsy manohana fahatsiarovana fefy.
// Mba hialana amin'ny tatitra diso diso amin'ny fampiharana Arc/Malemy dia ampiasao entana atomika ho an'ny fampifanarahana.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Toro-fanisana fanisana isa azo antoka amin'ny kofehy.'Arc' midika hoe 'Atomically Reference Counted'.
///
/// Manome ny karazana Shared `Arc<T>` tompony ny zava-dehibe ny karazana `T`, omena ao amin'ny antontan-javatra.Fanononany ny fiandrianam-[`clone`][clone] amin'ny `Arc` mamokatra `Arc` vaovao, ohatra, izay manondro ny fanomezana toy izany koa eo amin'ny antontam-bato ho toy ny loharanom-`Arc`, raha mitombo ny boky fanisana.
/// Rehefa rava ny tondro `Arc` farany amin'ny fizarana nomena dia nidina ihany koa ny sanda voatahiry ao amin'io fizarana io (matetika antsoina hoe "inner value").
///
/// Dia nizara andinin-tsoratra masina ao amin'ny Rust nandrara mutation amin'ny toerana misy anao, ary tsy misy afa-tsy `Arc` fa: ianao tsy afaka hahazo mutable ankapobeny momba ny zavatra ao anatiny ny `Arc`.Raha mila mutate amin'ny alàlan'ny `Arc` ianao dia ampiasao ny [`Mutex`][mutex], [`RwLock`][rwlock], na ny iray amin'ireo karazana [`Atomic`][atomic].
///
/// ## Fiarovana amin'ny kofehy
///
/// Tsy toy ny [`Rc<T>`], `Arc<T>` dia mampiasa atomika asa noho ny ny boky Ny fisiana ara-.Midika izany fa azo antoka kofehy-.Ny fatiantoka dia ny fiasan'ny atomika lafo noho ny fidirana fahatsiarovana tsotra.Raha tsy mizara ny reference-isaina vola omena eo amin'ny kofehy, diniho mampiasa [`Rc<T>`] ho ambony ambany.
/// [`Rc<T>`] dia azo antoka toerana misy anao, fa ny compiler dia hisambotra misy fikasana handefa ny [`Rc<T>`] eo amin'ny kofehy.
/// Na izany aza, ny trano famakiam-boky dia mety misafidy `Arc<T>` mba hanomezana fahafaha-misafidy bebe kokoa ny mpanjifa fitahirizam-boky.
///
/// `Arc<T>` hampihatra [`Send`] sy [`Sync`] raha toa ka mampihatra [`Send`] sy [`Sync`] ny `T`.
/// Nahoana no tsy afaka ianao tsy nasiany kofehy-azo antoka karazana `T` amin'ny `Arc<T>` mba ataovy kofehy-azo antoka?Mety ho somary mifanohitra amin'ny intuitive izany amin'ny voalohany: raha ny marina, tsy azo antoka ve ny teboka fiarovana `Arc<T>`?Ny lakileny dia ity: `Arc<T>` dia mahatonga azy ho azo antoka ny fananana tompony maro amin'ny angon-drakitra mitovy, saingy tsy manampy ny fiarovana ny kofehy amin'ny angon-drakitra ao aminy.
///
/// Diniho ny `Arc <` ['RefCell<T>`]`> `.
/// [`RefCell<T>`] tsy [`Sync`], ary raha X0 `Arc<T>` dia [`Send`] foana, `Arc <` ['RefCell<T>`]>: Ho koa.
/// Nefa manana olana izahay avy eo:
/// [`RefCell<T>`] tsy azo antoka ve ny kofehy;mitazona ny fanisana indram-bola amin'ny alàlan'ny hetsika tsy ataoma.
///
/// Amin'ny farany, midika izany fa mety mila mampifanaraka ny `Arc<T>` amin'ny karazana [`std::sync`] ianao, mazàna [`Mutex<T>`][mutex].
///
/// ## Kitapo tapaka miaraka amin'ny `Weak`
///
/// Ny [`downgrade`][downgrade] fomba azo ampiasaina mba hamoronana ny tsy fividianana [`Weak`] manondro.Ny tondro [`Weak`] dia mety [«fanavaozana`][fanavaozana] d mankany `Arc`, saingy hiverina [`None`] io raha efa nilatsaka ny sanda voatahiry ao amin'ny fizarana.
/// Raha lazaina amin'ny teny hafa, ny tondro `Weak` dia tsy mitazona ny lanja ao anaty ny fizarana velona;na izany aza, izy ireo dia *mitazona* ny fizarana (magazay miantoka ny sandany) ho velona.
///
/// Ny tsingerina eo anelanelan'ny tondro `Arc` dia tsy hifindra toerana mihitsy.
/// Noho io antony io, [`Weak`] dia ampiasaina hanapotehana ny tsingerina.Ohatra, ny hazo dia mety manana tondro `Arc` matanjaka hatrany amin'ny vodin'ny ray aman-dreny ka hatrany amin'ny zanaka, ary ny tondro [`Weak`] avy amin'ny zanaka miverina amin'ny ray aman-dreniny.
///
/// # Fanondroana klona
///
/// Ny famoronana referansa vaovao avy amin'ny tondro misy isa voaisa dia ampiasaina amin'ny alàlan'ny `Clone` trait napetraka ho an'ny [`Arc<T>`][Arc] sy [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ny syntaxes roa etsy ambany dia mitovy.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, ary foo dia Arcs rehetra izay manondro ny toerana fitadidiana mitovy
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` mandeha ho azy dereferansa ny `T` (amin'ny alàlan'ny [`Deref`][deref] trait), amin'izay ianao afaka miantso ny fomba `T` amin'ny sanda `Arc<T>`.Mba hisorohana ny fifandonana amin'ny anarany: T` ny fomba, ny fomba `Arc<T>` mihitsy no mifandray asa, antsoina hoe mampiasa [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Ny fampiharana ny traits toy ny `Clone` dia azo antsoina koa amin'ny fampiasana syntax feno fahaizana.
/// Ny olona sasany dia aleony mampiasa syntax feno fahaizana, fa ny sasany kosa aleony mampiasa sintona antso-fomba.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntax fiantsoana fomba
/// let arc2 = arc.clone();
/// // Syntax mahafeno fepetra feno
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] tsy manadino ny `T` ho azy, satria mety efa nilatsaka ny sanda anatiny.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Mizara angona tsy azo ovaina eo anelanelan'ny kofehy:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Mariho fa tsy ** ** mihazakazaka izany fitsapana eto.
// Ireo mpanorina windows dia tena faly tokoa raha misy kofehy mihoatra ny kofehy lehibe ary mivoaka miaraka amin'izay (zavatra tsy mety maty) ka hialantsika tanteraka izany amin'ny alàlan'ny tsy fihazakazahana ireo fitsapana ireo.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Mizara [`AtomicUsize`] azo ovaina:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Jereo ny [`rc` documentation][rc_examples] raha mila ohatra misimisy kokoa momba ny fanisam-bidy amin'ny ankapobeny.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` dia dikan-[`Arc`] izay mihazona ny tsy hividy momba ny nahavita fanomezana.
/// Ny fizarana dia alaina amin'ny alàlan'ny fiantsoana [`upgrade`] amin'ny tondro `Weak`, izay mamerina [`Option`]`<`[`Arc`] `<T>>`.
///
/// Satria ny fanondroana `Weak` dia tsy manisa ny fananana, tsy hanakana ny soatoavina voatahiry ao amin'ny fizarana tsy ho nilatsaka izany, ary `Weak` mihitsy no tsy manome antoka momba ny sanda mbola misy.
///
/// Araka izany dia mety hiverina [`None`] izy io rehefa [`fanavaozana`] d.
/// Mariho anefa fa `Weak` boky * * no misakana ny fanomezana mihitsy (ny fanohanana fivarotana) tsy ho deallocated.
///
/// Tondro `Weak` dia ilaina amin'ny fitazonana referansa vonjimaika amin'ny fizarana tantanan'ny [`Arc`] nefa tsy manakana ny sandany anatiny tsy hianjera.
/// Ampiasaina ihany koa izy io hisorohana ny fanondroana boribory eo anelanelan'ny tondro [`Arc`], satria ny fananana referansa mifampiankina dia tsy hamela ny [`Arc`] hilatsaka.
/// Ohatra, mety manana ny hazo mafy [`Arc`] sahaza avy amin'ny ray aman-dreny nodes ho an'ny ankizy, ary `Weak` sahaza avy amin'ny ankizy aoriana ny ray aman-dreniny.
///
/// Ny fomba mahazatra ahazoana pointer `Weak` dia ny fiantsoana [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // `NonNull` ity ahafahana manatsara ny haben'ity karazana ity amin'ny enum, saingy tsy voatery ho mpanondro marina izany.
    //
    // `Weak::new` apetraka amin'ny `usize::MAX` ity ka tsy mila manokana toerana amin'ny antontam-bato.
    // Tsy salan'isa izany ny tondro iray tena izy satria RcBox dia manana fampifanarahana farafaharatsiny 2.
    // Tsy misy izany raha tsy rehefa `T: Sized`;uns01 `T` tsy mihantona na oviana na oviana.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Izany no repr(C) ny future-porofo manohitra azo atao reordering-zavatra, izay mety hanelingelina raha tsy izany dia azo antoka [into|from]_raw() ny transmutable anaty karazana.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // ny lanjan'ny usize::MAX miasa ho toy ny Sentinel ho vetivety "locking" hanatsarana ny fahaizana sahaza malemy na manambany matanjaka;ampiasaina hialana amin'ny hazakazaka amin'ny `make_mut` sy `get_mut` ity.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Manangana `Arc<T>` vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Atombohy ny isa isa malemy ho 1 izay ny pointer malemy mitazona ny tondro mahery (kinda) rehetra, jereo std/rc.rs raha mila fanazavana fanampiny
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Manangana `Arc<T>` vaovao amin'ny alàlan'ny fanondroana malemy ho azy.
    /// Nikasa ny hanatsarana ny malemy momba alohan'ny asa ity dia miverina ao amin'ny `None` vokany sarobidy.
    /// Na izany aza, ny referansa malemy dia azo clone maimaimpoana ary tehirizina hampiasaina amin'ny fotoana manaraka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Amboary ny atitany ao amin'ny fanjakana "uninitialized" miaraka amina referansa malemy tokana.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Zava-dehibe tsy kivy ny malemy tompon'ny manondro, fa raha tsy ny fahatsiarovana mba ho afaka ny andro `data_fn` miverina.
        // Raha tena te handany ny tompony isika dia afaka mamorona tondro malemy fanampiny ho an'ny tenantsika, saingy izany dia hiteraka fanavaozana fanampiny ho an'ny isa malemy izay mety tsy ilaina raha tsy izany.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ankehitriny isika dia afaka manomboka am-pahamendrehana ny soatoavina anatiny ary mamadika ny fanovozanay malemy ho loharano mahery.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ny manoratra etsy ambony ho an'ny sahan-tahirin-kevitra dia tsy maintsy ho hitan'ny kofehy izay mandinika fanisana mahery tsy aotra.
            // Noho izany mila farafahakeliny fividianana "Release" izahay mba ahafahana mifandrindra amin'ny `compare_exchange_weak` amin'ny `Weak::upgrade`.
            //
            // "Acquire" Ordering tsy ilaina.
            // Rehefa mandinika ny mety ho fitondran-tenan'ny `data_fn` isika dia mila mijery izay azony atao amin'ny alàlan'ny firesahana amin'ny `Weak` tsy azo havaozina:
            //
            // - Mety *Clone* ny `Weak`, mitombo ny osa momba fanisam.
            // - Afaka mandatsaka ireo clone ireo izy, mampihena ny isa malemy (fa tsy aotra mihitsy).
            //
            // Ireo vokatra hafa ireo dia tsy misy fiantraikany amintsika amin'ny lafiny rehetra, ary tsy misy voka-dratsy hafa azo atao amin'ny kaodim-piarovana irery ihany.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Ny fanovozan-kevitra mafonja dia tokony hanana tondro malemy iraisana iraisana, koa aza mihazakazaka ny mpanimba ho an'ny referansa malemy taloha.
        //
        mem::forget(weak);
        strong
    }

    /// Manangana `Arc` vaovao misy atiny tsy voamarina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Manangana `Arc` vaovao misy atiny tsy voalamina, miaraka amin'ny fahatsiarovan-tena feno `0` bytes.
    ///
    ///
    /// Jereo [`MaybeUninit::zeroed`][zeroed] raha ohatra amin'ny fampiasana marina sy tsy marina an'io fomba io.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Manangana `Pin<Arc<T>>` vaovao.
    /// Raha tsy mampihatra `Unpin` i `T`, dia hoentina ao anaty fahatsiarovana i `data` ary tsy azo afindra.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Constructs `Arc<T>` vaovao, niverina ny fahadisoana raha fanomezana ho levona mandrakizay.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Atombohy ny isa isa malemy ho 1 izay ny pointer malemy mitazona ny tondro mahery (kinda) rehetra, jereo std/rc.rs raha mila fanazavana fanampiny
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Manangana `Arc` vaovao misy atiny tsy voalamina, mamerina lesoka raha toa ka tsy mahomby ny fizarana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Manangana `Arc` vaovao misy atiny tsy voalamina, miaraka amin'ny fahatsiarovana feno `0` bytes, mamerina lesoka raha toa ka tsy mahomby ny fizarana.
    ///
    ///
    /// Jereo [`MaybeUninit::zeroed`][zeroed] raha ohatra amin'ny fampiasana marina sy tsy marina an'io fomba io.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Miverina ny sanda anatiny, raha ny `Arc` dia manana referansa mahery matanjaka iray.
    ///
    /// Raha tsy izany, [`Err`] averina miaraka amin'ny `Arc` mitovy izay nampitaina.
    ///
    ///
    /// Hahomby izany na dia misy fanondroana malemy miavaka aza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Manaova tondro malemy mba hanadio ny tondro malemy mahery
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Constructs vaovao boky atomically-isaina silaka amin'ny uninitialized anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Constructs vaovao boky atomically-isaina silaka amin'ny uninitialized anatiny, miaraka amin'ny fahatsiarovana ho feno `0` oktety.
    ///
    ///
    /// Jereo [`MaybeUninit::zeroed`][zeroed] raha ohatra amin'ny fampiasana marina sy tsy marina an'io fomba io.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Mivadika ho `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Toy ny [`MaybeUninit::assume_init`], dia niakatra ho any amin'ny mpiantso mba antoka fa tena sarobidy ny anaty ao amin'ny initialized fanjakana.
    ///
    /// Ny fiantsoana an'io rehefa tsy vita am-boalohany ny atiny dia miteraka fihetsika tsy voafaritra eo noho eo.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Mivadika ho `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Toy ny [`MaybeUninit::assume_init`], dia niakatra ho any amin'ny mpiantso mba antoka fa tena sarobidy ny anaty ao amin'ny initialized fanjakana.
    ///
    /// Ny fiantsoana an'io rehefa tsy vita am-boalohany ny atiny dia miteraka fihetsika tsy voafaritra eo noho eo.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Manjifa ny `Arc`, mamerina ny tondro voatonona.
    ///
    /// Mba hisorohana ny fahatsiarovana dia tsy maintsy mandefa ny manondro hiova fo miverina any amin'ny `Arc` mampiasa [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Manome tondro mazava ho an'ny data.
    ///
    /// Ny fanisana dia tsy misy fiantraikany amin'ny lafiny rehetra ary ny `Arc` tsy lany.
    /// Ny manondro manan-kery ho an'ny raha mbola misy mandritry ny fitsidihana matanjaka ao amin'ny `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // Famonjena, Mety tsy ho amin'ny alalan'ny Deref::deref na RcBoxPtr::inner satria
        // izany dia takiana mba hitazonana ny raw/mut porofo toy izany ohatra
        // `get_mut` afaka manoratra amin'ny alàlan'ny pointer aorian'ny Rc averina amin'ny alalàn'ny `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Constructs ny `Arc<T>` avy amin'ny manta manondro.
    ///
    /// Ny manta dia tsy maintsy manondro efa niverina teo aloha amin'ny alalan'ny antso ho [`Arc<U>::into_raw`][into_raw] `U` izay tsy maintsy manana ny mitovy habe sy ny fampifanarahana araka ny `T`.
    /// Marina izany fa tsy misy dikany raha `T` dia `T`.
    /// Mariho fa raha `U` dia tsy `T` fa manana ny habeny sy ny fampifanarahana azy dia toy ny fandefasana referansa amin'ny karazany isan-karazany io.
    /// Jereo [`mem::transmute`][transmute] raha mila fanazavana fanampiny momba ny fameperana mihatra amin'ity tranga ity.
    ///
    /// Ny mpampiasa `from_raw` dia tsy maintsy mahazo antoka fa ny lanjan'antoka `T` iray dia nilatsaka indray mandeha ihany.
    ///
    /// Tsy azo antoka ity fiasa ity satria ny fampiasana tsy mety dia mety hitarika tsy fahatokisan-tsaina, na dia tsy azo idirana mihitsy aza ilay `Arc<T>` tafaverina.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Miverena miverina amin'ny `Arc` hisorohana ny fivoahan'ny rano.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Koa antso ho `Arc::from_raw(x_ptr)` ho fahatsiarovana-azo antoka.
    /// }
    ///
    /// // Navoaka ny fahatsiarovana rehefa nivoaka ivelan'ny sehatra ambony i `x`, ka mihantona izao i `x_ptr`!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Hanova ireny offset mba hahitana ArcInner tany am-boalohany.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Mamorona tondro [`Weak`] vaovao amin'ity fizarana ity.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Izany tony dia maninona satria isika mijery ny sarobidy eo čas eto ambany.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // zahao raha "locked" ny kaontera malemy ankehitriny;Raha eny, kofehy ireny.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ity kaody ity dia tsy miraharaha ny mety hisian'ny fihoarana
            // ho any usize::MAX;amin'ny ankapobeny dia mila ahitsy ny Rc sy ny Arc mba hiatrehana ny safo-drano.
            //

            // Tsy toy ny Clone(), ilaintsika izy ity mba ho vakiana Acquire mba hifanaraka amin'ny soratra avy amin'ny `is_unique`, mba hitranga alohan'ity vakiteny ity ny hetsika alohan'ny anoratana.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Hamarino tsara fa tsy mamorona fahalemena mihantona isika
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Mahazo ny isan'ny tondro [`Weak`] amin'ity fizarana ity.
    ///
    /// # Safety
    ///
    /// Ity fomba ity irery dia azo antoka, fa ny fampiasana azy io kosa dia mila fitandremana fanampiny.
    /// Kofehy iray hafa afaka manova ny malemy fanisam na oviana na oviana, ao anatin'izany ny mety eo niantso izany fomba sy manao ny vokany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ity fanambarana ity dia azo faritana satria tsy nizara ny `Arc` na `Weak` teo anelanelan'ny kofehy izahay.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Raha mihidy izao ny isa malemy dia 0 ny isan'ny fanisana alohan'ny nakana ny hidiny.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Mahazo ny isan'ny tondro mahery (`Arc`) amin'ity fizarana ity.
    ///
    /// # Safety
    ///
    /// Ity fomba ity irery dia azo antoka, fa ny fampiasana azy io kosa dia mila fitandremana fanampiny.
    /// Ny kofehy iray hafa dia afaka manova ny isa mavesatra amin'ny fotoana rehetra, anisan'izany ny mety hiantsoana an'io fomba io sy ny fiasa amin'ny valiny.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ity fanambarana ity dia azo faritana satria tsy nizara ny `Arc` teo anelanelan'ny kofehy izahay.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Mitombo tsikelikely ny mahery matoky momba ny `Arc<T>` mifandray amin'ny ny nanome manondro iray.
    ///
    /// # Safety
    ///
    /// Ny pointer dia tokony ho azo tamin'ny alàlan'ny `Arc::into_raw`, ary ny ohatra `Arc` mifandraika dia tsy maintsy mitombina (ie
    /// fanisana ny mahery, fara fahakeliny, dia tsy maintsy 1) nandritra ny fisian'ny fomba fiasa io.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ity fanambarana ity dia azo faritana satria tsy nizara ny `Arc` teo anelanelan'ny kofehy izahay.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Hitana Arc, fa aza mikasika refcount ny wrapping in ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Ampitomboy ny refcount ankehitriny, fa aza mandatsaka refcount vaovao koa
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Decrements momba ny mahery matoky ny `Arc<T>` mifandray amin'ny ny nanome manondro iray.
    ///
    /// # Safety
    ///
    /// Ny pointer dia tokony ho azo tamin'ny alàlan'ny `Arc::into_raw`, ary ny ohatra `Arc` mifandraika dia tsy maintsy mitombina (ie
    /// fanisana ny mahery, fara fahakeliny, dia tsy maintsy 1), rehefa izany fomba fanononany ny fiandrianam-.
    /// Ity fomba ity dia azo ampiasaina hamoahana ny `Arc` farany sy ny fitehirizana fitehirizana, fa **tsy tokony** no antsoina aorian'ny famoahana ny `Arc` farany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ireo fanizingizinana ny deterministic noho ny tsy anananay nizara ny `Arc` eo amin'ny kofehy.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ity unsafety dia maninona satria raha mbola velona Arc ity isika dia antoka fa ny anaty manondro manan-kery.
        // Ankoatr'izay, fantatray fa ny rafitra `ArcInner` dia `Sync` satria ny data ao anatiny dia `Sync` ihany koa, noho izany dia tsara ny manondro tondro tsy azo ovaina amin'ireto atiny ireto.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Non-inlined anisan'ny `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ravao ny angon-drakitra amin'izao fotoana izao, na dia mety tsy manana fahafahana ny boaty fanomezana mihitsy (dia mety mbola ho malemy sahaza lainga manodidina).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Mitete ny malemy ref miaraka natao rehetra andinin-tsoratra masina mahery
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Miverina `true` raha toa ny roa `Arc`s manondro ny fizarana mitovy (amin'ny lalan-drà mitovy amin'ny [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Manokana `ArcInner<T>` misy toerana sahaza ho an'ny sanda anatiny anaty tsy voatanisa izay manome ny lamina omena ny sanda.
    ///
    /// Ny asa `mem_to_arcinner` Antsoina hoe miaraka amin'ny angon-drakitra ary tsy maintsy hiverina manondro Hiverina any amina (mety matavy)-pointer ho an'ny `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Manisa kaonty amin'ny alàlan'ny fisehon'ny sanda nomena.
        // Talohan'izay, ny layout dia nikajiana tamin'ny fitenenana `&*(ptr as* const ArcInner<T>)`, saingy izany dia namorona referansa diso (jereo #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Manokana `ArcInner<T>` misy toerana sahaza ho an'ny sanda anatiny mety tsy voadio izay manome ny lamina omena ny soatoavina, mamerina lesoka raha toa ka tsy nahomby ny fizarana.
    ///
    ///
    /// Ny asa `mem_to_arcinner` Antsoina hoe miaraka amin'ny angon-drakitra ary tsy maintsy hiverina manondro Hiverina any amina (mety matavy)-pointer ho an'ny `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Manisa kaonty amin'ny alàlan'ny fisehon'ny sanda nomena.
        // Talohan'izay, ny layout dia nikajiana tamin'ny fitenenana `&*(ptr as* const ArcInner<T>)`, saingy izany dia namorona referansa diso (jereo #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Atombohy ny ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Manokana `ArcInner<T>` misy toerana ampy ho an'ny sanda anatiny tsy voarindra.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Atokana ho an'ny `ArcInner<T>` ny fampiasana ny sanda nomena.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Adikao ny sandan'ny bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Afaho ny fizarana raha tsy mandatsaka ny atiny
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Manokana `ArcInner<[T]>` miaraka amin'ny halavany.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Adikao ireo singa avy ao amin'ny silaka ao anaty Arc <\[T\]> vao natokana
    ///
    /// Mampidi-doza, satria ny mpiantso na dia tsy maintsy maka tompony na fehezinao `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Manangana `Arc<[T]>` amin'ny iterator fantatra amin'ny habe iray.
    ///
    /// Tsy voafaritra ny fitondran-tena raha diso ny habeny.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic mpiambina raha mandahatra ny singa T.
        // Raha toa ny panic, zavatra izay efa voasoratra any an-vaovao dia nandatsaka ArcInner, dia nanafaka ny fahatsiarovana.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Manondro ny singa voalohany
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Mazava daholo.Adinoy ny mpiambina sao mamotsotra ny ArcInner vaovao.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait `From<&[T]>` nampiasaina.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Manao clone ny tondro `Arc`.
    ///
    /// Izany dia miteraka tondro iray hafa amin'ny fizarana mitovy amin'izany, mampitombo ny isa mavesatra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Mampiasa ny aina antokony dia maninona eto, toy ny fahalalana ny boky am-boalohany manakana ny hafa famafana kofehy avy Diso hevitra ilay vehivavy ilay zavatra.
        //
        // Araka ny nohazavaina tao amin'ny [Boost documentation][1], ny fampitomboana ny kaonteran-tsoratra dia azo atao foana miaraka amin'ny memory_order_relaxed: Ny referansa vaovao amin'ny zavatra iray dia azo amboarina avy amin'ny referansa efa misy, ary ny fandefasana referansa efa misy avy amin'ny kofehy iray mankany amin'ny iray hafa dia efa tokony hanome izay fitakiana ilaina.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Na izany aza dia mila mitandrina faobe refcounts raha olona iray dia: MEM::forget`ing Arcs.
        // Raha tsy manao izany ny fanisam hindaosin'ny sy mpampiasa dia afaka hampiasa-aorian'ny maimaim-poana.
        // Izahay dia mifantoka amin'ny `isize::MAX` amin'ny fiheverana fa tsy misy kofehy ~2 miliara mampiakatra ny isa isaina indray mandeha.
        //
        // Izany branch tsy ho naka na inona na inona zava-misy fandaharana.
        //
        // Nofoanana izahay satria miharatsy tanteraka ny programa toy izany ary tsy miraharaha ny hanohana azy izahay.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Mahatonga referable miovaova amin'ny `Arc` nomena.
    ///
    /// Raha misy tondro hafa `Arc` na [`Weak`] amin'ny fizarana mitovy amin'izany, dia hamorona fizarana vaovao i `make_mut` ary hiantso ny [`clone`][clone] amin'ny sanda anatiny mba hiantohana ny fananana tokana.
    /// Ity dia antsoina koa hoe clone-on-write.
    ///
    /// Mariho fa tsy mitovy amin'ny fitondran-tenan'ny [`Rc::make_mut`] izay misaraka amin'ny tondro `Weak` sisa.
    ///
    /// Jereo ihany koa ny [`get_mut`][get_mut], izay tsy hahomby fa tsy hanjifa.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Tsy hanaiky na inona na inona
    /// let mut other_data = Arc::clone(&data); // Tsy hanafoana ny angona anatiny
    /// *Arc::make_mut(&mut data) += 1;         // Data angona anatiny
    /// *Arc::make_mut(&mut data) += 1;         // Tsy hanaiky na inona na inona
    /// *Arc::make_mut(&mut other_data) *= 2;   // Tsy hanaiky na inona na inona
    ///
    /// // Ankehitriny `data` sy `other_data` dia manondro fizarana samihafa.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Mariho fa samy mitazona fanovozan-kevitra matanjaka sy referansa malemy isika.
        // Noho izany, namoaka ny boky matanjaka ihany no tsy, ho azy, hahatonga ny fahatsiarovana ho deallocated.
        //
        // Ampiasao Acquire hahazoana antoka fa mahita soratana amin'ny `weak` izay nitranga talohan'ny famoahana izahay (izany hoe decrement) mankany `strong`.
        // Satria mitazona isa malemy isika dia tsy misy kisendrasendra ny ArcInner mihitsy no mety hifindra toerana.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Misy tondro mahery iray koa misy, noho izany dia tsy maintsy manao klone isika.
            // Mizara mialoha ny fahatsiarovana hahafahanao manoratra mivantana ny soatoavina klona.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ampy izay ny fialan-tsasatra etsy ambony satria fanatsarana izany amin'ny ankapobeny: mihazakazaka foana isika miaraka amin'ireo tondro malemy naidina.
            // Tranga ratsy indrindra, farany nanokana Arc vaovao tsy ilaina isika.
            //

            // Nesorinay ny ref mahery farany, fa misy ref kosa malemy fanampiny.
            // Ho isika hanosika ny votoatin'ny vaovao ho Arc, ary hanafoana ny hafa refs malemy.
            //

            // Mariho fa tsy azo atao ny mamaky `weak` hamoaka usize::MAX (izany hoe mihidy), satria ny isa malemy dia azo fehezina amin'ny kofehy iray misy referansa mahery.
            //
            //

            // Vatan'olombelona ny malemy tanteraka ny manondro, ka dia afaka manadio ny ArcInner raha ilaina.
            //
            let _weak = Weak { ptr: this.ptr };

            // Afaka mangalatra angona fotsiny, ny sisa dia Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Izahay ihany no hany firesahana na inona na inona karazany;mametaka ny isa ref mahery.
            //
            this.inner().strong.store(1, Release);
        }

        // Tahaka ny `get_mut()`, tsy milamina ny tsy fandriam-pahalemana satria tsy mitovy ny nanombohantsika ny fanovozan-kevitra na nanjary iray tamin'ny fametahana ny atiny.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Miverina ny referable miovaova amin'ny `Arc` nomena, raha tsy misy tondro hafa `Arc` na [`Weak`] amin'ny fizarana mitovy.
    ///
    ///
    /// Miverina amin'ny [`None`] raha tsy izany, satria tsy azo antoka ny mampiova ny sanda ifampizarana.
    ///
    /// Jereo ihany koa ny [`make_mut`][make_mut], izay [`clone`][clone] ny sanda anatiny raha misy tondro hafa.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ity tsy fandriam-pahalemana ity dia ok satria manome toky izahay fa ny pointer niverina no *hany* pointer izay haverina amin'ny T.
            // Ny isa fanovozan-kevitray dia azo antoka fa ho 1 amin'izao fotoana izao, ary nitaky ny Arc ny tenany ho `mut`, noho izany averinay ny hany azo ilazana ireo angona anatiny.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Miverina ny mutable boky ho any amin'ny nomena `Arc`, tsy misy maso.
    ///
    /// Jereo ihany koa ny [`get_mut`], izay azo antoka ary manao fanamarinana mety.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ny tondro hafa `Arc` na [`Weak`] hafa mitovy amin'ny fizarana dia tsy tokony holavina mandritra ny faharetan'ny indram-bola nody.
    ///
    /// Izany no trivially ny raharaha tsy misy toy izany raha sahaza misy, ohatra avy hatrany taorian'ny `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mitandrina isika mba *tsy* mamorona boky "count" mandrakotra ny saha, tahaka Izany dia antsoina amin'ny concurrent fahafahana hahazo ny boky fanisana (oh
        // nataon'i `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Fantaro raha ity no referansa tokana (ao anatin'izany ny ref malemy) amin'ireo angona ifotony.
    ///
    ///
    /// Mariho fa izany dia mitaky fanidiana ny isa malemy ref.
    fn is_unique(&mut self) -> bool {
        // hanidy ny malemy manondro fanisam raha toa tsy manondro ny tokana mpihazona malemy.
        //
        // Ny mari-pamantarana azo eto dia miantoka fifandraisana misy eo alohan'ny zava-mitranga amin'ny `strong` (indrindra amin'ny `Weak::upgrade`) alohan'ny fihenan'ny isa `weak` (amin'ny alàlan'ny `Weak::drop`, izay mampiasa famotsorana).
        // Raha ny upgraded malemy ref tsy mbola nandatsaka, ny čas eto dia tsy toy izany dia tsy miraharaha ny synchronize.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ity dia mila `Acquire` hifanindriana amin'ny fihenan'ny counter `strong` amin'ny `drop`-ny hany fidirana hitranga rehefa misy izany fa ny referansa farany kosa dia nilatsaka.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Soraty eto ny fanafahana synchronizes amin'ny Lire dans `downgrade`, mahomby manakana ny ambony hamaky ny `strong` tsy hitranga aorian'ny soraty.
            //
            //
            self.inner().weak.store(1, Release); // avoahy ny hidim-baravarana
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Mitete ny `Arc`.
    ///
    /// Io dia hampihena ny isa mavesatra.
    /// Raha toa ka mahatratra aotra ny isa fanovozan-kevitra mahery dia ny [`Weak`] ihany no referansa hafa (raha misy), ka `drop` no sanda anatiny.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Tsy manonta na inona na inona
    /// drop(foo2);   // Pirinty "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Satria efa atomika ny `fetch_sub` dia tsy mila mifanindry amin'ny kofehy hafa isika raha tsy mamafa ny zavatra.
        // Io lojika io ihany dia mihatra amin'ny ambany `fetch_sub` amin'ny isa `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Io fefy no ilaina mba tsy reordering ny fampiasana ny angon-drakitra sy ny famafana ny tahirin-kevitra.
        // Satria ny marika `Release`, ny mihena ny boky fanisam synchronizes izany `Acquire` fefy.
        // Midika izany fa ny fampiasana ny angon-drakitra dia mitranga alohan'ny hampihenana ny isa fanisana, izay mitranga alohan'ity fefy ity, izay mitranga alohan'ny famafana ireo data.
        //
        // Araka ny nohazavaina tao amin'ny [Boost documentation][1],
        //
        // > Zava-dehibe ny fampiharana ny mety hidirana amin'ilay zavatra amin'ny iray
        // > kofehy (amin'ny alàlan'ny referansa efa misy) hitranga * alohan'ny famafana
        // > ny zavatra hafa ao amin'ny kofehy.Izany no tratra iray "release"
        // > fandidiana aorian'ny fandatsahana referansa (misy fidirana amin'ilay zavatra
        // > amin'ny alàlan'ity fanovozan-kevitra ity dia tsy maintsy mazava fa nitranga talohan'izay), ary an
        // > "acquire" fandidiana alohan'ny hamafana ilay zavatra.
        //
        // Manokana indrindra, na dia tsy azo ovaina matetika aza ny atin'ny Arc dia azo atao ny manoratra ao anaty zavatra toa ny Mutex<T>.
        // Satria tsy azo ny Mutex iray rehefa voafafa izany, tsy azonay atao ny miantehitra amin'ny lojika fampitambarana nataony mba hanoratana ao anaty kofehy A hitan'ny mpanimba iray mihodina ao amin'ny kofehy B.
        //
        //
        // Ary mariho fa ny Mahazoa fefy eto angamba mety ho soloina miaraka amin'ny Miezaha hanana entana, izay mety hanatsarana ny fampisehoana in-nifandahatra tena toe-javatra.Jereo [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Miezaka downcast ny `Arc<dyn Any + Send + Sync>` ny karazana simenitra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Manangana `Weak<T>` vaovao, nefa tsy mizara fahatsiarovana.
    /// Ny fiantsoana [`upgrade`] amin'ny sanda fiverenana dia manome [`None`] foana.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Karazana mpanampy hamelana ny fidirana amin'ny fanisana raha tsy misy fanamafisana momba ny sehatry ny angona.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Mamerina ny tondro masaka amin'ilay zavatra `T` notondroin'ity `Weak<T>` ity.
    ///
    /// Ny mpanondro dia manan-kery raha tsy misy referansa matanjaka.
    /// Ny tondro dia mety manantona, tsy mifanaraka ary [`null`] mihitsy aza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Samy manondro zavatra iray izy roa
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ny mahery eto dia mamelona azy, ka mbola afaka miditra amin'ilay zavatra ihany isika.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Fa tsy izany intsony.
    /// // Afaka manao weak.as_ptr() isika, fa ny fidirana amin'ny tondro dia hitarika amin'ny fitondrantena tsy voafaritra.
    /// // assert_eq! ("hello", tsy azo antoka {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Raha manantona ilay mpanondro dia averintsika mivantana ilay mpitily.
            // Tsy mety adiresy fandefasana karama io, satria ny karama dia farafaharatsiny mifanaraka amin'ny ArcInner (usize).
            ptr as *const T
        } else {
            // SAFETY: raha i_dangling miverina diso, dia azo esorina ny tondro.
            // Ny mety ho latsaka payload Tamin'io fotoana io, ka tsy maintsy foana provenance, ka mampiasa manta manondro fanodinkodinana.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Manjifa ny `Weak<T>` ary mamadika azy ho mpanondro manta.
    ///
    /// Izany niova fo manondro ny malemy ho manondro manta, raha mbola mitahiry ny tompon'ny iray malemy ny boky (ny malemy dia tsy fanisam farany ity hetsika).
    /// Izy io dia azo averina averina ho `Weak<T>` miaraka [`from_raw`].
    ///
    /// Ireo fameperana mitovy amin'ny fidirana amin'ny kendrena ny tondro ary amin'ny [`as_ptr`] dia mihatra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Mamadika pointer manta noforonin'i [`into_raw`] niverina ho `Weak<T>`.
    ///
    /// Izy io dia azo ampiasaina hahazoana loharanom-pahalalana matanjaka (amin'ny fiantsoana [`upgrade`] any aoriana) na hametrahana ny isa malemy amin'ny famoahana ny `Weak<T>`.
    ///
    /// Mitaky ny fananana tondro malemy iray (ankoatry ny tondro noforonin'i [`new`], satria tsy manana na inona na inona izy ireo; ny fomba dia mbola mandaitra amin'izy ireo).
    ///
    /// # Safety
    ///
    /// Ny tondro dia tokony ho avy amin'ny [`into_raw`] ary tsy maintsy manana ny mety ho malemy referansa.
    ///
    /// Avela ho 0 ny isa mavesatra amin'ny fotoana iantsoana an'ity.
    /// Na izany aza, ity dia mitaky ny fananana tondro malemy iray izay soloina ankehitriny ho toy ny mpanondro manta (ny fanisana malemy dia tsy ovaina amin'ity asa ity) ary noho izany dia tsy maintsy ampiarahina amin'ny antso taloha ho [`into_raw`] izy io.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Mampihena ny isa malemy farany.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Jereo Weak::as_ptr ny teny manodidina amin'ny fomba manondro ny fahan'ny teny.

        let ptr = if is_dangling(ptr as *mut T) {
            // Malemy mihantona ity.
            ptr as *mut ArcInner<T>
        } else {
            // Raha tsy izany dia mahazo antoka isika fa avy amin'ny Malemy tsy mitongilana ny tondro.
            // SAFETY: azo antoka iantsoana ny data_offset, satria ptr manondro ny tena (mety nilatsaka) T.
            let offset = unsafe { data_offset(ptr) };
            // Noho izany, averintsika ny offset mba hahazoana ny RcBox iray manontolo.
            // Famonjena, manondro Avy amin'ny malemy, ka izany offset voavonjy.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: efa azontsika izao ny pointer Weak tany am-boalohany, ka afaka mamorona ny Malemy.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Ezaka mba hanatsarana ny `Weak` manondro any amin'ny iray [`Arc`], fanemorana ny rano mitete ny anatiny sarobidy, raha mahomby.
    ///
    ///
    /// Miverina [`None`] raha nilatsaka ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Aringano ireo tondro mahery rehetra.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Mampiasa loop CAS izahay mba hampiakarana ny isa mavesatra fa tsy fetch_add satria io asa io dia tsy tokony hitondra ny isa isa hatramin'ny zero hatramin'ny iray.
        //
        //
        let inner = self.inner()?;

        // Enta-mavesatra miala sasatra satria izay soratan'ny 0 izay azontsika jerena dia mamela ny saha amin'ny fanjakana aotra maharitra (noho izany ny famakiana "stale" an'ny 0 dia tsara), ary ny sanda hafa dia voamarina amin'ny alàlan'ny CAS etsy ambany.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Jereo ny fanehoan-kevitra ao amin'ny `Arc::clone` fa nahoana isika no manao izany (fa `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Milamina tsara amin'ny raharaha tsy fahombiazana satria tsy manana fanantenana momba ny fanjakana vaovao isika.
            // Ilaina ny fahazoana raha te hitovy amin'ny `Arc::new_cyclic` ny tranga fahombiazana, rehefa azo atomboka ny valeur anatiny aorian'ny famoronana referansa `Weak`.
            // Raha izany, dia manantena ny mandinika ny zava-dehibe initialized tanteraka.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null nojerena etsy ambony
                Err(old) => n = old,
            }
        }
    }

    /// Mahazo ny isan'ny tondro mahery (`Arc`) manondro io fizarana io.
    ///
    /// Raha noforonina [`Weak::new`] `self` dia hiverina 0 ity.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Mahazo fanakaikezana ny isan'ny tondro `Weak` manondro io fizarana io.
    ///
    /// Raha `self` noforonina mampiasa [`Weak::new`], na raha tsy misy fijanonana ho mafy orina sahaza, izao hiverina 0.
    ///
    /// # Accuracy
    ///
    /// Noho ny pitsopitsony momba ny fampiharana, ny sanda miverina dia mety ho 1 amin'ny làlan-kaleha raha misy kofehy hafa manodinkodina izay `Arc`s na`Weak`s manondro ny fizarana mitovy.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Koa satria nahita fa nisy iray, fara fahakeliny matanjaka manondro rehefa avy namaky ny malemy fanisana, fantatsika fa ny tanteraka malemy boky (ankehitriny isaky ny misy mafy andinin-tsoratra masina mbola velona) dia mbola manodidina rehefa nahita ny malemy fanisana, ka afaka noho izany soa aman-tsara analana izany.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Miverina `None` rehefa mihantona ilay mpanondro ary tsy misy `ArcInner` natokana, (izany hoe rehefa `Weak` no noforonin'i `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mitandrina izahay mba *tsy* hamorona referansa manarona ny saha "data", satria mety hiovaova ny fifanarahana (ohatra, raha latsaka ny `Arc` farany, dia hajanona eo amin'ny toerany ny saha data).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Miverina `true` raha manondro fizarana mitovy (mitovy amin'ny [`ptr::eq`]) ireo roa `Malemy ', na raha samy tsy manondro fizarana (satria noforonina tamin'ny `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Koa satria mampitaha tondro izany dia midika fa ny `Weak::new()` dia hitovy, na dia tsy manondro fizarana aza izy ireo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Mampitaha `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Manao clone ny tondro `Weak` izay manondro ny fizarana mitovy.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Jereo ny hevitra ao amin'ny Arc::clone() fa maninona ity no milamina.
        // Ity dia afaka mampiasa fetch_add (tsy miraharaha ny hidin-trano) satria ny isa malemy dia mihidy fotsiny izay tsy misy * fanondroana malemy hafa misy.
        //
        // (Ka tsy afaka mihazakazaka an'ity kaody ity isika raha izany).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Jereo ny fanehoan-kevitra ao amin'ny Arc::clone() fa nahoana isika no manao izany (fa mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Manangana `Weak<T>` vaovao, tsy mizara memori.
    /// Ny fiantsoana [`upgrade`] amin'ny sanda fiverenana dia manome [`None`] foana.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Mitete ny tondro `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tsy manonta na inona na inona
    /// drop(foo);        // Pirinty "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Raha mahita fa izahay malemy manondro ny farany, dia ny fotoana deallocate ny angon-drakitra mihitsy.Jereo ny fifanakalozan-kevitra ao amin'ny Arc::drop() momba ny filaharam-memo
        //
        // Tsy ilaina ny mijery ny mihidy fanjakana eto, satria ny malemy fanisam ihany ho mihidy, raha nisy marina iray malemy ref, izay midika fa ny rano indray mitete afaka ihany tatỳ aoriana mihazakazaka ON fa ny fijanonana ho malemy ref, izay ihany no hitranga araka ny hidin-trano Navoaka.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Izahay dia manao an'ity spécialisation ity eto, fa tsy amin'ny fanatsarana ankapobeny kokoa amin'ny `&T`, satria raha tsy izany dia hanampy vola amin'ny fanamarinana fitoviana rehetra amin'ny ref.
/// Heverinay fa ny `Arc`s dia ampiasaina hitehirizana soatoavina lehibe, miadana ny fandefasana azy, fa mavesatra ihany koa hijerena ny fitoviana, ka handoa mora kokoa io vidiny io.
///
/// Izany ihany koa ny mety hanana clones `Arc` roa, izay manondro ny vidiny ihany, noho ny roa: &T`s.
///
/// Azontsika atao ihany izany rehefa `T: Eq` amin'ny maha `PartialEq` dia mety fanahy iniana tsy milay.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Fitoviana amin'ny `Arc` roa.
    ///
    /// Ny `Arc` roa dia mitovy raha mitovy ny sanda anatiny, na dia voatahiry amina fizarana samihafa aza.
    ///
    /// Raha `T` koa dia mampihatra `Eq` (milaza reflexivity ny fitoviana), ny `Arc` roa izay manondro ny fizarana mitovy dia mitovy foana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ny tsy fitoviana roa `Arc`s.
    ///
    /// Ny `Arc 'roa dia tsy mitovy raha tsy mitovy ny sanda anatiny.
    ///
    /// Raha `T` ihany koa ny manatanteraka `Eq` (midika reflexivity ny fitoviana), roa: Arc`s fa manondro ny vidiny ihany no tsy mitovy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Fampitahana ampahany amin'ny `Arc` roa.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `partial_cmp()` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Fampitahana kely noho ny an'ny `Arc` roa.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `<` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Latsaky ny na mitovy amin'ny' fampitahana ny roa Arc.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `<=` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Fampitahana lehibe kokoa noho ny `Arc` roa.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `>` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Lehibe noho na mitovy ny' fampitahana roa `Arc`s.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `>=` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Fampitahana roa `Arc`s.
    ///
    /// Roa ireo raha oharina amin'ny fiantsoana `cmp()` eo amin'ny soatoavina anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Mamorona `Arc<T>` vaovao, miaraka amin'ny sanda `Default` ho an'ny `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Manokà sombin-isa voatanisa ary fenoy amin'ny alàlan'ny fananganana clon `v` ny entana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Atokà `str` isaina ho referansa ary adikao `v` ao.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Atokà `str` isaina ho referansa ary adikao `v` ao.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Mifindra ny boxed zavatra ho vaovao, fanomezana reference-isaina.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Manokà sombin-isa voatanisa ary afindra ao aminy ny entana 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Avelao ny Vec hanafaka ny fitadidiany, fa aza manimba ny ao anatiny
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Raiso ny singa tsirairay ao amin'ny `Iterator` ary angonina ao anaty `Arc<[T]>`.
    ///
    /// # Toetra mampiavaka
    ///
    /// ## Ny tranga ankapobeny
    ///
    /// Amin'ny tranga ankapobeny, ny fanangonana amin'ny `Arc<[T]>` dia atao amin'ny alàlan'ny fanangonana voalohany mankany `Vec<T>`.Izany hoe, rehefa nanoratra izao manaraka izao:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// mitondra tena ho toy izany raha nanoratra hoe:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ny voalohany napetraka ny vola omena mitranga eto.
    ///     .into(); // Fizarana faharoa ho an'ny `Arc<[T]>` no mitranga eto.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ity dia hanokana im-betsaka araka izay ilaina amin'ny fananganana ny `Vec<T>` ary avy eo dia hanokana indray mandeha hanodinana ny `Vec<T>` ho `Arc<[T]>`.
    ///
    ///
    /// ## Iterator amin'ny halavany fantatra
    ///
    /// Rehefa manatanteraka ny `Iterator` `TrustedLen` ary iray tena habeny, iray fanomezana ho natao ho ny `Arc<[T]>`.Ohatra:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Fizarana tokana ihany no mitranga eto.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialization trait ampiasaina amin'ny manangona ho any `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ity no tranga misy iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Mila mahazo antoka isika fa manana ny halavany marina ilay iterator ary manana isika.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Miverina amin'ny fampiharana mahazatra.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Alao ny offset ao anatin'ny `ArcInner` ho an'ny karama aorian'ny mpanondro.
///
/// # Safety
///
/// Ny tondro dia tsy maintsy manondro (ary manana metadata manan-kery ho an'ny) ohatra T izay manan-kery teo aloha, fa ny T kosa avela hilatsaka.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Hampifanaraka ny unsized sarobidy hatramin'ny farany ny ArcInner.
    // Satria ny RcBox dia repr(C), dia io no farany ho fahatsiarovana farany.
    // SAFETY: satria ny karazany tsy voafaritra ihany no azo atao dia ny silaka, zavatra trait,
    // ary ny karazany ivelany, ny fepetra takiana amin'ny fiarovana izao dia ampy hanomezana fahafaham-po ny fepetra takian'ny align_of_val_raw;izany dia fampiharana antsipirihany ny fiteny izay tsy ho niankina eo ivelan'ny std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}