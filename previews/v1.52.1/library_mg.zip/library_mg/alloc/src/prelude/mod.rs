//! Ny fizarana Prelude
//!
//! Ny tanjon'ity modely ity dia ny hanamaivanana ny fanafarana entana efa zatra `alloc` crate amin'ny alàlan'ny fampidirana impor glob eo an-tampon'ny modules:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;