use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Manoratra ny fitsapana ny eo anivon'ny antoko fahatelo-allocators sy `RawVec` ny kely, satria mamitaka ny `RawVec` API tsy asehony fomba fanomezana hadisoana, noho izany dia tsy afaka manamarina ny zavatra mitranga rehefa allocator dia reraka (mihoatra vao hita ny panic).
    //
    //
    // Fa kosa, ity dia manamarina fotsiny fa ny fomba `RawVec` dia mandalo farafaharatsiny amin'ny Allocator API rehefa mitahiry tahiry.
    //
    //
    //
    //
    //

    // Mpizara iray moana izay mandany solika voafaritra alohan'ny hanombohana ny tsy fahombiazan'ny fanandramana.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (miteraka realloc, ka mampiasa solika 50 + 150=200)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Voalohany, `reserve` dia mizara toa `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 dia mihoatra ny avo roa heny amin'ny 7, noho izany `reserve` dia tokony hiasa toa `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // Ny 3 dia latsaky ny antsasaky ny 12, ka `reserve` dia tsy maintsy mitombo.
        // Tamin'ny fotoana nanoratana ity test ity dia 2, ka ny fahaiza-manao vaovao dia 24, na izany aza, ny fambolena 1.5 dia OK ihany koa.
        //
        // Noho izany `>= 18` amin'ny fanamafisana.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}