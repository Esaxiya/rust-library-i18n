//! # Ny tranomboky Rust fototra sy famakiam-boky fanangonana
//!
//! Ity trano famakiam-boky dia manome sahaza marani-tsaina sy ny fanangonana antontan-javatra noho ny fitantanana-omena soatoavina.
//!
//! Ity tranomboky ity, toy ny libcore, matetika dia tsy mila ampiasaina mivantana satria aondrana any ivelany indray ny atiny ao amin'ny [`std` crate](../std/index.html).
//! Crates izay mampiasa ny toetra `#![no_std]` na izany aza dia tsy hiankina amin'ny `std`, noho izany dia hampiasa an'io crate io izy ireo.
//!
//! ## Sanda mitambatra
//!
//! Ny karazany [`Box`] dia karazana tondro marani-tsaina.Tsy misy afa-tsy tompona [`Box`] iray, ary ny tompony dia afaka manapa-kevitra ny hanova ny atiny, izay mipetraka eo ambonin'ny antontam-bato.
//!
//! Ity karazana ity dia azo alefa amin'ireo kofehy amin'ny fomba mahomby satria ny haben'ny sanda `Box` dia mitovy amin'ny an'ny mpanondro.
//! Ny firafitry ny angon-drakitra toy ny hazo dia matetika miorina amin'ny boaty satria ny tadim-poitra tsirairay matetika dia manana tompony iray ihany, ny ray aman-dreny.
//!
//! ## Toro-isa voaisa
//!
//! Ny karazany [`Rc`] dia karazan-tondro isaina tsy threadsafe azo isaina hizarana fahatsiarovana ao anaty kofehy.
//! Ny pointer [`Rc`] dia mamono karazana, `T`, ary mamela ny fidirana amin'ny `&T`, referansa iraisana.
//!
//! Ilaina ity karazana ity raha toa ka miovaova loatra ny fampiharana ny lova nolovaina (toy ny fampiasana [`Box`]) ary matetika ampiarahina amin'ireo karazana [`Cell`] na [`RefCell`] mba hahafahana miovaova.
//!
//!
//! ## Fanondroana isa voaisa amin'ny atomika
//!
//! Ny karazany [`Arc`] dia ilay threadsafe mitovy amin'ny karazany [`Rc`].Izy io dia manome ny fiasan'ny [`Rc`] rehetra, raha tsy hoe mitaky ny fizarana ilay karazana `T`.
//! Ankoatr'izay, [`Arc<T>`][`Arc`] dia azo alefa raha tsy [`Rc<T>`][`Rc`] kosa.
//!
//! Ity karazana ity dia mamela ny fidirana an-tserasera amin'ireo angon-drakitra misy ao aminy, ary matetika ampiarahina amin'ireo primitives fampitahana toy ny mutexes hahafahana miova ny loharanom-pahalalana zaraina.
//!
//! ## Collections
//!
//! Ny fampiharana ny firafitry ny angon-drakitra ankapobeny dia voafaritra ao amin'ity tranomboky ity.Aondrana indray amin'ny alàlan'ny [standard collections library](../std/collections/index.html) izy ireo.
//!
//! ## Atohofy betsaka interface
//!
//! Ny maodelin'ny [`alloc`](alloc/index.html) dia mamaritra ny interface avo lenta ho an'ny mpaninjara manerantany.Tsy mifanaraka amin'ny libc API mpizara.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// Raha ara-teknika dia bug ao amin'ny rustdoc ity: hitan'i rustdoc ny antontan-taratasy ao amin'ny `#[lang = slice_alloc]` blocks ho an'ny `&[T]`, izay misy koa antontan-taratasy mampiasa an'io endri-javatra io ao amin'ny `core`, ary tezitra fa tsy afaka mandeha ilay vavahady manasongadina.
// Raha ny tokony ho izy dia tsy hijerena ny vavahady aseho ho an'ny dokam-barotra avy amin'ny crates hafa izany, fa satria tsy hita ho an'ny entana lang io dia toa tsy ilaina ny manamboatra azy io.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// Avelao hizaha toetra ity trano famakiam-boky ity

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// Module misy macros anatiny ampiasain'ny modules hafa (mila ampidirina alohan'ny modules hafa).
#[macro_use]
mod macros;

// Vongana natokana ho an'ny paikady fizarana ambany

pub mod alloc;

// Karazana primitive mampiasa ny korontam-bato etsy ambony

// Ilaina ny fepetra mamaritra ny Mod avy `boxed.rs` mba tsy kopia ny Lang-zavatra, rehefa manorina amin'ny fizahan-toetra cfg;fa mila mamela kaody manana fanambarana `use boxed::Box;` ihany koa.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}