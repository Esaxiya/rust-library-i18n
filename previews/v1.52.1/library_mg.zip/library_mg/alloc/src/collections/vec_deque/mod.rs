//! Filaharana roa sosona napetraka miaraka amin'ny buffer peratra mety maniry.
//!
//! Ity filaharana ity dia misy sisin-tsoratra *O*(1) amortisialy sy fanesorana amin'ny sisin'ny fitoeran'ny kaontenera.
//! Izy io koa dia manana index O * (1) toy ny vector.
//! Ireo singa voarakitra dia tsy takiana mba azo adika, ary ny filaharana dia halefa raha azo alefa ilay karazana misy.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Herin'ny roa lehibe indrindra

/// Filaharana roa sosona napetraka miaraka amin'ny buffer peratra mety maniry.
///
/// Ny fampiasana "default" an'ity karazana ity ho filaharana dia ny fampiasana [`push_back`] hanampiana amin'ny filaharana, ary [`pop_front`] hanesorana ny filaharana.
///
/// [`extend`] ary [`append`] manosika ny lamosina amin'ity fomba ity, ary ny miverina mihoatra ny `VecDeque` dia mandeha miverina mankany aoriana.
///
/// Satria `VecDeque` dia buffer peratra, ny singa ao aminy dia tsy voatery hitadidy fahatsiarovana.
/// Raha te hiditra amin'ireo singa ianao ho toy ny tapa-tokana, toy ny fanasokajiana mahomby, azonao atao ny mampiasa [`make_contiguous`].
/// Izy io dia manodina ny `VecDeque` mba tsy hamatotra ireo singa ao aminy, ary mamerina ny silaka azo ovaina amin'ny filaharan'ny singa ankehitriny.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // ny rambony sy ny loha dia tondro ao anaty buffer.
    // Ny rambony dia manondro hatrany ny singa voalohany azo vakiana, ny loha dia manondro hatrany ny toerana tokony hanoratana.
    //
    // Raha rambo==lohany dia foana ny buffer.Ny halavan'ny ringbuffer dia faritana ho toy ny elanelana misy eo amin'izy roa.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Mihazakazaka ny mpanimba ny entana rehetra ao amin'ilay sombin-javatra rehefa milatsaka izy (ara-dalàna na mandritra ny famafanaana aina).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // mampiasa mitete ho an'ny [T]
            ptr::drop_in_place(front);
        }
        // RawVec dia mitantana ny fifanolanana
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Mamorona `VecDeque<T>` foana.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Mety kokoa amin'ny lafiny maria
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Mety kokoa amin'ny lafiny maria
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Ho an'ny karazana habe aotra dia eo amin'ny fahafaha-manao ambony indrindra foana isika
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Avadiho ho pika ny ptr
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Avadiho ho sl mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Mamindra singa iray ao anaty buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Manoratra singa iray ao anaty buffer, mampihetsika azy.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Miverina `true` raha toa ka feno ny buffer.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Miverina ny index ao amin'ny buffer eo ambaniny ho an'ny index index element lojika.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Miverina ny index ao amin'ny buffer eo ambaniny ho an'ny index index + addend singa lojika.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Miverina ny index ao amin'ny buffer ambanin'ny tany ho an'ny mari-pahaizana singa lojika nomena, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Mandika andian-tsarimihetsika tandindona len izay manomboka hatrany amin'ny src ka hatrany amin'ny dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Mandika andian-tsarimihetsika tandindona len izay manomboka hatrany amin'ny src ka hatrany amin'ny dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Mandika sakana iray mety ho fonosana fitadidiana len efa ela hatrany src mankany amin'ny dest.
    /// (abs(dst - src) + len) dia tsy tokony ho lehibe kokoa noho ny cap() (Tsy maintsy farafahakeliny faritra mitohy mifanindry eo anelanelan'ny src sy ny dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src tsy mifono, dst tsy mifono
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst alohan'ny src, src tsy mifono fa mifono
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src alohan'ny dst, src tsy mifono, mifono
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst alohan'ny src, src mifono, dst tsy mifono
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src alohan'ny dst, fonosana src, dst tsy fonosina
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst alohan'ny src, fonosana src, fonosana dst
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src alohan'ny dst, fonosana src, fonosana dst
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Manetsiketsika ny loha sy ny rambony manodidina hizahana ny zava-misy fa nifindra toerana fotsiny izahay.
    /// Tsy azo antoka satria matoky ny taloha_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Afindra ny faritra mifanila fohy indrindra amin'ny buffer peratra TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Mamorona `VecDeque` foana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Mamorona `VecDeque` foana miaraka amin'ny habaka ho an'ny singa `capacity` farafaharatsiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 satria mamela ny habaka iray foana ny ringbuffer
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Manome fanovozan-kevitra momba ilay singa ao amin'ny fanondroana nomena.
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Manome fanovozan-kevitra miovaova amin'ny singa amin'ny fanondroana nomena.
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Mampifamadika ireo singa amin'ny indéks `i` sy `j`.
    ///
    /// `i` ary `j` dia mety hitovy.
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka ivelan'ny fetra ny index rehetra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Miverina ny isan'ny singa azon'ny `VecDeque` tazonina tsy misy famerenana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Mitahiry ny fahaiza-manao farafahakeliny ho an'ny singa `additional` misimisy kokoa hampidirina ao amin'ilay `VecDeque` nomena.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// Mariho fa ny mpizara dia mety hanome toerana betsaka kokoa noho ny angatahany.
    /// Noho izany ny fahaiza-manao dia tsy azo atokisana ho kely indrindra.
    /// Aleo [`reserve`] raha andrasana ny fampidirana future.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra `usize` ny fahafaha-manao vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Mitahiry fahaiza-manao farafahakeliny `additional` singa bebe kokoa hampidirina ao amin'ny `VecDeque` nomena.
    /// Ny famoriam-bola dia mety hitahiry toerana bebe kokoa hisorohana ny fizahana toerana matetika.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra `usize` ny fahafaha-manao vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Miezaka mitahiry ny fahaiza-manao farafahakeliny ho an'ny singa `additional` misimisy kokoa hampidirina ao amin'ny `VecDeque<T>` nomena.
    ///
    /// Aorian'ny fiantsoana `try_reserve_exact`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional`.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// Mariho fa ny mpizara dia mety hanome toerana betsaka kokoa noho ny angatahany.
    /// Noho izany, ny fahaiza-manao dia tsy azo atokisana ho kely indrindra.
    /// Aleo `reserve` raha andrasana ny fampidirana future.
    ///
    /// # Errors
    ///
    /// Raha mihoatra ny `usize` ny fahaiza-manao na mitatitra ny tsy fahombiazan'ny mpizara dia miverina ny lesoka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Arovy mialoha ny fahatsiarovana, mivoaka raha tsy vitantsika
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Fantatsika izao fa tsy afaka OOM(Out-Of-Memory) eo afovoan'ny asa sarotra ataontsika izany
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tena sarotra
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Miezaka mitahiry fahaiza-manao farafahakeliny `additional` singa bebe kokoa hampidirina ao amin'ny `VecDeque<T>` nomena.
    /// Ny famoriam-bola dia mety hitahiry toerana bebe kokoa hisorohana ny fizahana toerana matetika.
    /// Aorian'ny fiantsoana `try_reserve`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional`.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// # Errors
    ///
    /// Raha mihoatra ny `usize` ny fahaiza-manao na mitatitra ny tsy fahombiazan'ny mpizara dia miverina ny lesoka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Arovy mialoha ny fahatsiarovana, mivoaka raha tsy vitantsika
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Fantatsika izao fa tsy afaka OOM eo afovoan'ny asa sarotra ataontsika
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tena sarotra
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Mampihena ny fahafahan'ny `VecDeque` araka izay azo atao.
    ///
    /// Hidina ambany hatrany araka izay azo atao amin'ny lavany izy io fa ny mpanokana dia mety mbola hampandre ny `VecDeque` fa misy toerana ho an'ny singa vitsivitsy hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Mampihena ny fahafahan'ny `VecDeque` misy fehy ambany.
    ///
    /// Ny fahaiza-manao dia hijanona farafahakeliny lehibe toy ny halavany sy ny sanda omena.
    ///
    ///
    /// Raha toa ka ambany noho ny fetra ambany ny fahafaha-miasa ankehitriny dia tsy misy izany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Tsy mila miahiahy momba ny safo-drano isika satria na `self.len()` na `self.capacity()` dia mety tsy ho `usize::MAX`.
        // +1 satria mamela ny habaka iray foana ny ringbuffer.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Misy tranga telo mahaliana:
            //   Ny singa rehetra dia avy amin'ny fetra irina Eoropeana mifanila, ary ny lohany dia ivelan'ny fefy irina Etsy an-danin'izay ny elatra, ary ny rambony dia avy amin'ny fetra irina
            //
            //
            // Amin'ny fotoana hafa rehetra, ny toeran'ny singa dia tsy misy fiantraikany.
            //
            // Manondro fa ny singa ao an-doha dia tokony hafindra.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Afindra ireo singa avy amin'ny fetra irina (toerana aorian'ny target_cap)
            if self.tail >= target_cap && head_outside {
                // faha
                //   [. . . . . . . . o o o o o o o . ]
                //    faha
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // faha
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Mampihena ny `VecDeque`, mitazona ireo singa `len` voalohany ary mandatsaka ny ambiny.
    ///
    ///
    /// Raha lehibe kokoa noho ny halavan'ny `VecDeque` i `len` dia tsy misy vokany izany.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Mihazakazaka ny mpanimba ny entana rehetra ao amin'ilay sombin-javatra rehefa milatsaka izy (ara-dalàna na mandritra ny famafanaana aina).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Milamina satria:
        //
        // * Izay sombina ampitaina amin'ny `drop_in_place` dia mitombina;ny tranga faharoa dia manana `len <= front.len()` ary miverina amin'ny `len > self.len()` dia miantoka ny `begin <= back.len()` amin'ny tranga voalohany
        //
        // * Ny lohan'ny VecDeque dia afindra alohan'ny hiantsoana ny `drop_in_place`, noho izany dia tsy misy vidiny latsaka indroa raha `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Hamarino tsara fa nilatsaka ny tapany faharoa na dia mpanimba iray amin'ny panics voalohany aza.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Miverina iterator aloha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Miverina iterator mifanatrika-miverina izay mamerina referansy azo ovaina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SAFETY: napetraka ny invariant fiarovana `IterMut` anatiny satria ny
        // `ring` mamorona izahay dia silaka tsy azo ovaina mandritra ny androm-piainana '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Miverina sombin-tsivana izay misy, milahatra, ny atin'ny `VecDeque`.
    ///
    /// Raha nantsoina taloha [`make_contiguous`], ny singa rehetra ao amin'ny `VecDeque` dia ho ao amin'ny sombin-javatra voalohany ary ho foana ny sombin-javatra faharoa.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Miverina sombin-tsivana izay misy, milahatra, ny atin'ny `VecDeque`.
    ///
    /// Raha nantsoina taloha [`make_contiguous`], ny singa rehetra ao amin'ny `VecDeque` dia ho ao amin'ny sombin-javatra voalohany ary ho foana ny sombin-javatra faharoa.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Mamerina ny isan'ny singa ao amin'ny `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Miverina `true` raha foana ny `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Mamorona iterator izay manarona ny faritra voalaza ao amin'ny `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics raha ny teboka fanombohana dia lehibe kokoa noho ny teboka farany na raha lehibe kokoa noho ny halavan'ny vector ny teboka farany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ny ambaratonga feno dia mandrakotra ny atiny rehetra
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Ny referansa iraisana ananantsika ao amin'ny &self dia voatazona ao amin'ny '_ an'i Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Mamorona iterator izay manarona ny elanelam-piovana voafaritra ao amin'ny `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics raha ny teboka fanombohana dia lehibe kokoa noho ny teboka farany na raha lehibe kokoa noho ny halavan'ny vector ny teboka farany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ny ambaratonga feno dia mandrakotra ny atiny rehetra
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SAFETY: napetraka ny invariant fiarovana `IterMut` anatiny satria ny
        // `ring` mamorona izahay dia silaka tsy azo ovaina mandritra ny androm-piainana '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Mamorona iterator mitsika izay manala ny elanelam-potoana voatondro ao amin'ny `VecDeque` ary mamokatra ireo entana nesorina.
    ///
    /// Fanamarihana 1: nesorina ny elanelan'ny singa na dia tsy lanina hatramin'ny farany aza ilay iterator.
    ///
    /// Fanamarihana 2: Tsy voafaritra mazava hoe firy ny singa nesorina tao amin'ilay deque, raha tsy nilatsaka ny sanda `Drain`, fa tapitra kosa ny indram-bola tazoniny (ohatra: `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics raha ny teboka fanombohana dia lehibe kokoa noho ny teboka farany na raha lehibe kokoa noho ny halavan'ny vector ny teboka farany.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ny faritra feno dia mamafa ny atiny rehetra
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Fiarovana amin'ny fahatsiarovana
        //
        // Rehefa noforonina ny Drain voalohany dia nohafohezina ny loharanom-baovao mba tsy hilazana ny singa tsy voatanisa na mifindra avy amin'ny singa azo idirana mihitsy raha toa ka tsy afaka mihazakazaka mihitsy ilay mpanimba ny Drain.
        //
        //
        // Drain dia hamoaka ptr::read ireo soatoavina esorina.
        // Rehefa vita izany, ny tahirin-kevitra sisa tavela dia hosarahina mba hanaronana ny lavaka, ary ny sanda head/tail dia haverina amin'ny laoniny tsara.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Ny singa ao amin'ny deque dia mizara telo:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;T=drain_tail;h=drain_head
        //
        // Izahay dia mitahiry ny drain_tail ho self.head, ary ny drain_head ary self.head toy ny after_tail ary aorian'ny_head ao amin'ny Drain.
        // Io koa dia mametaka ny laharana mahomby ka raha mivoaka ny Drain dia hadinonay ny momba ny soatoavina mety nafindra aorian'ny fanombohan'ny drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" momba ny soatoavina aorian'ny fanombohan'ny drain mandra-pahatapitry ny fahavitan'ny drain ary mandeha ny mpanimba Drain.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Zava-dehibe dia ny referansa zaraina `self` fotsiny no vitanay eto ary vakiantsika avy eo.
                // Izahay dia tsy manoratra amin'ny `self` na miverina mamaky référence azo ovaina.
                // Noho izany ny tondro masaka noforoninay etsy ambony, ho an'ny `deque`, dia mitoetra ho manan-kery hatrany.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Manadio ny `VecDeque`, manala ny sanda rehetra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Miverina `true` raha toa ka misy singa mitovy amin'ny sanda nomena ny `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Manome fanondroana ny singa eo aloha, na `None` raha foana ny `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Manome fanovozan-kevitra miovaova amin'ny singa anoloana, na `None` raha foana ny `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Manome andinin-tsoratra ho an'ny singa any aoriana, na `None` raha foana ny `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Manome fanovozan-kevitra miovaova amin'ny singa any aoriana, na `None` raha foana ny `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Esorina ny singa voalohany ary averiny, na `None` raha foana ny `VecDeque`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Esory ny singa farany amin'ny `VecDeque` ary avereno, na `None` raha foana izy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Manomana singa amin'ny `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Manampy singa ao ambadiky ny `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Tokony hodinihintsika ve ny `head == 0`
        // mifanila ve i `self`?
        self.tail <= self.head
    }

    /// Manala singa iray na aiza na aiza ao amin'ny `VecDeque` ary mamerina azy, manolo azy amin'ny singa voalohany.
    ///
    ///
    /// Tsy mitahiry ny filaharana izany, fa *O*(1).
    ///
    /// Miverina `None` raha toa ka ivelan'ny fetra ny `index`.
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Manala singa iray na aiza na aiza ao amin'ny `VecDeque` ary mamerina azy, manolo azy amin'ny singa farany.
    ///
    ///
    /// Tsy mitahiry ny filaharana izany, fa *O*(1).
    ///
    /// Miverina `None` raha toa ka ivelan'ny fetra ny `index`.
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Mampiditra singa ao amin'ny `index` ao anatin'ny `VecDeque`, manova ny singa rehetra misy indice lehibe kokoa na mitovy amin'ny `index` mankany aoriana.
    ///
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Panics
    ///
    /// Panics raha `index` lehibe kokoa noho ny halavan'ny `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Afindra ny singa kely indrindra ao amin'ny buffer peratra ary ampidiro ilay zavatra nomena
        //
        // Amin'ny ankapobeny len/2, singa 1 no hafindra. O(min(n, n-i))
        //
        // Misy tranga telo lehibe:
        //  Misy ifandraisany ireo singa
        //      - tranga manokana raha ny rambony dia 0 Ny singa dia tsy mitombina ary ny fampidirana dia ao amin'ny fizarana rambo Ireo singa dia tsy azo antoka ary ny fampidirana dia ao amin'ny faritra lohan'ny
        //
        //
        // Fa tsirairay ireo misy tranga roa:
        //  Ampidiro akaiky kokoa ny rambony Mampiditra akaiky kokoa ny loha
        //
        // Lakile: H, self.head
        //      T, self.tail o, singa manan-kery I, singa fampidirana A, Ilay singa tokony ho taorian'ny teboka fampidirana M, manondro singa nifindra
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // contiguous, ampidiro akaiky ny rambony:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           faha
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // contiguous, ampidiro akaiky ny rambony sy ny rambony dia 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MG

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Efa nanetsika ny rambony, ka ny singa `index - 1` ihany no alainay.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguous, ampidiro eo akaikin'ny loha:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             faha
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, ampidiro akaikin'ny rambony, fizarana rambony:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, ampidiro akaikin'ny loha, fizarana rambony:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // mandika singa hatramin'ny loha vaovao
                    self.copy(1, 0, self.head);

                    // adikao ny singa farany amin'ny toerana tsy misy eo ambanin'ny buffer
                    self.copy(0, self.cap() - 1, 1);

                    // afindra ireo singa avy amin'ny idx mankany amin'ny farany tsy tafiditra ao anatin'ilay ^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, ampidiro manakaiky ny rambony, ny loha-lohan-doha, ary eo amin'ny index zero amin'ny buffer anatiny:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // mandika singa hatramin'ny rambony vaovao
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // adikao ny singa farany amin'ny toerana tsy misy eo ambanin'ny buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, ampidiro akaikin'ny rambony, faritra lohany:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // mandika singa hatramin'ny rambony vaovao
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // adikao ny singa farany amin'ny toerana tsy misy eo ambanin'ny buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // afindra ireo singa avy amin'ny idx-1 hifarana mandroso tsy anisany ^ singa
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, ampidiro akaikin'ny loha, faritra loha:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // mety efa novaina ny rambony ka mila manisa isika
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Manala sy mamerina ny singa ao amin'ny `index` avy amin'ny `VecDeque`.
    /// Na inona na inona farany dia akaiky kokoa ny fanesorana fotoana dia ho voatosika hanao trano, ary ny singa voakasiky dia nifindra tany amin'ny toerana vaovao.
    ///
    /// Miverina `None` raha toa ka ivelan'ny fetra ny `index`.
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Misy tranga telo lehibe:
        //  Ny singa dia mifanakaiky Etsy an-daniny ny singa ary ny fanesorana dia ao amin'ny fizarana rambony Ireo singa dia tsy azo antoka ary ny fanesorana dia ao amin'ny faritra lohany
        //
        //      - tranga manokana rehefa mifanila amin'ny lafiny teknika ny singa, fa self.head =0
        //
        // Fa tsirairay ireo misy tranga roa:
        //  Ampidiro akaiky kokoa ny rambony Mampiditra akaiky kokoa ny loha
        //
        // Lakile: H, self.head
        //      T, self.tail O, Valid singa X, singa nanamarika ny fanesorana R, mampiseho singa izay efa nesorina M, mampiseho singa Voatosika
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // mifanakaiky, esory akaikin'ny rambony:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               faha
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // mifanakaiky, esory akaikin'ny loha:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             faha
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, esory akaiky ny rambony, fizarana rambony:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, esory akaikin'ny loha, loha-loha:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, esory akaikin'ny loha, faritra amin'ny rambony:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // na quasi-discontiguous, esory eo akaikin'ny loha, fizarana rambony:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         faha
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // manaova singa ao amin'ny fizarana rambony
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Misoroka ny fidobohana.
                    if self.head != 0 {
                        // singa voalohany handika ho foana tsy mitondra fanatitra toerana
                        self.copy(self.cap() - 1, 0, 1);

                        // mamindra ireo singa ao amin'ny faritra lohan'ny loha mankany aoriana
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, esory akaiky ny rambony, faritra loha:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // manaova singa hatramin'ny idx
                    self.copy(1, 0, idx);

                    // kopia ny singa farany ho any amin'ny toerana foana
                    self.copy(0, self.cap() - 1, 1);

                    // mamindra singa avy amin'ny rambony mankany amin'ny farany, tsy manilika ny iray farany
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Mizara roa ny `VecDeque` amin'ny index nomena.
    ///
    /// Miverina `VecDeque` vao natokana.
    /// `self` misy singa `[0, at)`, ary ny `VecDeque` niverina dia misy singa `[at, len)`.
    ///
    /// Mariho fa ny fahafahan'ny `self` tsy miova.
    ///
    /// Element amin'ny index 0 no eo alohan'ny filaharana.
    ///
    /// # Panics
    ///
    /// Panics raha `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` mivoaka amin'ny tapany voalohany.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // raiso fotsiny ny tapany faharoa.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` mitoetra amin'ny tapany faharoa, mila mampiditra ireo singa nolalovantsika tamin'ny tapany voalohany.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Manadio izay misy ny faran'ny buffer
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Mamindra ny singa `other` rehetra mankany `self`, mamela `other` foana.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra ny `usize` ny singa vaovao ao aminy.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naive impl
        self.extend(other.drain(..));
    }

    /// Ireo singa notondroin'ny predicate ihany no tazonina.
    ///
    /// Raha atao teny hafa, esory ny singa `e` rehetra ka miverina diso ny `f(&e)`.
    /// Ity fomba ity dia miasa amin'ny toerany, mitsidika ny singa tsirairay avy indray mandeha amin'ny filaharana tany am-boalohany, ary mitahiry ny filaharan'ny singa tazonina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Ny filaharana tena izy dia mety ilaina amin'ny fanarahana ny fanjakana ivelany, toy ny index.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Mety panic na esorina io
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Ataovy avo roa heny ny haben'ny buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Manova ny `VecDeque` eo amin'ny toerany ka ny `len()` dia mitovy amin'ny `new_len`, na amin'ny fanesorana ireo singa be loatra avy any aoriana na amin'ny alàlan'ny fampidirana ireo singa vokarin'ny fiantsoana `generator` any aoriana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Mamerina mandamina ny fitehirizana anatiny an'io deque io ka io dia voadio iray mifanila aminy, izay averina avy eo.
    ///
    /// Ity fomba ity dia tsy mizara ary tsy manova ny filaharan'ireo singa natsofoka.Rehefa mamerina silaka azo ovaina izy ity dia azo ampiasaina hanivanana deque.
    ///
    /// Raha vantany vao mifanakaiky ny fitehirizana anatiny, ny fomba [`as_slices`] sy [`as_mut_slices`] dia hamerina ny atiny `VecDeque` iray manontolo ao anaty sombina tokana.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Fanasoketana ny atin'ny deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // manasokajy ny deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // mandahatra azy amin'ny lamina mifamadika
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Fahazoana fidirana tsy miovaova amin'ilay silaka mifanakaiky.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // azontsika antoka izao fa `slice` dia misy ny singa rehetra ao amin'ny deque, raha mbola manana fidirana tsy azo ovaina mankany `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // misy toerana malalaka ampy handikana ny rambony indray mandeha, midika izany fa ampodintsika mihemotra aloha ny loha, ary avy eo kopia ny rambony amin'ny toerana mety.
            //
            //
            // avy amin'ny: DEFGH .... ABC
            // mankany: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Tsy mandinika isika izao .... ABCDEFGH
            // ho contiguous satria `head` dia `0` amin'ity tranga ity.
            // Na dia mety te hanova an'io aza isika dia tsy misy dikany izany satria toerana vitsivitsy manantena ny `is_contiguous` dia midika fa afaka manapaka fotsiny amin'ny `buf[tail..head]` fotsiny isika.
            //
            //

            // misy toerana malalaka ampy handika ny loha indray mandeha, midika izany fa ampodintsika aloha ny rambony, ary avy eo kopia ny loha amin'ny toerana mety.
            //
            //
            // avy amin'ny: FGH .... ABCDE
            // mankany: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // Ny maimaim-poana dia kely noho ny loha sy ny rambo, midika izany fa tsy maintsy ataontsika miadana "swap" ny rambony sy ny loha.
            //
            //
            // avy amin'ny: EFGHI ... ABCD na HIJK.ABCDEFG
            // mankany: ABCDEFGHI ... na ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Ny olana ankapobeny dia toa ity GHIJKLM ... ABCDEF ity, alohan'ny hisoloany ny ABCDEFM ... GHIJKL, aorian'ny fividianana swaps 1 ABCDEFGHIJM ... KL, ifanakalozy mandra-pahatongan'ny edge ankavia amin'ny fivarotana temp
                //                  - avy eo avereno ny algorithm amin'ny fivarotana (smaller) vaovao Indraindray dia tonga ny fivarotana temp rehefa tonga eo amin'ny faran'ny buffer ny edge havanana, midika izany fa nahatratra ny filaharana mahitsy izy niaraka tamin'ny swaps vitsy kokoa!
                //
                // E.g
                // EF..ABCD ABCDEF .., taorian'ny swap efatra fotsiny dia nahavita isika
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Ahodina ny toerana an-dàlana `mid` an-kavia havia.
    ///
    /// Equivalently,
    /// - Ahodina ny entana `mid` ho eo amin'ny laharana voalohany.
    /// - Alefaso ireo entana `mid` voalohany ary atosika hatramin'ny farany.
    /// - Mihodina ny toerana `len() - mid` miankavanana.
    ///
    /// # Panics
    ///
    /// Raha `mid` lehibe kokoa noho `len()`.
    /// Mariho fa `mid == len()` dia manao _not_ panic ary fihodinana no-op.
    ///
    /// # Complexity
    ///
    /// Mila fotoana `*O*(min(mid, len() - mid))` fa tsy misy toerana fanampiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Mihodina ny toerana milahatra `k` milahatra avo roa heny amin'ny ankavanana.
    ///
    /// Equivalently,
    /// - Ahodina ny entana voalohany ho amin'ny toerana `k`.
    /// - Alefaso ireo entana `k` farany ary atosika mankany aloha.
    /// - Ahodina ny toerana `len() - k` ankavia.
    ///
    /// # Panics
    ///
    /// Raha `k` lehibe kokoa noho `len()`.
    /// Mariho fa `k == len()` dia manao _not_ panic ary fihodinana no-op.
    ///
    /// # Complexity
    ///
    /// Mila fotoana `*O*(min(k, len() - k))` fa tsy misy toerana fanampiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: ireto fomba roa manaraka ireto dia mitaky ny habetsaky ny fihodinana
    // ho latsaky ny antsasaky ny halavan'ny deque.
    //
    // `wrap_copy` mitaky an'io `min(x, cap() - x) + copy_len <= cap()` io, fa noho ny `min` dia tsy mihoatra ny antsasaky ny fahafaha-manao na inona na inona x, noho izany dia tsara ny miantso eto satria miantso zavatra latsaky ny antsasaky ny halavany isika, izay tsy mihoatra ny antsasaky ny fahafaha-manao velively.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary dia mitady an'ity `VecDeque` milahatra ity ho an'ny singa iray.
    ///
    /// Raha hita ny sanda dia miverina [`Result::Ok`], misy ny index an'ny singa mifangaro.
    /// Raha misy lalao maromaro, dia azo averina ny iray amin'ireo lalao.
    /// Raha tsy hita ny sanda dia averina [`Result::Err`], misy ny index izay azo ampidirina singa mifangaro raha mitazona ny filaharana milahatra.
    ///
    ///
    /// # Examples
    ///
    /// Mitady andiana singa efatra.
    /// Ny voalohany dia hita, miaraka amina toerana voafaritra tokana;ny faharoa sy ny fahatelo tsy hita;ny fahefatra afaka mifanaraka misy toerana any `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Raha te hampiditra entana amin'ny `VecDeque` nalahatra ianao, ary mitazona filaharana:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary dia mitady an'io `VecDeque` voasokajy io miaraka amina asa fampitahana.
    ///
    /// Ny asan'ny mpampitaha dia tokony hampihatra lamina mifanaraka amin'ny filahatr'ilay `VecDeque` ambanin'ny tany, mamerina kaody kaody izay manondro raha `Less`, `Equal` na `Greater` no ifandiran'izy ireo noho ilay kendrena tadiavina.
    ///
    ///
    /// Raha hita ny sanda dia miverina [`Result::Ok`], misy ny index an'ny singa mifangaro.Raha misy lalao maromaro, dia azo averina ny iray amin'ireo lalao.
    /// Raha tsy hita ny sanda dia averina [`Result::Err`], misy ny index izay azo ampidirina singa mifangaro raha mitazona ny filaharana milahatra.
    ///
    /// # Examples
    ///
    /// Mitady andiana singa efatra.Ny voalohany dia hita, miaraka amina toerana voafaritra tokana;ny faharoa sy ny fahatelo tsy hita;ny fahefatra dia afaka mifanaraka amin'ny toerana rehetra ao amin'ny `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary dia mikaroka an'io `VecDeque` voasokajy io miaraka amina lahasa fitrandrahana manan-danja.
    ///
    /// Mihevitra fa ny `VecDeque` dia voasokajy amin'ny lakile, ohatra amin'ny [`make_contiguous().sort_by_key()`](#method.make_contiguous) izay mampiasa ny fitrandrahana fanalahidy mitovy.
    ///
    ///
    /// Raha hita ny sanda dia miverina [`Result::Ok`], misy ny index an'ny singa mifangaro.
    /// Raha misy lalao maromaro, dia azo averina ny iray amin'ireo lalao.
    /// Raha tsy hita ny sanda dia averina [`Result::Err`], misy ny index izay azo ampidirina singa mifangaro raha mitazona ny filaharana milahatra.
    ///
    /// # Examples
    ///
    /// Jereo ny andiana singa efatra amin'ny tapa-tsiroaroa voasokajy araka ny singa faharoa.
    /// Ny voalohany dia hita, miaraka amina toerana voafaritra tokana;ny faharoa sy ny fahatelo tsy hita;ny fahefatra afaka mifanaraka misy toerana any `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Manova ny `VecDeque` eo amin'ny toerany ka ny `len()` dia mitovy amin'ny new_len, na amin'ny fanesorana ireo singa be loatra avy any aoriana na amin'ny alàlan'ny fampidirana klone `value` any aoriana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Miverina ny index ao amin'ny buffer eo ambaniny ho an'ny index index element lojika.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // habe dia herin'ny 2 foana
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Kajy ny isan'ny singa sisa hovakiana ao anaty buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // habe dia herin'ny 2 foana
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Hatrany zaraina amin'ny fizarana telo, ohatra: tena: [a b c|d e f] hafa: [0 1 2 3|4 5] aloha=3, tapaky ny volana=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Tsy azo atao ny mampiasa Hash::hash_slice amin'ny sombin-kaody averina amin'ny alàlan'ny fomba as_slices satria ny halavany dia mety miovaova amin'ny endrika hafa.
        //
        //
        // Hasher ihany no miantoka ny fitoviana amin'ny antso mitovy amin'ny fomba fiasa.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Manjifa ny `VecDeque` ho lasa iterator manoloana-averina mamokatra singa isam-sandany.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ity asa ity dia tokony hitovy amin'ny:
        //
        //      ho an'ny entana amin'ny iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Avadiho ho [`VecDeque<T>`] ny [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Izany dia misoroka ny famerenana amin'ny toerana azo atao, fa ny fepetra momba izany dia henjana, ary mety hiova, ary noho izany dia tsy tokony hiankina raha tsy ny `Vec<T>` dia avy amin'ny `From<VecDeque<T>>` ary mbola tsy notokanana.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Tsy misy ny fizarana tena izy mba hanahiran'ny ZST ny fahaizany, fa ny `VecDeque` kosa tsy mahazaka halava hatramin'ny `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Mila Raha hanova haben raha toa ny fahafahana dia tsy hery roa, kely loatra na tsy manana ny iray, fara fahakeliny, toerana maimaim-poana.
            // Ataontsika izany raha mbola ao amin'ny `Vec` ka hilatsaka amin'ny panic ireo entana.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Avadiho ho [`Vec<T>`] ny [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Tsy mila mizara indray io, fa mila manao fihetsiketsehana *O*(*n*) raha toa ka tsy eo am-piandohan'ny fizarana ny buffer boribory.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Ity dia *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Mila manamboatra data indray ity iray ity.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}