//! Filaharana laharam-pahamehana apetraka amin'ny antontam-bola roa.
//!
//! Ny fampidirana sy mipoitra ny singa lehibe indrindra dia manana fahasarotana amin'ny ora *O*(log(*n*)).
//! Ny manamarina ny singa lehibe indrindra dia *O*(1).Ny famadihana ny vector amin'ny antontam-bato dia azo atao eo amin'ny toerany ary manana fahasarotana *O*(*n*).
//! Ny antontam-bola mimari-droa dia azo avadika ho vector voalahatra eo an-toerana ihany koa, ka avela hampiasaina ho an'ny *O*(*n*\*log(* n*)) eo an-toerana heapsort.
//!
//! # Examples
//!
//! Ity dia ohatra lehibe kokoa izay mampihatra [Dijkstra's algorithm][dijkstra] hamahana ny [shortest path problem][sssp] amin'ny [directed graph][dir_graph].
//!
//! Mampiseho ny fomba fampiasana [`BinaryHeap`] amin'ny karazana fanao izy.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Ny filaharana laharam-pahamehana dia miankina amin'ny `Ord`.
//! // Ampiharo miharihary ny trait ka manjary antontam-bato ny filaharana fa tsy tambabe.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Jereo fa miverimberina amin'ny vidiny izahay.
//!         // Raha misy fatorana dia ampitahaintsika ny toerana, ilaina ity dingana ity mba hampifanarahana ny fampiharana ny `PartialEq` sy `Ord`.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` mila ampiharina koa.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Ny teboka tsirairay dia aseho ho `usize`, ho fampiharana fohy kokoa.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Algorithme faran'ny fohy indrindra Dijkstra.
//!
//! // Atombohy amin'ny `start` ary ampiasao `dist` hanarahana ny elanelana fohy indrindra amin'izao fotoana izao.Ity fampiharana ity dia tsy mahomby amin'ny fitadidiana satria mety hamela teboka duplicate ao amin'ny filaharana.
//! //
//! // Izy io koa dia mampiasa `usize::MAX` ho sandan'ny sentinel, ho fampiharana tsotra kokoa.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=elanelana fohy indrindra amin'izao fotoana izao manomboka amin'ny `start` ka hatramin'ny `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Ao amin'ny `start` izahay, miaraka amin'ny vidiny aotra
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Diniho ny sisin-tany amin'ny teboka ambany ambany (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Raha tsy izany dia afaka nanohy nitady ireo lalana fohy indrindra isika
//!         if position == goal { return Some(cost); }
//!
//!         // Zava-dehibe satria mety efa nahita fomba tsara kokoa isika
//!         if cost > dist[position] { continue; }
//!
//!         // Ho an'ny node tsirairay azontsika tratrarina, jereo raha afaka mahita fomba isika amin'ny vidiny ambany mandalo io node io
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Raha izany dia ampio amin'ny sisintany ary tohizo
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Fitsaharana, nahita fomba tsara kokoa isika izao
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Tanjona tsy tratrarina
//!     None
//! }
//!
//! fn main() {
//!     // Ity ny sary nalahatra hampiasaintsika.
//!     // Ireo isa node dia mifanaraka amin'ny fanjakana samihafa, ary ny lanjan'ny edge dia tandindon'ny vidin'ny fifindrana avy amin'ny teboka iray mankany amin'ny iray hafa.
//!     //
//!     // Mariho fa ny sisiny dia làlana tokana.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Ny graf dia aseho ho toy ny lisitra mifanila toerana izay misy ny lisitry ny sisiny mivoaka ny index tsirairay, mifanaraka amin'ny lanja node.
//!     // Voafidy amin'ny fahombiazany.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Filaharana laharam-pahamehana apetraka amin'ny antontam-bola roa.
///
/// Ity dia ho be haavo.
///
/// Fahadisoana lojika raha ovaina ny entana amina fomba iray izay andidian'ny entana mifandraika amin'ny zavatra hafa, araka ny nofaritan'ny `Ord` trait, dia miova raha mbola eo am-pitoerana izy.
///
/// Amin'ny alalàn'ny kaody `Cell`, `RefCell`, fanjakana manerantany, I/O, na kaody tsy azo antoka no ahazoana azy io.
/// Ny fihetsika vokatry ny lesoka lojika toy izany dia tsy voatondro, fa tsy hiteraka fihetsika tsy voafaritra.
/// Mety tafiditra ao anatin'izany ny panics, valiny tsy marina, fanalana hetaheta, famoahana tadidy ary tsy famaranana.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Ny inferansa kely dia ahafahantsika manala sonia karazana mazava (izay mety ho `BinaryHeap<i32>` amin'ity ohatra ity).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Azontsika atao ny mampiasa ny jery todika ny zavatra manaraka ao amin'ny antontany.
/// // Amin'ity tranga ity dia mbola tsy misy entana ao ka tsy misy azontsika.
/// assert_eq!(heap.peek(), None);
///
/// // Andao ampio isa vitsivitsy ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Ankehitriny ny peek dia mampiseho ny entana manan-danja indrindra amin'ny antontam-bato.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Azontsika atao ny manamarina ny halavan'ny antontam-bato.
/// assert_eq!(heap.len(), 3);
///
/// // Azontsika atao ny miverimberina mijery ireo entana ao amin'ny antontam-bato, na dia averina ao anaty baiko tampoka aza izy ireo.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Raha alefantsika ireo isa ireo dia tokony hiverina milamina indray izy ireo.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Azontsika atao ny mamafa ny antontan-javatra sisa tavela.
/// heap.clear();
///
/// // Tokony ho foana izao ny antontam-bato.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Na `std::cmp::Reverse` na fampiharana `Ord` manokana dia azo ampiasaina hanamboarana `BinaryHeap` ho korontam-bato.
/// Izany dia mahatonga ny `heap.pop()` hamerina ny sandany kely indrindra fa tsy ny lehibe indrindra.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Fonosana ao `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Raha avoakantsika izao isa izao dia tokony hiverina amin'ny lamina mihodina izy ireo.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Fahasarotan'ny fotoana
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Ny sandan'ny `push` dia vidiny andrasana;manome ny fanadihadiana amin'ny antsipiriany kokoa ny antontan-taratasy momba ny fomba.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Structure fonosana referable miovaova amin'ny singa lehibe indrindra amin'ny `BinaryHeap`.
///
///
/// Ity `struct` dia noforonina tamin'ny fomba [`peek_mut`] amin'ny [`BinaryHeap`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SAFETY: ny peekMut dia ampiorina fotsiny ho an'ny korontam-poana.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut dia ampiorina fotsiny ho an'ny korontam-poana
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut dia ampiorina fotsiny ho an'ny korontam-poana
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Esorina ny soatoavina voatazona avy amin'ny antontam-bato ary avereno.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Mamorona `BinaryHeap<T>` foana.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Mamorona `BinaryHeap` foana ho toy ny antontan-javatra avo indrindra.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Mamorona `BinaryHeap` foana miaraka amin'ny fahaiza-manao manokana.
    /// Io dia mamela mialoha ny fahatsiarovana ampy ho an'ny singa `capacity`, ka ny `BinaryHeap` dia tsy mila averina alefa raha tsy misy soatoavina farafaharatsiny.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Miverina fanondroana miovaova amin'ny singa lehibe indrindra ao amin'ny antontam-bolan'ny binary, na `None` raha foana izy.
    ///
    /// Note: Raha tafaporitsaka ny sanda `PeekMut` dia mety ho ao anaty tsy fitoviana ny antontam-bato.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Fahasarotan'ny fotoana
    ///
    /// Raha novaina ilay entana dia *O*(log(*n*)) ny fahasarotan'ny fotoana ratsy indrindra, raha tsy izany dia *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Esory ny entana lehibe indrindra amin'ny antontam-bato roa ary avereno, na `None` raha foana izy.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Fahasarotan'ny fotoana
    ///
    /// Ny tranga ratsy indrindra `pop` amin'ny antontam-bato misy singa *n* dia *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SAFETY: !self.is_empty() dia midika fa self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Manosika entana iray ho any amin'ilay antontam-bato.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Fahasarotan'ny fotoana
    ///
    /// Ny vidin'ny `push` andrasana, salan'isa isaky ny mety ho fandefasana ireo singa atosika, ary mihoatra ny isan'ny fanosehana dia *O*(1).
    ///
    /// Ity no metrikan'ny fandaniana manan-danja indrindra rehefa manosika ireo singa izay *tsy* efa ao anaty lamina voalahatra.
    ///
    /// Mihena ny fahasarotan'ny fotoana raha atosika amin'ny filaharana miakatra be ny singa.
    /// Amin'ny tranga ratsy indrindra, ny singa dia atosika anaty filaharana miakatra ary ny vidin'ny amortisialy isaky ny tsindry dia *O*(log(*n*)) amin'ny antontam-bato misy *n* singa.
    ///
    /// Ny tranga faran'izay ratsy indrindra amin'ny antso tokana *tokana mankany `push` dia ny* O *(* n *).Ny tranga ratsy indrindra dia mitranga rehefa reraka ny fahaiza-manao ary mila manova habe.
    /// Ny vidin'ny habe dia namboarina tamin'ny isa teo aloha.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SAFETY: Satria nanosika entana vaovao izahay dia midika izany fa
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Manjifa ny `BinaryHeap` ary mamerina vector amin'ny filaharana (ascending) voalahatra.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAFETY: `end` dia avy amin'ny `self.len() - 1` ka hatramin'ny 1 (samy tafiditra ao),
            //  ka index azo ampiasaina foana io.
            //  Azo antoka ny fidirana amin'ny index 0 (ie `ptr`), satria
            //  1 <=faran'ny <self.len(), izay midika self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAFETY: `end` dia manomboka amin'ny `self.len() - 1` ka hatramin'ny 1 (samy tafiditra ao) ka:
            //  0 <1 <=faran'ny <= self.len(), 1 <self.len() izay midika hoe 0 <faran'ny sy faran'ny <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Ny fampiharana ny sift_up sy ny sift_down dia mampiasa sakana tsy azo antoka mba hamindrana singa iray avy ao amin'ny vector (avela ao aorian'ny loaka), afindrao ny hafa ary afindra miverina ao amin'ny vector ilay toerana nesorina.
    //
    // Ny karazana `Hole` dia ampiasaina hanehoana an'io, ary alao antoka fa fenoina indray ny lavaka amin'ny faran'ny habeny, na dia amin'ny panic aza.
    // Ny fampiasana lavaka dia mampihena ny singa tsy miova raha oharina amin'ny fampiasana swaps, izay misy indroa mihetsika indroa.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Ny miantso dia tsy maintsy manome antoka fa `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Esory ny sanda amin'ny `pos` ary mamorona lavaka.
        // SAFETY: Ny miantso dia manome antoka fa pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SAFETY: hole.pos()> fanombohana>=0, izay midika hoe hole.pos()> 0
            //  ary toy izany hole.pos(), 1 tsy afaka miroborobo.
            //  Izy io dia manome antoka fa ny ray aman-dreny <hole.pos() ka index manan-kery ary koa!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAFETY: Mitovy amin'ny etsy ambony ihany
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Makà singa iray ao amin'ny `pos` ary afindrao ilay antontam-bato, raha toa ka lehibe kokoa ny zanany.
    ///
    ///
    /// # Safety
    ///
    /// Ny miantso dia tsy maintsy manome antoka fa `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SAFETY: Ny miantso dia manome antoka fa pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loar invariant: zaza==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ampitahao amin'ny lehibe kokoa amin'ireo ankizy roa SAFETY: zaza <faran'ny, 1 <self.len() sy zaza + 1 <faran'ny <= self.len(), noho izany dia index tsara izy ireo.
            //
            //  zaza==2 *hole.pos() + 1!= hole.pos() sy zaza + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 na 2* hole.pos() + 2 dia mety hisondrotra raha toa ka ZST ny T
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // raha efa milamina isika dia ajanony.
            // SAFETY: ny zaza dia izao na ny antitra na ilay zaza antitra + 1
            //  Efa noporofoinay fa samy <self.len() sy!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAFETY: mitovy amin'ny etsy ambony.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAFETY: &&faritra fohy, izay midika fa ao amin'ny
        //  fepetra faharoa dia efa marina io zaza==mifarana, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAFETY: ny zaza dia efa voaporofo fa index mety ary
            //  zaza==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Ny miantso dia tsy maintsy manome antoka fa `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAFETY: pos <len dia antoky ny miantso ary
        //  mazava ho azy Len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Makà singa iray ao amin'ny `pos` ary afindra hatreny ambanin'ilay antontam-bato, ary zahao hatrany amin'ny toerany.
    ///
    ///
    /// Note: Haingana kokoa izany rehefa fantatra fa lehibe/tokony ho manakaiky ny farany ambany ny singa.
    ///
    /// # Safety
    ///
    /// Ny miantso dia tsy maintsy manome antoka fa `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAFETY: Ny miantso dia manome antoka fa pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loar invariant: zaza==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SAFETY: zaza <faran'ny, 1 <self.len() ary
            //  zaza + 1 <faran'ny <= self.len(), noho izany dia index azo ampiasaina izy ireo.
            //  zaza==2 *hole.pos() + 1!= hole.pos() sy zaza + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 na 2* hole.pos() + 2 dia mety hisondrotra raha toa ka ZST ny T
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAFETY: Mitovy amin'ny etsy ambony ihany
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAFETY: zaza==faran'ny, 1 <self.len(), noho izany dia index mety
            //  ary ny zaza==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SAFETY: pos no toerana ao anaty lavaka ary efa voaporofo
        //  ho index mety.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAFETY: n manomboka amin'ny self.len()/2 ary midina hatramin'ny 0.
            //  Ny tranga tokana rehefa! (N <self.len()) dia raha self.len() ==0, fa ny fehin'ny loop no manapaka azy.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Mamindra ny singa `other` rehetra mankany `self`, mamela `other` foana.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` mandray ny fiasan'ny O(len1 + len2) ary ny fampitahana 2 *(len1 + len2) amin'ny tranga ratsy indrindra raha `extend` kosa mandray ny fiasan'ny O(len2* log(len1)) ary ny 1 *len2* log_2(len1) raha ampitahaina amin'ny tranga ratsy indrindra, mihevitra len1>= len2.
        // Ho an'ny korontam-bato lehibe kokoa, ny teboka crossover dia tsy manaraka an'io fanjohian-kevitra io intsony ary voafaritra mazava tsara.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Miverina iterator izay mamerina ireo singa milahatra.
    /// Ireo singa nalaina dia nesorina tamin'ny antontam-bato voalohany.
    /// Ireo singa sisa tavela dia hesorina amin'ny filatsahan'ny antontam-bato.
    ///
    /// Note:
    /// * `.drain_sorted()` dia *O*(*n*\*log(* n*)); miadana kokoa noho ny `.drain()`.
    ///   Tokony hampiasa an'ity farany ianao amin'ny ankamaroan'ny tranga.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // manala ny singa rehetra amin'ny filaharana antontam-bato
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Ireo singa notondroin'ny predicate ihany no tazonina.
    ///
    /// Raha atao teny hafa, esory ny singa `e` rehetra toy izany `f(&e)` mamerina `false`.
    /// Ireo singa dia tsidihina amin'ny filaharana tsy voasivana (sy tsy voafaritra).
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // isa fotsiny ihany no tazomy
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Miverina iterator mitsidika ny sanda rehetra ao amin'ny vector ambanin'ny tany, amina filaharana tsy aritra.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ataovy pirinty 1, 2, 3, 4 amin'ny filaharana tsy aritra
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Miverina iterator izay mamerina ireo singa milahatra.
    /// Ity fomba ity dia mandany ny antontam-bato tany am-boalohany.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Miverina ny entana lehibe indrindra amin'ny antontam-bolan'ny binary, na `None` raha foana izy.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Fahasarotan'ny fotoana
    ///
    /// Ny vidiny dia *O*(1) raha ratsy indrindra.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Miverina ny isan'ny singa azon'ny antontam-bato tsy tanterahina.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Mitahiry ny fahaiza-manao farafahakeliny ho an'ny singa `additional` misimisy kokoa hampidirina ao amin'ilay `BinaryHeap` nomena.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// Mariho fa ny mpizara dia mety hanome toerana betsaka kokoa noho ny angatahany.
    /// Noho izany ny fahaiza-manao dia tsy azo atokisana ho kely indrindra.
    /// Aleo [`reserve`] raha andrasana ny fampidirana future.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra `usize` ny fahafaha-manao vaovao.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Mitahiry fahaiza-manao farafahakeliny `additional` singa bebe kokoa hampidirina ao amin'ny `BinaryHeap`.
    /// Ny famoriam-bola dia mety hitahiry toerana bebe kokoa hisorohana ny fizahana toerana matetika.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra `usize` ny fahafaha-manao vaovao.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Ario araka izay azo atao ny fahafaha-manao fanampiny.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Manilika ny fahaizany miaraka amin'ny fatorana ambany.
    ///
    /// Ny fahaiza-manao dia hijanona farafahakeliny lehibe toy ny halavany sy ny sanda omena.
    ///
    ///
    /// Raha toa ka ambany noho ny fetra ambany ny fahafaha-miasa ankehitriny dia tsy misy izany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Manjifa ny `BinaryHeap` ary mamerina ny vector ao anaty baiko arakaraka.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Hanao pirinty amin'ny filaharana vitsivitsy
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Mamerina ny halavan'ny antontam-bato roa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Hamarino raha foana ny antontam-bato.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Manadio ny antontam-bolan'ny binary, mamerina iterator amin'ireo singa nesorina.
    ///
    /// Ireo singa dia nesorina tamina filaharana tsy nahy.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Mitete ny entana rehetra avy amin'ny antontam-bato.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Ny lavaka dia maneho lavaka ao anaty slice izany hoe index izay tsy misy sanda manan-kery (satria nesorina na naverina).
///
/// Ao anaty latsaka, `Hole` dia hamerina amin'ny laoniny ny silaka amin'ny famenoana ny toeran'ny lavaka amin'ny sanda nesorina voalohany.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Mamorona `Hole` vaovao amin'ny index `pos`.
    ///
    /// Tsy azo antoka satria ny pos dia tsy maintsy ao anatin'ny sombin-data.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: tokony ho ao anaty silaka ny pos
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Miverina referansa ny singa nesorina.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Miverina referansa ny singa amin'ny `index`.
    ///
    /// Tsy azo antoka satria ny index dia tsy maintsy ao anatin'ny slice data fa tsy mitovy amin'ny pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Mifindra lavaka mankany amin'ny toerana vaovao
    ///
    /// Tsy azo antoka satria ny index dia tsy maintsy ao anatin'ny slice data fa tsy mitovy amin'ny pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // fenoy indray ny lavaka
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Mpiverina amin'ny singa `BinaryHeap`.
///
/// Ity `struct` ity dia noforonin'i [`BinaryHeap::iter()`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Esory ho an'ny `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Manana iterator amin'ny singa `BinaryHeap`.
///
/// `struct` ity dia noforonin'i [`BinaryHeap::into_iter()`] (nomen'ny `IntoIterator` trait).
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Famerenana miverimberina amin'ny singa `BinaryHeap`.
///
/// Ity `struct` ity dia noforonin'i [`BinaryHeap::drain()`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Famerenana miverimberina amin'ny singa `BinaryHeap`.
///
/// Ity `struct` ity dia noforonin'i [`BinaryHeap::drain_sorted()`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Manala ireo singa antontam-bato amin'ny filaharana antontam-bato.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Manova `Vec<T>` ho `BinaryHeap<T>`.
    ///
    /// Ity fiovam-po ity dia mitranga eo amin'ny toerany ary manana fahasarotana amin'ny fotoana *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Manova `BinaryHeap<T>` ho `Vec<T>`.
    ///
    /// Ity fanovana ity dia tsy mila hetsika na fizarana data, ary manana fahasarotana ara-potoana tsy tapaka.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Mamorona iterator mandevona, izany hoe, iray izay mamindra ny sandany tsirairay avy ao amin'ilay antontam-bola mimari-droa amin'ny filaharana tsy aritra.
    /// Ny antontam-bola binary dia tsy azo ampiasaina aorian'ny fiantsoana an'io.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ataovy pirinty 1, 2, 3, 4 amin'ny filaharana tsy aritra
    /// for x in heap.into_iter() {
    ///     // x manana karazana i32 fa tsy &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}