use core::intrinsics;
use core::mem;
use core::ptr;

/// Manolo ny sanda ao ambadiky ny referansa tokana `v` amin'ny fiantsoana ny fiasa mifandraika amin'izany.
///
///
/// Raha misy panic mitranga amin'ny fanidiana `change` dia hesorina ny dingana iray manontolo.
#[allow(dead_code)] // tazomy ho toy ny fanoharana ary raha hampiasa future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Manolo ny sanda ao ambadiky ny referansa tokana `v` amin'ny fiantsoana ny fiasa mifandraika amin'izany, ary mamerina valiny azo teny an-dàlana.
///
///
/// Raha misy panic mitranga amin'ny fanidiana `change` dia hesorina ny dingana iray manontolo.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}