use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Fandraisana voafehy hotadiavina, toy ny `Bound::Included(T)` ihany.
    Included(T),
    /// Voafaritra hitady azy manokana, toy ny `Bound::Excluded(T)` ihany.
    Excluded(T),
    /// Fatorana mifandraika tsy misy fepetra, toy ny `Bound::Unbounded` ihany.
    AllIncluded,
    /// Fatorana manokana tsy misy fepetra.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Mitady lakile voatendry ao anaty hazo (zana) tarihin'ny node, miverina.
    /// Miverina `Found` miaraka amin'ny tanan'ny KV mifanentana, raha misy.
    /// Raha tsy izany dia avereno `GoDown` miaraka amin'ny tanan'ny ravina edge izay misy ny lakile.
    ///
    /// Ny valiny dia misy dikany raha tsy baikoin'ny lakile ny hazo, toy ny hazo ao amin'ny `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Midina any amin'ny teboka akaiky indrindra izay misy ny edge mifanitsy amin'ny faritry ny ambany ny sakany dia tsy mitovy amin'ny edge mifanitsy amin'ny fatorana ambony, izany hoe ilay node akaiky indrindra izay manana lakile iray farafahakeliny ao anatin'ilay faritra.
    ///
    ///
    /// Raha hita dia avereno `Ok` miaraka amin'io teboka io, ny indice ny edge ao aminy mametra ny elanelam-potoana, ary ny fehezan-dalàna mifandraika amin'izany amin'ny fanohizana ny fikarohana ao amin'ny zaza node, raha toa ka ao anatiny ilay node.
    ///
    /// Raha tsy hita dia avereno `Err` miaraka amin'ilay ravina edge mifanaraka amin'ny elanelany rehetra.
    ///
    /// Ny valiny dia misy dikany raha tsy baikoin'ny lakile ny hazo.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Ny fampidirana ireo fanovana ireo dia tokony hialana.
        // Mihevitra izahay fa ny fetra notaterin'ny `range` dia mijanona ho toy izany ihany, fa ny fampiharana ny fahavalo dia mety hiova eo anelanelan'ny antso (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Mahita edge ao amin'ny node mametra ny faran'ny ambany eo anelanelany.
    /// Avereno ihany koa ny fetra farany ambany hampiasaina hanohizana ny fikarohana ao amin'ilay node zaza mifanandrify aminy, raha i `self` dia teboka anatiny.
    ///
    ///
    /// Ny valiny dia misy dikany raha tsy baikoin'ny lakile ny hazo.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klone `find_lower_bound_edge` ho an'ny fetra ambony.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mitady lakile voatendry ao amin'ny node, tsy misy recursion.
    /// Miverina `Found` miaraka amin'ny tanan'ny KV mifanentana, raha misy.
    /// Raha tsy izany dia avereno `GoDown` miaraka amin'ny tantaran'ny edge izay mety hahitana ny lakile (raha ao anatiny ny node) na izay azo ampidirina ny lakile.
    ///
    ///
    /// Ny valiny dia misy dikany raha tsy baikoin'ny lakile ny hazo, toy ny hazo ao amin'ny `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Miverina na ny index KV ao amin'ny node izay misy ny lakile (na mitovy aminy), na ny index edge izay misy ny lakile.
    ///
    ///
    /// Ny valiny dia misy dikany raha tsy baikoin'ny lakile ny hazo, toy ny hazo ao amin'ny `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Mahita index edge ao amin'ny node mametra ny faran'ny ambany eo anelanelany.
    /// Avereno ihany koa ny fetra farany ambany hampiasaina hanohizana ny fikarohana ao amin'ilay node zaza mifanandrify aminy, raha i `self` dia teboka anatiny.
    ///
    ///
    /// Ny valiny dia misy dikany raha tsy baikoin'ny lakile ny hazo.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klone `find_lower_bound_index` ho an'ny fetra ambony.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}