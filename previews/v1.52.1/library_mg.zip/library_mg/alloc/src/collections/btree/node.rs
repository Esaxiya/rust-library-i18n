// Ity dia fanandramana amin'ny fampiharana manaraka ny idealy
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Satria ny Rust dia tsy manana karazana miankina sy recursion polymorphic, dia manao izay tsy hampilamina isika.
//

// Tanjona lehibe an'ity modely ity ny hisorohana ny fahasarotana amin'ny alàlan'ny fitsaboana ny hazo toy ny fitoeram-bolo (raha miendrika hafahafa) ary hisorohana ny fifandraisan'ny ankamaroan'ireo invariants B-Tree.
//
// Raha izany dia tsy raharahain'ity maodely ity na voasokajy ny fampidirana, izay node no mety ho ambanin-javatra, na koa ny dikan'ny hoe underfull.Na izany aza, miantehitra amin'ny mpanasa vitsivitsy izahay:
//
// - Ny hazo dia tokony hanana depth/height fanamiana.Midika izany fa ny lalana rehetra mankany amin'ny ravina iray amin'ny node iray dia mitovy ny halavany.
// - Ny teboka lava `n` dia misy lakile `n`, sanda `n`, ary sisiny `n + 1`.
//   Midika izany fa na ny teboka poakaty aza dia manana edge farafaharatsiny.
//   Ho an'ny teboka ravina, "having an edge" dia midika fotsiny fa afaka mamantatra toerana iray ao amin'ny node isika, satria foana ny sisin'ny ravina ary tsy mila fanehoana data.
// Ao amin'ny teboka anatiny, ny edge dia samy mamaritra ny toerana misy azy ary misy mpanondro ny tadin'ny zaza.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Ny fanehoana ifotony an'ireo teboka ravina ary ampahany amin'ny fanehoana ireo teboka anatiny.
struct LeafNode<K, V> {
    /// Tianay ny ho covariant amin'ny `K` sy `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Ity index node ity dia ao amin'ny laharana `edges` an'ny node's parent node.
    /// `*node.parent.edges[node.parent_idx]` dia tokony hitovy amin'ny `node`.
    /// Ity dia azo antoka ihany fa hatao voaloham-bokatra rehefa X-`parent` tsy misy fanafoanana.
    parent_idx: MaybeUninit<u16>,

    /// Ny isan'ny fanalahidy sy sanda itobiana an'ity node ity.
    len: u16,

    /// Ireo arrays mitahiry ny tena angon-drakitra ny node.
    /// Ny singa `len` voalohany amin'ny laharana tsirairay ihany no voaloham-bokatra sy mitombina.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Manomboka `LeafNode` vaovao amin'ny toerany.
    unsafe fn init(this: *mut Self) {
        // Amin'ny maha politika ankapobeny antsika dia avelantsika tsy misy idiran'ny sehatra ny saha raha misy izany, satria tokony ho somary haingana kokoa sy mora kokoa ny manara-dia an'i Valgrind.
        //
        unsafe {
            // parent_idx, lakile, ary vals dia angambaUninit daholo
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Mamorona `LeafNode` boaty vaovao.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ny fanehoana ifotony ireo node anatiny.Toy ny amin'ny "LeafNode`s, ireo dia tokony hafenina ao ambadiky ny"BoxedNode`s hisorohana ny fandatsahana lakile sy soatoavina tsy voafaritra.
/// Ny tondro rehetra amin'ny `InternalNode` dia azo atsipy mivantana amin'ny tondro any amin'ilay ampahany `LeafNode` ambanin'ny node, mamela ny kaody hiasa amin'ny teboka ravina sy ao anatiny amin'ny ankapobeny nefa tsy mila manamarina akory hoe iza amin'ireo no tondroin'izy ireo.
///
/// Ity trano ity dia azo ampiasaina amin'ny alàlan'ny fampiasana `repr(C)`.
///
#[repr(C)]
// gdb_providers.py mampiasa an'ity karazana anarana ity ho an'ny fitsirihana.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ny tondro dia ny zanaky io node io.
    /// `len + 1` Ny iray amin'ireny dia heverina ho voaloham-bokatra sy manan-kery, afa-tsy ny amin'ny faran'ny farany, raha ny hazo dia mitazona amin'ny endrika `Dying` indramina, ny sasany amin'ireo tondro ireo dia mihantona.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Mamorona `InternalNode` boaty vaovao.
    ///
    /// # Safety
    /// Ny invariant ny nodes anatiny dia ny manana edge farafaharatsiny farafaharatsiny.
    /// Ity fiasa ity dia tsy mametraka edge toy izany.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Ny data fotsiny no mila ataontsika;ny sisiny dia angambaUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Toro-làlana tsy azo ovaina amin'ny node.Izy io dia mety ho tondro fananana mankany `LeafNode<K, V>` na tondro any `InternalNode<K, V>`.
///
/// Na izany aza, ny `BoxedNode` dia tsy misy fampahalalana hoe iza amin'ireo karazana node roa no tena misy ao aminy, ary, ampahany noho io tsy fahampian'ny fampahalalana io, dia tsy karazana misaraka ary tsy misy mpanimba.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ny fototry ny hazo fananana.
///
/// Mariho fa tsy manana mpanimba izany, ary tsy maintsy diovina amin'ny tanana.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Miverina hazo vaovao fananana, miaraka amina fotony misy ny fotony izay foana foana.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` tsy tokony ho aotra.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Azo ampindramina mindrana ilay vodin-kazo fananana.
    /// Tsy toy ny `reborrow_mut`, ity dia azo antoka satria ny sanda miverina dia tsy azo ampiasaina hanimbana ny faka, ary tsy misy fanondroana hafa momba ilay hazo.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Somary azo ovaina ny mindrana ilay vodin-kazo fananana.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Famindrana tsy azo ihodivirana amin'ny fanovozan-kevitra mamela ny fifamoivoizana ary manolotra fomba manimba ary zavatra hafa kely.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Manampy node anatiny vaovao miaraka amina edge tokana manondro ilay vodin-tsavony teo aloha, ataovy io node vaovao io ilay root node, ary avereno izany.
    /// Mampitombo ny haavon'ny 1 ary mifanohitra amin'ny `pop_internal_level` izany.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, afa-tsy hoe nanadino fotsiny isika fa ao anaty izao:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Esorina ny node root internal, ampiasao ny zanany voalohany ho lasa root root vaovao.
    /// Satria natao hantsoina fotsiny izy io raha toa ka tokana ny zanaka node, dia tsy misy fanadiovana atao amin'ireo lakile, soatoavina ary ankizy hafa.
    ///
    /// Izany dia mampihena ny haavon'ny 1 ary mifanohitra amin'ny `push_internal_level`.
    ///
    /// Mitaky fidirana manokana amin'ny zavatra `Root` fa tsy mankany amin'ny root node;
    /// tsy hanafoana ny fikirakirana hafa na ny fanondroana ilay teboka faka io.
    ///
    /// Panics raha tsy misy ambaratonga anatiny, izany hoe raha ravina ny fotony.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SAFETY: nanamafy izahay fa anatiny.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SAFETY: nindrana `self` manokana izahay ary ny karazany indramina dia tsy miankina.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SAFETY: ny edge voalohany dia hatrany am-boalohany.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` dia covariant foana amin'ny `K` sy `V`, na dia `Mut` aza ny `BorrowType`.
// Diso ara-teknika izany fa tsy mety hiteraka tsy fandriam-pahalemana noho ny fampiasana `NodeRef` anatiny satria mijanona ho generika tanteraka mihoatra ny `K` sy `V` isika.
//
// Na izany aza, isaky ny karazam-bahoaka manosotra `NodeRef` dia alao antoka fa manana ny tsy fitovizany marina izy.
//
/// Fanondroana teboka.
///
/// Ity karazana ity dia manana masontsivana maromaro izay mifehy ny fomba fiheviny:
/// - `BorrowType`: Karazana dummy izay mamaritra ny karazana mindrana ary mitondra androm-piainany.
///    - Rehefa `Immut<'a>` ity dia mihetsika sahala amin'ny `&'a Node` ny `NodeRef`.
///    - Rehefa `ValMut<'a>` ity, ny `NodeRef` dia mihetsika sahala amin'ny `&'a Node` mikasika ny fanalahidy sy ny firafitry ny hazo, fa mamela ihany koa ireo fanondroana mutable maro momba ny soatoavina manerana ny hazo hiara-monina.
///    - Rehefa `Mut<'a>` ity, ny `NodeRef` dia mihetsika sahala amin'ny `&'a mut Node`, na dia ny fomba fampidirana aza dia mamela ny tondro azo ovaina ho soatoavina miaraka.
///    - Rehefa `Owned` ity dia mihetsika sahala amin'ny `Box<Node>` ny `NodeRef`, saingy tsy manana mpanimba, ary tsy maintsy diovina amin'ny tanana.
///    - Rehefa `Dying` ity, ny `NodeRef` dia mbola mihetsika sahala amin'ny `Box<Node>`, saingy manana fomba hanapotehana tsikelikely ilay hazo, ary ny fomba mahazatra, na dia tsy voamarika aza hoe tsy azo antoka hantsoina, dia afaka miantso ny UB raha diso ny fiantsoana azy.
///
///   Satria misy `NodeRef` mamela ny fitetezana ny hazo, `BorrowType` dia mihatra amin'ny hazo iray manontolo fa tsy amin'ny node fotsiny.
/// - `K` ary `V`: Ireo no karazana fanalahidy sy sanda voatahiry ao amin'ireo node.
/// - `Type`: Mety ho `Leaf`, `Internal`, na `LeafOrInternal` ity.
/// Rehefa `Leaf` ity dia manondro teboka ravina ny `NodeRef`, raha `Internal` ity dia manondro teboka anatiny ny `NodeRef`, ary raha `LeafOrInternal` ity dia mety manondro karazana node ny `NodeRef`.
///   `Type` antsoina hoe `NodeType` rehefa ampiasaina ivelan'ny `NodeRef`.
///
/// Ny `BorrowType` sy `NodeType` dia mametra izay fomba ampiharintsika, hitrandrahana ny fiarovana ny karazana statika.Misy fetrany ny fomba ahafahantsika mampihatra fameperana toy izany:
/// - Isaky ny masontsivana isan-karazany dia tsy misy afa-tsy amin'ny fomba mahazatra na amin'ny karazana iray manokana no ahafahantsika mamaritra.
/// Ohatra, tsy azonay atao ny mamaritra ny fomba toy ny `into_kv` amin'ny ankapobeny ho an'ny `BorrowType` rehetra, na indray mandeha ho an'ny karazana rehetra izay mitondra mandritra ny androm-piainana, satria tianay ny hamerenany ireo referansa `&'a`.
///   Noho izany dia faritanay ho an'ny karazana `Immut<'a>` kely matanjaka indrindra ihany izany.
/// - Tsy afaka mahazo teritery implicit isika raha miteny hoe `Mut<'a>` ka hatramin'ny `Immut<'a>`.
///   Noho izany, tsy maintsy miantso an-kolaka ny `reborrow` amin'ny `NodeRef` mahery kokoa isika mba hahatratrarana fomba iray toa ny `into_kv`.
///
/// Ny fomba rehetra amin'ny `NodeRef` izay mamerina karazana fanovozan-kevitra, na:
/// - Raiso ny sanda `self` ary avereno ny androm-piainana entin'i `BorrowType`.
///   Indraindray, raha hampiasa fomba toy izany dia mila miantso `reborrow_mut` isika.
/// - Raiso `self` amin'ny alàlan'ny referansa, ary avereno (implicitly) ny androm-piainan'io referansa io, fa tsy ny androm-piainana entin'i `BorrowType`.
/// Amin'izany fomba izany, ny mpanamarina findramam-bola dia manome antoka fa ny `NodeRef` dia mitrosa hatrany raha mbola ampiasaina ny referansa niverina.
///   Ny fomba manohana ny sisin-tsoroka dia aorin'ity fitsipika ity amin'ny alàlan'ny famerenana tondro iray manta, izany hoe, referansa tsy misy androm-piainany.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Ny isan'ny ambaratonga izay ananan'ny node sy ny haavon'ny ravina dia mitohy, tsy miovaova ilay node izay tsy afaka faritan'ny `Type` tanteraka, ary ilay node dia tsy mitahiry.
    /// Mila mitazona ny haavon'ny node root fotsiny isika, ary mahazo ny haavon'ny node hafa rehetra avy eo.
    /// Tsy maintsy aotra raha `Type` dia `Leaf` ary tsy aotra raha `Type` dia `Internal`.
    ///
    ///
    height: usize,
    /// Ny tondro any amin'ny ravina na ny vona anatiny.
    /// Ny famaritana ny `InternalNode` dia miantoka fa ny tondro dia mitombina na amin'ny fomba ahoana.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Vahao ny referansa node izay nofonosina ho `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Mampiharihary ny angon-drakitra node anatiny.
    ///
    /// Miverina ptr manta mba hialana amin'ny fanafoanana ireo fanondroana hafa momba ity node ity.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SAFETY: ny karazana node static dia `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Mindrana fidirana manokana amin'ny angon-drakitra node anatiny.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mahita ny halavan'ny node.Io no isan'ny lakile na sanda.
    /// Ny isan'ireo sisiny dia `len() + 1`.
    /// Mariho fa, na eo aza ny maha-azo antoka azy, ny fiantsoana an'io fiasa io dia mety hisy fiatraikany amin'ny fanesorana ireo fiovana miovaova izay noforonina kaody tsy azo antoka.
    ///
    pub fn len(&self) -> usize {
        // Zava-dehibe dia tsy miditra amin'ny saha `len` fotsiny isika eto.
        // Raha marker::ValMut ny BorrowType dia mety misy fanondroana miavaka azo ovaina amin'ny sanda izay tsy tokony hofoananay.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Mamerina ny isan'ny ambaratonga izay misaraka ny tampona sy ny ravina.
    /// Ny haavon'ny zero dia midika hoe ravina ny node.
    /// Raha sary ny hazo misy fotony eo amboniny dia milaza ilay isa hoe amin'ny toerana aiza no hisehoan'ny tampona.
    /// Raha sary ny hazo misy ravina eo amboniny, dia milaza ny isa hoe maninona ny haavon'ny hazo no miitatra ambonin'ny tampona.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Mamoaka vonjimaika iray hafa ilay teboka iray ihany, vetivety.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mampiharihary ny ampahan'ny ravina na ravina anatiny.
    ///
    /// Miverina ptr manta mba hialana amin'ny fanafoanana ireo fanondroana hafa momba ity node ity.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Ny node dia tsy maintsy mitombina farafaharatsiny amin'ny ampahany LeafNode.
        // Tsy referansa amin'ny karazana NodeRef ity satria tsy fantatray raha tokony ho tokana na zaraina izany.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Mahita ny ray aman-drenin'ny teboka ankehitriny.
    /// Miverina `Ok(handle)` raha toa ka manana ray aman-dreny ny teboka ankehitriny, izay manondro ny X0edge0Z an'ny ray aman-dreny izay manondro ny teboka ankehitriny ny `handle`.
    ///
    /// Miverina `Err(self)` raha toa ka tsy manana ray aman-dreny ilay node amin'izao fotoana izao, mamerina ilay `NodeRef` tany am-boalohany.
    ///
    /// Ny anaran'ny fomba dia mihevitra anao hazo sary misy fakan-kazo eo amboniny.
    ///
    /// `edge.descend().ascend().unwrap()` ary `node.ascend().unwrap().descend()` dia samy tokony hanao na inona na inona, rehefa tafita.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mila mampiasa tondro manta amin'ny teboka isika satria, raha BorrowType dia marker::ValMut, dia mety misy andinin-tsoratra miavaka azo ovaina amin'ny soatoavina izay tsy tokony hofoananay.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Mariho fa `self` dia tsy maintsy atao ho nonempty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Mariho fa `self` dia tsy maintsy atao ho nonempty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Aharihary amin'ny ampahany amin'ny ravina na ravina anatiny ao anaty hazo tsy miova.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAFETY: mety tsy misy fanovana azo ovaina amin'ity hazo nindramina `Immut` ity.
        unsafe { &*ptr }
    }

    /// Mampindrana fijery amin'ny lakile voatahiry ao amin'ny node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Mitovy amin'ny `ascend`, mahazo referansa node's node's node, nefa koa manadino ny node amin'izao fotoana izao ao amin'ilay dingana.
    /// Tsy azo antoka izany satria mbola azo idirana ny node ankehitriny na eo aza ny fifampiraharahana.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Manamafy tsy misy antoka amin'ny mpamorona ny fampahalalana miorim-paka fa io node io dia `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Manamafy tsy misy antoka amin'ny mpamorona ny fampahalalana miorim-paka fa io node io dia `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Mamoaka vonjimaika ilay node hafa iray vetivety.Tandremo, araka ny fomba fiasa ity dia tena mampidi-doza, avo roa heny izany satria mety tsy hiseho avy hatrany mampidi-doza.
    ///
    /// Noho ny tondro azo ovaina dia afaka mivezivezy eny rehetra eny amin'ny hazo, ny tondro miverina dia azo ampiasaina mora foana mba hanantona ilay tondro tany am-boalohany, tsy voafetra, na tsy mety amin'ny lalàna mifehy nindramina.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) diniho ny fanampiana parameter hafa karazana amin'ny `NodeRef` izay mametra ny fampiasana fomba fitetezana ireo tondro nindramina, hisorohana an'io tsy fandriam-pahalemana io.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Mindrana fidirana manokana amin'ny ampahan'ny ravina misy ravina na vona anatiny.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAFETY: manana fidirana manokana amin'ny node iray manontolo isika.
        unsafe { &mut *ptr }
    }

    /// Manolotra fidirana manokana amin'ny ampahany amin'ny ravina misy ravina na vona anatiny.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAFETY: manana fidirana manokana amin'ny node iray manontolo isika.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Mindrana fidirana manokana amin'ny singa iray amin'ny faritra fitehirizana lehibe.
    ///
    /// # Safety
    /// `index` dia fehezin'ny 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SAFETY: ny mpiantso dia tsy afaka miantso fomba hafa samirery
        // mandra-pijanonan'ny referansa slice fototra, satria manana fidirana tsy manam-paharoa mandritra ny androm-bola indramina isika.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Mindrana fidirana manokana mankany amina singa na sombin-tsiran'ny faritra fitehirizan'ilay node.
    ///
    /// # Safety
    /// `index` dia fehezin'ny 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SAFETY: ny mpiantso dia tsy afaka miantso fomba hafa samirery
        // mandra-pijanonan'ny referansa sombin-danja, satria manana fidirana tsy manam-paharoa mandritra ny androm-bola indramina isika.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Mindrana fidirana manokana mankany amina singa na sombin-kazo fitehirizana node ho an'ny atiny edge.
    ///
    /// # Safety
    /// `index` dia fehezin'ny 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SAFETY: ny mpiantso dia tsy afaka miantso fomba hafa samirery
        // mandra-pijanonan'ny referansa edge slice, satria manana fidirana tsy manam-paharoa mandritra ny androm-bola indramina isika.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Ny node dia manana singa mihoatra ny `idx` voalohany.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Izahay dia mamorona fanondroana singa iray izay mahaliana anay ihany, mba tsy hialana amin'ny alàlan'ny fanamarihana miavaka amin'ireo singa hafa, indrindra ireo izay niverina tany am-piantsoana tamin'ny famerimberenana teo aloha.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Tsy maintsy manery ireo tondro tsy voamarina isika noho ny laharana Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Mindrana fidirana manokana amin'ny halavan'ny node.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Mametraka ny rohin'ilay node mankany amin'ny edge reniny, nefa tsy manadino ireo fanondroana hafa momba ilay node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Manadio ny rohy fakany mankany amin'ny edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Manampy mpivady manan-danja amin'ny faran'ny node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ny entana rehetra naverin'i `range` dia index edge manan-kery ho an'ny node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Manampy mpivady manan-danja, ary edge handeha eo ankavanan'io mpivady io, any amin'ny faran'ny node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Manamarina raha node dia teboka `Internal` na teboka `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Fanondroana mpivady sanda manan-danja manokana na edge ao anatin'ny node.
/// Ny masontsivana `Node` dia tsy maintsy ho `NodeRef`, raha `Type` kosa dia mety ho `KV` (manondro ny tahony amin'ny mpivady manan-danja) na `Edge` (manondro ny tahony amin'ny edge).
///
/// Mariho fa na ny teboka `Leaf` aza dia mety manana tahony `Edge`.
/// Raha tokony hisolo tena ny tondro any amin'ny vodin-jaza izy ireo, ireo kosa dia maneho ireo toerana halehan'ny tondro ho an'ny ankizy eo anelanelan'ny mpivady manan-danja.
/// Ohatra, amin'ny teboka manana halavana 2, dia mety hisy toerana 3 mety ho edge, iray eo ankavanan'ny node, iray eo anelanelan'ny tsiroaroa, ary ny iray eo ankavanan'ny node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Tsy mila ny ankapobeny `#[derive(Clone)]`, satria ny fotoana tokana `Node` dia ho `Clone`able dia rehefa tsy azo ovaina ny referansa ary noho izany `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Averina ny node izay misy ny edge na ny valiny manan-danja izay tondroin'ity tahiry ity.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Miverina ny toeran'ny tahony io ao amin'ny node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Mamorona tahony vaovao amin'ny mpivady manan-danja ao amin'ny `node`.
    /// Tsy azo antoka satria ny miantso dia tsy maintsy miantoka fa `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Mety ho fampiharana ampahibemaso an'ny PartialEq, saingy amin'ity modely ity ihany no ampiasaina.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Mamoaka vonjimaika iray hafa, tsy miova, amin'ny toerana iray ihany, ny vonjimaika.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Tsy afaka mampiasa Handle::new_kv na Handle::new_edge izahay satria tsy fantatray ny karazany
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Tsy azo antoka ny manamafy amin'ny mpamorona ny fampahalalana miorim-paka fa X-`Leaf`-node ny fonony.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Mamoaka vonjimaika iray hafa, miova amin'ny toerana iray ihany, vetivety.
    /// Mitandrema, satria mampidi-doza ity fomba ity, avo roa heny noho izany satria mety tsy hiseho loza avy hatrany izy io.
    ///
    ///
    /// Raha mila tsipiriany, jereo `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Tsy afaka mampiasa Handle::new_kv na Handle::new_edge izahay satria tsy fantatray ny karazany
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Mamorona tahony vaovao amin'ny edge ao amin'ny `node`.
    /// Tsy azo antoka satria ny miantso dia tsy maintsy miantoka fa `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Raha omena index edge izay te-hiditra ao anaty node feno fahafaha-manao, dia manisa ny index KV azo tsapain-tanana amin'ny teboka mizara sy ny toerana hanaovana ilay fampidirana.
///
/// Ny tanjon'ny teboka mizara dia ny hiafarany ao amin'ny vona ray aman-dreny ny lakile sy ny sandany;
/// ny lakile, ny sanda ary ny sisiny ankavia amin'ny teboka misaraka dia lasa ilay zaza ankavia;
/// ny lakile, ny sanda ary ny sisiny ankavanan'ny teboka misaraka dia lasa zaza mety.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Ny olana Rust #74834 dia manandrana manazava ireo fitsipika simetrika ireo.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mampiditra mpivady sanda manan-danja vaovao eo anelanelan'ny mpivady sanda manan-danja eo ankavanana sy ankavia amin'ity edge ity.
    /// Ity fomba ity dia mihevitra fa misy toerana malalaka ao amin'ny node hahafahan'ny mpivady vaovao miditra.
    ///
    /// Ny tondro nanondro dia nanondro ny sanda napetraka.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mampiditra mpivady sanda manan-danja vaovao eo anelanelan'ny mpivady sanda manan-danja eo ankavanana sy ankavia amin'ity edge ity.
    /// Ity fomba ity dia mampisaraka ny vona raha tsy ampy ny efitrano.
    ///
    /// Ny tondro nanondro dia nanondro ny sanda napetraka.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Amboary ny pointer sy index an'ny ray aman-dreny ao amin'ny tadin'ny zaza izay ampifandraisin'ity edge ity.
    /// Ilaina izany rehefa novaina ny filaharany ny sisiny,
    fn correct_parent_link(self) {
        // Mamorona backpointer nefa tsy manadino ireo fanondroana hafa momba ilay node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Mampiditra mpivady sanda manan-danja vaovao sy edge izay handeha eo ankavanan'ny mpivady vaovao eo anelanelan'ny edge sy ny mpivady manan-danja eo ankavanan'ity edge ity.
    /// Ity fomba ity dia mihevitra fa misy toerana malalaka ao amin'ny node hahafahan'ny mpivady vaovao miditra.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Mampiditra mpivady sanda manan-danja vaovao sy edge izay handeha eo ankavanan'ny mpivady vaovao eo anelanelan'ny edge sy ny mpivady manan-danja eo ankavanan'ity edge ity.
    /// Ity fomba ity dia mampisaraka ny vona raha tsy ampy ny efitrano.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Mampiditra mpivady sanda manan-danja vaovao eo anelanelan'ny mpivady sanda manan-danja eo ankavanana sy ankavia amin'ity edge ity.
    /// Ity fomba ity dia mampisaraka ny fipetrahana raha tsy ampy ny efitrano, ary manandrana mampiditra ny ampahany mizara ao amin'ilay vody ray aman-dreny mandra-pahatongan'ny fakany.
    ///
    ///
    /// Raha `Fit` ny valiny naverina, dia mety ho io nosy edge io no razambe na razambe iray.
    /// Raha `Split` ny valiny niverina, ny saha `left` no ho root node.
    /// Ny tondro nanondro dia nanondro ny sanda napetraka.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Mahita ilay node tondroin'ity edge ity.
    ///
    /// Ny anaran'ny fomba dia mihevitra anao hazo sary misy fakan-kazo eo amboniny.
    ///
    /// `edge.descend().ascend().unwrap()` ary `node.ascend().unwrap().descend()` dia samy tokony hanao na inona na inona, rehefa tafita.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mila mampiasa tondro manta amin'ny teboka isika satria, raha BorrowType dia marker::ValMut, dia mety misy andinin-tsoratra miavaka azo ovaina amin'ny soatoavina izay tsy tokony hofoananay.
        // Tsy misy ahiahy ny miditra amin'ny sehatra avo satria kopia io sanda io.
        // Tandremo fa raha vantany vao voadidy ny teboka node dia miditra amin'ny sisin'ny sisiny isika miaraka amin'ny referansa (Rust nomerao #73987) ary manafoana ireo fanondroana hafa momba na ao anaty ny laharana, raha tokony hisy.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Tsy afaka miantso fomba fanalahidy sy sanda misaraka izahay, satria ny fiantsoana ny faharoa dia manala ny referansa naverin'ilay voalohany.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Soloy ny lakile sy ny sanda izay tondroin'ny kV KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Manampy amin'ny fampiharana ny `split` ho an'ny `NodeType` manokana, amin'ny fikarakarana ny angon-drakitra.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Mamaky ny node fototra ho telo toko:
    ///
    /// - Ny node dia notapahina mba tsy hahitana afa-tsy ireo tsiro-sandan'ny key eo ankavia amin'ity fantsona ity.
    /// - Ny lakile sy ny sanda tondroin'ity tahony ity dia alaina.
    /// - Ny tsiro-bidy rehetra eo an-kavanan'ity tsorakazo ity dia atsofoka ao anaty vona vao natokana.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Esorina ny mpivady manan-danja izay tondroin'ity tahony ity ary averiny, miaraka amin'ny edge izay nianjeran'ilay mpivady manan-danja.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Mamaky ny node fototra ho telo toko:
    ///
    /// - Ny node dia notapahina mba tsy hahitana afa-tsy ny sisiny sy ny tsindry valiny manan-danja eo ankavia amin'ity fantsona ity.
    /// - Ny lakile sy ny sanda tondroin'ity tahony ity dia alaina.
    /// - Ny sisiny rehetra sy ny mpivady manan-danja eo ankavanan'ity tahony ity dia atsofoka ao amin'ny node vao natokana.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Maneho fivoriana iray hanombanana sy hanaovana asa fandanjalanjana manodidina ny mpivady manan-danja manan-danja.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Misafidy fifandanjana mifandanja misy ilay teboka amin'ny maha-zaza azy, ka eo anelanelan'ny KV avy hatrany amin'ny ankavia na amin'ny ankavanana ao amin'ny node parent.
    /// Miverina `Err` raha tsy misy ray aman-dreny.
    /// Panics raha foana ny ray aman-dreny.
    ///
    /// Aleo ny ilany havia, ho tonga lafatra raha toa ka tsy dia misy dikany ilay node nomena, midika izany eto fa kely kokoa noho ny iray tampo aminy sy ny iray tampo aminy raha toa misy izy ireo.
    /// Raha izany no izy, dia haingana kokoa ny fampitambarana ny iray tam-po aminy havia, satria ny singa N an'ny node ihany no mila afindra, fa tsy ny mamindra azy ireo ho any ankavanana ary mihetsika mihoatra ny singa N eo aloha.
    /// Ny mangalatra ny iray tampo amin'ny iray tampo aminy dia matetika kokoa ihany koa satria isika ihany no mila mamindra ny singa N ao ankavanan'ny node, fa tsy manova ny elakelaky ny elan'ny iray tam-po aminy miankavia.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Miverina raha azo atao ny mampitambatra, izany hoe raha misy efitrano ampy ao anaty teboka iray hanambatra ny KV afovoany miaraka amin'ireo teboka zaza mifanila aminy.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Manao merge ary mamela ny fanidiana hanapa-kevitra izay hiverina.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAFETY: ny haavon'ny teboka atambatra dia iray ambanin'ny hahavony
                // ny node an'ity edge ity, ambonin'ny zero, ka ao anatiny izy ireo.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Mampifangaro ny mpivady manan-danja sy ny vodin-jaza mifanakaiky ao amin'ilay vinan-jaza ankavia ary mamerina ilay vodin'ny ray aman-dreny mihena.
    ///
    ///
    /// Panics raha tsy hoe `.can_merge()` izahay.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ampangaroharo ny vady manan-danja sy ny vavan'ny zaza mifanakaiky ao amin'ilay node zaza havia ary averiny ilay node-jaza.
    ///
    ///
    /// Panics raha tsy hoe `.can_merge()` izahay.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ampangaroharo ny vady manan-danja sy ny vavan'ny zaza mifanakaiky ao amin'ilay node zaza havia ary mamerina ny fehin-tànana edge ao amin'ilay valan-jaza izay niafaran'ilay zaza edge voasoratra,
    ///
    ///
    /// Panics raha tsy hoe `.can_merge()` izahay.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Manala ny mpivady sanda manan-danja amin'ilay zaza ankavia ary mametraka azy ao amin'ny fitehirizan-tsarobidin'ny ray aman-dreny, ary manosika ilay mpivady soatoavina manan-danja ho an'ny zaza havanana.
    ///
    /// Miverina fihazonana amin'ny edge amin'ny zaza havanana mifanaraka amin'ny toerana niafaran'ny edge voalohany nofaritan'i `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Manala mpivady sanda manan-danja amin'ny zaza ankavanana ary mametraka azy ao amin'ny fitehirizan-tsarobidin'ny ray aman-dreny, ary manosika ilay mpivady sanda manan-danja taloha ho an'ny zaza havia.
    ///
    /// Miverina tahony amin'ny edge ao amin'ilay zaza havia notondroin'ny `track_left_edge_idx`, izay tsy nihetsika.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Izany dia mangalatra mitovy amin'ny `steal_left` fa mangalatra singa maromaro indray mandeha.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Hamarino tsara fa afaka mangalatra soa aman-tsara isika.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mifindra angona ravina.
            {
                // Manomeza efitrano halatra ho an'ny zaza mety.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Afindra ny singa ankavia mankany amin'ny iray mahitsy.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Afindra amin'ny ray aman-dreny ilay mpivady ankavia indrindra.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Afindrao amin'ilay zaza mahitsy ny vady sahaza ny ray aman-dreny.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Manamboara toerana ho an'ny sisin'ny halatra.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Sisiny mangalatra.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Ny clone symmetric an'ny `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Hamarino tsara fa afaka mangalatra soa aman-tsara isika.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mifindra angona ravina.
            {
                // Afindra amin'ny ray aman-dreny ilay mpivady tena ankavanana.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Afindra amin'ilay zaza ankavia ny mpivady manan-danja lanjaina.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Afindra ny singa ankavanana mankany amin'ny ankavia.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Fenoy ny elanelana nisy ireo singa nangalarina.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Sisiny mangalatra.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Fenoy ny elanelana nisy ny sisin'ny halatra taloha.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Manala ireo fampahalalana miorina izay manamafy fa io node io dia teboka `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Manala ireo fampahalalana miorim-paka milaza fa io node io dia teboka `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Hamarino raha teboka `Internal` na teboka `Leaf` ny node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Afindra ny tohatra aorian'ny `self` avy amin'ny teboka iray mankany amin'ny iray hafa.`right` dia tokony ho foana.
    /// Ny edge voalohany an'ny `right` dia mijanona tsy miova.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Vokatry ny fampidirana, raha mila node hanitatra mihoatra ny fahaizany.
pub struct SplitResult<'a, K, V, NodeType> {
    // Node niova tamin'ny hazo efa misy misy singa sy sisiny izay an'ny ankavia `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Nisaraka ny lakile sy ny sandany sasany, hapetraka any an-kafa.
    pub kv: (K, V),
    // Node vaovao tsy misy ifandraisany sy mifamatotra, misy singa sy sisiny izay an'ny zon'ny `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Na ny referansa node amin'ity karazana findramam-bola ity dia mamela ny fivezivezena any amin'ny teboka hafa ao amin'ilay hazo.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Tsy ilaina ny traversal, mitranga amin'ny fampiasana ny valin'ny `borrow_mut`.
        // Amin'ny alàlan'ny fampandehanana ny fifamoivoizana, ary ny famoronana referansa vaovao fotsiny amin'ny faka, dia fantatsika fa ny referansa rehetra amin'ny karazana `Owned` dia mankany amin'ny vona-paka.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Atsofohy ao anaty sombin-javatra voajanahary ny sanda iray aorian'izay singa iray tsy voatanisa.
///
/// # Safety
/// Ny singa dia manana singa mihoatra ny `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Manala sy mamerina sanda avy amina sombin-javatra rehetra natomboka, ka mamela singa iray mbola tsy voadinika.
///
///
/// # Safety
/// Ny singa dia manana singa mihoatra ny `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Avadiho ireo singa ao anaty tsanganana `distance` avia ankavia.
///
/// # Safety
/// Ny slice dia manana singa `distance` farafaharatsiny.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Amboary ireo singa ao anaty tsanganana `distance` atsimo.
///
/// # Safety
/// Ny slice dia manana singa `distance` farafaharatsiny.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Mamindra ny sanda rehetra avy amin'ny sombin'ireo singa namboarina ho amin'ny sombin-javatra tsy voatanisa, mamela ny `src` ho uninitialized rehetra.
///
/// Miasa toy ny `dst.copy_from_slice(src)` fa tsy mila `T` ho `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;