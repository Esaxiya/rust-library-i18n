use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Ampiarahina ireo tsiroaroa-danja rehetra avy amin'ny firaisan'ny iterator miakatra roa, mampitombo ny fari-`length` eny an-dalana.Ity farany dia manamora ny fampiasan'ny mpiantso ny fivoahan'ny rano rehefa mikoropaka ny mpikarakara.
    ///
    /// Raha samy mamoaka fanalahidy mitovy ny iteratera roa, ity fomba ity dia mandatsaka ny mpivady avy amin'ilay iterator havia ary manampy ny mpivady avy amin'ilay iterator havanana.
    ///
    /// Raha tianao ny hiafaran'ilay hazo amin'ny filaharana miakatra mafy, toy ny `BTreeMap`, dia tokony hamoaka lakilema miakatra mafy ny hazo iteratera roa tonta, lehibe kokoa noho ny lakile rehetra ao anaty hazo, ao anatin'izany ny lakile rehetra efa tafiditra ao amin'ilay hazo rehefa tafiditra.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Miomana izahay hampitambatra ny `left` sy `right` ho filaharana milahatra amin'ny fotoana tsipika.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Mandritra izany fotoana izany dia manangana hazo avy amin'ny filaharana milahatra amin'ny fotoana fohy izahay.
        self.bulk_push(iter, length)
    }

    /// Manosika ny mpivady manan-danja rehetra any amin'ny faran'ny hazo, mampitombo ny fiovaovan'ny `length` eny an-dalana.
    /// Ity farany dia manamora ny fampiasan'ny mpiantso ny fivoahan'ny rano rehefa mihetsiketsika ilay iterator.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Ampidiro ireo mpivady manan-danja rehetra, manosika azy ireo ho any amin'ny teboka amin'ny haavony mety.
        for (key, value) in iter {
            // Miezaha manosika ny mpivady manan-danja hidina ao amin'ilay vodin-dravina.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Tsy misy toerana tavela intsony, miakara atosika any.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Nahita node misy elanelana sisa, tsindrio eto.
                                open_node = parent;
                                break;
                            } else {
                                // Miakara indray.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Eo an-tampony isika, mamorona node faka vaovao ary manosika eo.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Atosory ny mpivady manan-danja sy ny subtree havanana vaovao.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Midina amin'ny ravina farany tsara indrindra.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Ny halavan'ny fampitomboana isaky ny miverina, mba hahazoana antoka fa ny sari-tany dia mandatsaka ireo singa ampidirina na dia mandroso aza ny fikorontanan'ny iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Mpiverina iray amin'ny fampiraisana ny filaharana roa nilahatra ho iray
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Raha mitovy ny fanalahidy roa, avereno avy amin'ny loharano mety ilay mpivady manan-danja.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}