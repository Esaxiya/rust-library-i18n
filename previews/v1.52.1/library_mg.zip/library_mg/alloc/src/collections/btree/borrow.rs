use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modely famerenam-bola amin'ny famaritana tsy manam-paharoa, rehefa fantatrao fa ny mpampindram-bola sy ny taranany rehetra (izany hoe ny tondro sy ny fanovozan-kevitra rehetra nalaina avy tao aminy) dia tsy hampiasaina intsony amin'ny fotoana sasany, ary aorian'izay dia te hampiasa ilay referansa tokana niavaka ianao. .
///
///
/// Matetika ny mpanamarina findramam-bola dia mitantana an'ity fanangonam-bola ity ho anao, saingy misy fantsom-pifehezana sasany izay mahavita an'io fametahana io dia sarotra loatra ka tsy arahin'ilay mpanangona.
/// `DormantMutRef` dia ahafahanao manamarina mindrana ny tenanao, raha mbola maneho ny toetrany mifatotra, ary mametaka ny kaody mpanondro ilaina mba hanaovana izany tsy misy fihetsika tsy voafaritra.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Makà indram-bola tsy manam-paharoa, ary avereno avy hatrany.
    /// Ho an'ny mpamorona, ny androm-piainan'ny fanovozan-kevitra vaovao dia mitovy amin'ny androm-piainan'ilay boky voalohany, fa ianao kosa promise hampiasa izany mandritra ny fotoana fohy kokoa.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: mitazona ny indram-bola mandritra ny 'a amin'ny alàlan'ny `_marker` izahay, ary mampiharihary
        // ity referansy ity ihany, noho izany dia tokana izy.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Miverena any amin'ny indram-bola indramina voasambotra.
    ///
    /// # Safety
    ///
    /// Ny famindram-bola dia tsy maintsy nifarana, izany hoe, ny referansa naverin'i `new` sy ny tondro rehetra ary ny referansa nalaina avy tao aminy dia tsy tokony hampiasaina intsony.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAFETY: ny fepetra fiarovana antsika manokana dia midika tsy manam-paharoa ity fanovozan-kevitra ity.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;