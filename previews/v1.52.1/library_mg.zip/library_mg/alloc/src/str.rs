//! Unicode slices.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Ny karazany `&str` dia iray amin'ireo karazana tadin-doha roa, ny iray hafa dia `String`.
//! Tsy toy ny mpifaninana `String` fa nindramina ny atiny.
//!
//! # Fampiasana fototra
//!
//! Fanambarana kofehy fototra karazana `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Eto izahay dia nanambara fa ara-bakiteny ny kofehy, fantatra amin'ny anarana hoe slice string.
//! String literals manana voasakantsakan'ny androm-piainany, izay midika hoe ny kofehy `hello_world` azo antoka ho manan-kery nandritra ny fisian'ny fandaharana manontolo.
//!
//! Afaka milaza mivantana ny androm-piainany: hello_world` ihany koa:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Betsaka ny fampiasana ato amin'ity modely ity no ampiasaina amin'ny fikirakirana ny fanandramana.
// Madio kokoa ny mamono ny fampitandremana tsy ampiasaina_imports toy izay manamboatra azy ireo.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` in `Concat<str>` dia tsy manan-danja eto.
/// Io karazana fikirana ny trait misy ihany mba hahafahan'ny hafa impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ny tadivavarana misy habe mikirakira mafy dia mihazakazaka haingana kokoa dia manokana ireo tranga misy halavan'ny fisarahana kely
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // fallback habe tsy aotra arbitrary
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Fampiharana haino aman-jery havaozina izay miasa ho an'ny Vec<T>(T: Copy) ary ny atiny anatiny an'i String amin'izao fotoana izao (2018-05-13) dia misy bibikely misy karazana fanatobiana sy fanamoriana (jereo ny laharana #36262) Noho io antony io SliceConcat<T>dia tsy manokana ho an'ny T: Copy sy SliceConcat<str>no hany mpampiasa an'io fiasa io.
// Ny sisa ao fitoerana teo ho an'ny fotoana izany tafatoetra.
//
// ny fetra ho an'ny String-join dia S: mindrana<str>ary ho an'ny Vec-join Borrow <[T]> [T] ary str AsRef <[T]> ho an'ny T sasany
// => s.borrow().as_ref() ary manana silaka foana izahay
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ny silaka voalohany ihany no tsy misy mpampisaraka alohan'io
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // manisa ny halavan'ny totalin'ny Vec nanatevin-daharana raha toa ka feno ny kajy `len`, dia ho panic izahay fa ho lany fahatsiarovana ihany ary ny sisa amin'ny asa dia mitaky ny Vec natokana natokana ho an'ny fiarovana.
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // manomàna buffer tsy voadinika
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // mandika Separator sy ny slices ny taratasim-bola tsy misy fetra hiteraka tadivavarana amin'ny hardcoded maivana ho an'ny kely separators fanatsarana goavana azo atao (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Ny fampiharana findramam-bola hafahafa dia mety hamerina sary samihafa ho an'ny kajy halavany sy ilay tena kopia.
        //
        // Hamarino tsara fa tsy hampiharantsika amin'ireo miantso ireo bytes tsy voalamina.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Fomba fampiasa amin'ny tapa-kofehy.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Manova `Box<str>` ho `Box<[u8]>` nefa tsy mandika na mizara.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Manolo ny lalao rehetra amin'ny lamina amin'ny tadiny hafa.
    ///
    /// `replace` mamorona [`String`] vaovao, ary mandika ny angon-drakitra avy amin'io tsipika io ho ao aminy.
    /// Raha manao izany, fa miezaka mba hahita lalao ny modely.
    /// Raha mahita izy dia manolo azy ireo amin'ilay sombin-tariby soloina.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Rehefa tsy mifanaraka ny lamina:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Manolo ny lalao N voalohany amin'ny lamina misy tadiny hafa.
    ///
    /// `replacen` mamorona [`String`] vaovao, ary mandika ny angon-drakitra avy amin'io tsipika io ho ao aminy.
    /// Raha manao izany, fa miezaka mba hahita lalao ny modely.
    /// Raha mahita izy dia manolo azy ireo amin'ny tsipika tadiny soloina farafaharatsiny `count` fotoana.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Rehefa tsy mifanaraka ny lamina:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Manantena ny hampihena ny fotoana fanokanana indray
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Miverina ny lowercase mitovy amin'ny kofehy ity silaka, toy ny [`String`] vaovao.
    ///
    /// 'Lowercase' dia faritana araka ny teny ao amin'ny Unicode Anarana Core Property `Lowercase`.
    ///
    /// Koa satria afaka hanitatra litera sasany ho endri-tsoratra maro, rehefa manova ny raharaha, io asany niverina ny [`String`] fa tsy manova ny fikirana in-toerana.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Ohatra sarotra, miaraka amin'ny sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // fa amin'ny faran'ny teny dia ς fa tsy σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Fiteny tsy misy raharaha dia tsy niova;
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ sarintany mankany σ, afa-tsy amin'ny faran'ny teny izay misy ny sarintany to.
                // Ity no hany (contextual) misy fepetra fa misy ny sarintany tsy miankina amin'ny fiteny ao amin'ny `SpecialCasing.txt`, ka asio kaody fatratra fa tsy manana mekanika "condition" mahazatra.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // ho an'ny famaritana ny `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Miverina ny mitovy aminy amin'ilay sombin-tadiny, ho [`String`] vaovao.
    ///
    /// 'Uppercase' dia faritana araka ny fepetra ao amin'ny Unicode Derived Core Property `Uppercase`.
    ///
    /// Koa satria afaka hanitatra litera sasany ho endri-tsoratra maro, rehefa manova ny raharaha, io asany niverina ny [`String`] fa tsy manova ny fikirana in-toerana.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Ny script tsy misy tranga dia tsy miova:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ny toetra amam-panahy dia mety ho lasa maro:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Manova [`Box<str>`] ho [`String`] nefa tsy mandika na mizara.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Mamorona [`String`] vaovao amin'ny famerenana tadiny `n` fotoana.
    ///
    /// # Panics
    ///
    /// Ity fiasa ity dia panic raha toa ka mihoatra ny tondra-drano.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic eo ambonin'ny safotra:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Miverina ny dika mitovy io kofehy izay mpandray anjara tsirairay dia marika ASCII tsarintany ho any amin'ny raharaha ambony mitovy.
    ///
    ///
    /// Ny litera ASCII 'a' ka hatramin'ny 'z' dia mapafao amin'ny 'A' ka hatramin'ny 'Z', fa ny litera tsy ASCII tsy miova.
    ///
    /// Raha te-hametraka ny soatoavina eo an-toerana dia ampiasao ny [`make_ascii_uppercase`].
    ///
    /// Mba hametahana ny endri-tsoratra ASCII ankoatry ny endri-tsoratra ASCII dia ampiasao [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() miaro ny UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Miverina ny dika mitovy io kofehy izay mpandray anjara tsirairay dia tsarintany ny marika ASCII ambany ny tranga mitovy.
    ///
    ///
    /// Marika ASCII taratasy 'A' ho 'Z' dia tsarintany ny 'a' ho 'z', fa tsy marika ASCII taratasy dia niova.
    ///
    /// Raha hampidina ny sandam-bola eo an-toerana dia ampiasao ny [`make_ascii_lowercase`].
    ///
    /// Raha hampidina ny litera ASCII ankoatry ny litera tsy ASCII dia ampiasao [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() miaro ny UTF-8 invariant.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Niova fo ny boxed silaka oktety amin'ny kofehy boxed silaka tsy misy mijery fa misy manan-kery amin'ny kofehy UTF-8.
///
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}