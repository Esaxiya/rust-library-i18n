//! Toro-fanisana isa tokana kambana.'Rc' mijoro for 'Reference
//! Counted'.
//!
//! Ny karazana [`Rc<T>`][`Rc`] dia manome ny fananana iraisana ny karazana `T`, natokana ao amin'ny antontam-bato.
//! Fanononany ny fiandrianam-[`clone`][clone] amin'ny [`Rc`] mamokatra vaovao manondro ny fanomezana toy izany koa ao amin'ny antontan-javatra.
//! Rehefa rava ny tondro [`Rc`] farany amin'ny fizarana nomena dia nidina ihany koa ny sanda voatahiry ao amin'io fizarana io (matetika antsoina hoe "inner value").
//!
//! Ny referansa zaraina ao amin'ny Rust dia mamela ny fiovan'ny toetr'andro, ary ny [`Rc`] tsy ankanavaka: tsy afaka mahazo référence mutable zavatra iray ao anaty [`Rc`] ianao.
//! Raha mila mutability ianao dia asio [`Cell`] na [`RefCell`] ao anatin'ny [`Rc`];jereo [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] mampiasa fanisana referansa tsy atôma.
//! Midika izany fa ambany dia ambany dia ambany, fa ny [`Rc`] dia tsy azo alefa eo anelanelan'ny kofehy, ary vokatr'izany [`Rc`] dia tsy mampihatra [`Send`][send].
//! Vokatr'izany, ny compiler Rust dia hanamarina *amin'ny fotoana fanangonana* fa tsy mandefa an'i [`Rc`] eo anelanelan'ny kofehy ianao.
//! Raha mila fanisana marimaritra iraisana ianao, ampiasao [`sync::Arc`][arc].
//!
//! Ny fomba [`downgrade`][downgrade] dia azo ampiasaina hamoronana tondro [`Weak`] tsy manana.
//! Ny tondro [`Weak`] dia mety [«fanavaozana`][fanavaozana] d mankany [`Rc`], saingy hiverina [`None`] io raha efa nilatsaka ny sanda voatahiry ao amin'ny fizarana.
//! Raha lazaina amin'ny teny hafa, ny tondro `Weak` dia tsy mitazona ny lanja ao anaty ny fizarana velona;na izany aza, izy ireo dia *mitazona* ny fizarana (fivarotana miorina amin'ny sandany anatiny) velona.
//!
//! Ny tsingerina eo anelanelan'ny tondro [`Rc`] dia tsy hifindra toerana mihitsy.
//! Noho io antony io, [`Weak`] dia ampiasaina hanapotehana ny tsingerina.
//! Ohatra, ny hazo dia mety hanana tondro [`Rc`] matanjaka hatrany amin'ny vodin'ny ray aman-dreny ka hatrany amin'ny zanaka, ary ny tondro [`Weak`] avy amin'ny zanaka miverina amin'ny ray aman-dreniny.
//!
//! `Rc<T>` mandeha ho azy dereferansa ny `T` (amin'ny alàlan'ny [`Deref`] trait), amin'izay ianao afaka miantso ny fomba `T` amin'ny sanda [`Rc<T>`][`Rc`].
//! Mba hisorohana ny fifandonana anarana amin'ny fomban'ny `T`, ny fomba [`Rc<T>`][`Rc`] mihitsy dia asa mifandraika, antsoina hoe [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>` 'S implementations ny traits tahaka `Clone` koa hatao hoe mampiasa Syntaxe mendrika tanteraka.
//! Ny olona sasany dia aleony mampiasa syntax feno fahaizana, fa ny sasany kosa aleony mampiasa sintona antso-fomba.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntax fiantsoana fomba
//! let rc2 = rc.clone();
//! // Syntax mahafeno fepetra feno
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] tsy manadino ny `T` ho azy, satria mety efa nilatsaka ny sanda anatiny.
//!
//! # Fanondroana klona
//!
//! Ny famoronana referansa vaovao amin'ny fizarana mitovy amin'ny fanondroana isa voaisa dia ampiasaina amin'ny alàlan'ny `Clone` trait napetraka ho an'ny [`Rc<T>`][`Rc`] sy [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ny syntaxes roa etsy ambany dia mitovy.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a sy b dia manondro ny toerana fitadidiana mitovy amin'ny foo.
//! ```
//!
//! Ny syntax `Rc::clone(&from)` no idiomatika indrindra satria mampita mazava kokoa ny dikan'ilay kaody.
//! Ao amin'ny ohatra etsy ambony, ity syntax ity dia manamora kokoa ny mahita fa ity kaody ity dia mamorona referansa vaovao fa tsy maka tahaka ny atiny foo manontolo.
//!
//! # Examples
//!
//! Diniho ny scenario iray izay ananan'i `Owner` andiana `Gadget`s.
//! Tianay ny manondro ny `Gadget`s amin'ny `Owner` azy ireo.Tsy afaka manao izany amin'ny tompona tokana izahay, satria mihoatra ny iray ny gadget mety ho an'ny `Owner` iray ihany.
//! [`Rc`] mamela antsika hizara `Owner` eo anelanelan'ny `Gadget`s, ary hanana `Owner` hijanona hatokana raha mbola misy teboka `Gadget` ao.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... saha hafa
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... saha hafa
//! }
//!
//! fn main() {
//!     // Mamorona `Owner` isaina isa.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Mamorona `Gadget an'ny `gadget_owner`.
//!     // Fanamboarana ny `Rc<Owner>` manome antsika vaovao ho iray ihany manondro `Owner` fanomezana, incrementing ny boky fanisam ao amin'ny dingana.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Atsipazo ny `gadget_owner` miova eo an-toerana.
//!     drop(gadget_owner);
//!
//!     // Na dia eo aza nandatsaka `gadget_owner`, izahay mbola afaka pirinty avy ny anaran'ny `Owner` ny `Gadget`s.
//!     // Ny antony dia satria isika ihany no efa nandatsaka `Rc<Owner>` iray, fa tsy ny `Owner` dia manondro.
//!     // Raha mbola misy hafa nanondro `Rc<Owner>` miaraka amin'izay koa `Owner` fanomezana, dia mbola velona.
//!     // Projection any an-tsaha, satria `Rc<Owner>` `gadget1.owner.name` miasa avy hatrany ny `Owner` dereferences.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Amin'ny faran'ny fiasa dia rava ny `gadget1` sy `gadget2`, ary miaraka amin'izy ireo ny fanisana farany isaina ny `Owner`-tsika.
//!     // Potika koa izao ny Gadget Man.
//!     //
//! }
//! ```
//!
//! Raha miova ny takianay, ary mila afaka mamakivaky ny `Owner` ka hatramin'ny `Gadget` isika dia hahita olana.
//! Tondro [`Rc`] iray avy amin'ny `Owner` ka hatramin'ny `Gadget` dia manolotra tsingerina iray.
//! Midika izany fa tsy hahatratra 0 mihitsy ny fanisana ataon'izy ireo ary tsy ho rava mihitsy ny fizarana:
//! famoahana fahatsiarovana.Raha te-hitety an'ity dia afaka mampiasa tondro [`Weak`] isika.
//!
//! Rust raha ny marina no mahatonga azy somary sarotra ny hamokatra manome fitoerana ity eo amin'ny toerana voalohany.Mba hiafara amin'ny soatoavina roa izay mifanondro dia mila miova ny iray amin'izy ireo.
//! Sarotra izany satria [`Rc`] dia miaro ny fiarovana ny fahatsiarovana amin'ny alàlan'ny fanomezana torolàlana iraisana momba ny sanda fonosiny, ary ireo dia tsy mamela fiovana mivantana.
//! Tokony hofonosintsika ny ampahany amin'ny sanda tiantsika ahodina ao amin'ny [`RefCell`], izay manome ny *fiovan'ny atiny*: fomba iray hahatratrarana ny fiovan'ny toetr'andro amin'ny alàlan'ny reperitoara iraisana.
//! [`RefCell`] Rust manamafy ny fitsipika amin'ny runtime nindrana.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... saha hafa
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... saha hafa
//! }
//!
//! fn main() {
//!     // Mamorona `Owner` isaina isa.
//!     // Mariho fa napetrantsika ao anaty `RefCell` ny `Owner's vector an'ny` Gadget 'mba hahafahantsika manova azy amin'ny alàlan'ny reperitoara iraisana.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Mamorona `Gadget an'ny `gadget_owner`, toy ny teo aloha.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Ampio ny `Gadget` ao amin'ny `Owner`-dry zareo.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` mifarana eto ny findramam-bola mavitrika.
//!     }
//!
//!     // Mialà sasatra amin'ny `Gadget`s, manonta ny antsipiriany.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` dia `Weak<Gadget>`.
//!         // Satria ny point `Weak` dia tsy afaka manome antoka fa mbola misy ny fizarana, dia mila miantso `upgrade` isika, izay mamerina `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Amin'ity tranga ity dia fantatsika ny fanomezana mbola misy, noho izany dia ny `Option` `unwrap` fotsiny.
//!         // Ao amin'ny programa sarotra kokoa dia mety mila fikirana amboarina ianao noho ny valiny `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Amin'ny faran'ny fiasa dia rava ny `gadget_owner`, `gadget1`, ary `gadget2`.
//!     // Misy (`Rc`) mafy ka tsy ho sahaza ny fitaovana, ka ho torotoro Izy.
//!     // Io dia manome ny isa ny fanondroana ao amin'ny Gadget Man, ka simba koa izy.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Izany no repr(C) ny future-porofo manohitra azo atao reordering-zavatra, izay mety hanelingelina raha tsy izany dia azo antoka [into|from]_raw() ny transmutable anaty karazana.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Toro-isa fanoratana tokana kofehy.'Rc' midika hoe 'Reference
/// Counted'.
///
/// Jereo ny [module-level documentation](./index.html) raha mila fanazavana fanampiny.
///
/// Ny fomba fanao `Rc` dia fiasa mifandraika rehetra, izay midika fa tsy maintsy miantso azy ireo ianao hoe oh, [`Rc::get_mut(&mut value)`][get_mut] fa tsy `value.get_mut()`.
/// Izany dia misoroka ny fifanolanana amin'ireo fomba ao anaty `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ity tsy fandriam-pahalemana ity dia tsy maninona satria raha mbola velona ity Rc ity dia manome toky isika fa mety ny fanondroana anatiny.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Manangana `Rc<T>` vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Misy tsy manan-kery tanteraka manondro fananan'ny rehetra sahaza ny mahery, izay miantoka fa ny malemy destructor tsy manafaka ny fanomezana raha destructor ny mahery dia mihazakazaka, na dia ny malemy manondro voatahiry ao anatin'ny matanjaka.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Constructs vaovao mampiasa ny malemy `Rc<T>` momba ny tenany.
    /// Nikasa ny hanatsarana ny malemy momba alohan'ny asa ity dia miverina ao amin'ny `None` vokany sarobidy.
    ///
    /// Na izany aza, ny referansa malemy dia azo clone maimaimpoana ary tehirizina hampiasaina amin'ny fotoana manaraka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... saha fanampiny
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Amboary ny atitany ao amin'ny fanjakana "uninitialized" miaraka amina referansa malemy tokana.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Zava-dehibe tsy kivy ny malemy tompon'ny manondro, fa raha tsy ny fahatsiarovana mba ho afaka ny andro `data_fn` miverina.
        // Raha tena te handany ny tompony isika dia afaka mamorona tondro malemy fanampiny ho an'ny tenantsika, saingy izany dia hiteraka fanavaozana fanampiny ho an'ny isa malemy izay mety tsy ilaina raha tsy izany.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Ny fanovozan-kevitra mafonja dia tokony hanana tondro malemy iraisana iraisana, koa aza mihazakazaka ny mpanimba ho an'ny referansa malemy taloha.
        //
        mem::forget(weak);
        strong
    }

    /// Manangana `Rc` vaovao misy atiny tsy voamarina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Manangana `Rc` vaovao misy atiny tsy voalamina, miaraka amin'ny fahatsiarovan-tena feno `0` bytes.
    ///
    ///
    /// Jereo [`MaybeUninit::zeroed`][zeroed] raha ohatra amin'ny fampiasana marina sy tsy marina an'io fomba io.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Manangana `Rc<T>` vaovao, mamerina lesoka raha tsy nahomby ny fizarana
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Misy tsy manan-kery tanteraka manondro fananan'ny rehetra sahaza ny mahery, izay miantoka fa ny malemy destructor tsy manafaka ny fanomezana raha destructor ny mahery dia mihazakazaka, na dia ny malemy manondro voatahiry ao anatin'ny matanjaka.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Constructs vaovao `Rc` amin'ny uninitialized anatiny, niverina ny fahadisoana raha ny fanomezana ho levona mandrakizay
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Manangana `Rc` vaovao misy atiny tsy voalamina, miaraka amin'ny fahatsiarovana feno `0` bytes, mamerina lesoka raha toa ka tsy mahomby ny fizarana.
    ///
    ///
    /// Jereo [`MaybeUninit::zeroed`][zeroed] raha ohatra amin'ny fampiasana marina sy tsy marina an'io fomba io.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Manangana `Pin<Rc<T>>` vaovao.
    /// Raha tsy manatanteraka `T` `Unpin`, dia ho mipaingotra `value` fahatsiarovana sy tsy afaka hangozohozo.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Miverina ny sanda anatiny, raha ny `Rc` dia manana referansa mahery matanjaka iray.
    ///
    /// Raha tsy izany, [`Err`] averina miaraka amin'ny `Rc` mitovy izay nampitaina.
    ///
    ///
    /// Hahomby izany na dia misy fanondroana malemy miavaka aza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // adikao ilay zavatra ao anatiny

                // Lazao amin'ny Weaks fa tsy afaka ampiroboroboana izy ireo amin'ny alàlan'ny fampihenana ny isa mavesatra, ary avy eo esory ny pointer "strong weak" tsy voatanisa ary koa ny fikirakirana lozika amin'ny alàlan'ny fanamboarana ny Malemy sandoka fotsiny.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Manangana sombin-tsoratra vaovao voasokajy misy atiny tsy voalamina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Manangana sombin-tsoratra vaovao voasokajy misy atiny tsy voalamina, miaraka amin'ny fahatsiarovana nofenoina baoty `0`.
    ///
    ///
    /// Jereo [`MaybeUninit::zeroed`][zeroed] raha ohatra amin'ny fampiasana marina sy tsy marina an'io fomba io.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Mivadika ho `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Toy ny [`MaybeUninit::assume_init`], dia niakatra ho any amin'ny mpiantso mba antoka fa tena sarobidy ny anaty ao amin'ny initialized fanjakana.
    ///
    /// Ny fiantsoana an'io rehefa tsy vita am-boalohany ny atiny dia miteraka fihetsika tsy voafaritra eo noho eo.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Mivadika ho `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Toy ny [`MaybeUninit::assume_init`], dia niakatra ho any amin'ny mpiantso mba antoka fa tena sarobidy ny anaty ao amin'ny initialized fanjakana.
    ///
    /// Ny fiantsoana an'io rehefa tsy vita am-boalohany ny atiny dia miteraka fihetsika tsy voafaritra eo noho eo.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Fanombohana fanemorana:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Manjifa ny `Rc`, mamerina ny tondro voatonona.
    ///
    /// Mba hisorohana ny famoahana fahatsiarovana dia tokony havadika ho `Rc` amin'ny fampiasana [`Rc::from_raw`][from_raw] ny pointer.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Manome tondro mazava ho an'ny data.
    ///
    /// Ny fanisana dia tsy misy fiantraikany amin'ny lafiny rehetra ary ny `Rc` tsy lany.
    /// Ny pointer dia manan-kery raha mbola misy fanisana mahery ao amin'ny `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAFETY: Tsy afaka mandalo Deref::deref na Rc::inner ity satria
        // izany dia takiana mba hitazonana ny raw/mut porofo toy izany ohatra
        // `get_mut` afaka manoratra amin'ny alàlan'ny pointer aorian'ny Rc averina amin'ny alalàn'ny `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Manangana `Rc<T>` avy amin'ny mpanondro manta.
    ///
    /// Ny pointer manta dia tsy maintsy naverina tamin'ny alàlan'ny antso mankany amin'ny [`Rc<U>::into_raw`][into_raw] izay misy `U` tsy maintsy mitovy habe sy fampifanarahana amin'ny `T`.
    /// Marina izany fa tsy misy dikany raha `T` dia `T`.
    /// Mariho fa raha `U` dia tsy `T` fa manana ny habeny sy ny fampifanarahana azy dia toy ny fandefasana referansa amin'ny karazany isan-karazany io.
    /// Jereo [`mem::transmute`][transmute] raha mila fanazavana fanampiny momba ny fameperana mihatra amin'ity tranga ity.
    ///
    /// Ny mpampiasa `from_raw` dia tsy maintsy mahazo antoka fa ny lanjan'antoka `T` iray dia nilatsaka indray mandeha ihany.
    ///
    /// Tsy azo antoka ity fiasa ity satria ny fampiasana tsy mety dia mety hitarika tsy fahatokisan-tsaina, na dia tsy azo idirana mihitsy aza ilay `Rc<T>` tafaverina.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Niova fo miverina any amin'ny `Rc` mba tsy mandefa.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ny antso lavitra mankany `Rc::from_raw(x_ptr)` dia tsy ho azo antoka.
    /// }
    ///
    /// // Navoaka ny fahatsiarovana rehefa nivoaka ivelan'ny sehatra ambony i `x`, ka mihantona izao i `x_ptr`!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Miverina ny offset raha te hahita ny RcBox tany am-boalohany.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Mamorona tondro [`Weak`] vaovao amin'ity fizarana ity.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Hamarino tsara fa tsy mamorona fahalemena mihantona isika
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Mahazo ny isan'ny tondro [`Weak`] amin'ity fizarana ity.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Mahazo ny isan'ny tondro mahery (`Rc`) amin'ity fizarana ity.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Miverina `true` raha tsy misy tondro hafa `Rc` na [`Weak`] amin'ity fizarana ity.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Miverina ny referable miovaova amin'ny `Rc` nomena, raha tsy misy tondro hafa `Rc` na [`Weak`] amin'ny fizarana mitovy.
    ///
    ///
    /// Miverina amin'ny [`None`] raha tsy izany, satria tsy azo antoka ny mampiova ny sanda ifampizarana.
    ///
    /// Jereo ihany koa ny [`make_mut`][make_mut], izay [`clone`][clone] ny sanda anatiny raha misy tondro hafa.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Miverina ny referable miovaova ao amin'ny `Rc` nomena, tsy misy fanamarinana.
    ///
    /// Jereo ihany koa ny [`get_mut`], izay azo antoka ary manao fanamarinana mety.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Hafa na [`Weak`] `Rc` sahaza ho fanomezana iray ihany tsy tokony dereferenced nandritra ny fisian'ny amin'ny niverina hisambotra.
    ///
    /// Tsy dia misy dikany izany raha tsy misy ny tondro toy izany, ohatra aorian'ny `Rc::new` avy hatrany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mitandrina izahay mba *tsy* hamorona referansa mandrakotra ny saha "count", satria mifanohitra amin'ny fidirana amin'ny isa isa (oh:
        // nataon'i `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Miverina `true` raha toa ka manondro ny fizarana mitovy ny roa Rc` (amin'ny lalan-drà mitovy amin'ny [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Mahatonga referable miovaova amin'ny `Rc` nomena.
    ///
    /// Raha misy hafa `Rc` sahaza ho fanomezana iray ihany, dia ho [`clone`] `make_mut` ny anatiny vidy ny fanomezana vaovao mba hahazoana antoka tsy manam-paharoa tompony.
    /// Ity dia antsoina koa hoe clone-on-write.
    ///
    /// Raha tsy misy tondro hafa `Rc` amin'ity fizarana ity dia esorina ny tondro [`Weak`] amin'ity fizarana ity.
    ///
    /// Jereo ihany koa ny [`get_mut`], izay tsy hahomby fa tsy hanjifa.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Tsy hanaiky na inona na inona
    /// let mut other_data = Rc::clone(&data);    // Tsy hanafoana ny angona anatiny
    /// *Rc::make_mut(&mut data) += 1;        // Data angona anatiny
    /// *Rc::make_mut(&mut data) += 1;        // Tsy hanaiky na inona na inona
    /// *Rc::make_mut(&mut other_data) *= 2;  // Tsy hanaiky na inona na inona
    ///
    /// // Ankehitriny `data` sy `other_data` dia manondro fizarana samihafa.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] hoesorina ireo tondro:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Tokony handahatra ny angon-drakitra, misy Rcs hafa.
            // Mizara mialoha ny fahatsiarovana hahafahanao manoratra mivantana ny soatoavina klona.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Afaka mangalatra angona fotsiny, ny sisa dia Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Esory tanteraka mafy-malemy ref (tsy misy tokony hanamboarana sandoka eto Malemy Ara-panahy-fantatsika Weaks hafa dia afaka hanadio ho antsika)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ity tsy fandriam-pahalemana ity dia ok satria manome toky izahay fa ny pointer niverina no *hany* pointer izay haverina amin'ny T.
        // Ny isa fanovozan-kevitray dia azo antoka fa ho 1 amin'izao fotoana izao, ary takianay ny `Rc<T>` tenany ho `mut`, ka averinay ny hany mety ilazana ny fizarana.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Miezaha hampidina ny `Rc<dyn Any>` amin'ny karazana simenitra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Manokana `RcBox<T>` misy toerana sahaza ho an'ny sanda anatiny anaty tsy voatanisa izay manome ny lamina omena ny sanda.
    ///
    /// Ny lahasa `mem_to_rcbox` dia nantsoina niaraka tamin'ny mpanondro data ary tsy maintsy miverina miverina (mety ho matavy)-pointer ho an'ny `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Manisa kaonty amin'ny alàlan'ny fisehon'ny sanda nomena.
        // Talohan'izay, ny layout dia nikajiana tamin'ny fitenenana `&*(ptr as* const RcBox<T>)`, saingy izany dia namorona referansa diso (jereo #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Manokana `RcBox<T>` misy toerana sahaza ho an'ny sanda anatiny mety tsy voadio izay manome ny lamina omena ny soatoavina, mamerina lesoka raha toa ka tsy nahomby ny fizarana.
    ///
    ///
    /// Ny lahasa `mem_to_rcbox` dia nantsoina niaraka tamin'ny mpanondro data ary tsy maintsy miverina miverina (mety ho matavy)-pointer ho an'ny `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Manisa kaonty amin'ny alàlan'ny fisehon'ny sanda nomena.
        // Talohan'izay, ny layout dia nikajiana tamin'ny fitenenana `&*(ptr as* const RcBox<T>)`, saingy izany dia namorona referansa diso (jereo #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Mizarà ho an'ny lamina.
        let ptr = allocate(layout)?;

        // Atombohy ny RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Manokana `RcBox<T>` misy toerana ampy ho an'ny sanda anatiny tsy voarindra
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Atokana ho an'ny `RcBox<T>` ny fampiasana ny sanda nomena.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Adikao ny sandan'ny bytes
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Afaho ny fizarana raha tsy mandatsaka ny atiny
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Manokana `RcBox<[T]>` miaraka amin'ny halavany.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Adikao ireo singa avy amin'ny silaka ao anaty Rc <\[T\]> vao natokana
    ///
    /// Tsy azo antoka satria ny miantso dia tsy maintsy mandray tompony na mamatotra `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Manangana `Rc<[T]>` amin'ny iterator fantatra amin'ny habe iray.
    ///
    /// Tsy voafaritra ny fitondran-tena raha diso ny habeny.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic mpiambina raha mandahatra ny singa T.
        // Raha toa ny panic, zavatra izay efa voasoratra any an-vaovao dia nandatsaka RcBox, dia nanafaka ny fahatsiarovana.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Manondro ny singa voalohany
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Mazava daholo.Adinoy ny mpiambina ka tsy manafaka ny RcBox vaovao.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait `From<&[T]>` nampiasaina.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Mitete ny `Rc`.
    ///
    /// Io dia hampihena ny isa mavesatra.
    /// Raha toa ka mahatratra aotra ny isa fanovozan-kevitra mahery dia ny [`Weak`] ihany no referansa hafa (raha misy), ka `drop` no sanda anatiny.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Tsy manonta na inona na inona
    /// drop(foo2);   // Pirinty "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // aringano ilay zavatra voarakitra
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // esory ny pointer "strong weak" implicit ankehitriny satria nopotehinay ny atiny.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Manao clone ny tondro `Rc`.
    ///
    /// Izany dia miteraka tondro iray hafa amin'ny fizarana mitovy amin'izany, mampitombo ny isa mavesatra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Mamorona `Rc<T>` vaovao, miaraka amin'ny sanda `Default` ho an'ny `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack mba hamela manokana anao amin'ny `Eq` na dia manana fomba aza ny `Eq`.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Izahay dia manao an'ity spécialisation ity eto, fa tsy amin'ny fanatsarana ankapobeny kokoa amin'ny `&T`, satria raha tsy izany dia hanampy vola amin'ny fanamarinana fitoviana rehetra amin'ny ref.
/// Heverinay fa ny `Rc`s dia ampiasaina hitehirizana soatoavina lehibe, miadana ny fametahana azy, nefa mavesatra ihany koa hijerena ny fitoviana, ka handoa mora kokoa io vidiny io.
///
/// Izany ihany koa ny mety hanana clones `Rc` roa, izay manondro ny vidiny ihany, noho ny roa: &T`s.
///
/// Azontsika atao ihany izany rehefa `T: Eq` amin'ny maha `PartialEq` dia mety fanahy iniana tsy milay.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Fitoviana ho an'ny `Rc` roa.
    ///
    /// `Rc`s roa mitovy raha ny anatiny fa mitovy soatoavina, na dia voatahiry ao fanomezana samihafa.
    ///
    /// Raha `T` koa dia mampihatra `Eq` (milaza reflexivity ny fitoviana), ny roa Rc` izay manondro ny fizarana mitovy dia mitovy foana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Tsy fitoviana amin'ny `Rc` roa.
    ///
    /// Ny `Rc` roa dia tsy mitovy raha tsy mitovy ny sanda anatiny.
    ///
    /// Raha `T` ihany koa ny manatanteraka `Eq` (midika reflexivity ny fitoviana), roa: Rc`s fa mitovy hevitra ny fanomezana dia tsy mitovy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Fampitahana ampahany amin'ny roa Rc`s.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `partial_cmp()` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Fampitahana kely noho ny an'ny `Rc` roa.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `<` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Tsy ampy na mitovy ny' fampitahana roa `Rc`s.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `<=` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Greater-noho ny fampitahana roa `Rc`s.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `>` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Lehibe noho na mitovy ny' fampitahana roa `Rc`s.
    ///
    /// Ny roa dia ampitahaina amin'ny fiantsoana `>=` amin'ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Fampitahana amin'ny `Rc` roa.
    ///
    /// Roa ireo raha oharina amin'ny fiantsoana `cmp()` eo amin'ny soatoavina anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Manokà sombin-isa voatanisa ary fenoy amin'ny alàlan'ny fananganana clon `v` ny entana.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Zarao ny reference-isaina tady silaka, ary mandika `v` ao anatiny.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Zarao ny reference-isaina tady silaka, ary mandika `v` ao anatiny.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Afindra amin'ny boaty vaovao, isaina, fizarana ny boaty.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Manokà sombin-isa voatanisa ary afindra ao aminy ny entana 'v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Avelao ny Vec hanafaka ny fitadidiany, fa aza manimba ny ao anatiny
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Raiso ny singa tsirairay ao amin'ny `Iterator` ary angonina ao anaty `Rc<[T]>`.
    ///
    /// # Toetra mampiavaka
    ///
    /// ## Ny tranga ankapobeny
    ///
    /// Amin'ny tranga ankapobeny, ny fanangonana amin'ny `Rc<[T]>` dia atao amin'ny alàlan'ny fanangonana voalohany mankany `Vec<T>`.Izany hoe, rehefa nanoratra izao manaraka izao:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// mitondra tena ho toy izany raha nanoratra hoe:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Ny voalohany napetraka ny vola omena mitranga eto.
    ///     .into(); // Ny faharoa fanomezana ho an'ny `Rc<[T]>` mitranga eto.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Izany dia zarao ho imbetsaka araka izay ilaina ho an'ny fanorenana ny `Vec<T>` ary avy eo dia zarao indray mandeha noho ny mamadika ny `Vec<T>` ho any amin'ny `Rc<[T]>`.
    ///
    ///
    /// ## Iterator amin'ny halavany fantatra
    ///
    /// Rehefa manatanteraka ny `Iterator` `TrustedLen` ary iray tena habeny, iray fanomezana ho natao ho ny `Rc<[T]>`.Ohatra:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Fizarana tokana ihany no mitranga eto.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// trait manokana ampiasaina amin'ny fanangonana `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ity no tranga misy iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAFETY: Mila mahazo antoka isika fa manana ny halavany marina ilay iterator ary manana isika.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Miverina amin'ny fampiharana mahazatra.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` dia kinova [`Rc`] izay mitazona referansa tsy tompony amin'ny fizarana tantanana.Ny fizarana dia alaina amin'ny alàlan'ny fiantsoana [`upgrade`] amin'ny tondro `Weak`, izay mamerina [`Option`]`<`[`Rc`]`<T>>`.
///
/// Satria ny fanondroana `Weak` dia tsy manisa ny fananana, tsy hanakana ny soatoavina voatahiry ao amin'ny fizarana tsy ho nilatsaka izany, ary `Weak` mihitsy no tsy manome antoka momba ny sanda mbola misy.
/// Araka izany dia mety hiverina [`None`] izy io rehefa [`fanavaozana`] d.
/// Mariho anefa fa `Weak` boky * * no misakana ny fanomezana mihitsy (ny fanohanana fivarotana) tsy ho deallocated.
///
/// Tondro `Weak` dia ilaina amin'ny fitazonana referansa vonjimaika amin'ny fizarana tantanan'ny [`Rc`] nefa tsy manakana ny sandany anatiny tsy hianjera.
/// Ampiasaina ihany koa izy io hisorohana ny fanondroana boribory eo anelanelan'ny tondro [`Rc`], satria ny fananana referansa mifampiankina dia tsy hamela ny [`Rc`] hilatsaka.
/// Ohatra, ny hazo dia mety hanana tondro [`Rc`] matanjaka hatrany amin'ny vodin'ny ray aman-dreny ka hatrany amin'ny zanaka, ary ny tondro `Weak` avy amin'ny zanaka miverina amin'ny ray aman-dreniny.
///
/// Ny fomba mahazatra mba hahazoana ny `Weak` manondro ny miantso [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // `NonNull` ity ahafahana manatsara ny haben'ity karazana ity amin'ny enum, saingy tsy voatery ho mpanondro marina izany.
    //
    // `Weak::new` apetraka amin'ny `usize::MAX` ity ka tsy mila manokana toerana amin'ny antontam-bato.
    // Tsy salan'isa izany ny tondro iray tena izy satria RcBox dia manana fampifanarahana farafaharatsiny 2.
    // Tsy misy izany raha tsy rehefa `T: Sized`;uns01 `T` tsy mihantona na oviana na oviana.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Manangana `Weak<T>` vaovao, nefa tsy mizara fahatsiarovana.
    /// Ny fiantsoana [`upgrade`] amin'ny sanda fiverenana dia manome [`None`] foana.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Karazana mpanampy hamelana ny fidirana amin'ny fanisana raha tsy misy fanamafisana momba ny sehatry ny angona.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Mamerina ny tondro masaka amin'ilay zavatra `T` notondroin'ity `Weak<T>` ity.
    ///
    /// Ny mpanondro dia manan-kery raha tsy misy referansa matanjaka.
    /// Ny tondro dia mety manantona, tsy mifanaraka ary [`null`] mihitsy aza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Samy manondro zavatra iray izy roa
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ny mahery eto dia mamelona azy, ka mbola afaka miditra amin'ilay zavatra ihany isika.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Fa tsy izany intsony.
    /// // Afaka manao weak.as_ptr() isika, fa ny fidirana amin'ny tondro dia hitarika amin'ny fitondrantena tsy voafaritra.
    /// // assert_eq! ("hello", tsy azo antoka {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Raha manantona ilay mpanondro dia averintsika mivantana ilay mpitily.
            // Tsy mety adiresy fandefasana karama io, satria ny karama dia farafaharatsiny mifanaraka amin'ny RcBox (usize).
            ptr as *const T
        } else {
            // SAFETY: raha i_dangling miverina diso, dia azo esorina ny tondro.
            // Ny mety ho latsaka payload Tamin'io fotoana io, ka tsy maintsy foana provenance, ka mampiasa manta manondro fanodinkodinana.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Manjifa ny `Weak<T>` ary mamadika azy ho mpanondro manta.
    ///
    /// Izany niova fo manondro ny malemy ho manondro manta, raha mbola mitahiry ny tompon'ny iray malemy ny boky (ny malemy dia tsy fanisam farany ity hetsika).
    /// Izy io dia azo averina averina ho `Weak<T>` miaraka [`from_raw`].
    ///
    /// Ireo fameperana mitovy amin'ny fidirana amin'ny kendrena ny tondro ary amin'ny [`as_ptr`] dia mihatra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Mamadika pointer manta noforonin'i [`into_raw`] niverina ho `Weak<T>`.
    ///
    /// Izy io dia azo ampiasaina hahazoana loharanom-pahalalana matanjaka (amin'ny fiantsoana [`upgrade`] any aoriana) na hametrahana ny isa malemy amin'ny famoahana ny `Weak<T>`.
    ///
    /// Mitaky ny fananana tondro malemy iray (ankoatry ny tondro noforonin'i [`new`], satria tsy manana na inona na inona izy ireo; ny fomba dia mbola mandaitra amin'izy ireo).
    ///
    /// # Safety
    ///
    /// Ny tondro dia tokony ho avy amin'ny [`into_raw`] ary tsy maintsy manana ny mety ho malemy referansa.
    ///
    /// Avela ho 0 ny isa mavesatra amin'ny fotoana iantsoana an'ity.
    /// Na izany aza, ity dia mitaky ny fananana tondro malemy iray izay soloina ankehitriny ho toy ny mpanondro manta (ny fanisana malemy dia tsy ovaina amin'ity asa ity) ary noho izany dia tsy maintsy ampiarahina amin'ny antso taloha ho [`into_raw`] izy io.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Mampihena ny isa malemy farany.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Jereo Weak::as_ptr ny teny manodidina amin'ny fomba manondro ny fahan'ny teny.

        let ptr = if is_dangling(ptr as *mut T) {
            // Malemy mihantona ity.
            ptr as *mut RcBox<T>
        } else {
            // Raha tsy izany dia mahazo antoka isika fa avy amin'ny Malemy tsy mitongilana ny tondro.
            // SAFETY: azo antoka iantsoana ny data_offset, satria ptr manondro ny tena (mety nilatsaka) T.
            let offset = unsafe { data_offset(ptr) };
            // Noho izany, averintsika ny offset mba hahazoana ny RcBox iray manontolo.
            // Famonjena, manondro Avy amin'ny malemy, ka izany offset voavonjy.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: efa azontsika izao ny pointer Weak tany am-boalohany, ka afaka mamorona ny Malemy.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Ny fiezahana havaozina ny tondro `Weak` ho [`Rc`], mampihemotra ny fandatsahana ny sanda anatiny raha mahomby.
    ///
    ///
    /// Miverina [`None`] raha nilatsaka ny sanda anatiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Aringano ireo tondro mahery rehetra.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Mahazo ny isan'ny tondro mahery (`Rc`) manondro io fizarana io.
    ///
    /// Raha noforonina [`Weak::new`] `self` dia hiverina 0 ity.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Mahazo ny isan'ny tondro `Weak` manondro io fizarana io.
    ///
    /// Raha tsy misy tondro mahery mijanona dia hiverina aotra izany.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // esory ny ptr osa malemy
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Miverina `None` rehefa mihantona ilay mpanondro ary tsy misy `RcBox` natokana, (izany hoe rehefa `Weak` no noforonin'i `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mitandrina izahay mba *tsy* hamorona referansa manarona ny saha "data", satria mety hiovaova ny fifanarahana (ohatra, raha latsaka ny `Rc` farany, dia hajanona eo amin'ny toerany ny saha data).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Miverina `true` raha manondro fizarana mitovy (mitovy amin'ny [`ptr::eq`]) ireo roa `Malemy ', na raha samy tsy manondro fizarana (satria noforonina tamin'ny `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Koa satria mampitaha tondro izany dia midika fa ny `Weak::new()` dia hitovy, na dia tsy manondro fizarana aza izy ireo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Mampitaha `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Mitete ny tondro `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Tsy manonta na inona na inona
    /// drop(foo);        // Pirinty "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ny isa malemy dia manomboka amin'ny 1, ary ho lasa zero raha toa ka nanjavona avokoa ireo tondro mahery.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Manao clone ny tondro `Weak` izay manondro ny fizarana mitovy.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Manangana `Weak<T>` vaovao, mizara fahatsiarovana ho an'ny `T` nefa tsy fanombohana azy.
    /// Ny fiantsoana [`upgrade`] amin'ny sanda fiverenana dia manome [`None`] foana.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Checked_add eto izahay mba hiatrehana mem::forget soa aman-tsara.Manokana
// raha mem::forget Rcs (na Weaks), ny ref-fanisana dia afaka tondraka, ary avy eo dia afaka manafaka ny fanomezana miavaka raha Rcs (na Weaks) misy.
//
// Nofoanana izahay satria tranga miharatsy io ka tsy miraharaha izay hitranga izahay-tsy misy programa tena tokony hiaina izany.
//
// Ity dia tokony hanana overhead tsy azo tsinontsinoavina satria tsy mila manangona ireo ao amin'ny Rust ianao noho ny fananana sy ny semantika mifindra.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Tianay ny manala ny safotra mihoatra ny fandatsahana ny sandany.
        // Ny isa fanovozan-kevitra dia tsy ho zero mihitsy raha io no antsoina;
        // na izany aza, mampiditra abort eto izahay mba hanondroana ny LLVM amin'ny fanatsarana tsy azo atao.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Tianay ny manala ny safotra mihoatra ny fandatsahana ny sandany.
        // Ny isa fanovozan-kevitra dia tsy ho zero mihitsy raha io no antsoina;
        // na izany aza, mampiditra abort eto izahay mba hanondroana ny LLVM amin'ny fanatsarana tsy azo atao.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Get ny offset `RcBox` ao anatin'ny iray ho an'ny payload ambadiky ny manondro.
///
/// # Safety
///
/// Ny tondro dia tsy maintsy manondro (ary manana metadata manan-kery ho an'ny) ohatra T izay manan-kery teo aloha, fa ny T kosa avela hilatsaka.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ampifanaraho amin'ny faran'ny RcBox ny sanda tsy voafaritra.
    // Satria ny RcBox dia repr(C), dia io no farany ho fahatsiarovana farany.
    // SAFETY: satria ny karazany tsy voafaritra ihany no azo atao dia ny silaka, zavatra trait,
    // ary ny karazany ivelany, ny fepetra takiana amin'ny fiarovana izao dia ampy hanomezana fahafaham-po ny fepetra takian'ny align_of_val_raw;izany dia fampiharana antsipirihany ny fiteny izay tsy ho niankina eo ivelan'ny std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}