use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// trait manokana ampiasaina amin'ny Vec::from_iter
///
/// ## Ny delegasiona kisary:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ny tranga mahazatra dia mandalo ny vector ho asa izay avy hatrany indray manangona ho vector.
        // Azontsika atao ny mihodina manodidina ity raha toa ka tsy nandroso mihitsy ny IntoIter.
        // Rehefa efa nandroso io dia azontsika atao koa ny mampiasa indray ny memoara ary mamindra ny data atsy aloha.
        // Fa tsy manao afa-tsy isika rehefa tsy manana fahaiza-miasa tsy ampiasaina intsony ny Vec vokatr'izany noho ny famoronana azy amin'ny alàlan'ny fampiharana avy amin'ny FromIterator.
        //
        // Izany tsy fahatanterahana dia tsy tena ilaina ny fanomezana araka ny fitondran-tenan'ny već dia fanahy iniana voafaritra.
        // Fa mba ho safidy nentin-drazana.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // dia tsy maintsy manome ny spec_extend() extend() mihitsy satria solontena ho spec_from ho foana tsy mitondra fanatitra Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Izany mampiasa spec_extend `iterator.as_slice().to_vec()` satria tsy maintsy ho antony bebe kokoa dingana farany momba ny fahafahana + lavany, ka manao bebe kokoa ny asa.
// `to_vec()` allocates mivantana ny marina vola sy marina rehetra eo aminy.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): miaraka cfg(test) ny fomba `[T]::to_vec` voajanahary, izay takiana amin'ity famaritana fomba ity dia tsy misy.
    // Raha tokony hampiasa ny `slice::to_vec` asa izay ihany no hita amin'ny cfg(test) NB mahita ny slice::hack Module in slice.rs Raha mila fanazavana fanampiny
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}