//! A contiguous growable nahay karazana amin'ny antontam-bato-omena anatiny, voasoratra `Vec<T>`.
//!
//! Vector dia manana `O(1)` indexing, amortized `O(1)` push (hatramin'ny farany) ary `O(1)` pop (avy any amin'ny farany).
//!
//!
//! Vectors hahazoana antoka na oviana na oviana izy ireo zarao mihoatra noho `isize::MAX` oktety.
//!
//! # Examples
//!
//! Azonao atao ny mamorona mazava [`Vec`] amin'ny [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... na amin'ny fampiasana ny makro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // folo zeroes
//! ```
//!
//! Azonao atao [`push`] sarobidy tao ny faran'ny iray vector (izay hitombo ny vector raha ilaina):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Miasa amin'ny fomba mitovy amin'izany ny sanda fametrahana:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vector koa dia manohana ny fanondroana anarana (amin'ny alàlan'ny [`Index`] sy [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Karazan-tsivalana azo zohina mitombo, voasoratra ho `Vec<T>` ary tononina 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Ny [`vec!`] macro dia omena mba hahatonga initialization mety kokoa:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Mety ihany koa ny singa tsirairay initialize ny `Vec<T>` amin'ny sanda nomena.
/// Mety ho mahomby kokoa noho ny manao fanomezana sy ny initialization amin'ny dingana samihafa, indrindra rehefa nitranga teo am-ny vector ny zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Ny manaraka dia mitovy, fa mety ho miadana kokoa:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Raha mila fanazavana fanampiny, jereo [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Mampiasà `Vec<T>` ho toy ny stack mahomby:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Fanontana 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Ny karazana `Vec` mamela ny fidirana amin'ny fanondroana soatoavina, satria manatanteraka ny [`Index`] trait.Ohatra iray ho mora kokoa ny mazava;
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // hasehony ny '2'
/// ```
///
/// Mitandrema ihany anefa: raha manandrana miditra index izay tsy ao amin'ny `Vec` ianao dia ho panic ny rindrambaiko!Tsy azonao atao izany:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Ampiasao [`get`] sy [`get_mut`] raha te hanamarina ianao raha ao amin'ny `Vec` ilay index.
///
/// # Slicing
///
/// Ny `Vec` dia mety miova.Etsy ankilany, ny slices dia zavatra vakina fotsiny.
/// Raha te hahazo [slice][prim@slice] dia ampiasao [`&`].Ohatra:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ary izay ihany!
/// // dia azonao atao ny manao izany toy izao:
/// let u: &[usize] = &v;
/// // na toy izao:
/// let u: &[_] = &v;
/// ```
///
/// Ao amin'ny Rust, mahazatra kokoa ny mandefa silaka ho toy ny fifamaliana fa tsy vectors raha te hanome fidirana vakiana fotsiny ianao.Toy izany koa ho an'ny [`String`] mandeha sy [`&str`].
///
/// # Fahafahana sy famerenana amin'ny laoniny
///
/// Ny fahaizan'ny vector dia ny habetsaky ny toerana natokana ho an'ny singa future izay hampiana ao amin'ny vector.Izany dia tsy tokony hampifangaroina amin'ny halavan'ny * * ny vector, izay mamaritra ny isan'ny singa tena ao anatin'ny vector.
/// Raha mihoatra ny fahafaha-manaony ny halavan'ny vector iray dia hitombo ho azy ny fahaizany fa tsy maintsy hapetraka indray ireo singa ao aminy.
///
/// Ohatra, ny vector manana fahaizana 10 sy ny halavany 0 dia vector foana misy habaka ho an'ny singa 10 hafa.Manosika 10 na latsaka tao amin'ny vector singa dia tsy hanova ny fahaiza-manao na mahatonga reallocation ho tonga izany.
/// Na izany aza, raha toa ka nitombo ho 11 ny halavan'ny vector dia tsy maintsy mivezivezy izy io, izay mety miadana.Noho io antony io dia asaina mampiasa [`Vec::with_capacity`] isaky ny azo atao ny mamaritra ny haben'ny vector andrasana.
///
/// # Guarantees
///
/// Noho ny mampino toetra fototra, `Vec` mahatonga be dia be ny antoka momba ny famolavolana.Izy io dia miantoka fa ambany loatra araka izay azo atao amin'ny tranga ankapobeny izy io, ary azo ampiasaina amin'ny fomba tsy miangatra amin'ny kaody tsy azo antoka.Mariho fa ireo antoka ireo dia manondro `Vec<T>` tsy mendrika.
/// Raha fanampiny masontsivana dia nanampy karazana (ohatra, mba hanohanana fanao allocators), miahy ny defaults dia mety hanova ny fitondran-tena.
///
/// Amin'ny ankapobeny, ny `Vec` dia ary (foana hatrany hatrany, dia ho triplet (pointer, capacité, halavany).Tsy misy intsony, tsy latsa-danja.Ny lamin 'ireo saha dia tanteraka tsy fantatra, ary tokony hampiasa ny fomba tsara ny manova izany.
/// Manondro dia tsy ho tohivakana foana, ka izany no karazana tohivakana foana-manondro-optimisé.
///
/// Na izany aza, ny tondro dia mety tsy manondro ny fahatsiarovana voatokana.
/// Manokana, raha manamboatra `Vec` manana fahaizana 0 amin'ny alàlan'ny [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], na amin'ny fiantsoana [`shrink_to_fit`] amin'ny Vec tsy misy izy dia tsy hanokana fahatsiarovana izany.Toy izany koa, raha mitahiry aotra-salantsalany karazana ao anaty `Vec`, dia tsy zarao toerana malalaka ho azy ireo.
/// *Mariho fa amin'ity tranga ity ny `Vec` dia mety tsy mitatitra [`capacity`] an'ny 0*.
/// `Vec` dia hizara raha ary raha [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Amin'ny ankapobeny, ny fanomezana: Vec` antsipirihany dia tena saro-takarina-raha mikasa ny zarao fahatsiarovana mampiasa `Vec`, mba hanaovana zavatra hafa (na ny zava-nitranga ny fehezan-dalàna mampidi-doza, na hanorina anao manokana fahatsiarovana tohanan'ny famoriam-bola), dia ataovy ny deallocate fahatsiarovana izany amin'ny alalan'ny fampiasana `from_raw_parts` hanavotra ny `Vec` ary avy eo dia nandatsaka azy io.
///
/// Raha `Vec`*dia manana* fahatsiarovana natokana ho azy, ny fahatsiarovana izay tondroiny dia eo amin'ny antontam-bato (araka ny famaritan'ny mpaninjara Rust dia namboarina hampiasa azy io), ary ny tondro manondro ny [`len`] dia namboarina, singa mifanakaiky arakaraka (izay tianao jereo raha noterenao ho amin'ny silaka) ianao, narahin'ny [`capacité`]`,`[`len`] tsy lozisialy tsy misy ilana azy, singa mifanakaiky.
///
///
/// vector misy ny singa `'a'` sy `'b'` misy fahaiza-manao 4 dia azo alaina sary etsy ambany.Ny tapany ambony no `Vec` struct, dia misy ny manondro ny lohan'ny ny fanomezana eo amin'ny korontam-bato, ny halavany sy ny fahafahana.
/// Ny tapany ambany dia ny fizarana amin'ny antontam-bato, sakana fahatsiarovana mifanila.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** dia maneho fahatsiarovana tsy voalahatra, jereo [`MaybeUninit`].
/// - Note: ny ABI dia tsy milamina ary `Vec` dia tsy manome antoka momba ny fisian'ny fahatsiarovany (ao anatin'izany ny filaharan'ny saha).
///
/// `Vec` tsy hanao "small optimization" mihitsy izay misy singa tena tehirizina ao anaty stack noho ny antony roa:
///
/// * Hananasarotra kokoa ho an'ny kaody tsy azo antoka ny manodinkodina tsara ny `Vec`.Ny atin'ny `Vec` dia tsy hanana adiresy marin-toerana raha tsy nafindra fotsiny izy io, ary ho sarotra kokoa ny hamantatra raha `Vec` no nanokana fahatsiarovana.
///
/// * Mety miteraka fatiantoka ho raharaha ny ankapobeny, mizaka fanampiny fidirana branch ny teny rehetra.
///
/// `Vec` dia tsy tonga dia hihemotra mihitsy, na dia tanteraka foana.Io dia miantoka fa tsy misy fizarana na fifanolanana tsy ilaina ilaina hitranga.Foanana ny `Vec` ary avy eo mameno niverina niakatra ho any amin'ny iray ihany dia tokony hiharan'ny [`len`] tsy misy antso ho amin'ny allocator.Raha te hanafaka ny fahatsiarovana tsy ampiasaina ianao dia ampiasao [`shrink_to_fit`] na [`shrink_to`].
///
/// [`push`] ary [`insert`] dia tsy hanome (re) mihitsy raha toa ka ampy ny fahafaha-mitatitra.[`push`] sy [`insert`]*dia*(Re) zarao raha toa [`len`]==``[` capacity`].Izany hoe, ny fahaiza-manao voalaza dia marina tanteraka, ary azo ianteherana.Azo ampiasaina mihitsy aza izy io hanafahana tanana ny fahatsiarovana natolotry `Vec` iray raha irina.
/// Fomba fampidirana marobe *mety* hisintaka, na dia tsy ilaina aza.
///
/// `Vec` dia tsy manome antoka ny paikadim-pitomboana manokana rehefa miseho rehefa feno, na rehefa antsoina i [`reserve`].Ny paikady ankehitriny dia fototra ary mety hanaporofoana fa mety ny fampiasana fivoarana tsy tapaka.Na inona na inona tetika ampiasaina dia azo antoka fa hiantoka *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, ary [`Vec::with_capacity(n)`][`Vec::with_capacity`], dia hamokatra ny `Vec` rehetra miaraka mihitsy ny nangataka fahafahana.
/// Raha [`len`]==``[` capacity`], (toy ny tranga ho an'ny [`vec!`] macro), avy eo `Vec<T>` afaka hiova fo ho ary avy amin'ny [`Box<[T]>`][owned slice] tsy reallocating na mihetsiketsika ny singa.
///
/// `Vec` tsy hanadino manokana data izay nesorina taminy, nefa koa tsy hitahiry manokana azy.Ny fahatsiarovana azy tsy voatanisa dia ny toerana karakaina mety hampiasainy na izany aza no tadiaviny.Amin'ny ankapobeny dia hanao izay mahomby indrindra na mora ampiharina fotsiny izy io.Aza miantehitra amin'ny Nesorin'i angon-drakitra mba ho voafafa noho ny fiarovana tanjona.
/// Na mandatsaka `Vec` aza ianao, dia mety hampiasa `Vec` hafa fotsiny ny buffer-ny.
/// Na dia ZERO misy: ny fahatsiarovana Vec` voalohany, izay mety tsy tena hitranga, satria ny optimizer tsy Mihevera izany ny lafiny-vokany izay tsy maintsy harovana.
/// Misy tranga iray izay tsy hotapahiny, na izany aza: mampiasa `unsafe` fehezan-dalàna ho manorata any amin'ny fahafahana be loatra, ary avy eo dia mitombo ny lavany mba mitovy, dia manan-kery foana.
///
/// Amin'izao fotoana izao, dia tsy manome antoka `Vec` ny baiko izay nandatsaka singa ireo.
/// Niova ny filaharana taloha ary mety hiova indray.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Fomba entina mandova
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Constructs vaovao, hahafoana `Vec<T>`.
    ///
    /// Ny vector tsy zarao raha singa dia atosika teo izany.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Manangana `Vec<T>` vaovao tsy misy fangarony miaraka amin'ny fahaizany voafaritra.
    ///
    /// Ny vector dia afaka mitazona singa `capacity` tena izy nefa tsy miverina mandingana.
    /// Raha `capacity` no 0, ny vector dia tsy zarao.
    ///
    /// Zava-dehibe ny manamarika fa na dia ny niverina vector manana fahafahana * * voatondro, ny vector hanana aotra * * halavany.
    ///
    /// Raha mila fanazavana momba ny fahasamihafana misy eo amin'ny halavany sy ny fahaizany dia jereo ny *[Capacity and reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Ny vector tsy misy zavatra, na dia manana fahafahana bebe kokoa
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Vita daholo ireo fa tsy mizaha toerana ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... fa izany dia mety hahatonga ny vector hamindra toerana
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Mamorona `Vec<T>` mivantana avy amin'ireo singa manta an'ny vector hafa.
    ///
    /// # Safety
    ///
    /// Izany no tena azo antoka, noho ny isan'ny invariants izay tsy avy amin'ny teny anglisy:
    ///
    /// * `ptr` mila natokana tamin'ny alàlan'ny [`String`]/`Vec<T>`(Raha kely indrindra, fa tena mety ho diso raha tsy).
    /// * `T` mila manana habe sy fampifanarahana mitovy amin'ilay natokana ho an'ny `ptr`.
    ///   (`T` manana fampifanarahana tsy dia hentitra loatra dia tsy ampy, ny fampifanarahana dia tena mila fitoviana mba hanomezana fahafaham-po ny takiana [`dealloc`] fa ny fahatsiarovana dia tsy maintsy omena sy hifanarahana amin'ny endriny mitovy.)
    ///
    /// * `length` mila latsaky ny na mitovy amin'ny `capacity`.
    /// * `capacity` mila ny fahaiza-manao izay nanondroana ny tondro.
    ///
    /// Nanitsakitsaka ireo dia mety hahatonga zava-manahirana toy ny manimba ny allocator ny angon-drakitra rafitra anatiny.Ohatra tsy dia ** ** azo antoka ny hanorina `Vec<u8>` avy amin'ny manondro ny C `char` voaomana amin'ny `size_t` halavany.
    /// Tsy azo antoka koa ny manangana iray avy amin'ny `Vec<u16>` sy ny halavany, satria ny mpizara dia miahy ny fampifanarahana, ary ireo karazany roa ireo dia samy hafa ny fampifanarahana azy.
    /// Ny buffer dia omena amin'ny fampifanarahana 2 (fa `u16`), fa rehefa mamadika izany ho `Vec<u8>` dia ho deallocated Ho amin'ny fampifanarahana 1.
    ///
    /// Ny tompon'ny `ptr` dia afindra amin'ny `Vec<T>` mahomby izay mety hifampiraharaha, hamindra na hanova ny atin'ny fahatsiarovana notondroin'ilay mpanondro araka ny sitrapony.
    /// Hamarino tsara fa tsy misy zavatra hafa mampiasa ny tondro rehefa niantso ity asa ity.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Ampivoary izany rehefa miorina tsara ny vector_into_raw_parts.
    ///     // Prévenir mihazakazaka `v` ny destructor izany tanteraka isika amin'ny fanaraha-maso ny fanomezana.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tsoahy ireo fampahalalana marobe momba ny `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Soraty amin'ny 4, 5, 6 ny fahatsiarovana
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Ataovy ny zavatra rehetra indray miaraka an-već
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Manangana `Vec<T, A>` vaovao sy foana.
    ///
    /// Ny vector tsy zarao raha singa dia atosika teo izany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Manangana `Vec<T, A>` vaovao tsy misy fangarony miaraka amin'ny fahaiza-manao voafaritra miaraka amin'ilay mpizara.
    ///
    /// Ny vector dia afaka mitazona singa `capacity` tena izy nefa tsy miverina mandingana.
    /// Raha `capacity` no 0, ny vector dia tsy zarao.
    ///
    /// Zava-dehibe ny manamarika fa na dia ny niverina vector manana fahafahana * * voatondro, ny vector hanana aotra * * halavany.
    ///
    /// Raha mila fanazavana momba ny fahasamihafana misy eo amin'ny halavany sy ny fahaizany dia jereo ny *[Capacity and reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Ny vector tsy misy zavatra, na dia manana fahafahana bebe kokoa
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Vita daholo ireo fa tsy mizaha toerana ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... fa izany dia mety hahatonga ny vector hamindra toerana
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Mamorona `Vec<T, A>` mivantana avy amin'ireo singa manta an'ny vector hafa.
    ///
    /// # Safety
    ///
    /// Izany no tena azo antoka, noho ny isan'ny invariants izay tsy avy amin'ny teny anglisy:
    ///
    /// * `ptr` mila natokana tamin'ny alàlan'ny [`String`]/`Vec<T>`(Raha kely indrindra, fa tena mety ho diso raha tsy).
    /// * `T` mila manana habe sy fampifanarahana mitovy amin'ilay natokana ho an'ny `ptr`.
    ///   (`T` manana fampifanarahana tsy dia hentitra loatra dia tsy ampy, ny fampifanarahana dia tena mila fitoviana mba hanomezana fahafaham-po ny takiana [`dealloc`] fa ny fahatsiarovana dia tsy maintsy omena sy hifanarahana amin'ny endriny mitovy.)
    ///
    /// * `length` mila latsaky ny na mitovy amin'ny `capacity`.
    /// * `capacity` mila ny fahaiza-manao izay nanondroana ny tondro.
    ///
    /// Nanitsakitsaka ireo dia mety hahatonga zava-manahirana toy ny manimba ny allocator ny angon-drakitra rafitra anatiny.Ohatra tsy dia ** ** azo antoka ny hanorina `Vec<u8>` avy amin'ny manondro ny C `char` voaomana amin'ny `size_t` halavany.
    /// Tsy azo antoka koa ny manangana iray avy amin'ny `Vec<u16>` sy ny halavany, satria ny mpizara dia miahy ny fampifanarahana, ary ireo karazany roa ireo dia samy hafa ny fampifanarahana azy.
    /// Ny buffer dia omena amin'ny fampifanarahana 2 (fa `u16`), fa rehefa mamadika izany ho `Vec<u8>` dia ho deallocated Ho amin'ny fampifanarahana 1.
    ///
    /// Ny tompon'ny `ptr` dia afindra amin'ny `Vec<T>` mahomby izay mety hifampiraharaha, hamindra na hanova ny atin'ny fahatsiarovana notondroin'ilay mpanondro araka ny sitrapony.
    /// Hamarino tsara fa tsy misy zavatra hafa mampiasa ny tondro rehefa niantso ity asa ity.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Ampivoary izany rehefa miorina tsara ny vector_into_raw_parts.
    ///     // Prévenir mihazakazaka `v` ny destructor izany tanteraka isika amin'ny fanaraha-maso ny fanomezana.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Tsoahy ireo fampahalalana marobe momba ny `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Soraty amin'ny 4, 5, 6 ny fahatsiarovana
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Ataovy ny zavatra rehetra indray miaraka an-već
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Mamolavola `Vec<T>` ho singa fototra.
    ///
    /// Miverina ny manta manondro ny tahirin-kevitra fototra, ny halavan'ny ny vector (in singa), ary ny natokana afaka ny tahirin-kevitra (ao amin'ny singa).
    /// Ireo dia mitovy hevitra amin'ny filaharana mitovy amin'ny tohan-kevitra mankany [`from_raw_parts`].
    ///
    /// Rehefa avy niantso izany ny asa, ny mpiantso no tompon'andraikitra mitantana ny fahatsiarovana teo aloha ny `Vec`.
    /// Ny hany fomba ahafahana manao izany dia ny hampiova finoana ny manta manondro, ny halavany, sy ny fahafahana miverina an-`Vec` ny [`from_raw_parts`] asa, mamela ny destructor mba hanatanteraka ny fanadiovana.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Tsy afaka hanova izao ny singa, toy ny transmuting ny manta manondro ny karazana mifanaraka.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Mamolavola `Vec<T>` ho singa fototra.
    ///
    /// Mamerina ny tondro masaka amin'ny angon-drakitra fototra, ny halavan'ny vector (amin'ny singa), ny fahafaha-mizara atokana (amin'ny singa), ary ny mpizara.
    /// Ireo dia mitovy hevitra amin'ny filaharana mitovy amin'ny tohan-kevitra mankany [`from_raw_parts_in`].
    ///
    /// Rehefa avy niantso izany ny asa, ny mpiantso no tompon'andraikitra mitantana ny fahatsiarovana teo aloha ny `Vec`.
    /// Ny fomba tokana hanaovana izany dia ny fanovana ny tondro, ny halavany ary ny fahafaha-miverina miverina ho `Vec` miaraka amin'ny asan'ny [`from_raw_parts_in`], ahafahan'ny mpanimba manatanteraka ny fanadiovana.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Tsy afaka hanova izao ny singa, toy ny transmuting ny manta manondro ny karazana mifanaraka.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Miverina ny isan'ny singa ny vector dia afaka hihazona tsy reallocating.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Mitahiry fahaiza-manao farafahakeliny `additional` singa bebe kokoa hampidirina ao amin'ny `Vec<T>` nomena.
    /// Ny famoriam-bola dia mety hitahiry toerana bebe kokoa hisorohana ny fizahana toerana matetika.
    /// Aorian'ny fiantsoana `reserve`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional`.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// # Panics
    ///
    /// Panics raha mihoatra ny `isize::MAX` bytes ny fahaiza-manao vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Reserves ny kely indrindra afaka ho tsara kokoa ny singa `additional` ho nakambana ao amin'ny nomena `Vec<T>`.
    ///
    /// Aorian'ny fiantsoana `reserve_exact`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional`.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// Mariho fa ny mpizara dia mety hanome toerana betsaka kokoa noho ny angatahany.
    /// Noho izany, ny fahaiza-manao dia tsy azo atokisana ho kely indrindra.
    /// Aleo `reserve` raha andrasana ny fampidirana future.
    ///
    /// # Panics
    ///
    /// Panics raha toa ka mihoatra `usize` ny fahafaha-manao vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Miezaka mitahiry fahaiza-manao farafahakeliny `additional` singa bebe kokoa hampidirina ao amin'ny `Vec<T>` nomena.
    /// Ny famoriam-bola dia mety hitahiry toerana bebe kokoa hisorohana ny fizahana toerana matetika.
    /// Aorian'ny fiantsoana `try_reserve`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional`.
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// # Errors
    ///
    /// Raha mihoa-pefy ny fahafaha-manao, na mitatitra ny tsy fahombiazan'ny mpizara, dia niverina ny lesoka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Arovy mialoha ny fahatsiarovana, mivoaka raha tsy vitantsika
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Fantatsika izao fa tsy afaka OOM eo afovoan'ny asa sarotra ataontsika
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tena sarotra
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Miezaka mitahiry ny fahaiza-manao farafahakeliny ho an'ny singa `additional` marina ampidirina ao amin'ny `Vec<T>` nomena.
    /// Aorian'ny fiantsoana `try_reserve_exact`, ny fahaiza-manao dia ho lehibe kokoa na mitovy amin'ny `self.len() + additional` raha miverina `Ok(())` izy.
    ///
    /// Tsy manao na inona na inona raha efa ampy ny fahaiza-manao.
    ///
    /// Mariho fa ny mpizara dia mety hanome toerana betsaka kokoa noho ny angatahany.
    /// Noho izany, ny fahaiza-manao dia tsy azo atokisana ho kely indrindra.
    /// Aleo `reserve` raha andrasana ny fampidirana future.
    ///
    /// # Errors
    ///
    /// Raha mihoa-pefy ny fahafaha-manao, na mitatitra ny tsy fahombiazan'ny mpizara, dia niverina ny lesoka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Arovy mialoha ny fahatsiarovana, mivoaka raha tsy vitantsika
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Fantatsika izao fa tsy afaka OOM eo afovoan'ny asa sarotra ataontsika
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // tena sarotra
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Mampihena ny fahafahan'ny vector araka izay azo atao.
    ///
    /// Hidina ambany araka izay azo atao ny halavany io fa ny mpanome dia mety mbola hampandre ny vector fa misy toerana ho an'ny singa vitsivitsy hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Ny fahaiza-manao dia tsy latsa-danja velively amin'ny halavany, ary tsy misy tokony hatao raha mitovy izy ireo, mba hahafahantsika misoroka ny tranga panic amin'ny `RawVec::shrink_to_fit` amin'ny fiantsoana azy fotsiny amin'ny fahaiza-manao lehibe kokoa.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Shrinks ny fahaiza ny vector tamin'ny ambany mifatotra.
    ///
    /// Ny fahaiza-manao dia hijanona farafahakeliny lehibe toy ny halavany sy ny sanda omena.
    ///
    ///
    /// Raha toa ka ambany noho ny fetra ambany ny fahafaha-miasa ankehitriny dia tsy misy izany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Manova ny vector ho [`Box<[T]>`][owned slice].
    ///
    /// Mariho fa hampihena ny fahafaha-manao tafahoatra izany.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Esorina ny fahafaha-manao tafahoatra
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Mampihena ny vector, mitazona ireo singa `len` voalohany ary mandatsaka ny ambiny.
    ///
    /// Raha lehibe kokoa noho ny halavan'ny vector ny `len` dia tsy misy vokany izany.
    ///
    /// Ny fomba [`drain`] dia afaka maka tahaka ny `truncate`, fa kosa mahatonga ireo singa be loatra hiverina fa tsy nilatsaka.
    ///
    ///
    /// Mariho fa io fomba tsy misy vokany eo amin'ny natokana afaka ny vector.
    ///
    /// # Examples
    ///
    /// Truncating ny singa dimy vector ho zavatra roa:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Tsy misy truncation miseho rehefa `len` dia lehibe noho ny amin'izao fotoana izao vector Length:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating rehefa `len == 0` dia mitovy ny fiantsoana ny [`clear`] fomba.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Izany no azo antoka satria:
        //
        // * ny silaka ampitaina amin'ny `drop_in_place` dia mitombina;ny raharaha tsy mankeny `len > self.len` mamorona ny tsy manan-kery silaka, ary
        // * ny `len` ny vector dia shrunk alohan'ny miantso `drop_in_place`, toy izany fa tsy misy vidiny ho nandatsaka indroa raha sendra `drop_in_place` nasaina ho panic indray mandeha (raha panics indroa, ny fandaharana aborts).
        //
        //
        //
        unsafe {
            // Note: Fanahy iniana fa `>` ity fa tsy `>=`.
            //       Ny fanovana azy amin'ny `>=` dia misy fiantraikany ratsy amin'ny tranga sasany.
            //       Jereo #78884 kokoa.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Voajanahary koa omen'ny silaka misy ny vector manontolo.
    ///
    /// Mitovy amin'ny `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Manala silaka azo ovaina amin'ny vector iray manontolo.
    ///
    /// Mitovy amin'ny `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Miverina tondro iray manta amin'ny buffer an'ny vector.
    ///
    /// Ny miantso dia tsy maintsy miantoka fa ny vector dia mivelona amin'ilay tondro averin'ity asany ity raha tsy izany dia hiafara amin'ny fanondroana fako.
    /// Ny fanovana ny vector dia mety hiteraka ny famindrana ny buffer azy, izay mety hahatonga ny tondro any aminy tsy mety.
    ///
    /// Dia tsy maintsy ihany koa ny mpiantso antoka fa manondro ny fahatsiarovana (non-transitively) manondro dia tsy voasoratra ho (afa-tsy ao anatin'ny iray `UnsafeCell`) mampiasa io manondro na homarinana avy amin'ny teny manondro azy.
    /// Raha mila manova ny atin'ny silaka ianao dia ampiasao [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Isika aloky ny silaka fomba mitovy anarana mba tsy mandalo `deref`, izay miteraka-kafa ny boky.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Miverina tondro azo ovaina tsy azo antoka amin'ny buffer an'ny vector.
    ///
    /// Ny miantso dia tsy maintsy miantoka fa ny vector dia mivelona amin'ilay tondro averin'ity asany ity raha tsy izany dia hiafara amin'ny fanondroana fako.
    ///
    /// Ny fanovana ny vector dia mety hiteraka ny famindrana ny buffer azy, izay mety hahatonga ny tondro any aminy tsy mety.
    ///
    /// # Examples
    ///
    /// ```
    /// // Atokana vector ampy lehibe ho an'ny singa 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Atombohy ireo singa amin'ny alàlan'ny fanoratana pointer manta, avy eo mamaritra ny halavany.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Isika aloky ny silaka fomba mitovy anarana mba tsy mandalo `deref_mut`, izay miteraka-kafa ny boky.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Miverina fanondroana ilay mpanome eo ambaniny.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Forces ny halavan'ny ny vector ho `new_len`.
    ///
    /// Ity dia fiasa ambaratonga ambany izay tsy mitazona na iza na iza ny invariants mahazatra ny karazany.
    /// Ny fanovana ara-dalàna ny halavan'ny vector dia atao amin'ny fampiasana ny iray amin'ireo fandidiana azo antoka fa tsy toy ny [`truncate`], [`resize`], [`extend`], na [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` dia tokony ho latsaka na mitovy amin'ny [`capacity()`].
    /// - Ireo singa ao amin'ny `old_len..new_len` tsy maintsy initialized.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Izany dia mety ho fomba mahasoa ny toe-javatra izay ny vector manompo ho toy ny fehezan-dalàna buffer ho an'ny hafa, indrindra fa ny FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Izany no taolana kely dia kely fotsiny ho an'ny fanononana tsy ohatra;
    /// # // aza mampiasa izany ho toy ny teboka fanombohana tranokala tena.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Araka ny tahirin-kevitry ny fomba FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // Famonjena, rehefa miverina `deflateGetDictionary` `Z_OK`, ka manana ny fa:
    ///     // 1. `dict_length` initialized singa ireo.
    ///     // 2.
    ///     // `dict_length` <=ny capacité (32_768) izay mahatonga an'i `set_len` azo antoka hiantsoana.
    ///     unsafe {
    ///         // Ataovy ny antso FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ary ny lavany vaovao farany ny zava-initialized.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Na dia tsara aza ity ohatra manaraka ity dia misy fahatapahana fahatsiarovana satria ny vectors anatiny dia tsy navotsotra talohan'ny antso `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` Foana ka tsy misy zavatra tokony initialized.
    /// // 2. `0 <= capacity` mitazona foana izay `capacity` rehetra.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Raha ny mahazatra, eto, hisy hampiasa [`clear`] tsara fa tsy mba handao ny anatiny, ka tsy mandefa fahatsiarovana.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Manala singa iray amin'ny vector ary mamerina azy.
    ///
    /// Ny singa nesorina dia nosoloin'ny singa farany an'ny vector.
    ///
    /// Tsy mitahiry ny filaminana izany fa O(1).
    ///
    /// # Panics
    ///
    /// Panics raha `index` dia avy amin'ny fetra.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Manolo ny tenantsika [index] amin'ny singa farany izahay.
            // Mariho fa raha mahomby ny fizahana fetra etsy ambony dia tsy maintsy misy singa farany (izay mety ho ny tenany [index] mihitsy).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Manisika ny singa ao amin'ny toerana `index` ao anatin'ny vector, miovaova singa rehetra rehefa ho amin'ny tsara.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // toerana ho an'ny singa vaovao
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible Ny toerana hametrahana ny sanda vaovao
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Fiovàna ny zava-drehetra ny hanaovana toerana.
                // (Mametaka ny singa `index`th ho toerana roa misesy.)
                ptr::copy(p, p.offset(1), len - index);
                // Hosoratako ao, overwriting voalohany dika mitovy amin'ny: index`th singa.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Manala sy mamerina ilay singa amin'ny toerana `index` ao anatin'ny vector, manova ny singa rehetra aorian'io ho amin'ny ankavia.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `index` dia avy amin'ny fetra.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // ny toerana alainay.
                let ptr = self.as_mut_ptr().add(index);
                // adikao izy io, tsy manana tahiry mitovy amin'ilay sanda amin'ny stack ianao ary ao amin'ny vector miaraka amin'izay.
                //
                ret = ptr::read(ptr);

                // Fiovàna ny zava-drehetra any amin'ny toerana drà any izany.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Ireo singa notondroin'ny predicate ihany no tazonina.
    ///
    /// Raha atao teny hafa, esory ny singa `e` rehetra toy izany `f(&e)` mamerina `false`.
    /// Ity fomba ity dia miasa amin'ny toerany, mitsidika ny singa tsirairay avy indray mandeha amin'ny filaharana tany am-boalohany, ary mitahiry ny filaharan'ny singa tazonina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Satria ny singa dia zahana indray mandeha katroka amin'ny filaharana tany am-boalohany, ny fanjakana ivelany dia azo ampiasaina hanapahana izay singa tazomina.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Sorohy ny fidinana indroa raha toa ka tsy novonoina ilay mpiambina satria mety hanao lavaka kely isika mandritra ny fizotrany.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-nokarakaraina len-> |^-manaraka hanamarinana
        //                  | <-voafafa cnt-> |
        //      | <-original_len-> |Tazonina: ireo singa izay predicate dia miverina marina amin'ny.
        //
        // Hole: Nafindra na nandatsaka singa slot.
        // Tsy voamarina: singa tsy voamarina tsy voamarina.
        //
        // Izany mitete mpiambina dia azo hampiharina rehefa enti-na `drop` ny singa raiki-tahotra.
        // Tsy voafehy singa mpiasa miasa amin'ny rakotra fanaovam-panavotana sy `set_len` lavaka ho an'ny marina ny halavany.
        // Raha sendra predicate sy `drop` dia tsy hikorontana na oviana na oviana, dia havaozina izy.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SAFETY: Ireo entana tsy voamarina dia tsy maintsy mitombina satria tsy mikasika azy ireo mihitsy isika.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SAFETY: Aorian'ny famenoana ny lavaka dia ao anaty fahatsiarovana mifanentana daholo ny entana rehetra.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SAFETY: Ny singa tsy voamarina dia tsy maintsy mitombina.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Mandrosoa aloha mba hisorohana ny filatsahana indroa raha mikorontana ny `drop_in_place`.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SAFETY: Tsy mikasika an'ity singa ity intsony izahay taorian'ny nilatsaka.
                unsafe { ptr::drop_in_place(cur) };
                // Efa nandroso ny kaontera izahay.
                continue;
            }
            if g.deleted_cnt > 0 {
                // Famonjena, `deleted_cnt`> 0, toy izany koa ny lavaka slot tsy tokony hifanindry amin'ny singa amin'izao fotoana izao.
                // Mampiasà kopia hifindra izahay ary tsy hikasika an'io singa io intsony.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Ny entana rehetra dia voahodina.Izany dia azo hatsaraina amin'ny `set_len` avy amin'i LLVM.
        drop(g);
    }

    /// Esorina daholo fa ny singa voalohany mifandimby ao amin'ny vector izay mivaha amin'ny fanalahidy mitovy.
    ///
    ///
    /// Raha nalamina ny vector dia esorina daholo ireo duplicate ireo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Manala ny rehetra afa-tsy ny singa voalohany misesy ao amin'ny vector manome fahafaham-po ny fifandraisana fitoviana nomena.
    ///
    /// Ny asa `same_bucket` dia lasa soratra masina ny singa roa avy amin'ny vector ary tsy maintsy hamaritra raha mampitaha ny zavatra mitovy.
    /// Ireo singa dia ampitaina amin'ny filaharana mifanohitra amin'ny filaharany ao anaty silaka, ka raha miverina `true` i `same_bucket(a, b)` dia esorina ny `a`.
    ///
    ///
    /// Raha nalamina ny vector dia esorina daholo ireo duplicate ireo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Manampy singa ao ambadiky ny fanangonana.
    ///
    /// # Panics
    ///
    /// Panics raha mihoatra ny `isize::MAX` bytes ny fahaiza-manao vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Ity dia panic na esorina raha toa ka manokana> by00 isize::MAX na raha toa ka mihoa-pefy ny fisondrotana lava ho an'ny karazana tsy refy.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Esory ny singa farany amin'ny vector ary avereno, na [`None`] raha foana izy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Mamindra ny singa `other` rehetra mankany `Self`, mamela `other` foana.
    ///
    /// # Panics
    ///
    /// Panics raha ny isan'ny singa ao amin'ny vector Tondraka ny `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Manampy singa mankany `Self` avy amin'ny buffer hafa.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Miteraka kosa natopiny iterator no nanesotra ny lasa mihamatanjaka ny isan-karazany ao amin'ny vector sy ka nanaraka ny Nesorin'i zavatra.
    ///
    /// Rehefa iterator ** ** no nandatsaka, singa rehetra ao amin'ny isan-karazany dia esorina avy amin'ny vector, na dia ny iterator tsy levona tanteraka.
    /// Raha tsy nidina ilay iterator ** (miaraka amin'ny [`mem::forget`] ohatra) dia tsy voafaritra mazava hoe firy ny singa esorina.
    ///
    /// # Panics
    ///
    /// Panics raha ny teboka fanombohana dia lehibe kokoa noho ny teboka farany na raha lehibe kokoa noho ny halavan'ny vector ny teboka farany.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Ny faritra feno dia manadio ny vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Fiarovana amin'ny fahatsiarovana
        //
        // Rehefa noforonina voalohany ny Drain dia manafoana ny halavan'ny loharano vector izy io mba hahazoana antoka fa tsy misy idirana tsy fantatra na nafindra-avy amin'ireo singa azo idirana mihitsy raha toa ka tsy afaka mihazakazaka mihitsy ilay mpanimba ny Drain.
        //
        //
        // Drain dia hamoaka ptr::read ireo soatoavina esorina.
        // Rehefa vita, sisa rambo ny već dia kopia hiverina hanarona ny lavaka, ary ny lavany dia vector indray ny halavan'ny vaovao.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // apetraho ny halavan'ny self.vec hanombohana, ho azo antoka raha tafaporitsaka ny Drain
            self.set_len(start);
            // Ampiasao ny findramam-bola ao amin'ny IterMut hanondroana ny fihetsiky ny findramana ny iterator Drain iray manontolo (toy ny &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Manadio ny vector, manala ny sanda rehetra.
    ///
    /// Mariho fa io fomba tsy misy vokany eo amin'ny natokana afaka ny vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Miverina ny isan'ny singa ao amin'ny vector, koa dia antsoina hoe ny 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Miverina `true` raha tsy misy singa ny vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Mizara roa ny fanangonana amin'ny index nomena.
    ///
    /// Miverina vector vao natokana misy ireo singa ao amin'ny faritra `[at, len)`.
    /// Aorian'ny antso, ny sisa vector dia avela misy ny singa `[0, at)` miaraka amin'ny fahaiza-manao teo aloha tsy miova.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // ny vector vaovao dia afaka maka ny buffer tany am-boalohany ary manalavitra ny kopia
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` tsy azo antoka ary adikao amin'ny `other` ireo entana.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Manova ny haben'ny `Vec` amin'ny toerany ka mitovy ny `len` amin'ny `new_len`.
    ///
    /// Raha lehibe kokoa ny `new_len` noho ny `len`, ny `Vec` dia itarina amin'ny fahasamihafana, isaky ny slot fanampiny feno ny valin'ny fiantsoana ny fikatonan'ny `f`.
    ///
    /// Ny sanda miverina avy amin'ny `f` dia hiafara amin'ny `Vec` araka ny filaharana namboarina.
    ///
    /// Raha `new_len` dia kely noho `len`, ny `Vec` truncated fotsiny.
    ///
    /// Mampiasa fomba iray ity mba hamoronana fanakatonana soatoavina vaovao hanoto ny teny rehetra.Raha toa ianao tsy mazoto [`Clone`] ny sanda nomena, fampiasana [`Vec::resize`].
    /// Raha te hampiasa ny [`Default`] trait ianao hiteraka soatoavina dia azonao atao ny mandingana ny [`Default::default`] ho toy ny adihevitra faharoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Manjifa sy mamoaka ny `Vec`, mamerina manondro ny votoatiny azo ovaina. `&'a mut [T]`.
    /// Mariho fa ny karazana `T` dia tsy maintsy mihoatra ny androm-piainana voafidy `'a`.
    /// Raha tsy misy static references fotsiny ilay karazana, na tsy misy mihitsy, dia azo fidina `'static` ity.
    ///
    /// Ity fiasa ity dia mitovy amin'ny asan'ny [`leak`][Box::leak] amin'ny [`Box`] afa-tsy ny tsy misy fomba hamerenana ny fahatsiarovana tafaporitsaka.
    ///
    ///
    /// Ilaina indrindra io asa io amin'ny data izay miaina mandritra ny androm-piainan'ny programa.
    /// Ny fampiatoana ny referansa naverina dia hiteraka fahatapahan'ny fahatsiarovana.
    ///
    /// # Examples
    ///
    /// Fampiasana tsotra:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Miverina ny sisa tavela amin'ny vector ho tapa-`MaybeUninit<T>`.
    ///
    /// Ny silaka tafaverina dia azo ampiasaina hamenoana ny data vector (oh
    /// amin'ny alalan'ny famakiana avy amin'ny rakitra) alohan'ny nanamarika ny angon-drakitra araka ny initialized mampiasa ny fomba [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Atokana vector ampy lehibe ho an'ny singa 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Fenoy ny voalohany 3 singa.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marka 3 singa voalohany amin'ny vector toy ny hoe initialized.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ity fomba ity dia tsy ampiharina amin'ny `split_at_spare_mut`, hisorohana ny fanesorana ireo tondro mankany amin'ny buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Miverina ny atiny vector ho toy ny sombin-`T`, miaraka amin'ny fahafaha-mitahiry sisa tavela an'ny vector ho tapa-`MaybeUninit<T>`.
    ///
    /// Ny sombin-tsolika miverina miverina dia azo ampiasaina hamenoana ny vector amin'ny angona (oh: amin'ny famakiana amin'ny fisie) alohan'ny hanisy marika ny angon-drakitra ho fanombohana amin'ny fampiasana ny fomba [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Mariho fa API ambany ity, izay tokony hampiasaina amin'ny fikarakarana ny tanjona fanatsarana.
    /// Raha toa ka mila ny append antontan-kevitra amin'ny `Vec` azonao ampiasaina [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] na [`resize_with`], arakaraka ny zavatra ilaina marina.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Mitehiriza toerana fanampiny ampy ho an'ny singa 10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Fenoy ireo singa 4 manaraka.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Mariho ireo singa 4 an'ny vector ho voalohany.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len tsy raharahina ary tsy miova mihitsy
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Fiarovana: miova miverina .2 (&mut usize) dia heverina ho toy ny miantso `.set_len(_)`.
    ///
    /// Ity fomba ity dia ampiasaina hananana fidirana tokana amin'ireo faritra vector rehetra indray mandeha amin'ny `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` dia azo antoka fa manan-kery ho an'ny singa `len`
        // - `spare_ptr` manondro singa iray lasa ny buffer, noho izany tsy mifanindry amin'ny `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Manova ny haben'ny `Vec` amin'ny toerany ka mitovy ny `len` amin'ny `new_len`.
    ///
    /// Raha `new_len` dia lehibe noho `len`, ny `Vec` dia mivelatra ny maha samy hafa, isaky ny slot fanampiny feno `value`.
    ///
    /// Raha `new_len` dia kely noho `len`, ny `Vec` truncated fotsiny.
    ///
    /// Ity fomba ity dia mitaky `T` hampihatra [`Clone`], hahafahana mana-clone ny sanda nandalo.
    /// Raha mila malefaka kokoa ianao (na te hiantehitra amin'ny [`Default`] fa tsy [`Clone`]), ampiasao [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones ary mampiditra ny singa rehetra ao anaty slice mankany amin'ny `Vec`.
    ///
    /// Mametaka ny sombintsombin'ny `other`, mandahatra ny singa tsirairay avy eo ary mampiditra azy io amin'ity `Vec` ity.
    /// Ny `other` vector dia nitety an-trano.
    ///
    /// Mariho fa ity fiasa ity dia mitovy amin'ny [`extend`] afa-tsy ny manampahaizana manokana hiasa miaraka amin'ny silaka.
    ///
    /// Raha sy rehefa oviana i Rust mahazo specialization dia mety tsy hanana izany asa izany intsony (fa mbola misy).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Dika mitovy singa avy `src` miainga hatramin'ny farany ny vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` manome antoka fa ny laharana nomena dia manan-kery ho an'ny tenany manokana
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ity kaody ity dia manaparitaka ny `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Hanitatra ny vector amin'ny `n` soatoavina, mampiasa ny nomena gropy.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Ampiasao SetLenOnDrop hiasa manodidina bug izay mety tsy mahatsapa ny magazay amin'ny alàlan'ny `ptr` amin'ny alàlan'ny self.set_len() ny mpamorona.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Soraty singa rehetra, afa-tsy ny farany
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Ampitomboy ny halavany amin'ny dingana rehetra raha toa ka next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Afaka manoratra ny singa farany mivantana Fanamboarana tsy amin'ny antony
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len napetraky ny mpiambina ambaratonga
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Mamindra misesy zavatra miverimberina ao amin'ny vector araka ny [`PartialEq`] trait fampiharana.
    ///
    ///
    /// Raha nalamina ny vector dia esorina daholo ireo duplicate ireo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Anatiny fomba sy ny asa
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` mila fanondroana mety
    /// - `self.capacity() - self.len()` tsy maintsy `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - Ny len dia ampitomboina aorian'ny fanombohana singa
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - mpiantso dia manome toky fa src dia index mety
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Vao natsangana tamin'ny `MaybeUninit::write` ny singa, ka tsy maninona ny manatsara ny len
            // - Mitombo ny len aorian'ny singa tsirairay hisorohana ny famoahana (jereo ny laharana #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - mpiantso dia manome antoka fa `src` dia index mety
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Ireo tondro roa ireo dia noforonina avy amin'ny fanovozan-kevitra slice tokana (`&mut [_]`) ka mitombina ary tsy mifanindry.
            //
            // - Singa ireo: Copy dia tsy maninona ny haka tahaka azy ireo, tsy manao na inona na inona amin'ny tany am-boalohany soatoavina
            // - `count` dia mitovy amin'ny len an'ny `source`, ka ny loharano dia manan-kery amin'ny famakiana `count`
            // - `.reserve(count)` manome antoka fa `spare.len() >= count` ka ny tahiry dia manan-kery ho an'ny `count` manoratra
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Ireo singa dia vao nanomboka ny `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Fampiharana trait mahazatra ho an'ny Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): miaraka cfg(test) ny fomba `[T]::to_vec` voajanahary, izay takiana amin'ity famaritana fomba ity dia tsy misy.
    // Raha tokony hampiasa ny `slice::to_vec` asa izay ihany no hita amin'ny cfg(test) NB mahita ny slice::hack Module in slice.rs Raha mila fanazavana fanampiny
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // Mitete na inona na inona izay tsy ho overwritten
        self.truncate(other.len());

        // self.len <= other.len noho ny truncate etsy ambony, noho izany ny slices eto dia in-fetra foana.
        //
        let (init, tail) = other.split_at(self.len());

        // ampiasao indray ireo sanda misy allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Mamorona iterator mandevona, izany hoe, izay mampihetsika ny sanda tsirairay avy ao amin'ny vector (manomboka amin'ny voalohany ka hatramin'ny farany).
    /// Ny vector dia tsy azo ampiasaina aorian'ny fiantsoana an'ity.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s misy karazana String fa tsy &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // fomba ravina anaovan'ny fampiharana SpecFrom/SpecExtend isan-karazany rehefa tsy misy fanatsarana azo ampiharina intsony
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Izany no nitranga noho ny ankapobeny iterator.
        //
        // Ity asa ity dia tokony hitovy amin'ny:
        //
        //      ny zavatra ao iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Ny NB dia tsy afaka misondrotra satria tsy maintsy nanokana ny habaka adiresy izahay
                self.set_len(len + 1);
            }
        }
    }

    /// Miteraka splicing iterator izay manolo ny voafaritra ao amin'ny vector isan-karazany miaraka amin'ny nomena `replace_with` iterator ary ka nanaraka ny Nesorin'i zavatra.
    ///
    /// `replace_with` tsy mila hitovy halava amin'ny `range`.
    ///
    /// `range` esorina na dia tsy lanina hatramin'ny farany aza ilay miverina.
    ///
    /// Tsy singa Tsy lazaina firy no nesorina avy amin'ny vector raha ny `Splice` sarobidy no tafaporitsaka.
    ///
    /// Ny input iterator `replace_with` dia lany fotsiny rehefa nilatsaka ny sanda `Splice`.
    ///
    /// Tsara indrindra izany raha:
    ///
    /// * Ny rambony (singa ao amin'ny vector aorian'ny `range`) dia foana,
    /// * na `replace_with` dia mamokatra singa vitsy na mitovy noho ny halavan'ny `range`
    /// * na ny fetra ambany an'ny `size_hint()` dia marina.
    ///
    /// Raha tsy izany, dia tsy maharitra dia omena vector sy ny rambony dia nifindra indroa.
    ///
    /// # Panics
    ///
    /// Panics raha ny teboka fanombohana dia lehibe kokoa noho ny teboka farany na raha lehibe kokoa noho ny halavan'ny vector ny teboka farany.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Mamorona iterator izay mampiasa fanakatonana hamaritana raha tokony esorina ny singa iray.
    ///
    /// Raha miverina marina ny fanidiana dia esorina ary omena ny singa.
    /// Raha miverina amin'ny laoniny ny fanidiana dia mijanona ao amin'ny vector ilay singa ary tsy omen'ny iterator.
    ///
    /// Ny fampiasana an'io fomba io dia mitovy amin'ny kaody manaraka ireto:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ny kaody eto
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Fa ny `drain_filter` dia mora ampiasaina kokoa.
    /// `drain_filter` dia mahomby kokoa ihany koa, satria izy io dia afaka mampihemotra ny singa amin'ny laharana amin'ny ankapobeny.
    ///
    /// Mariho fa `drain_filter` dia mamela anao hanova ny singa rehetra amin'ny fanidiana ny sivana, na inona na inona safidinao hitazona na esorina.
    ///
    ///
    /// # Examples
    ///
    /// Fampisarahana ny tsipika iray amin'ny tsipika sy ny mety, ampiasaina indray ny fizarana tany am-boalohany:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Mitandrema amin'izay antsika hatao tafaporitsaka (mandefa amplification)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Hanitatra fametrahana izay mandika singa avy amin'ny andinin-tsoratra masina eo anatrehan'i manosika azy ireo teo amin'ny već.
///
/// Io no fampiharana manokana ho silaka iterators, izay mampiasa [`copy_from_slice`] mba append silaka iray manontolo avy hatrany.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Mampihatra ny fampitahana ny vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Mampihatra ny baikon'ny vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // fampiasana mitete for [T] mampiasa manta silaka mba hilazana ny singa ao amin'ny vector ho osa indrindra ilaina karazana;
            //
            // fanontaniana tsy mety ny toe-javatra sasany kery amin'ny
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec dia mitantana ny fifanolanana
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Mamorona `Vec<T>` foana.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: ny fitsapana dia misintona libstd, izay miteraka lesoka eto
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: ny fitsapana dia misintona libstd, izay miteraka lesoka eto
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Mahazo ny rehetra ny `Vec<T>` anatiny toy ny nitsangana, raha ny habeny tena mifanaraka ny an'ny nangataka fihaingoana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Raha tsy mifanaraka ny halavany dia miverina amin'ny `Err` ny fidirana:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Raha tsy maninona ianao raha mahazo prefet an'ny `Vec<T>` dia azonao atao ny miantso [`.truncate(N)`](Vec::truncate) aloha.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SAFETY: `.set_len(0)` dia milamina foana.
        unsafe { vec.set_len(0) };

        // SAFETY: mifanitsy tsara foana ny mpanondro ny «Vec`, ary
        // ny fampifanarahana ilain'ny filaharana dia mitovy amin'ny entana.
        // Nanamarina teo aloha izahay fa manana entana ampy.
        // Ireo entana dia tsy hampidina in-droa satria ny `set_len` dia milaza amin'ny `Vec` mba tsy hampidina azy ireo ihany koa.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}