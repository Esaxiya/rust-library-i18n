//! Fijerena mitovy habe amin'ny dinamika, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Ny slices dia fijerena loziska fahatsiarovana soloina ho toy ny tondro sy halavana.
//!
//! ```
//! // slicing ny već
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // hanerena ny voaomana ho silaka
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Ny silaka dia azo ovaina na zaraina.
//! Ny karazana slice nozaraina dia `&[T]`, raha ny karazana slice azo ovaina dia `&mut [T]`, izay `T` dia maneho ny karazana singa.
//! Ohatra, azonao atao ny manova ny sakana fahatsiarovana izay tondroin'ny miovaova miovaova amin'ny:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ireto ny sasany amin'ireo zavatra Module ity dia mirakitra:
//!
//! ## Structs
//!
//! Maro ireo structs izay ilaina ho an'ny slices, toy ny [`Iter`], izay maneho iteration nandritra ny silaka.
//!
//! ## Trait Implementations
//!
//! Misy fampiharana maromaro ny traits mahazatra ho an'ny tsiro.Ohatra vitsivitsy amin'izany:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ho an'ny silaka misy karazany [`Eq`] na [`Ord`].
//! * [`Hash`] - ho an'ny silaka izay karazana singa dia [`Hash`].
//!
//! ## Iteration
//!
//! Mampihatra `IntoIterator` ireo sombin-tsakafo.Ny iterator dia manome firesahana ireo singa slice.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Ny silaka azo ovaina dia manome fanondroana miovaova amin'ireo singa:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Io andinin-tsoratra masina iterator mutable mahavokatra ny silaka ny singa, ka raha ny singa karazana ny silaka dia `i32`, ny singa karazana ny iterator no `&mut i32`.
//!
//!
//! * [`.iter`] ary [`.iter_mut`] no fomba mazava hamerenana ireo iterator default.
//! * Fomba fanampiny miverimberina iterator dia [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ary maro hafa.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Betsaka ny fampiasana ato amin'ity modely ity no ampiasaina amin'ny fikirakirana ny fanandramana.
// Madio kokoa ny mamono ny fampitandremana tsy ampiasaina_imports toy izay manamboatra azy ireo.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Fomba fanitarana slice ifotony
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) ilaina amin'ny fampiharana ny makro `vec!` mandritra ny fanandramana NB, jereo ny modely `hack` amin'ity rakitra ity raha mila fanazavana fanampiny.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) ilaina amin'ny fampiharana ny `Vec::clone` mandritra ny fanandramana NB, jereo ny modely `hack` amin'ity rakitra ity raha mila fanazavana fanampiny.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Amin'ny cfg(test) `impl [T]` dia tsy misy, ireo asa telo ireo fomba marina izay ao `impl [T]` fa tsy amin'ny `core::slice::SliceExt`, dia mila manome ireo asa ho an'ny `test_permutations` fitsapana
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Tsy tokony ampidirintsika io toetra io satria ampiasaina amin'ny makro `vec!` ny ankamaroany ary miteraka famerenan'ny perf.
    // Jereo #71204 raha mila valim-pifanakalozan-kevitra sy perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ireo entana dia nasiana marika tamin'ny loop teo ambany
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ilaina amin'ny LLVM hanala ireo fanamarinana fetra ary manana codegen tsara kokoa noho ny zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // ny vector dia natokana ary natomboka tany ambony farafaharatsiny mba halavany.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // natokana etsy ambony miaraka amin'ny fahafahan'ny `s`, ary alao amin'ny `s.len()` amin'ny ptr::copy_to_non_overlapping etsy ambany.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sivanina ny silaka.
    ///
    /// Ity karazana ity dia milamina (ie, tsy mamerina mandamina singa mitovy) ary ny *O*(*n*\*log(* n*)) tranga ratsy indrindra.
    ///
    /// Raha azo atao, miovaova fanasokajiana dia nisafidy satria haingana kokoa noho ny tranon'omby ankapobeny manavaka ary tsy zarao mpanampy fahatsiarovana.
    /// Jereo [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm ankehitriny dia fampifangaroana fampifanarahana miovaova, aingam-panahy avy amin'ny [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Natao ho haingana be izy io amin'ny toe-javatra saika voasokajy ilay silaka, na misy filaharana milamina roa na maromaro mifangaro mifandimby.
    ///
    ///
    /// Izy io koa dia mizara fitehirizana vonjimaika ny antsasaky ny haben'ny `self`, fa ho an'ny silaka fohy kosa dia karazana fampidirana tsy mizara no ampiasaina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sivanina miaraka amina asa fampitahana ilay silaka.
    ///
    /// Ity karazana ity dia milamina (ie, tsy mamerina mandamina singa mitovy) ary ny *O*(*n*\*log(* n*)) tranga ratsy indrindra.
    ///
    /// Ny fampitahana dia tsy maintsy mamaritra famaritana tanteraka ho an'ny singa ao amin'ilay silaka.Raha tsy feno ny fandefasana dia tsy voafaritra mazava ny filaharan'ireo singa.
    /// Ny baiko dia tanteraka raha mba (ho an'ny rehetra `a`, `b` sy `c`):
    ///
    /// * total sy antisymmetric: marina ny iray amin'ny `a < b`, `a == b` na `a > b` dia marina, ary
    /// * transitive, `a < b` ary `b < c` dia midika `a < c`.Ny mitovy dia tsy maintsy mihazona ho an'ny `==` sy `>`.
    ///
    /// Ohatra, na dia tsy mampihatra [`Ord`] aza i [`f64`] satria `NaN != NaN`, azontsika atao ny mampiasa `partial_cmp` ho toy ny lahasa fanaovan-tsika rehefa fantatsika fa tsy misy `NaN` ilay sombina.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Raha azo atao, miovaova fanasokajiana dia nisafidy satria haingana kokoa noho ny tranon'omby ankapobeny manavaka ary tsy zarao mpanampy fahatsiarovana.
    /// Jereo [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm ankehitriny dia fampifangaroana fampifanarahana miovaova, aingam-panahy avy amin'ny [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Natao ho haingana be izy io amin'ny toe-javatra saika voasokajy ilay silaka, na misy filaharana milamina roa na maromaro mifangaro mifandimby.
    ///
    /// Izy io koa dia mizara fitehirizana vonjimaika ny antsasaky ny haben'ny `self`, fa ho an'ny silaka fohy kosa dia karazana fampidirana tsy mizara no ampiasaina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // fanasokajiana
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sivanina ilay sombin-kazo miaraka amina lahasa fanonganana manan-danja
    ///
    /// Ity karazana ity dia milamina (ie, tsy mamerina mandahatra singa mitovy) sy *O*(*m*\* * n *\* log(*n*)) tranga ratsy indrindra, izay *O*(*m*) no fiasa fototra.
    ///
    /// Fa manan-danja lafo vidy fiasan'ny (oh:
    /// fiasa izay tsy fidirana amin'ny trano tsotra na fandidiana ifotony), [`sort_by_cached_key`](slice::sort_by_cached_key) dia mety ho haingana kokoa, satria tsy mamerina ny lakilen'ny singa.
    ///
    ///
    /// Raha azo atao, miovaova fanasokajiana dia nisafidy satria haingana kokoa noho ny tranon'omby ankapobeny manavaka ary tsy zarao mpanampy fahatsiarovana.
    /// Jereo [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm ankehitriny dia fampifangaroana fampifanarahana miovaova, aingam-panahy avy amin'ny [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Natao ho haingana be izy io amin'ny toe-javatra saika voasokajy ilay silaka, na misy filaharana milamina roa na maromaro mifangaro mifandimby.
    ///
    /// Izy io koa dia mizara fitehirizana vonjimaika ny antsasaky ny haben'ny `self`, fa ho an'ny silaka fohy kosa dia karazana fampidirana tsy mizara no ampiasaina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sivanina ilay sombin-kazo miaraka amina lahasa fanonganana manan-danja
    ///
    /// Mandritra ny fanasokajiana, ny fiasa lehibe dia antsoina indray mandeha isaky ny singa.
    ///
    /// Izao dia marin-toerana (izany hoe, moa ve tsy reorder mitovy singa) ary *O*(*m*\* * N *+* N *\* log(*n*)) ratsy indrindra-tranga, izay misy ny fototra asany dia *O*(*M*) .
    ///
    /// Ho an'ny fiasa fototra tsotra (oh: ny fampiasa amin'ny fidirana amin'ny trano na fiasana ifotony), mety ho haingana kokoa i [`sort_by_key`](slice::sort_by_key).
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm amin'izao fotoana izao dia mifototra amin'ny [pattern-defeating quicksort][pdqsort] avy amin'i Orson Peters, izay manambatra ny tranga antonony haingana ny quicksort randomized sy ny tranga ratsy indrindra amin'ny heapsort, raha toa ka mahatratra ny fotoana maharitra amin'ny sombin-kazo miaraka amina lamina sasany.
    /// Mampiasa randomisation kely izy hialana amin'ny tranga mihasimba, fa miaraka amin'ny seed raikitra mba hanomezana fitondran-tena maharitra.
    ///
    /// Ao amin'ny tranga ratsy indrindra, ny algorithm allocates vetivety fitehirizana tao amin'ny `Vec<(K, usize)>` ny lavan'ny silaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Makro mpanampy amin'ny fanondroana ny vector antsika amin'ny karazana kely indrindra azo atao, hampihenana ny fizarana.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Ny singa `indices` dia miavaka, satria voatanisa, noho izany ny karazana rehetra dia ho marin-toerana manoloana ny sombin-tany tany am-boalohany.
                // Mampiasa `sort_unstable` izahay eto satria tsy dia kely loatra ny fizarana fitadidiana.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Adikao `self` ho `Vec` vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Eto, `s` sy `x` dia azo ovaina tsy miankina.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Adikao `self` ho `Vec` vaovao miaraka amin'ny mpizara.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Eto, `s` sy `x` dia azo ovaina tsy miankina.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, dia jereo ny `hack` Module ity antontan-taratasy ho an'ny antsipirihany bebe kokoa.
        hack::to_vec(self, alloc)
    }

    /// Mivadika `self` ho vector tsy misy clones na fizarana.
    ///
    /// Ny vector vokatr'izany dia azo avadika ho boaty amin'ny alàlan'ny `Vec<T>`` Fomba `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` tsy azo ampiasaina intsony satria efa navadika ho `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, dia jereo ny `hack` Module ity antontan-taratasy ho an'ny antsipirihany bebe kokoa.
        hack::into_vec(self)
    }

    /// Mamorona vector amin'ny famerimberenana slice `n` fotoana.
    ///
    /// # Panics
    ///
    /// Ity fiasa ity dia panic raha toa ka mihoatra ny tondra-drano.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic eo ambonin'ny safotra:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Raha `n` dia lehibe kokoa noho ny aotra, dia mety hitresaka toy ny `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` dia ny isa soloin'ny '1' farany havia an'ny `n`, ary `rem` no ampahany sisa amin'ny `n`.
        //
        //

        // Mampiasa `Vec` hiditra amin'ny `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` Ny famerimberenana dia atao amin'ny alàlan'ny avo roa heny `buf` `expn`-fotoana.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Raha `m > 0` dia misy sisa tavela hatramin'ny '1' farany havia.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` manana `self.len() * n` fahaizana.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=N 2 ^ expn`) famerenana atao amin'ny alalan'ny fandikana voalohany `rem` AHOAN avy `buf` mihitsy.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Tsy mifandona izany hatramin'ny `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` mitovy amin'ny `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Mamelatra ny sombin-`T` ho `Self::Output` sanda tokana.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Mamelatra ny sombin-`T` ho `Self::Output` sanda tokana, mametraka mpampisaraka nomena eo anelanelany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Mamelatra ny sombin-`T` ho `Self::Output` sanda tokana, mametraka mpampisaraka nomena eo anelanelany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Miverina ny vector misy ny dika mitovy io silaka izay byte tsirairay dia marika ASCII tsarintany ho any amin'ny raharaha ambony mitovy.
    ///
    ///
    /// Ny litera ASCII 'a' ka hatramin'ny 'z' dia mapafao amin'ny 'A' ka hatramin'ny 'Z', fa ny litera tsy ASCII tsy miova.
    ///
    /// Raha te-hametraka ny soatoavina eo an-toerana dia ampiasao ny [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Miverina vector misy kopian'ity sombin-kazo ity izay misy sarintany tsirairay amin'ny sarintany mitovy amin'ny ASCII ambany.
    ///
    ///
    /// Marika ASCII taratasy 'A' ho 'Z' dia tsarintany ny 'a' ho 'z', fa tsy marika ASCII taratasy dia niova.
    ///
    /// Raha hampidina ny sandam-bola eo an-toerana dia ampiasao ny [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extension traits ho an'ny kapoaka amin'ny karazana data manokana
////////////////////////////////////////////////////////////////////////////////

/// Mpanampy trait an'ny [`[T]: : concat`](slice::concat).
///
/// Note: ny masontsivana karazana `Item` dia tsy ampiasaina amin'ity trait ity, fa mamela ny impls ho generic kokoa.
/// Raha tsy misy izany dia mahazo ity lesoka ity isika:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Izany dia satria mety misy karazana `V` misy `Borrow<[_]>` impls marobe, toy izany koa ny karazana `T` marobe:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ny karazana vokatr'izany aorian'ny concatenation
    type Output;

    /// Fampiharana ny [`[T]: : concat`](silaka::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Mpanampy trait an'ny [`[T]: : manambatra`](tapa::manatevin-daharana)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Ny karazana vokatr'izany aorian'ny concatenation
    type Output;

    /// Fampiharana ny [`[T]: : manambatra`](silaka::manatevin-daharana)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Fampiharana mahazatra trait ho an'ny silaka
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // mandatsaka zava-kendrena izay tsy hosoratana
        target.truncate(self.len());

        // target.len <= self.len noho ny truncate etsy ambony, noho izany ny slices eto dia in-fetra foana.
        //
        let (init, tail) = self.split_at(target.len());

        // ampiasao indray ireo sanda misy allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Ampidiro ao anaty filaharana `v[1..]` ny `v[0]` ka lasa milamina ny `v[..]` manontolo.
///
/// Ity no subroutine tsy mitongilana amin'ny karazana insertion.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Misy fomba telo hampiharana ny fampidirana eto:
            //
            // 1. Ampifamadiho ireo singa mifanila aminy mandra-pahatongan'ny voalohany amin'ilay toerana nalehany.
            //    Saingy, ity fomba ity dia maka tahaka ny angon-drakitra mihoatra ny ilaina izahay.
            //    Raha singa lehibe ireo rafitra (lafo ny maka tahaka azy) dia hiadana ity fomba ity.
            //
            // 2. Ampidiro mandra-pahatongan'ny toerana mety ho an'ny singa voalohany.
            // Avereno avy eo ireo singa nandimby azy mba hanome toerana ho azy ary apetraho amin'ny lavaka sisa tavela.
            // Ity dia fomba tsara.
            //
            // 3. Adikao ny singa voalohany ho vonjimaika miova.Ampidiro mandra-pahatongan'ny toerana mety azy.
            // Rehefa mandeha isika, alaivo kopia ao anaty ilay slot alohan'io ny singa rehetra nandalo azy.
            // Farany, handika angona avy amin'ny vonjimaika miova ho any amin'ny sisa tavela lavaka.
            // Izany no fomba tsara indrindra izany.
            // Ny benchmark dia nampiseho fahombiazana somary tsara kokoa noho ny tamin'ny fomba faha-2.
            //
            // Ny fomba rehetra dia nasiana refy, ary ny faha-3 dia naneho vokatra tsara indrindra.Ka io no nofidinay.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Anelanelany toetry ny fampidirana dingana fantarina foana ny `hole`, izay manompo tanjona roa:
            // 1. Miaro ny tsy fivadihan'ny `v` amin'ny panics amin'ny `is_less`.
            // 2. Fenoy ny lavaka sisa tavela amin'ny `v` amin'ny farany.
            //
            // Panic fiarovana:
            //
            // Raha `is_less` panics amin'ny fotoana rehetra mandritra ny fizotrany, `hole` dia hidina ary hameno ny lavaka ao `v` amin'ny `tmp`, ka hiantohana fa `v` dia mitazona ny zavatra rehetra notazoniny voalohany indray mandeha.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` milatsaka ary avy eo kopian'ny `tmp` ao anaty lavaka sisa tavela amin'ny `v`.
        }
    }

    // Rehefa nilatsaka dia kopia avy amin'ny `src` ka hatramin'ny `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Ny Merges tsy mihena dia mihazakazaka `v[..mid]` sy `v[mid..]` amin'ny fampiasana `buf` ho tahiry vonjimaika, ary mitahiry ny valiny ho `v[..]`.
///
/// # Safety
///
/// Ireo takelaka roa dia tokony tsy ho foana ary `mid` dia tokony ho ao anaty fetra.
/// Buffer `buf` ela dia tsy maintsy ho ampy ny hihazona ny dika mitovy amin'ny silaka fohy kokoa.
/// Ary koa, ny `T` dia tsy tokony ho karazany mitovy refy.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Ny dingana voalohany mampiray mandika ny fohy mankamin'ny `buf`.
    // Avy eo dia miresaka ny vao nadika mihazakazaka sy ny forwards mihazakazaka intsony (na nihemotra), nampitaha ny unconsumed singa manaraka sy maka tahaka ny kely (na ny lehibe kokoa) ny iray ho any `v`.
    //
    // Raha vantany vao lany tanteraka ny fihazakazahana fohy kokoa dia vita ny dingana.Raha toa ka mihazakazaka vokany intsony levona aloha, dia tsy maintsy maka tahaka na inona na inona ny sisa amin'ny fohy nihazakazaka ho any amin'ny sisa amin'ny `v` lavaka.
    //
    // Ny fanjakana antonony amin'ny fizotrany dia arahin'i `hole` foana, izay misy tanjona roa:
    // 1. Miaro ny tsy fivadihan'ny `v` amin'ny panics amin'ny `is_less`.
    // 2. Fenoy ny lavaka sisa tavela amin'ny `v` raha ny hazakazaka lava kokoa no lany voalohany.
    //
    // Panic fiarovana:
    //
    // Raha `is_less` panics na oviana na fotoana mandritra ny dingana, `hole` dia hatao nandatsaka ary mamenoa ny lavaka ao `v` ny unconsumed isan-karazany ao amin'ny `buf`, dia toy izany no hahazoana antoka fa `v` mbola manana zavatra rehetra izany tamin'ny voalohany natao marina indray mandeha.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ny hazakazaka havia dia fohy kokoa.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Tamin'ny voalohany, ireo tondro ireo dia manondro ny fiandohan'ny filaharana.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Lany ny lafiny ambany.
            // Raha mitovy dia aleony mihazakazaka mihazakazaka hitazomana fitoniana.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Ny fihazakazahana mety dia fohy kokoa.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Tamin'ny voalohany, ireo tondro ireo dia manondro ny faran'ny filaharana.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Alao ny lafy lehibe kokoa.
            // Raha mitovy dia aleo ny fihazakazahana mety hitazomana ny fitoniana.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Farany, nilatsaka i `hole`.
    // Raha ny hazakazaka fohy dia tsy tena levona, na inona na inona sisa dia izao azo adika any an-lavaka in `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Rehefa nilatsaka dia kopia ny laharana `start..end` ho `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` dia tsy karazan'olona mitovy habe aotra, ka tsy maninona ny mizara araka ny habeny.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ity merge sort ity dia mampindrana ny hevitra sasany (fa tsy ny rehetra) avy amin'ny TimSort, izay faritana amin'ny antsipiriany [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Ny algorithm dia mamaritra ny fivoahana midina sy ny tsy fidiny, izay antsoina hoe fihazakazahana voajanahary.Misy niisa ny mbola miandry mihazakazaka mbola tsy natambatra.
/// Ny fihazakazahana tsirairay vao hita dia atosika mankany amin'ny stack, ary avy eo dia ampifangaroina ny mpivady mifanila mandrapahafaham-po ireo invariants roa ireo:
///
/// 1. isaky ny `i` amin'ny `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. amin'ny isan-`i` in `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Ny invariants dia miantoka fa ny fotoana fandehanana dia *O*(*n*\*log(* n*)) tranga ratsy indrindra.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ny silaka mahatratra an'io halavany io dia alahatra amin'ny alàlan'ny karazana fampidirana.
    const MAX_INSERTION: usize = 20;
    // Very fohy mihazakazaka Omena fampidirana mampiasa ny androm-karazany, fara fahakeliny, io singa maro.
    const MIN_RUN: usize = 10;

    // Ny fanasokajiana dia tsy misy fitondran-tena misy dikany amin'ny karazana zero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Ny filaharana fohy dia alahatra amin'ny toerany amin'ny alàlan'ny karazana fampidirana mba hisorohana ny fizarana.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Atokà ny buffer hampiasaina ho fahatsiarovana tahotra.Tsy mitandrina ny lavany 0 mba hahafahantsika foana ao marivo dika mitovy ny votoatin'ny `v` tsy vivery ny dtors mihazakazaka eo amin'ny dika mitovy, raha `is_less` panics.
    //
    // Rehefa mampifangaro hazakazaka roa nalahatra izy, ity buffer ity dia mitazona kopian'ny fihazakazahana fohy kokoa, izay hanana halavana hatrany amin'ny ankamaroan'ny `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Mba hamantarana ny fihazakazahana voajanahary ao amin'ny `v` dia ampitodintsika any aoriana izy io.
    // Mety ho toa fanapahan-kevitra hafahafa izany, nefa diniho ny zava-misy fa ny merges dia matetika mandeha amin'ny lalana mifanohitra (forwards).
    // Raha ny marimaritra iraisana, ny fampitambarana mandroso dia somary haingana kokoa noho ny fampifangaroana any aoriana.
    // Ho famaranana, ny famaritana ny fihazakazahana amin'ny alàlan'ny fitsangatsanganana mankany aoriana dia manatsara ny fahombiazana.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Tadiavo ny fihazakazahana voajanahary manaraka, ary avadiho izany raha midina mafy izy io.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Ampidiro eto ny sasany singa bebe kokoa any an-mihazakazaka raha fohy loatra.
        // Ny karazana insertion dia haingana kokoa noho ny merge sort amin'ny filaharana fohy, noho izany dia manatsara ny fahombiazany izany.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Atosiho eo amin'ny stack ity hazakazaka ity.
        runs.push(Run { start, len: end - start });
        end = start;

        // Mampifangaro hazakazaka mifanila eo akaikiny mba hanomezana fahafaham-po ireo mpanasa azy.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Farany, fihazakazahana iray marina dia tsy maintsy mijanona ao amin'ny stack.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Mandinika ny gazety Ny mihazakazaka sy mampiseho ireo zavatra roa mihazakazaka manaraka mampiray.
    // Ny marimarina kokoa, raha miverina ny `Some(r)`, midika izany fa tsy maintsy atambatra ny `runs[r]` sy `runs[r + 1]` manaraka.
    // Raha tokony hanohy hanangana fihazakazahana vaovao ny algorithm dia averina i `None`.
    //
    // TimSort dia malaza amin'ny fampiharana ny buggy, araka ny voalaza eto:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Ny votoatin'ny tantara dia: tsy maintsy hampihatra ny invariants efatra teo an-tampon'ny mihazakazaka eo amin'ny stack.
    // Ny fanerena azy ireo amin'ny telo voalohany fotsiny dia tsy ampy hahazoana antoka fa mbola hihazona ireo mpihira *hihazakazaka* rehetra * ao anaty stack.
    //
    // Ity fiasa ity dia manamarina tsara ireo mpanasa olona amin'ireo hazakazaka efatra voalohany.
    // Koa, raha teo an-tampon'ny mihazakazaka manomboka amin'ny Index 0, dia hangataka foana ny asa mampiray mandra-niisa nirodana tanteraka, mba hamenoana ny karazana.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}