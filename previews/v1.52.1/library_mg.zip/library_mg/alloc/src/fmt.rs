//! Fitaovana fanodinana sy fanaovana pirinty `String`s.
//!
//! Ity modely ity dia misy ny fanohanan'ny fotoana maharitra ho an'ny fanitarana ny syntax [`format!`].
//! Ity makro ity dia ampiharina amin'ny mpamorona handefasana antso an'ity modely ity mba hamolavola ireo tohan-kevitra amin'ny fotoana fohy.
//!
//! # Usage
//!
//! Ny makro [`format!`] dia natao hahafantaran'ireo izay avy amin'ny asan'ny C's `printf`/`fprintf` na ny asan'ny Python's `str.format`.
//!
//! Ohatra vitsivitsy amin'ny fanitarana [`format!`] dia:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" miaraka amin'ny zero mitarika
//! ```
//!
//! Avy amin'ireto dia azonao atao ny mahita fa ny filaharana voalohany dia tariby misy endrika.Dia takiana ny compiler Ary noho izany ny tady ho ara-bakiteny;dia tsy afaka ny ho lasa miova ao (mba hanao manankery fanamarinana).
//! Ny mpanangom-bokatra avy eo dia hamaky ny tadin'ny endrika ary hamaritra raha toa ka mifanaraka amin'ny lisitry ny format ity ny lisitry ny hevitra omena.
//!
//! Raha hanova ny sanda tokana amin'ny tady dia ampiasao ny fomba [`to_string`].Ity dia hampiasa ny format [`Display`] trait.
//!
//! ## Paramèteran'ny toerana
//!
//! Ny adihevitra fanodinana tsirairay dia avela hamaritra izay tohan-kevitra momba ny soatoavina resahina ao, ary raha esorina dia heverina ho "the next argument".
//! Ohatra, ny tadin-tsarimihetsika `{} {} {}` dia mila refy telo, ary izy ireo dia hovolavolaina amin'ny lamina mitovy amin'ny nanomezana azy ireo.
//! Ny tady format `{2} {1} {0}` kosa dia hametraka lamina amin'ny lamina mifamadika.
//!
//! Afaka mahazo zavatra kely indray mandeha sarotra manomboka intermingling ny karazany roa ny toeran'ny specifiers.Ny "next argument" specifier azo nieritreritra toy ny iterator noho ny tohan-kevitra.
//! Isaky ny mahita mpamaritra "next argument" dia mandroso ilay miverina.Izany dia mitarika amin'ny fitondran-tena toy izao:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Ny iterator anatiny ny adihevitra dia tsy nandroso tamin'ny fotoana nahitana ny `{}` voalohany, noho izany dia manonta ny adihevitra voalohany.Avy eo, rehefa tonga tao amin'ny `{}` faharoa, dia nandroso hatrany amin'ilay adihevitra faharoa ilay iterator.
//! Amin'ny ankapobeny, masontsivana izay anarana mivantana ny tohan-kevitra tsy misy fiantraikany masontsivana izay tsy anarany ny tohan-kevitra eo amin'ny toeran'ny specifiers.
//!
//! Takelaka misy endrika no ilaina hampiasaina amin'ny tohan-keviny rehetra, raha tsy izany dia hadisoana amin'ny fotoana manangona.Azonao atao ny manondro ilay tohan-kevitra mitovy mihoatra ny indray mandeha ao amin'ny tadin'ny endrika.
//!
//! ## Paramère nomena anarana
//!
//! Rust tena tsy manana Python-tahaka mitovy amin'ny atao hoe masontsivana amin'ny asa, fa ny [`format!`] macro dia Syntaxe fanitarana izay mamela azy ho leverage atao hoe masontsivana.
//! Ny masontsivana voalaza dia voatanisa ao amin'ny faran'ny lisitry ny adihevitra ary manana ny syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Ohatra, ireto fehezan-teny [`format!`] manaraka ireto dia samy mampiasa ny ady hevitra rehetra.
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Tsy mitombina ny mametraka masontsivana napetraka (ireo izay tsy misy anarana) aorian'ny ady hevitra misy anarana.Toy ny masontsivana napetraka, tsy mitombina ny manome masontsivana voalaza fa tsy ampiasain'ny kofehy format.
//!
//! # Famaritana Parameter
//!
//! Ny tohan-kevitra tsirairay izay voaforona dia azo ovaina amin'ny alàlan'ny paramètre formatting (mifanaraka amin'ny `format_spec` ao amin'ny [the syntax](#syntax)).
//!
//! ## Width
//!
//! ```
//! // Ireo rehetra ireo dia printy "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ity dia masontsivana ho an'ny "minimum width" izay tokony horaisin'ny endrika.
//! Raha tsy mameno ireo tarehin-tsoratra marobe ity ny tadin'ny sanda, dia ny takelaka nofaritan'i fill/alignment no ampiasaina haka ny habaka takiana (jereo eto ambany).
//!
//! Ny sanda ho an'ny sakanana dia azo omena ho [`usize`] ao amin'ny lisitry ny masontsivana amin'ny alàlan'ny fampidirana paosotra `$`, izay manondro fa ny adihevitra faharoa dia [`usize`] mamaritra ny sakany.
//!
//! Ny firesahana adihevitra miaraka amin'ny syntax dolara dia tsy misy fiatraikany amin'ny kaontera "next argument", noho izany dia hevitra tsara matetika ny miresaka tohan-kevitra amin'ny laharana, na mampiasa tohan-kevitra.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Ny endri-tsoratra sy ny fampifanarahana tsy voatery atao dia omena mahazatra miaraka amin'ny masontsivana [`width`](#width).Tsy maintsy faritana alohan'ny `width`, aorian'ny `:`.
//! Midika izany fa raha kely kokoa noho ny `width` ny sanda voaforona, dia ho voasoratra manodidina azy ny litera fanampiny.
//! Ity famenoana ity dia misy ireto karazany manaraka ireto ho an'ny fampifanarahana samihafa:
//!
//! * `[fill]<` - ny adihevitra dia mifanaraka amin'ny ankavia ao amin'ny tsanganana `width`
//! * `[fill]^` - ny ady hevitra dia ampifanarahana afovoany amin'ny tsanganana `width`
//! * `[fill]>` - mifanaraka tsara eo amin'ny tsanganana `width` ny adihevitra
//!
//! Ny [fill/alignment](#fillalignment) default ho an'ny tsy tarehimarika dia habaka ary mifanaraka amin'ny ankavia.Ny banga ho an'ny fanefitra nomerika koa dia toetran'ny habaka fa misy fampifanarahana mahitsy.
//! Raha voafaritra ho an'ny tarehimarika ny saina `0` (jereo eto ambany), dia `0` ny toetra fenoina implicit.
//!
//! Mariho fa ny fampifanarahana dia mety tsy ampiharin'ny karazana sasany.Manokana, tsy ampiharina amin'ny ankapobeny ho an'ny `Debug` trait.
//! Fomba iray tsara ahazoana antoka fa ampiharina ny padding dia ny famolavolana ny fidiranao, avy eo apetaho ity kofehy azo ity hahazoana ny vokatrao:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Salama Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Izy rehetra ireo dia saina manova ny fihetsiky ny mpanova.
//!
//! * `+` - Natao ho an'ny karazana tarehimarika izy io ary manondro fa ny pirinty dia tokony hatao pirinty foana.Ireo mari-pamantarana miabo dia tsy atao pirinty amin'ny alàlan'ny tsindry mihitsy, ary ny marika ratsy dia aorina fotsiny ho an'ny `Signed` trait.
//! Ity saina ity dia manondro fa ny mari-pamantarana marina (`+` na `-`) dia tokony hatao pirinty foana.
//! * `-` - Tsy ampiasaina ankehitriny
//! * `#` - Ity saina ity dia manondro fa ny endrika fanontana "alternate" dia tokony hampiasaina.Ireto misy endrika hafa:
//!     * `#?` - pirinty tsara ny format [`Debug`]
//!     * `#x` - mialoha ny fifamaliana amin'ny `0x`
//!     * `#X` - mialoha ny fifamaliana amin'ny `0x`
//!     * `#b` - mialoha ny fifamaliana amin'ny `0b`
//!     * `#o` - mialoha ny fifamaliana amin'ny `0o`
//! * `0` - Ity dia ampiasaina hanondroana ireo endrika integer fa ny padding mankany `width` dia samy tokony hatao miaraka amina endrika `0` ary koa ho fantatry ny tanana.
//! Ny endrika toy ny `{:08}` dia hamoaka `00000001` ho an'ny integer `1`, raha toa kosa ny endrika mitovy `-0000001` ho an'ny integer `-1`.
//! Jereo fa ny kinova ratsy dia manana aotra vitsivitsy noho ny kinova miabo.
//!         Mariho fa ny zezika padding dia apetraka aorian'ny famantarana (raha misy) ary alohan'ny tarehimarika.Rehefa ampiasaina miaraka amin'ny sainam-pirenena `#` dia misy lalàna mitovy amin'izany koa: ny zerô padding dia atsofoka aorian'ny prefika fa alohan'ny tarehimarika.
//!         Ny nauna dia tafiditra ao amin'ny sakany manontolo.
//!
//! ## Precision
//!
//! Ho an'ireo karazana tsy isa, azo raisina ho "maximum width" ity.
//! Raha lava kokoa noho ity sakany ity ny tadiny vokarina, dia ampidinina amin'ireo tarehin-tsoratra marobe io ary ny sandan'ny truncated dia alefa miaraka amin'ny `fill`, `alignment` ary `width` mety raha napetraka ireo masontsivana ireo.
//!
//! Ho an'ny karazany tsy mitongilana, tsy raharahina izany.
//!
//! Fa mitsingevana-teboka karazana, izany dia mampiseho ny fomba maro isa taorian'ny fotoana tokony decimal pirinty.
//!
//! Misy fomba telo azo hamaritana ny `precision` tadiavina:
//!
//! 1. X-`.N` X integer:
//!
//!    ny integer `N` mihitsy no marina.
//!
//! 2. Integer na anarana narahin'ny famantarana dolara `.N$`:
//!
//!    mampiasa format *argument*`N` (izay tsy maintsy ho `usize`) toy ny marimarina.
//!
//! 3. Asterisk `.*`:
//!
//!    `.*` dia midika fa ity `{...}` ity dia mifandraika amina fampidirana endrika *roa* fa tsy iray: ny fidirana voalohany dia mitazona ny `usize` mazava tsara, ary ny faharoa kosa mitazona ny sanda hanontana.
//!    Mariho fa amin'ity tranga ity, raha mampiasa ny endrika kofehy `{<arg>:<spec>.*}`, dia ny anjara `<arg>` manondro ny vidy* + mba pirinty, ary tsy maintsy ho avy ny `precision` ao fahan'ny `<arg>` teo aloha.
//!
//! Ohatra, ity manaraka ity dia miantso ny printy rehetra mitovy zavatra `Hello x is 0.01000`:
//!
//! ```
//! // Salama {arg 0 ("x")} dia {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Salama {arg 1 ("x")} dia {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Salama {arg 0 ("x")} dia {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Salama {next arg ("x")} dia {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Salama {next arg ("x")} dia {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} no {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Raha ireto:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! manonta zavatra telo samy hafa be dia be:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Amin'ny fiteny fandefasana fandaharana sasany, ny fitondran-draharahan'ny fanaingoana ny tadiny dia miankina amin'ny toerana misy ny rafitra fandidiana.
//! Ny fiasa endrika natolotry ny tranombokin'i Rust mahazatra dia tsy misy hevitra momba ny toerana eo an-toerana ary hamokatra valiny mitovy amin'ny rafitra rehetra na inona na inona fananganana mpampiasa.
//!
//! Ohatra, ity kaody manaraka ity dia hanao pirinty `1.5` foana na dia mampiasa mpampisaraka desimaly hafa aza ny faritra eo an-toerana fa tsy teboka.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Ireo litera ara-bakiteny `{` sy `}` dia mety ho tafiditra ao anaty kofehy amin'ny alalàn'izy ireo miaraka amina toetra mitovy.Ohatra, ny `{` endri-tsoratra dia afa-nandositra miaraka amin'ny `{{` ary ny endri-tsoratra `}` dia afa-nandositra miaraka amin'i `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Raha fintino, eto ianao dia afaka mahita ny fitsipi-pitenenana feno tadin-format.
//! Ny syntax an'ny fiteny fandefasana ampiasaina dia nalaina avy amin'ny fiteny hafa, noho izany dia tsy tokony ho hafahafa loatra.Ny fifamaliana dia apetraka amin'ny syntax toy ny Python, midika izany fa voadidin'ny `{}` ny adihevitra fa tsy ny C-like `%`.
//! Ny fitsipi-pitenenana tena izy ho an'ny syntax fandefasana dia:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Ao amin'ny fitsipi-pitenenana etsy ambony, `text` dia mety tsy misy litera `'{'` na `'}'`.
//!
//! # Famolavolana traits
//!
//! Rehefa mangataka ny hametrahana endrika iray miaraka amina karazana manokana ianao, dia tena mangataka ny adiresy iray ho an'ny trait iray manokana.
//! Io dia ahafahana mamolavola endrika tena izy amin'ny alàlan'ny `{:x}` (toy ny [`i8`] ary koa ny [`isize`]).Ny amin'izao fotoana izao ny karazana sarintany ho traits dia:
//!
//! * *tsy misy* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] miaraka amin'ireo integers hexadecimal ambany
//! * `X?` ⇒ [`Debug`] miaraka amin'ireo integers hexadecimal ambony
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ny dikan'izany dia ny karazana tohan-kevitra izay mampihatra ny [`fmt::Binary`][`Binary`] trait dia azo ovaina amin'ny `{:b}`.Implementations dia nanome ho an'ireo traits ho maro karazana faran'izay tsotra ny fitsipika trano famakiam-boky ihany koa.
//!
//! Raha tsy misy endrika voatondro (toy ny `{}` na `{:6}`), dia ny endrika trait no ampiasaina dia ny [`Display`] trait.
//!
//! Rehefa mampiditra endrika trait ho an'ny karazanyo manokana ianao dia tsy maintsy mampihatra fomba iray amin'ny sonia:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // ny karazanay manokana
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Ny karazanao dia halefa ho referansa `self` ary avy eo ny fiasa dia tokony hamoaka output amin'ny renirano `f.buf`.Miankina amin'ny endriny tsirairay ny fampiharana trait raha hanaraka tsara ireo masontsivana fanodinana angatahina.
//! Ny salan'ireo masontsivana ireo dia ho voatanisa ao amin'ny sahan'ny [`Formatter`] str.Mba ho fanampiana izany, ny [`Formatter`] struct mpanampy ihany koa dia manome ny sasany fomba.
//!
//! Ankoatr'izay, ny sandan'ny fiverenan'ity fiasa ity dia [`fmt::Result`] izay karazana solon'anarana [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Ny fametrahana ny fampiharana dia tokony hiantoka ny fanaparitahana lesoka avy amin'ny [`Formatter`] (ohatra, rehefa miantso [`write!`]).
//! Na izany aza, tsy tokony hamerina fahadisoana velively izy ireo.
//! Izany hoe, ny fampiharana format dia tsy maintsy ary mety mamerina lesoka fotsiny raha toa ka miverina ny error [`Formatter`].
//! Izany dia satria, mifanohitra amin'izay tondroin'ilay sonia fiasa, ny fandrafetana ny tadiny dia asa tsy mety diso.
//! Io fiasa io dia mamerina valiny fotsiny satria mety tsy hahomby ny fanoratana amin'ny renirano ary tokony hanome fomba iray hanaparitahana ny zava-misy fa nisy lesoka nitranga namerina ilay stack.
//!
//! Ohatra iray amin'ny fampiharana ny format traits dia toa:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Ny sanda `f` dia mampihatra ny `Write` trait, izay no soratanao!miandry i makro.
//!         // Mariho fa ity firafitra ity dia tsy miraharaha ireo sainam-pirenena samihafa natolotra tamin'ny tady famolavolana.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Ny traits samihafa dia mamela ny endrika famoahana karazany iray.
//! // Ny dikan'ity endrika ity dia ny fanontana ny haben'ny vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hajao ny sainam-pandrafetana amin'ny alàlan'ny fampiasana ny fomba mpanampy `pad_integral` amin'ny zavatra Formatter.
//!         // Jereo ny antontan-taratasy momba ny antsipiriany, ary ny fiasa `pad` dia azo ampiasaina amin'ny tadin'ny tadiny.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Ireny fampisehoana roa traits ireny dia samy manana ny tanjony:
//!
//! - [`fmt::Display`][`Display`] ny fampiharana dia manamafy fa ny karazany dia azo soloina am-pahatokiana ho tadin'ny UTF-8 amin'ny fotoana rehetra.**Tsy** ampoizina fa hampihatra ny [`Display`] trait ny karazany rehetra.
//! - [`fmt::Debug`][`Debug`] fampiharana dia tokony hampiharina amin'ny **rehetra** karazam-bahoaka.
//!   Ny famoahana matetika dia maneho ny fanjakana anatiny araka izay azo atao.
//!   Ny tanjon'ny [`Debug`] trait dia ny hanamorana ny famafana kaody Rust.Amin'ny ankamaroan'ny tranga, ny fampiasana `#[derive(Debug)]` dia ampy ary atolotra.
//!
//! Ohatra vitsivitsy amin'ny vokatra azo avy amin'ny traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makrô mifandraika
//!
//! Misy makro mifandraika maromaro ao amin'ny fianakaviana [`format!`].Ireo izay ampiharina amin'izao fotoana izao dia:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ity sy [`writeln!`] dia macros roa izay ampiasaina hamoahana ny tadin'ny endrika amina renirano voatondro.Izy io dia ampiasaina mba hisorohana ny fizarana mpanelanelana amin'ny tadin'ny endrika ary manorata mivantana ny vokatra.
//! Eo ambanin'ny hood, ity fiasa ity dia miantso ny fiasa [`write_fmt`] voafaritra ao amin'ny [`std::io::Write`] trait.
//! Ny fampiasana ohatra dia:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ity sy [`println!`] dia mamoaka ny vokatra avoakany mankany stdout.Toy izany koa amin'ny makro [`write!`], ny tanjon'ireto makro ireto dia ny hisorohana ny fizarana antonony rehefa manonta ny vokatra.Ny fampiasana ohatra dia:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Ny makro [`eprint!`] sy [`eprintln!`] dia mitovy amin'ny [`print!`] sy [`println!`], raha tsy hoe mamoaka ny vokatra avoakany amin'ny stderr.
//!
//! ### `format_args!`
//!
//! Ity dia makro mahaliana tiana hampiasaina mba handehanana soa aman-tsara any amina zavatra tsy mivaingana mamaritra ny tadin'ny endrika.Ity zavatra ity dia tsy mitaky fizarana antontam-bato hamoronana, ary fampahalalana fotsiny no resahina ao amin'ilay stack.
//! Eo ambanin'ny hood, ny makrô mifandraika rehetra dia ampiharina amin'ny lafiny an'io.
//! Voalohany, misy ohatra ampiasaina:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Ny valin'ny makro [`format_args!`] dia sanda karazana [`fmt::Arguments`].
//! Ity rafitra ity dia azo ampitaina amin'ny asan'ny [`write`] sy [`format`] ao anatin'ity modely ity mba hanodinana ny tadin'ny endrika.
//! Ny tanjon'ity makro ity dia ny hisorohana bebe kokoa ny fizarana antenantenany rehefa mifampiraharaha amin'ny tadin'ny formatting.
//!
//! Ohatra, ny famakiam-boky momba ny fitrandrahana ala dia afaka mampiasa ny syntax fanaingoana mahazatra, saingy handalo manodidina io rafitra io izy mandra-pahafantatra ny toerana tokony halehan'ny vokatra.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Ny asa `format` maka ny [`Arguments`] struct sy miverina ny vokatry format kofehy.
///
///
/// Ny ohatra [`Arguments`] dia azo foronina miaraka amin'ny makro [`format_args!`].
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Azafady, mariho fa ny fampiasana [`format!`] dia mety kokoa.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}