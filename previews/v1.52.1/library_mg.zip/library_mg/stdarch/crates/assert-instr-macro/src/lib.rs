//! Fampiharana ny `#[assert_instr]` macro
//!
//! Ity makro ity dia ampiasaina rehefa mizaha toetra ny `stdarch` crate ary ampiasaina hiteraka tranga fitsapana mba hanamafisana fa tena misy torolàlana izay antenainay ho hita ao.
//!
//! Ny fomba fanatanterahana indray dia somary macro eto tsotra, izany fotsiny ny `#[test]` appends miasa ho tany am-boalohany token Stream izay milaza fa ny asa misy mihitsy ny fampianarana manan-danja.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // Ajanony ny assert_instr ho an'ny tanjona x86 namboarina niaraka tamin'ny avx azo atao, izay mahatonga ny LLVM hiteraka intrinsika samihafa izay andramantsika.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // Raha fampianarana fitsirihana ireo sembana Aza emitting shim izany mihitsy, tany am-boalohany fotsiny hiverina zavatra tsy ny toetra.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // Ireo anarana ireo dia tokony ho tsy manam-paharoa hahafahantsika mahita izany amin'ny fanaparitahana azy amin'ny manaraka:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // Mampiasà ABI amin'ny Windows izay mandalo ny sanda SIMD ao anaty fisoratana anarana, toy ny inona no mitranga amin'ny Unix (heveriko?) Aorizanao.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // Ny compiler amin'ny maody optimised amin'ny alàlan'ny default dia mampandeha pass antsoina hoe "mergefunc" izay hanambatra ireo fiasa izay mitovy endrika.
            // Mivadika ireo intrinsika sasany mamorona kaody mitovy ary miforitra izy ireo, midika izany fa mitsambikina iray hafa fotsiny ny iray.
            // Izany messes ny ny maso ny disassembly ity asa ary izahay tsy be mpankafy izany.
            //
            // Mba hanoherana an'ity pass ity sy hisorohana ny fiasa tsy hiasa dia mamorona kaody vitsivitsy izahay izay antenaina fa tery tokoa amin'ny resaka codegen fa tsy manam-paharoa raha tsy izany tsy azo aforitra ny kaody.
            //
            //
            // Ialana amin'ny Wasm32 amin'izao fotoana izao satria tsy miasa ireo fiasa ireo izay manapaka ny fitsapana ataonay satria toa ny fiasan'ny intrinsika tsirairay avy dia miantso fiasa.
            // Ny famadihana ireo fiasa dia tsy mitovy amin'ny fampifangaroana azy amin'ny wasm32.
            // Ity bibikely ity dia arahana amin'ny rust-lang/rust#74320.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}