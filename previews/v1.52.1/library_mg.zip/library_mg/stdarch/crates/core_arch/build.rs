use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Nampiasaina mba hilazana ny fanamarihana `#[assert_instr]` misy anay fa ny intrinsika simd rehetra dia misy mba hizaha toetra ny codegen, satria ny sasany voafatotra ao ambadiky ny `-Ctarget-feature=+unimplemented-simd128` fanampiny izay tsy misy mitovy amin'ny `#[target_feature]` amin'izao fotoana izao.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}