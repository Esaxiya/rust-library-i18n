`core::arch` - Rust ny fotodrafitrasa famakiam-boky fototra intrinsika manokana
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Ny maody `core::arch` dia mampiditra intrinsika miankina amin'ny maritrano (ohatra SIMD).

# Usage 

`core::arch` azo alaina ho ampahany amin'ny `libcore` ary aondrany indray i `libstd`.Aleo mampiasa azy amin'ny alàlan'ny `core::arch` na `std::arch` noho ny amin'ny alàlan'ity crate ity.
Ireo fisehoan-javatra tsy milamina dia matetika misy isaky ny alina Rust amin'ny alàlan'ny `feature(stdsimd)`.

Ny fampiasana `core::arch` amin'ny alàlan'ity crate ity dia mitaky Rust isan'alina, ary afaka (ary) mamaky matetika.Ny tranga tokana tokony handinihanao ny fampiasana azy amin'ny alàlan'ity crate ity dia:

* raha mila mamerina mamorona ny `core::arch` ny tenanao ianao, ohatra, miaraka amina endri-javatra kendrena manokana izay tsy alefa ho an'ny `libcore`/`libstd`.
Note: raha toa ka mila ny indray manangona azy ho tsy fitsipika lasibatra, azafady kokoa mampiasa `xargo` sy nanoratra indray `libcore`/`libstd` raha ilaina fa tsy mampiasa izany crate.
  
* mampiasa fampiasa sasantsasany izay mety tsy misy na dia ao ambadiky ny fisongadinan'ny Rust tsy mitombina aza.Tsy miezaka ny hitandrina izany ho faran'izay kely.
Raha mila mampiasa ny sasany amin'ireto endri-javatra ireto ianao dia miangavy mba sokafy olana mba hahafahanay mamoaka azy ireo amin'ny alina Rust ary azonao ampiasaina avy any.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` no zaraina voalohany eo ambanin'ny fehezan-dalàna na ny MIT licence ary ny Apache License (Version 2.0), miaraka amin'ireo ampahany rakotry ny fahazoan-dàlana mitovy amin'ny BSD.

Jereo ny LICENSE-APACHE, ary ny LICENSE-MIT raha mila fanazavana.

# Contribution

Raha tsy milaza mazava ianao amin'ny fomba hafa, ny anjara biriky niniana nampidirina ho tafiditra ao amin'ny `core_arch`, araka ny voafaritry ny fahazoan-dàlana Apache-2.0, dia hanana fahazoan-dàlana roa sosona etsy ambony, tsy misy fe-potoana na fepetra fanampiny.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












