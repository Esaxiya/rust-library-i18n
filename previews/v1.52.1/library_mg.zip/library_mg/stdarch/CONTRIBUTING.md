# Mandray anjara amin'ny stdarch

Ny `stdarch` crate dia mihoatra noho ny vonona ny handray anjara biriky!Voalohany, mety ho tianao ny hijery ny trano fitehirizam-boky ary hahazoana antoka fa mandalo anao ny fitsapana:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Raha `<your-target-arch>` no tratra kendrena ampiasain'ny `rustup`, ohatra `x86_x64-unknown-linux-gnu` (tsy misy `nightly-` teo aloha na mitovy aminy).
Aza adino koa fa ity fitahirizana ity dia mitaky fantsona isan-alina an'ny Rust!
Ny fitsapana ambony no mitaky alina raha ny marina rust ho ny toerana misy anao eo amin'ny rafitra, mba hametraka ny fampiasana `rustup default nightly` (sy `rustup default stable` ny hiverina).

Raha tsy mandeha ireo dingana etsy ambony ireo, [please let us know][new]!

Manaraka izany dia azonao atao ny manampy [find an issue][issues] manampy, nifidy vitsivitsy izahay niaraka tamin'ny tag [`help wanted`][help] sy [`impl-period`][impl] izay afaka mampiasa fanampiana manokana. 
Mety ho liana indrindra amin'ny [#40][vendor] ianao, amin'ny fampiharana ny intrinsika mpivarotra rehetra ao amin'ny x86.Ity olana ity dia nahazo tondro tsara momba ny toerana hanombohana!

Raha efa nahazo ankapobeny fanontaniana dia aza misalasala manontany [join us on gitter][gitter] sy ny manodidina!Aza misalasala manantona any@BurntSushi na@alexcrichton miaraka amina fanontaniana.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Fomba fanoratana ohatra ho an'ny intrinsika stdarch

Misy endri-javatra vitsivitsy izay tsy maintsy avela mba hiasa tsara ilay intrinsika nomena ary ny ohatra dia tsy maintsy alefan'ny `cargo test --doc` fotsiny rehefa tohanan'ny CPU ilay fampiasa.

Vokatr'izany dia tsy mandeha ny default `fn main` izay vokarin'i `rustdoc` (amin'ny ankamaroan'ny tranga).
Diniho ny fampiasana ity manaraka ity ho toy ny torolàlana hahazoana antoka fa mandeha araka ny antenaina ny ohatra asehonao.

```rust
/// # // Mila CFg_target_feature izahay mba hahazoana antoka fa ny ohatra dia irery
/// # // tantanan'ny `cargo test --doc` rehefa manohana ny endri-javatra ny CPU
/// # #![feature(cfg_target_feature)]
/// # // Mila target_feature isika mba hiasa ny intrinsika
/// # #![feature(target_feature)]
/// #
/// # // rustdoc amin'ny toerana misy anao dia mampiasa `extern crate stdarch`, fa mila izany izahay
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // Ny tena tena fiasa
/// # fn main() {
/// #     // Alefaso ihany ity raha tohana ny `<target feature>`
/// #     raha cfg_feature_enified! ("<target feature>"){
/// #         // Mamorona asa `worker` izay ihany no hihazakazaka ho kendrena raha endri-javatra
/// #         // tohanana ary alao antoka fa avela ho an'ny mpiasanao `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         tsy azo antoka fn worker() {
/// // Soraty eto ny ohatra nasehonao.Ny intrinsika manokana dia miasa eto!Mandehana bibidia!
///
/// #         }
///
/// #         { worker(); } tsy azo antoka
/// #     }
/// # }
```

Raha toa ka tsy mahazatra ny sasany amin'ireo syntax etsy ambony, ny faritra [Documentation as tests] an'ny [Rust Book] dia mamaritra tsara ny syntax `rustdoc`.
Toy ny mahazatra, dia aza misalasala manontany anay [join us on gitter][gitter] ary raha namely misy snags, ary misaotra anao noho ny manampy amin'ny fanatsarana ny tahirin-kevitra ny `stdarch`!

# Torolàlana fitsapana hafa

Amporisihina amin'ny ankapobeny ianao hampiasa `ci/run.sh` hitantanana ny fitsapana.
Na izany aza tsy mety aminao io, ohatra, raha ao amin'ny Windows ianao.

Amin'izay dia afaka miverina mihazakazaka `cargo +nightly test` sy `cargo +nightly test --release -p core_arch` ianao amin'ny fitsapana ny taranaka kaody.
Mariho fa ireo mitaky ny alina toolchain ho nametraka sy `rustc` ho fantatra momba ny lasibatra sy ny CPU telo.
Manokana indrindra ianao dia mila mametraka ny fiovan'ny tontolo iainana `TARGET` tahaka ny nataonao ho an'ny `ci/run.sh`.
Ho fanampin'izany dia mila mametraka `RUSTCFLAGS` (mila ny `C`) ianao hanondroana ireo endri-javatra kendrena, ohatra `RUSTCFLAGS="-C -target-features=+avx2"`.
Azonao atao ihany koa ny mametraka `-C -target-cpu=native` raha toa ianao ka "just" mivoatra mifanohitra amin'ny CPU misy anao ankehitriny.

Tandremo fa rehefa mampiasa ireo torolàlana hafa ireo ianao, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ohatra
Mety tsy hahomby ny fitsapana famoronana torolàlana satria tsy mitovy ny anaran'ny disassembler azy ireo, oh
mety hiteraka `vaesenc` fa tsy torolàlana `aesenc` na eo aza ny fomba fitondran-tenany.
Ireo torolàlana ireo koa dia manao fitsapana kely kokoa noho izay tokony hatao, koa aza gaga fa rehefa mangataka ianao dia mety hisy lesoka sasany hiseho amin'ny fitiliana tsy voarakotra eto.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






