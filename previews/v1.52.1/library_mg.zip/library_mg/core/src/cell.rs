//! Kaontenera azo ovaina azo zaraina.
//!
//! Rust fahatsiarovana dia mifototra amin'ny fiarovana ity fitsipika ity: jerena ny zavatra `T`, dia azo atao ihany ny iray amin'ireto:
//!
//! - Raha manana andinin-tsoratra masina maro (`&T`) loha tsy mety miova ny zavatra (fantatra amin'ny anarana hoe **koa aliasing**).
//! - Manana referato azo mutable iray (`&mut T`) amin'ilay zavatra (fantatra koa amin'ny hoe **mutability**).
//!
//! Izany dia ampiharina ny Rust compiler.Na izany aza, misy ny toe-javatra izay tsy dia miovaova io fitsipika io.Indraindray dia takiana ny hanana firesahana marobe amin'ny zavatra iray nefa hanova izany.
//!
//! Ireo kaontenera azo ovaina azo zaraina dia misy mba hamela ny fiovaovan'ny toetr'andro amin'ny fomba voafehy, na dia eo aza ny alàlan'ny aliasing.Samy mamela ny [`Cell<T>`] sy [`RefCell<T>`] hanao an'io amin'ny fomba kofehy tokana.
//! Na izany aza, na `Cell<T>` na dia kofehy `RefCell<T>` soa aman-tsara (tsy manatanteraka [`Sync`]).
//! Raha mila manao aliasing sy mutation eo anelanelan'ny kofehy maromaro ianao dia azo atao ny mampiasa karazana [`Mutex<T>`], [`RwLock<T>`] na [`atomic`].
//!
//! Soatoavin'ny ny `Cell<T>` sy `RefCell<T>` karazana azo zaraina mutated amin'ny alalan'ny soratra masina (izany hoe
//! ny karazany `&T` mahazatra), fa ny ankamaroan'ny karazana Rust dia tsy azo soloina amin'ny alàlan'ny referansa tokana (`&mut T`).
//! Lazainay fa ny `Cell<T>` sy `RefCell<T>` dia manome 'fiovan'ny toetr'andro', mifanohitra amin'ireo karazana Rust mahazatra izay mampiseho ny 'fifandimbiasana nolovaina'.
//!
//! Cell karazany roa avy amin'ny tsirony: `Cell<T>` sy `RefCell<T>`.`Cell<T>` dia mampihatra ny fiovaovan'ny atiny amin'ny alàlan'ny famindrana ny soatoavina miditra sy mivoaka ny `Cell<T>`.
//! Ny mampiasa andinin-tsoratra masina fa tsy soatoavina, dia tsy maintsy mampiasa ny `RefCell<T>` karazana, nahazo ny hidin-trano alohan'ny mutating hanoratra.`Cell<T>` dia manome fomba mba retrieve sy hanova ny vidiny amin'izao fotoana izao anatiny:
//!
//!  - Ho an'ireo karazana mampihatra [`Copy`], ny fomba [`get`](Cell::get) dia mamerina ny sanda anatiny ankehitriny.
//!  - Fa karazany izay mampihatra [`Default`], ny fomba [`take`](Cell::take) manolo ny anatiny amin'izao fotoana izao zava-dehibe amin'ny [`Default::default()`] sy miverina ny Nosoloana sarobidy.
//!  - Fa karazana rehetra, ny fomba [`replace`](Cell::replace) manolo ny anatiny amin'izao fotoana izao lanja sy ny miverina ny nosoloina ny lanja sy ny fomba [`into_inner`](Cell::into_inner) manimba ny `Cell<T>` sy miverina ny anatiny sarobidy.
//!  Ankoatr'izay, ny fomba [`set`](Cell::set) dia manolo ny sanda anatiny, mandatsaka ny sanda nosoloina.
//!
//! `RefCell<T>` Rust mampiasa ny lifetimes ho fampiharana 'mavitrika nindrana', ny dingana famantarany zavatra misy afaka milaza vonjimaika, manokana, mutable ny fidirana ho ao anaty zava-dehibe.
//! Mindrana ho an'ny `RefCell<T>`S dia fantarina 'amin'ny runtime', tsy toy ny tompon-tany Rust karazana boky izay tanteraka fantarina fitohy, amin'ny fotoana manangona.
//! Satria `RefCell<T>` maka dia mavitrika azo atao ny miezaka mba hisambotra ny zava-dehibe izay efa mutably nindramina;rehefa mitranga izany dia miteraka kofehy panic.
//!
//! # Rahoviana no hisafidy mutability anatiny
//!
//! Ny mahazatra kokoa nandova mutability, izay tsy maintsy manana fahafahana miditra tsy manam-paharoa ny mutate ny zava-dehibe, dia iray amin'ireo singa manan-danja izay mahatonga teny Rust ny antony mafy momba ny manondro aliasing, fitohy hisorohana loza bibikely.
//! Noho izany dia aleony miovaova ny lova nolovaina ary ny fiovaovana anatiny dia zavatra farany ilaina.
//! Koa satria ny karazana sela dia mamela ny mutation izay tsy hanaiky azy raha tsy izany, misy fotoana mety mety hampiovaova ny ao anaty, na koa tsy maintsy * ampiasaina, ohatra
//!
//! * Mampahafantatra mutability 'inside' zavatra tsy azo ovaina
//! * Ny antsipirian'ny fampiharana ireo fomba lojika tsy azo ovaina.
//! * Mutating implementations ny [`Clone`].
//!
//! ## Mampahafantatra mutability 'inside' zavatra tsy azo ovaina
//!
//! Betsaka ny karazana fanondro marani-tsaina iraisana, ao anatin'izany ny [`Rc<T>`] sy [`Arc<T>`], no manome kaontenera izay azo klona sy zaraina amin'ny antoko maro.
//! Satria ny ao soatoavina mety ho hihamaro-aliased, dia afaka ihany nindramina tamin'i `&`, fa tsy `&mut`.
//! Raha tsy misy sela dia ho vita ny mutate angon-drakitra ao anatiny ireo sahaza marani-tsaina mihitsy.
//!
//! Tena fahita izany dia hametraka ny `RefCell<T>` ao anatin'ny karazana nizara manondro ny hampidritra indray mutability:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Mamorona vaovao mametra ny sakana mba sehatra ny mavitrika Borrow
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Mariho fa raha tsy avela teo aloha hisambotra ny cache latsaka amin'ny sehatra dia ny manaraka Borrow hahatonga mavitrika panic kofehy.
//!     //
//!     // Ity no atahorana lehibe amin'ny fampiasana `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Mariho fa mampiasa ohatra io fa tsy `Arc<T>` `Rc<T>`.`RefCell<T>`S dia ho an'ny mpitovo-threaded tranga.Diniho ny fampiasana [`RwLock<T>`] na [`Mutex<T>`] raha mila fifandimbiasana iraisana ianao amin'ny toe-javatra misy kofehy maro.
//!
//! ## Fanatanterahana antsipirian'ny fomba mazava-loha tsy mety miova
//!
//! Indraindray mety irina ny tsy hampiharihary API fa misy fiovana mitranga "under the hood".
//! Mety ho noho ny fandidiana dia mazava loha tsy mety miova, fa ohatra, ny fampiharana caching tafika hanao mutation;na satria tsy maintsy ampiasaina mutation ho fampiharana ny trait fomba izay voafaritra tany am-boalohany mba haka `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Mandeha eto ny kajy lafo
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mampifanaraka ny fampiharana ny `Clone`
//!
//! Ity dia tranga manokana, nefa mahazatra, an'ny teo aloha: ny fanafenana ny fiovan'ny toetr'andro ho an'ny asa izay toa tsy azo ovaina.
//! Ny fomba [`clone`](Clone::clone) dia tsy tokony hanova ny loharano sarobidy, ary nambara ny hitondra `&self`, fa tsy `&mut self`.
//! Noho izany, ny mutation rehetra mitranga amin'ny fomba `clone` dia tsy maintsy mampiasa karazana sela.
//! Ohatra, [`Rc<T>`] dia mitazona ny isa isaina ao anatin'ny `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Toerana fitadidiana azo ovaina.
///
/// # Examples
///
/// Amin'ity ohatra ity dia hitanao fa ny `Cell<T>` dia mamela ny mutation ao anaty rafitra tsy miova.
/// Amin'ny teny hafa, dia mahatonga "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: `my_struct` dia tsy miova
/// // my_struct.regular_field =new_value;
///
/// // ASA: na dia tsy miova aza ny `my_struct`, `special_field` dia `Cell`,
/// // izay azo ovaina foana
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Jereo ny [module-level documentation](self) raha mila fanazavana fanampiny.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Miteraka `Cell<T>`, miaraka amin'ny `Default` sarobidy ho an'ny T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Mamorona `Cell` vaovao misy ny sanda nomena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Mametraka ny sanda voarakitra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Swaps ny soatoavina roa sela.
    /// Ny fahasamihafana amin'ny `std::mem::swap` dia tsy mila referansa `&mut` io fiasa io.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SAFETY: Mety hampidi-doza io raha antsoina avy amin'ny kofehy misaraka, fa `Cell`
        // no `!Sync` ka izany dia tsy ho tanteraka.
        // Ity koa dia tsy hanafoana ireo tondro satria `Cell` dia manome toky fa tsy misy zavatra hafa manondro an'ireo "Cell`s ireo.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Manolo ny lanjany ao amin'ny `val`, ary miverina ny antitra sarobidy voarakitra.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SAFETY: Mety hiteraka hazakazaka angona izany raha antsoina amin'ny kofehy misaraka,
        // fa `Cell` dia `!Sync` ka tsy hitranga izany.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Mamaha ny sanda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Mamerina kopian'ny sanda misy.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SAFETY: Mety hiteraka hazakazaka angona izany raha antsoina amin'ny kofehy misaraka,
        // fa `Cell` dia `!Sync` ka tsy hitranga izany.
        unsafe { *self.value.get() }
    }

    /// Ny vaovao farany ny voarakitra mampiasa asa sarobidy sy miverina ny vidiny vaovao.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Miverina tondro iray manta amin'ireo angona fototra ao amin'ity sela ity.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Miverina fanovana azo ovaina amin'ny angona ifotony.
    ///
    /// Ity antso ity dia mindrana `Cell` azo ovaina (amin'ny fotoana fanangonana) izay manome antoka fa manana ilay hany referansa isika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Miverina `&Cell<T>` avy amin'ny `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SAFETY: `&mut` miantoka fidirana tokana.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Raiso ny sandan'ny sela, avelao eo amin'ny toerany ny `Default::default()`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Miverina `&[Cell<T>]` avy amin'ny `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SAFETY: `Cell<T>` dia manana endrika fahatsiarovana mitovy amin'ny `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Toerana fitadidiana azo ovaina miaraka amina fitsipika indram-bola voamarina
///
/// Jereo ny [module-level documentation](self) raha mila fanazavana fanampiny.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Misy lesoka naverin'i [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Misy lesoka naverin'i [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Ny sanda tsara dia maneho ny isa mavitrika `Ref`.Ratsy soatoavina maneho ny isan'ny mpanao `RefMut`.
// Multimy `RefMut`s dia afaka miasa amin'ny fotoana iray raha toa ka miresaka momba ny singa tsy mitovy amin'ny tsy mitongilana `RefCell` (ohatra, ny elanelam-potoana iray amin'ny sombina).
//
// `Ref` ary `RefMut` Samy teny roa ny habeny, ary ny toy izany dia azo inoana fa tsy ho ampy na oviana na oviana, na ``Ref`s RefMut`s in nisy ny anananareo betsaka ny antsasaky ny `usize` isan-karazany.
// Araka izany, ny `BorrowFlag` dia mety tsy hihoatra na hisondrotra mihitsy.
// Na izany aza, tsy antoka izany, satria ny programa pathological dia mety hamorona hatrany ary avy eo mem::forget `Ref`s na`RefMut`s.
// Noho izany, dia tsy maintsy mazava tsara ny fehezan-dalàna ho tondraka, ary mijery underflow mba tsy unsafety, na, fara fahakeliny, mitondra entana tsara ao amin'ny hetsika izay tondraka, na underflow mitranga (ohatra, jereo ny BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Mamorona `RefCell` vaovao misy `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Manjifa ny `RefCell`, mamerina ny sandan'ny fonosana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Koa satria izany asa maka `self` (ny `RefCell`) by sarobidy, ny compiler fitohy manamarina fa tsy amin'izao fotoana izao nindramina.
        //
        self.value.into_inner()
    }

    /// Manolo ny soatoavina nofonosina amin'ny iray vaovao, mamerina ny sanda taloha, nefa tsy manala ny iray amin'izy ireo.
    ///
    ///
    /// Izany asa mifanitsy amin'ny [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics raha amin'izao fotoana izao ny vidin'ny nindramina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Manolo ny nofonosina sarobidy amin'ny olona vaovao computed avy `f`, miverina ny vidiny taloha, tsy misy na iray deinitializing.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha amin'izao fotoana izao ny vidin'ny nindramina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Swaps ny nofonosina `self` tena ilaina ny miaraka amin'ny nofonosina hasarobidin'ny `other`, tsy misy na iray deinitializing.
    ///
    ///
    /// Ity fiasa ity dia mifanaraka amin'ny [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Mindrana tsy azo ovaina ny soatoavina fonosina.
    ///
    /// Ny Borrow maharitra mandra-niverina `Ref` fivoahana lenta.
    /// Ny fisamboram-bola marobe tsy azo ovaina dia azo esorina miaraka amin'izay.
    ///
    /// # Panics
    ///
    /// Panics raha azo ampindramina indroa ny sandany.
    /// Ho an'ny variant non-panicking dia ampiasao [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Ohatra iray amin'ny panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Mindrana tsy miova ny sanda nofonosina, mamerina lesoka raha toa ka azo indramina nindrana ny sandany.
    ///
    ///
    /// Ny Borrow maharitra mandra-niverina `Ref` fivoahana lenta.
    /// Ny fisamboram-bola marobe tsy azo ovaina dia azo esorina miaraka amin'izay.
    ///
    /// Izany no tsy panicking Variant ny [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SAFETY: `BorrowRef` dia miantoka fa tsy misy fiovana tsy azo ovaina fotsiny
            // amin'ny sanda raha mindrana.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Azo atao ny mampindrana ny sandan'ny fonosana.
    ///
    /// Ny indram-bola dia maharitra mandra-piverin'ny `RefMut` na ny `RefMut` izay nalaina avy tao aminy.
    ///
    /// Ny zava-dehibe tsy azo indramina raha mbola miasa ity dia Borrow.
    ///
    /// # Panics
    ///
    /// Panics raha amin'izao fotoana izao ny vidin'ny nindramina.
    /// Ho an'ny variant non-panicking dia ampiasao [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Ohatra iray amin'ny panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutably mindran ny nofonosina vidiny, niverina ny fahadisoana raha ny vidiny amin'izao fotoana izao nindramina.
    ///
    ///
    /// Ny indram-bola dia maharitra mandra-piverin'ny `RefMut` na ny `RefMut` izay nalaina avy tao aminy.
    /// Ny zava-dehibe tsy azo indramina raha mbola miasa ity dia Borrow.
    ///
    /// Izany no tsy panicking Variant ny [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SAFETY: `BorrowRef` dia manome antoka ny fidirana tokana.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Miverina tondro iray manta amin'ireo angona fototra ao amin'ity sela ity.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Miverina fanovana azo ovaina amin'ny angona ifotony.
    ///
    /// Izany antso mindran `RefCell` mutably (amin'ny manangona andro) ka tsy mila taratasim-bola mavitrika.
    ///
    /// Na izany aza mitandrema: ity fomba ity dia manantena fa miova ny `self`, izay matetika tsy izany no izy rehefa mampiasa `RefCell`.
    ///
    /// Topazo maso ny fomba [`borrow_mut`] fa raha tsy `self` mutable.
    ///
    /// Fantaro ihany koa fa ity fomba ity dia tsy natao afa-tsy amin'ny toe-javatra manokana ary matetika tsy izay no tadiavinao.
    /// Raha misy fisalasalana, ampiasao [`borrow_mut`] fa tsy.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Hanafoana ny vokatry ny tafaporitsaka mpiambina eo amin'ny Borrow toetry ny `RefCell`.
    ///
    /// Izany antso izany, fa mitovy amin'ny [`get_mut`] manokana bebe kokoa.
    /// Izany mindran `RefCell` mutably mba hahazoana antoka tsy maka resets misy ary avy eo dia nizara ny fanjakana maka Tracking.
    /// Izany no manan-danja raha misy maka ny `Ref` na `RefMut` no tafaporitsaka.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Mindrana tsy miova ny sanda nofonosina, mamerina lesoka raha toa ka azo indramina nindrana ny sandany.
    ///
    /// # Safety
    ///
    /// Tsy toy ny `RefCell::borrow`, ity fomba ity dia tsy azo antoka satria tsy mamerina `Ref`, ka mamela ny sainam-bola tsy voakitika.
    /// Mutably mindrana ny `RefCell` raha niverina ny boky tamin'ny fomba io dia tsy voafaritra velona fitondran-tena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SAFETY: Hamarininay fa tsy misy olona mavitrika manoratra ankehitriny, fa izany tokoa
            // ny andraikitry ny mpiantso mba hahazoana antoka fa tsy misy olona manoratra mandra-boky niverina dia tsy ampiasaina intsony.
            // Koa, `self.value.get()` dia manondro ny vidiny nanana ny `self` ary dia toy izany no antoka ho marim-pototra ny androm-piainany ny `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Raiso ny sanda fonosina, avelao eo amin'ny toerany ny `Default::default()`.
    ///
    /// # Panics
    ///
    /// Panics raha amin'izao fotoana izao ny vidin'ny nindramina.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics raha azo ampindramina indroa ny sandany.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Mamorona `RefCell<T>`, miaraka amin'ny sanda `Default` ho an'ny T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics raha nindramina ny sandan'ny `RefCell` na izao.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Incrementing Borrow mety amin'ny tsy mamaky danja (<=0) ao amin'ny toe-javatra ireto:
            // 1. <0, ie misy fisoratana indram-panoratana, noho izany tsy azontsika atao ny mamela findramam-bola vakiana noho ny fitsipi-pitenenan'i Rust mifehy
            // 2.
            // I isize::MAX (ny Max habetsahan'ny mamaky maka) Ary nanasaforany an isize::MIN (ny Max habetsaky ny fanoratana maka), ka tsy afaka hamela fanampiny Vakio ny Borrow, satria tsy afaka hisolo tena isize maro Vakio ny maka ny (izany mety ihany no hitranga, raha mem::forget ianao mihoatra noho ny habetsaky ny kely foana: Ref`s, izay tsy fanao tsara)
            //
            //
            //
            //
            None
        } else {
            // Ny fampindrana indram-bola dia mety miteraka lanja famakiana (> 0) amin'ireto tranga ireto:
            // 1. Tamin'ny=0, izany hoe tsy mbola nindramina, ary dia nandray ny voalohany hamaky Borrow
            // 2. Ny> 0 sy <isize::MAX, izany hoe
            // nisy Vakio ny maka, ary isize dia malalaka hisolo tena manana ny iray hafa hamaky ny Borrow
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Koa satria misy Ref ity, fantatray ny Borrow saina dia famakiana hisambotra.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Hisorohana ny latabatra Borrow mba tsy hisy mitete an-tsoratra hisambotra.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Fonosiny nindramina momba ny zava-dehibe ao amin'ny `RefCell` boaty.
/// Karazana fonosana ho an'ny sanda nindrana tsy azo ovaina avy amin'ny `RefCell<T>`.
///
/// Jereo ny [module-level documentation](self) raha mila fanazavana fanampiny.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Mandika `Ref`.
    ///
    /// Ny `RefCell` efa immutably nindramina, ka mety tsy ho levona.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `Ref::clone(...)`.
    /// A `Clone` fampiharana na ny fomba mety hanelingelina ny fampiasana ny `r.borrow().clone()` hatraiza hatraiza mba Clone ny anatiny ny `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Manao `Ref` vaovao ho an'ny singa iray amin'ireo angona nindramina.
    ///
    /// Ny `RefCell` efa immutably nindramina, ka mety tsy ho levona.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `Ref::map(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Manao `Ref` vaovao ho an'ny singa tsy voatery aorina amin'ireo angona nindramina.
    /// Ny mpiambina dia niverina tany am-boalohany ho toy ny `Err(..)` raha hiverina `None` fanakatonana.
    ///
    /// Ny `RefCell` efa immutably nindramina, ka mety tsy ho levona.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `Ref::filter_map(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Mamaky ny `Ref` ho maro: Ref`s ny singa samihafa ao amin'ny nindramina angona.
    ///
    /// Ny `RefCell` efa immutably nindramina, ka mety tsy ho levona.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `Ref::map_split(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Niova fo ho fanondro ny antontan-kevitra fototra.
    ///
    /// Ny `RefCell` ifotony dia tsy azo indramina mihodina indray ary hiseho efa nindrana tsy mety miova.
    ///
    /// Tsy hevitra tsara ny mandefa tsy tapaka bebe kokoa noho ny andinin-tsoratra masina maro.
    /// Ny `RefCell` dia azo indramina tsy azo ovaina indray raha tsy misy afa-tsy fivoahana kely kokoa fotsiny no nitranga.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `Ref::leak(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Raha manadino an'io Ref io isika dia manome antoka fa ny counter counter amin'ny RefCell dia tsy afaka miverina amin'ny UNUSED mandritra ny androm-piainana `'b`.
        // Ny famerenana ny fanjakana fanaraha-maso dia mila referansa tokana amin'ny RefCell nindramina.
        // Tsy misy tohiny azo ovaina intsony azo foronina avy amin'ilay sela tany am-boalohany.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Manao `RefMut` vaovao ho an'ny singa iray amin'ireo angona nindramina, ohatra, enum variant.
    ///
    /// Ny `RefCell` dia efa indramina nindraminy, ka tsy hahomby io.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `RefMut::map(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): manamboatra fanamarinana indram-bola
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Manao `RefMut` vaovao ho an'ny singa tsy voatery aorina amin'ireo angona nindramina.
    /// Ny mpiambina dia niverina tany am-boalohany ho toy ny `Err(..)` raha hiverina `None` fanakatonana.
    ///
    /// Ny `RefCell` dia efa indramina nindraminy, ka tsy hahomby io.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `RefMut::filter_map(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): manamboatra fanamarinana indram-bola
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: miasa miasa amin'ny referansa manokana amin'ny faharetana
        // ny fiantsoana azy amin'ny alàlan'ny `orig`, ary ny tondro dia tsy voatonona afa-tsy ao anaty ilay antso hoe tsy mamela ny referansa manokana afa-mandositra.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: mitovy amin'ny etsy ambony.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Mizara `RefMut` ho `RefMut` maro ho an'ny singa samihafa amin'ny angona nindramina.
    ///
    /// Ny fototra `RefCell` dia hijanona mutably nindramina mandra samy niverina `RefMut`s miala lenta.
    ///
    /// Ny `RefCell` dia efa indramina nindraminy, ka tsy hahomby io.
    ///
    /// Izany dia fiasa mifandraika izay mila ampiasaina amin'ny `RefMut::map_split(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Niova fo ho mutable fototra momba ny angon-drakitra.
    ///
    /// Ny fototra `RefCell` tsy azo nindramina avy indray, ary efa hiseho foana mutably nindramina, ka mahatonga ny niverina momba ny ihany ny anatiny.
    ///
    ///
    /// Izany dia mifandray ny asa izay tokony ho ampiasaina ho `RefMut::leak(...)`.
    /// Ny fomba mety hanelingelina fomba mitovy anarana amin'ny votoatin'ny ny `RefCell` ampiasaina amin'ny alalan'ny `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ny fanadinoana izany BorrowRefMut no hahazoana antoka fa ny Borrow hanoherana ao amin'ny RefCell tsy afaka hiverina any maromaro ao anatin'ny androm-piainany `'b`.
        // Ny famerenana ny fanjakana fanaraha-maso dia mila referansa tokana amin'ny RefCell nindramina.
        // Tsy misy referansa hafa azo foronina avy amin'ilay sela tany am-boalohany tao anatin'ny androm-piainany, ka ny findramam-bola amin'izao fotoana izao no hany referansa amin'ny andiany sisa.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Tsy toy ny BorrowRefMut::clone, vaovao no antsoina hamoronana ny voalohany
        // referable miovaova, ary noho izany dia tsy tokony misy referansa misy.
        // Noho izany, raha mitombo tsikelikely ny mutable Clone refcount, Eto isika dia mazava ihany no mamela handeha avy maromaro ho maromaro, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clones ny `BorrowRefMut`.
    //
    // Izany no manan-kery ihany, raha `BorrowRefMut` tsirairay dia ampiasaina mba manara-maso ny mutable momba ny miavaka, nonoverlapping isan-karazany ny zavatra tany am-boalohany.
    //
    // Tsy ao amin'ny Clone impl mba fehezan-dalàna no tsy mba niantso izany tanteraka.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Hisorohana ny latabatra avy underflowing Borrow.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Karazana fonosana iray ho an'ny sanda azo indramina azo ampindramina avy amin'ny `RefCell<T>`.
///
/// Jereo ny [module-level documentation](self) raha mila fanazavana fanampiny.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Ny fototra faran'izay tsotra ny anatiny mutability in Rust.
///
/// Raha manana boky `&T`, dia mazàna in Rust ny compiler manao optimizations miorina amin'ny fahalalana fa `&T` manondro loha tsy mety miova angona.Mutating fa ny tahirin-kevitra, ohatra amin'ny alalan'ny antsoina na amin'ny alalan'ny transmuting ny `&T` ho any an-`&mut T`, dia heverina ho tsy voafaritra fitondran-tena.
/// `UnsafeCell<T>` mifidy ny antoka tsy azo ovaina ho an'ny `&T`: ny referansa `&UnsafeCell<T>` nozaraina dia mety hanondro data izay miovaova.Io dia antsoina hoe "interior mutability".
///
/// Ny karazana hafa rehetra mamela ny fiovaovana ao anaty, toy ny `Cell<T>` sy `RefCell<T>`, dia mampiasa `UnsafeCell` ao anatiny mba hamonosana ny angon-drakitra.
///
/// Mariho fa ny antoka tsy azo ovaina amin'ny referansa iraisana ihany no voakasiky ny `UnsafeCell`.Ny fiantohana tokana amin'ny fanovozan-kevitra miovaova dia tsy misy fiatraikany.Tsy misy *fomba* ara-dalàna hahazoana aliasing `&mut`, na dia amin'ny `UnsafeCell<T>` aza.
///
/// Ny `UnsafeCell` API ara-teknika mihitsy no tena tsotra: [`.get()`] manome anao ny manta manondro `*mut T` ho amin'ny anatiny.Miankina amin'ny _you_ ho toy ny mpamorona abstraction hampiasa tsara azy io.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Somary mikorontana ihany ny fitsipi-pifehezana Rust marina, saingy tsy mifanditra ireo hevi-dehibe:
///
/// - Raha mamorona andinin-tsoratra azo antoka ianao amin'ny androm-piainana `'a` (na referansa `&T` na `&mut T`) izay azo alaina amin'ny kaody azo antoka (ohatra, satria naverinao io), dia tsy tokony hidiranao amin'ny data na oviana na oviana ny angona amin'ny fomba mifanohitra amin'izany. an'ny `'a`.
/// Ohatra, Midika izany fa raha maka ny `*mut T` avy amin'ny `UnsafeCell<T>` ka manipy azy ho amin'ny `&T`, dia ny antontan-kevitra dia tsy maintsy mijanona ao amin'ny `T` loha tsy mety miova (modulo `UnsafeCell` misy tahirin-kevitra hita ao `T`, mazava ho azy) mandra-pahatongan'ny momba ny androm-piainany Tapitra.
/// Toy izany koa, raha mamorona `&mut T` boky izay navoaka ho azo antoka fehezan-dalàna, dia tsy maintsy tsy mahazo ny antontan-kevitra ao anatin'ny `UnsafeCell` mandra-pahatongan'ny boky Tapitra.
///
/// - Amin'ny fotoana rehetra dia tsy maintsy sorohinao ny firazanana data.Raha kofehy marobe no mahazo `UnsafeCell` mitovy, dia tsy maintsy misy ny fisoratana misy raha sendra misy ifandraisany amin'ireo fidirana hafa rehetra (na mampiasa atomika).
///
/// Mba hanampiana amin'ny famolavolana sahaza azy, ireto tranga manaraka ireto dia nambara mazava fa ara-dalàna amin'ny kaody tokana:
///
/// 1. A `&T` reference azo navoaka ny fehezan-dalàna soa aman-tsara ary afaka miara-misy hafa `&T` andinin-tsoratra masina, nefa tsy dia tamin'ny `&mut T`
///
/// 2. A `&mut T` reference dia mety ho afaka ho azo antoka sady tsy nanome fehezan-dalàna `&mut T` hafa na `&T` mpiara-misy ny izany.A `&mut T` dia tsy maintsy ho tsy manan-tsahala foana.
///
/// Mariho fa raha mitoetra mutating ny votoatin'ny iray `&UnsafeCell<T>` (na dia andinin-tsoratra masina hafa `&UnsafeCell<T>` antsoina amin'ny sela) dia OK (nanome anao hampihatra ny ambony invariants fomba hafa), dia mbola tsy voafaritra mba hanana fitondran-tena maro `&mut UnsafeCell<T>` aliases.
/// Izany hoe `UnsafeCell` dia wrapper natao manana fifandraisana manokana amin'i _shared_ accesses (_i.e._, alalan'ny `&UnsafeCell<_>` reference);tsy misy majika na inona na inona rehefa mifampiraharaha amin'ny _exclusive_ accesses (_e.g._, amin'ny alàlan'ny `&mut UnsafeCell<_>`): na ny sela na ny sanda voafono dia mety tsy alahatra mandritra ny fotoana fitrandrahana `&mut`.
///
/// Izany no showcased ny [`.get_mut()`] accessor, izay ny _safe_ getter izay mahavokatra ny `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ity misy ohatra iray mampiseho ny fomba hanovana tsara ny atin'ny `UnsafeCell<_>` na eo aza ny fanovozan-kevitra marobe manoloana ny sela:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Get maro/nizara andinin-tsoratra masina ho toy izany koa `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SAFETY: ao anatin'ity sehatra ity dia tsy misy fanondroana hafa momba ny atiny `x`,
///     // noho izany ny antsika dia miavaka miavaka.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- mindrana-+
///     *p1_exclusive += 27; // |
/// } // <---------- tsy afaka mihoatra an'io teboka io -------------------+
///
/// unsafe {
///     // Famonjena, ao anatin'ny votoatiny ity tsy misy olona manantena ny hanana manokana ny fidirana amin'ny: x` ny votoatin'ny,
///     // mba hahafahantsika manana nizara accesses maro amin'ny fotoana mitovy.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Ny ohatra manaraka dia manapariaka ny hoe manokana ny fidirana ho amin'ny `UnsafeCell<T>` dia midika fidirana manokana ho any amin'ny `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // amin'ny accesses manokana,
///                         // `UnsafeCell` dia fonosana mangarahara tsy misy op-op, ka tsy mila `unsafe` eto.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Makà referansa tsy manam-paharoa voamarina amin'ny `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Amin'ny alàlan'ny referansa manokana, azontsika atao ny manova ny atiny maimaimpoana.
/// *p_unique.get_mut() = 0;
/// // Na, equivalently:
/// x = UnsafeCell::new(0);
///
/// // Rehefa manana ny sandany isika dia afaka mamoaka maimaimpoana ny atiny.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Manangana tranga vaovao `UnsafeCell` izay hamonosana ny sandany voatondro.
    ///
    ///
    /// Ny fidirana amin'ny sanda anatiny amin'ny alàlan'ny fomba dia `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Mamaha ny sanda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Mahazo mpanondro azo ovaina amin'ny sanda fonosina.
    ///
    /// Izany dia mety ho nandatsaka ny manondro na inona na inona.
    /// Hamarino fa tsy manam-paharoa ny fidirana (tsy misy referansy mavitrika, azo ovaina na tsia) rehefa mandefa mankany `&mut T`, ary alao antoka fa tsy misy fiovana na solonanarana azo ovaina rehefa mandefa mankany `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Azontsika atao ny mandefa ny pointer amin'ny `UnsafeCell<T>` mankany `T` noho ny #[repr(transparent)].
        // Manararaotra ny satan'ny libstd manokana izy io, tsy misy antoka ho an'ny kaody mpampiasa fa miasa amin'ny kinova future an'ny mpamorona!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Miverina fanovana azo ovaina amin'ny angona ifotony.
    ///
    /// Ity antso ity dia mindrana ny `UnsafeCell` azo ovaina (amin'ny fotoana atambatra) izay manome antoka fa manana ilay hany referansa isika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Mahazo mpanondro azo ovaina amin'ny sanda fonosina.
    /// Ny mahasamihafa ny [`get`] dia ity ekipa ity mandray ekena mpanondro, izay ilaina hialana amin'ny famoronana referansa vonjimaika.
    ///
    /// Ny valiny dia azo alefa amin'ny tondro na inona na inona karazany.
    /// Hahazoana antoka fa ny fidirana tsy manam-paharoa (tsy mavitrika andinin-tsoratra masina, mutable na tsia) rehefa namoaka ny `&mut T`, ary azo antoka fa tsy misy fiovana na mutable aliases mitranga rehefa namoaka ny `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Tsikelikely initialization iray dia mitaky `UnsafeCell` `raw_get`, toy ny miantso `get` dia mila mamorona ny momba ny uninitialized Data:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Azontsika atao ny mandefa ny pointer amin'ny `UnsafeCell<T>` mankany `T` noho ny #[repr(transparent)].
        // Manararaotra ny satan'ny libstd manokana izy io, tsy misy antoka ho an'ny kaody mpampiasa fa miasa amin'ny kinova future an'ny mpamorona!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Mamorona `UnsafeCell`, miaraka amin'ny sanda `Default` ho an'ny T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}