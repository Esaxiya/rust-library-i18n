use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Miverina `true` raha toa tsy mandeha ny tondro.
    ///
    /// Mariho fa ny karazana tsy voamarika dia manana tondro maro azo namboarina, satria ny mpanondro tahirin-kevitra fotsiny no jerena fa tsy ny halavany, ny latabatra sns.
    /// Noho izany, ny tondro roa izay tsy misy dikany dia mety mbola tsy ampitahaina amin'ny tsirairay.
    ///
    /// ## Fihetsika mandritra ny fanombanana
    ///
    /// Rehefa ampiasaina mandritra ny fanombanana ny const io fiasa io dia mety hiverina `false` ho an'ny tondro izay mivadika ho tsy mandeha amin'ny fotoana maharitra.
    /// Raha ny tena manokana, raha ny pointer amin'ny fahatsiarovana sasany dia voafafa mihoatra ny fetrany ka tsy mahomby ilay mpanondro vokatr'izany dia mbola hiverina `false` ny asany.
    ///
    /// Tsy misy fomba ahafahan'ny CTFE hahalala ny tena toerana misy an'io fitadidiana io, noho izany tsy azontsika atao ny milaza raha tsy mandeha na tsia ilay mpanondro.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Ampitahao amin'ny alàlan'ny mpilalao amin'ny tondro manify, noho izany dia manondro ny ampahany "data" ho an'ny null-ness fotsiny ireo tondro matavy.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Mandidy amin'ny tondro hafa karazana.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Arotsaho ny isa (mety ho sakany) ho adiresy sy singa metadata.
    ///
    /// Ny tondro dia afaka averina haorina amin'ny [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Miverina `None` raha tsy misy dikany ny tondro, na raha tsy izany dia miverina fanondroana iraisana momba ny sanda nofonosina `Some`.Raha mety tsy voahaja ny sanda, [`as_uninit_ref`] dia tokony hampiasaina.
    ///
    /// Ho an'ny mpiara-miasa azo ovaina dia jereo [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila miantoka fa *na* ilay pointer dia NULL *na* marina daholo ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Ny tondro dia tsy maintsy manondro ohatra voalohany `T`.
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///   Manokana, mandritra ny androm-piainanao, ny fahatsiarovan'ny mpanondro nanondro fa tsy tokony ho mutated (afa-tsy ao anatin'ny `UnsafeCell`).
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    /// (Ny ampahany momba ny fanombohana azy dia mbola tsy tapa-kevitra tanteraka, fa mandra-pahatongan'izany, ny fomba tokana azo antoka dia ny miantoka fa voalahatra tokoa izy ireo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Dikan-teny tsy voamarina
    ///
    /// Raha azonao antoka fa ny pointer dia tsy afaka null ary mitady karazana `as_ref_unchecked` mamerina ny `&T` fa tsy `Option<&T>`, fantaro fa azonao atao ny manala ny pointer mivantana.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` manan-kery ho an'ny a
        // raha tsy null ilay izy.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Miverina `None` raha tsy misy dikany ny tondro, na raha tsy izany dia miverina fanondroana iraisana momba ny sanda nofonosina `Some`.
    /// Mifanohitra amin'ny [`as_ref`], ity dia tsy mitaky ny hamaritana ny sandany.
    ///
    /// Ho an'ny mpiara-miasa azo ovaina dia jereo [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila miantoka fa *na* ilay pointer dia NULL *na* marina daholo ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///
    ///   Manokana, mandritra ny androm-piainanao, ny fahatsiarovan'ny mpanondro nanondro fa tsy tokony ho mutated (afa-tsy ao anatin'ny `UnsafeCell`).
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // takiana amin'ny referansa.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Kajy ny offset avy amin'ny manondro.
    ///
    /// `count` dia ao anatin'ny tarika T;oh, ny `count` an'ny 3 dia maneho ny isa fanondroana ny byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Raha misy amin'ireto fepetra manaraka ireto no voahitsakitsaka, ny vokany dia fitondran-tena tsy voafaritra:
    ///
    /// * Na ny tondro fanombohana sy ny vokatr'izany dia tsy maintsy ao anaty fetra na byte iray aorian'ny faran'ny zavatra natokana mitovy.
    /// Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
    ///
    /// * Ny offset voaisa,**amin'ny bytes**, dia tsy afaka mihoatra ny `isize`.
    ///
    /// * Na dia nanana ny offset fetra tsy afaka miantehitra amin'ny "wrapping around" ny adiresy toerana.Izany hoe, ny vola tsy voafetra,**amin'ny bytes** dia tsy maintsy tafiditra ao anaty usize.
    ///
    /// Ny compiler sy ny trano famakiam-boky mahazatra dia manandrana manome antoka ny fizarana tsy hahatratra habe iray izay ahiana ny offset.
    /// Ohatra, `Vec` sy `Box` dia miantoka fa tsy manokana mihoatra ny `isize::MAX` bytes, ka dia azo antoka `vec.as_ptr().add(vec.len())`.
    ///
    /// Ny ankamaroan'ny sehatra dia tsy afaka manamboatra fizarana toy izany akory.
    /// Ohatra, tsy misy sehatra 64-bit fantatra afaka manolotra fangatahana 2 <sup>63</sup> bytes noho ny fetran'ny latabatra amin'ny pejy na ny fizarana ny habaka adiresy.
    /// Na izany aza, ny sehatra 32-bit sy 16-bit sasany dia mety hahomby amin'ny fanatanterahana fangatahana mihoatra ny `isize::MAX` bytes miaraka amin'ny zavatra toy ny Physical Address Extension.
    ///
    /// Araka izany, ny memoara azo avy amin'ny mpizara sy ny rakitra an-tsarintany * dia mety ho lehibe loatra ka tsy zakan'ity asa ity.
    ///
    /// Hevero ny fampiasana [`wrapping_offset`] raha toa ka sarotra ny manome fahafaham-po ireo famerana ireo.
    /// Ny tombony tokana amin'ity fomba ity dia ny fanamafisana ny fanamafisana ny fanamafisam-peo mahery setra.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `offset`.
        // Ny pointer azo dia manan-kery amin'ny fanoratana satria ny miantso dia tsy maintsy manome toky fa manondro ny zavatra natokana mitovy amin'ny `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Kajy ny offset avy amin'ny tondro iray mampiasa arithmetika fonosana.
    /// `count` dia ao anatin'ny tarika T;oh, ny `count` an'ny 3 dia maneho ny isa fanondroana ny byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ity fandidiana ity dia azo antoka foana, fa ny fampiasana ny mpanondro vokany dia tsy.
    ///
    /// Ny valim-panondroana vokatr'izany dia miraikitra amin'ilay zavatra natokana mitovy amin'ilay tondro `self`.
    /// Mety *tsy* hampiasaina mba mahazo zavatra hafa omena.Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
    ///
    /// Raha lazaina amin'ny teny hafa, `let z = x.wrapping_offset((y as isize) - (x as isize))` dia tsy *manao*`z` mitovy amin'ny `y` na dia heverintsika fa `T` dia manana habe `1` ary tsy misy onjampeo: `z` dia mbola miraikitra amin'ilay zavatra `x` mifamatotra aminy, ary ny fanalavirana izany dia fitondran-tena tsy voafaritra raha tsy hoe `x` sy `y` manondro an'io zavatra natokana io ihany.
    ///
    /// Raha oharina amin'ny [`offset`], io fomba fahatarana Raha jerena ankapobeny ny fitakiana ny mitoetra ao anatin'ny zavatra natokana ihany: [`offset`] dia avy hatrany Undefined Behavior rehefa niampita zavatra faritra;`wrapping_offset` dia mamokatra tondro iray nefa mbola mitarika amin'ny fitondran-tena tsy voafaritra raha toa ka tsy mahazo tombony ny mpanondro rehefa lavitra ny fetra amin'ilay zavatra niraiketany.
    /// [`offset`] azo hatsaraina tsara kokoa ary tsara kokoa amin'ny kaody mora tohina amin'ny fampisehoana.
    ///
    /// Ny fanamarinana mihemotra dia tsy mihevitra afa-tsy ny sandan'ny pointer izay nesorina, fa tsy ny sanda antonony nampiasaina nandritra ny fanisana ny valiny farany.
    /// Ohatra, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` dia mitovy amin'ny `x` foana.Amin'ny teny hafa, fa namela ny zavatra natokana ary avy eo dia Namerina-miditra izany tatỳ aoriana dia navela.
    ///
    /// Raha mila miampita ny fetran'ny zavatra ianao dia atsipazo amin'ny integer ny pointer ary ataovy eo ny arithmetika.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // Iterate mampiasa pointer manta amin'ny fampitomboana singa roa
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: ny intrinsika `arith_offset` dia tsy misy fepetra takiana hantsoina.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Miverina `None` raha tsy misy dikany ny tondro, na raha tsy izany dia miverina fanondro tsy manam-paharoa amin'ny sanda nofonosina `Some`.Raha mety tsy voahaja ny sanda, [`as_uninit_mut`] dia tokony hampiasaina.
    ///
    /// Ho an'ny mpifanaraka zara dia jereo [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila miantoka fa *na* ilay pointer dia NULL *na* marina daholo ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Ny tondro dia tsy maintsy manondro ohatra voalohany `T`.
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///   Manokana, mandritra ny androm-piainana ity, ny fahatsiarovana izay tondroin'ny tondro dia tsy tokony hiditra (vakiana na soratana) amin'ny alàlan'ny tondro hafa.
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    /// (Ny ampahany momba ny fanombohana azy dia mbola tsy tapa-kevitra tanteraka, fa mandra-pahatongan'izany, ny fomba tokana azo antoka dia ny miantoka fa voalahatra tokoa izy ireo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Hatao pirinty izy io: "[4, 2, 3]".
    /// ```
    ///
    /// # Dikan-teny tsy voamarina
    ///
    /// Raha azonao antoka fa ny pointer dia tsy afaka null ary mitady karazana `as_mut_unchecked` mamerina ny `&mut T` fa tsy `Option<&mut T>`, fantaro fa azonao atao ny manala ny pointer mivantana.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Hatao pirinty izy io: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` dia mitombina
        // fanovozan-kevitra azo ovaina raha tsy null.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Miverina `None` raha tsy misy dikany ny tondro, na raha tsy izany dia mamerina fanamarihana tokana momba ny sanda nofonosina `Some`.
    /// Mifanohitra amin'ny [`as_mut`], ity dia tsy mitaky ny hamaritana ny sandany.
    ///
    /// Fa ny Shared mitovy jereo [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila miantoka fa *na* ilay pointer dia NULL *na* marina daholo ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///
    ///   Manokana, mandritra ny androm-piainana ity, ny fahatsiarovana izay tondroin'ny tondro dia tsy tokony hiditra (vakiana na soratana) amin'ny alàlan'ny tondro hafa.
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // takiana amin'ny referansa.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Miverina raha misy tondro roa azo antoka fa hitovy.
    ///
    /// Amin'ny fotoana fohy, ity fiasa ity dia mitondra tena toy ny `self == other`.
    /// Na dia izany aza, amin'ny toe-javatra sasany (ohatra, manangona andro tombana), dia tsy azo atao ny mamaritra foana fitoviana roa sahaza, ka asa izany dia mety hiverina spuriously `false` ho an'ny mpanondro izay raha ny marina tatỳ aoriana hiverina avy mba hitovy.
    ///
    /// Fa rehefa miverina `true` izy, dia azo antoka fa hitovy ny tondro.
    ///
    /// Ity fiasa ity dia fitaratry ny [`guaranteed_ne`], fa tsy ny fivadika.Misy ny fampitahana ireo mpanondro izay samy miverina `false` avokoa.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Ny valiny miverina dia mety hiova arakaraka ny kinovan'ny mpanangona ary ny kaody tsy azo antoka dia mety tsy hiankina amin'ny valin'ity fiasa ity ho an'ny fahasalamana.
    /// Soso-kevitra ny hampiasa an'io asa io fotsiny ho an'ny fanatsarana ny fahombiazana izay tsy misy fiantraikany amin'ny valiny ny sanda miverina `false` avy amin'ity fiasa ity fa ny zava-bita fotsiny.
    /// Ny vokatry ny fampiasana an'io fomba io hanamboarana fe-potoana fahita fotoana sy fehezan-dalàna tsy hitadiavana.
    /// Ity fomba ity dia tsy tokony hampiasaina hampidirana fahasamihafana toy izany, ary tsy tokony hampiorina ihany koa izy io alohan'ny hahatakarantsika tsara kokoa an'ity olana ity.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Miverina raha misy tondro roa azo antoka fa tsy mitovy.
    ///
    /// Amin'ny fotoana fohy, ity fiasa ity dia mitondra tena toy ny `self != other`.
    /// Na izany aza, amin'ny toe-javatra sasantsasany (oh: fanombanana fotoana fanombanana), tsy azo atao foana ny mamaritra ny tsy fitovian'ny tondro roa, noho izany io fiasa io dia mety hiverina `false` ho an'ny tondro izay hitany fa tsy mitovy.
    ///
    /// Fa rehefa miverina `true` izy, dia azo antoka fa tsy hitovy ireo tondro.
    ///
    /// Ity fiasa ity dia fitaratry ny [`guaranteed_eq`], fa tsy ny fivadika.Misy fampitahana izay manondro asa na hiverina `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Ny valiny miverina dia mety hiova arakaraka ny kinovan'ny mpanangona ary ny kaody tsy azo antoka dia mety tsy hiankina amin'ny valin'ity fiasa ity ho an'ny fahasalamana.
    /// Soso-kevitra ny hampiasa an'io asa io fotsiny ho an'ny fanatsarana ny fahombiazana izay tsy misy fiantraikany amin'ny valiny ny sanda miverina `false` avy amin'ity fiasa ity fa ny zava-bita fotsiny.
    /// Ny vokatry ny fampiasana an'io fomba io hanamboarana fe-potoana fahita fotoana sy fehezan-dalàna tsy hitadiavana.
    /// Ity fomba ity dia tsy tokony hampiasaina hampidirana fahasamihafana toy izany, ary tsy tokony hampiorina ihany koa izy io alohan'ny hahatakarantsika tsara kokoa an'ity olana ity.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Kajy ny elanelana misy eo amin'ny tondro roa.Ny sanda miverina dia ao anatin'ny singa T: ny halaviran'ny bytes dia zaraina amin'ny `mem::size_of::<T>()`.
    ///
    /// Ity fiasa ity dia ny mifanohitra amin'ny [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Raha misy amin'ireto fepetra manaraka ireto no voahitsakitsaka, ny vokany dia fitondran-tena tsy voafaritra:
    ///
    /// * Na ny fanombohana na ny fanondroana hafa dia tsy maintsy arahana sisin-tany na iray byte aorian'ny faran'ny zavatra natokana mitovy.
    /// Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
    ///
    /// * Ireo tondro roa ireo dia tsy maintsy * nalaina avy amin'ny tondro iray amin'ny zavatra iray ihany.
    ///   (Jereo eto ambany ohatra.)
    ///
    /// * Ny elanelana misy eo anelanelan'ny tondro, amin'ny bytes, dia tsy maintsy refesina mitovy habe amin'ny `T`.
    ///
    /// * Ny elanelana misy eo amin'ny tondro,**amin'ny bytes**, dia tsy afaka mihoatra ny `isize`.
    ///
    /// * Ny elanelana misy eo amin'ny fetra dia tsy afaka miankina amin'ny "wrapping around" ny habaka adiresy.
    ///
    /// Rust karazana dia tsy lehibe noho `isize::MAX` sy Rust tsy mamatotra manodidina vola omena ny adiresy toerana, ka ao anatin'ny roa sahaza sasany hasarobidin'ny misy Rust `T` karazana fahafaham-po foana ny farany roa fepetra.
    ///
    /// Ny trano famakiam-boky mahazatra ihany koa dia manome antoka fa ny famatsiam-bola dia tsy hahatratra habe velively izay ahina ny offset.
    /// Ohatra, `Vec` sy `Box` dia miantoka fa tsy manokana mihoatra ny `isize::MAX` bytes, ka `ptr_into_vec.offset_from(vec.as_ptr())` dia manome fahafaham-po ireo fepetra roa farany.
    ///
    /// Ny ankamaroan'ny sehatra dia tsy afaka manangana vola be toy izany akory.
    /// Ohatra, tsy misy sehatra 64-bit fantatra afaka manolotra fangatahana 2 <sup>63</sup> bytes noho ny fetran'ny latabatra amin'ny pejy na ny fizarana ny habaka adiresy.
    /// Na izany aza, ny sehatra 32-bit sy 16-bit sasany dia mety hahomby amin'ny fanatanterahana fangatahana mihoatra ny `isize::MAX` bytes miaraka amin'ny zavatra toy ny Physical Address Extension.
    /// Araka izany, ny memoara azo avy amin'ny mpizara sy ny rakitra an-tsarintany * dia mety ho lehibe loatra ka tsy zakan'ity asa ity.
    /// (Mariho fa [`offset`] sy [`add`] koa toy izany koa tsy fahatanterahany ka noho izany dia tsy azo ampiasaina amin'ny vola omena na lehibe toy izany.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ity fiasan'ny panics ity raha `T` dia karazana ("ZST") Zero-Sized.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Fampiasana diso*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ataovy ptr2_other ny "alias" an'ny ptr2, fa azo avy amin'ny ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Satria ptr2_other sy ptr2 dia nalaina avy amin'ny tondro mankany amin'ny zavatra isan-karazany, ny fanisana ny offset-dry zareo dia fihetsika tsy voafaritra, na dia mitovy ny adiresy omeny!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Undefined Behavior
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Kajy ny offset avy amin'ny tondro (mora amin'ny `.offset(count as isize)`).
    ///
    /// `count` dia ao anatin'ny tarika T;oh, ny `count` an'ny 3 dia maneho ny isa fanondroana ny byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Raha misy amin'ireto fepetra manaraka ireto no voahitsakitsaka, ny vokany dia fitondran-tena tsy voafaritra:
    ///
    /// * Na ny tondro fanombohana sy ny vokatr'izany dia tsy maintsy ao anaty fetra na byte iray aorian'ny faran'ny zavatra natokana mitovy.
    /// Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
    ///
    /// * Ny offset voaisa,**amin'ny bytes**, dia tsy afaka mihoatra ny `isize`.
    ///
    /// * Na dia nanana ny offset fetra tsy afaka miantehitra amin'ny "wrapping around" ny adiresy toerana.Izany hoe, tsy manam-petra-fametrahana mazava tsara vola dia tsy maintsy antonona ao amin'ny `usize`.
    ///
    /// Ny compiler sy ny trano famakiam-boky mahazatra dia manandrana manome antoka ny fizarana tsy hahatratra habe iray izay ahiana ny offset.
    /// Ohatra, `Vec` sy `Box` dia miantoka fa tsy manokana mihoatra ny `isize::MAX` bytes, ka dia azo antoka `vec.as_ptr().add(vec.len())`.
    ///
    /// Ny ankamaroan'ny sehatra dia tsy afaka manamboatra fizarana toy izany akory.
    /// Ohatra, tsy misy sehatra 64-bit fantatra afaka manolotra fangatahana 2 <sup>63</sup> bytes noho ny fetran'ny latabatra amin'ny pejy na ny fizarana ny habaka adiresy.
    /// Na izany aza, ny sehatra 32-bit sy 16-bit sasany dia mety hahomby amin'ny fanatanterahana fangatahana mihoatra ny `isize::MAX` bytes miaraka amin'ny zavatra toy ny Physical Address Extension.
    ///
    /// Araka izany, ny memoara azo avy amin'ny mpizara sy ny rakitra an-tsarintany * dia mety ho lehibe loatra ka tsy zakan'ity asa ity.
    ///
    /// Hevero ny fampiasana [`wrapping_add`] raha toa ka sarotra ny manome fahafaham-po ireo famerana ireo.
    /// Ny tombony tokana amin'ity fomba ity dia ny fanamafisana ny fanamafisana ny fanamafisam-peo mahery setra.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Kajy ny offset avy amin'ny tondro (mora amin'ny `.offset ((isaina ho isize).wrapping_neg())`).
    ///
    /// `count` dia ao anatin'ny tarika T;oh, ny `count` an'ny 3 dia maneho ny isa fanondroana ny byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Raha misy amin'ireto fepetra manaraka ireto no voahitsakitsaka, ny vokany dia fitondran-tena tsy voafaritra:
    ///
    /// * Na ny tondro fanombohana sy ny vokatr'izany dia tsy maintsy ao anaty fetra na byte iray aorian'ny faran'ny zavatra natokana mitovy.
    /// Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
    ///
    /// * Ny offset novaina dia tsy afaka mihoatra ny `isize::MAX`**bytes**.
    ///
    /// * Ny offset izay ao anatin'ny fetra dia tsy afaka miankina amin'ny "wrapping around" ny habaka adiresy.Izany hoe, ny vola tsy manam-petra dia tsy maintsy mifanaraka amin'ny usize.
    ///
    /// Ny compiler sy ny trano famakiam-boky mahazatra dia manandrana manome antoka ny fizarana tsy hahatratra habe iray izay ahiana ny offset.
    /// Ohatra, `Vec` sy `Box` antoka na oviana na oviana izy ireo mihoatra noho ny `isize::MAX` zarao oktety, ka `vec.as_ptr().add(vec.len()).sub(vec.len())` soa aman-tsara foana.
    ///
    /// Ny ankamaroan'ny sehatra dia tsy afaka manamboatra fizarana toy izany akory.
    /// Ohatra, tsy misy sehatra 64-bit fantatra afaka manolotra fangatahana 2 <sup>63</sup> bytes noho ny fetran'ny latabatra amin'ny pejy na ny fizarana ny habaka adiresy.
    /// Na izany aza, ny sehatra 32-bit sy 16-bit sasany dia mety hahomby amin'ny fanatanterahana fangatahana mihoatra ny `isize::MAX` bytes miaraka amin'ny zavatra toy ny Physical Address Extension.
    ///
    /// Araka izany, ny memoara azo avy amin'ny mpizara sy ny rakitra an-tsarintany * dia mety ho lehibe loatra ka tsy zakan'ity asa ity.
    ///
    /// Hevero ny fampiasana [`wrapping_sub`] raha toa ka sarotra ny manome fahafaham-po ireo famerana ireo.
    /// Ny tombony tokana amin'ity fomba ity dia ny fanamafisana ny fanamafisana ny fanamafisam-peo mahery setra.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Kajy ny offset avy amin'ny tondro iray mampiasa arithmetika fonosana.
    /// (mety amin'ny `.wrapping_offset(count as isize)`)
    ///
    /// `count` dia ao anatin'ny tarika T;oh, ny `count` an'ny 3 dia maneho ny isa fanondroana ny byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ity fandidiana ity dia azo antoka foana, fa ny fampiasana ny mpanondro vokany dia tsy.
    ///
    /// Ny valim-panondroana vokatr'izany dia miraikitra amin'ilay zavatra natokana mitovy amin'ilay tondro `self`.
    /// Mety *tsy* hampiasaina mba mahazo zavatra hafa omena.Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
    ///
    /// Raha lazaina amin'ny teny hafa, `let z = x.wrapping_add((y as usize) - (x as usize))` dia tsy *manao*`z` mitovy amin'ny `y` na dia heverintsika fa `T` dia manana habe `1` ary tsy misy onjampeo: `z` dia mbola miraikitra amin'ilay zavatra `x` mifamatotra aminy, ary ny fanalavirana izany dia fitondran-tena tsy voafaritra raha tsy hoe `x` sy `y` manondro an'io zavatra natokana io ihany.
    ///
    /// Raha ampitahaina amin'ny [`add`], ity fomba ity dia manemotra ny fepetra takiana amin'ny fijanonana ao anatin'ilay zavatra natokana mitovy: [`add`] dia fitondran-tena tsy voafaritra eo noho eo rehefa miampita ny fetran'ny zavatra;`wrapping_add` dia mamokatra tondro iray nefa mbola mitarika amin'ny fitondran-tena tsy voafaritra raha toa ka tsy mahazo tombony ny mpanondro rehefa lavitra ny fetra amin'ilay zavatra niraiketany.
    /// [`add`] azo hatsaraina tsara kokoa ary tsara kokoa amin'ny kaody mora tohina amin'ny fampisehoana.
    ///
    /// Ny fanamarinana mihemotra dia tsy mihevitra afa-tsy ny sandan'ny pointer izay nesorina, fa tsy ny sanda antonony nampiasaina nandritra ny fanisana ny valiny farany.
    /// Ohatra, `x.wrapping_add(o).wrapping_sub(o)` dia mitovy amin'ny `x` foana.Raha lazaina amin'ny teny hafa, ny mamela ny zavatra natokana ary avy eo dia miditra indray avy eo avela.
    ///
    /// Raha mila miampita ny fetran'ny zavatra ianao dia atsipazo amin'ny integer ny pointer ary ataovy eo ny arithmetika.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // Iterate mampiasa pointer manta amin'ny fampitomboana singa roa
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ity loop ity dia manao pirinty "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Kajy ny offset avy amin'ny tondro iray mampiasa arithmetika fonosana.
    /// (fanamorana ny `.wrapping_offset ((isao ho isize).wrapping_neg())`)
    ///
    /// `count` dia ao anatin'ny tarika T;oh, ny `count` an'ny 3 dia maneho ny isa fanondroana ny byte `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ity fandidiana ity dia azo antoka foana, fa ny fampiasana ny mpanondro vokany dia tsy.
    ///
    /// Ny valim-panondroana vokatr'izany dia miraikitra amin'ilay zavatra natokana mitovy amin'ilay tondro `self`.
    /// Mety *tsy* hampiasaina mba mahazo zavatra hafa omena.Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
    ///
    /// Raha lazaina amin'ny teny hafa, `let z = x.wrapping_sub((x as usize) - (y as usize))` dia tsy *manao*`z` mitovy amin'ny `y` na dia heverintsika fa `T` dia manana habe `1` ary tsy misy onjampeo: `z` dia mbola miraikitra amin'ilay zavatra `x` mifamatotra aminy, ary ny fanalavirana izany dia fitondran-tena tsy voafaritra raha tsy hoe `x` sy `y` manondro an'io zavatra natokana io ihany.
    ///
    /// Raha ampitahaina amin'ny [`sub`], ity fomba ity dia manemotra ny fepetra takiana amin'ny fijanonana ao anatin'ilay zavatra natokana mitovy: [`sub`] dia fitondran-tena tsy voafaritra eo noho eo rehefa miampita ny fetran'ny zavatra;`wrapping_sub` mamokatra ny manondro fa mbola Mitondra ny Undefined Behavior raha misy manondro dereferenced rehefa tonga ny avy-of-fari-tanin'ireo zavatra izany no tia.
    /// [`sub`] azo hatsaraina tsara kokoa ary tsara kokoa amin'ny kaody mora tohina amin'ny fampisehoana.
    ///
    /// Ny fanamarinana mihemotra dia tsy mihevitra afa-tsy ny sandan'ny pointer izay nesorina, fa tsy ny sanda antonony nampiasaina nandritra ny fanisana ny valiny farany.
    /// Ohatra, `x.wrapping_add(o).wrapping_sub(o)` dia mitovy amin'ny `x` foana.Raha lazaina amin'ny teny hafa, ny mamela ny zavatra natokana ary avy eo dia miditra indray avy eo avela.
    ///
    /// Raha mila miampita ny fetran'ny zavatra ianao dia atsipazo amin'ny integer ny pointer ary ataovy eo ny arithmetika.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // Iterate mampiasa pointer manta amin'ny fampitomboana singa roa (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ity loop ity dia manao pirinty "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Mametraka ny sandan'ny pointer amin'ny `ptr`.
    ///
    /// Raha sanatria `self` dia mpanondro (fat) amin'ny karazany tsy voamarina, ity fiasa ity dia hisy fiantraikany amin'ny ampahany amin'ny tondro, fa kosa ho an'ny tondro (thin) amin'ny karazany marobe, dia misy vokany mitovy amin'ny andraikitra tsotra io.
    ///
    /// Ny pointer vokatr'izany dia hanana porofo `val`, izany hoe ho an'ny tondro tavy, ity asa ity dia mitovy amin'ny famoronana tavy tavy vaovao miaraka amin'ny sanda pointer data `val` fa ny metadata an'ny `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ilaina indrindra io fiasa io amin'ny famelana ny aritmetika pointer hendry amin'ny tondro mety matavy:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // hanonta "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SAFETY: Raha misy tondro manify dia mitovy io asa io
        // amin'ny fanendrena tsotra.
        // Raha misy tondro tavy, miaraka amina fampiharana ny famolavolana tondro matavy ankehitriny, ny sehatra voalohany amin'ny mpanondro toy izany dia ny mpanondro data foana, izay voatendry ihany koa.
        //
        unsafe { *thin = val };
        self
    }

    /// Mamaky ny sanda avy amin'ny `self` nefa tsy mihetsika.
    /// Io dia mamela ny fahatsiarovana ao amin'ny `self` tsy miova.
    ///
    /// Jereo ny [`ptr::read`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny ``.
        unsafe { read(self) }
    }

    /// Manatanteraka famakiana mora miovaova ny sanda avy amin'ny `self` nefa tsy mihetsika izany.Io dia mamela ny fahatsiarovana ao amin'ny `self` tsy miova.
    ///
    /// Ny fiasa mihetsiketsika dia natao hiasa amin'ny fahatsiarovana I/O, ary azo antoka fa tsy ho voaroaka na hanonta ny mpanera manerana ny asa hafa miovaova.
    ///
    ///
    /// Jereo ny [`ptr::read_volatile`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Mamaky ny sanda avy amin'ny `self` nefa tsy mihetsika.
    /// Io dia mamela ny fahatsiarovana ao amin'ny `self` tsy miova.
    ///
    /// Tsy toy ny `read`, ny tondro dia mety tsy mifanaraka.
    ///
    /// Jereo ny [`ptr::read_unaligned`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Mandika bytes `count * size_of<T>` manomboka amin'ny `self` ka hatramin'ny `dest`.
    /// Mety hifanindry ny loharano sy ny toerana alehany.
    ///
    /// NOTE: ity dia manana baiko ady hevitra *mitovy* amin'ny [`ptr::copy`].
    ///
    /// Jereo ny [`ptr::copy`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Mandika bytes `count * size_of<T>` manomboka amin'ny `self` ka hatramin'ny `dest`.
    /// Ny loharano sy ny toerana halehany dia mety *tsy* mifanindry.
    ///
    /// NOTE: ity dia manana baiko ady hevitra *mitovy* amin'ny [`ptr::copy_nonoverlapping`].
    ///
    /// Jereo ny [`ptr::copy_nonoverlapping`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Mandika bytes `count * size_of<T>` manomboka amin'ny `src` ka hatramin'ny `self`.
    /// Mety hifanindry ny loharano sy ny toerana alehany.
    ///
    /// NOTE: ity dia manana ny laharana *mifanohitra* amin'ny [`ptr::copy`].
    ///
    /// Jereo ny [`ptr::copy`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Mandika bytes `count * size_of<T>` manomboka amin'ny `src` ka hatramin'ny `self`.
    /// Ny loharano sy ny toerana halehany dia mety *tsy* mifanindry.
    ///
    /// NOTE: ity dia manana ny laharana *mifanohitra* amin'ny [`ptr::copy_nonoverlapping`].
    ///
    /// Jereo ny [`ptr::copy_nonoverlapping`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Manatanteraka ny mpanimba (raha misy) ny sanda voatondro.
    ///
    /// Jereo ny [`ptr::drop_in_place`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Manoratra toerana fitadidiana miaraka amin'ny sanda nomena fa tsy mamaky na mandatsaka ny sanda taloha.
    ///
    ///
    /// Jereo ny [`ptr::write`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `write`.
        unsafe { write(self, val) }
    }

    /// Miantso ny memset amin'ny tondro voatondro, mametraka fampiasa fahatsiarovana `count * size_of::<T>()` manomboka amin'ny `self` ka hatramin'ny `val`.
    ///
    ///
    /// Jereo ny [`ptr::write_bytes`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Manatanteraka fanoratana mora miova amin'ny toerana fahatsiarovana miaraka amin'ny sanda nomena fa tsy mamaky na mandatsaka ny sanda taloha.
    ///
    /// Ny fiasa mihetsiketsika dia natao hiasa amin'ny fahatsiarovana I/O, ary azo antoka fa tsy ho voaroaka na hanonta ny mpanera manerana ny asa hafa miovaova.
    ///
    ///
    /// Jereo ny [`ptr::write_volatile`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Manoratra toerana fitadidiana miaraka amin'ny sanda nomena fa tsy mamaky na mandatsaka ny sanda taloha.
    ///
    ///
    /// Tsy tahaka `write`, manondro mety ho unaligned.
    ///
    /// Jereo ny [`ptr::write_unaligned`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Manolo ny sanda amin'ny `self` amin'ny `src`, mamerina ny sanda taloha, nefa tsy milatsaka ihany koa.
    ///
    ///
    /// Jereo ny [`ptr::replace`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `replace`.
        unsafe { replace(self, src) }
    }

    /// Ampifamadiho ny soatoavina amin'ny toerana roa azo ovaina amin'ny karazany mitovy, nefa tsy manafoana izany koa.
    /// Mety hifanindry zareo, tsy toy ny `mem::swap` izay mitovy.
    ///
    /// Jereo ny [`ptr::swap`] raha te hanana ahiahy sy ohatra azo antoka ianao.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `swap`.
        unsafe { swap(self, with) }
    }

    /// Computes ny offset fa mila ampiharina amin'ny manondro, mba hanaovany azy ho `align` mifanaraka.
    ///
    /// Raha tsy azo atao ny mampifanaraka ny tondro, dia miverina `usize::MAX` ny fampiharana.
    /// Tsy azo atao ny fampiharana ny * * hiverina `usize::MAX` foana.
    /// Ny zava-bitanao algorithm ihany no afaka miankina amin'ny fahazoana offset azo ampiasaina eto, fa tsy ny maha-marina azy.
    ///
    /// Ny offset dia aseho amin'ny singa `T` fa tsy bytes.Ny sanda niverina dia azo ampiasaina amin'ny fomba `wrapping_add`.
    ///
    /// Tsy misy antoka azo antoka na inona na inona fa ny offsetting ny pointer dia tsy hihoatra na hihoatra ny vola natolotry ny tondro.
    ///
    /// Anjaranao ny miantoka ny fiasa fa ny offset miverina dia marina amin'ny teny rehetra ankoatry ny fampifanarahana.
    ///
    /// # Panics
    ///
    /// Ny lahasa panics raha `align` dia tsy herin'ny roa.
    ///
    /// # Examples
    ///
    /// Miditra mifanila `u8` ho `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // raha azo ampifanarahana amin'ny alàlan'ny `offset` ny tondro, dia manondro eo ivelan'ny fizarana izany
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SAFETY: `align` dia voamarina fa herin'ny 2 etsy ambony
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Mamerina ny halavan'ny silaka manta.
    ///
    /// Ny sanda miverina dia ny isan'ny singa ** **, fa tsy ny isan'ny bytes.
    ///
    /// Azo antoka ity fiasa ity, na dia tsy azo alefa amin'ny lozisialy aza ny silaka manta satria tsy mahomby na tsy mifanaraka ny tondro.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: azo antoka ity satria mitovy endrika ny `*const [T]` sy `FatPtr<T>`.
            // `std` irery no afaka manome an'io antoka io.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Mamerina ny tondro masaka ao amin'ny buffer an'ny silaka.
    ///
    /// Izy io dia mitovy amin'ny fandefasana `self` ka `*mut T`, fa azo antoka kokoa kosa.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Miverina tondro iray manta amina singa iray na subslice, nefa tsy manao fanaraha-maso fetra.
    ///
    /// Ny fiantsoana an'io fomba io amin'ny index tsy voafetra na rehefa tsy dereferencable ny `self` dia *[fihetsika tsy voafaritra]* na dia tsy ampiasaina aza ny mpanondro vokatr'izany.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: miantoka ny miantso ny `self` fa tsy azo esorina ny `self` ary voafetra ao anatin'ny fetrany `index`.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Miverina `None` raha tsy misy dikany ny pointer, na raha tsy izany dia miverina miambina amina sanda mifono `Some`.
    /// Mifanohitra amin'ny [`as_ref`], ity dia tsy mitaky ny hamaritana ny sandany.
    ///
    /// Ho an'ny mpiara-miasa azo ovaina dia jereo [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila miantoka fa *na* ilay pointer dia NULL *na* marina daholo ireto manaraka ireto:
    ///
    /// * Ny tondro dia tokony ho [valid] raha te-hamaky `ptr.len() * mem::size_of::<T>()` byte maro, ary tsy maintsy mifanaraka tsara.Midika manokana izany:
    ///
    ///     * Ny haben'ny fahatsiarovana iray manontolo amin'ity sombin-kazo ity dia tsy maintsy ao anaty zavatra iray natokana!
    ///       Ny slices dia tsy afaka mamakivaky zavatra maro natokana.
    ///
    ///     * Ny tondro dia tsy maintsy ampifanarahana na dia amin'ny sombina lava aza.
    ///     Ny antony iray mahatonga an'io dia ny fanamafisana ny famolavolana enum dia mety hiankina amin'ny fanovozan-kevitra (ao anatin'izany ny sombina amin'ny halavany rehetra) mifanaraka sy tsy azo foanana hanavahana azy ireo amin'ny angona hafa.
    ///
    ///     Azonao atao ny mahazo pointer izay azo ampiasaina ho `data` ho an'ny sombina lava aotra mampiasa [`NonNull::dangling()`].
    ///
    /// * Ny haben'ny `ptr.len() * mem::size_of::<T>()` an'ny silaka dia tsy tokony ho lehibe noho `isize::MAX`.
    ///   Jereo ny antontan-taratasy fiarovana an'ny [`pointer::offset`].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///   Manokana, mandritra ny androm-piainanao, ny fahatsiarovan'ny mpanondro nanondro fa tsy tokony ho mutated (afa-tsy ao anatin'ny `UnsafeCell`).
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// Jereo koa [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Miverina `None` raha tsy misy dikany ny tondro, na raha tsy izany dia mamerina sombina miavaka amin'ilay sanda nofonosina `Some`.
    /// Mifanohitra amin'ny [`as_mut`], ity dia tsy mitaky ny hamaritana ny sandany.
    ///
    /// Ho an'ny mpifanaraka zara dia jereo [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila miantoka fa *na* ilay pointer dia NULL *na* marina daholo ireto manaraka ireto:
    ///
    /// * Ny pointer dia tokony ho [valid] raha te hamaky ary manoratra ho an'ny `ptr.len() * mem::size_of::<T>()` byte maro, ary tsy maintsy ampifanarahana tsara.Midika manokana izany:
    ///
    ///     * Ny haben'ny fahatsiarovana iray manontolo amin'ity sombin-kazo ity dia tsy maintsy ao anaty zavatra iray natokana!
    ///       Ny slices dia tsy afaka mamakivaky zavatra maro natokana.
    ///
    ///     * Ny tondro dia tsy maintsy ampifanarahana na dia amin'ny sombina lava aza.
    ///     Ny antony iray mahatonga an'io dia ny fanamafisana ny famolavolana enum dia mety hiankina amin'ny fanovozan-kevitra (ao anatin'izany ny sombina amin'ny halavany rehetra) mifanaraka sy tsy azo foanana hanavahana azy ireo amin'ny angona hafa.
    ///
    ///     Azonao atao ny mahazo pointer izay azo ampiasaina ho `data` ho an'ny sombina lava aotra mampiasa [`NonNull::dangling()`].
    ///
    /// * Ny haben'ny `ptr.len() * mem::size_of::<T>()` an'ny silaka dia tsy tokony ho lehibe noho `isize::MAX`.
    ///   Jereo ny antontan-taratasy fiarovana an'ny [`pointer::offset`].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///   Manokana, mandritra ny androm-piainana ity, ny fahatsiarovana izay tondroin'ny tondro dia tsy tokony hiditra (vakiana na soratana) amin'ny alàlan'ny tondro hafa.
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// Jereo koa [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Fitoviana ho an'ny tondro
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}