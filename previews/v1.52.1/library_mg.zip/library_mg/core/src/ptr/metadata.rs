#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Manome ny karazana metadata mpanondro na inona na inona karazany tondro.
///
/// # Metadata mpanondro
///
/// Ny karazan-tondro ary ny karazana fanondroana ao amin'ny Rust dia azo eritreretina ho vita amin'ny faritra roa:
/// pointer data izay misy ny adiresy fahatsiarovana ny sanda, ary ny metadata sasany.
///
/// Ho an'ireo karazana refy statically (izay mampihatra ny `Sized` traits) ary koa ho an'ny `extern` karazany, ny tondro dia voalaza fa "manify": metadata dia zero ary ny karazany dia `()`.
///
///
/// Sahaza ho [dynamically-sized types][dst] dia lazaina fa "malalaka" na "matavy", izy ireo tsy aotra-salantsalany Metadata:
///
/// * Ho an'ny tsipika izay DST ny saha farany, ny metadata no metadata ho an'ny saha farany
/// * Ho an'ny karazana `str`, metadata no halavan'ny bytes ho `usize`
/// * Fa toy ny silaka karazana `[T]`, Metadata ny lavany amin'ny zavatra toy ny `usize`
/// * Ho an'ny zavatra trait toa `dyn SomeTrait`, metadata dia [`DynMetadata<Self>`][DynMetadata] (oh: `DynMetadata<dyn SomeTrait>`)
///
/// Ao amin'ny future, ny fiteny Rust dia mety hahazo karazana karazany vaovao izay misy metadata mpanondro samihafa.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Ny `Pointee` trait
///
/// Ny teboka an'ity trait ity dia ny karazany mifandraika amin'ny `Metadata`, izay `()` na `usize` na `DynMetadata<_>` araka ny voalaza etsy ambony.
/// Ampiharina ho azy ho an'ny sokajy rehetra izy io.
/// Azo heverina fa ampiharina amin'ny toe-javatra mahazatra, na dia tsy misy fetra mifandraika amin'izany aza.
///
/// # Usage
///
/// Ny tondro mena dia azo alaina ao anaty adiresy data sy singa metadata miaraka amin'ny fomba [`to_raw_parts`].
///
/// Raha tsy izany, metadata irery dia azo alaina miaraka amin'ny lahasa [`metadata`].
/// Ny referansa dia azo ampitaina amin'ny [`metadata`] ary terena an-keriny.
///
/// Ny pointer (possibly-wide) dia azo averina miaraka amin'ny adiresy sy ny metadata miaraka amin'ny [`from_raw_parts`] na [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Ny karazany ho an'ny metadata amin'ny tondro sy ny fanondroana ny `Self`.
    #[lang = "metadata_type"]
    // NOTE: Tehirizo ny trait bounds ao amin'ny `static_assert_expected_bounds_for_metadata`
    //
    // amin'ny `library/core/src/ptr/metadata.rs` ampifandraisina amin'ireo eto:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ireo manondro ireo karazana mampihatra an'ity alias trait ity dia "manify".
///
/// Tafiditra ao anatin'izany ny karazana statutika `Sized` sy ny karazana `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: aza mampiorina izany alohan'ny milamina ny trait amin'ny fiteny?
pub trait Thin = Pointee<Metadata = ()>;

/// Esory ny singa metadata mpanondro.
///
/// Ny soatoavin'ny karazana `*mut T`, `&T`, na `&mut T` dia azo ampitaina mivantana amin'ity asa ity satria manery amin'ny `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Ny fidirana amin'ny sanda avy amin'ny firaisana `PtrRepr` dia azo antoka hatramin'ny * const T
    // ary ny PtrComponents<T>manana lamina fitadidiana mitovy.
    // std ihany no afaka manome an'io antoka io.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Mamorona pointer (possibly-wide) manta avy amin'ny adiresy data sy metadata.
///
/// Ity fiasa ity dia azo antoka fa ny tondro naverina dia tsy voatery ho azo antoka.
/// Fa slices, dia jereo ny tahirin-kevitra ny [`slice::from_raw_parts`] ho fepetra fiarovana.
/// Ho an'ny zavatra trait, ny metadata dia tsy maintsy miainga avy amin'ny tondro iray mankany amin'ilay karazana efa voahidy.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Ny fidirana amin'ny sanda avy amin'ny firaisana `PtrRepr` dia azo antoka hatramin'ny * const T
    // ary ny PtrComponents<T>manana lamina fitadidiana mitovy.
    // std ihany no afaka manome an'io antoka io.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Manatanteraka fampiasa mitovy amin'ny [`from_raw_parts`], afa-tsy ny pointer `*mut` manta averina, mifanohitra amin'ny tondro `* const` manta.
///
///
/// Jereo ny antontan-taratasy momba ny [`from_raw_parts`] raha mila fanazavana fanampiny.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Ny fidirana amin'ny sanda avy amin'ny firaisana `PtrRepr` dia azo antoka hatramin'ny * const T
    // ary ny PtrComponents<T>manana lamina fitadidiana mitovy.
    // std ihany no afaka manome an'io antoka io.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ilaina ny impl manual mba hialana amin'ny `T: Copy` voafatotra.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Ilaina ny impl manual mba hialana amin'ny `T: Clone` voafatotra.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Ny metadata ho an'ny karazana zavatra `Dyn = dyn SomeTrait` trait.
///
/// Izy io dia tondro iray amin'ny latabatra (latabatra antso virtoaly) izay maneho ny fampahalalana ilaina rehetra hanodinana ny karazana simenitra voatahiry ao anatin'ny zavatra trait.
/// Ny latabatra dia misy:
///
/// * karazana habe
/// * karazana fampifanarahana
/// * mpanondro ny karazana `drop_in_place` impl (mety ho tsy op-na data-taloha-taloha)
/// * manondro ny fomba rehetra amin'ny fampiharana ny karazana trait
///
/// Mariho fa ireo telo voalohany, satria ry zareo manokana ilaina mba zarao, mitete, ary deallocate misy trait zavatra.
///
/// Azo atao ny manome anarana an'ity firafitra ity miaraka amina karazana masontsivana izay tsy zavatra `dyn` trait (ohatra `DynMetadata<u64>`) fa tsy hahazoana sanda manan-danja amin'io firafitra io.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Ny fehintsoratra mahazatra ny vtables rehetra.Manaraka izany ny tondro fiasa ho an'ny fomba trait.
///
/// Antsipirian'ny fampiharana manokana an'ny `DynMetadata::size_of` sns.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Mamerina ny haben'ny karazana mifandraika amin'ity latabatra ity.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Miverina ny fampifanarahana ny karazany mifandraika amin'ity vtable ity.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Miverina miaraka amin'ny `Layout` ny habeny sy ny fampifanarahana
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: ny compiler dia namoaka an'ity latabatra ity ho an'ny karazana Rust mivaingana izay
        // dia fantatra fa manana layout milamina.Ny antony mitovy amin'ny `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ilaina ny impls manual hisorohana ny fetran'ny `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}