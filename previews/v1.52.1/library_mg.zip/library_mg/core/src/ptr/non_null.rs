use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` fa tsy aotra sy covariant.
///
/// Matetika io no zavatra marina tokony hampiasaina rehefa manangana firafitry ny angon-drakitra mampiasa tondro manta, saingy atahorana kokoa hampidi-doza noho ny fananany fanampiny.Raha tsy azonao antoka ny tokony hampiasana `NonNull<T>` dia ampiasao `*mut T` fotsiny!
///
/// Tsy toy ny `*mut T`, ny tondro dia tsy maintsy null null, na dia tsy natokana mihitsy aza ny tondro.Izany dia mba hampiasan'ny enum an'io sanda voarara io amin'ny fanavakavahana-ny `Option<NonNull<T>>` dia mitovy habe amin'ny `* mut T`.
/// Na eo aza izany dia mety mbola hilona ilay mpanondro raha tsy dereferena.
///
/// Tsy toy ny `*mut T`, `NonNull<T>` dia voafidy ho covariant mihoatra ny `T`.Izany dia ahafahana mampiasa `NonNull<T>` rehefa manangana karazana covariant, fa mampiditra ny mety tsy fahatokisan-tena raha ampiasaina amin'ny karazana tsy tokony ho covariant.
/// (Ny mifanohitra safidy no natao ho ny `*mut T` na dia ara-teknika ny unsoundness ihany no mety ho vokatry ny asany miantso mampidi-doza.)
///
/// Ny covariance dia marina amin'ny abstraction azo antoka indrindra, toy ny `Box`, `Rc`, `Arc`, `Vec`, ary `LinkedList`.Izany no izy satria manome API ho an'ny daholobe izy ireo izay manaraka ny fitsipika mahazatra XOR azo ovaina an'ny Rust.
///
/// Raha tsy afaka miova covariant soa aman-tsara ny karazana anao dia tokony ho azonao antoka fa misy faritra fanampiny fanampiny hanomezana invariance.Matetika ity saha ity dia ho karazana [`PhantomData`] toy ny `PhantomData<Cell<T>>` na `PhantomData<&'a mut T>`.
///
/// Mariho fa manana `From` `NonNull<T>` ohatra ho an'ny `&T`.Na izany aza, tsy manova ny zava-misy izany fa ny mutation amin'ny alàlan'ny (pointer azo avy amin'ny a) repertoara iraisana dia fihetsika tsy voafaritra raha tsy ny mutation dia mitranga ao anaty [`UnsafeCell<T>`].Toy izany koa ny famoronana référence azo ovaina avy amin'ny referansa iraisana.
///
/// Rehefa mampiasa an'io ohatra `From` tsy misy `UnsafeCell<T>` io dia anjaranao ny miantoka fa tsy antsoina i `as_mut` ary `as_ptr` dia tsy ampiasaina amin'ny mutation mihitsy.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` Tsy `Send` ny tondro satria mety alefa ny angon-drakitra lazainy.
// NB, tsy ilaina io impl io fa tokony hanome hafatra diso kokoa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` Tsy `Sync` ny tondro satria mety alefa ny angon-drakitra lazainy.
// NB, tsy ilaina io impl io fa tokony hanome hafatra diso kokoa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Mamorona `NonNull` vaovao mihantona, nefa mifanaraka tsara.
    ///
    /// Ilaina izy io amin'ny fanombohana ireo karazan-karazan-tsokosoko izay mizarazara kamo, toa ny `Vec::new`.
    ///
    /// Mariho fa ny lanjan'ireo mpanondro dia mety hanondro mpanondro manan-kery ho `T`, izay midika fa io dia tsy tokony hampiasaina ho toy ny sandan'ny "not yet initialized" sentinel.
    /// Ireo karazan-tsokosoko kamo dia tsy maintsy manara-maso ny fanombohana amin'ny fomba hafa.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() dia mamerina usize tsy zero izay alefa avy eo
        // a * mut T.
        // Noho izany, `ptr` dia tsy foana ary hajaina ny fepetra amin'ny fiantsoana new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Miverina fanondroana iraisana momba ny sanda.Mifanohitra amin'ny [`as_ref`], ity dia tsy mitaky ny hamaritana ny sandany.
    ///
    /// Ho an'ny mpiara-miasa azo ovaina dia jereo [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila mahazo antoka fa marina avokoa ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///
    ///   Manokana, mandritra ny androm-piainanao, ny fahatsiarovan'ny mpanondro nanondro fa tsy tokony ho mutated (afa-tsy ao anatin'ny `UnsafeCell`).
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // takiana amin'ny referansa.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Miverina fanondroana tokana momba ny sanda.Mifanohitra amin'ny [`as_mut`], ity dia tsy mitaky ny hamaritana ny sandany.
    ///
    /// Fa ny Shared mitovy jereo [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila mahazo antoka fa marina avokoa ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///
    ///   Manokana, mandritra ny androm-piainana ity, ny fahatsiarovana izay tondroin'ny tondro dia tsy tokony hiditra (vakiana na soratana) amin'ny alàlan'ny tondro hafa.
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // takiana amin'ny referansa.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Mamorona vaovao `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` tokony tsy ho foana.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Famonjena, ny mpiantso dia tsy maintsy manome antoka fa `ptr` dia tsy tohivakana foana.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Mamorona `NonNull` vaovao raha toa ka tsy manan-kery ny `ptr`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Efa voamarina ary tsy null ny pointer
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Manatanteraka fampiasa mitovy amin'ny [`std::ptr::from_raw_parts`], afa-tsy ny tondro `NonNull` averina, mifanohitra amin'ny tondro `*const` manta.
    ///
    ///
    /// Jereo ny antontan-taratasy momba ny [`std::ptr::from_raw_parts`] raha mila fanazavana fanampiny.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: ny valin'ny `ptr::from::raw_parts_mut` dia tsy manan-kery satria `data_address` no.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Arotsaho ny isa (mety ho sakany) ho adiresy sy singa metadata.
    ///
    /// Ny tondro dia afaka averina haorina amin'ny [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Mahazo ilay tondro `*mut` ao ambaniny.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Miverina fanondroana iraisana momba ny sanda.Raha mety uninitialized ny soatoavina dia tokony ampiasaina ny [`as_uninit_ref`].
    ///
    /// Ho an'ny mpiara-miasa azo ovaina dia jereo [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila mahazo antoka fa marina avokoa ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Ny tondro dia tsy maintsy manondro ohatra voalohany `T`.
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///
    ///   Manokana, mandritra ny androm-piainanao, ny fahatsiarovan'ny mpanondro nanondro fa tsy tokony ho mutated (afa-tsy ao anatin'ny `UnsafeCell`).
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    /// (Ny ampahany momba ny fanombohana azy dia mbola tsy tapa-kevitra tanteraka, fa mandra-pahatongan'izany, ny fomba tokana azo antoka dia ny miantoka fa voalahatra tokoa izy ireo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // takiana amin'ny referansa.
        unsafe { &*self.as_ptr() }
    }

    /// Miverina fanondroana tokana momba ny sanda.Raha mety uninitialized ny soatoavina dia tokony ampiasaina ny [`as_uninit_mut`].
    ///
    /// Ho an'ny mpifanaraka zara dia jereo [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila mahazo antoka fa marina avokoa ireto manaraka ireto:
    ///
    /// * Ny tondro dia tsy maintsy mifanaraka tsara.
    ///
    /// * Tokony ho "dereferencable" amin'ny dikany voafaritra amin'ny [the module documentation].
    ///
    /// * Ny tondro dia tsy maintsy manondro ohatra voalohany `T`.
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///
    ///   Manokana, mandritra ny androm-piainana ity, ny fahatsiarovana izay tondroin'ny tondro dia tsy tokony hiditra (vakiana na soratana) amin'ny alàlan'ny tondro hafa.
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    /// (Ny ampahany momba ny fanombohana azy dia mbola tsy tapa-kevitra tanteraka, fa mandra-pahatongan'izany, ny fomba tokana azo antoka dia ny miantoka fa voalahatra tokoa izy ireo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // fepetra takiana amin'ny référence azo ovaina.
        unsafe { &mut *self.as_ptr() }
    }

    /// Mandidy amin'ny tondro hafa karazana.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` dia tondro `NonNull` izay tsy voatery ho null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Mamorona silaka manta tsy misy fotony avy amin'ny tondro manify sy ny halavany.
    ///
    /// Ny adihevitra `len` dia ny isan'ny singa ** **, fa tsy ny isan'ny bytes.
    ///
    /// Ity no asa azo antoka, fa dereferencing ny miverina sarobidy dia azo antoka.
    /// Zahao ny antontan-taratasy momba ny [`slice::from_raw_parts`] raha mila fepetra arovana.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // mamorona pointer slice rehefa manomboka amin'ny pointer mankany amin'ny singa voalohany
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Mariho fa ity ohatra ity dia mampiseho fomba fampiasana an'io fomba io, fa `avelao ny slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` dia tondro `NonNull` izay tsy voatery ho null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Mamerina ny halavan'ny silaka manta tsy misy dikany.
    ///
    /// Ny sanda miverina dia ny isan'ny singa ** **, fa tsy ny isan'ny bytes.
    ///
    /// Ity fiasa ity dia azo antoka, na dia tsy azo esorina amin'ny silaka aza ilay silaka manta tsy misy dikany satria tsy manana adiresy mety ilay mpanondro.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Miverina tondro tsy misy dikany amin'ny buffer an'ny silaka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: Fantatray fa tsy misy dikany ny `self`.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Mamerina ny tondro masaka ao amin'ny buffer an'ny silaka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Miverina fanondroana iraisana amin'ny sombin-javatra mety tsy voadinika.Mifanohitra amin [`as_ref`], tsy mitaky izany fa ny zava-dehibe tsy maintsy initialized.
    ///
    /// Ho an'ny mpiara-miasa azo ovaina dia jereo [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila mahazo antoka fa marina avokoa ireto manaraka ireto:
    ///
    /// * Ny tondro dia tokony ho [valid] raha te-hamaky `ptr.len() * mem::size_of::<T>()` byte maro, ary tsy maintsy mifanaraka tsara.Midika manokana izany:
    ///
    ///     * Ny haben'ny fahatsiarovana iray manontolo amin'ity sombin-kazo ity dia tsy maintsy ao anaty zavatra iray natokana!
    ///       Ny slices dia tsy afaka mamakivaky zavatra maro natokana.
    ///
    ///     * Ny tondro dia tsy maintsy ampifanarahana na dia amin'ny sombina lava aza.
    ///     Ny antony iray mahatonga an'io dia ny fanamafisana ny famolavolana enum dia mety hiankina amin'ny fanovozan-kevitra (ao anatin'izany ny sombina amin'ny halavany rehetra) mifanaraka sy tsy azo foanana hanavahana azy ireo amin'ny angona hafa.
    ///
    ///     Azonao atao ny mahazo pointer izay azo ampiasaina ho `data` ho an'ny sombina lava aotra mampiasa [`NonNull::dangling()`].
    ///
    /// * Ny haben'ny `ptr.len() * mem::size_of::<T>()` an'ny silaka dia tsy tokony ho lehibe noho `isize::MAX`.
    ///   Jereo ny antontan-taratasy fiarovana an'ny [`pointer::offset`].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///   Manokana, mandritra ny androm-piainanao, ny fahatsiarovan'ny mpanondro nanondro fa tsy tokony ho mutated (afa-tsy ao anatin'ny `UnsafeCell`).
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// Jereo koa [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Miverina ny manam-paharoa momba ny silaka angamba uninitialized soatoavina.Mifanohitra amin'ny [`as_mut`], ity dia tsy mitaky ny hamaritana ny sandany.
    ///
    /// Ho an'ny mpifanaraka zara dia jereo [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Rehefa miantso an'io fomba io ianao dia mila mahazo antoka fa marina avokoa ireto manaraka ireto:
    ///
    /// * Ny pointer dia tokony ho [valid] raha te hamaky ary manoratra ho an'ny `ptr.len() * mem::size_of::<T>()` byte maro, ary tsy maintsy ampifanarahana tsara.Midika manokana izany:
    ///
    ///     * Ny haben'ny fahatsiarovana iray manontolo amin'ity sombin-kazo ity dia tsy maintsy ao anaty zavatra iray natokana!
    ///       Ny slices dia tsy afaka mamakivaky zavatra maro natokana.
    ///
    ///     * Ny tondro dia tsy maintsy ampifanarahana na dia amin'ny sombina lava aza.
    ///     Ny antony iray mahatonga an'io dia ny fanamafisana ny famolavolana enum dia mety hiankina amin'ny fanovozan-kevitra (ao anatin'izany ny sombina amin'ny halavany rehetra) mifanaraka sy tsy azo foanana hanavahana azy ireo amin'ny angona hafa.
    ///
    ///     Azonao atao ny mahazo pointer izay azo ampiasaina ho `data` ho an'ny sombina lava aotra mampiasa [`NonNull::dangling()`].
    ///
    /// * Ny haben'ny `ptr.len() * mem::size_of::<T>()` an'ny silaka dia tsy tokony ho lehibe noho `isize::MAX`.
    ///   Jereo ny antontan-taratasy fiarovana an'ny [`pointer::offset`].
    ///
    /// * Tsy maintsy ampiharinao ny lalàna aloky ny Rust, satria voafidy ara-dalàna ny fahaverezan'ny fiainana `'a` ary tsy voatery hitaratra ny tena androm-piainan'ny angona.
    ///   Manokana, mandritra ny androm-piainana ity, ny fahatsiarovana izay tondroin'ny tondro dia tsy tokony hiditra (vakiana na soratana) amin'ny alàlan'ny tondro hafa.
    ///
    /// Mihatra izany na dia tsy ampiasaina aza ny valin'io fomba io!
    ///
    /// Jereo koa [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Azo antoka izany satria `memory` dia manan-kery amin'ny famakiana ary manoratra ho an'ny `memory.len()` byte maro.
    /// // Mariho fa ny fiantsoana `memory.as_mut()` dia tsy azo atao eto satria ny votoatiny dia mety ho uninitialized.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Miverina tondro iray manta amina singa iray na subslice, nefa tsy manao fanaraha-maso fetra.
    ///
    /// Ny fiantsoana an'io fomba io amin'ny index tsy voafetra na rehefa tsy dereferencable ny `self` dia *[fihetsika tsy voafaritra]* na dia tsy ampiasaina aza ny mpanondro vokatr'izany.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: miantoka ny miantso ny `self` fa tsy azo esorina ny `self` ary voafetra ao anatin'ny fetrany `index`.
        // Vokatr'izany, ny pointer vokatr'izany dia tsy afaka NUL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAFETY: Ny tondro iray tsy manam-paharoa dia tsy azo foanana, noho izany ny fepetra
        // new_unchecked() hajaina.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAFETY: ny referansy azo ovaina dia tsy azo foanana.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: ny referansa dia tsy azo foanana, noho izany ny fepetra
        // new_unchecked() hajaina.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}