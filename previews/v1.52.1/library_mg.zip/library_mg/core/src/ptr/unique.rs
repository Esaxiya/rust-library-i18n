use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Fonosana manodidina `*mut T` tsy misy fangarony izay manondro fa ny tompon'ity fonosana ity dia tompon'ny referent.
/// Ilaina amin'ny fananganana abstraction toa `Box<T>`, `Vec<T>`, `String`, ary `HashMap<K, V>`.
///
/// Tsy toy ny `*mut T`, `Unique<T>` "as if"-tsy mitondra tena ho ohatra ny `T`.
/// Mampihatra `Send`/`Sync` raha `T` dia `Send`/`Sync`.
/// Midika koa izany fa ny karazana aliasing matanjaka dia manome antoka ny andrasana `T` iray manantena:
/// ny mpanondro ny tondro dia tsy tokony ovaina raha tsy misy làlana tokana mankany amin'ny fananany Unique.
///
/// Raha tsy azonao antoka raha marina ny fampiasana `Unique` ho an'ny tanjonao, dia ampiasao ny `NonNull`, izay manana semantika malemy kokoa.
///
///
/// Tsy toy ny `*mut T`, ny tondro dia tsy maintsy null null, na dia tsy nasiam-bola mihitsy aza ny tondro.
/// Izany dia mba hampiasan'ny enum ity sanda voarara ity ho fanavakavahana-ny `Option<Unique<T>>` dia mitovy habe amin'ny `Unique<T>`.
/// Na eo aza izany dia mety mbola hilona ilay mpanondro raha tsy dereferena.
///
/// Tsy toy ny `*mut T`, `Unique<T>` dia covariant mihoatra ny `T`.
/// Izany dia tokony ho marina ho an'ireo karazana manam-paharoa izay manohana ny fepetra aliasing.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: Ity marika ity dia tsy misy vokany amin'ny tsy fitoviana, fa ilaina izany
    // ho an'ny dropck hahatakatra fa manana `T` lojika isika.
    //
    // Fa tsipiriany, dia jereo ny:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointers dia `Send` raha `T` dia `Send` satria tsy voavaha ireo angona notondroin'izy ireo.
/// Mariho fa ity invanant aliasing ity dia tsy ampiasain'ny rafitra rafitra;ny abstraction dia tsy maintsy mampiasa ny `Unique` hampihatra izany.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pointers dia `Sync` raha `T` dia `Sync` satria tsy voavaha ireo angona notondroin'izy ireo.
/// Mariho fa ity invanant aliasing ity dia tsy ampiasain'ny rafitra rafitra;ny abstraction dia tsy maintsy mampiasa ny `Unique` hampihatra izany.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Mamorona `Unique` vaovao mihantona, nefa mifanaraka tsara.
    ///
    /// Ilaina izy io amin'ny fanombohana ireo karazan-karazan-tsokosoko izay mizarazara kamo, toa ny `Vec::new`.
    ///
    /// Mariho fa ny lanjan'ireo mpanondro dia mety hanondro mpanondro manan-kery ho `T`, izay midika fa io dia tsy tokony hampiasaina ho toy ny sandan'ny "not yet initialized" sentinel.
    /// Ireo karazan-tsokosoko kamo dia tsy maintsy manara-maso ny fanombohana amin'ny fomba hafa.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() mamerina mpanondro tsy manan-kery.ny
        // hajaina araka izany ny fepetra hiantsoana new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Mamorona `Unique` vaovao.
    ///
    /// # Safety
    ///
    /// `ptr` tokony tsy ho foana.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Famonjena, ny mpiantso dia tsy maintsy manome antoka fa `ptr` dia tsy tohivakana foana.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Mamorona `Unique` vaovao raha toa ka tsy manan-kery ny `ptr`.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: Ny tondro dia efa nozahana ary tsy foana.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Mahazo ilay tondro `*mut` ao ambaniny.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Fanadinadinana ny atiny.
    ///
    /// Ny androm-piainana vokatr'izany dia miankina amin'ny tenany ka izany dia mihetsika "as if" fa tena ohatra ny T izay mindrana.
    /// Raha ilaina ny androm-piainana (unbound) lava kokoa dia ampiasao `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // takiana amin'ny referansa.
        unsafe { &*self.as_ptr() }
    }

    /// Azo inoana fa manafoana ny atiny.
    ///
    /// Ny androm-piainana vokatr'izany dia miankina amin'ny tenany ka izany dia mihetsika "as if" fa tena ohatra ny T izay mindrana.
    /// Raha ilaina ny androm-piainana (unbound) lava kokoa dia ampiasao `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: ny miantso dia tsy maintsy manome antoka fa `self` mahafeno ny rehetra
        // fepetra takiana amin'ny référence azo ovaina.
        unsafe { &mut *self.as_ptr() }
    }

    /// Mandidy amin'ny tondro hafa karazana.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Unique::new_unchecked() dia mamorona tokana sy ilaina vaovao
        // ny tondro nomena mba tsy ho null.
        // Satria mandalo ny tenantsika ho toy ny tondro isika, dia tsy afaka nody.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Famonjena, A mutable boky tsy afaka ny ho tohivakana foana
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}