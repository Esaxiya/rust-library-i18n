//! Tantano amin'ny alàlan'ny tondro manta ny fitadidy.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Maro ny asa ao amin'io Module haka sahaza manta toy ny fanehoan-kevitra ary namaky avy na manorata any aminy.Mba hilamina ity dia tsy maintsy *manan-kery* ireo tondro ireo.
//! Raha marina ny fanondroana dia miankina amin'ny fandidiana ampiasana azy (vakio na soraty), ary ny haben'ny fahatsiarovan-tena azo alaina (izany hoe ohatrinona ny bytes read/written).
//! Ny ankamaroan'ny asa dia mampiasa `*mut T` sy `* const T` tsy hidirana afa-tsy sanda tokana, ary amin'izany dia esorin'ny antontan-taratasy ny habeny ary heveriny ho byota `size_of::<T>()` izany.
//!
//! Ny fitsipika marina ho an'ny tsy marina ataon dia mbola tapa-kevitra.Ny antoka azo omena amin'izao fotoana izao dia kely dia kely:
//!
//! * Ny pointer [null] dia *tsy manan-kery* mihitsy, na dia amin'ny fidirana [size zero][zst] aza.
//! * Mba hampanan-kery ny tondro dia ilaina, fa tsy ampy foana, ny fanondroana *tsy azo ekena*: ny haben'ny fahatsiarovana ny habe nomena manomboka amin'ny mpanondro dia tsy maintsy ao anatin'ny faritry ny zavatra tokana natokana.
//!
//! Mariho fa ao amin'ny Rust, ny isa (stack-allocated) rehetra dia heverina ho zavatra natokana voatokana.
//! * Na ho an'ny asan'ny [size zero][zst] aza, ny tondro dia tsy tokony manondro fahatsiarovan-tena, izany hoe, ny fifampiraharahana dia mahatonga ny tondro tsy mitombina na dia ho an'ny fandidiana zero aza.
//! Na izany aza, ny fandefasana integer *ara-bakiteny* ara-bakiteny ho an'ny tondro iray dia manan-kery ho an'ny fidirana an-tsehatra zero, na dia misy fahatsiarovana sasany aza ao amin'io adiresy io ary mahazo fifanarahana.
//! Zavatra tsy mifanitsy amin'ny fanoratana manokana allocator: allocating aotra-salantsalany dia tsy zavatra tena sarotra.
//! Ny fomba kanônika ahazoana pointer izay manan-kery ho an'ny fidirana tsy refy dia [`NonNull::dangling`].
//! * Accesses rehetra tanterahana amin'ny alalan'ny asa ao amin'io Module dia * tsy atomika + amin'ny heviny ny [atomic operations] zatra synchronize eo amin'ny kofehy.
//! Midika izany fa fitondran-tena tsy voafaritra ny fanatanterahana fidirana roa miaraka amin'ny toerana iray ihany avy amin'ny kofehy samihafa raha tsy ny famakiana no tadidinao fotsiny.
//! Jereo fa ity dia ahitana mazava ny [`read_volatile`] sy [`write_volatile`]: Ny fidirana mikorontana dia tsy azo ampiasaina amin'ny fampifanarahana ny kofehy.
//! * Ny valin'ny fandefasana ny fanondroana tondro iray dia manan-kery raha mbola velona ilay zavatra ifotony ary tsy misy referansa (tondro manta fotsiny) ampiasaina hahazoana ilay fitadidiana mitovy.
//!
//! Ireo axioms ireo, miaraka amin'ny fampiasana [`offset`] tsara ho an'ny arithmetic pointer, dia ampy hampiharana zavatra mahasoa maro amin'ny kaody tsy azo antoka.
//! Ny valim-panamafisana matanjaka kokoa dia homena amin'ny farany, satria tapa-kevitra ny [aliasing].
//! Raha mila fanazavana fanampiny, jereo ny [book] ary koa ny fizarana ao amin'ny referansa natokana ho [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Ny tondro manta mety araka ny voafaritra etsy ambony dia tsy voatery mifanaraka tsara (izay mamaritra ny fampifanarahana "proper" amin'ny karazana pointee, izany hoe, `*const T` dia tsy maintsy ampifanarahana amin'ny `mem::align_of::<T>()`).
//! Na izany aza, ny ankamaroan'ny asa dia mitaky ny fifandanjan-kevitr'izy ireo ary hambara mazava tsara izany takiana izany ao amin'ny antontan-taratasin'izy ireo.
//! Maningana amin'izany ny [`read_unaligned`] sy [`write_unaligned`].
//!
//! Rehefa mila fampifanarahana tsara ny fiasa iray dia manao izany na dia manana ny habe 0 aza ny fidirana, izany hoe, na dia tsy voakitika aza ny fitadidiana.Diniho ny fampiasana [`NonNull::dangling`] amin'ny tranga toy izany.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Manatanteraka ny mpanimba (raha misy) ny sanda voatondro.
///
/// Izany no semantically mitovy amin'ny fiantsoana [`ptr::read`] sy ho fanariana ny vokany, fa manana tombony ireto:
///
/// * *Takiana* ny fampiasana `drop_in_place` handatsahana ireo karazana voadio toy ny zavatra trait, satria tsy azo vakiana ao anaty stack izy ireo ary milatsaka ara-dalàna.
///
/// * Tsara kokoa ho an'ny optimizer ny manao an'io mihoatra ny [`ptr::read`] rehefa mandao ny fahatsiarovana natokana ho an'ny tanana (ohatra, amin'ny fampiharana `Box`/`Rc`/`Vec`), satria ny compiler dia tsy mila manaporofo fa tsara ny mamaky ilay kopia.
///
///
/// * Azo ampiasaina izy io handatsahana ireo angona [pinned] rehefa tsy `repr(packed)` ny `T` (tsy tokony hafindra ny angona voatanisa alohan'ny hametrahana azy).
///
/// Ny soatoavina tsy voarindra dia tsy azo arotsaka eo amin'ny toerany, izy ireo dia tsy maintsy adika amin'ny toerana mifanaraka amin'ny fampiasana [`ptr::read_unaligned`].Ho an'ny kofehy feno fonosana, ity hetsika ity dia ataon'ny mpamorona azy ho azy.
/// Midika izany fa tsy naidina an-toerana ireo tanin'ny lakandrano feno fonosana.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `to_drop` tsy maintsy [valid] na samy mamaky na manoratra.
///
/// * `to_drop` dia tsy maintsy ho araka ny tokony mifanaraka.
///
/// * Ny sanda `to_drop` dia tokony ho marina amin'ny filatsahana, izay mety hidika hoe tsy maintsy manohana invariants fanampiny izy, miankina amin'ny karazany izany.
///
/// Ho fanampin'izay, raha tsy [`Copy`] ny `T`, ny fampiasana ny lanjan-tondro aorian'ny fiantsoana `drop_in_place` dia mety hiteraka fihetsika tsy voafaritra.Mariho fa ny `*to_drop = foo` dia isaina ho toy ny fampiasana satria io no hampihena ny sandany indray.
/// [`write()`] dia azo ampiasaina hametahana data nefa tsy ampidinina.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Esory amin'ny tanana ny entana farany amin'ny vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Makà tondro iray manta amin'ny singa farany amin'ny `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Manafohy `v` mba hisorohana ny zavatra farany tsy ho nandatsaka.
///     // Manao izany voalohany, mba hisorohana ny olana raha toa ka `drop_in_place` panics eto ambany.
///     v.set_len(1);
///     // Raha tsy misy antso `drop_in_place` dia tsy hilatsaka mihitsy ny entana farany ary ho tafaporitsaka ny fahatsiarovana izay tanterahiny.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Hamarino fa nilatsaka ny entana farany.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Mariho fa ny compiler dia manao an'io kopia io avy hatrany rehefa mandatsaka ireo fantsona feno entana, izany hoe, matetika tsy mila miahiahy momba ny olana toy izany ianao raha tsy miantso tanana `drop_in_place` anao.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Tsy maninona ny kaody eto fa soloina ny lakaoly mitete avy amin'ny mpanangona.
    //

    // SAFETY: jereo ny hevitra etsy ambony
    unsafe { drop_in_place(to_drop) }
}

/// Mamorona pointer manta tsy misy.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Mamorona pointer manta azo ovaina.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Ilaina ny impl manual mba hialana amin'ny `T: Clone` voafatotra.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Ilaina ny impl manual mba hialana amin'ny `T: Copy` voafatotra.
impl<T> Copy for FatPtr<T> {}

/// Mamorona silaka manta avy amin'ny tondro sy halavany.
///
/// Ny adihevitra `len` dia ny isan'ny singa ** **, fa tsy ny isan'ny bytes.
///
/// Ity fiasa ity dia azo antoka, fa ny fampiasana ny sandan'ny fiverenana dia tsy azo antoka.
/// Zahao ny antontan-taratasy momba ny [`slice::from_raw_parts`] raha mila fepetra arovana.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // mamorona pointer slice rehefa manomboka amin'ny pointer mankany amin'ny singa voalohany
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Ny fidirana amin'ny sanda avy amin'ny firaisana `Repr` dia azo antoka hatramin'ny * const [T]
        //
        // ary FatPtr dia manana lamina fahatsiarovana mitovy.std ihany no afaka manome an'io antoka io.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Manatanteraka izany araka ny [`slice_from_raw_parts`]-miasa, afa-tsy ny manta mutable silaka dia niverina, izay mifanohitra amin'ny loha tsy mety miova ny manta silaka.
///
///
/// Jereo ny antontan-taratasy momba ny [`slice_from_raw_parts`] raha mila fanazavana fanampiny.
///
/// Ity fiasa ity dia azo antoka, fa ny fampiasana ny sandan'ny fiverenana dia tsy azo antoka.
/// Zahao ny antontan-taratasy momba ny [`slice::from_raw_parts_mut`] raha mila fepetra arovana.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // manomeza sanda amin'ny index ao amin'ilay slice
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Ny fidirana amin'ny sanda avy amin'ny firaisana `Repr` dia azo antoka hatramin'ny * mut [T]
        // ary FatPtr dia manana lamina fahatsiarovana mitovy
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Ampifamadiho ny soatoavina amin'ny toerana roa azo ovaina amin'ny karazany mitovy, nefa tsy manafoana izany koa.
///
/// Fa ho an'ireo maningana roa manaraka, ity fiasa ity dia mitovy amin'ny [`mem::swap`]:
///
///
/// * Miasa amin'ny tondro manta izy io fa tsy fanovozan-kevitra.
/// Rehefa misy ny fanovozan-kevitra dia aleo [`mem::swap`].
///
/// * Ireo soatoavina roa nanondro dia mety hifanindry.
/// Raha mifanindry ny soatoavina, dia hampiasaina ny faritra fahatsiarovana avy amin'ny `x`.
/// Ity dia aseho amin'ny ohatra faharoa etsy ambany.
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * Samy `x` sy `y` tsy maintsy ho [valid] ho an'ny mamaky sy manoratra.
///
/// * Ny `x` sy `y` dia tsy maintsy ampifanarahana tsara.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Fivadihana faritra roa tsy mifanindry:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // `array[0..2]` ity
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // `array[2..4]` ity
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Fanakalozana faritra roa mifanindry:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // `array[0..3]` ity
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // `array[1..4]` ity
///
/// unsafe {
///     ptr::swap(x, y);
///     // Ny index `1..3` an'ny sombin-javatra mifanindry eo anelanelan'ny `x` sy `y`.
///     // Ny valiny mety dia ho `[2, 3]` ho azy ireo, ka ny index `0..3` dia `[1, 2, 3]` (mifanentana amin'ny `y` alohan'ny `swap`);na ho `[0, 1]` ho azy ireo ka ny index `1..4` dia `[0, 1, 2]` (mifanentana amin'ny `x` alohan'ny `swap`).
/////
///     // Ity fampiharana ity dia nofaritana mba hisafidianana ny farany.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Omeo toerana hikirakirana ny tenanay.
    // Tsy mila miahiahy momba ny rano mitete isika: `MaybeUninit` tsy manao na inona na inona rehefa nilatsaka.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Ataovy ny SAFETY fifanakalozana: ny miantso dia tsy maintsy manome toky fa `x` sy `y` dia manan-kery amin'ny fanoratana sy mifanaraka tsara.
    // `tmp` Tsy azo atao mifanindry na `x` na `y` satria `tmp` no natokana teo amin'ny stack raha toa ka zavatra natokana natokana ho azy.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ary `y` mety hifanindry
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Mivadika bytes `count * size_of::<T>()` eo anelanelan'ny faritra fahatsiarovana roa manomboka amin'ny `x` sy `y`.
/// Ireo faritra roa dia tsy tokony * hifanindry.
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * Ny `x` sy `y` dia tokony ho [valid] ho an'ny famakiana sy fanoratana ny `count *
///   size_of: :<T>() `bytes.
///
/// * Ny `x` sy `y` dia tsy maintsy ampifanarahana tsara.
///
/// * Ny faritry ny fahatsiarovana manomboka amin'ny `x` miaraka amin'ny habe `count *
///   size_of: :<T>() `bytes dia tsy tokony * tsy hifanindry amin'ny faritry ny fahatsiarovana manomboka amin'ny `y` mitovy habe aminy.
///
/// Mariho fa na dia ny habeny namboarina tamin'ny fomba mahomby aza (`count * size_of: :<T>():) Dia `0`, ny sahaza dia tsy maintsy ho tsy araka ny tokony ho tohivakana foana sy mifanaraka.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: ny miantso dia tsy maintsy manome antoka fa `x` sy `y` dia
    // manan-kery ho an'ny fanoratana ary mifanaraka tsara.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Ho an'ireo karazana kely kokoa noho ny fanatsarana ny sakana etsy ambany, miovaova fotsiny mba hialana amin'ny codegen pessimizing.
    //
    if mem::size_of::<T>() < 32 {
        // SAFETY: ny miantso dia tsy maintsy manome toky fa `x` sy `y` dia marina
        // ho an'ny fanoratana, mifanaraka tsara, ary tsy mifanindry.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Ny fomba fijery eto dia ny hampiasa simd ny swap X&y mahomby.
    // Ny fitsapana dia mampiharihary fa ny fifanakalozana 32 bytes na 64 bytes indray mandeha dia mandaitra indrindra ho an'ny processeur Intel Haswell E.
    // LLVM dia afaka manatsara kokoa raha manome struct ny #[repr(simd)], na dia tsy tena mampiasa izany struct mivantana.
    //
    //
    // FIXME repr(simd) tapaka amin'ny emscripten sy redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop amin'ny x&y, maka tahaka azy ireo `Block` indray mandeha Ny mpandanja dia tokony hamaha tanteraka ny loop ho an'ny ankamaroan'ny karazana NB
    // Tsy afaka mampiasa loop for loop izahay satria ny `range` impl miantso `mem::swap` miverina
    //
    let mut i = 0;
    while i + block_size <= len {
        // Mamorona fahatsiarovana tsy voamarina ho toy ny toerana manala ny fanambarana ny `t` eto fa tsy mampifanaraka ny stack raha tsy ampiasaina ity loop ity
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: Amin'ny maha `i < len`, ary amin'ny maha miantso azy dia tsy maintsy manome toky fa `x` sy `y` no marina
        // ho an'ny byte `len`, `x + i` ary `y + i` dia tsy maintsy adiresy manan-kery, izay manatanteraka ny fifanarahana fiarovana ho an'ny `add`.
        //
        // Ary koa, ny miantso dia tsy maintsy manome toky fa `x` sy `y` dia manan-kery amin'ny fanoratana, mifanaraka tsara, ary tsy mifanindry, izay manatanteraka ny fifanarahana fiarovana ho an'ny `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Ampifamadiho ny bytes x&y, ampiasao ny t ho buffer vonjimaika Ity dia tokony hasiana fanatsarana ho lasa asa SIMD mahomby izay misy
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Ampifamadiho ny bytes sisa
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // Famonjena, fiarovana jereo ny teo aloha fanehoan-kevitra.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Mamindra `src` ao anaty `dst` maranitra, mamerina ny sanda `dst` teo aloha.
///
/// Samy tsy nilatsaka ny sanda.
///
/// Ity fiasa ity dia mitovy amin'ny [`mem::replace`] raha tsy hoe miasa amin'ny tondro manta izy fa tsy referansa.
/// Rehefa misy ny fanovozan-kevitra dia aleo [`mem::replace`].
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `dst` tsy maintsy [valid] na samy mamaky na manoratra.
///
/// * `dst` dia tsy maintsy ho araka ny tokony mifanaraka.
///
/// * `dst` dia tsy maintsy manondro sanda `T` natomboka tsara.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` dia hisy vokany mitovy amin'izany raha tsy mitaky ny sakana tsy azo antoka.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: ny miantso dia tsy maintsy manome toky fa `dst` dia mety
    // alefa amina référable azo ovaina (manan-kery ho an'ny manoratra, mifanaraka, namboarina), ary tsy afaka mifanindry `src` satria `dst` dia tsy maintsy manondro zavatra miavaka natokana.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // tsy afaka mifanindry
    }
    src
}

/// Mamaky ny sanda avy amin'ny `src` nefa tsy mihetsika.Io dia mamela ny fahatsiarovana ao amin'ny `src` tsy miova.
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `src` tsy maintsy [valid] raha vakiana.
///
/// * `src` tsy maintsy ampifanarahana tsara.Mampiasà [`read_unaligned`] raha tsy izany no izy.
///
/// * `src` dia tsy maintsy manondro sanda `T` natomboka tsara.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ampiharo amin'ny tanana ny [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Mamorona kopia bitwise amin'ilay sanda amin'ny `a` ao `tmp`.
///         let tmp = ptr::read(a);
///
///         // Fivoahan'ny Tamin'io fotoana io (na amin'ny alalan'ny miverina mivantana na amin'ny fiantsoana ny asa izay panics) hahatonga ny sarobidy eo `tmp` ho latsaka raha mbola mitovy vidy no mbola hanovozan-kevitra amin'ny `a`.
///         // Mety hiteraka fihetsika tsy voafaritra izany raha tsy `Copy` ny `Copy`.
/////
/////
///
///         // Mamorona kopia bitwise amin'ilay sanda amin'ny `b` ao `a`.
///         // Tsy misy atahorana izany satria tsy azo atao solon'anarana ireo andinin-tsoratra miovaova.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Tahaka ny etsy ambony, ny fivoahana eto dia mety hiteraka fihetsika tsy voafaritra satria ny sanda mitovy dia asehon'ny `a` sy `b`.
/////
///
///         // Afindra amin'ny `b` ny `tmp`.
///         ptr::write(b, tmp);
///
///         // `tmp` dia nafindra (`write` dia tompon'ny tohan-kevitra faharoa), ka tsy misy na inona na inona nilatsaka eto.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Fananana ny sanda niverina
///
/// `read` mamorona dika mitovy `T` bitwise, na inona na inona `T` dia [`Copy`].
/// Raha `T` dia tsy [`Copy`], ny fampiasana ny sanda miverina sy ny sanda amin'ny `*src` dia mety hanimba ny fiarovana ny fitadidiana.
/// Mariho fa ny fanendrena ny `*src` dia isaina ho toy ny fampiasana satria hanandrana mandatsaka ny sanda amin'ny `* src` izy.
///
/// [`write()`] dia azo ampiasaina hametahana data nefa tsy ampidinina.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` ankehitriny dia manondro ilay fitadidiana izay mitovy amin'ny `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ny fanendrena amin'ny `s2` dia mahatonga ny lanjan'orinasa nilatsaka.
///     // Ankoatra io teboka io dia tsy tokony hampiasaina intsony ny `s`, satria efa navotsotra ny fahatsiarovana ifotony.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ny fanendrena amin'ny `s` dia mety hampihena ny sanda taloha, ka miteraka fihetsika tsy voafaritra.
/////
///     // s= String::from("bar");//ERROR
///
///     // `ptr::write` dia azo ampiasaina hanonerana ny sanda iray nefa tsy arotsanao izany.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: ny miantso dia tsy maintsy manome toky fa `src` dia manan-kery amin'ny famakiana.
    // `src` tsy afaka mifanindry `tmp` satria `tmp` dia natokana fotsiny teo amin'ny stack ho toy ny zavatra natokana natokana.
    //
    //
    // Ary koa, satria vao nanoratra sanda manan-kery ho `tmp` izahay, dia azo antoka fa ho voaloham-bokatra.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Mamaky ny sanda avy amin'ny `src` nefa tsy mihetsika.Io dia mamela ny fahatsiarovana ao amin'ny `src` tsy miova.
///
/// Tsy toy ny [`read`], i `read_unaligned` dia miasa miaraka amin'ireo tondro tsy voasoratra.
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `src` tsy maintsy [valid] raha vakiana.
///
/// * `src` dia tsy maintsy manondro sanda `T` natomboka tsara.
///
/// Toy ny [`read`], `read_unaligned` dia mamorona kopian'ny `T` kely, na inona na inona `T` dia [`Copy`].
/// Raha `T` dia tsy [`Copy`], ny fampiasana ny sanda miverina sy ny sanda amin'ny `*src` dia afaka [violate memory safety][read-ownership].
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NUL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Amin'ny tsipika `packed`
///
/// Tsy azo atao izao ny mamorona tondro manta amin'ny sahan'endrika tsy voafetra.
///
/// Ny fiezahana hamorona pointer manta amin'ny sehatry ny rafitra `unaligned` misy fitenenana toy ny `&packed.unaligned as *const FieldType` dia mamorona referansa tsy misy fanelanelanana alohan'ny hamadihana izany ho mpanondro manta.
///
/// Vetivety ity fanovozan-kevitra ity dia tsy misy dikany ny fandefasana azy avy hatrany satria ny mpanangona dia manantena foana fa mifanaraka tsara ny fanovozan-kevitra.
/// Vokatr'izany, ny fampiasana `&packed.unaligned as *const FieldType` dia miteraka fihetsika* tsy voafaritra eo noho eo * amin'ny programa nataonao.
///
/// Ohatra iray amin'ny zavatra tsy tokony hatao sy ny fifandraisany amin'ny `read_unaligned` dia:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Eto isika dia miezaka ny hitondra ny adiresy iray 32-bit integer izay tsy mifanaraka.
///     let unaligned =
///         // Natao eto ny referansy iray tsy mifanaraka amin'ny laoniny izay miteraka fihetsika tsy voafaritra na inona na inona fampiasana na tsia.
/////
///         &packed.unaligned
///         // Tsy manampy ny fanondro any amin'ny tondro masaka;ny fahadisoana efa nitranga.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ny fidirana amin'ny saha tsy voasokitra mivantana miaraka amin'ny eg `packed.unaligned` dia azo antoka.
///
///
///
///
///
///
// FIXME: Fanavaozana ireo antontan-taratasy mifototra amin'ny valin'ny RFC #2582 sy ny namana.
/// # Examples
///
/// Vakio ny usize sarobidy avy amin'ny byte buffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: ny miantso dia tsy maintsy manome toky fa `src` dia manan-kery amin'ny famakiana.
    // `src` tsy afaka mifanindry `tmp` satria `tmp` dia natokana fotsiny teo amin'ny stack ho toy ny zavatra natokana natokana.
    //
    //
    // Ary koa, satria vao nanoratra sanda manan-kery ho `tmp` izahay, dia azo antoka fa ho voaloham-bokatra.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Manoratra toerana fitadidiana miaraka amin'ny sanda nomena fa tsy mamaky na mandatsaka ny sanda taloha.
///
/// `write` tsy mandatsaka ny atin'ny `dst`.
/// Tsy misy atahorana izany, saingy mety hiteraka famatsiam-bola na famoahana loharano izany, koa tokony hotandremana mba tsy hanoratra zavatra tokony haidina.
///
///
/// Ankoatr'izay, tsy milatsaka `src` izy io.Raha ara-potoana, ny `src` dia afindra any amin'ilay toerana notondroin'i `dst`.
///
/// Izany no mety ho nitranga teo am-uninitialized fahatsiarovana, na overwriting fahatsiarovana teo aloha izay efa [`read`] avy.
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `dst` tsy maintsy [valid] raha hanoratra.
///
/// * `dst` tsy maintsy ampifanarahana tsara.Ampiasao [`write_unaligned`] raha tsy izany no nitranga.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ampiharo amin'ny tanana ny [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Mamorona kopia bitwise amin'ilay sanda amin'ny `a` ao `tmp`.
///         let tmp = ptr::read(a);
///
///         // Fivoahan'ny Tamin'io fotoana io (na amin'ny alalan'ny miverina mivantana na amin'ny fiantsoana ny asa izay panics) hahatonga ny sarobidy eo `tmp` ho latsaka raha mbola mitovy vidy no mbola hanovozan-kevitra amin'ny `a`.
///         // Mety hiteraka fihetsika tsy voafaritra izany raha tsy `Copy` ny `Copy`.
/////
/////
///
///         // Mamorona kopia bitwise amin'ilay sanda amin'ny `b` ao `a`.
///         // Tsy misy atahorana izany satria tsy azo atao solon'anarana ireo andinin-tsoratra miovaova.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Tahaka ny etsy ambony, ny fivoahana eto dia mety hiteraka fihetsika tsy voafaritra satria ny sanda mitovy dia asehon'ny `a` sy `b`.
/////
///
///         // Afindra amin'ny `b` ny `tmp`.
///         ptr::write(b, tmp);
///
///         // `tmp` dia nafindra (`write` dia tompon'ny tohan-kevitra faharoa), ka tsy misy na inona na inona nilatsaka eto.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Miantso mivantana ny intrinsika izahay mba hialana amin'ny antso an-tariby amin'ny kaody noforonina satria ny `intrinsics::copy_nonoverlapping` dia fonosana fonosana.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: ny miantso dia tsy maintsy manome antoka fa `dst` dia manan-kery amin'ny fanoratana.
    // `dst` tsy afaka mifanindry `src` satria ny miantso dia manana fidirana mutable mankany `dst` raha `src` kosa dia manana an'io fiasa io.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Manoratra toerana fitadidiana miaraka amin'ny sanda nomena fa tsy mamaky na mandatsaka ny sanda taloha.
///
/// Tsy toy ny [`write()`], ny tondro dia mety tsy mifanaraka.
///
/// `write_unaligned` tsy mandatsaka ny atin'ny `dst`.Tsy misy atahorana izany, saingy mety hiteraka famatsiam-bola na famoahana loharano izany, koa tokony hotandremana mba tsy hanoratra zavatra tokony haidina.
///
/// Ankoatr'izay, tsy milatsaka `src` izy io.Raha ara-potoana, ny `src` dia afindra any amin'ilay toerana notondroin'i `dst`.
///
/// Izy io dia mety amin'ny fanombohana fahatsiarovana tsy voalamina, na fampidirina fahatsiarovana izay novakiana niaraka tamin'ny [`read_unaligned`].
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `dst` tsy maintsy [valid] raha hanoratra.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NUL.
///
/// [valid]: self#safety
///
/// ## Amin'ny tsipika `packed`
///
/// Tsy azo atao izao ny mamorona tondro manta amin'ny sahan'endrika tsy voafetra.
///
/// Ny fiezahana hamorona pointer manta amin'ny sehatry ny rafitra `unaligned` misy fitenenana toy ny `&packed.unaligned as *const FieldType` dia mamorona referansa tsy misy fanelanelanana alohan'ny hamadihana izany ho mpanondro manta.
///
/// Vetivety ity fanovozan-kevitra ity dia tsy misy dikany ny fandefasana azy avy hatrany satria ny mpanangona dia manantena foana fa mifanaraka tsara ny fanovozan-kevitra.
/// Vokatr'izany, ny fampiasana `&packed.unaligned as *const FieldType` dia miteraka fihetsika* tsy voafaritra eo noho eo * amin'ny programa nataonao.
///
/// Ohatra iray amin'ny zavatra tsy tokony hatao sy ny fifandraisany amin'ny `write_unaligned` dia:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Eto isika dia miezaka ny hitondra ny adiresy iray 32-bit integer izay tsy mifanaraka.
///     let unaligned =
///         // Natao eto ny referansy iray tsy mifanaraka amin'ny laoniny izay miteraka fihetsika tsy voafaritra na inona na inona fampiasana na tsia.
/////
///         &mut packed.unaligned
///         // Tsy manampy ny fanondro any amin'ny tondro masaka;ny fahadisoana efa nitranga.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ny fidirana amin'ny saha tsy voasokitra mivantana miaraka amin'ny eg `packed.unaligned` dia azo antoka.
///
///
///
///
///
///
///
///
///
// FIXME: Fanavaozana ireo antontan-taratasy mifototra amin'ny valin'ny RFC #2582 sy ny namana.
/// # Examples
///
/// Manorata sanda usize amin'ny buffer byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: ny miantso dia tsy maintsy manome antoka fa `dst` dia manan-kery amin'ny fanoratana.
    // `dst` tsy afaka mifanindry `src` satria ny miantso dia manana fidirana mutable mankany `dst` raha `src` kosa dia manana an'io fiasa io.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Miantso mivantana ny intrinsika izahay mba hisorohana ireo fiantsoana miasa ao amin'ilay kaody novokarina.
        intrinsics::forget(src);
    }
}

/// Manatanteraka famakiana mora miovaova ny sanda avy amin'ny `src` nefa tsy mihetsika izany.Izany mamela ny fahatsiarovana ao `src` niova.
///
/// Ny fiasa mihetsiketsika dia natao hiasa amin'ny fahatsiarovana I/O, ary azo antoka fa tsy ho voaroaka na hanonta ny mpanera manerana ny asa hafa miovaova.
///
/// # Notes
///
/// Rust dia tsy manana maodely fitadidiana voafaritra henjana sy voafaritra tsara ankehitriny, noho izany ny semantika marina momba ny dikan'ny "volatile" eto dia azo ovaina rehefa mandeha ny fotoana.
/// Ny amin'ilay efa nanao hoe: ny semantics ho foana farany somary mitovy amin'ny [C11's definition of volatile][c11].
///
/// Ny mpandrindra dia tsy tokony hanova ny filaharana na ny isan'ny asa fitadidiana miovaova.
/// Na izany aza, ny asan'ny fahatsiarovana miovaova amin'ny karazana zero-habe (oh: raha toa ka nolovaina tamin'ny `read_volatile` ny karazana aotra-lehibe) dia tampony ary azo tsinontsinoavina.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `src` tsy maintsy [valid] raha vakiana.
///
/// * `src` dia tsy maintsy ho araka ny tokony mifanaraka.
///
/// * `src` dia tsy maintsy manondro sanda `T` natomboka tsara.
///
/// Toy ny [`read`], `read_volatile` dia mamorona kopian'ny `T` kely, na inona na inona `T` dia [`Copy`].
/// Raha `T` dia tsy [`Copy`], ny fampiasana ny sanda miverina sy ny sanda amin'ny `*src` dia afaka [violate memory safety][read-ownership].
/// Na izany aza, mitahiry hitenenan'izay [: Copy`] karazany in mikorontana fahatsiarovana dia saika azo antoka fa diso.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Toy ny any C, na miovaova ny fandidiana dia tsy misy ifandraisany amin'ny fanontaniana misy idirana miaraka amin'ny kofehy maro.Ny fidirana mihetsiketsika dia mitondra tena toy ny fidirana tsy ataoma raha izany.
///
/// Manokana, hazakaza eo anelanelan'ny `read_volatile` sy ny fiasan-tsoratra amin'ny toerana iray ihany dia fihetsika tsy voafaritra.
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Tsy mikoropaka hitazomana ny fiantraikan'ny codegen ho kely kokoa.
        abort();
    }
    // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Manatanteraka fanoratana mora miova amin'ny toerana fahatsiarovana miaraka amin'ny sanda nomena fa tsy mamaky na mandatsaka ny sanda taloha.
///
/// Ny fiasa mihetsiketsika dia natao hiasa amin'ny fahatsiarovana I/O, ary azo antoka fa tsy ho voaroaka na hanonta ny mpanera manerana ny asa hafa miovaova.
///
/// `write_volatile` tsy mandatsaka ny atin'ny `dst`.Tsy misy atahorana izany, saingy mety hiteraka famatsiam-bola na famoahana loharano izany, koa tokony hotandremana mba tsy hanoratra zavatra tokony haidina.
///
/// Ankoatr'izay, tsy milatsaka `src` izy io.Raha ara-potoana, ny `src` dia afindra any amin'ilay toerana notondroin'i `dst`.
///
/// # Notes
///
/// Rust dia tsy manana maodely fitadidiana voafaritra henjana sy voafaritra tsara ankehitriny, noho izany ny semantika marina momba ny dikan'ny "volatile" eto dia azo ovaina rehefa mandeha ny fotoana.
/// Ny amin'ilay efa nanao hoe: ny semantics ho foana farany somary mitovy amin'ny [C11's definition of volatile][c11].
///
/// Ny mpandrindra dia tsy tokony hanova ny filaharana na ny isan'ny asa fitadidiana miovaova.
/// Na izany aza, ny asan'ny fahatsiarovana miovaova amin'ny karazana zero-habe (oh: raha toa ka nolovaina tamin'ny `write_volatile` ny karazana aotra-lehibe) dia tampony ary azo tsinontsinoavina.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `dst` tsy maintsy [valid] raha hanoratra.
///
/// * `dst` dia tsy maintsy ho araka ny tokony mifanaraka.
///
/// Mariho fa na `T` aza dia manana habe `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// [valid]: self#safety
///
/// Toy ny any C, na miovaova ny fandidiana dia tsy misy ifandraisany amin'ny fanontaniana misy idirana miaraka amin'ny kofehy maro.Ny fidirana mihetsiketsika dia mitondra tena toy ny fidirana tsy ataoma raha izany.
///
/// Manokana, hazakaza eo anelanelan'ny `write_volatile` sy ny fiasa hafa (mamaky na manoratra) amin'ny toerana iray ihany no fihetsika tsy voafaritra.
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Tsy mikoropaka hitazomana ny fiantraikan'ny codegen ho kely kokoa.
        abort();
    }
    // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Ampifanaraho amin'ny tondro `p`.
///
/// Kajy ny offset (amin'ny lafin'ny singa `stride` stride) izay tsy maintsy ampiharina amin'ny tondro `p` mba hifanaraka amin'ny `a` ny tondro `p`.
///
/// Note: Ity fampiharana ity dia namboarina tsara fa tsy panic.UB ho an'ity mankany panic.
/// Ny hany fanovana azo atao eto dia ny fanovana ny `INV_TABLE_MOD_16` sy ny Constant mifandray.
///
/// Raha manapa-kevitra ny hanao izay azo atao isika hiantsoana ny intrinsika amin'ny `a` izay tsy herin'olon-droa isika, dia mety ho malina kokoa ny manova ny fampiharana tsy misy fotony fa tsy manandrana mampifanaraka an'io mba handray ilay fanovana.
///
///
/// Ny fanontaniana dia mandeha any@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ny fampiasana mivantana ireo intrinsika ireo dia manatsara ny codegen amin'ny opt-level <=
    // 1, izay tsy naseho ireo kinova fomba fiasa amin'ireo.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Fikajiana inverse modular multiplicative an'ny `x` modulo `m`.
    ///
    /// Ity fampiharana ity dia natao ho an'ny `align_offset` ary manaraka fepetra mialoha:
    ///
    /// * `m` dia herin'ny roa;
    /// * `x < m`; (raha `x ≥ m`, ampidiro `x % m`)
    ///
    /// Ny fampiharana an'io asa io dia tsy tokony panic.Mandrakizay.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Modulo latabatra miolakolaka modular 2⁴=16.
        ///
        /// Mariho fa ity latabatra ity dia tsy misy sanda raha tsy misy ny inverse (ie, ho an'ny `0⁻¹ mod 16`, `2⁻¹ mod 16`, sns.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo izay kasaina ny `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: `m` dia takiana amin'ny herin'ny roa, noho izany tsy aotra.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Izahay dia miverina "up" amin'ny fampiasana ity paika manaraka ity:
            //
            // $$ xy ≡ 1 (Mod 2ⁿ) → xy (2, xy) ≡ 1 (Mod 2²ⁿ) $$
            //
            // mandra-2²ⁿ ≥ m.Avy eo isika dia afaka mampihena ny `m` tadiavintsika amin'ny fakana ny valiny `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Mariho, fanahy iniana ampiasainay ny fonosana fonosana eto-ny raikipohy tany am-boalohany dia mampiasa oh, ny fitrandrahana `mod n`.
                // Milamina tanteraka ny fanaovana azy ireo `mod usize::MAX` fa tsy izany, satria mandray ny vokatra `mod n` ihany isika amin'ny farany.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` dia herin'ny roa, noho izany tsy aotra.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Ny tranga dia azo isaina amin'ny alàlan'ny `-p (mod a)` tsotra kokoa, fa ny fanatanterahana izany dia manakana ny fahafahan'ny LLVM misafidy torolàlana toy ny `lea`.Fa manoratra kosa izahay
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // izay mizara fiasa manodidina ny enta-mavesatra, fa pessimizing `and` ampy hahafahan'ny LLVM mampiasa ireo fanatsarana isan-karazany fantany.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Efa mifanaraka.Yay!
        return 0;
    } else if stride == 0 {
        // Raha tsy manondro ny mifanaraka, ary ny singa dia aotra-salantsalany, dia tsy habetsaky ny singa dia mandrakizay hampifanaraka manondro.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a dia herin'ny roa noho izany tsy aotra.stride==0 tranga no raisina etsy ambony.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow dia manana fehin-tànana ambony izay farafahakeliny ny isan'ny bitsika amin'ny usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd dia lehibe kokoa na mitovy amin'ny 1 hatrany.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ity branch ity dia mamaha ity fampitahana kônjotra manaraka ity:
        //
        // ` p + so = 0 mod a `
        //
        // `p` ity ny sanda pointer, `s`, stride of `T`, `o` offset ao amin'ny `T`s, ary `a`, ilay fampifanarahana nangatahina.
        //
        // Miaraka amin'ny `g = gcd(a, s)`, ary ny fepetra etsy ambony manamafy fa `p` dia zarain'ny `g` ihany koa, azontsika atao ny manondro ny `a' = a/g`, `s' = s/g`, `p' = p/g`, avy eo lasa mitovy amin'ny:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ny fehezan-teny voalohany dia "the relative alignment of `p` to `a`" (nozarain'ny `g`), ny fe-potoana faharoa dia "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (zarazaraina indray amin'ny `g`).
        //
        // Ny fizarana amin'ny `g` dia ilaina mba hampiorina tsara ny inverse raha toa ka tsy mpiara-miombon'antoka i `a` sy `s`.
        //
        // Ankoatr'izay, ny vokatra vokarin'ity vahaolana ity dia tsy "minimal", noho izany dia ilaina ny maka ny valiny `o mod lcm(s, a)`.Azontsika atao ny manolo ny `lcm(s, a)` amin'ny `a'` fotsiny.
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` dia manana fehin-kibo ambony tsy lehibe noho ny isan'ny 0-bitika mivoaka ao `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` dia tsy aotra.Ny famindrana `a` an'i `gcdpow` dia tsy afaka mamindra ireo sombin-javatra napetraka
        // amin'ny `a` (izay manana iray tena izy).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` dia manana fehin-kibo ambony tsy lehibe noho ny isan'ny 0-bitika mivoaka ao `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` dia manana fetra ambony tsy ambony noho ny isan'ny 0-bitika ao anatiny
        // `a`.
        // Ankoatr'izay, ny subtraction dia tsy afaka misondrotra satria `a2 = a >> gcdpow` dia ho lehibe lavitra noho ny `(p % a) >> gcdpow` foana.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: `a2` dia herin'ny roa, araka ny voaporofo etsy ambony.`s2` dia tanteraka latsaky ny `a2`
        // satria fotsiny `(s % a) >> gcdpow` dia latsaky ny `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Tsy azo atao mifanaraka mihitsy.
    usize::MAX
}

/// Mampitaha ireo tondro manta amin'ny fitoviana.
///
/// Izy io dia mitovy amin'ny fampiasana ny mpandraharaha `==`, fa kely kokoa:
/// ny fanehoan-kevitra tsy maintsy ho `*const T` manta sahaza, tsy na inona na inona ny fitaovana `PartialEq`.
///
/// Izy io dia azo ampiasaina hampitahana ireo referansa `&T` (izay manery ny `*const T` mihintsy) amin'ny adiresy fa tsy mampitaha ny soatoavina tondroin'izy ireo (izay ny fampiharana `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Ny slices dia ampitahaina amin'ny halavany (tondro tavy):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits dia ampitahain'ny fampiharana azy ihany koa:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Ny adiresy dia manana adiresy mitovy.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Ireo zavatra dia manana adiresy mitovy, fa ny `Trait` dia samy manana ny fampiharana azy.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Mampivadika ny referansa amin'ny `*const u8` raha oharina amin'ny adiresy.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Manomeza mpanondro manta.
///
/// Izy io dia azo ampiasaina hanasongadinana referansa `&T` (izay manery ny `*const T` mihintsy) amin'ny adiresy fa tsy ny sanda tondroiny (izay ny fampiharana `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Miorina amin'ny tondro fiasa
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ny mpilalao antonony toy ny usize dia takiana amin'ny AVR
                // ka ny habaka adiresin'ny pointer d'exploitation source dia voatahiry ao amin'ny pointeur final function.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ny mpilalao antonony toy ny usize dia takiana amin'ny AVR
                // ka ny habaka adiresin'ny pointer d'exploitation source dia voatahiry ao amin'ny pointeur final function.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Tsy misy fiasa variadika misy masontsivana 0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Mamorà paozy `const` manta amin'ny toerana iray, nefa tsy mamorona referansa mpanelanelana.
///
/// Ny famoronana referansa miaraka amin'ny `&`/`&mut` dia azo ekena raha toa ka mifanaraka tsara ny mpanondro ary manondro ny angon-drakitra voalahatra.
/// Ho an'ireo tranga izay tsy itananan'ireo fepetra takiana ireo dia tokony hampiasaina ireo tondro manta.
/// Na izany aza, `&expr as *const _` dia mamorona référence alohan'ny fandefasana azy any amin'ny pointer manta, ary io referansa io dia miankina amin'ny lalàna mitovy amin'ny referansa hafa rehetra.
///
/// Ity makro ity dia afaka mamorona tondro maska *tsy* mamorona referansa aloha.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` dia hamorona fanovozan-kevitra tsy mifanaraka, ary amin'izany dia ho fitondrantena tsy voafaritra!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Mamorà paozy `mut` manta amin'ny toerana iray, nefa tsy mamorona referansa mpanelanelana.
///
/// Ny famoronana referansa miaraka amin'ny `&`/`&mut` dia azo ekena raha toa ka mifanaraka tsara ny mpanondro ary manondro ny angon-drakitra voalahatra.
/// Ho an'ireo tranga izay tsy itananan'ireo fepetra takiana ireo dia tokony hampiasaina ireo tondro manta.
/// Na izany aza, `&mut expr as *mut _` dia mamorona référence alohan'ny fandefasana azy any amin'ny pointer manta, ary io referansa io dia miankina amin'ny lalàna mitovy amin'ny referansa hafa rehetra.
///
/// Ity makro ity dia afaka mamorona tondro maska *tsy* mamorona referansa aloha.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` dia hamorona fanovozan-kevitra tsy mifanaraka, ary amin'izany dia ho fitondrantena tsy voafaritra!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` hery mandika ny saha fa tsy mamorona referansa.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}