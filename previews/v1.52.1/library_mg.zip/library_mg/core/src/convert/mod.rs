//! Traits ho an'ny fiovam-po eo amin'ny karazany.
//!
//! Ny traits ato amin'ity modely ity dia manome fomba iray hanovana karazana iray hafa.
//! Ny trait tsirairay dia samy manana tanjona hafa:
//!
//! - Ampiharo ny [`AsRef`] trait ho an'ny fiovam-po-to-referansa mora vidy
//! - Tanteraho ny [`AsMut`] trait ho mora vidy mutable-to-mutable fiovam-pony
//! - Ampiharo ny [`From`] trait handevonana ny fiovam-po amin'ny sanda
//! - Ampiharo ny [`Into`] trait handaniana ny fiovam-po amin'ny sanda amin'ny karazany ivelan'ny crate ankehitriny
//! - Ny [`TryFrom`] sy [`TryInto`] traits hitondra tena toy ny [`From`] sy [`Into`], fa tokony ho ampiharina, rehefa tsy mety ny fiovam-po.
//!
//! Ny traits in Module ity dia matetika ampiasaina ho trait bounds for levitra asa toy izay ny hevitra ny maro karazana no manohana.Jereo ny tahirin-kevitra tsirairay ny ohatra trait.
//!
//! Amin'ny maha-mpanoratra trano famakiam-boky, fa tokony hataonao foana fampiharana kokoa [`From<T>`][`From`] na [`TryFrom<T>`][`TryFrom`] fa tsy [`Into<U>`][`Into`] na [`TryInto<U>`][`TryInto`], araka ny [`From`] sy [`TryFrom`] manome manovaova kokoa sy manolotra mitovy [`Into`] na [`TryInto`] implementations maimaim-poana, noho ny fampiharana ny bodofotsy tao amin'ny fitehirizam-boky Standard.
//! Rehefa mikendry kinova alohan'ny Rust 1.41 dia mety ilaina ny mampihatra mivantana ny [`Into`] na [`TryInto`] rehefa manova endrika hafa ivelan'ny crate ankehitriny.
//!
//! # Generic Implementations
//!
//! - [`AsRef`] ary [`AsMut`] auto-dereferance raha ny karazana anatiny no resahina
//! - [`Avy`]`<U>satria T` dia midika hoe [`Ao Amin`]`</u><T><U>ho an'i U`</u>
//! - [`TryFrom`]: <U>ho T`dia midika [` TryInto`]</u><T><U>ho an'i U`</u>
//! - [`From`] ary [`Into`] dia taitaitra, izay midika fa afaka `into` karazana rehetra ny tenany sy ny `from` ny tenany
//!
//! Zahao ny trait tsirairay avy ohatra amin'ny fampiasana.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Ny asan'ny maha-izy azy.
///
/// Zava-dehibe roa ny manamarika an'io asa io:
///
/// - Tsy mitovy foana ny fanakatonana tahaka `|x| x`, satria manery ny fanakatonana `x` mety ho karazana hafa.
///
/// - Izy io dia mampihetsika ny fahan'ny `x` ampitaina amin'ny fiasa.
///
/// Na dia toa hafahafa ny hanana asa fa vao miverina indray ny fahan'ny, misy mahaliana ampiasaina amin-javatra.
///
///
/// # Examples
///
/// Mampiasa `identity` tsy hanao na inona na inona amin'ny filaharana asa mahaliana hafa:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Aleo mody manao hoe manampy ny mahaliana ny manampy iray.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Mampiasa `identity` ho toy ny fototra "do nothing" raharaha ao amin'ny fepetra:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Manaova zavatra mahaliana kokoa ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Mampiasà `identity` hitazonana ireo karazany `Some` amin'ny iterator `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Nampiasaina hanaovana fiovampo-to-referansa mora vidy.
///
/// Ity trait ity dia mitovy amin'ny [`AsMut`] izay ampiasaina amin'ny famadihana eo anelanelan'ny références azo mutable.
/// Raha mila manao fiovam-po lafo ianao dia tsara kokoa ny mampihatra ny [`From`] amin'ny karazana `&T` na manoratra fomba amam-panao.
///
/// `AsRef` dia manana izany fanaovan-tsonia araka ny [`Borrow`], fa [`Borrow`] Tsy mitovy eo amin'ny lafiny vitsivitsy:
///
/// - Tsy toy ny `AsRef`, [`Borrow`] manana bodofotsy `T` impl na inona na inona, ary azo ampiasaina mba hanaiky na ny boky, na ny zava-dehibe.
/// - [`Borrow`] mitaky ihany koa ny [`Hash`], [`Eq`] ary [`Ord`] ho an'ny sandam-bola nindramina dia mitovy amin'ny an'ny sanda fananana.
/// Noho izany antony izany, raha te-hisambotra saha iray ihany ny struct dia afaka hametraka `AsRef`, fa tsy [`Borrow`].
///
/// **Note: Ity trait ity dia tsy tokony hahomby **.Raha mety tsy hahomby ny fiovam-po dia ampiasao fomba manokana izay mamerina [`Option<T>`] na [`Result<T, E>`].
///
/// # Generic Implementations
///
/// - `AsRef` auto-dereferansa raha toa ny referansa anatiny na referansa azo ovaina (oh: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Amin'ny alalan'ny fampiasana trait bounds afaka manaiky hevitra ny samy hafa karazana raha toa ka afaka ny hiova fo ho amin'ny karazana voafaritra `T`.
///
/// Ohatra: Ny famoronana asa levitra izay mandray ny `AsRef<str>` dia maneho fa te-hanaiky ny andinin-tsoratra masina izay afaka hiova fo ho [`&str`] toy ny tohan-kevitra.
/// Satria samy [`String`] sy [`&str`] dia mampihatra `AsRef<str>` dia azontsika atao ny manaiky azy roa ho toy ny adihevitra fampidirana.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Manao ny fiovam-po.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Ampiasaina mba hanao ny mora vidy mutable-to-boky mutable fiovam-po.
///
/// Ity trait ity dia mitovy amin'ny [`AsRef`] fa ampiasaina amin'ny famadihana eo anelanelan'ny références azo mutable.
/// Raha mila manao fiovam-po lafo ianao dia tsara kokoa ny mampihatra ny [`From`] amin'ny karazana `&mut T` na manoratra fomba amam-panao.
///
/// **Note: Ity trait ity dia tsy tokony hahomby **.Raha mety tsy hahomby ny fiovam-po dia ampiasao fomba manokana izay mamerina [`Option<T>`] na [`Result<T, E>`].
///
/// # Generic Implementations
///
/// - `AsMut` auto-dereferansa raha toa ka karazan-kevitra azo ovaina ny karazana anatiny (oh: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Mampiasa `AsMut` ho trait bound ho levitra asa azontsika rehetra manaiky mutable andinin-tsoratra masina izay afaka hiova fo mba nitendry `&mut T`.
/// Satria [`Box<T>`] dia mampihatra `AsMut<T>` dia afaka manoratra fiasa `add_one` izay mandray ny hevitra rehetra azo avadika ho `&mut u64`.
/// Satria [`Box<T>`] dia mampihatra `AsMut<T>`, `add_one` dia manaiky ny tohan-kevitra momba ny karazana `&mut Box<u64>` ihany koa:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Manao ny fiovam-po.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Ny sanda-to-zava-dehibe ny fiovam-po mandevona fahan'ny sarobidy.Ny mifanohitra amin'ny [`From`].
///
/// Ny iray dia tokony hisoroka ny fampiharana [`Into`] ary hampihatra [`From`] fa tsy.
/// [`From`] fampiharana avy hatrany dia manome ny iray miaraka amin'ny fametrahana [`Into`] noho ny bodofotsy fampiharana fitehirizam-boky ao amin'ny fitsipika.
///
/// Kokoa mampiasa [`Into`] ny [`From`] rehefa voafaritra trait bounds amin'ny levitra asa mba hahazoana antoka fa izay ihany no manatanteraka karazana [`Into`] azo ampiasaina ihany koa.
///
/// **Note: Izany dia tsy maintsy tsy ho levona trait **.Raha mety tsy hahomby ny fiovam-po, ampiasao [`TryInto`].
///
/// # Generic Implementations
///
/// - [`From`]: <T>for U` dia midika `Into<U> for T`
/// - [`Into`] dia reflexive, izay midika fa ampiharina ny `Into<T> for T`
///
/// # Mampihatra [`Into`] ho an'ny fiovam-po amin'ny karazany ivelany amin'ny kinova Rust taloha
///
/// Talohan'ny Rust 1.41, raha ny karazana toerana tsy anisan'ny crate amin'izao fotoana dia tsy afaka manatanteraka [`From`] mivantana.
/// Ohatra, raiso ity kaody ity:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Tsy hahomby amin'ny fanangonana kinova taloha amin'ilay fiteny izany satria somary hentitra kokoa ny fitsipiky ny kamboty Rust taloha.
/// Mba hialana amin'io dia azonao atao ny mampihatra ny [`Into`] mivantana:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Zava-dehibe ny mahatakatra fa ny [`Into`] dia tsy manome fampiharana [`From`] (toy ny [`From`] amin'ny [`Into`]).
/// Noho izany, tokony hiezaka hatrany ianao hampihatra ny [`From`] ary miverina any [`Into`] raha tsy azo ampiharina ny [`From`].
///
/// # Examples
///
/// [`String`] fitaovana [`Into`]: <: [`Vec`]: <: [`u8`] >>`:
///
/// Raha te hilaza fa te hanana lahasa générique daholo ny hevitra rehetra azo ovaina amin'ny karazana `T` voafaritra tsara dia afaka mampiasa trait bound an'ny [`Into`]`<T>`.
///
/// Ohatra: Ny asa rehetra `is_hello` maka hevitra izay afaka hiova fo ho [`Vec`]: <: [`u8`]> `.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Manao ny fiovam-po.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Nampiasaina hanaovana fiovam-po ho an'ny soatoavina nefa mandany ny sanda ampidirina.Io dia ny valin'ny [`Into`].
///
/// Ny olona iray dia tokony aleony foana mampihatra `From` mihoatra ny [`Into`] satria ny fampiharana `From` dia manome ho azy ny fampiharana [`Into`] noho ny fampiharana lamba firakotra ao amin'ny tranomboky mahazatra.
///
///
/// [`Into`] manatanteraka ihany, rehefa mikendry ny dikan-talohan'ny Rust 1.41 sy hanova ny karazana ivelan'ny crate amin'izao fotoana izao.
/// `From` tsy mahay manao izao karazana dikan fiovam-pony ao amin'ny teo aloha noho ny orphaning Rust ny fitsipika.
/// Jereo [`Into`] raha mila fanazavana fanampiny.
///
/// Aleo mampiasa [`Into`] mihoatra ny `From` rehefa manondro ny trait bounds amin'ny fiasa mahazatra.
/// Izany, karazana izay manatanteraka mivantana [`Into`] azo ampiasaina toy ny fanehoan-kevitra ihany koa.
///
/// Ny `From` tena ilaina ihany koa, rehefa manao fahadisoana fikirakirana.Rehefa misy asa fanorenana izay afaka mahomby, ny fiverenana dia karazana ankapobeny ho avy ny endriky `Result<T, E>`.
/// Ny `From` trait dia manamora ny fikirakirana ny lesoka amin'ny alàlan'ny famelana fiasa hamerina karazana hadisoana tokana izay mametaka karazana hadisoana marobe.Zahao ny fizarana "Examples" sy [the book][book] raha mila fanazavana fanampiny.
///
/// **Note: Ity trait ity dia tsy tokony hahomby **.Raha mety tsy hahomby ny fiovam-po, ampiasao [`TryFrom`].
///
/// # Generic Implementations
///
/// - `From<T> for U` midika hoe [`Into`]`<U>ho an'i T`</u>
/// - `From` dia reflexive, izay midika fa ampiharina ny `From<T> for T`
///
/// # Examples
///
/// [`String`] mampihatra `From<&str>`:
///
/// Ny fiovam-po avy amin'ny mazava ho any amin'ny String `&str` atao toy izao manaraka izao:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Raha manao fikirakirana hadisoana dia matetika ilaina ny mampihatra `From` ho an'ny karazana hadisoanao manokana.
/// Amin'ny alalan'ny karazana fahadisoana hiova finoana fototra mankany amin 'ny fanao karazana fahadisoana izay encapsulates ny fototra karazana fahadisoana, dia afaka miverina karazana fahadisoana iray tsy very vaovao momba ny mahatonga.
/// Ny mpandraharaha '?' dia mamadika ho azy ny karazana lesoka ambanin'ny tany amin'ny karazana hadisoantsika manokana amin'ny fiantsoana `Into<CliError>::into` izay omena ho azy rehefa mampihatra `From`.
/// Ny compiler avy eo infers izay fampiharana `Into` tokony hampiasaina.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Manao ny fiovam-po.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ny fiovam-po saika mandevona `self`, izay mety na mety tsy ho lafo.
///
/// Library mpanoratra matetika tsy tokony hampiharana izany mivantana trait, fa kokoa fampiharana ny [`TryFrom`] trait, izay manome manovaova kokoa sy manome mitovy `TryInto` fampiharana maimaim-poana, noho ny fampiharana ny bodofotsy tao amin'ny fitehirizam-boky Standard.
/// Raha mila fanazavana fanampiny momba izany, dia jereo ny antontan-taratasy momba ny [`Into`].
///
/// # fampiharana `TryInto`
///
/// Izany dia mizaka ny fameperana sy ny fanjohian-kevitra mitovy amin'ny fampiharana [`Into`], jereo eto raha mila antsipiriany.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Ny karazana niverina tamin'ny hetsika ny fiovam-po fahadisoana.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Manao ny fiovam-po.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Fivadihana karazana tsotra sy azo antoka izay mety tsy hahomby amin'ny fomba voafehy amin'ny toe-javatra sasany.Izany no reciprocal ny [`TryInto`].
///
/// Izany no ilaina rehefa manao ny karazana trivially fiovam-po izay mety hahomby, fa mety koa mila fikirakirana manokana.
/// Ohatra, tsy misy fomba hanovana [`i64`] ho [`i32`] amin'ny fampiasana [`From`] trait, satria ny [`i64`] dia mety misy sanda iray izay tsy azon'ny [`i32`] soloina ary very ny tahirin-kevitra.
///
/// Mety ho handaminana amin'ny truncating ny [`i64`] tany amin'ny [`i32`] (indrindra manome ny [`i64`] 's sarobidy modulo [`i32::MAX`]), na amin'ny alalan'ny [`i32::MAX`] niverina fotsiny, na amin'ny fomba hafa.
/// Ny [`From`] trait dia natao ho lavorary po, toy izany koa ny `TryFrom` trait mampahalala ny rindrambaiko, rehefa misy karazana afaka mandeha ny fiovam-po ratsy, ary mamela azy ireo manapa-kevitra ny fomba hiatrehana izany.
///
/// # Generic Implementations
///
/// - `TryFrom<T> for U` midika hoe [`AndramoInto`]`<U>ho an'ny T`</u>
/// - [`try_from`] dia reflexive, izay midika fa ny `TryFrom<T> for T` dia ampiharina ary tsy afaka tsy mahomby-ny karazana `Error` mifandraika amin'ny fiantsoana `T::try_from()` amin'ny sanda `T` dia [`Infallible`].
/// Rehefa milamina ny karazana [`!`] dia [`Infallible`] ary [`!`] dia hitovy.
///
/// `TryFrom<T>` azo ampiharina toy izao:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Araka ny voalaza, [`i32`] dia mampihatra ny `TryFrom <` [`i64`]`> ':
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Mangina mangingina `big_number`, mila mamantatra sy mitantana ny truncation aorian'ny zava-misy.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Mamerina lesoka satria `big_number` dia lehibe loatra ka tsy tafiditra amin'ny `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Miverina `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Ny karazana niverina tamin'ny hetsika ny fiovam-po fahadisoana.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Manao ny fiovam-po.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS GENERIKA
////////////////////////////////////////////////////////////////////////////////

// Rehefa miakatra&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Toy ny fampiakarana mihoatra ny &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): hanoloana ny ambony impls for&/&mut amin'ny ankapobeny kokoa ny manaraka ny iray:
// // Toy ny manandratra an'i Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Salantsalany> AsRef <U>for D {naoty as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut dia miakatra mihoatra ny &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): hanoloana ny ambony impl for &mut amin'ny ankapobeny kokoa ny manaraka ny iray:
// // AsMut dia manandratra an'i DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>ho an'ny D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Avy amin'ny hoe
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Avy (ary amin'izany no ho) dia reflexive
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Fanamarihana azo antoka:** Mbola tsy misy io impl io, fa "reserving space" izahay manampy azy ao amin'ny future.
/// Jereo [rust-lang/rust#64715][#64715] raha mila fanazavana.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): manamboatra fotopoto-pitsipika fa tsy.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// Ny TryFrom dia midika hoe TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Mety diso fiovam-pony dia semantically mitovy amin'ny hadisoana fiovam-pony amin'ny karazana fahadisoana any antany.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETAO IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// NY TSIA-ERROR ERROR TYPE
////////////////////////////////////////////////////////////////////////////////

/// Ny karazana lesoka ho an'ny lesoka izay tsy mety hitranga mihitsy.
///
/// Koa satria tsy misy izany enum Variant, dia tena ilaina io karazana raha ny marina na oviana na oviana dia afaka misy.
/// Mety ho ilaina amin'ny API iraisana izay mampiasa [`Result`] sy mamaritra ny karazana hadisoana, hanondroana fa ny valiny dia [`Ok`] foana.
///
/// Ohatra, ny [`TryFrom`] trait (fiovam-po fa miverina ny [`Result`]) manana bodofotsy fampiharana ho an'ny rehetra, ny karazana izay mifanohitra [`Into`] misy fampiharana.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Fifanarahana Future
///
/// Ity enum ity dia manana andraikitra mitovy amin'ny [the `!`“never”type][never], izay miovaova amin'ity kinova Rust ity.
/// Rehefa `!` dia voahozongozona, dia mikasa ny hanao karazana `Infallible` antsoina ho azy;
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ary farany lany ny `Infallible`.
///
/// Na izany aza misy tranga iray izay ahafahana mampiasa ny syntax `!` alohan'ny hampiorenana ny `!` ho karazana feno: amin'ny toeran'ny karazana fiverenan'ny asa iray.
/// Manokana, azo atao ny fampiharana ho an'ny karazana tondro roa:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Miaraka amin'ny `Infallible` enum dia manan-kery ity kaody ity.
/// Saingy rehefa lasa alias ho an'ny never type ny `Infallible` dia hanomboka hifanindry ny `impl` roa ary noho izany dia tsy hahazo ny lalàna mifehy ny firaisan-kinan'io fiteny trait io.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}