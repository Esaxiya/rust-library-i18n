#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` dia mamela ny mpampihatra mpanatanteraka asa hamorona [`Waker`] izay manome fitondran-tena manaitra manokana.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Izany dia ahitana ny tahirin-kevitra ary ny [virtual function pointer table (vtable)][vtable] manondro izay customizes ny fitondran-tena ny `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// A angona manondro, izay azo ampiasaina mba hitahiry jadona fanazavana araka ny takian'ny ny mpanatanteraka.
    /// Mety ho ohatra
    /// tondro iray voafafa tamina `Arc` izay mifandraika amin'ilay lahasa.
    /// Ny sandan'ity saha ity dia nanjary ho an'ny asa rehetra izay ao anatin'ny latabatra ho masontsivana voalohany.
    ///
    data: *const (),
    /// Ny latabatra fanondroana fiasa virtoaly izay manamboatra ny toetran'ity olona mifoha ity.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Mamorona `RawWaker` vaovao avy amin'ny mpanondro `data` sy `vtable`.
    ///
    /// Ny pointer `data` dia azo ampiasaina hitahirizana angona tsy ara-dalàna arak'izay takian'ny mpanatanteraka.Mety ho oh
    /// tondro iray voafafa tamina `Arc` izay mifandraika amin'ilay lahasa.
    /// Ny sandan'ity pointer ity dia hampitaina amin'ny asa rehetra izay ao anatin'ny `vtable` ho masontsivana voalohany.
    ///
    /// Ny `vtable` dia manamboatra ny toetran'ny `Waker` izay noforonina avy amin'ny `RawWaker`.
    /// Ho an'ny asa tsirairay amin'ny `Waker`, ny fiasa mifandraika amin'ny `vtable` an'ny `RawWaker` dia miantso.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tabilao mpanondro asa virtoaly (vtable) izay mamaritra ny fitondran-[`RawWaker`].
///
/// Manondro lasa rehetra ao anatin'ny vtable asa dia manondro ny `data` avy amin'ny hihodidina [`RawWaker`] zavatra.
///
/// Ny fiasa ao anatin'ity rafitra ity dia natao hantsoina fotsiny amin'ny tondro `data` amin'ny zavatra [`RawWaker`] namboarina araka ny tokony ho izy avy ao anatin'ny fampiharana [`RawWaker`].
/// Ny fiantsoana ny iray amin'ireo lahasa misy ao anatin'izany amin'ny fampiasana tondro `data` hafa dia hiteraka fihetsika tsy voafaritra.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Hantsoina ity fiasa ity rehefa voahidy ny [`RawWaker`], ohatra, rehefa lasa klona ilay [`Waker`] izay itahirizana ny [`RawWaker`].
    ///
    /// Ny fanatanterahana ny asa dia tsy maintsy hitazona izany harena rehetra izay ilaina noho izany ny ohatra fanampiny [`RawWaker`] sy ny asa mifandray amin'izany.
    /// Calling `wake` ny vokatry [`RawWaker`] dia tokony hiteraka ny wakeup ny mitovy asa izay efa awoken avy tany am-boalohany [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Hantsoina ity fiasa ity rehefa antsoina `wake` amin'ny [`Waker`].
    /// Tsy maintsy manaitra ny lahasa mifandraika amin'ity [`RawWaker`] ity izy io.
    ///
    /// Ny fampiharana an'io lahasa io dia tsy maintsy ahazoana antoka fa hamoahana izay loharano rehetra mifandraika amin'ity tranga [`RawWaker`] ity sy ny asa mifandraika amin'izany.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Hantsoina ity fiasa ity rehefa antsoina `wake_by_ref` amin'ny [`Waker`].
    /// Tsy maintsy manaitra ny lahasa mifandraika amin'ity [`RawWaker`] ity izy io.
    ///
    /// Ity fiasa ity dia mitovy amin'ny `wake`, fa tsy tokony handany ireo angon-drakitra nomena.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Antsoina ity fiasa ity rehefa nilatsaka ny [`RawWaker`].
    ///
    /// Ny fampiharana an'io lahasa io dia tsy maintsy ahazoana antoka fa hamoahana izay loharano rehetra mifandraika amin'ity tranga [`RawWaker`] ity sy ny asa mifandraika amin'izany.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Mamorona vaovao `RawWakerVTable` avy amin'ny nanome `clone`, `wake`, `wake_by_ref`, ary `drop` asany.
    ///
    /// # `clone`
    ///
    /// Hantsoina ity fiasa ity rehefa voahidy ny [`RawWaker`], ohatra, rehefa lasa klona ilay [`Waker`] izay itahirizana ny [`RawWaker`].
    ///
    /// Ny fanatanterahana ny asa dia tsy maintsy hitazona izany harena rehetra izay ilaina noho izany ny ohatra fanampiny [`RawWaker`] sy ny asa mifandray amin'izany.
    /// Calling `wake` ny vokatry [`RawWaker`] dia tokony hiteraka ny wakeup ny mitovy asa izay efa awoken avy tany am-boalohany [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Hantsoina ity fiasa ity rehefa antsoina `wake` amin'ny [`Waker`].
    /// Tsy maintsy manaitra ny lahasa mifandraika amin'ity [`RawWaker`] ity izy io.
    ///
    /// Ny fampiharana an'io lahasa io dia tsy maintsy ahazoana antoka fa hamoahana izay loharano rehetra mifandraika amin'ity tranga [`RawWaker`] ity sy ny asa mifandraika amin'izany.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Hantsoina ity fiasa ity rehefa antsoina `wake_by_ref` amin'ny [`Waker`].
    /// Tsy maintsy manaitra ny lahasa mifandraika amin'ity [`RawWaker`] ity izy io.
    ///
    /// Ity fiasa ity dia mitovy amin'ny `wake`, fa tsy tokony handany ireo angon-drakitra nomena.
    ///
    /// # `drop`
    ///
    /// Antsoina ity fiasa ity rehefa nilatsaka ny [`RawWaker`].
    ///
    /// Ny fampiharana an'io lahasa io dia tsy maintsy ahazoana antoka fa hamoahana izay loharano rehetra mifandraika amin'ity tranga [`RawWaker`] ity sy ny asa mifandraika amin'izany.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Ny `Context` iray asynchronous asa.
///
/// Amin'izao fotoana izao, `Context` dia manome ny fidirana amin'ny `&Waker` izay azo ampiasaina hamohazana ny asa ankehitriny.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Hamarino fa future-porofo manohitra ny fiovan'ny fahasamihafana amin'ny alàlan'ny fanerena ny fiainana tsy ho faty (ny vanim-potoana misy ny tohan-kevitra dia mankahala raha toa ka covariant ny androm-piainana miverina).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Mamorona vaovao avy amin'ny `&Waker` `Context`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Miverina referansa amin'ny `Waker` ho an'ny asa ankehitriny.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` dia tahony ny mifoha ny asa amin'ny mampahafantatra ny mpanatanteraka fa vonona ny ho mihazakazaka.
///
/// Ity tahony ity dia mametaka ohatra [`RawWaker`], izay mamaritra ny fitondran-tena manaitra manokana ny mpanatanteraka.
///
///
/// Fitaovana [`Clone`], [`Send`], ary [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Mifohaza ny asa mifandray amin'ny `Waker` ity.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Ny tena wakeup antso dia natolotra amin'ny alalan'ny virtoaly miasa antso ny fampiharana izay voafaritry ny mpanatanteraka.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Aza miantso ny `drop`-ho lanin'ny `wake` ny mpmata.
        crate::mem::forget(self);

        // Famonjena, azo antoka izany, satria `Waker::from_raw` no hany fomba
        // hanombohana `wake` sy `data` mitaky ny hanaiky ny mpampiasa fa voatazona ny fifanarahana `RawWaker`.
        //
        unsafe { (wake)(data) };
    }

    /// Mifohaza ilay asa mifandraika amin'ity `Waker` ity nefa tsy mihinana `Waker`.
    ///
    /// Izy io dia mitovy amin'ny `wake`, saingy mety tsy dia mahomby kely amin'ny tranga misy `Waker` tompony.
    /// Izany fomba tokony nisafidy ny miantso `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Ny tena wakeup antso dia natolotra amin'ny alalan'ny virtoaly miasa antso ny fampiharana izay voafaritry ny mpanatanteraka.
        //

        // SAFETY: jereo `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Miverina `true` raha `Waker` `Waker` ary ny anankiray toy izany koa no awoken asa.
    ///
    /// Ity asa ity dia miasa amin'ny fiezahana tsara indrindra, ary mety hiverina diso na dia hanaitra ilay asa mitovy aza ny `Waker's.
    /// Na izany aza, raha miverina `true` ity fiasa ity dia azo antoka fa hamoha ilay asa mitovy ihany ny `Waker`s.
    ///
    /// Ity fiasa ity dia ampiasaina indrindra amin'ny tanjona fanatsarana.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Mamorona `Waker` vaovao avy amin'ny [`RawWaker`].
    ///
    /// Ny fitondran-tenan'ny `Waker` tafaverina dia tsy voafaritra raha tsy voatazona ny fifanarahana voafaritra ao amin'ny rakitsoratr'i [`RawWaker`] sy [`RawWakerVTable`].
    ///
    /// Noho izany tsy azo antoka ity fomba ity.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // Famonjena, azo antoka izany, satria `Waker::from_raw` no hany fomba
            // hanombohana `clone` sy `data` mitaky ny hanaiky ny mpampiasa fa voatazona ny fifanarahana [`RawWaker`].
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // Famonjena, azo antoka izany, satria `Waker::from_raw` no hany fomba
        // mba initialize `drop` sy `data` mitaky ny mpampiasa mba fantany tsara fa fifanarahana ny `RawWaker` dia nanohana.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}