//! Ity fitaovana Module ny `Any` trait, izay ahafahan'ny mavitrika fanoratana na `'static` karazana amin'ny alalan'ny fandinihana runtime.
//!
//! `Any` ny tenany dia azo ampiasaina hahazoana `TypeId`, ary manana fiasa bebe kokoa rehefa ampiasaina ho zavatra trait.
//! Araka ny `&dyn Any` (a nindramina trait zavatra), dia manana ny `is` sy `downcast_ref` fomba, mba hitsapana raha ny voarakitra sarobidy dia nomena ny karazana, ary mba hahazo momba ny anatiny ho toy ny karazana sarobidy.
//! Amin'ny maha `&mut dyn Any` anao, misy ihany koa ny fomba `downcast_mut`, hahazoana fahazoana manova ny sanda anatiny.
//! `Box<dyn Any>` manampy ny `downcast` fomba, izay miezaka niova fo ho amin'ny `Box<T>`.
//! Jereo ny rakitra [`Box`] ho an'ny antsipiriany feno.
//!
//! Mariho fa `&dyn Any` dia voafetra amin'ny fitsapana raha toa ka ny soatoavina dia karazana simenitra voafaritra, ary tsy azo ampiasaina hanandramana raha misy karazana mampihatra trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Toro marin-tsaina sy `dyn Any`
//!
//! Ny fihetsika iray tsy tokony ho adino ao an-tsaina rehefa mampiasa `Any` ho zavatra trait, indrindra amin'ny karazany toa ny `Box<dyn Any>` na `Arc<dyn Any>`, dia ny fiantsoana `.type_id()` fotsiny amin'ny sanda dia hamokatra `TypeId`-n'ny *container* fa tsy ilay zavatra trait ao ambaniny.
//!
//! Azo sorohina izany amin'ny alàlan'ny fanovana ny tondro marani-tsaina ho `&dyn Any` fa tsy hamerina ilay zavatra `TypeId`.
//! Ohatra:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Azo inoana fa maniry an'ity ianao:
//! let actual_id = (&*boxed).type_id();
//! // ... noho ity:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Diniho ny toe-javatra iray izay te-hamoaka sanda napetraka tamina lahasa iray izahay.
//! Fantatray ny sanda ampiasainay amin'ny fampiharana ny Debug, saingy tsy fantatray ny karazany mivaingana.Tianay ny hanome fitsaboana manokana ny karazana sasany: amin'ity tranga ity, ny fanontana ny halavan'ny soatoavina String alohan'ny sandany.
//! Tsy fantatsika ny karazana simenitra ny sarobidy amin'ny manangona fotoana, ka mila mampiasa runtime fa tsy fandinihana.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger asa na inona na inona karazana ny fitaovana Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Miezaha manova ny sandam-bolantsika ho `String`.
//!     // Raha mahomby dia te hamoaka ny halavan'ny String` ary koa ny sandany.
//!     // Raha tsy izany dia karazany hafa: apetaho fotsiny tsy voaravaka.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ity asa ity dia te-hivoaka ny masontsivana alohan'ny hiara-miasa aminy.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... manaova asa hafa
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// trait rehetra
///////////////////////////////////////////////////////////////////////////////

/// trait maka tahaka ny fanoratana mavitrika.
///
/// Ny ankamaroan'ny karazana mampihatra `Any`.Na izany aza, ny karazana misy referansa tsy ``statika` dia tsy.
/// Jereo ny [module-level documentation][mod] raha mila fanazavana fanampiny.
///
/// [mod]: crate::any
// Ity trait ity dia tsy azo antoka, na dia miantehitra amin'ny antsipirian'ny asan'ny `type_id` azy irery amin'ny kaody tsy azo antoka aza isika (oh: `downcast`).Raha ny mahazatra, dia mety ho olana, fa noho ny hany impl ny `Any` dia bodofotsy fampiharana, tsy misy hafa afaka mampihatra `Any` kaody.
//
// Tsy afaka manao izany plausibly trait mampidi-doza-dia tsy mahatonga breakage, satria isika rehetra, mifehy ny implementations-fa misafidy ny tsy ho toy izany na tsy tena ilaina, ary mety hampifangaro mpampiasa momba ny fanavahana ny traits mampidi-doza sy ny fomba mampidi-doza (izany hoe, `type_id` dia mbola azo antoka ny miantso azy, saingy mety te-hanondro izany amin'ny antontan-taratasy isika).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Mahazo ny `TypeId` an'ny `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Fomba fanitarana ho an'ny zavatra trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Ataovy azo antoka fa ny vokatry ny ohatra, manatevin-daharana ny kofehy azo pirinty, ary noho izany ampiasaina amin'ny `unwrap`.
// Mety tsy ilaina intsony ny farany raha toa ka miasa amin'ny fisondrotana ny asa ny fandefasana.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Miverina `true` raha toa ka mitovy amin'ny `T` ilay karazana boaty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Mialà `TypeId` avy ny karazana asa ity dia instantiated amin'ny.
        let t = TypeId::of::<T>();

        // Raiso `TypeId` ny karazany ao amin'ny trait zavatra (`self`).
        let concrete = self.type_id();

        // Ampitahao ny `TypeId`s amin'ny fitoviana.
        t == concrete
    }

    /// Niverina sasany momba ny boxed danja raha avy karazany `T`, na `None` raha tsy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // Famonjena, homarinana avy amin'ny teny fotsiny isika raha nanondro ny marina karazana, ary afaka miantehitra
            // izay manamarina ny fiarovana ny fahatsiarovana satria nampihatra izay rehetra misy karazana izahay;tsy misy impla hafa mety hisy satria hifanohitra amin'ny implantsika izy ireo.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Miverina fanondroana miovaova amin'ilay sanda boaty raha karazana `T`, na `None` raha tsy izany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // Famonjena, homarinana avy amin'ny teny fotsiny isika raha nanondro ny marina karazana, ary afaka miantehitra
            // izay manamarina ny fiarovana ny fahatsiarovana satria nampihatra izay rehetra misy karazana izahay;tsy misy impla hafa mety hisy satria hifanohitra amin'ny implantsika izy ireo.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Mandrosoa amin'ny fomba voafaritra amin'ny karazana `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Mandrosoa amin'ny fomba voafaritra amin'ny karazana `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Mandrosoa amin'ny fomba voafaritra amin'ny karazana `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Mandrosoa amin'ny fomba voafaritra amin'ny karazana `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Mandrosoa amin'ny fomba voafaritra amin'ny karazana `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Mandrosoa amin'ny fomba voafaritra amin'ny karazana `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID sy ny fombany
///////////////////////////////////////////////////////////////////////////////

/// Ny `TypeId` dia maneho mpamantatra tokana eran-tany ho an'ny karazany iray.
///
/// `TypeId` tsirairay dia manjavozavo zavatra izay tsy mamela maso ny inona no ao anatiny fa tsy mamela ny asa fototra toy ny Fanamboarana, fampitahana, fanontam-pirinty, ary ny fampisehoana.
///
///
/// Ny `TypeId` dia tsy misy afa-tsy amin'ny karazana manondro `'static`, fa io fetra io dia azo esorina ao amin'ny future.
///
/// Raha mampihatra `Hash`, `PartialOrd`, ary `Ord` ny `TypeId`, dia tsara ny manamarika fa ny hashes sy ny baiko dia miovaova eo anelanelan'ny famoahana Rust.
/// Mitandrema amin'ny fianteherana amin'izy ireo ao anaty kaody!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Miverina ny `TypeId` 'ny karazana asa levitra ity no instantiated amin'ny.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Mamerina ny anaran'ny karazana iray ho toy ny tapa-tady.
///
/// # Note
///
/// Natao hampiasa diagnostika izany.
/// Ny tena votoatin'ny sy ny rafitry ny rohitra niverina tsy mazava, hafa noho ny maha-tsara indrindra-ezaka famaritana ny karazana.
/// Ohatra, eo amin'ireo tadiny mety hiverenan'i `type_name::<Option<String>>()` dia `"Option<String>"` sy `"std::option::Option<std::string::String>"`.
///
///
/// Ny kofehy naverina dia tsy tokony hoheverina ho mpamantatra tokana ny karazany iray satria ny karazana maro dia mety hanao sarintany amin'ny anaran'ny karazana iray ihany.
/// Toy izany koa, tsy misy antoka fa ampahany karazana no hita ao amin'ny niverina tady; fa ohatra, specifiers androm-piainany amin'izao fotoana izao dia tsy tafiditra.
/// Ho fanampin'izany, ny vokatra dia mety hiova eo amin'ny kinova an'ny mpandrafitra.
///
/// Ny fampiharana ankehitriny dia mampiasa fotodrafitrasa mitovy amin'ny diagnostika mpanangona sy debuginfo, saingy tsy azo antoka izany.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Mamerina ny anaran'ny karazana soatoavina tondro ho tapa-tady.
/// Izany dia mitovy amin'ny `type_name::<T>()`, fa azo ampiasaina izay ny karazana iray dia tsy mora miova misy.
///
/// # Note
///
/// Izany dia natao ho fampiasana fizahana aretina.Ny atiny marina sy ny endrik'ilay tady dia tsy voatondro, ankoatry ny famaritana ny ezaka tsara indrindra momba ilay karazany.
/// Ohatra, `type_name_of_val::<Option<String>>(None)` dia afaka mamerina `"Option<String>"` na `"std::option::Option<std::string::String>"`, fa tsy `"foobar"`.
///
/// Ho fanampin'izany, ny vokatra dia mety hiova eo amin'ny kinova an'ny mpandrafitra.
///
/// Ity asa ity dia tsy mamaha ireo zavatra trait, midika izany fa mety hiverina `"dyn Debug"` ny `type_name_of_val(&7u32 as &dyn Debug)`, fa tsy `"u32"`.
///
/// Ny anaran'ny karazana dia tsy tokony heverina ho famantarana tokana karazana;
/// karazany maro no mety mizara anarana mitovy karazana.
///
/// Ny fampiharana ankehitriny dia mampiasa fotodrafitrasa mitovy amin'ny diagnostika mpanangona sy debuginfo, saingy tsy azo antoka izany.
///
/// # Examples
///
/// Diam ny toerana misy anao sy ny float integer karazana.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}