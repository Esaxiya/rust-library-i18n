//! Ny `Clone` trait ho an'ny karazana tsy azo 'adika an-kolaka'.
//!
//! Ao amin'ny Rust, karazana tsotra sasany dia "implicitly copyable" ary rehefa omenao azy ireo na ampitao ho toy ny adihevitra dia hahazo kopia ny mpandray, avelany eo amin'ny toerany ny sanda am-boalohany.
//! Ireo karazana ireo dia tsy mitaky fanokanana handikana sy tsy hananana famaranana (izany hoe tsy misy boaty tompony na hampiharana [`Drop`]), ka heverin'ny mpamorona ho mora sy azo antoka ny maka tahaka azy ireo.
//!
//! Ho an'ny karazana hafa, ny kopia dia tsy maintsy atao mazava, amin'ny alàlan'ny fivoriambe amin'ny fampiharana ny [`Clone`] trait ary miantso ny fomba [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Fototra fampiasana example:
//!
//! ```
//! let s = String::new(); // Ny karazana tadiny dia manamboatra an'i Clone
//! let copy = s.clone(); // mba hahafahantsika mitahiry izany
//! ```
//!
//! Mba hampiharana mora ny Clone trait, azonao atao ihany koa ny mampiasa `#[derive(Clone)]`.Ohatra:
//!
//! ```
//! #[derive(Clone)] // dia hametraka ny Clone trait an'i Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // Ary ankehitriny isika dia afaka Clone izany!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Ny mahazatra trait ny fahaizana mivantana haka tahaka ny zavatra.
///
/// Ny fahasamihafana amin'ny [`Copy`] ao anatin'io [`Copy`] io dia implicité ary lafo vidy tokoa, raha `Clone` kosa dia mibaribary foana ary mety lafo na tsia.
/// Mba hampihatra ireo toetra, Rust tsy mamela anao reimplement [`Copy`], fa mety reimplement `Clone` sy mihazakazaka jadona kaody.
///
/// Koa satria `Clone` kokoa noho [`Copy`] ankapobeny, dia afaka avy hatrany manao na inona na inona ho `Clone` [`Copy`] ihany koa.
///
/// ## Derivable
///
/// Zavatra trait dia azo ampiasaina amin'ny `#[derive]` raha ny `Clone` saha rehetra.Ny fampiharana `derive`d an'ny [`Clone`] dia miantso [`clone`] isaky ny saha.
///
/// [`clone`]: Clone::clone
///
/// Fa ny levitra struct, `#[derive]` manatanteraka `Clone` fepetra amin'ny fampidirana namatotra `Clone` amin'ny levitra masontsivana.
///
/// ```
/// // `derive` mampihatra Clone ho an'ny famakiana<T>rehefa T dia Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ahoana no fomba ampiharako ny `Clone`?
///
/// Ireo karazana [`Copy`] dia tokony hanana fampiharana `Clone` tsy misy dikany.More fomba ofisialy:
/// raha `T: Copy`, `x: T`, ary `y: &T`, dia `let x = y.clone();` dia mitovy amin'ny `let x = *y;`.
/// Ny fampiharana an-tanana dia tokony hitandrina mba hitazona io invariant io;na izany aza, ny kaody tsy azo antoka dia tsy tokony hiankina amin'izany mba hiantohana ny fiarovana ny fahatsiarovana.
///
/// Ohatra iray dia levitra struct mitana manondro asa.Amin'ity tranga ity, ny fametrahana ny `Clone` tsy afaka ny ho: derive`d, fa azo ampiharina araka ny:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Mpanatanteraka fanampiny
///
/// Ho fanampin'ny [implementors listed below][impls], ireto karazana manaraka ireto dia mampihatra `Clone` ihany koa:
///
/// * Karazan-tsarimihetsika (ohatra, ireo karazana voafaritra voafaritra isaky ny asany)
/// * Manondro asa karazana (ohatra, `fn() -> i32`)
/// * Array karazana, habe rehetra, raha toa ilay zavatra ihany koa ny karazana manatanteraka `Clone` (ohatra, `[i32; 123456]`)
/// * Karazana Tuple, raha ampiasain'ny singa tsirairay `Clone` (oh: `()`, `(i32, bool)`)
/// * Fanakatonana karazana, raha tsy nahafaka danja avy ny tontolo iainana, na raha toa izany babo rehetra soatoavina `Clone` mampihatra ny tenany.
///   Mariho fa hiovaova nalain'ny nizara boky manatanteraka mandrakariva `Clone` (na dia tsy manao ny referent), raha hiovaova voasambotra ny boky mutable tsy manatanteraka `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Mamerina kopian'ny sanda.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str mampihatra Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Manatanteraka handika-fanendrena avy any `source`.
    ///
    /// `a.clone_from(&b)` dia mitovy amin'ny `a = b.clone()` amin'ny fampiasa, saingy azo ovaina mba hampiasa indray ny loharanon'ny `a` hisorohana ny fizarana tsy ilaina.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Misintona macro niteraka ny impl ny trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): structs ireo fotsiny no ampiasaina amin'ny#[misintona] ny filazana fa singa iray isan-karazany na fitaovana Clone Copy.
//
//
// Ireo firafitra ireo dia tsy tokony hiseho amin'ny kaody mpampiasa mihitsy.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Fampiharana `Clone` ho an'ny karazana primitive.
///
/// Ny fampiharana izay tsy azo faritana ao amin'ny Rust dia ampiharina amin'ny `traits::SelectionContext::copy_clone_conditions()` amin'ny `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Azo zahana ny clon referansa zaraina, fa ny références azo soloina *tsy afaka*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Azo zahana ny clon referansa zaraina, fa ny références azo soloina *tsy afaka*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}