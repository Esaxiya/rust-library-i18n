//! Compiler intrinsika.
//!
//! Ny famaritana mifanaraka any `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ny fampiharana izay mifanaraka aminy dia ao amin'ny `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: fanovana ny constness ny intrinsics dia tokony hodinihina miaraka amin'ny teny ekipa.
//! Tafiditra ao anatin'izany ny fanovana ny fahamarinan-toerana misy ny Constity.
//!
//! Mba hanao anaty azo ampiasaina amin'ny manangona andro, iray ilaina ny mandika ny fampiharana avy <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ho `compiler/rustc_mir/src/interpret/intrinsics.rs` sy hanampy ny `#[rustc_const_unstable(feature = "foo", issue = "01234")]` amin'ny anaty.
//!
//!
//! Raha misy anaty heverina fa azo ampiasaina avy amin'ny `const fn` tamin'ny `rustc_const_stable` toetra, ny toetra ny anaty tsy maintsy ho `rustc_const_stable`, koa.
//! Fiovana toy izany dia tsy tokony hatao tsy misy T-Lang fifampidinihana, satria bakes ny endri-javatra any an-fiteny izay tsy azo replicated ao amin'ny fehezan-dalàna tsy misy compiler mpampiasa fanohanana.
//!
//! # Volatiles
//!
//! Ireo intrinsika miovaova dia manome ny asa natao hiasa amin'ny fahatsiarovana I/O, izay azo antoka fa tsy ho voahitsy amin'ny mpamorona amin'ny intrinsika hafa miovaova hafa.Jereo ny tahirin-kevitra ao amin'ny [[volatile]] LLVM.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Ny atomika intrinsics manome atomika mahazatra fandidiana eo amin'ny milina teny, amin'ny fitadidiana orderings maro azo atao.Manaraka semantika mitovy amin'ny C++ 11 izy ireo.Zahao ny antontan-taratasy LLVM ao amin'ny [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Fanavaozana haingana ny famandrihana fahatsiarovana:
//!
//! * Mahazoa, sakana ahazoana hidin-trano.Tatỳ aoriana mamaky ary manoratra hitranga taorian'ny sakana.
//! * Fanafaka, sakana amin'ny famoahana hidin-trano.Mialoha ny sakana ny famakiana sy ny fanoratana mialoha.
//! * Sequentially miovaova, sequentially miovaova asa azo antoka fa hitranga mba.Ity no maody mahazatra amin'ny fiasa amin'ny karazana atomika ary mitovy amin'ny X0 `volatile` an'ny Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ireo fanafarana ireo dia ampiasaina hanamorana ny rohy intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Famonjena, jereo `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ireo mandray manta intrinsics sahaza satria mutate aliased fahatsiarovana, izay tsy manan-kery ho an'ny na `&` na `&mut`.
    //

    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] ho na ny `success` sy `failure` masontsivana.
    ///
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::Acquire`] ho na ny `success` sy `failure` masontsivana.
    ///
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `success` sy [`Ordering::Acquire`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] ho na ny `success` sy `failure` masontsivana.
    ///
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `success` sy [`Ordering::Acquire`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `compare_exchange_weak` amin'ny alàlan'ny fandefasana [`Ordering::SeqCst`] ho an'ireo masontsivana `success` sy `failure`.
    ///
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `compare_exchange_weak` amin'ny alàlan'ny fandefasana [`Ordering::Acquire`] ho an'ireo masontsivana `success` sy `failure`.
    ///
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange_weak` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange_weak` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `success` sy [`Ordering::Acquire`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange_weak` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] ho na ny `success` sy `failure` masontsivana.
    ///
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange_weak` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange_weak` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `success` sy [`Ordering::Acquire`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange_weak` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Fivarotana ny zava-dehibe raha ny amin'izao fotoana izao dia mitovy vidy tahaka ny `old` sarobidy.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `compare_exchange_weak` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `success` sy [`Ordering::Relaxed`] toy ny `failure` masontsivana.
    /// Ohatra, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Enta-mavesatra ny amin'izao fotoana izao ilaina ny manondro.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `load` amin'ny alàlan'ny fandefasana [`Ordering::SeqCst`] ho `order`.
    /// Ohatra, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Enta-mavesatra ny amin'izao fotoana izao ilaina ny manondro.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `load` amin'ny alàlan'ny fandefasana [`Ordering::Acquire`] ho `order`.
    /// Ohatra, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Enta-mavesatra ny amin'izao fotoana izao ilaina ny manondro.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `load` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Mitahiry ny sanda amin'ny toerana fahatsiarovana voatondro.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `store` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Mitahiry ny sanda amin'ny toerana fahatsiarovana voatondro.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `store` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Mitahiry ny sanda amin'ny toerana fahatsiarovana voatondro.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `store` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Fivarotana zava-dehibe eo amin'ny toerana voatondro fitadidiana, niverina ny vidiny taloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `swap` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fivarotana zava-dehibe eo amin'ny toerana voatondro fitadidiana, niverina ny vidiny taloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `swap` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fivarotana zava-dehibe eo amin'ny toerana voatondro fitadidiana, niverina ny vidiny taloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `swap` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fivarotana zava-dehibe eo amin'ny toerana voatondro fitadidiana, niverina ny vidiny taloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `swap` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Fivarotana zava-dehibe eo amin'ny toerana voatondro fitadidiana, niverina ny vidiny taloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `swap` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Manampy ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_add` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Manampy ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_add` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Manampy ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_add` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Manampy ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `fetch_add` amin'ny alàlan'ny fandefasana [`Ordering::AcqRel`] ho `order`.
    /// Ohatra, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Manampy ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_add` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Analana amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_sub` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Analana amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_sub` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Analana amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_sub` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Analana amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_sub` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Analana amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `fetch_sub` amin'ny alàlan'ny fandefasana [`Ordering::Relaxed`] ho `order`.
    /// Ohatra, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise sy ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `fetch_and` amin'ny alàlan'ny fandefasana [`Ordering::SeqCst`] ho `order`.
    /// Ohatra, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sy ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_and` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sy ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_and` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sy ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_and` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sy ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_and` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`AtomicBool`] karazana alalan'ny fomba `fetch_nand` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`AtomicBool`] karazana alalan'ny fomba `fetch_nand` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`AtomicBool`] karazana alalan'ny fomba `fetch_nand` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`AtomicBool`] karazana alalan'ny fomba `fetch_nand` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand amin'ny vidiny amin'izao fotoana izao, niverina vidiny teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`AtomicBool`] karazana alalan'ny fomba `fetch_nand` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise na amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_or` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_or` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_or` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_or` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise na amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `fetch_or` amin'ny alàlan'ny fandefasana [`Ordering::Relaxed`] ho `order`.
    /// Ohatra, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor miaraka amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_xor` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor miaraka amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_xor` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor miaraka amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `fetch_xor` amin'ny alàlan'ny fandefasana [`Ordering::Release`] ho `order`.
    /// Ohatra, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor miaraka amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny karazany [`atomic`] amin'ny alàlan'ny fomba `fetch_xor` amin'ny alàlan'ny fandefasana [`Ordering::AcqRel`] ho `order`.
    /// Ohatra, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor miaraka amin'ny sanda ankehitriny, mamerina ny sanda teo aloha.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] karazana alalan'ny fomba `fetch_xor` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ambony indrindra amin'ny vidiny amin'izao fotoana izao mampiasa fampitahana nanao sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ambony indrindra amin'ny vidiny amin'izao fotoana izao mampiasa fampitahana nanao sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ambony indrindra amin'ny vidiny amin'izao fotoana izao mampiasa fampitahana nanao sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ambony indrindra amin'ny vidiny amin'izao fotoana izao mampiasa fampitahana nanao sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ambony indrindra amin'ny vidiny amin'izao fotoana izao.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum ny amin'izao fotoana izao mampiasa sonia sarobidy fampitahana.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ny amin'izao fotoana izao mampiasa sonia sarobidy fampitahana.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ny amin'izao fotoana izao mampiasa sonia sarobidy fampitahana.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia azo alaina amin'ny [`atomic`] karazana integer nosoniavina tamin'ny alàlan'ny fomba `fetch_min` amin'ny alàlan'ny fandefasana [`Ordering::Release`] ho `order`.
    /// Ohatra, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ny amin'izao fotoana izao mampiasa sonia sarobidy fampitahana.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ny amin'izao fotoana izao mampiasa sonia sarobidy fampitahana.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] nanao sonia integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum miaraka amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum miaraka amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum miaraka amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum miaraka amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia azo alaina amin'ny [`atomic`] karazana integer tsy misy sonia amin'ny alàlan'ny fomba `fetch_min` amin'ny alàlan'ny fandefasana [`Ordering::AcqRel`] ho `order`.
    /// Ohatra, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum miaraka amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_min` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::Acquire`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum amin'ny sanda amin'izao fotoana izao amin'ny fampiasana fampitahana tsy misy sonia.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic`] unsigned integer karazana amin'ny alalan'ny fomba `fetch_max` amin'ny alalan'ny mandalo [`Ordering::Relaxed`] toy ny `order`.
    /// Ohatra, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ny intrinsika `prefetch` dia fambara ho an'ny mpamorona kaody hametahana torolàlana mialoha raha tohanana;raha tsy izany dia tsy manan-kery izany.
    /// Ny prefetches dia tsy misy fiatraikany amin'ny fitondran-tena amin'ny programa fa afaka manova ny mampiavaka azy.
    ///
    /// Ny tohan-kevitra `locality` dia tsy maintsy ho foana integer ara-nofo, ary dia Ort specifier miainga amin'ny (0), tsy nisy asezare, ho (3), tena an-toerana ao amin'ny cache mandrakariva.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Ny intrinsika `prefetch` dia fambara ho an'ny mpamorona kaody hametahana torolàlana mialoha raha tohanana;raha tsy izany dia tsy manan-kery izany.
    /// Ny prefetches dia tsy misy fiatraikany amin'ny fitondran-tena amin'ny programa fa afaka manova ny mampiavaka azy.
    ///
    /// Ny tohan-kevitra `locality` dia tsy maintsy ho foana integer ara-nofo, ary dia Ort specifier miainga amin'ny (0), tsy nisy asezare, ho (3), tena an-toerana ao amin'ny cache mandrakariva.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Ny intrinsika `prefetch` dia fambara ho an'ny mpamorona kaody hametahana torolàlana mialoha raha tohanana;raha tsy izany dia tsy manan-kery izany.
    /// Ny prefetches dia tsy misy fiatraikany amin'ny fitondran-tena amin'ny programa fa afaka manova ny mampiavaka azy.
    ///
    /// Ny tohan-kevitra `locality` dia tsy maintsy ho foana integer ara-nofo, ary dia Ort specifier miainga amin'ny (0), tsy nisy asezare, ho (3), tena an-toerana ao amin'ny cache mandrakariva.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Ny intrinsika `prefetch` dia fambara ho an'ny mpamorona kaody hametahana torolàlana mialoha raha tohanana;raha tsy izany dia tsy manan-kery izany.
    /// Ny prefetches dia tsy misy fiatraikany amin'ny fitondran-tena amin'ny programa fa afaka manova ny mampiavaka azy.
    ///
    /// Ny tohan-kevitra `locality` dia tsy maintsy ho foana integer ara-nofo, ary dia Ort specifier miainga amin'ny (0), tsy nisy asezare, ho (3), tena an-toerana ao amin'ny cache mandrakariva.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Fefy atomika.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic::fence`] amin'ny alalan'ny mandalo [`Ordering::SeqCst`] toy ny `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Fefy atomika.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia azo jerena ao amin'ny [`atomic::fence`] amin'ny alàlan'ny fandalinana [`Ordering::Acquire`] ho `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Fefy atomika.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia azo jerena ao amin'ny [`atomic::fence`] amin'ny alàlan'ny fandalinana [`Ordering::Release`] ho `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Fefy atomika.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic::fence`] amin'ny alalan'ny mandalo [`Ordering::AcqRel`] toy ny `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// A compiler-fitadidiana ihany no sakana.
    ///
    /// Memory accesses tsy ho reordered manerana izao sakana amin'ny compiler, nefa tsy misy toromarika ho avoakan'ny ho azy.
    /// Izany no mety ho hetsika eo amin'ny kofehy mitovy izay mety ho preempted, toy ny tsato-kazo famantarana, rehefa hiresaka amin'ny entany.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia azo jerena ao amin'ny [`atomic::compiler_fence`] amin'ny alàlan'ny fandalinana [`Ordering::SeqCst`] ho `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// A compiler-fitadidiana ihany no sakana.
    ///
    /// Memory accesses tsy ho reordered manerana izao sakana amin'ny compiler, nefa tsy misy toromarika ho avoakan'ny ho azy.
    /// Izany no mety ho hetsika eo amin'ny kofehy mitovy izay mety ho preempted, toy ny tsato-kazo famantarana, rehefa hiresaka amin'ny entany.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia azo jerena ao amin'ny [`atomic::compiler_fence`] amin'ny alàlan'ny fandalinana [`Ordering::Acquire`] ho `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// A compiler-fitadidiana ihany no sakana.
    ///
    /// Memory accesses tsy ho reordered manerana izao sakana amin'ny compiler, nefa tsy misy toromarika ho avoakan'ny ho azy.
    /// Izany no mety ho hetsika eo amin'ny kofehy mitovy izay mety ho preempted, toy ny tsato-kazo famantarana, rehefa hiresaka amin'ny entany.
    ///
    /// Ny dikan-voahozongozona izany anaty tsy ampy amin'ny [`atomic::compiler_fence`] amin'ny alalan'ny mandalo [`Ordering::Release`] toy ny `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// A compiler-fitadidiana ihany no sakana.
    ///
    /// Memory accesses tsy ho reordered manerana izao sakana amin'ny compiler, nefa tsy misy toromarika ho avoakan'ny ho azy.
    /// Izany no mety ho hetsika eo amin'ny kofehy mitovy izay mety ho preempted, toy ny tsato-kazo famantarana, rehefa hiresaka amin'ny entany.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia azo jerena ao amin'ny [`atomic::compiler_fence`] amin'ny alàlan'ny fandalinana [`Ordering::AcqRel`] ho `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic anaty izay notsoahina ny dikany avy amin'ny toetra tia ny asa.
    ///
    /// Ohatra, dataflow fampiasana atao ny mampiditra izany fanizingizinana voasakantsakan'ny mba `rustc_peek(potentially_uninitialized)` dia tena avo roa heny-maso fa dataflow compute tokoa fa ny uninitialized amin'izay fotoana izay dia eo amin'ny fanaraha-maso ny mikoriana.
    ///
    ///
    /// Io anaty tsy tokony ampiasaina ivelan'ny compiler.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Manala ny fanatanterahana ny fizotrany.
    ///
    /// A kokoa ny mpampiasa-namana sy ny dikan-marin-toerana ity hetsika dia [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Mampahafantatra ny optimizer fa tsy azo tratrarina ity teboka ao anaty kaody ity, ahafahana manatsara bebe kokoa.
    ///
    /// NB, tena tsy mitovy amin'ny makro `unreachable!()` io: tsy toy ny makro, izay panics rehefa novonoina dia *fitondran-tena tsy voafaritra* hahatratrarana kaody voamarika amin'ity fiasa ity.
    ///
    ///
    /// Ny dikan-voahozongozona izany no [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) anaty.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Mampahalala ny optimizer fa ny toe-javatra dia marina foana.
    /// Raha diso ny fepetra dia tsy voafaritra ny fihetsika.
    ///
    /// Tsy misy fehezan-dalàna noho izany dia niteraka anaty, fa ny optimizer dia hiezaka ny hiaro azy (sy ny toe-javatra) eo amin'ny hadilanana, izay mety hanelingelina ny manodidina Optimization fehezan-dalàna sy hampihenana ny fampisehoana.
    /// Tsy tokony hampiasaina izy io raha mety ho hitan'ny mpanentana samirery ilay invariant, na raha tsy mamela fanatsarana lehibe io.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Soso-kevitra amin'ny mpanangona fa ny toetoetran'ny branch dia mety ho marina.
    /// Mamerina ny sanda nampitaina taminy.
    ///
    /// Ny fampiasana hafa ankoatry ny fanambarana `if` dia mety tsy hisy vokany.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Hamantatra izany ny compiler fa branch fepetra dia mety ho diso.
    /// Mamerina ny sanda nampitaina taminy.
    ///
    /// Ny fampiasana hafa ankoatry ny fanambarana `if` dia mety tsy hisy vokany.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Manome ny breakpoint tonta, fa debugger maso iray.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn breakpoint();

    /// Ny haben'ny karazana amin'ny bytes.
    ///
    /// More manokana, dia izao no offset amin'ny oktety eo nifandimby zavatra mitovy karazana, ao anatin'izany ny fampifanarahana padding.
    ///
    ///
    /// Ny dikan-voahozongozona izany no [`core::mem::size_of`](crate::mem::size_of) anaty.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ny fampifanarahana farafaharatsiny karazana.
    ///
    /// Ny dikan-voahozongozona izany no [`core::mem::align_of`](crate::mem::align_of) anaty.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Ny fampifanarahana tian'ny karazana iray.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ny haben'ny sanda voatondro amin'ny bytes.
    ///
    /// Ny dikan-voahozongozona izany no [`mem::size_of_val`] anaty.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ny fampifanarahana takiana amin'ny sanda voatondro.
    ///
    /// Ny dikan-voahozongozona izany no [`core::mem::align_of_val`](crate::mem::align_of_val) anaty.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Nahazo voasakantsakan'ny kofehy silaka misy ny anaran 'ny karazana.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Mahazo ny Solon'anarana izay tsy manam-paharoa manerantany ny lasa mihamatanjaka ny karazana.
    /// Ity fiasa ity dia hamerina ny sanda mitovy amin'ny karazana na inona na inona crate izay iantsoana azy.
    ///
    ///
    /// Ny dikan-voahozongozona izany no [`core::any::TypeId::of`](crate::any::TypeId::of) anaty.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Ny mpiambina ho an'ny asa mampidi-doza, izay tsy hovonoina mandrakizay raha `T` dia antany:
    /// Izany dia na panic fitohy, na manao na inona na inona.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Ny mpiambina ho an'ny asa mampidi-doza, izay tsy hovonoina mandrakizay raha tsy mamela `T` aotra-initialization: fitohy izany dia na panic, na manao na inona na inona.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn assert_zero_valid<T>();

    /// Ny mpiambina ho an'ny asa mampidi-doza, izay tsy hovonoina mandrakizay raha tsy mety somary `T` manana fomba: fitohy izany dia na panic, na manao na inona na inona.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn assert_uninit_valid<T>();

    /// Mahazo andinin-tsoratra momba ny static `Location` izay manondro izay niantsoana azy.
    ///
    /// Diniho fa tsy mampiasa [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Mamindra sanda tsy mihoatra ny sakany raha tsy misy lakaoly mitete.
    ///
    /// Ity misy fotsiny for [`mem::forget_unsized`];`forget` ara-dalàna fa tsy mampiasa `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets ny potika ny sandan'ny iray karazana toy ny karazana hafa.
    ///
    /// Samy tsy maintsy manana karazana mitovy habe.
    /// Na ny tena izy, na ny vokany, dia mety ho [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` dia semantically mitovy ny bitwise hetsika iray any amin'ny hafa karazana.Izy io dia mandika ny sombintsombiny avy amin'ny sandan'ny loharano ho lasa sanda fitodiana, avy eo manadino ny tany am-boalohany.
    /// Tena mitovy amin'ny C ny `memcpy` ambanin'ny Hood, tahaka `transmute_copy`.
    ///
    /// Satria `transmute` dia by-danja fandidiana, fampifanarahana ny *transmuted soatoavina ireo* Tsy mampanahy.
    /// Toy ny hafa ny asa, efa miantoka ny compiler `T` sy `U` na dia araka ny tokony ho mifanaraka.
    /// Na izany aza, rehefa transmuting soatoavina izay teboka *any an-kafa*(toy ny sahaza, andinin-tsoratra masina, boaty ...), ny mpiantso tsy maintsy hahazoana antoka tsara fampifanarahana ny fefy-ny soatoavina.
    ///
    /// `transmute` dia mampino ** ** azo antoka.Misy fomba maro be mahatonga ny [undefined behavior][ub] amin'ity fiasa ity.`transmute` no tokony ho tanteraka ala nenina farany.
    ///
    /// Ny [nomicon](../../nomicon/transmutes.html) dia misy antontan-taratasy fanampiny.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Misy zavatra vitsivitsy izay tena mahasoa `transmute` for.
    ///
    /// Manova ny tondro isa ho mpanondro asa.Izany no *tsy* portable ny milina izay sahaza sy ny angon-drakitra asa sahaza manana habe samihafa.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ny fanolorana ny androm-piainany, na invariant shortening ny androm-piainany.Izany no nandroso, tena azo antoka Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Aza kivy: fampiasana `transmute` maro no azo tratrarina amin'ny fomba hafa.
    /// Ireto ambany ireto ny fampiharana ny `transmute` mahazatra izay azo soloina amin'ny constructs azo antoka kokoa.
    ///
    /// Nitodika manta bytes(`&[u8]`) ho `u32`, `f64`, etc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // fampiasana `u32::from_ne_bytes` fa tsy
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // na mampiasa `u32::from_le_bytes` na `u32::from_be_bytes` mba mamaritra ny endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Mamadika pointer ho `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Mampiasà mpilalao `as` fa tsy
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Mamadika ny `*mut T` ho any an-`&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Mampiasà reborrow fa tsy
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Mamadika `&mut T` ho `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ankehitriny, atambatra `as` sy reborrowing Mariho ny chaining ny `as` `as` dia tsy: transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Mamadika ny `&str` ho any an-`&[u8]`:
    ///
    /// ```
    /// // Tsy izany no fomba tsara hanaovana izany.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Azonao ampiasaina `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Na, ampiasao tady byte fotsiny, raha voafehinao ara-bakiteny ilay kofehy
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Mamadika `Vec<&T>` ho `Vec<Option<&T>>`.
    ///
    /// Mba transmute ny anatiny karazana ny votoatin'ny ny fitoeran-javatra, dia tsy maintsy ho azo antoka mba tsy mandika ny fitoeran-javatra misy ny invariants.
    /// Fa `Vec`, izany dia midika hoe samy *ny habe sy ny fampifanarahana* ny anatiny tsy maintsy mitovy karazana.
    /// Kaontenera hafa mety miantehitra amin'ny haben'ny ny karazana, fampifanarahana, na dia ny `TypeId`, izay transmuting tranga tsy ho azo atao mihitsy kanefa tsy hoe manimba ny fitoeran-javatra invariants.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // Clone ny vector ampiasaina araka ny ho azy ireo taty aoriana
    /// let v_clone = v_orig.clone();
    ///
    /// // Mampiasa transmute: miankina amin'ny layout data tsy voafaritra momba ny `Vec`, izay hevitra ratsy ary mety hiteraka fitondran-tena tsy voafaritra.
    /////
    /// // Na izany aza, dia no-dika mitovy.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Izany no soso-kevitra, azo antoka izany.
    /// // Izany no handika ny vector manontolo, anefa, ho any amin'ny fihaingoana vaovao.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ity no fomba tsy misy kopia, tsy azo antoka an'ny "transmuting" a `Vec`, raha tsy miantehitra amin'ny firafitry ny angona.
    /// // Fa tsy ara-bakiteny niantso `transmute`, dia manao ny manondro bato, fa eo amin'ny lafiny hiova finoana tany am-boalohany ho any anaty karazana (`&i32`) (`Option<&i32>`) iray vaovao, izany dia manana ny rehetra ihany ny fampitandremana aorina.
    /////
    /// // Ankoatra ny fanazavana nanome ambony, koa dia nanontany ny [`from_raw_parts`] tahirin-kevitra.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Ampivoary izany rehefa miorina tsara ny vector_into_raw_parts.
    ///     // Ataovy azo antoka vector tany am-boalohany dia tsy nandatsaka.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Fampiharana `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Misy fomba maro hanaovana an'io, ary misy olana maro amin'ny fomba (transmute) manaraka.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // voalohany: tsy azo antoka ny «transmute»;taratasim-bola rehetra izany dia ny hoe T sy ny
    ///         // U dia mitovy habe aminy.
    ///         // Faharoa, eto, dia misy andinin-tsoratra masina roa azo ovaina manondro fitadidiana mitovy.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Izany dia manala ireo olana amin'ny fiarovana ny karazana;`&mut *` dia* + anao ihany ny `&mut T` avy amin'ny `&mut T` na `*mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // na eo aza izany dia mbola manana andinin-tsoratra roa miovaova ianao manondro ilay fitadidiana mitovy.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Toy izao no anaovan'ny tranomboky mahazatra azy.
    /// // Izany no fomba tsara indrindra, raha toa ka mila ny hanao zavatra toy izany
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Izany izao no andinin-tsoratra masina telo mutable nanondro miaraka amin'izay koa fahatsiarovana.`slice`, ny rvalue ret.0, ary ny rvalue ret.1.
    ///         // `slice` dia tsy ampiasaina araka `let ptr = ...`, ary mba misy afaka hitondra izany ho toy "dead", ka noho izany, ianao ihany no tena mutable roa slices.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Na dia mampiorina ny intrinsika aza ity dia manana kaody manokana ao amin'ny const fn izahay
    // taratasim-bola izay manakana ny fampiasana ao anatin'ny `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Miverina `true` raha ny tena karazana nomena ho `T` mitaky lakaoly indray mitete;mamerina `false` raha toa ny tena karazana omena ho `T` mampihatra `Copy`.
    ///
    ///
    /// Raha ny tena na dia mitaky karazana mitete lakaoly na fitaovana `Copy`, dia ny fiverenan'ny asa sarobidy izany dia voafaritra.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Kajy ny offset avy amin'ny manondro.
    ///
    /// Izany dia ampiharina ho toy ny anaty mba tsy manova fo ny, ary avy integer, satria ny fiovam-po dia manary aliasing vaovao.
    ///
    /// # Safety
    ///
    /// Na ny fanombohana sy ny vokatr'izany dia tsy maintsy manondro na eo fetra na byte lasa ny faran'ny zavatra iray natokana.
    /// Raha manondro na avy amin'ny fetra na rafitrisa tondraka mitranga dia misy koa fampiasana ny niverina sarobidy hiteraka fitondran-tena tsy voafaritra.
    ///
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Kajy ny offset avy amin'ny manondro, mety ho wrapping.
    ///
    /// Izany dia ampiharina ho toy ny anaty mba tsy manova fo ny, ary avy integer, satria ny fiovam-po dia mampihena optimizations sasany.
    ///
    /// # Safety
    ///
    /// Tsy toy ny `offset` anaty, anaty io dia tsy mametra ny vokatry ny manondro ny hevitra ho any na iray byte lasa ny faran'ny zavatra iray natokana, ary ny roa amin'ny Fonosiny famenon'i rafitrisa.
    /// Ny valiny vokatr'izany dia tsy voatery mitombina raha tiana hampiasaina hanatsarana ny fahatsiarovana.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Mitovy ny mety `llvm.memcpy.p0i8.0i8.*` anaty, miaraka amin'ny haben'ny `count`*`size_of::<T>()` sy ny fampifanarahana ny
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ny fikirana mikorontana no nametraka an'i `true`, dia toy izany no tsy ho optimisé avy raha tsy mitovy ny habeny dia aotra.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Mitovy amin'ny intrinsika `llvm.memmove.p0i8.0i8.*` sahaza azy, misy habe `count* size_of::<T>()` sy fampifanarahana ny
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ny fikirana mikorontana no nametraka an'i `true`, dia toy izany no tsy ho optimisé avy raha tsy mitovy ny habeny dia aotra.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Mitovy ny mety `llvm.memset.p0i8.*` anaty, miaraka amin'ny haben'ny `count* size_of::<T>()` sy ny fampifanarahana ny `min_align_of::<T>()`.
    ///
    ///
    /// Ny fikirana mikorontana no nametraka an'i `true`, dia toy izany no tsy ho optimisé avy raha tsy mitovy ny habeny dia aotra.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Manao iray mikorontana entana avy amin'ny `src` manondro.
    ///
    /// Ny dikan-voahozongozona izany no [`core::ptr::read_volatile`](crate::ptr::read_volatile) anaty.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Manao ny mikorontana hotehirizina ao amin'ny `dst` manondro.
    ///
    /// Ny dikan-voahozongozona izany no [`core::ptr::write_volatile`](crate::ptr::write_volatile) anaty.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Manatanteraka enta-mavesatra mihetsiketsika avy amin'ny tondro `src` Ny tondro dia tsy voatery hampifanarahana.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Manao ny mikorontana hotehirizina ao amin'ny `dst` manondro.
    /// Ny fanondroana dia tsy voatery hampifanarahana.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Miverina ny kianja fototry ny iray `f32`
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Miverina ny kianja fototry ny iray `f64`
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Manangana ny `f32` any amin'ny iray integer fahefana.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Manangana `f64` ho hery anaty.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Miverina ny mason'ny `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Miverina ny Sine iray `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Miverina ny cosine iray `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Miverina ny cosine `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Manangana `f32` ho hery `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Manangana `f64` ho hery `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Miverina ny exponential iray `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Miverina ny exponential iray `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Miverina 2 atsangana ny herin 'ny `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Miverina 2 atsangana amin'ny herin'ny `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Miverina ny voajanahary `f32` logarithm iray.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Miverina ny logaritma voajanahary `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Miverina ny base 10 logaritma `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Miverina ny fototra 10 logarithm iray `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Miverina ny logaritma 2 fototra amin'ny `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Miverina ny fototra 2 logarithm iray `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Miverina `a * b + c` ho an'ny sanda `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Miverina `a * b + c` ho an'ny sanda `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Miverina ny tena lanjan 'ny `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Miverina ny sanda farany `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Mamerina ny farafahakeliny sanda `f32` roa.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Miverina ny kely indrindra ny soatoavina `f64` roa.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Miverina ny ambony indrindra ny soatoavina `f32` roa.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Miverina ny ambony indrindra ny soatoavina `f64` roa.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Adikao ny famantarana avy amin'ny `y` ka hatramin'ny `x` ho an'ny sanda `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Mandika ny famantarana avy `y` ho `x` for `f64` soatoavina.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Miverina ny integer lehibe indrindra ambany na mitovy amin'ny `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Miverina ny integer lehibe indrindra ambany na mitovy amin'ny `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Miverina ny integer kely indrindra lehibe kokoa na mitovy amin'ny `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Miverina ny kely indrindra na ny lehibe noho integer mitovy any amin'ny iray `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Miverina ny integer ampahany amin'ny `f32`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Miverina ny integer ampahany amin'ny `f64`.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Miverina akaiky indrindra any amin'ny iray `f32` integer.
    /// Enga anie hanangana ny inexact mitsingevana-teboka afa-tsy raha toa ny tohan-kevitra dia tsy integer.
    pub fn rintf32(x: f32) -> f32;
    /// Miverina akaiky indrindra any amin'ny iray `f64` integer.
    /// Enga anie hanangana ny inexact mitsingevana-teboka afa-tsy raha toa ny tohan-kevitra dia tsy integer.
    pub fn rintf64(x: f64) -> f64;

    /// Miverina akaiky indrindra any amin'ny iray `f32` integer.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Miverina akaiky indrindra any amin'ny iray `f64` integer.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Miverina ny integer akaiky indrindra amin'ny `f32`.Fihodinana antsasaky ny fomba toe-javatra hiala aotra.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Miverina akaiky indrindra any amin'ny iray `f64` integer.Fihodinana antsasaky ny fomba toe-javatra hiala aotra.
    ///
    /// Ny voahozongozona anaty dika ity dia
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Hitsingevana koa izay mamela ny optimizations algebraic miorina amin'ny fitsipika.
    /// Mety hihevitra fa voafetra ny fampidirana.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Fanesorana mitsingevana izay mamela ny fanatsarana mifototra amin'ny fitsipiky ny algebra.
    /// Mety hihevitra fa voafetra ny fampidirana.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Fampitomboana Float izay mamela ny fanatsarana mifototra amin'ny fitsipiky ny algebra.
    /// Mety hihevitra fa voafetra ny fampidirana.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Fizarana mitsingevana izay mamela ny fanatsarana mifototra amin'ny lalàna algebraic.
    /// Mety hihevitra fa voafetra ny fampidirana.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float sisa tavela izay mamela ny fanatsarana mifototra amin'ny fitsipiky ny algebra.
    /// Mety hihevitra fa voafetra ny fampidirana.
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Niova fo amin'ny LLVM ny fptoui/fptosi, izay mety hiverina undef ny soatoavina isan-karazany avy amin'ny
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Voamarina ho [`f32::to_int_unchecked`] sy [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Miverina ny isan'ny potika napetraka tao amin'ny integer karazana `T`
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny primitives integer amin'ny alàlan'ny fomba `count_ones`.
    /// Ohatra,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Miverina ny isan'ny mpitarika unset potika (zeroes) amin'ny integer `T` karazana.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `leading_zeros`.
    /// Ohatra,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// An `x` amin'ny vidiny `0` dia hiverina ny sakan'ny `T` kely.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Toa an'i `ctlz`, fa mampidi-doza ivelan'ny araka ny miverina `undef` rehefa nomena ny `x` amin'ny `0` sarobidy.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Miverina ny isan'ny tanatin 'unset potika (zeroes) amin'ny integer `T` karazana.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `trailing_zeros`.
    /// Ohatra,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// An `x` amin'ny vidiny `0` dia hiverina ny kely sakan'ny `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Toa an'i `cttz`, fa mampidi-doza ivelan'ny araka ny miverina `undef` rehefa nomena ny `x` amin'ny `0` sarobidy.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Zavatra mampalahelo ny oktety amin'ny integer `T` karazana.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `swap_bytes`.
    /// Ohatra,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Zavatra mampalahelo ny potika tao amin'ny integer `T` karazana.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `reverse_bits`.
    /// Ohatra,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Homarinana avy amin'ny teny integer manatanteraka koa.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny primitives integer amin'ny alàlan'ny fomba `overflowing_add`.
    /// Ohatra,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Manao teny integer subtraction
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny primitives integer amin'ny alàlan'ny fomba `overflowing_sub`.
    /// Ohatra,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Manatanteraka fampitomboana integer voamarina
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `overflowing_mul`.
    /// Ohatra,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Manao ny marina fizarana, izay niafara tamin'ny fitondran-tena izay tsy voafaritra `x % y != 0` na `y == 0` na `x == T::MIN && y == -1`
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Manao ny fizarana voafehy, izay niafara tamin'ny fitondran-tena izay tsy voafaritra `y == 0` na `x == T::MIN && y == -1`
    ///
    ///
    /// Ireo fonosana azo antoka ho an'ity intrinsika ity dia misy amin'ny primitives integer amin'ny alàlan'ny fomba `checked_div`.
    /// Ohatra,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Miverina ny sisa tsy voafehy fizarana, izay niafara tamin'ny fitondran-tena, rehefa tsy voafaritra `y == 0` na `x == T::MIN && y == -1`
    ///
    ///
    /// Safe wrappers Ary noho izany dia azo jerena ao amin'ny anaty ny integer primitives amin'ny alalan'ny fomba `checked_rem`.
    /// Ohatra,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Manatanteraka ny voafehy ankavia fiovana, izay niafara tamin'ny fitondran-tena, rehefa tsy voafaritra `y < 0` na `y >= N`, izay N no sakan'ny T in potika.
    ///
    ///
    /// Safe wrappers Ary noho izany dia azo jerena ao amin'ny anaty ny integer primitives amin'ny alalan'ny fomba `checked_shl`.
    /// Ohatra,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Manatanteraka ny fiovana voafehy tsara, izay niafara tamin'ny fitondran-tena, rehefa tsy voafaritra `y < 0` na `y >= N`, izay N no sakan'ny T in potika.
    ///
    ///
    /// Safe wrappers Ary noho izany dia azo jerena ao amin'ny anaty ny integer primitives amin'ny alalan'ny fomba `checked_shr`.
    /// Ohatra,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Miverina ny vokatry ny voafehy koa, izay niafara tamin'ny fitondran-tena, rehefa tsy voafaritra `x + y > T::MAX` na `x + y < T::MIN`.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Miverina ny vokatry ny voafehy subtraction, izay niafara tamin'ny fitondran-tena, rehefa tsy voafaritra `x - y > T::MAX` na `x - y < T::MIN`.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Miverina ny vokatry ny fampitomboana voafehy, izay niafara tamin'ny fitondran-tena, rehefa tsy voafaritra `x *y > T::MAX` na `x* y < T::MIN`.
    ///
    ///
    /// Ity intrinsika ity dia tsy misy mifanohitra aminy.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Manatanteraka hanodinana ny sisa.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `rotate_left`.
    /// Ohatra,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Manatanteraka hanodinana ny marina.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia misy amin'ny primitives integer amin'ny alàlan'ny fomba `rotate_right`.
    /// Ohatra,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Miverina (a + b) Mod 2 <sup>N,</sup> izay N no sakan'ny T in potika.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `wrapping_add`.
    /// Ohatra,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Miverina (a, b) Mod 2 <sup>N,</sup> izay N no sakan'ny T in potika.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `wrapping_sub`.
    /// Ohatra,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Miverina (a + b) Mod 2 <sup>N,</sup> izay N no sakan'ny T in potika.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `wrapping_mul`.
    /// Ohatra,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Manisa `a + b`, mahavoky ny fetra isa.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `saturating_add`.
    /// Ohatra,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, mamonto amin'ny numeric fetra.
    ///
    /// Ny voahozongozona anaty dika ity dia hita ao amin'ny integer primitives amin'ny alalan'ny fomba `saturating_sub`.
    /// Ohatra,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Miverina ny sandan'ny fanavakavahana ho an'ny variant amin'ny 'v';
    /// raha tsy manavakavaka i `T` dia avereno `0`.
    ///
    /// Ny kinova miorina amin'ity intrinsika ity dia [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Miverina ny isan'ny variants ny karazana `T` hariana any amin'ny `usize`;
    /// raha tsy manana variants `T`, miverina `0`.Tsy misy mipetraka mantsy variants ho isaina.
    ///
    /// Ny kinova mampiorina ity intrinsika ity dia [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// "try catch" Rust ny fanamboarana izay mitalaho manondro ny asa miaraka amin'ny angon-drakitra `try_fn` manondro `data`.
    ///
    /// Ny adihevitra fahatelo dia fiasa antsoina raha misy panic.
    /// Izany asa atao manondro ny tahirin-kevitra sy ny manondro ny lasibatra-afa-tsy zavatra manokana izay tratra.
    ///
    /// Raha mila fanazavana fanampiny dia jereo ny loharanom-pahalalana ary koa ny fampiharana ny std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Mamoaka ny `!nontemporal` fivarotana araka ny LLVM (jereo ny tahirin-kevitrao).
    /// Angamba dia tsy ho tranon'omby.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Jereo ny tahirin-kevitra ny `<*const T>::offset_from` ho an'ny antsipirihany.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Jereo ny tahirin-kevitra ny `<*const T>::guaranteed_eq` ho an'ny antsipirihany.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Jereo ny antontan-taratasy momba ny `<*const T>::guaranteed_ne` raha mila fanazavana.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Mizarà amin'ny fotoana fanangonana.Tokony tsy hatao hoe amin'ny runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Misy asa dia voafaritra eto, satria natao tsy nahy nataony misy amin'ny Module ity amin'ny tranon'omby.
// Jereo <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` koa ho latsaka ity sokajy ity, saingy tsy azo nofonosina noho ny maso fa `T` sy `U` manana ny habeny ihany.)
//

/// Manamarina raha mifanaraka tsara amin'ny `align_of::<T>()` ny `ptr`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Bytes `count *size_of::<T>()` dika mitovy avy amin'ny `src` ho `dst`.Ny loharano sy ny toerana tsy maintsy* tsy * hifanindry.
///
/// Fa ny fahatsiarovana faritra izay mety hifanindry, fa tsy mampiasa [`copy`].
///
/// `copy_nonoverlapping` dia mitovy amin'ny C semantically ny [`memcpy`], fa ny tohan-kevitra mba swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `src` tsy maintsy [valid] raha vaky ny byte `count * size_of::<T>()`.
///
/// * `dst` dia tsy maintsy ho [valid] ny manoratra ny `count * size_of::<T>()` oktety.
///
/// * Samy `src` sy `dst` tsy maintsy ho araka ny tokony mifanaraka.
///
/// * Ny faritra ny fahatsiarovana manomboka amin'ny `src` amin'ny haben'ny: manisa *
///   size_of: :<T>() `bytes dia tsy tokony * tsy hifanindry amin'ny faritry ny fahatsiarovana manomboka amin'ny `dst` mitovy habe aminy.
///
/// Toy ny [`read`], `copy_nonoverlapping` dia mamorona kopian'ny `T` kely, na inona na inona `T` dia [`Copy`].
/// Raha `T` dia tsy [`Copy`], ampiasao ny *roa* ny sanda ao amin'ny faritra manomboka amin'ny `*src` ary ny faritra manomboka amin'ny `* dst` dia afaka [violate memory safety][read-ownership].
///
///
/// Mariho fa na dia ny habeny namboarina tamin'ny fomba mahomby aza (`count * size_of: :<T>():) Dia `0`, ny sahaza dia tsy maintsy ho tsy araka ny tokony ho tohivakana foana sy mifanaraka.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ampiharo amin'ny tanana ny [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Mamindra ny singa `src` rehetra mankany `dst`, mamela `src` foana.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Hahazoana antoka fa `dst` manana fahafahana ampy mba hihazona `src` rehetra.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Ny antso ho an'ny offset dia azo antoka foana satria ny `Vec` dia tsy hanokana mihoatra ny `isize::MAX` bytes.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` tsy nandatsaka ny zavatra raketiny.
///         // Manao izany isika aloha, mba tsy olana raha zavatra bebe kokoa teo panics.
///         src.set_len(0);
///
///         // Ireo faritra roa tsy afaka hifanindry satria tsy mutable andinin-tsoratra masina antsoina, ary roa samy hafa dia tsy afaka vectors manana fahatsiarovana toy izany koa.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Ampahafantaro ny `dst` fa mitazona ny atin'ny `src` izy izao.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Hanatanteraka ireo taratasim-bola ihany amin'ny fotoana nihazakazaka
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Tsy mikoropaka hitazomana ny fiantraikan'ny codegen ho kely kokoa.
        abort();
    }*/

    // Famonjena, ny fiarovana ho an'ny `copy_nonoverlapping` fifanarahana dia tsy maintsy ho
    // nanohana ny mpiantso.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Mandika bytes `count * size_of::<T>()` manomboka amin'ny `src` ka hatramin'ny `dst`.Ny loharano sy ny toerana dia mety hifanindry.
///
/// Raha ny loharanom-baovao sy ny toerana dia *tsy* roa, dia azo ampiasaina [`copy_nonoverlapping`] fa tsy.
///
/// `copy` dia mitovy amin'ny C semantically ny [`memmove`], fa ny tohan-kevitra mba swapped.
/// Kopia atao toy ny oktety dia nadika avy `src` ho vonjimaika nahay ary avy eo dia nadika avy amin'ny fihaingoana ho `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `src` tsy maintsy [valid] raha vaky ny byte `count * size_of::<T>()`.
///
/// * `dst` dia tsy maintsy ho [valid] ny manoratra ny `count * size_of::<T>()` oktety.
///
/// * Samy `src` sy `dst` tsy maintsy ho araka ny tokony mifanaraka.
///
/// Toa an'i [`read`], `copy` miteraka bitwise `T` dika mitovy, na inona na inona na dia [`Copy`] `T`.
/// Raha tsy `T` [`Copy`], na mampiasa ny soa toavina ao amin'ny faritra manomboka eo amin'ny `*src` sy ny faritra manomboka eo amin'ny `* dst` afaka [violate memory safety][read-ownership].
///
///
/// Mariho fa na dia ny habeny namboarina tamin'ny fomba mahomby aza (`count * size_of: :<T>():) Dia `0`, ny sahaza dia tsy maintsy ho tsy araka ny tokony ho tohivakana foana sy mifanaraka.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Mahomby mamorona Rust vector avy amin'ny mampidi-doza buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` dia tsy maintsy ampifanarahana tsara amin'ny karazany sy tsy zero.
/// /// * `ptr` dia tsy maintsy manan-kery ny mamaky ny `elts` contiguous karazana singa `T`.
/// /// * Ireo singa tsy azo ampiasaina rehefa miantso asa izany raha tsy `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // Famonjena, ny heverina ho mialohan miantoka ny loharanom-baovao dia mifanaraka sy manankery,
///     // ary `Vec::with_capacity` miantoka fa manana toerana azo ampiasaina mba hanoratra azy ireo.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: Noforoninay niaraka tamin'ity fahaiza-manao betsaka ity teo aloha,
///     // ary teo aloha dia initialized `copy` singa ireo.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Hanatanteraka ireo taratasim-bola ihany amin'ny fotoana nihazakazaka
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Tsy mikoropaka hitazomana ny fiantraikan'ny codegen ho kely kokoa.
        abort();
    }*/

    // Famonjena, ny fiarovana ho an'ny `copy` fifanarahana dia tsy maintsy ho nanohana ny mpiantso.
    unsafe { copy(src, dst, count) }
}

/// Karazana `count * size_of::<T>()` Bytes ny fahatsiarovana manomboka amin'ny `dst` ho `val`.
///
/// `write_bytes` dia mitovy amin'ny C's [`memset`], fa mametraka `count * size_of::<T>()` bytes ho `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `dst` dia tsy maintsy ho [valid] ny manoratra ny `count * size_of::<T>()` oktety.
///
/// * `dst` dia tsy maintsy ho araka ny tokony mifanaraka.
///
/// Ankoatra izany, ny mpiantso dia tsy maintsy azo antoka fa nanoratra `count * size_of::<T>()` Bytes ny faritra nomena ny fahatsiarovana vokatra amin'ny ekena sarobidy ny `T`.
/// Mampiasa ny faritra ny fahatsiarovana tendrena ho toy ny `T` izay ahitana ny tsy manan-kery `T` sarobidy ny fitondran-tena dia tsy voafaritra.
///
/// Mariho fa na dia ny fomba mahomby kopia habe (`manisa * size_of: :<T>()`) dia `0`, ny tondro dia tokony tsy NOL ary mifanaraka tsara.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Famoronana ny tsy mety vidiny:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Mamoaka ny sanda nitazona teo aloha amin'ny alàlan'ny fanoratana ny `Box<T>` miaraka amin'ny tondro tsy misy.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Tamin'izay fotoana izay, mampiasa na nandatsaka `v` valiny amin'ny fitondran-tena tsy voafaritra.
/// // drop(v); // ERROR
///
/// // Na dia mamoaka `v` "uses" aza izany, ary noho izany dia fihetsika tsy voafaritra.
/// // mem::forget(v); // ERROR
///
/// // Raha ny marina, `v` Tsy mety araka ny fototra karazana fisehon'ny invariants, ka *rehetra* fandidiana dia tsy voafaritra mikasika ny fitondran-tena.
/////
/// // aoka v2 =V;//ERROR
///
/// unsafe {
///     // Aleo isika mametraka sanda manan-kery
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ary ny efajoro tsara
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // Famonjena, ny fiarovana ho an'ny `write_bytes` fifanarahana dia tsy maintsy ho nanohana ny mpiantso.
    unsafe { write_bytes(dst, val, count) }
}