#![stable(feature = "core_hint", since = "1.27.0")]

//! Soso-kevitra amin'ny compiler izay misy fiatraikany amin'ny fomba tokony hamoahana na hanatsara ny kaody.
//! Mety ho fanangonana fotoana na fotoana fohy ny fambara.

use crate::intrinsics;

/// Mampahalala ny compiler fa io teboka ao amin'ny fehezan-dalàna dia tsy hita ety ivelany, manampy bebe kokoa optimizations.
///
/// # Safety
///
/// Fitoriana asany izany dia tsy voafaritra tanteraka * *(UB) fitondran-tena.Indrindra indrindra, ny compiler jerena, dia hoatran'ny hoe Ub rehetra tsy maintsy hitranga na oviana na oviana, ka noho izany dia hanafoana ny sampana rehetra izay takatry ny antso `unreachable_unchecked()`.
///
/// Toy ny tranga rehetra ny Ub, raha kevitra ity ny fandehany fa diso, izany hoe, ny `unreachable_unchecked()` antso dia tena hita ety ivelany amin'ny olona rehetra ny fanaraha-maso mety mikoriana, ny compiler dia hampihatra ny ratsy Optimization paik'ady, ary mety indraindray ratsy mihitsy aza heverina ho tsy mitovy fehezan-dalàna, ka mahatonga difficult-to-debug olana.
///
///
/// Ampiasao io asa io raha tsy rehefa manaporofo ianao fa tsy hiantso azy mihitsy ilay kaody.
/// Raha tsy izany, dia diniho ny fampiasana ny [`unreachable!`] macro, izay tsy mamela ho panic optimizations fa rehefa novonoina ho faty.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` dia miabo hatrany (tsy aotra), noho izany `checked_div` dia tsy hiverina `None` mihitsy.
/////
///     // Noho izany, ny hafa branch tsy takatra.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // Famonjena, ny fiarovana fifanarahana for `intrinsics::unreachable` tsy maintsy
    // ho nanohana ny mpiantso.
    unsafe { intrinsics::unreachable() }
}

/// Mamoaka torolàlana momba ny masinina hilazana ilay mpanamboatra fa mandeha amin'ny rotaka-miandry be atao ("hidin-trano" io).
///
/// Rehefa naharay ny kofehy ireny-manome fitoerana famantarana ny processeur dia afaka manatsara ny fitondran-tena ny, ohatra, na manan-kery hamonjy hyper ara-kofehy.
///
/// Io asa hafa noho [`thread::yield_now`], izay nanaraka ny tenin'ireo mivantana ny rafitra scheduler, `spin_loop` kosa no tsy mifandray amin'ny ny fandidiana rafitra.
///
/// Ny fampiasana iraisana tranga for `spin_loop` no be fanantenana fampiharana atsy kofehy amin'ny čas manome fitoerana amin'ny synchronization primitives.
/// Mba hisorohana ny olana toy ny laharam-pahamehana inversion, dia mafy soso-kevitra fa ny kofehy ireny dia faranana manome fitoerana voafetra taorian'ny habetsaky ny iterations sy mety fanakànana syscall atao.
///
///
/// Note ** **: Ny sehatra izay tsy manohana ny fandraisana-kofehy ireny manome fitoerana hamantatra izany asa izany dia tsy na inona na inona mihitsy.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // A nizara atomika sanda fa kofehy dia hampiasa ny mandrindra
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Ao anaty kofehy aoriana dia hametraka ny sandany isika amin'ny farany
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Manaova asa, avy eo ataovy velona hatrany ny soatoavina
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Miverina eo amin'ny kofehy amin'izao fotoana izao isika, dia miandry ny vidiny koa ho
/// while !live.load(Ordering::Acquire) {
///     // Ny kofehy ireny dia Soso-kevitra manome fitoerana ho an'ny CPU fa miandry isika, nefa azo inoana fa tsy ho ela
/////
///     hint::spin_loop();
/// }
///
/// // Ny zava-dehibe dia izao napetraka
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // Famonjena, ny `cfg` attr antoka fa isika ihany no hampihatra izany amin'ny x86 lasibatra.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // Famonjena, ny `cfg` attr antoka fa isika ihany no hampihatra izany amin'ny x86_64 lasibatra.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAFETY: ny `cfg` attr dia manome antoka fa tsy amin'ny fampiharana aarch64 ihany no anaovanay izany.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: ny `cfg` atr dia miantoka fa tsy amin'ny tanjon'ny sandry ihany no anaovanay izany
            // amin'ny fanohanana ny v6 endri-javatra.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Fandraisana andraikitra izay manondro *ny __ __* ny mpamorona mba pessimistic fatratra momba izay azon'i `black_box` atao.
///
/// Tsy toy ny [`std::convert::identity`], ny Rust compiler dia ampirisihina mba mihevitra fa afaka mampiasa `dummy` `black_box` na inona na inona mety ho manan-kery fomba Rust fehezan-dalàna no avela tsy fampidirana fihetsika tsy voafaritra ao amin'ny Calling code.
///
/// Zavatra tsy fananana `black_box` manao ilaina ho an'ny fanoratana fehezan-dalàna izay optimizations sasany tsy naniry, toy ny benchmarks.
///
/// Mariho anefa fa `black_box` ihany (ary afaka ihany) Nanome amin'ny "best-effort" fototra.Ny habe ahafahany manakana ny fanatsarana dia mety miovaova arakaraka ny lampihazo sy ny code-gen backend ampiasaina.
/// Fandaharana dia tsy afaka miantehitra amin'ny `black_box` for *correct* amin'ny fomba rehetra.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Mila "use" ny ady hevitra amin'ny fomba sasany tsy azon'ny LLVM dinihina, ary amin'ny tanjona kendrena hanohanana azy dia azontsika atao tsara ny manangona fivoriambe manao izany.
    // LLVM ny fandikana ny inline fiangonana dia izany, tsara, misy boaty mainty.
    // Tsy ny fampiharana lehibe indrindra satria angamba deoptimizes mihoatra noho tiantsika, saingy hatreto ampy tsara.
    //
    //

    #[cfg(not(miri))] // Izany no Soso-kevitra fotsiny, noho izany dia tsara ny mifalihavanja in Miri.
    // Famonjena, ny fiangonana inline dia no-Op.
    unsafe {
        // FIXME: Tsy afaka mampiasa `asm!` satria tsy manohana ny MIPS sy ny maritrano hafa.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}