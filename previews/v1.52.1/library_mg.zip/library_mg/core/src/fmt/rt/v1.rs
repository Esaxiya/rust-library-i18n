//! Izao no anatiny Module ampiasain'ny ifmt!runtime.Ireo firafitra ireo dia alefa amina tsanganana static mba hametrahana mialoha ny tadin'ny endrika mialoha.
//!
//! Ireo famaritana ireo toy izany koa ny `ct` equivalents, fa samy hafa amin 'izany ireo fitohy azo omena ary somary optimisé ho an'ny runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Fampifanarahana mety azo angatahina ao anatin'ny torolàlana amin'ny famolavolana.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Filazana fa tokony hatao mifanaraka amin'ny ankavia ny atiny.
    Left,
    /// Filazana fa tokony hatao mifanaraka tsara ny atiny.
    Right,
    /// Porofo fa tokony ho afovoany Hevitra ato Anatiny-mifanaraka.
    Center,
    /// Tsy misy fampifanarahana nangatahana.
    Unknown,
}

/// Nampiasain'ny [width](https://doc.rust-lang.org/std/fmt/#width) sy [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Voamarina amin'ny isa ara-bakiteny, mitahiry ny sandany
    Is(usize),
    /// Voamarina amin'ny fampiasana syntaxes `$` sy `*`, mitahiry ny index mankany `args`
    Param(usize),
    /// Tsy voasoritra
    Implied,
}