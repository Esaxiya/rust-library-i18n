//! Famerenana tsy azo ampiarahina.
//!
//! Raha z0futures0Z dia soatoavina tsy mitambatra, dia ny iteratera no miverina.
//! Raha efa nahita ny tenanao miaraka amin'ny asynchronous fitambarana karazana, ary ilaina mba hanao fandidiana eo amin'ny singa ny nilaza fanangonana, mihazakazaka haingana ianao ho any 'streams'.
//! Ny renirano dia ampiasaina betsaka amin'ny kaody Rust tsy mifanaraka amin'ny idiomatika, noho izany dia mendrika ny ho lasa mahazatra azy ireo.
//!
//! Alohan'ny hanazavana bebe kokoa dia andao hiresaka ny fomba fandrafetana ity modely ity:
//!
//! # Organization
//!
//! Module amin'ny ankapobeny ity dia nokarakarain'ny karazana:
//!
//! * [Traits] no fototra anjara: traits mamaritra ireo karazana renirano ny zavatra misy sy ny zavatra azonao atao miaraka aminy.Ny fomban'ireto traits ireto dia mendrika ny mametraka fotoana fandinihana fanampiny.
//! * Manome asa mahasoa ny sasany fomba hamoronana ny sasany fototra renirano.
//! * Structs matetika ny fiverenan'ny karazana ny fomba isan-karazany izao ny traits Module.Matetika ianao no te hijery ny fomba mamorona ny `struct` fa tsy ny `struct` mihitsy.
//! Raha mila tsipiriany misimisy momba ny antony dia jereo ny '[Implementing Stream](#implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! Dia izay!Andao hihady anaty rano.
//!
//! # Stream
//!
//! Ny fo sy ny fanahin'ity modely ity dia ny [`Stream`] trait.Toy izao ny fototry ny [`Stream`]:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Tsy toy ny `Iterator`, `Stream` manao manavaka ny [`poll_next`] fomba izay ampiasaina rehefa fametrahana ny `Stream`, ary ny (to-be-implemented) `next` fomba izay ampiasaina rehefa mandany ny renirano.
//!
//! Mpanjifa ny `Stream` ihany no tokony handinika `next`, izay raha atao hoe, miverina ny future izay `Option<Stream::Item>` mahavokatra.
//!
//! Ny future naverin'i `next` dia hanome `Some(Item)` raha mbola misy singa, ary rehefa reraka izy rehetra, dia hamoaka `None` hanondroana fa vita ny famerenana.
//! Raha toa isika ka miandry ny zavatra ianao asynchronous vahaolana, ny future hiandry mandra-dohasahan-driaka no vonona ny hilefitra indray.
//!
//! Ny safidin'ny tsirairay dia mety misafidy ny hanohy ny laoniny, ary ny fiantsoana `next` indray dia mety hamoaka `Some(Item)` indray amin'ny farany.
//!
//! Ny famaritana feno an'i [`Stream`] dia misy fomba maro hafa koa, saingy fomba fiasa tsy miangatra izy ireo, miorina eo ambonin'ny [`poll_next`], ka azonao maimaim-poana.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Fampiharana renirano
//!
//! Ny famoronana stream anao manokana dia misy dingana roa: mamorona `struct` hitazona ny fanjakan'ny renirano, ary avy eo mampihatra [`Stream`] ho an'io `struct`.
//!
//! Andao hanao renirano antsoina hoe `Counter` izay manisa hatramin'ny `1` ka hatramin'ny `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Voalohany, ny struct:
//!
//! /// Rano iray manisa hatramin'ny iray ka hatramin'ny dimy
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Tianay ny hanombohanay isa amin'ny iray, ka aleo manampy fomba new() hanampiana.
//! // Izany no tsy tena ilaina, fa mety.
//! // Mariho fa manomboka `count` amin'ny zero isika, ho hitantsika ny antony amin'ny fampiharana `poll_next()`'s etsy ambany.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Avy eo, mampihatra `Stream` ho an'ny `Counter` izahay:
//!
//! impl Stream for Counter {
//!     // Ny fisiana ara-isika dia ho amin'ny usize
//!     type Item = usize;
//!
//!     // poll_next() no hany takiana fomba
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Ampitomboy ny fanisanay.Izany no antony nanomboka amin'ny aotra.
//!         self.count += 1;
//!
//!         // Hamarino raha nahavita nanisa izahay na tsia.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Kamo * ny renirano.Midika izany fa ny renirano famoronana fotsiny no tsy _do_ be iray manontolo.Tsy misy zavatra tena mitranga raha tsy miantso `next` ianao.
//! Indraindray loharanom-pifangaroan-tsaina izany rehefa mamorona renirano fotsiny noho ny vokany.
//! Ny compiler dia mampitandrina antsika ny momba izany karazana fitondran-tena:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;