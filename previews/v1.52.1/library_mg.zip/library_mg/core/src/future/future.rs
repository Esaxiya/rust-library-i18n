#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Ny future dia maneho computation tsy mifanaraka.
///
/// A future dia zava-dehibe izay mety tsy ho vita ny computing mbola.
/// Io karazana "asynchronous value" manome fahafahana ny kofehy mba hanohy hanao asa mahasoa raha miandry ny zava-dehibe ho tonga misy.
///
///
/// # The `poll` fomba
///
/// Ny fototra fomba future, `poll`,* * ezaka mba hamaha ny future ho zava-dehibe farany.
/// Ity fomba ity dia tsy manakana raha tsy vonona ny sanda.
/// Kosa, ny asa amin'izao fotoana izao dia voalahatra ho Nifoha raha izany azo atao ny manao fandrosoana bebe kokoa amin'ny alalan'ny: poll`ing indray.
/// Ny `context` nandeha tamin'ny fomba `poll` afaka manome ny [`Waker`], izay ny tahony ho an'ny mifoha ny asa amin'izao fotoana izao.
///
/// Rehefa mampiasa future, ianao amin'ny ankapobeny dia tsy hoe `poll` mivantana, fa raha tokony `.await` ny zava-dehibe.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Ny karazana vokatra sarobidy tamin'ny vita.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Miezaka ho tapa-kevitra ny future sanda farany, ny fisoratam ny asa amin'izao fotoana izao ho an'ny wakeup raha ny vidiny dia tsy mbola misy.
    ///
    /// # Miverina amin'ny sarobidy
    ///
    /// Izany asa miverina:
    ///
    /// - [`Poll::Pending`] raha ny future tsy vonona mbola
    /// - [`Poll::Ready(val)`] ny vokatr'izany `val` io future raha vita soa aman-tsara.
    ///
    /// Raha vantany vao vita ny future dia tsy tokony hamerina azy io indray ny mpanjifa.
    ///
    /// Rehefa mbola tsy vonona ny future dia miverina `Poll::Pending` ny `poll` ary mitahiry klone an'ny [`Waker`] nalaina tahaka tamin'ny [`Context`] ankehitriny.
    /// Izany dia avy eo [`Waker`] Nifoha indray mandeha ny future afaka handroso.
    /// Ohatra, ny future miandry ny faladiany ho vakiana dia miantso `.clone()` ny [`Waker`] sy mitahiry azy.
    /// Rehefa tonga any an-kafa tsato-kazo famantarana manondro fa ny faladiany dia vakiana, [`Waker::wake`] dia antsoina hoe ny faladiany sy ny asa future dia awoken.
    /// Raha vao ny asa efa Nifoha, dia tokony hiezaka ny `poll` ny future indray, izay mety na tsy miteraka sanda farany.
    ///
    /// Mariho fa amin'ny antso maro ho `poll`, afa-tsy ny avy ao amin'ny [`Context`] [`Waker`] nandeha ny antso farany indrindra dia tokony ho voalahatra handray ny wakeup.
    ///
    /// # Toetra mampiavaka ny fotoana maharitra
    ///
    /// Futures irery ihany no *inert*;izy ireo dia tsy maintsy atao *mavitrika*`poll`l mba handrosoana, midika izany fa isaky ny mifoha ny asa ankehitriny dia tokony hamerina hamaky``poll` am-piandrasana ny futures izay mbola mahaliana azy.
    ///
    /// Ny fiasan'ny `poll` dia tsy antsoina miverimberina ao anaty tadiny mafy-fa tokony hantsoina fotsiny izy io rehefa manondro ny future fa vonona ny handroso (amin'ny fiantsoana `wake()`).
    /// Raha fantatrao ny syscalls `poll(2)` na `select(2)` amin'ny Unix dia tsara ny manamarika fa futures mazàna *tsy* mijaly amin'ny olana mitovy amin'ny "all wakeups must poll all events";mitovy kokoa amin'ny `epoll(4)` izy ireo.
    ///
    /// Ny fametrahana ny `poll` dia tokony hiezaka ny hiverina haingana, ary tsy tokony hanakana.Misakana tsy amin'antony niverina haingana clogging ny kofehy na ny hetsika tadivavarana.
    /// Raha fantatra mialoha fa ny antso ho `poll` dia mety hiafara maka ny fotoana fohy, ny asa tokony offloaded ny kofehy dobo (na zavatra mitovy) mba ho azo antoka fa `poll` afaka hiverina haingana.
    ///
    /// # Panics
    ///
    /// Indray andro nisy future efa vita (niverina `Ready` avy `poll`), niantso indray ny `poll` fomba mety panic, hibahana mandrakizay, na mahatonga ny olana hafa karazana;ny `Future` trait tsy mametraka fepetra ny vokatry ny antso toy izany.
    /// Na dia izany aza, araka ny fomba tsy `poll` marika `unsafe`, Rust mampihatra ny fitsipika mahazatra: antso tsy tokony hiteraka fihetsika tsy voafaritra (fitadidiana ny kolikoly, ny fampiasana ny `unsafe` diso asa, na ny toy izany), na inona na inona ny future ny fanjakana.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}