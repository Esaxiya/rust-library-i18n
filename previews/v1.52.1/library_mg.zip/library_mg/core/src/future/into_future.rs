use crate::future::Future;

/// Fiovam-po an-`Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Ny Output fa ny future dia hamokatra ny vita.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Izay karazana future isika no mamadika izany ho any?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Miteraka future avy amin'ny zava-dehibe.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}