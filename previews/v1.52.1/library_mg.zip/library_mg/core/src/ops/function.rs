/// Ny kinalan'ny mpandraharaha antso izay mandray mpandray tsy miova.
///
/// Ny tranga `Fn` dia azo antsoina miverimberina tsy misy mutating state.
///
/// *Ity trait (`Fn`) ity dia tsy tokony hafangaro amin'ny [function pointers] (`fn`).*
///
/// `Fn` dia ampiharina amin'ny alàlan'ny fanakatonana izay tsy maka fanovana tsy azo ovaina fotsiny amin'ireo variable voasambotra na tsy misambotra na inona na inona mihitsy, ary koa (safe) [function pointers] (miaraka amina fampitandremana sasany, jereo ny antontan-taratasiny raha mila tsipiriany misimisy kokoa).
///
/// Ankoatr'izay, ho an'ny karazana `F` izay mampihatra `Fn`, `&F` dia mampihatra `Fn` koa.
///
/// Satria ny [`FnMut`] sy [`FnOnce`] dia supertraits an'ny `Fn`, ny ohatra `Fn` dia azo ampiasaina ho masontsivana izay antenaina [`FnMut`] na [`FnOnce`].
///
/// Ampiasao ny `Fn` ho voafatotra rehefa te-hanaiky ny masontsivana karazana toy ny fiasa ianao ary mila miantso azy imbetsaka ary tsy miovaova ny fanjakana (ohatra, rehefa miantso azy io miaraka).
/// Raha tsy mila fepetra henjana toy izany ianao dia ampiasao fehezan-dalàna ny [`FnMut`] na [`FnOnce`].
///
/// Jereo ny [chapter on closures in *The Rust Programming Language*][book] ho an'ny sasany fanazavana bebe kokoa momba ity lohahevitra ity.
///
/// Marihina ihany koa ny syntax manokana ho an'ny `Fn` traits (oh
/// `Fn(usize, bool) -> usize`).Ireo liana amin'ny pitsopitsony ara-teknika an'ity dia afaka manondro ny [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Calling ny fanakatonana
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Mampiasà masontsivana `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // mba hahafahan'ny regex miantehitra amin'io `&str: !FnMut` io
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Manao ny fiasan'ny antso.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Ny kinalan'ny mpandraharaha antso izay mandray mpandray miovaova.
///
/// Ny tranga `FnMut` dia azo antsoina miverimberina ary mety hiovaova ny fanjakana.
///
/// `FnMut` dia ampiharina amin'ny alàlan'ny fanakatonana izay maka referable miovaova amin'ireo variable voasambotra, ary koa ny karazany rehetra izay mampihatra [`Fn`], ohatra, (safe) [function pointers] (satria `FnMut` dia supertrait an'ny [`Fn`]).
/// Ankoatr'izay, ho an'ny karazana `F` izay mampihatra `FnMut`, `&mut F` dia mampihatra `FnMut` koa.
///
/// Satria [`FnOnce`] dia supertrait an'ny `FnMut`, misy ohatra `FnMut` dia azo ampiasaina amin'ny toerana [`FnOnce`], ary satria [`Fn`] dia subtrait `FnMut`, ny tranga [`Fn`] rehetra dia azo ampiasaina amin'ny toerana andrasana `FnMut`.
///
/// Ampiasao ny `FnMut` ho voafatotra rehefa te-hanaiky ny masontsivana karazana toy ny fiasa ianao ary mila miantso azy hatrany hatrany, nefa mamela azy hiova fanjakana.
/// Raha tsy tianao ny mutate mutate, ampiasao [`Fn`] ho voafatotra;raha tsy mila miantso azy miverimberina ianao dia ampiasao [`FnOnce`].
///
/// Jereo ny [chapter on closures in *The Rust Programming Language*][book] ho an'ny sasany fanazavana bebe kokoa momba ity lohahevitra ity.
///
/// Marihina ihany koa ny syntax manokana ho an'ny `Fn` traits (oh
/// `Fn(usize, bool) -> usize`).Ireo liana amin'ny pitsopitsony ara-teknika an'ity dia afaka manondro ny [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Miantso fanidiana azo isamborana
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Mampiasà masontsivana `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // mba hahafahan'ny regex miantehitra amin'io `&str: !FnMut` io
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Manao ny fiasan'ny antso.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Ny kinovan'ny mpandraharaha antso izay mandray mpandray lanja.
///
/// Ny tranga `FnOnce` dia azo antsoina, saingy mety tsy ho voantso imbetsaka.Noho io antony io, raha ny zavatra tokana fantatra momba ny karazana dia ny fampiharana `FnOnce` dia indray mandeha ihany no azo iantsoana azy.
///
/// `FnOnce` dia ampiharina amin'ny alàlan'ny fanidiana izay mety handany ireo variable voasambotra, ary koa ny karazana rehetra izay mampihatra [`FnMut`], ohatra, (safe) [function pointers] (satria `FnOnce` dia supertrait an'ny [`FnMut`]).
///
///
/// Satria ny [`Fn`] sy [`FnMut`] dia subtraits an'ny `FnOnce`, ny ohatra [`Fn`] na [`FnMut`] dia azo ampiasaina amin'ny toerana `FnOnce` antenaina.
///
/// Ampiasao ny `FnOnce` ho voafatotra rehefa te hanaiky ny masontsivana karazana toy ny fiasa ianao ary mila miantso azy indray mandeha fotsiny.
/// Raha mila miantso ny masontsivana miverimberina ianao dia ampiasao [`FnMut`] ho voafatotra;raha mila izany koa ianao mba tsy hampiova fanjakana, ampiasao [`Fn`].
///
/// Jereo ny [chapter on closures in *The Rust Programming Language*][book] ho an'ny sasany fanazavana bebe kokoa momba ity lohahevitra ity.
///
/// Marihina ihany koa ny syntax manokana ho an'ny `Fn` traits (oh
/// `Fn(usize, bool) -> usize`).Ireo liana amin'ny pitsopitsony ara-teknika an'ity dia afaka manondro ny [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Mampiasà masontsivana `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` mandany ireo miova voasambotra, noho izany dia tsy afaka mihazakazaka mihoatra ny indray mandeha izy.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ny fiezahana hiantso `func()` indray dia hanary lesoka `use of moved value` ho an'ny `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` tsy azo antsoina intsony amin'izao fotoana izao
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // mba hahafahan'ny regex miantehitra amin'io `&str: !FnMut` io
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Ny karazana tafaverina aorian'ny fampiasan'ny mpandraharaha antso.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Manao ny fiasan'ny antso.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}