use crate::marker::Unsize;

/// Trait izay manondro fa mpanondro na fonosana ho an'ny iray izy io, izay azo anaovana unsizing amin'ny pointee.
///
/// Jereo ny [DST coercion RFC][dst-coerce] sy [the nomicon entry on coercion][nomicon-coerce] raha mila fanazavana fanampiny.
///
/// Ho an'ireo karazana pointer builtin, ny tondro mankany `T` dia hanery ny tondro mankany `U` raha `T: Unsize<U>` amin'ny alàlan'ny fanovana ny tondro manify mankany amin'ny tondro tavy.
///
/// Ho an'ny karazana fanao manokana, ny fanerena eto dia miasa amin'ny alàlan'ny fanerena `Foo<T>` ka hatramin'ny `Foo<U>` fa misy impl `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Ny imply toy izany dia tsy azo soratana raha tsy manana sehatra tsy phantomdata tokana misy `T` i `Foo<T>`.
/// Raha `Bar<T>` ny karazana an'io saha io dia tsy maintsy misy ny fampiharana `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Ny coercion dia hiasa amin'ny alàlan'ny fanerena ny sahan `Bar<T>` ho `Bar<U>` ary ny famenoana ireo saha sisa tavela amin'ny `Foo<T>` mba hamoronana `Foo<U>`.
/// Ity dia hitrandraka mahomby amin'ny sehatry ny tondro ary hanery izany.
///
/// Amin'ny ankapobeny, ho an'ny tondro marani-tsaina dia hampihatra `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ianao, miaraka amina `?Sized` tsy voatery voafatotra amin'ny `T` mihitsy.
/// Ho an'ireo karazana fonosana izay mampiditra mivantana ny `T` toy ny `Cell<T>` sy `RefCell<T>` dia azonao atao ny mampihatra mivantana ny `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Io dia hamela ny fanerena karazana toy ny `Cell<Box<T>>` miasa.
///
/// [`Unsize`][unsize] dia ampiasaina hanamarihana ireo karazana izay azo terena amin'ny DST raha misy ambadika.Mampihatra azy ho azy ny mpamorona.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ity dia ampiasaina amin'ny fiarovana ny zavatra, hanamarinana raha azo alefa ny karazana mpandray fomba iray.
///
/// Ohatra iray amin'ny fampiharana ny trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}