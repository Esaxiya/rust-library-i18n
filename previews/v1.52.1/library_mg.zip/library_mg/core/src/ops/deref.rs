/// Nampiasaina ho an'ny asa fanidiana dereferencing tsy azo ovaina, toa ny `*v`.
///
/// Ankoatry ny fampiasàna azy amin'ny hetsika dereferencing miharihary amin'ny mpikirakira (unary) `*` amin'ny toe-javatra tsy miova, `Deref` koa dia ampiasain'ny mpamongady amin'ny toe-javatra maro.
/// Ity rafitra ity dia antsoina hoe ['`Deref` coercion'][more].
/// Amin'ny toe-javatra azo ovaina, [`DerefMut`] no ampiasaina.
///
/// Ny fampiharana `Deref` ho an'ny tondro maranitra dia mahatonga ny fidirana amin'ny angon-drakitra ao aoriany ho mora, ka izany no antony ampiharan'izy ireo ny `Deref`.
/// Etsy ankilany, ny lalàna momba ny `Deref` sy [`DerefMut`] dia natao manokana handraisana ireo tondro marani-tsaina.
/// Noho izany,**: Deref` tokony ho ampiharina ihany no sahaza ho an'ny mahay** mba tsy ho very hevitra.
///
/// Noho ny antony mitovy amin'izany,**ity trait tsy tokony hahomby**.Ny tsy fahombiazana mandritra ny fitsinjaram-pahefana dia mety hampikorontana indrindra rehefa iantsoana an-tsokosoko ny `Deref`.
///
/// # Misimisy kokoa momba ny fanerena `Deref`
///
/// Raha `T` dia mampihatra `Deref<Target = U>`, ary `x` dia soatoavin'ny karazana `T`, dia:
///
/// * Amin'ny toe-javatra tsy miova, `*x` (izay ny `T` dia sady tsy referansa no tsy tondroina manta) dia mitovy amin'ny `* Deref::deref(&x)`.
/// * Soatoavin'ny karazany `&T` dia nanery ny soatoavina ny karazana `&U`
/// * `T` mampihatra implicitely ny fomba (immutable) rehetra an'ny karazana `U`.
///
/// Raha mila tsipiriany misimisy kokoa dia tsidiho ny [the chapter in *The Rust Programming Language*][book] ary koa ny fizarana fizarana ao amin'ny [the dereference operator][ref-deref-op], [method resolution] ary [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Str iray misy sehatra tokana izay azo alefa amin'ny alàlan'ny fanesorana ny strukt.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ny karazana vokatr'izany aorian'ny fitsinjaram-pahefana.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Fanadinadinana ny sanda.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Ampiasaina amin'ny asa fanodinana dereferencing azo ovaina, toy ny amin'ny `*v = 1;`.
///
/// Ankoatry ny fampiasana amin'ny hetsika dereferencing miharihary amin'ny mpikirakira (unary) `*` amin'ny toe-javatra azo ovaina, `DerefMut` koa dia ampiasain'ny mpamongady amin'ny toe-javatra maro.
/// Ity rafitra ity dia antsoina hoe ['`Deref` coercion'][more].
/// Amin'ny toe-javatra tsy miova, [`Deref`] no ampiasaina.
///
/// Ny fampiharana `DerefMut` ho an'ny tondro marani-tsaina dia mahatonga ny fanovana ny angon-drakitra ao aoriany ho mora, ka izany no antony ampiharan'izy ireo ny `DerefMut`.
/// Etsy ankilany, ny lalàna momba ny [`Deref`] sy `DerefMut` dia natao manokana handraisana ireo tondro marani-tsaina.
/// Noho io antony io,**`DerefMut` dia tokony hampiharina fotsiny amin'ny tondro marani-tsaina** hisorohana ny fikorontanana.
///
/// Noho ny antony mitovy amin'izany,**ity trait tsy tokony hahomby**.Ny tsy fahombiazana mandritra ny fitsinjaram-pahefana dia mety hampikorontana indrindra rehefa iantsoana an-tsokosoko ny `DerefMut`.
///
/// # Misimisy kokoa momba ny fanerena `Deref`
///
/// Raha `T` dia mampihatra `DerefMut<Target = U>`, ary `x` dia soatoavin'ny karazana `T`, dia:
///
/// * Amin'ny toe-javatra azo ovaina, ny `*x` (izay ny `T` dia sady tsy referansa no tsy tondroina manta) dia mitovy amin'ny `* DerefMut::deref_mut(&mut x)`.
/// * Ny soatoavin'ny karazana `&mut T` dia terena amin'ny sanda `&mut U`
/// * `T` mampihatra implicitely ny fomba (mutable) rehetra an'ny karazana `U`.
///
/// Raha mila tsipiriany misimisy kokoa dia tsidiho ny [the chapter in *The Rust Programming Language*][book] ary koa ny fizarana fizarana ao amin'ny [the dereference operator][ref-deref-op], [method resolution] ary [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Str iray misy saha tokana azo ovaina amin'ny alàlan'ny fanalefahana ny rafitra.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Azo inoana fa manafoana ny sandany.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Manondro fa ny strat dia azo ampiasaina ho mpandray fomba, raha tsy misy ny endri-`arbitrary_self_types`.
///
/// Izy io dia ampiharin'ireo karazana stdlib toy ny `Box<T>`, `Rc<T>`, `&T`, ary `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}