/// Kaody manokana ao anatin'ny mpanimba.
///
/// Rehefa tsy ilaina intsony ny sanda dia hampandeha "destructor" amin'io zara io ny Rust.
/// Ny fomba mahazatra indrindra izay tsy ilaina intsony ny soatoavina dia rehefa lasa ivelan'ny sehatra.Ireo mpandrava dia mety mbola hihazakazaka amin'ny toe-javatra hafa, fa hifantoka amin'ny sakany amin'ireo ohatra eto isika.
/// Raha te hahalala momba ny sasany amin'ireo tranga hafa ireo dia zahao azafady ny fizarana [the reference] momba ireo mpanimba.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ity mpandrava ity dia misy singa roa:
/// - Antso mankany `Drop::drop` ho an'io sanda io, raha ity `Drop` trait manokana ity dia ampiharina amin'ny karazany.
/// - "drop glue" namboarina ho azy izay miantso recursively ireo mpandrava ny saha rehetra amin'io sanda io.
///
/// Satria miantso ho azy ireo mpanimba ny faritra rehetra misy ny Rust, dia tsy mila mampihatra `Drop` amin'ny ankamaroan'ny tranga ianao.
/// Saingy misy tranga sasany izay ilana azy, ohatra ho an'ireo karazana izay mitantana mivantana loharano iray.
/// Mety ho fahatsiarovana izany loharano izany, mety ho mpanoritsoritra rakitra, mety ho tobin'ny tamba-jotra.
/// Raha vantany vao tsy ampiasaina intsony ny sandan'io karazana io dia tokony "clean up" ny loharano amin'ny alàlan'ny famotsorana ny memoara na ny fanidiana ny fisie na ny socket.
/// Ity dia asan'ny mpanimba, ary noho izany ny asan'ny `Drop::drop`.
///
/// ## Examples
///
/// Mba hahitana ireo mpanimba amin'ny asany, andao jerena ity programa manaraka ity:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust dia hiantso `Drop::drop` voalohany ho an'ny `_x` ary avy eo ho an'ny `_x.one` sy `_x.two`, midika izany fa hanonta ny fihazakazahana ity
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Na dia esorintsika aza ny fampiharana ny `Drop` ho an'ny `HasTwoDrop` dia mbola antsoina ihany ireo mpanimba ny sahany.
/// Izany dia hiteraka
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Tsy afaka miantso ny tenanao `Drop::drop`
///
/// Satria `Drop::drop` no ampiasaina hanadiovana sanda iray, mety hampidi-doza ny fampiasana an'io sanda io taorian'ny niantsoana ny fomba.
/// Satria tsy mandray ny fampiasa ao aminy ny `Drop::drop`, Rust dia misoroka ny fampiasana diso amin'ny alàlan'ny tsy famelana anao hiantso `Drop::drop` mivantana.
///
/// Raha lazaina amin'ny teny hafa, raha nanandrana niantso an-tariby `Drop::drop` ianao tamin'ity ohatra etsy ambony ity dia hahazo lesoka amin'ny mpanangona ianao.
///
/// Raha tianao ny hiantsoana mazava ny mpanimba ny sanda iray, [`mem::drop`] dia azo ampiasaina ho solony.
///
/// [`mem::drop`]: drop
///
/// ## Filaharana milatsaka
///
/// Iza amin'ireo `HasDrop` roa no latsaka voalohany?Ho an'ny kofehy dia mitovy amin'ny baiko nambarany ihany: `one` voalohany, avy eo `two`.
/// Raha te hanandrana izany ianao, dia azonao atao ny manova ny `HasDrop` etsy ambony mba hahitana data vitsivitsy, toy ny integer, ary avy eo ampiasainao ao amin'ny `println!` ao anatin'ny `Drop`.
/// Ity fihetsika ity dia iantohan'ny fiteny.
///
/// Tsy toy ny amin'ny tsangantsangana, ny variables eo an-toerana dia aidina milahatra:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Hatao pirinty ity
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Azafady mba jereo ny [the reference] ho an'ny lalàna feno.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ary `Drop` manokana
///
/// Tsy azonao atao ny mampihatra ny [`Copy`] sy `Drop` amin'ny karazany mitovy.Ireo karazana `Copy` dia voarohirohy amin'ny alàlan'ny mpamorona, ka sarotra be ny maminavina hoe rahoviana, ary impiry no hamonoana ireo mpanimba.
///
/// Araka izany, ireo karazana ireo dia tsy afaka manana mpanimba.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Manatanteraka ny mpanimba an'ity karazana ity.
    ///
    /// Ity fomba ity dia antsoina hoe implicité rehefa mivoaka ny sanda ary tsy azo antsoina mazava (izany no error compiler [E0040]).
    /// Na izany aza, ny asan'ny [`mem::drop`] ao amin'ny prelude dia azo ampiasaina hiantsoana ny fampiharana ny `Drop` an'ny adihevitra.
    ///
    /// Rehefa nantsoina io fomba io dia mbola tsy nifindrana ny `self`.
    /// Tsy vita izany rehefa vita ny fomba.
    /// Raha tsy izany no izy, dia ho referansa mihantona ny `self`.
    ///
    /// # Panics
    ///
    /// Raha toa ka miantso `drop` ny [`panic!`] rehefa miala sasatra izy, dia mety hesorina ny [`panic!`] rehetra amin'ny fampiharana `drop`.
    ///
    /// Mariho fa na dia io panics io aza dia heverina fa haidina;
    /// tsy tokony hiteraka antso i `drop` ianao.
    /// Mazava ho azy fa ny mpitambatra no mitantana azy io, fa rehefa mampiasa kaody tsy azo antoka dia indraindray mety hitranga tsy fanahy iniana, indrindra rehefa mampiasa [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}