use crate::marker::Unpin;
use crate::pin::Pin;

/// Vokatry ny famerenana amin'ny laoniny ny generator.
///
/// Izany enum dia niverina avy tany `Generator::resume` fomba sy manondro ny mety ho fiverenana soatoavina ny gropy.
/// Amin'izao fotoana izao dia mifandraika amin'ny teboka fampiatoana (`Yielded`) na teboka famaranana (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Mihantona miaraka amina sanda ny generator.
    ///
    /// Ity fanjakana ity dia manondro fa nisy herinaratra naato, ary matetika dia mifanaraka amin'ny fanambarana `yield`.
    /// Ny sanda omena amin'ity variana ity dia mifanaraka amin'ny fomba fiteny ampitaina amin'ny `yield` ary mamela ny mpamorona manome lanja isaky ny manome.
    ///
    ///
    Yielded(Y),

    /// Ny generator dia nahavita sanda miverina.
    ///
    /// Ity fanjakana ity dia manondro fa ny mpamokatra herinaratra dia nahavita famonoana tamin'ny sanda omena.
    /// Raha vantany vao niverina ny mpanamboatra `Complete` dia heverina ho hadisoana programmer hiantsoana `resume` indray.
    ///
    Complete(R),
}

/// Ny trait ampiharin'ireo karazana mpamorona builtin.
///
/// Generators, izay matetika antsoina koa hoe coroutines, dia endri-pitenenana andrana amin'ny fiteny Rust.
/// Nampiana generator [RFC 2033] amin'izao fotoana izao dia natao hanomezana sakana ho an'ny syntax async/await fa mety hitatra ihany koa amin'ny fanomezana famaritana ergonomika an'ireo iteratera sy primitives hafa.
///
///
/// Ny syntax sy semantika ho an'ny mpamokatra herinaratra dia miovaova ary mitaky RFC fanampiny hanamafisana.Amin'izao fotoana izao anefa, ny syntax dia toy ny fanidiana:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Betsaka ny antontan-taratasy momba ny herinaratra hita ao amin'ilay boky miovaova.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Ny karazana lanja omena an'ity generator ity.
    ///
    /// Ity karazana mifandraika ity dia mifanaraka amin'ny fitenenana `yield` sy ny sanda avela averina isaky ny manome generator.
    ///
    /// Ohatra, ny iterator-as-a-generator dia mety hanana an'io karazana `T` io, ilay karazana izay miverimberina.
    ///
    type Yield;

    /// Ny karazana sanda miverina amin'ity generator ity.
    ///
    /// Izany dia mifanitsy amin'ny karazana niverina avy amin'ny mpamorona, na misy ny fanambarana `return` na ny hoe implicitement farany an'ny generator ara-bakiteny.
    /// Ohatra, futures dia hampiasa izany ho `Result<T, E>` satria maneho ny future vita.
    ///
    ///
    type Return;

    /// Manohy ny fanatanterahana ity generator ity.
    ///
    /// Ity asa ity dia hanohy ny famonoana ny generator na hanomboka ny famonoana raha mbola tsy nanao izany.
    /// Ity antso ity dia hiverina any amin'ny teboka fampiatoana farany an'ny generator, hanohy ny famonoana hatramin'ny `yield` farany.
    /// Ny generator dia hanohy hanatanteraka mandra-pahatongan'ny vokatra na ny fiverenany, amin'izay fotoana izay dia hiverina ity asa ity.
    ///
    /// # Miverina amin'ny sarobidy
    ///
    /// Ny enum `GeneratorState` niverina avy amin'ity asa ity dia manondro ny fanjakana misy ny generator rehefa miverina.
    /// Raha miverina ny variant `Yielded` dia nahatratra ny teboka fampiatoana ny mpamokatra ary nomena ny isa.
    /// Ireo motera amin'ity fanjakana ity dia azo alaina indray amin'ny fotoana manaraka.
    ///
    /// Raha averina `Complete` dia vita tanteraka ny mpamokatra amin'ny sanda omena.Tsy mety ny famerenana amin'ny laoniny ny generator.
    ///
    /// # Panics
    ///
    /// Ity fiasa ity dia mety panic raha antsoina aorian'ny fiverenan'ny `Complete` variana teo aloha.
    /// Raha gropy literals amin'ny fiteny azo antoka fa ho panic amin'ny resuming rehefa afaka `Complete`, izany dia tsy azo antoka ho an'ny rehetra implementations ny `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}