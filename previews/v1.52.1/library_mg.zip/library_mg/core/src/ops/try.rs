/// trait amin'ny fanaingoana ny fihetsiky ny mpikirakira `?`.
///
/// Ny karazana fampiharana `Try` dia iray izay manana fomba kanônika hijerena azy amin'ny resaka dichotomy success/failure.
/// Ity trait dia mamela ny famoahana ireo soatoavina mahomby na tsy fahombiazana avy amin'ny tranga misy ary mamorona tranga vaovao avy amin'ny lanonana fahombiazana na tsy fahombiazana.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Ny karazana an'io sanda io rehefa heverina fa mahomby.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Ny karazana an'io sanda io rehefa heverina fa tsy nahomby.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Mihatra amin'ny mpandraharaha "?".Ny fiverenan'ny `Ok(t)` dia midika fa ny fanatanterahana dia tokony hitohy ara-dalàna, ary ny valin'ny `?` dia ny sanda `t`.
    /// Ny fiverenan'ny `Err(e)` dia midika fa ny famonoana dia tokony branch mankany anaty anatiny indrindra `catch`, na miverina amin'ny asany.
    ///
    /// Raha niverina ny valiny `Err(e)`, ny sanda `e` dia ho "wrapped" amin'ny karazana fiverenan'ny habaka mihidy (izay tsy maintsy mampihatra `Try`).
    ///
    /// Manokana, ny sanda `X::from_error(From::from(e))` dia miverina, izay `X` no karazana fiverenan'ny fonosana fonosana.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Fonosy sanda diso mba hananganana ny valiny mitambatra.
    /// Ohatra, `Result::Err(x)` sy `Result::from_error(x)` dia mitovy.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Fonosy sanda OK mba hananganana ny valiny mitambatra.
    /// Ohatra, `Result::Ok(x)` sy `Result::from_ok(x)` dia mitovy.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}