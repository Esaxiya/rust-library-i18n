//! Ny prelude mahery
//!
//! Ity modely ity dia natao ho an'ireo mpampiasa libcore izay tsy mifandray amin'ny libstd ihany koa.
//! Ity modely ity dia ampidirina amin'ny alàlan'ny default raha `#![no_std]` no ampiasaina amin'ny fomba mitovy amin'ny prelude an'ny tranomboky mahazatra.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Ny kinova 2015 an'ny prelude fototra.
///
/// Jereo ny [module-level documentation](self) raha mila fanazavana fanampiny.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ny kinova 2018 an'ny prelude fototra.
///
/// Jereo ny [module-level documentation](self) raha mila fanazavana fanampiny.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Ny kinova 2021 an'ny prelude fototra.
///
/// Jereo ny [module-level documentation](self) raha mila fanazavana fanampiny.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Manampia zavatra bebe kokoa.
}