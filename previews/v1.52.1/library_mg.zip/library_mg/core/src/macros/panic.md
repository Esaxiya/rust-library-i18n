Panics kofehy ny amin'izao fotoana izao.

Izany dia mamela ny fandaharana mba ajanona avy hatrany ary manome tsikera ny mpiantso ny fandaharana.
`panic!` tokony hampiasaina rehefa misy fandaharana iray mahatratra unrecoverable fanjakana.

Izany no tonga lafatra macro lalana ny filazana toe-piainana ao amin'ny fehezan-dalàna sy ny ohatra amin'ny fitsapana.
`panic!` mifamatotra akaiky amin'ny `unwrap` fomba na [`Option`][ounwrap] sy [`Result`][runwrap] enums.
Samy miantso implementations `panic!` rehefa aroso ho [`None`] na [`Err`] variants.

Rehefa mampiasa `panic!()` dia afaka milaza ny laha-daza payload, izay efa vita mampiasa ny [`format!`] Syntaxe.
Izany payload no ampiasaina rehefa mampiditra ny panic ho any amin'ny fiantsoana Rust kofehy, ka nahatonga ny kofehy ho panic tanteraka.

Ny fitondran-tenan'ny default `std` hook, izany hoe
ny kaody izay mandeha mivantana aorian'ny fiantsoana ny panic dia ny fanontana ny karama hafatra amin'ny `stderr` miaraka amin'ny fampahalalana file/line/column an'ny antso `panic!()`.

Afaka handresy ny panic hook mampiasa [`std::panic::set_hook()`].
Ao anatin'ny hook a panic dia azo idirana ho `&dyn Any + Send`, izay misy `&str` na `String` ho an'ny fiantsoana `panic!()` mahazatra.
To panic amin'ny zava-dehibe hafa karazana hafa, [`panic_any`] azo ampiasaina.

[`Result`] enum dia matetika vahaolana tsara kokoa ho sitrana avy tamin'ny fahadisoana noho ny fampiasana ny `panic!` macro.
Zavatra macro tokony hampiasaina mba tsy mandeha mampiasa ny soatoavina diso, toy ny loharanom-baovao avy any ivelany.
Tsipiriany momba fahadisoana fikirakirana dia hita ao amin'ny [book].

Jereo koa ny macro [`compile_error!`], noho ny fitaizana fahadisoana mandritra ny fanangonana.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Fanatanterahana ankehitriny

Raha ny tena kofehy panics dia hamarana ny kofehy rehetra sy hamarana ny fandaharana amin'ny fehezan-dalàna `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





