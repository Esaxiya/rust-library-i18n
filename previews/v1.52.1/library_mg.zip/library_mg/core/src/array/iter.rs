//! Mamaritra ny mpamaky `IntoIter` ho an'ny arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A by-danja [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ity no laharana izay andalovantsika.
    ///
    /// Ireo singa misy index `i` izay tsy mbola nahazoana `alive.start <= i < alive.end` ary dia fidirana tandahatra manan-kery.
    /// Ireo singa amin'ny indices `i < alive.start` na `i >= alive.end` efa nanolotra sahady sy ny tsy ho jerena intsony!Ireo singa maty ireo dia mety ho ao anaty fanjakana iray tsy voatanisa mihitsy!
    ///
    ///
    /// Ka ny invariants dia:
    /// - `data[alive]` velona (izany hoe misy singa mety)
    /// - `data[..alive.start]` ary `data[alive.end..]` nefa maty ihany (izany hoe ny singa no efa namaky sy ny tsy ho nikasika intsony!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Ireo singa ao amin'ny `data` izay mbola tsy voaloa.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Mamorona iterator vaovao amin'ny `array` nomena.
    ///
    /// *Fanamarihana*: ity fomba ity dia mety esorina amin'ny future, aorian'ny [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Ny karazana `value` dia `i32` eto, fa tsy `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAFETY: azo antoka ny transmute eto.Ireo tahirin-kevitra momba ny `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` dia azo antoka fa hitovy habe sy fampifanarahana
        // > toy ny `T`.
        //
        // Ny Docs mihitsy aza mampiseho transmute avy amin'ny nahay ny `MaybeUninit<T>` ho amin'ny fihaingoana ny `T`.
        //
        //
        // Miaraka amin'izany dia manome fahafaham-po ireo manasa-maso ity fanombohana ity.

        // FIXME(LukasKalbertodt): tena mampiasa `mem::transmute` eto, raha vantany vao miasa amin'ny generic const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Mandra-pahatongan'izany dia afaka mampiasa `mem::transmute_copy` isika hamoronana kopia bitwise ho karazana hafa, avy eo hadinoy ny `array` mba tsy hahena.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Miverina ny loha tsy mety miova silaka zavatra rehetra izay tsy mbola nisy nanolotra.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAFETY: Fantatsika fa ny singa rehetra ao anatin'ny `alive` dia voazaha ara-dalàna.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Miverina ny mutable silaka zavatra rehetra izay tsy mbola nisy nanolotra.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAFETY: Fantatsika fa ny singa rehetra ao anatin'ny `alive` dia voazaha ara-dalàna.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Raiso avy eo aloha ny fanondroana manaraka.
        //
        // Ny fampitomboana ny `alive.start` amin'ny 1 dia mitazona ny invariant momba ny `alive`.
        // Na izany aza, noho izany fiovana, nandritra ny fotoana fohy, ny velona faritra dia tsy `data[alive]` intsony, fa `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Vakio ny singa avy amin'ny laharana.
            // Famonjena, `idx` dia fanondroana ho any amin'ny faritra "alive" teo aloha ny
            // filaharana.Ny famakiana an'ity singa ity dia midika fa ny `data[idx]` dia heverina ho maty ankehitriny (izany hoe aza mikasika).
            // Araka ny `idx` no fanombohan'ny ny velona-faritra, ny velona faritra ankehitriny `data[alive]` indray, indray invariants rehetra.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Raiso avy any aoriana ny fanondroana manaraka.
        //
        // Ny fihenan'ny `alive.end` amin'ny 1 dia mitazona ny invariant momba ny `alive`.
        // Na izany aza, noho io fiovana io, vetivety dia tsy `data[alive]` intsony ny faritra velona fa `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Vakio ny singa avy amin'ny laharana.
            // Famonjena, `idx` dia fanondroana ho any amin'ny faritra "alive" teo aloha ny
            // filaharana.Ny famakiana an'ity singa ity dia midika fa ny `data[idx]` dia heverina ho maty ankehitriny (izany hoe aza mikasika).
            // Araka ny `idx` no faran'ny velona-faritra, ny velona faritra ankehitriny `data[alive]` indray, indray invariants rehetra.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: azo antoka ity: miverina amin'ny laoniny ilay sombin-tsolika `as_mut_slice`
        // ireo singa izay mbola tsy nafindra ary mbola hajanona.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Tsy hilentika mihitsy noho ny invariant `velona.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Ilay iteratera dia mitatitra ny halavany marina.
// "alive" ny isan'ny singa (izay mbola ho amidy) dia ny halavan'ny `alive` ny isan-karazany.
// Io kiheba dia decremented ny lavany in na `next` na `next_back`.
// Io dia mihena hatrany amin'ny 1 amin'ireo fomba ireo, fa raha averina `Some(_)` fotsiny.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Mariho, tsy mila mifanandrify amin'ilay velarana velona mitovy mihitsy isika, amin'izay isika vao afaka clone ho offset 0 na aiza na aiza `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone ny singa velona rehetra.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Manorata klone ao anaty laharana vaovao, avy eo havaozy ny faritra velona.
            // Raha Fanamboarana panics, isika Mitete Ho tsara ny zavatra teo aloha.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ataovy pirinty fotsiny ireo singa izay mbola tsy voa: tsy afaka miditra amin'ireo singa voaangona intsony isika.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}