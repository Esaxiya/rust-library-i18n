#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Ahitana famaritana firafitra ho an'ny firafitry ny karazana built-in compiler.
//!
//! Izy ireo dia azo ampiasaina ho lasibatry ny fandefasana amina kaody tsy azo antoka amin'ny fanodikodinana mivantana ireo sary manta.
//!
//!
//! Ny famaritana azy ireo dia tokony hifanaraka amin'ny ABI voafaritra ao amin'ny `rustc_middle::ty::layout` foana.
//!

/// Ny solontenan'ny zavatra trait toy ny `&dyn SomeTrait`.
///
/// Izany struct manana ny mitovy karazana fisehon'ny ho toa `&dyn SomeTrait` sy `Box<dyn AnotherTrait>`.
///
/// `TraitObject` dia azo antoka fa mifanaraka amin'ny layout, fa tsy ny karazana trait (ohatra, ny saha dia tsy azo idirana mivantana amin'ny `&dyn SomeTrait`) ary tsy voafehiny koa ny fisehosehoana (ny fanovana ny famaritana dia tsy hanova ny fisian'ny `&dyn SomeTrait`).
///
/// Misy ihany natao ho ampiasain'ny mampidi-doza fehezan-dalàna izay mila fitaovana ny ambaratonga ambany-antsipirihany.
///
/// Tsy misy fomba hijerena ireo zavatra trait rehetra amin'ny ankapobeny, noho izany ny fomba tokana hamoronana soatoavina an'ity karazana ity dia ny fiasa toa ny [`std::mem::transmute`][transmute].
/// Toy izany koa, ny fomba tokana ahafahana mamorona tena trait avy amin'ny sanda `TraitObject` dia amin'ny `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ny famolavolana zavatra trait misy karazany tsy mifanaraka aminy-toerana iray izay tsy mifanaraka amin'ny karazana soatoavina asehon'ny mpanondro ny data-dia mety hitarika fihetsika tsy voafaritra.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ohatra trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // avelao ny compiler hanao zavatra trait
/// let object: &dyn Foo = &value;
///
/// // jereo ny fisehoana manta
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ny data pointer dia ny adiresy `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // manamboatra zavatra vaovao, manondro `i32` hafa, mitandrina amin'ny fampiasana ny latabatra `i32` avy amin'ny `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // tokony handeha izy io sahala amin'ny nanamboarantsika zavatra trait avy tao `other_value` mivantana
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}