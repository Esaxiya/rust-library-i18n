#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Fitaovana mifandraika amin'ny fantsom-pifandraisana (FFI) fampiasa ivelany.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Mitovy amin'ny C ny `void` karazana rehefa ampiasaina ho toy ny [pointer].
///
/// Raha ny marina, `*const c_void` dia mitovy amin'ny C ny `const void*` sy `*mut c_void` dia mitovy amin'ny C ny `void*`.
/// Izay nanao hoe: Ity no * + ny tsy mitovy amin'ny C ny `void` miverina karazana, izay ny `()` Rust karazana.
///
/// Mba hanomezana modely ireo tondro amin'ny karazana opaque ao amin'ny FFI, mandra-piorenan'ny `extern type` dia asaina mampiasa fonosana newtype manodidina ny fipetrahana byte foana.
///
/// Jereo ny [Nomicon] ho an'ny antsipirihany.
///
/// Afaka mampiasa `std::os::raw::c_void` ny olona iray raha te-hanohana ny mpanangona Rust taloha hatramin'ny 1.1.0.
/// Taorian'ny Rust 1.30.0, naverina navoaka indray io famaritana io.
/// Raha mila fanazavana fanampiny, dia vakio [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, fa LLVM mamantatra ny karazana sy manondro foana ny fanitarana miasa toy ny malloc(), dia mila manana izany nisolo tena tahaka ny i8 * Amin'ny LLVM bitcode.
// Ny enum ampiasaina eto dia miantoka izany ary manakana ny fampiasana tsy diso ny karazana "raw" amin'ny alàlan'ny fanovana tsy miankina irery ihany.
// Mila variants roa, satria ny compiler nitaraina momba ny repr toetra raha tsy izany dia mila iray, fara fahakeliny Variant toy raha izany, ny enum ho hisy mponina intsony, ary toy izany, fara fahakeliny, dereferencing sahaza ho Ub.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Fampiharana fototra `va_list`.
// WIP no anarany, mampiasa `VaListImpl` amin'izao fotoana izao.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant over `'f`, ka ny zavatra `VaListImpl<'f>` dia mifamatotra amin'ny faritry ny fiasa voafaritra ao
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Fampiharana ABI an'ny `va_list`.
/// Jereo ny [AArch64 Procedure Call Standard] raha mila fanazavana fanampiny.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Fampiharana ABI an'ny `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Fampiharana ABI an'ny `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Fonosana ho an'ny `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Avadiho ny `VaListImpl` ho `VaList` izay mifanaraka amin'ny binary miaraka amin'i C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Avadiho ny `VaListImpl` ho `VaList` izay mifanaraka amin'ny binary miaraka amin'i C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Ny VaArgSafe trait ilaina ampiasaina amin'ny interface-bahoaka, na izany aza, ny trait aza tsy ho afaka ny ho ampiasaina ivelan'ny Module ity.
// Ny famelana ireo mpampiasa hampihatra ny trait ho an'ny karazana vaovao (amin'izay mamela ny intrinsika va_arg hampiasa amin'ny karazana vaovao) dia mety hiteraka fihetsika tsy voafaritra.
//
// FIXME(dlrobertson): Raha te hampiasa ny VaArgSafe trait amin'ny sehatry ny daholobe nefa koa azo antoka fa tsy azo ampiasaina any an-kafa, ny trait dia mila ampahibemaso ao anatin'ny mody tsy miankina.
// Raha vantany vao nampiharina ny RFC 2145 dia jereo ny fanatsarana izany.
//
//
//
//
mod sealed_trait {
    /// Trait izay mamela ireo karazana navela ampiasaina amin'ny [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Mandrosoa amin'ny arg manaraka.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // Famonjena, dia tsy maintsy manohana ny mpiantso ny fiarovana ho an'ny `va_arg` fifanarahana.
        unsafe { va_arg(self) }
    }

    /// Adikao ny `va_list` amin'ny toerana misy anao ankehitriny.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // Famonjena, dia tsy maintsy manohana ny mpiantso ny fiarovana ho an'ny `va_end` fifanarahana.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // Famonjena, dia manorata any amin'ny `MaybeUninit`: Izany no initialized sy `assume_init` no ara-dalàna
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ity dia tokony hiantso `va_end`, fa tsy misy fomba madio
        // manome toky fa ny `drop` dia tafiditra ao anatin'ny mpiantso azy foana, noho izany ny `va_end` dia antsoina mivantana amin'ny fiasa mitovy amin'ilay `va_copy` mifanaraka aminy.
        // `man va_end` dia milaza fa C mitaky izany, ary LLVM Raha jerena ankapobeny dia manaraka ny C semantics, ka ilaintsika mba hahazoana antoka fa `va_end` dia foana hoe avy mitovy asa araka ny `va_copy`.
        //
        // Raha mila tsipiriany, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Izy io dia miasa aloha, satria `va_end` dia tsy misy idirany amin'ireo lasibatra LLVM rehetra ankehitriny.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Aringano ny lisitra `ap` aorian'ny fanombohana amin'ny `va_start` na `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Adikao ny toerana misy ny arglist `src` amin'ny arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Entana miady ny karazana `T` avy amin'ny `va_list` increment `ap` sy ny tohan-kevitra `ap` manondro.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}