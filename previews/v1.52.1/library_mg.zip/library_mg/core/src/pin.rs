//! Ireo karazana manaparitaka data amin'ny toerana misy azy ho fahatsiarovana.
//!
//! Ilaina indraindray ny fananana zavatra azo antoka fa tsy hihetsika, amin'ny heviny fa tsy miova ny fametrahana azy ireo ho fahatsiarovana ary azo ianteherana amin'izany.
//! Ohatra iray voalohany amin'ny tranga toy izany ny fananganana fomba fiasa tena, satria ny fanetsehana zavatra iray misy tondro mankany aminy dia hanafoanana azy ireo, izay mety hiteraka fihetsika tsy voafaritra.
//!
//! Amin'ny ambaratonga avo, [`Pin<P>`] dia manome antoka fa ny pointee an'ny karazana pointer `P` dia manana toerana marim-pototra ao anaty fitadidiana, midika izany fa tsy azo afindra amin'ny toeran-kafa izany ary ny fitadidiany dia tsy azo atrehana mandra-pialany.Holazaintsika fa ny pointee no "pinned".Mihalasa misimisy kokoa ny raharaha rehefa mifanakalo hevitra momba ireo karazana izay atambatra ny angona tsy voafintina;[see below](#projections-and-structural-pinning) raha mila fanazavana fanampiny.
//!
//! Ny toerana misy anao, ny karazana rehetra ao Rust dia mitsingevana.
//! Ny Rust dia mamela ny fandefasana isa-soatoavina ny karazana rehetra, ary ireo karazana smart-pointer mahazatra toy ny [`Box<T>`] sy `&mut T` dia mamela ny fanoloana sy famindrana ireo soatoavina fonosin'izy ireo: afaka mivoaka amin'ny [`Box<T>`] ianao, na afaka mampiasa [`mem::swap`].
//! [`Pin<P>`] mamono karazana pointer `P`, ka [`Pin`]`<`[`Box`]`<T>>`miasa toy ny mahazatra
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box````<T>> `nilatsaka, toy izany koa ny ao anatiny, ary tonga ny fahatsiarovana
//!
//! nifampiraharaha.Toy izany koa ny [`Pin`]`<&mut T>` dia mitovy amin'ny `&mut T`.Na izany aza, [`Pin<P>`] dia tsy mamela ny mpanjifa hahazo [`Box<T>`] na `&mut T` hametahana angona, izay milaza fa tsy afaka mampiasa fiasa toy ny [`mem::swap`] ianao:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` mila `&mut T`, saingy tsy azontsika izany.
//!     // Tafahitsoka izahay, tsy afaka mamadika ny atiny amin'ireo andinin-tsoratra masina ireo.
//!     // Azontsika atao ny mampiasa `Pin::get_unchecked_mut`, saingy tsy azo antoka izany noho ny antony iray:
//!     // tsy mahazo mampiasa azy io isika amin'ny famindrana zavatra avy ao amin'ny `Pin`.
//! }
//! ```
//!
//! Ilaina ny mamerina fa [`Pin<P>`]*tsy* manova ny zava-misy fa ny compiler Rust dia mihevitra ny karazany rehetra mihetsika.[`mem::swap`] dia miantso ho an'ny `T` rehetra.Fa kosa, [`Pin<P>`] dia manakana ny *soatoavina* sasany (tondroin'ny tondro nopetahany [`Pin<P>`]) tsy hohetsehina amin'ny alàlan'ny tsy ahafahana miantso fomba mitaky `&mut T` amin'izy ireo (toy ny [`mem::swap`]).
//!
//! [`Pin<P>`] dia azo ampiasaina hanamboarana ny karazana pointer `P`, ary toy izany no ifandraisany amin'ny [`Deref`] sy [`DerefMut`].[`Pin<P>`] izay `P: Deref` dia tokony ho raisina ho "`P`-style pointer" amin'ny `P::Target` voafintina-koa, [`Pin`]`<`[`Box`]``<T>>`dia tondro iray an'ny `T` voahidy, ary [`Pin`] `<` [`Rc`]` `<T>>: Dia voaisa boky-manondro ny mipaingotra `T`.
//! Fa correct, dia miantehitra amin'ny [`Pin<P>`] ny implementations ny [`Deref`] sy [`DerefMut`] tsy hifindra avy ny `self` fikirana, ary mbola hiverina ihany ny manondro ny mipaingotra antontan-kevitra, rehefa tsy eo amin'ny mipaingotra manondro.
//!
//! # `Unpin`
//!
//! Karazana maro no mihetsika malalaka foana, na dia apetaka aza, satria tsy miankina amin'ny fananana adiresy marin-toerana.Ao anatin'izany ny karazana fototra rehetra (toy ny [`bool`], [`i32`], ary ny firesahana) ary koa ireo karazana izay misy an'ireto karazana ireto fotsiny.Ireo karazana izay tsy miraharaha ny fametahana pin dia mampihatra ny [`Unpin`] auto-trait, izay manafoana ny vokatry ny [`Pin<P>`].
//! Ho an'ny `T: Unpin`, [`Pin`]`<`[`Box`]`<T>>`ary [`Box<T>`] miasa mitovy, toy ny [`Pin`] `<&mut T>` sy `&mut T`.
//!
//! Mariho fa ny pinning sy [`Unpin`] dia misy fiatraikany amin'ny `P::Target` tendrena, fa tsy ny karazana pointer `P` tenany izay nofonosina [`Pin<P>`]., Ohatra, na, na dia tsy [`Box<T>`] [`Unpin`] tsy manana vokany eo amin'ny fitondran-tena ny [`Pin`]: <: [`Box`]<T>> `(eto, `T` no karazany voatondro).
//!
//! # Ohatra: firafitry ny tena-tena
//!
//! Alohan'ny hidirantsika amin'ny antsipiriany bebe kokoa hanazavana ny antoka sy ny safidy mifandraika amin'ny `Pin<T>`, dia miresaka ohatra vitsivitsy momba ny fomba hampiasana azy.
//! Aza misalasala mankany [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ity dia rafitra mizaha tena ny tenany satria manondro ny sehatry ny angon-drakitra ny sahan-slice.
//! // Tsy azontsika atao ny mampahafantatra ny mpamorona momba izany amin'ny referansa mahazatra, satria io lamina io dia tsy azo faritana amin'ny fitsipika mahazatra momba ny mindrana.
//! //
//! // Fa kosa mampiasa tondro iray manta isika, na dia iray aza izay fantatra fa tsy ho namboarina, satria fantatsika fa manondro ny tadiny io.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Mba hahazoana antoka fa tsy mihetsika ny angona rehefa miverina ny asany, apetrantsika ao amin'ny antontam-bato izay hipetrahany mandritra ny androm-piainan'ilay zavatra, ary ny fomba tokana ahazoana azy dia amin'ny alàlan'ny fanondroana azy.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // izahay vao mamorona ny mpanondro raha vao tafapetraka ny angona raha tsy izany dia efa nifindra talohan'ny nanombohantsika akory aza
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // fantatray fa azo antoka ity satria ny fanovana saha dia tsy mampihetsika ny rafitra rehetra
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Ny tondro dia tokony hanondro ny toerana marina, raha mbola tsy nihetsika ny strat.
//! //
//! // Mandritra izany fotoana izany, isika dia afaka hifindra manondro manodidina.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Satria tsy mampiditra ny Unpin ny karazana antsika, dia tsy hahavita hamory ity:
//! // avelao mut new_unmaced= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Ohatra: lisitra misy ifandraisany indroa mifandray
//!
//! Ao anaty lisitra misy ifandraisany misy ifandraisany indroa, ny famoriam-bola dia tsy manome ny fahatsiarovana ireo singa mihitsy.
//! Ny allocation dia fehezin'ny mpanjifa, ary ny singa dia afaka miaina amin'ny fehezam-boninkazo izay miaina fohy kokoa noho ny fanangonana.
//!
//! Mba hampandehanana an'io asa io, ny singa rehetra dia misy tondro ny alohany sy ny mpandimby azy ao anaty lisitra.Ny singa dia azo ampiana rehefa voahidy izy ireo, satria ny famindrana ireo singa manodidina dia tsy mitombina ny tondro.Ankoatr'izay, ny fampiharana [`Drop`] singa lisitry mifandraika dia hametaka ireo tondro alohany sy handimby azy hanala ny tenany amin'ny lisitra.
//!
//! Zava-dehibe, tsy maintsy afaka miantehitra amin'ny fiantsoana an'i [`drop`] isika.Raha misy singa iray azo trandrahana na tsy manankery raha tsy miantso [`drop`], ny tondro mankany aminy avy amin'ireo singa mpifanila vodirindrina aminy dia ho lasa tsy mety, izay hanapotika ny firafitry ny angona.
//!
//! Noho izany, pinning koa dia tonga noho ny [: drop`]-related antoka.
//!
//! # `Drop` guarantee
//!
//! Ny tanjon'ny pinning dia ny hahafahana miantehitra amin'ny fametrahana ny angona sasany ao anaty fitadidiana.
//! Mba hanaovana an'io asa io dia voafetra ny tsy famindrana angona fotsiny;voafetra ihany koa ny fifampiraharahana, ny famerenana amin'ny laoniny, na ny fanafoanana ny fahatsiarovana ampiasaina hitahiry ireo angona.
//! Mifanentana amin'izany, ho an'ny angona voatanisa dia tsy maintsy tazominao ilay invariant fa *ny fahatsiarovany dia tsy hanan-kery na averina manomboka amin'ny fotoana hametahana azy raha tsy rehefa antsoina hoe [`drop`]*.Indray mandeha [`drop`] miverina na panics, dia azo ampiasaina indray ny fahatsiarovana.
//!
//! Ny fahatsiarovan-tena dia mety ho "invalidated" amin'ny alàlan'ny fifanarahana, fa koa amin'ny alàlan'ny fanoloana [`Some(v)`] an'i [`None`], na fiantsoana [`Vec::set_len`] ho "kill" singa sasany an'ny vector.Azo averina averina amin'ny alàlan'ny fampiasana [`ptr::write`] hametahana azy io nefa tsy miantso ny mpanimba azy aloha.Tsy misy na dia iray aza azo ekena amin'ny angona voatanisa raha tsy miantso [`drop`] ianao.
//!
//! Io no karazana antoka azo antoka fa mila mandeha tsara ny lisitra mifandray mampiditra avy amin'ny fizarana teo aloha.
//!
//! Mariho fa io antoka io dia tsy *tsy* midika fa tsy mitete ny fahatsiarovana!Tsy mbola tanteraka tsy ekena mihitsy ny hiantso [`drop`] amin'ny mipaingotra singa (ohatra, ianao mbola afaka miantso [`mem::forget`] amin'ny [`Pin`]: <: [`Box`]<T>> `).Ao amin'ny ohatra ny lisitra misy ifandraisany indroa, io singa io dia hijanona ao anaty lisitra fotsiny.Na izany aza tsy azonao atao ny manafaka na mampiasa indray ny fitehirizana *raha tsy miantso [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Raha ny karazana fampiasana pinning (toy ny ohatra roa etsy ambony), tsy maintsy mitandrina rehefa [`Drop`] fampiharana.Ny fiasan'ny [`drop`] dia mitaky `&mut self`, saingy antsoina hoe *na dia napetaka teo aloha aza ny karazana*!Toy ny hoe antsoina hoe [`Pin::get_unchecked_mut`] ilay mpamorona.
//!
//! Tsy mety hiteraka olana amin'ny kaody azo antoka izany satria ny fampiharana karazana miantehitra amin'ny fametahana dia mitaky kaody tsy azo antoka, nefa tandremo fa ny manapa-kevitra ny hampiasa pinning amin'ny karazana anao (ohatra amin'ny fampiharana ny asa amin'ny [`Pin`]`<&Self>`na [`Pin`] `<&mut Self>`) dia misy vokany amin'ny fampiharana [`Drop`] anao koa: raha nisy singa iray karazana azonao notampirina, dia tsy maintsy ataonao [`Drop`] amin'ny fakana am-pitoerana [`Pin`]`<&mut Tena>`.
//!
//!
//! Ohatra, azonao atao ny mampihatra ny `Drop` toy izao:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` tsy maninona satria fantatray fa tsy ampiasaina intsony io soatoavina io rehefa ajanona.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Ny kaody fitetezana marina dia mandeha eto.
//!         }
//!     }
//! }
//! ```
//!
//! Ny fiasa `inner_drop` dia manana ny karazana izay tokony ananan'i [`drop`] *, noho izany dia azo antoka fa tsy mampiasa `self`/`this` tsy nahy ianao amin'ny fomba mifanohitra amin'ny fametahana.
//!
//! Ankoatr'izay, raha `#[repr(packed)]` ny karazanyo, dia hamindra ho azy ireo ny compiler hahafahany mandatsaka azy ireo.Mety hataony mihitsy aza izany ho an'ny saha izay sendra mifanaraka tsara.Vokatr'izany dia tsy afaka mampiasa pinning amin'ny karazana `#[repr(packed)]` ianao.
//!
//! # Tetikasa sy paingotra firafitra
//!
//! Rehefa miasa miaraka amina fantsona voarindrina dia mipoitra ny fanontaniana amin'ny fomba ahafahan'ny olona miditra amin'ny sehatry ny firafitra amin'ny fomba iray izay mandray fotsiny ny [`Pin`]`<&mut Struct>`.
//! Ny fomba fanao mahazatra dia ny manoratra fomba mpanampy (antsoina hoe *vinavina*) izay mamadika ny [`Pin`]`<&mut Struct>`ho lasa firesahana an-tsaha, fa inona no karazana tokony ananan'io referansa io?Moa ve ilay [`Pin`]`<&mut Field>`na `&mut Field`?
//! Ny fanontaniana mitovy amin'izany dia mipoitra amin'ny sehatry ny `enum`, ary koa rehefa mandinika ireo karazana container/wrapper toy ny [`Vec<T>`], [`Box<T>`], na [`RefCell<T>`].
//! (Ity fanontaniana ity dia mihatra amin'ny fanovozan-kevitra azo ovaina sy zaraina, fa ny tranga matetika fampiasa eto dia ampiasainay ohatra.)
//!
//! Hita fa miankina amin'ny mpanoratra ny firafitry ny angon-drakitra ny manapa-kevitra raha toa ka ilay tetika napetaka amin'ny sehatr'asa iray manokana dia mivadika [`Pin`]`<&mut Struct>`ho [`Pin`] `<&mut Field>` na `&mut Field`.Misy ihany anefa ny teritery, ary ny teritery lehibe indrindra dia ny *tsy fitoviana*:
//! saha rehetra na dia mety ho * * kasaina amin'ny mipaingotra boky,*na* no pinning nesorina izay tafiditra ao ny projection.
//! Raha samy natao tamin'ny sehatra iray izy roa, dia mety ho tsy marin-toetra izany!
//!
//! Amin'ny maha-mpanoratra ny firafitry ny angon-drakitra dia azonao atao ny manapa-kevitra isaky ny saha na manindrona "propagates" amin'ity sehatra ity na tsia.
//! Pinning fa fizakàn'izy dia antsoina koa hoe "structural", satria manaraka ny firafitry ny karazana.
//! Amin'ireto andiany manaraka ireto dia fariparitanay ireo fiheverana tokony hatao amin'ny safidy roa.
//!
//! ## Ny pinning *dia tsy* rafitra ho an'ny `field`
//!
//! Mety ho toa tsy mampaninona izany fa mety tsy ho voafintina ny sahan'endri-tsoroka pin, fa izany no tena safidy mora indrindra: raha tsy noforonina mihitsy ny [`Pin`]`<&mut Field>`, dia tsy misy diso.Noho izany, raha manapa-kevitra ianao fa ny sehatra sasany dia tsy manana pinning struktural, ny hany azonao antoka dia ny tsy hamoronana referansa mihantona amin'io sehatra io ianao.
//!
//! Ireo saha tsy misy fametahana rafitra dia mety manana fomba vinavina hamadika ny [`Pin`]`<&mut Struct>`ho `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Tsy maninona izany satria `field` dia tsy heverina ho voafintina mihitsy.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Azonao atao koa `impl Unpin for Struct`*na dia* ny karazana `field` dia tsy [`Unpin`].Ny hevitr'io karazana io momba ny fametahana dia tsy misy ifandraisany rehefa tsy misy [`Pin`]`<&mut Field>` izay noforonina.
//!
//! ## Ny pinning *dia* rafitra ho an'ny `field`
//!
//! Ny safidy hafa dia ny manapa-kevitra fa ny pinning dia "structural" ho an'ny `field`, midika izany fa raha voafintina ilay strat dia toy izany koa ny saha.
//!
//! Io dia ahafahana manoratra projet izay mamorona [`Pin`]`<&mut Field>`, ka manamarina fa voahidy ny saha:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Tsy maninona ity satria `field` dia voahaingo amin'ny `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Na izany aza, ny fametahana rafitra dia misy fepetra takiana vitsivitsy:
//!
//! 1. Ny rafitra dia tokony ho [`Unpin`] fotsiny raha toa ka [`Unpin`] daholo ny sehatry ny firafitra.Ity no default, fa [`Unpin`] dia trait azo antoka, ka noho ny mpanoratra ny strap dia anjaranao *ny* manisy zavatra toa ny `impl<T> Unpin for Struct<T>`.
//! (Jereo fa mitaky kaody tsy azo antoka ny fampidirana fiasa amin'ny projet, ka ny zava-misy fa [`Unpin`] dia trait azo antoka dia tsy manapotika ilay fitsipika izay tsy maintsy atahoranao fotsiny momba an'io raha mampiasa `tsy azo antoka`.)
//! 2. Ny mpanimba ny rafitra dia tsy tokony hamindra ny sehatry ny firafitra hiala amin'ny tohan-keviny.Ity no teboka tena izy izay natsangana tamin'ny [previous section][drop-impl]: `drop` maka `&mut self`, fa ny istr (ary noho izany ny sahan'ireny) dia mety efa voatanisa teo aloha.
//!     Tsy maintsy manome toky ianao fa tsy mifindra saha ao anatin'ny fampiharana [`Drop`] anao.
//!     Manokana, araka ny nohazavaina teo aloha, midika izany fa ny rafitrao dia tokony *tsy* ho `#[repr(packed)]`.
//!     Jereo ity fizarana ity amin'ny fomba fanoratana [`drop`] amin'ny fomba izay afaka manampy anao ny mpamorona tsy manapaka ny pinning tsy nahy.
//! 3. Tokony ho azonao antoka fa manohana ny [`Drop` guarantee][drop-guarantee] ianao:
//!     Raha vantany vao voahidy ny stratanao, ny fahatsiarovana izay misy ny atiny dia tsy hosoratana na hifanenana raha tsy miantso ireo mpanimba ny atiny.
//!     Izany dia mety ho mamitaka, izay porofoin'ny [`VecDeque<T>`]: ny destructor ny [`VecDeque<T>`] tsy afaka miantso [`drop`] rehetra, raha singa iray amin'ireo destructors panics.Manitsakitsaka ny fiantohana [`Drop`] izany, satria mety hitarika ho amin'ny fifamoivoizana ireo singa raha tsy nantsoina ny mpanimba azy ireo.([`VecDeque<T>`] Tsy misy pinning vinavina, ka izany no mahatonga unsoundness.)
//! 4. Aza manolotra hetsika hafa izay mety hitarika ho amin'ny tahirin-kevitra rehefa nifindra avy tany amin'ny saha ara-drafitra, raha ny karazana no mipaingotra.Ohatra, raha misy [`Option<T>`] ny rafitra ary misy ny hetsika «take` toa ny karazana `fn(Pin<&mut Struct<T>>) -> Option<T>`, io asa io dia azo ampiasaina hamindra `T` avy ao amin'ny `Struct<T>` voafintina-izay midika fa ny pinning dia tsy mety ho rafitra ho an'ny saha mitazona an'io tahirin-kevitra.
//!
//!     Ho an'ny ohatra sarotra kokoa amin'ny famindrana angona avy amina karazana voahidy, alao sary an-tsaina hoe raha [`RefCell<T>`] dia nanana fomba `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Avy eo dia azontsika atao izao:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ity dia loza, midika izany fa azontsika atao aloha ny manisy pin ny atin'ny [`RefCell<T>`] (mampiasa `RefCell::get_pin_mut`) ary avy eo mamindra izany atiny izany amin'ny alàlan'ny référence mutable azontsika avy eo.
//!
//! ## Examples
//!
//! Ho an'ny karazana toy ny [`Vec<T>`], dia samy misy dikany avokoa ny fahafaha-manao (manoritra rafitra na tsia).
//! [`Vec<T>`] misy pinning struktural dia mety manana fomba `get_pin`/`get_pin_mut` hahazoana paingotra voatanisa amin'ireo singa.Na izany aza, tsy afaka *namela* niantso an'i [`pop`][Vec::pop] tamina pin [`Vec<T>`] voafintina izy io satria io dia hanetsika ny atiny (napetaka amin'ny rafitra)!Tsy afaka mamela [`push`][Vec::push] izany, izay mety reallocate ary dia toy izany ihany koa ny ao anatin'ilay mihetsika.
//!
//! Ny [`Vec<T>`] tsy misy fametahana rafitra dia mety `impl<T> Unpin for Vec<T>`, satria ny atiny tsy voafintina ary ny [`Vec<T>`] mihitsy no milamina rehefa nafindra ihany koa.
//! Amin'izay fotoana izay dia tsy misy fiatraikany amin'ny vector mihitsy ny pinning.
//!
//! Ao amin'ny trano famakiam-boky mahazatra, ny karazana pointer amin'ny ankapobeny dia tsy manana paingotra firafitra, ary noho izany dia tsy manome vinaingitra fametahana.Izany no mahatonga ny `Box<T>: Unpin` mitazona ny `T` rehetra.
//! Misy dikany ny fanaovana an'io amin'ny karazana pointer, satria ny famindrana ny `Box<T>` dia tsy mampihetsika ny `T`: ny [`Box<T>`] dia afaka mihetsika malalaka (aka `Unpin`) na dia tsy `T` aza.Raha ny marina, na dia [`Pin`]`<`[`Box`]`<T>>`ary [`Pin`] `<&mut T>` dia [`Unpin`] foana, noho io antony io ihany: ny votoatiny (ny `T`) dia voafintina, fa ny tondro kosa dia azo afindra raha tsy afindra ny angona voatanisa.
//! Ho an'ny [`Box<T>`] sy [`Pin`]`<`[`Box`]``<T>>`, raha voafintina ny atiny dia miankina tanteraka amin'ny hoe voatsindrona ny tondro, midika izany fa ny *fametahana dia* tsy * firafitra.
//!
//! Rehefa mampiditra kombina [`Future`] ianao dia matetika mila pinning struktural ho an'ny futures mitampina, satria mila maka petadrindrina mipetaka amin'izy ireo hiantsoana [`poll`] ianao.
//! Fa raha misy angona hafa tsy mila apetaka ny kombina anao, azonao atao ny manao ireo sehatr'asa ireo tsy ho ara-drafitra ary noho izany dia hidiranao amin-kalalahana miaraka amina fanovozan-kevitra miovaova na dia vao manana [`Pin`]`<&mut Self>`((ohatra toy ny fampiharana [`poll`] anao manokana).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Toro-marika
///
/// Ity dia fonosana manodidina ny karazana pointer izay mahatonga an'io mpanondro "pin" io ho sarany, manakana ny sanda voatondron'io mpanondro io tsy hafindra raha tsy mampihatra [`Unpin`].
///
///
/// *Jereo ny [`pin` module] antontan-taratasy ho fanazavana mikasika ny pinning.*
///
/// [`pin` module]: self
///
// Note: ny fakana `Clone` etsy ambany dia miteraka tsy fitoviana araka izay azo atao amin'ny fampiharana
// `Clone` ho an'ny andinin-tsoratra miovaova.
// Jereo <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> raha mila fanazavana fanampiny.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ireto fampiharana ireto dia tsy nalaina mba hialana amin'ny olana ara-pahasalamana.
// `&self.pointer` tsy tokony ho azo idirana amin'ny fampiharana trait tsy azo itokisana.
//
// Jereo <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> raha mila fanazavana fanampiny.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Hanorina `Pin<P>` vaovao manodidina ny manondro ny sasany angon-drakitra iray karazana fa fitaovana [`Unpin`].
    ///
    /// Tsy toy ny `Pin::new_unchecked`, ity fomba ity dia azo antoka satria ny pointer `P` dia manadino ny karazana [`Unpin`], izay manafoana ny antoka omena.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: ny sanda voatondro dia `Unpin`, ary noho izany dia tsy misy fepetra takiana
        // manodidina pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps ity `Pin<P>` mamerina ny mpanondro mpanondro.
    ///
    /// Izany dia mitaky ny angon-drakitra ao anatin'ity `Pin` ity dia [`Unpin`] hahafahantsika tsy miraharaha ireo invariants manindrona rehefa manala azy io.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Hanorina `Pin<P>` vaovao manodidina ny momba ny angon-drakitra misy ny karazana izay mety na tsy manatanteraka `Unpin`.
    ///
    /// Raha manadino `pointer` amin'ny karazana `Unpin` dia tokony ampiasaina ny `Pin::new`.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity mpanorina ity satria tsy afaka manome toky izahay fa ny angona notondroin'i `pointer` dia voahidy, midika izany fa tsy hafindra ny tahirin-kevitra na tsy mitombina ny fitehirizany mandra-pialany.
    /// Raha toa ny `Pin<P>` namboarina dia tsy manome toky fa ny data `P` manondro dia apetaka, izany dia fanitsakitsahana ny fifanarahana API ary mety hitarika fihetsika tsy voafaritra amin'ny asan'ny (safe) any aoriana.
    ///
    /// Amin'ny fampiasana an'io fomba io dia manao promise momba ny fampiharana `P::Deref` sy `P::DerefMut` ianao, raha misy izy ireo.
    /// Ny tena zava-dehibe dia tsy tokony hiala amin'ny tohan-keviny `self` izy ireo: `Pin::as_mut` sy `Pin::as_ref` dia hiantso `DerefMut::deref_mut` sy `Deref::deref`*amin'ilay tondro voatanisa* ary antenaina fa hanohana ireo invariants mibitsibitsika ireo fomba ireo.
    /// Ankoatr'izay, amin'ny fiantsoana an'ity fomba ity ianao promise fa ny referansa `P` dereferansa dia tsy hesorina intsony;manokana, tsy tokony ho azo atao ny mahazo `&mut P::Target` ary avy eo miala ao amin'izany referansa izany (mampiasa, ohatra [`mem::swap`]).
    ///
    ///
    /// Ohatra, ny fiantsoana `Pin::new_unchecked` amin'ny `&'a mut T` dia tsy azo antoka satria raha afaka mametaka azy mandritra ny androm-piainana `'a` ianao dia tsy voafehinao raha voatana amina pince io rehefa tapitra ny `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Midika izany fa tsy afaka mihetsika intsony ny pointee `a`.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Ny adiresy `a` dia niova ho slot b's` stack, noho izany `a` dia nifindra na dia efa napetantsika teo aza izy io!Nandika ny fifanarahana API nanamontsana izahay.
    /////
    /// }
    /// ```
    ///
    /// Ny sanda iray, raha vao voatsindry, dia tsy maintsy mijanona mihidy mandrakizay (raha tsy hoe `Unpin` no ampiasain'ny karazany).
    ///
    /// Toy izany koa, miantso `Pin::new_unchecked` momba ny `Rc<T>` dia mampidi-doza, satria misy aliases mety ho tahirin-kevitra iray ihany izay tsy manaiky ny pinning fameperana:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Midika izany fa tsy afaka mihetsika intsony ny pointee.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ankehitriny, raha ny `x` no hany referansa dia manana andinin-tsoratra miovaova amin'ny data izay napetantsika tetsy ambony isika, izay azonay nampiasaina mba hamindrana azy araka ny hitantsika tamin'ny ohatra teo aloha.
    ///     // Nandika ny fifanarahana API nanamontsana izahay.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Mahazo andinin-tsoratra iraisana madiodio avy amin'ity mpanondro voatsindry ity.
    ///
    /// Ity dia fomba mahazatra ahafahana miala amin'ny `&Pin<Pointer<T>>` ka hatramin'ny `Pin<&T>`.
    /// Milamina izy satria, ao anatin'ny fifanarahana `Pin::new_unchecked`, tsy afaka mihetsika ny pointee aorian'ny namoronana ny `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Ny fampiharana `Pointer::Deref` dia nolavina ihany koa tamin'ny fifanarahana `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAFETY: jereo ny antontan-taratasy momba io fiasa io
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps ity `Pin<P>` mamerina ny mpanondro mpanondro.
    ///
    /// # Safety
    ///
    /// Ity no asa azo antoka.Tsy maintsy manome toky ianao fa hanohy handray ny pointer `P` ho toy ny voahidy aorian'ny fiantsoanao io asa io, mba hahafahan'ireo invariants amin'ny karazana `Pin` hotohanana.
    /// Raha ny code mampiasa `P` vokatr'izany dia tsy manohy mitazona ireo invariants manindrona izay fanitsakitsahana ny fifanarahana API ary mety hitarika fihetsika tsy voafaritra amin'ny asan'ny (safe) taty aoriana.
    ///
    ///
    /// Raha [`Unpin`] ny angona ifotony, [`Pin::into_inner`] no tokony ampiasaina ho solony.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Mahazo andinin-tsoratra azo ovaina nopetahana tamin'ity fanondro voatanisa ity.
    ///
    /// Ity dia fomba mahazatra ahafahana miala amin'ny `&mut Pin<Pointer<T>>` ka hatramin'ny `Pin<&mut T>`.
    /// Milamina izy satria, ao anatin'ny fifanarahana `Pin::new_unchecked`, tsy afaka mihetsika ny pointee aorian'ny namoronana ny `Pin<Pointer<T>>`.
    ///
    /// "Malicious" Ny fampiharana `Pointer::DerefMut` dia nolavina ihany koa tamin'ny fifanarahana `Pin::new_unchecked`.
    ///
    /// Ilaina ity fomba ity rehefa manao antso maro amin'ireo fiasa izay mandany ilay karazana voametaka.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // manao zavatra
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` mandany `self`, koa avereno alao ny `Pin<&mut Self>` amin'ny alàlan'ny `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAFETY: jereo ny antontan-taratasy momba io fiasa io
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Manome sanda vaovao amin'ny fahatsiarovana ao ambadiky ny fanamarihana voatanisa.
    ///
    /// Ity pejy ity dia manindry data, saingy tsy maninona: ny mpanimba azy dia mihazakazaka alohan'ny hanoratana azy, ka tsy misy ny fiantohana pinning.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Manangana pin vaovao amin'ny alàlan'ny fandrafetana ny sarany anatiny.
    ///
    /// Ohatra, raha te hahazo `Pin` saha ny zavatra, afaka mampiasa izany mba hahazo ny fidirana amin'ny saha izay ao anatin'ny iray andalana ny fehezan-dalàna.
    /// Na izany aza, misy gotchas maromaro miaraka amin'ireto "pinning projections" ireto;
    /// jereo ny antontan-taratasy [`pin` module] raha mila fanazavana fanampiny momba an'io lohahevitra io.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity.
    /// Tsy maintsy manome toky ianao fa tsy hihetsika ny angona averinao raha mbola tsy mihetsika ny sandan'ny adihevitra (ohatra, satria iray amin'ireo sahan'io sanda io), ary koa tsy miala amin'ny adihevitra azonao ianao ny fiasa anatiny.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: ny fifanarahana fiarovana ho an'ny `new_unchecked` dia tsy maintsy atao
        // nanohana ny mpiantso.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Mahazo referansa iraisana amin'ny pin.
    ///
    /// Izany no azo antoka, satria tsy azo atao ny hifindra avy amin'ny boky nozaraina.
    /// Mety ho toa misy olana eto amin'ny fiovan'ny toetr'andro: raha ny tena izy, dia *azo atao* ny mamindra `T` amin'ny `&RefCell<T>`.
    /// Na izany aza, tsy olana izany raha mbola tsy misy koa `Pin<&T>` manondro ny angon-drakitra mitovy, ary ny `RefCell<T>` dia tsy mamela anao hamorona referansa mipetaka amin'ny atiny.
    ///
    /// Jereo ny fifanakalozan-kevitra eo amin'ny ["pinning projections"] ho an'ny antsipirihany bebe kokoa.
    ///
    /// Note: `Pin` koa dia mampiditra `Deref` amin'ny lasibatra, izay azo ampiasaina hidirana amin'ny sanda anatiny.
    /// Na izany aza, `Deref` dia manome andinin-tsoratra masina velona fotsiny raha mbola indram-bola ny `Pin` fa tsy ny androm-piainan'ny `Pin` mihitsy.
    /// Ity fomba ity dia mamela ny famadihana ny `Pin` ho referansa miaraka amin'ny androm-piainany mitovy amin'ilay `Pin` voalohany.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Manova an'io `Pin<&mut T>` io ho `Pin<&T>` miaraka amin'ny androm-piainany.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Mahazo andinin-tsoratra azo ovaina ao anatin'ity `Pin` ity.
    ///
    /// Izany dia mitaky ny angon-drakitra ao anatin'ity `Pin` ity dia `Unpin`.
    ///
    /// Note: `Pin` koa dia mampiditra `DerefMut` amin'ny angona, izay azo ampiasaina hidirana amin'ny sanda anatiny.
    /// Na izany aza, `DerefMut` dia manome andinin-tsoratra masina velona fotsiny raha mbola indram-bola ny `Pin` fa tsy ny androm-piainan'ny `Pin` mihitsy.
    ///
    /// Ity fomba ity dia mamela ny famadihana ny `Pin` ho referansa miaraka amin'ny androm-piainany mitovy amin'ilay `Pin` voalohany.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Mahazo andinin-tsoratra azo ovaina ao anatin'ity `Pin` ity.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity.
    /// Tsy maintsy manome toky ianao fa tsy hamindra ny angon-drakitra tsy ho azon'ny référence miovaova azonao rehefa miantso ity asa ity ianao, mba ho voatazona ireo invariants amin'ny karazana `Pin`.
    ///
    ///
    /// Raha `Unpin` ny angona ifotony, `Pin::get_mut` no tokony ampiasaina ho solony.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Hanorina Pin vaovao amin'ny alalan'ny fametrahana an-tsarintany ny anatiny sarobidy.
    ///
    /// Ohatra, raha te hahazo `Pin` saha ny zavatra, afaka mampiasa izany mba hahazo ny fidirana amin'ny saha izay ao anatin'ny iray andalana ny fehezan-dalàna.
    /// Na izany aza, misy gotchas maromaro miaraka amin'ireto "pinning projections" ireto;
    /// jereo ny antontan-taratasy [`pin` module] raha mila fanazavana fanampiny momba an'io lohahevitra io.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity.
    /// Tsy maintsy manome toky ianao fa tsy hihetsika ny angona averinao raha mbola tsy mihetsika ny sandan'ny adihevitra (ohatra, satria iray amin'ireo sahan'io sanda io), ary koa tsy miala amin'ny adihevitra azonao ianao ny fiasa anatiny.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAFETY: tompon'andraikitra ny tsy mihetsika ny miantso
        // lanja amin'ny boky izany.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: satria ny sandan'ny `this` dia azo antoka fa tsy hanana
        // nafindra, azo antoka ity antso amin'ny `new_unchecked` ity.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Makà loharano voatanisa ao amin'ny referansa static.
    ///
    /// Azo antoka izany, satria `T` indramina mandritra ny androm-piainana `'static`, izay tsy mifarana.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAFETY: ny 'static loan dia manome antoka ny data tsy ho
        // moved/invalidated mandra-pilatsaka (izay tsy misy mihitsy).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Makà referansy azo ovaina namboarina tamina referansa tsy azo ovaina napetaka.
    ///
    /// Azo antoka izany, satria `T` indramina mandritra ny androm-piainana `'static`, izay tsy mifarana.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAFETY: ny 'static loan dia manome antoka ny data tsy ho
        // moved/invalidated mandra-pilatsaka (izay tsy misy mihitsy).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: Midika izany fa misy impl `CoerceUnsized` izay mamela coercing
// ny karazana izay impls `Deref<Target=impl !Unpin>` iray karazana fa impls `Deref<Target=Unpin>` no antoka ny zavatra resahin'ny.
// Na izany aza, ny impla toy izany dia mety tsy ho marim-pototra noho ny antony hafa, koa mila mitandrina isika mba tsy hamela ireo imply toy izany hidina ao std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}