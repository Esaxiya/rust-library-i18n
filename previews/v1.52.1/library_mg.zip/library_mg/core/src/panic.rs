//! Fanohanana Panic ao amin'ny tranomboky mahazatra.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Volapoky manome fampahalalana momba ny panic.
///
/// `PanicInfo` ny rafitra dia ampitaina amin'ny panic hook napetraky ny asan'ny [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Mamerina ny karama mifandraika amin'ny panic.
    ///
    /// Matetika io, fa tsy matetika, dia ho `&'static str` na [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Raha ny makro `panic!` avy amin'ny `core` crate (tsy avy amin'ny `std`) dia nampiasaina niaraka tamin'ny tady famolavolana sy tohan-kevitra fanampiny, avereno omena izany hafatra izany ohatra amin'ny [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Miverina fampahalalana momba ny toerana niavian'ny panic, raha misy.
    ///
    /// Ity fomba ity dia hiverina [`Some`] foana amin'izao fotoana izao, saingy mety hiova amin'ny kinova future io.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Raha ovaina ity dia miverina indraindray, Tsy misy,
        // miatrehana an'io tranga io amin'ny std::panicking::default_hook sy std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: tsy afaka mampiasa downcast_ref: :<String>() Eto
        // satria ny String dia tsy misy amin'ny filokana!
        // Ny karama dia String rehefa antsoina `std::panic!` miaraka amin'ny tohan-kevitra marobe, fa raha izany dia misy ihany koa ny hafatra.
        //

        self.location.fmt(formatter)
    }
}

/// Struktur iray misy fampahalalana momba ny toerana misy ny panic.
///
/// Ity rafitra ity dia noforonin'i [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Ny fampitahana ny fitoviana sy ny filaharana dia atao amin'ny rakitra, tsipika, avy eo laharam-pahamehana amin'ny tsanganana.
/// Ny rakitra dia ampitahaina amin'ny tadiny fa tsy `Path`, izay mety tsy ampoizina.
/// Zahao ny rakitsoratr'i [`Location: : file`] raha hiadian-kevitra bebe kokoa.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Miverina ny toerana misy ny mpiantso an'io asa io.
    /// Raha voamarika ny mpiantso an'io asa io dia haverina ny toeran'ny fiantsoana azy, ary toy izany hatrany hatrany ny stack amin'ny antso voalohany ao anaty vatan'asa tsy voatanisa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Miverina ny [`Location`] izay iantsoana azy.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Miverina [`Location`] avy ao anatin'ny famaritan'ity asa ity.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // Ny fihazakazahana ilay fiasa tsy voahitsaka iray ihany amin'ny toerana hafa dia manome antsika valiny mitovy
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ny fihazakazahana ilay lahasa voahaja amin'ny toerana hafa dia miteraka sanda hafa
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Mamerina ny anaran'ny fisie loharano niavian'ny panic.
    ///
    /// # `&str`, tsy `&Path`
    ///
    /// Ny anarana niverina ny loharanom-baovao dia manondro lalana eo amin'ny rafitra nanoratra, nefa tsy manan-kery hisolo tena ity ho toy ny `&Path` mivantana.
    /// Ny kaody natambatra dia mety mandeha amin'ny rafitra hafa miaraka amin'ny fampiharana `Path` hafa noho ny rafitra manome ny atiny ary ity tranomboky ity dia tsy manana karazana "host path" hafa amin'izao fotoana izao.
    ///
    /// Ny fihetsika mahavariana indrindra dia mipoitra rehefa tratra ny rakitra "the same" amin'ny alàlan'ny lalana maro ao amin'ny rafitra mody (mazàna mampiasa ny toetra `#[path = "..."]` na mitovy aminy), izay mety hiteraka kaody mitovy hitodian'ny valiny tsy mitovy amin'ity asa ity.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Ity sanda ity dia tsy mety amin'ny fandefasana any amin'ny `Path::new` na ireo mpanorina mitovy amin'izany rehefa tsy mitovy ny sehatra fampiantranoana sy ny tanjona kendrena.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Mamerina ny laharana andalana niavian'ny panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Miverina ny tsanganana niavian'ny panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait anatiny iray ampiasain'i libstd handefasana angona avy amin'ny libstd mankany `panic_unwind` sy ireo fotoana hafa panic.
/// Tsy natao hampiorina azy atsy ho atsy, aza mampiasa.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Raiso ny tompony feno amin'ny atiny.
    /// Ny karazana fiverenana dia `Box<dyn Any + Send>`, fa tsy afaka mampiasa `Box` amin'ny libcore isika.
    ///
    /// Aorian'ny niantsoana an'io fomba io dia ny sanda default tsy misy valiny fotsiny sisa tavela amin'ny `self`.
    /// Ny fiantsoana an'ity fomba ity indroa, na fiantsoana `get` aorian'ny fiantsoana ity fomba ity, dia lesoka.
    ///
    /// Nindramina ny adihevitra satria ny X0panic0Z runtime (`__rust_start_panic`) dia mahazo `dyn BoxMeUp` indramina fotsiny.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Mindrana fotsiny ny atiny.
    fn get(&mut self) -> &(dyn Any + Send);
}