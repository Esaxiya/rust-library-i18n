//! Kamo soatoavina sy indray mandeha voasakantsakan'ny initialization ny tahirin-kevitra.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Ny efitra izay afaka hisy soratra indray mandeha ihany.
///
/// Tsy toy ny `RefCell`, `OnceCell` dia manome referansa `&T` nozaraina momba ny sandany.
/// Tsy toy ny `Cell`, ny `OnceCell` Tsy voatery maka tahaka ny zava-dehibe rehefa nosoloana ny mahazo azy.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: nosoratana ho any amin'ny tena indray mandeha.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Mamorona sela vaovao foana.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Mahazo ny firesahana momba ny antony sarobidy.
    ///
    /// Miverina `None` ny sela raha tsy foana tsy mitondra fanatitra.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // Famonjena, noho ny Safe: inner` ny invariant
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Mahazo ilay fanovana azo ovaina amin'ny soatoavina ifotony.
    ///
    /// Miverina `None` ny sela raha tsy foana tsy mitondra fanatitra.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // Famonjena, Safe, satria tsy manam-paharoa isika access
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Mamaritra ny votoatin'ny ny sela ho `value`.
    ///
    /// # Errors
    ///
    /// Io fomba `Ok(())` miverina raha dia foana ny sela sy `Err(value)` raha feno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // Famonjena, Safe satria tsy afaka ny hanana takela-barahina nifanindritsindry mutable maka ny
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // Famonjena, Izany no hany toerana izay nametraka ny slot, tsy misy firazanana
        // noho ny reentrancy/concurrency dia azo atao, ary efa homarinana avy amin'ny teny fa ny slot `None` amin'izao fotoana izao, ka soraty amin'izany ny: mitana ny invariant inner`.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Mahazo ny atin'ny sela, atombohy amin'ny `f` raha foana ny sela.
    ///
    /// # Panics
    ///
    /// Raha `f` panics, ny panic dia aelin'ny ny mpiantso, ary ny sela mbola uninitialized.
    ///
    ///
    /// Fahadisoana ny fanamafisana indray ny sela avy amin'ny `f`.Fanaovana izany ao amin'ny panic vokatr'izany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Mahazo ny atin'ny sela, atombohy amin'ny `f` raha foana ny sela.
    /// Raha ny sela dia foana sy tsy `f`, fahadisoana dia niverina.
    ///
    /// # Panics
    ///
    /// Raha `f` panics, ny panic dia aelin'ny ny mpiantso, ary ny sela mbola uninitialized.
    ///
    ///
    /// Fahadisoana ny fanamafisana indray ny sela avy amin'ny `f`.Fanaovana izany ao amin'ny panic vokatr'izany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Mariho fa ny sasany * * ampy reentrant initialization mety hitarika ho Ub (jereo ny `reentrant_init` fitsapana).
        // Mino aho fa izao fotsiny manaisotra `assert`, raha mitandrina `set/get` mety ho feo, fa toa tsara kokoa ny panic, amim-pahanginana fa tsy ny hampiasa zava-dehibe efa ela.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Manjifa ny sela, mamerina ilay sanda nofonosina.
    ///
    /// Miverina `None` raha dia foana ny sela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Satria `into_inner` maka `self` isaky ny sanda, ny compiler dia manamarina fa tsy nindramina izy ankehitriny.
        // Noho izany dia azo antoka ny hifindra avy `Option<T>`.
        self.inner.into_inner()
    }

    /// Maka ny hasarobidin'ny `OnceCell` amin'ity tany ity, mifindra niverina any amin'ny uninitialized fanjakana.
    ///
    /// Tsy misy fiantraikany sy miverina `None` raha `OnceCell` no tsy initialized.
    ///
    /// Ny fiarovana dia azo antoka amin'ny alàlan'ny fitakiana référence azo ovaina.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Ny sanda izay initialized eo amin'ny fidirana voalohany.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   vonona nitranga teo am-
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Mamorona vaovao kamo nomena zava-dehibe ny nitranga teo am-asa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Manery ny fanombanana an'io sanda kamo io ary mamerina manondro ny vokany.
    ///
    ///
    /// Izany no mitovy amin'ny `Deref` impl, fa misy zavatra vetaveta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Mamorona vaovao kamo mampiasa zava-dehibe nitranga teo am-`Default` ho toy ny asa.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}