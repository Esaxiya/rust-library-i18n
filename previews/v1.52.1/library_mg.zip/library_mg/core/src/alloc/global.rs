use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Ny fahatsiarovana allocator izay azo voasoratra ara-panjakana ho toy ny fitsipika tranomboky ny toerana misy anao amin'ny alalan'ny `#[global_allocator]` toetra.
///
/// Ny sasany amin'ireo fomba dia mitaky ny hanakanana ny bara fahatsiarovana * amin'ny alàlan'ny mpizara iray.Midika izany fa:
///
/// * ny adiresy fanombohana an'io sakana fahatsiarovana io dia naverin'ny antso teo aloha tamin'ny fomba fizarana toy ny `alloc`, ary
///
/// * ny sakana fahatsiarovana dia tsy nifindra toerana avy eo, izay ifanarahana ny sakana na alefa amin'ny fomba fifanarahana toy ny `dealloc` na ampitaina amin'ny fomba reallocation izay mamerina tondro tsy misy dikany.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Ny `GlobalAlloc` trait dia `unsafe` trait noho ny antony maro, ary ny mpampihatra dia tsy maintsy miantoka ny fifikirany amin'ireo fifanarahana ireo:
///
/// * Fihetsika tsy voafaritra izany raha toa ka miala sasatra ireo mpanome vola manerantany.Ity fetra ity dia azo esorina ao amin'ny future, fa amin'izao fotoana izao ny panic iray amin'ireo fiasa ireo dia mety hitarika tsy fahatokisan-tsaina.
///
/// * `Layout` fanontaniana sy ny kajy amin 'ny ankapobeny dia tsy maintsy ho marina.Mpiantso ity trait dia navela miantehitra amin'ny fifanarahana voafaritra amin'ny fomba tsirairay, ary dia tsy maintsy miantoka implementors fifanekena toy izany mijanona ho mahatoky.
///
/// * Mety tsy hiantehitra amin'ny fizarana tena misy ianao, na dia misy aza ny fanangonam-bola miharihary ao amin'ilay loharano.
/// Mety mahita ny optimizer maromaro vola omena fa na afaka manafoana tanteraka na hifindra any amin'ny niisa, ary dia toy izany no tsy mangataka ny allocator.
/// Ny optimizer dia mety hieritreritra bebe kokoa fa ny fizarana dia tsy mety diso, noho izany ny kaody izay tsy nahomby noho ny tsy fahombiazan'ny mpizara dia mety hiasa tampoka ankehitriny satria ny optimizer dia niasa manodidina ny filana fizarana.
/// Raha ny marimarina kokoa, ity ohatra kaody manaraka ity dia tsy marim-pototra, na inona na inona famelana raha toa ka mamela ny manisa firy ny vola natokana ho an'ny mpanome anao.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Mariho fa ny fanatsarana voalaza etsy ambony dia tsy ny fanatsarana azo ampiharina fotsiny.Mety tsy miankina amin'ny fizarana antontam-bato mitranga ianao amin'ny ankapobeny raha azo esorina izy ireo nefa tsy miova fitondran-tena amin'ny programa.
///   Na misy ny fizarana na tsia dia tsy ao anatin'ny fitondran-tenan'ny programa, na dia azo tsapain-tanana amin'ny alàlan'ny mpizara iray izay manara-maso ny fizarana amin'ny alàlan'ny fanontana na raha tsy izany dia misy vokany hafa.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Alaharo ny fahatsiarovana araka ny nofaritan'ny `layout` nomena.
    ///
    /// Miverina tondro iray amin'ny fahatsiarovana vao natokana, na tsy manan-kery hanondroana ny tsy fahombiazan'ny fizarana.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity satria ny fihetsika tsy voafaritra dia mety hiteraka raha tsy manome toky ny mpiantso fa `layout` dia manana habe tsy aotra.
    ///
    /// (Ny subtraits fanitarana dia mety manome fetra voafaritra kokoa momba ny fitondran-tena, ohatra, manome antoka ny adiresy sentinel na ny point null ho valin'ny fangatahana fizarana zoro.)
    ///
    /// Ny andian-tsoratra omena ny fahatsiarovana mety na tsy azo initialized.
    ///
    /// # Errors
    ///
    /// Fiverenana amin'ny tohivakana foana manondro fahatsiarovana mampiseho fa na dia reraka na tsy hihaona `layout` allocator ity ny habe na ny fampifanarahana faneren'ny.
    ///
    /// Entanina ny fampiharana mba hamerina amin'ny laoniny ny fahatsiarovan-tena fa tsy ny fanalan-jaza, fa tsy fepetra hentitra izany.
    /// (Manokana:*ara-dalàna* ny fampiharana an'io trait eo an-tampon'ny tranomboky fizarana zana-tany misy azy io izay tsy manadino ny fahatsiarovan-tena.)
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray fanomezana Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Alefaso ny sakana fahatsiarovana amin'ny tondro `ptr` nomena miaraka amin'ny `layout` nomena.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity satria ny fihetsika tsy voafaritra dia mety hitranga raha tsy miantoka an'ity manaraka ity ilay miantso:
    ///
    ///
    /// * `ptr` dia tsy maintsy manondro sakana fahatsiarovana natokana tamin'ny alàlan'ity mpizara ity,
    ///
    /// * `layout` dia tsy maintsy nitovy endrika namboarina mba hizarana izany sakana fahatsiarovana izany.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Behaves toy ny `alloc`, fa manome antoka ihany koa fa ny atiny dia napetraka ho aotra alohan'ny hamerenana azy.
    ///
    /// # Safety
    ///
    /// Ity fiasa ity dia tsy azo antoka noho ireo antony mitovy `alloc`.
    /// Na izany aza ny andian-tsoratra omena ny fahatsiarovana azo antoka ho initialized.
    ///
    /// # Errors
    ///
    /// Ny famerenana ny pointer null dia manondro fa na ny fahatsiarovana efa reraka na ny `layout` dia tsy mifanaraka amin'ny haben'ny mpizara na ny faneriterena, toy ny amin'ny `alloc`.
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray fanomezana Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SAFETY: ny fifanarahana fiarovana ho an'ny `alloc` dia tsy maintsy tohanan'ny mpiantso.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SAFETY: rehefa nahomby ny fizarana, ny faritra manomboka amin'ny `ptr`
            // ny habe `size` dia azo antoka fa manankery amin'ny fanoratana.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Hihemotra na hitombo ny andian-tsoratra ny fahatsiarovana ny nomena `new_size`.
    /// Ny sakana dia faritan'ny tondro `ptr` sy `layout` nomena.
    ///
    /// Raha miverina ny tsy manondro tohivakana foana, dia ny fahatsiarovana tompon'ny hanovozan-kevitra ny andian-tsoratra `ptr` dia nafindra izany allocator.
    /// Ny fahatsiarovana dia mety na nifindra toerana, ary tokony hoheverina ho tsy azo ampiasaina (raha tsy mazava ho azy fa nafindra tany amin'ny mpiantso indray tamin'ny alàlan'ny sandan'ny fiverenan'ny fomba ity).
    /// Ny fahatsiarovana vaovao dia omena miaraka amin'ny andian-tsoratra `layout`, fa amin'ny `size` nanavao ny `new_size`.
    /// Ity layout vaovao ity dia tokony hampiasaina rehefa mifampiraharaha ny sakana fahatsiarovana vaovao miaraka amin'ny `dealloc`.
    /// Any `0..min(layout.size(), new_size): ny fitadidiana andian-tsoratra ny vaovao azo antoka ho toy izany no soatoavina toy ny andian-tsoratra tany am-boalohany.
    ///
    /// Raha miverina tsy misy io fomba io, dia tsy nafindra tamin'ity mpizara ity ny fananana ny bara fitadidiana, ary tsy niova ny atin'ny sakana fahatsiarovana.
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity satria ny fihetsika tsy voafaritra dia mety hitranga raha tsy miantoka an'ity manaraka ity ilay miantso:
    ///
    /// * `ptr` dia tsy maintsy atokana amin'ny alàlan'ity mpizara ity,
    ///
    /// * `layout` dia tsy maintsy nitovy endrika namboarina mba hizarana izany sakana fahatsiarovana izany,
    ///
    /// * `new_size` tokony ho lehibe noho ny aotra.
    ///
    /// * `new_size`, raha niakatra ho any amin'ny boribory maro ny `layout.align()` akaiky indrindra, dia tsy maintsy tsy anananareo betsaka (izany hoe, ny boribory sarobidy dia tsy maintsy ho kely noho ny `usize::MAX`).
    ///
    /// (Ny subtraits fanitarana dia mety manome fetra voafaritra kokoa momba ny fitondran-tena, ohatra, manome antoka ny adiresy sentinel na ny point null ho valin'ny fangatahana fizarana zoro.)
    ///
    /// # Errors
    ///
    /// Miverina tsy misy dikany raha toa ka tsy mifanaraka amin'ny haben'ny famerana sy ny fampifanarahana ataon'ny mpanome ny firafitra vaovao, na raha tsy mahomby ny famerenana amin'ny laoniny.
    ///
    /// Entanina ny fampiharana mba hamerina amin'ny laoniny ny fahatsiarovan-tena fa tsy hikoropaka na hanala zaza, saingy tsy fepetra hentitra izany.
    /// (Manokana:*ara-dalàna* ny fampiharana an'io trait eo an-tampon'ny tranomboky fizarana zana-tany misy azy io izay tsy manadino ny fahatsiarovan-tena.)
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray reallocation Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: ny miantso dia tsy maintsy miantoka fa ny `new_size` dia tsy hihoatra.
        // `layout.align()` dia avy amin'ny `Layout` ary azo antoka fa mitombina.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // Famonjena, dia tsy maintsy miantoka ny mpiantso fa `new_layout` lehibe noho aotra.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAFETY: ny sakana natokana teo aloha dia tsy afaka mifanindry amin'ilay sakana vao natokana.
            // Ny fifanarahana fiarovana ho an'ny `dealloc` dia tsy maintsy tohanan'ny mpiantso.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}