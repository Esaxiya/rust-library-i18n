//! API fizarana fahatsiarovana

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Ny fahadisoana `AllocError` dia midika ny fanomezana tsy fahombiazana izay mety ho reraka noho ny harena na ny zavatra tsy mety, rehefa natambatra ny omena torohevitra allocator hevitra izany.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ilainay izany ho an'ny fidinana ambanin'ny trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Ny fampiharana `Allocator` dia afaka mizara, mampitombo, mihena, ary mifampiraharaha amin'ny sakana tsy ara-dalàna nofaritana tamin'ny alàlan'ny [`Layout`][].
///
/// `Allocator` Natao ho nampiharina tamin'ny ZSTs, andinin-tsoratra masina, na marani-tsaina sahaza, satria manan-allocator tahaka ny `MyAlloc([u8; N])` tsy mihetsika, tsy misy fanavaozana ny sahaza ho any amin'ny natokana fahatsiarovana.
///
/// Tsy toy ny [`GlobalAlloc`][], avela amin'ny `Allocator` ny fizarana zara-be.
/// Raha toa ka tsy manohana an'io (toy ny jemalloc) na manome tondro null (toy ny `libc::malloc`) ny mpaninjara dia tokony ho tratran'ny fampiharana izany.
///
/// ### Fahatsiarovana natokana ankehitriny
///
/// Ny sasany amin'ireo fomba dia mitaky ny hanakanana ny bara fahatsiarovana * amin'ny alàlan'ny mpizara iray.Midika izany fa:
///
/// * ny adiresy fanombohana an'io sakana fahatsiarovana io dia naverin'i [`allocate`], [`grow`], na [`shrink`], ary
///
/// * ny sakana fahatsiarovana dia mbola tsy nifampiraharaha, avy eo misy ny fifandimbiasan-toerana na nifindra mivantana tamin'ny alàlan'ny [`deallocate`] na novaina tamin'ny alàlan'ny [`grow`] na [`shrink`] izay mamerina `Ok`.
///
/// Raha `grow` na `shrink` niverina `Err`, manondro ny nandalo mbola manan-kery.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Fahatsiarovana mety
///
/// Ny sasany amin'ireo fomba dia mitaky ny fisian'ny layout * hifanaraka amin'ny sakana fahatsiarovana.
/// Ny dikan'ny hoe ho fisehon'ny ny "fit" andian-tsoratra ny fitadidiana dia midika hoe (na equivalently, ho fahatsiarovana andian-tsoratra ho "fit" ny fisehon'ny) dia ny manaraka fepetra tsy maintsy manana:
///
/// * Ny sakana dia tsy maintsy omena amin'ny fampifanarahana mitovy amin'ny [`layout.align()`], ary
///
/// * Ny nomena [`layout.size()`] dia tsy maintsy latsaka ao amin'ny faritra `min ..= max`, izay:
///   - `min` dia ny haben'ny layout efa zatra nanokana ny sakana, ary
///   - `max` dia ny habe farany farany naverina tamin'ny [`allocate`], [`grow`], na [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Ny sakana fahatsiarovana naverina avy amina mpizara iray dia tokony hanondro ny fahatsiarovan-tena manan-kery ary hitazomana ny fahamendrehan'izy ireo mandra-pijanonan'ny ohatra sy ny klone rehetra,
///
/// * ny fandokoana na ny famindrana ny mpizara dia tsy tokony manimba ireo sakana fahatsiarovana naverina avy amin'ity mpizara ity.Ny mpaninjara kloned dia tsy maintsy mitondra tena toy ny mpizara iray ihany, ary
///
/// * izay manondro ny fitadidiana andian-tsoratra izay mety ho lasa [*currently allocated*] amin'ny fomba hafa ny allocator.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Fiezahana hizara sakana fahatsiarovana.
    ///
    /// Amin'ny fahombiazana, avereno ny [`NonNull<[u8]>`][NonNull] fihaonana amin'ny habe sy ny fampifanarahana antoka `layout`.
    ///
    /// Ny sakana naverina dia mety manana habe lehibe kokoa noho izay notondroin'ny `layout.size()`, ary mety ho voaloham-bokatra na tsia ny atiny.
    ///
    /// # Errors
    ///
    /// Niverina `Err` dia midika fa na dia reraka na fahatsiarovana `layout` tsy hihaona allocator ny habe na ny fampifanarahana faneren'ny.
    ///
    /// Entanina ny fampiharana mba hamerina `Err` amin'ny havizanan'ny fahatsiarovana fa tsy hikoropaka na hanala zaza, saingy tsy fepetra hentitra izany.
    /// (Manokana:*ara-dalàna* ny fampiharana an'io trait eo an-tampon'ny tranomboky fizarana zana-tany misy azy io izay tsy manadino ny fahatsiarovan-tena.)
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray fanomezana Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behaves toy ny `allocate`, fa manome antoka ihany koa fa ny fahatsiarovana miverina dia averina am-boalohany.
    ///
    /// # Errors
    ///
    /// Niverina `Err` dia midika fa na dia reraka na fahatsiarovana `layout` tsy hihaona allocator ny habe na ny fampifanarahana faneren'ny.
    ///
    /// Entanina ny fampiharana mba hamerina `Err` amin'ny havizanan'ny fahatsiarovana fa tsy hikoropaka na hanala zaza, saingy tsy fepetra hentitra izany.
    /// (Manokana:*ara-dalàna* ny fampiharana an'io trait eo an-tampon'ny tranomboky fizarana zana-tany misy azy io izay tsy manadino ny fahatsiarovan-tena.)
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray fanomezana Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: `alloc` mamerina sakana fahatsiarovana mety
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates ny fahatsiarovana ny `ptr` hanovozan-kevitra.
    ///
    /// # Safety
    ///
    /// * `ptr` tsy maintsy maneho ny andian-tsoratra ny fahatsiarovana [*currently allocated*] alalan'ny allocator ity, ary
    /// * `layout` tsy maintsy [*fit*] io tsianjery io.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Fiezahana hanitatra ny sakana fahatsiarovana.
    ///
    /// Miverina [`NonNull<[u8]>`][NonNull] vaovao misy tondro sy ny haben'ny fahatsiarovana natokana.Ny pointer dia mety amin'ny fitazonana angona nofaritan'i `new_layout`.
    /// Mba hanatanterahana izany, ny mpizara dia mety manitatra ny fizarana noresahin'i `ptr` mba hifanaraka amin'ny lamina vaovao.
    ///
    /// Raha mamerina `Ok` ity, dia nafindra tamin'ity mpizara ity ny fananana ny tsanganana fahatsiarovana notondroin'i `ptr`.
    /// Ny fahatsiarovana mety na mety tsy ho afaka, ary tokony ho heverina ho azo ampiasaina intsony raha tsy nafindra indray ny mpiantso ny fiverenana indray amin'ny alalan'ny sarobidy io fomba fiasa.
    ///
    /// Raha io fomba `Err` miverina, dia tompon'ny andian-tsoratra ny fahatsiarovana dia tsy nafindra ho allocator ity, sy ny votoatin'ny andian-tsoratra ny fitadidiana dia unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` tsy maintsy maneho ny andian-tsoratra ny fahatsiarovana [*currently allocated*] alalan'ny allocator ity.
    /// * `old_layout` tsy maintsy [*fit*] io sakana fitadidiana io (Ny adihevitra `new_layout` dia tsy mila sahaza azy.).
    /// * `new_layout.size()` dia tokony ho lehibe kokoa na mitovy amin'ny `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Miverina `Err` fisehon'ny vaovao raha tsy mahafeno ny allocator ny habe sy ny fampifanarahana faneren'ny ny allocator, na raha mitombo raha tsy izany dia ho levona mandrakizay.
    ///
    /// Entanina ny fampiharana mba hamerina `Err` amin'ny havizanan'ny fahatsiarovana fa tsy hikoropaka na hanala zaza, saingy tsy fepetra hentitra izany.
    /// (Manokana:*ara-dalàna* ny fampiharana an'io trait eo an-tampon'ny tranomboky fizarana zana-tany misy azy io izay tsy manadino ny fahatsiarovan-tena.)
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray fanomezana Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: satria ny `new_layout.size()` dia tsy maintsy lehibe kokoa na mitovy
        // `old_layout.size()`, na ny antitra sy ny fahatsiarovana vaovao fanomezana dia manan-kery ho an'ny mamaky sy manoratra ho an'ny `old_layout.size()` oktety.
        // Ary koa, satria mbola tsy nifanarahana ny fizarana taloha, dia tsy afaka mihoatra ny `new_ptr` izy io.
        // Noho izany, ny antso mankany `copy_nonoverlapping` dia azo antoka.
        // Ny fifanarahana fiarovana ho an'ny `dealloc` dia tsy maintsy tohanan'ny mpiantso.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Behaves toy ny `grow`, fa manome antoka ihany koa fa ny atiny vaovao dia napetraka ho aotra alohan'ny hamerenana azy.
    ///
    /// Ny sakana fahatsiarovana dia ahitana ireto atiny manaraka ireto aorian'ny fiantsoana mahomby mankany
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` dia voatahiry amin'ny fizarana voalohany.
    ///   * Ny Bytes `old_layout.size()..old_size` dia hotehirizina na aotra, arakaraka ny fampiharana ny mpizara.
    ///   `old_size` dia manondro ny haben'ny tsanganana fahatsiarovana alohan'ny antso `grow_zeroed`, izay mety ho lehibe kokoa noho ny habe izay nangatahina tany am-boalohany rehefa natokana.
    ///   * Bytes `old_size..new_size` dia aotra.`new_size` dia manondro ny haben'ny ny fitadidiana andian-tsoratra niverina ny `grow_zeroed` antso.
    ///
    /// # Safety
    ///
    /// * `ptr` tsy maintsy maneho ny andian-tsoratra ny fahatsiarovana [*currently allocated*] alalan'ny allocator ity.
    /// * `old_layout` tsy maintsy [*fit*] io sakana fitadidiana io (Ny adihevitra `new_layout` dia tsy mila sahaza azy.).
    /// * `new_layout.size()` dia tokony ho lehibe kokoa na mitovy amin'ny `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Miverina `Err` fisehon'ny vaovao raha tsy mahafeno ny allocator ny habe sy ny fampifanarahana faneren'ny ny allocator, na raha mitombo raha tsy izany dia ho levona mandrakizay.
    ///
    /// Entanina ny fampiharana mba hamerina `Err` amin'ny havizanan'ny fahatsiarovana fa tsy hikoropaka na hanala zaza, saingy tsy fepetra hentitra izany.
    /// (Manokana:*ara-dalàna* ny fampiharana an'io trait eo an-tampon'ny tranomboky fizarana zana-tany misy azy io izay tsy manadino ny fahatsiarovan-tena.)
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray fanomezana Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: satria ny `new_layout.size()` dia tsy maintsy lehibe kokoa na mitovy
        // `old_layout.size()`, na ny antitra sy ny fahatsiarovana vaovao fanomezana dia manan-kery ho an'ny mamaky sy manoratra ho an'ny `old_layout.size()` oktety.
        // Ary koa, satria mbola tsy nifanarahana ny fizarana taloha, dia tsy afaka mihoatra ny `new_ptr` izy io.
        // Noho izany, ny antso mankany `copy_nonoverlapping` dia azo antoka.
        // Ny fifanarahana fiarovana ho an'ny `dealloc` dia tsy maintsy tohanan'ny mpiantso.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Fiezahana hampihena ny sakana fahatsiarovana.
    ///
    /// Miverina [`NonNull<[u8]>`][NonNull] vaovao misy tondro sy ny haben'ny fahatsiarovana natokana.Ny pointer dia mety amin'ny fitazonana angona nofaritan'i `new_layout`.
    /// Mba hanatanterahana izany, dia mety hihemotra ny allocator ny fanomezana ny `ptr` mba hanovozan-kevitra mifanaraka amin'ny fisehon'ny vaovao.
    ///
    /// Raha mamerina `Ok` ity, dia nafindra tamin'ity mpizara ity ny fananana ny tsanganana fahatsiarovana notondroin'i `ptr`.
    /// Ny fahatsiarovana mety na mety tsy ho afaka, ary tokony ho heverina ho azo ampiasaina intsony raha tsy nafindra indray ny mpiantso ny fiverenana indray amin'ny alalan'ny sarobidy io fomba fiasa.
    ///
    /// Raha io fomba `Err` miverina, dia tompon'ny andian-tsoratra ny fahatsiarovana dia tsy nafindra ho allocator ity, sy ny votoatin'ny andian-tsoratra ny fitadidiana dia unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` tsy maintsy maneho ny andian-tsoratra ny fahatsiarovana [*currently allocated*] alalan'ny allocator ity.
    /// * `old_layout` tsy maintsy [*fit*] io sakana fitadidiana io (Ny adihevitra `new_layout` dia tsy mila sahaza azy.).
    /// * `new_layout.size()` dia tokony ho kely kokoa na mitovy amin'ny `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Miverina `Err` raha toa ka tsy mifanaraka amin'ny haben'ny mpizara sy ny famerana ny mpizara, na raha toa ka tsy mahomby ny fihemorana.
    ///
    /// Entanina ny fampiharana mba hamerina `Err` amin'ny havizanan'ny fahatsiarovana fa tsy hikoropaka na hanala zaza, saingy tsy fepetra hentitra izany.
    /// (Manokana:*ara-dalàna* ny fampiharana an'io trait eo an-tampon'ny tranomboky fizarana zana-tany misy azy io izay tsy manadino ny fahatsiarovan-tena.)
    ///
    /// Mpanjifa ta-abort computation ho valin'ny fahadisoana iray fanomezana Ampirisihina hiantso ny [`handle_alloc_error`] ny asa, fa tsy mivantana fanononany ny fiandrianam-`panic!` na mitovy.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // Famonjena, satria tsy maintsy `new_layout.size()` ka lalina noho na mitovy
        // `old_layout.size()`, na ny antitra sy ny fahatsiarovana vaovao fanomezana dia manan-kery ho an'ny mamaky sy manoratra ho an'ny `new_layout.size()` oktety.
        // Ary koa, satria mbola tsy nifanarahana ny fizarana taloha, dia tsy afaka mihoatra ny `new_ptr` izy io.
        // Noho izany, ny antso mankany `copy_nonoverlapping` dia azo antoka.
        // Ny fifanarahana fiarovana ho an'ny `dealloc` dia tsy maintsy tohanan'ny mpiantso.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Miteraka "by reference" adaptatera noho izany ohatra ny `Allocator`.
    ///
    /// Ilay adaptatera tafaverina koa dia mampihatra `Allocator` ary hindrana tsotra izao.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: ny fifanarahana fiarovana dia tsy maintsy tohanan'ny mpiantso
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ny fifanarahana fiarovana dia tsy maintsy tohanan'ny mpiantso
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ny fifanarahana fiarovana dia tsy maintsy tohanan'ny mpiantso
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: ny fifanarahana fiarovana dia tsy maintsy tohanan'ny mpiantso
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}