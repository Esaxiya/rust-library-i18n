use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Na dia ampiasaina amina toerana iray aza io asa io ary azo tsipihina ny fampiharana azy, ny fanandramana teo aloha nanao izany dia nahatonga ny rustc hiadana:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout of a block of memory.
///
/// Ohatra iray amin'ny `Layout` dia mamaritra famaritana fahatsiarovana manokana.
/// Manangana `Layout` ianao ho fidirana omena ny mpizara.
///
/// Ny layout rehetra dia manana habe mifandraika sy fampifanarahana herinaratra avy amin'ny roa.
///
/// (Mariho fa ny fandrindran-takila dia *tsy* maintsy manana X-aotra habeny, na dia mitaky `GlobalAlloc` fa fangatahana rehetra ho fahatsiarovana tsy aotra ny habeny.
/// Ny mpiantso dia tsy maintsy miantoka fa voahaja ny fepetra toy izao, mampiasa mpaninjara manokana miaraka amin'ny takiana looser, na mampiasa ilay interface `Allocator` malemy kokoa.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // haben'ny tsangambato fahatsiarovana nangatahina, refesina amin'ny bytes.
    size_: usize,

    // fampifanarahana ny nangataka andian-tsoratra ny fitadidiana, refesina amin'ny oktety.
    // miantoka izahay fa herin'olon-droa hatrany io, satria ny API toa ny `posix_memalign` dia mitaky izany ary faneriterena mitombina ny fametrahana ireo mpanangana Layout.
    //
    //
    // (Na izany aza, dia tsy ifanahafany mitaky: hampifanaraka>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Constructs ny `Layout` avy amin'ny nomena `size` sy `align`, na miverina `LayoutError` raha misy ny fepetra manaraka ireto dia tsy nihaona:
    ///
    /// * `align` tsy tokony ho aotra,
    ///
    /// * `align` dia tokony ho herin'ny roa,
    ///
    /// * `size`, rehefa boribory hatrany amin'ny `align` marobe akaiky indrindra dia tsy tokony hihoatra ny rano (ie, ny sandan'ny boribory dia tokony ho ambany na mitovy amin'ny `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (herinaratra-of-two dia midika hoe align!=0.)

        // Ny habe boribory dia:
        //   size_rounds_up=(size + align, 1)&! (align, 1);
        //
        // Fantatsika avy any ambony fa hampifanaraka!=0.
        // Raha tsy misimisy ny manampy (mampifanaraka, 1) dia tsara ny fihodinana.
        //
        // Mifanohitra amin'izany,&-masking miaraka! (Hampifanaraka, 1) dia analana ihany no eny ambany-mba-potika.
        // Toy izany no mitranga, raha tondraka ny vola, ny&-mask tsy analana ampy hanafoana izany vokatra.
        //
        //
        // Ny etsy ambony dia midika fa ny fanaraha-maso ny fihoaran'ny famaranana dia ilaina sy ampy.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: ny fepetra momba ny `from_size_align_unchecked` dia
        // voamarina etsy ambony.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Miteraka fisehon'ny, nandika taratasim-bola rehetra.
    ///
    /// # Safety
    ///
    /// Ity no asa mampidi-doza toy ny tsy manamarina ny napetraka avy [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAFETY: ny miantso dia tsy maintsy miantoka fa `align` lehibe kokoa noho ny aotra.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ny kely indrindra amin'ny oktety haben'ny ho fahatsiarovana fisehon'ny andian-tsoratra ity.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Ny fara fahakeliny, byte fampifanarahana ho fahatsiarovana fisehon'ny andian-tsoratra ity.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Manangana `Layout` mety amin'ny fitazonana sanda `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // Famonjena, ny hampifanaraka azo antoka ny Rust ho herin 'ny roa sy
        // ny habe + align combo dia azo antoka fa tafiditra ao amin'ny habaka adiresinay.
        // Vokatr'izany dia ampiasao eto ny mpanorina tsy voamarina mba hialana amin'ny fampidirana kaody izay panics raha tsy voatsara tsara loatra izany.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Mamokatra fisehon'ny mamaritra ny rakitsoratra izay azo ampiasaina mba zarao manohana rafitra ho an'ny `T` (izay mety ho trait na unsized hafa karazana toy ny silaka).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // Famonjena, Jereo ny antony in `new` fa nahoana izany no mampidi-doza mampiasa ny Variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Mamokatra fisehon'ny mamaritra ny rakitsoratra izay azo ampiasaina mba zarao manohana rafitra ho an'ny `T` (izay mety ho trait na unsized hafa karazana toy ny silaka).
    ///
    /// # Safety
    ///
    /// Ity fiasa ity dia azo antoka ihany raha hiantsoana raha toa ka mihazona ireto fepetra manaraka ireto:
    ///
    /// - Raha `Sized` dia `Sized`, dia azo antoka ny miantso an'io fiasa io hatrany.
    /// - Raha ny unsized rambony ny `T` dia:
    ///     - [slice], avy eo ny halavan'ny rambony dia tokony ho integer intialé, ary ny haben'ny *soatoavina iray manontolo*(halavan'ny rambony be + aorika statically refy) dia tokony hiditra ao amin'ny `isize`.
    ///     - ny [trait object], dia ny vtable ampahany dia tsy maintsy manondro manoro ny marim-pototra ho an'ny karazana vtable `T` azony iray unsizing coersion, ary ny haben'ny ny *vidy* manontolo (mahery halavan'ny rambony + salantsalany fitohy tovona) dia tsy maintsy antonona in `isize`.
    ///
    ///     - (unstable) [extern type], dia azo antoka io antso io fa miantso foana, fa mety panic na raha tsy izany dia hamerina ny sandany ratsy, satria tsy fantatra ny firafitry ny karazana extern.
    ///     Io dia fihetsika mitovy amin'ny [`Layout::for_value`] amin'ny firesahana amin'ny rambony karazana ivelany.
    ///     - raha tsy izany, dia tsy mahazo conservatively hiantso asa ity.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: ampitainay amin'ireo miantso ireo fepetra takiana amin'ireo fiasa ireo
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // Famonjena, Jereo ny antony in `new` fa nahoana izany no mampidi-doza mampiasa ny Variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Mamorona `NonNull` mihantona, saingy mifanaraka tsara amin'ity Layout ity.
    ///
    /// Mariho fa ny sanda pointer dia mety hisolo tena ny tondro, izay midika fa tsy tokony hampiasaina ho toy ny sandan'ny "not yet initialized" sentinel izany.
    /// Ireo karazan-tsokosoko kamo dia tsy maintsy manara-maso ny fanombohana amin'ny fomba hafa.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAFETY: azo antoka fa tsy aotra ny align
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Miteraka fisehon'ny mamaritra ny firaketana an-tsoratra izay afaka hanao izany ilaina ny fisehon'ny maha `self`, fa ihany koa dia mifanaraka amin'ny fampifanarahana `align` (refesina amin'ny bytes).
    ///
    ///
    /// Raha efa nihaona tamin'ny fampifanarahana voatondro ny `self`, dia avereno `self`.
    ///
    /// Mariho fa ity fomba ity dia tsy manampy padding amin'ny habeny ankapobeny, na inona na inona endrik'ilay haverina naverina namboarina.
    /// Raha atao teny hafa, raha `K` manana habe 16, `K.align_to(32)` dia *mbola* manana habe 16.
    ///
    /// Mamerina lesoka iray raha toa ka manitsakitsaka ny fepetra voatanisa ao amin'ny [`Layout::from_size_align`] ny fitambaran'ny `self.size()` sy ny nomena `align`.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Mamerina ny habetsaky ny padding izay tsy maintsy ampidirintsika aorian'ny `self` hahazoana antoka fa hanome fahafaham-po `align` (refesina amin'ny bytes) ity adiresy manaraka ity.
    ///
    /// oh, raha `self.size()` dia 9, dia miverina 3 ny `self.padding_needed_for(4)`, satria izany no isa farafahakeliny bytes amin'ny padding ilaina hahazoana adiresy 4 mifanaraka (mihevitra fa ny adiresy fahatsiarovana mifandraika dia manomboka amin'ny adiresy 4 mifanaraka).
    ///
    ///
    /// Ny fiverenan'ny asa sarobidy io, raha tsy misy dikany `align` dia tsy hery-ny-roa.
    ///
    /// Mariho fa ny ilàna ny niverina sarobidy dia mitaky `align` ho latsaka na mitovy amin'ny fampifanarahana ny adiresy manomboka natokana manontolo ho an'ny andian-tsoratra ny fitadidiana.Ny fomba iray tery hanome fahafaham-po io dia mba ho azo antoka `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Boribory ny sanda dia:
        //   len_rounds_up=(len + align, 1)&! (align, 1);
        // ary averinay avy eo ny tsy fitovian'ny padding: `len_rounded_up - len`.
        //
        // Mampiasa Modular rafitrisa manerana:
        //
        // 1. ahitsy dia azo antoka fa> 0, ka align, 1 foana foana.
        //
        // 2.
        // `len + align - 1` Mety tondraka ny amin'ny `align - 1` indrindra, toy izany koa ny&-mask amin'ny `!(align - 1)` dia azo antoka fa ny zava-anananareo betsaka, dia `len_rounded_up` tenany ho 0.
        //
        //    Toy izany koa ny takelaka tafaverina, raha ampiana amin'ny `len`, dia manome 0, izay manome fahafaham-po kely ny fampifanarahana `align`.
        //
        // (Mazava ho azy, ny fiezahana hametraka sakana fahatsiarovana izay ny habeny sy ny firakofany be loatra amin'ny fomba etsy ambony dia tokony hahatonga ny mpanome hiteraka hadisoana ihany.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Mamorona lamina iray amin'ny alàlan'ny famolavolana ny haben'ity fisehosehoana ity hatramin'ny fampifanarahana marindrano maromaro.
    ///
    ///
    /// Izy io dia mitovy amin'ny fanampiana ny valin'ny `padding_needed_for` amin'ny haben'ny layout ankehitriny.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Tsy afa-manoatra ity.Teny nindramina avy amin'ny invariant of Layout:
        // > `size`, rehefa manodidina ny `align` marobe akaiky indrindra,
        // > tsy tondraka (izany hoe, ny boribory sarobidy dia tsy maintsy ho latsaky ny
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Miteraka fisehon'ny mamaritra ny firaketana an-tsoratra ho an'ny `n` tranga ny `self`, miaraka amin'ny mety habetsahan'ny padding eo amin'ny tsirairay mba ho azo antoka fa ny ohatra tsirairay dia nomena ny nangataka ny habeny sy ny fampifanarahana.
    /// Amin'ny fahombiazana, avereno `(k, offs)` izay `k` no fametrahana ny laharana ary `offs` no elanelana misy eo amin'ny fanombohan'ny singa tsirairay ao amin'ny laharana.
    ///
    /// Amin'ny fihoaran'ny arithmetika, avereno `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Tsy afa-manoatra ity.Teny nindramina avy amin'ny invariant of Layout:
        // > `size`, rehefa manodidina ny `align` marobe akaiky indrindra,
        // > tsy tondraka (izany hoe, ny boribory sarobidy dia tsy maintsy ho latsaky ny
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // Famonjena, self.align dia efa fantatra fa manan-kery sy alloc_size efa
        // padded efa.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Mamorona lamina iray mamaritra ny rakitsoratra ho an'ny `self` arahin'i `next`, ao anatin'izany ny padding ilaina mba hahazoana antoka fa mifanaraka tsara amin'ny `next`, fa *tsy misy padding*.
    ///
    /// Raha te hifanaraka amin'ny fisehon'ny fisehoana C `repr(C)` dia tokony hiantso `pad_to_align` ianao aorian'ny fanitarana ny lamina miaraka amin'ireo saha rehetra.
    /// (Tsy misy fomba mitovy ny toerana misy anao Rust fisehon'ny fanehoana `repr(Rust)`, as it is unspecified.)
    ///
    /// Mariho fa ny fampifanarahana ny vokatry ny fisehon'ny no ho ny ambony indrindra ny ny an'i `self` sy `next`, mba hahazoana antoka fampifanarahana ny faritra roa.
    ///
    /// Miverina `Ok((k, offset))`, izay `k` no firafitry ny concatenated `offset` firaketana an-tsoratra sy ny havany toerana, amin'ny oktety, ny nanombohan'ny ny `next` nandinika lalina ao anatin'ny firaketana an-tsoratra ny concatenated (mihevitra ho manana ho fa ny firaketana an-tsoratra mihitsy manomboka amin'ny offset 0).
    ///
    ///
    /// Amin'ny fihoaran'ny arithmetika, avereno `LayoutError`.
    ///
    /// # Examples
    ///
    /// Mba hikajiana ny firafitry ny rafitra `#[repr(C)]` sy ny offset any an-tsaha avy amin'ny laharan'ny saha:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Aza adino ny mamarana amin'ny `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // andramo fa mandeha io
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Mamorona lamina mamaritra ny rakitsoratra ho an'ny tranga `n` `self`, tsy misy padding eo anelanelan'ny tranga tsirairay.
    ///
    /// Mariho fa, tsy toy `repeat`, `repeat_packed` dia tsy manome antoka fa ny ohatra miverimberina ny `self` dia ho araka ny tokony mifanaraka, na dia ny nanome ohatra ny `self` dia araka ny tokony ho mifanaraka.
    /// Amin'ny teny hafa, raha ny fisehon'ny niverina avy `repeat_packed` no ampiasaina mba zarao ny nitsangana, dia tsy antoka fa singa rehetra ao amin'ny fihaingoana ho tsara mifanaraka.
    ///
    /// Amin'ny fihoaran'ny arithmetika, avereno `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Miteraka fisehon'ny mamaritra ny firaketana an-tsoratra ho an'ny `self` arahin'ny `next` tsy nisy fanampiny padding eo amin'ny roa.
    /// Koa satria tsy misy padding Ampidirina, ny fampifanarahana ny `next` no ilaina, ary tsy nampidirina * amin'ny rehetra + any an-vokatry ny fisehon'ny.
    ///
    ///
    /// Amin'ny fihoaran'ny arithmetika, avereno `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Mamorona lamina mamaritra ny firaketana ho an'ny `[T; n]`.
    ///
    /// Amin'ny fihoaran'ny arithmetika, avereno `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Ny masontsivana nomena `Layout::from_size_align` na hafa `Layout` Mpanao tsy manome fahafaham-po ny voarakitra sakana.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ilainay izany ho an'ny fidinana ambanin'ny trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}