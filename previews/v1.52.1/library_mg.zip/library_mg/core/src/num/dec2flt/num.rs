//! Fampiasana Utility ho an'ny bignum izay tsy misy dikany loatra hivadika fomba.

// FIXME Somary mampalahelo ny anaran'ity modely ity, satria ny modules hafa dia manafatra `core::num` ihany koa.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Andramo raha ny fanapahana ny bits rehetra tsy dia misy dikany kokoa noho ny `ones_place` dia mampiditra lesoka kely kokoa, mitovy, na lehibe kokoa noho ny 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Raha zero daholo ny sombintsombiny sisa tavela, dia= 0.5 ULP, raha tsy izany> 0.5 Raha tsy misy bits intsony (half_bit==0), ny eto ambany dia mamerina mitovy ihany koa.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Manova ny tadin'ny ASCII izay misy isa decimal fotsiny ho `u64`.
///
/// Tsy manao fanamarinana raha mihoatra na tsy mety ny endri-tsoratra, ka raha tsy mitandrina ny miantso dia valiny ny valiny ary afaka panic (na dia tsy `unsafe` aza).
/// Ankoatr'izay, ny tadin'ny poakaty dia raisina ho toy ny aotra.
/// Misy io fiasa io satria
///
/// 1. mampiasa `FromStr` amin'ny `&[u8]` dia mitaky `from_utf8_unchecked`, izay ratsy, ary
/// 2. ny manambatra ny valin'ny `integral.parse()` sy `fractional.parse()` dia sarotra kokoa noho io asa manontolo io.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Manova ny tadin'ny ASCII ho bignum.
///
/// Tahaka ny `from_str_unchecked`, ity fiasa ity dia miankina amin'ny parser handroaka ny tsy tarehimarika.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Mamono bignum ao anaty integer 64 bit.Panics raha be loatra ny isa.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Manala ambiny bitika.

/// Ny index 0 no kely indrindra ary ny elanelam-potoana dia misokatra misasaka toy ny mahazatra.
/// Panics raha asaina mamoaka bits betsaka kokoa noho ny tafiditra amin'ilay karazana fiverenana.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}