//! Ireo algorithma isan-karazany avy amin'ny taratasy.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Isan'ny sombin-danja amin'ny Fp
const P: u32 = 64;

// Izahay dia mitahiry fotsiny ny fanakaikezana tsara indrindra ho an'ny *exponents* rehetra *, noho izany dia azo esorina ny variable "h" sy ireo fepetra mifandraika amin'izany.
// Mampiroborobo ny zava-bita ho an'ny habaka kilobytes roa ity.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Amin'ny ankabeazan'ny maritrano dia misy habe mazava tsara ny fiasan'ny teboka mitsingevana, noho izany dia voafaritra tsara isaky ny miasa ny marim-pototra.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Amin'ny x86, ny x87 FPU dia ampiasaina amin'ny fiasa mitsingevana raha tsy misy ny extensions SSE/SSE2.
// Ny x87 FPU dia miasa miaraka amina volavolan-dalàna 80 amin'ny alàlan'ny default, izay midika fa hiasa hatramin'ny 80 bit ny fiasa ary hitranga ny fihodinana indroa rehefa aseho ny soatoavina amin'ny farany
//
// 32/64 soatoavina bit float.Mba hihoarana izany dia azo apetraka ny teny fifehezana FPU ka ny fanaovana ny computations dia tanterahina ao anaty fehezanteny tadiavina.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Rafitra iray ampiasaina hitehirizana ny sandan'ny teny fanaraha-maso FPU tany am-boalohany, mba hahafahany mamerina amin'ny laoniny rehefa nilatsaka ny firafitra.
    ///
    ///
    /// Ny x87 FPU dia fisoratana anarana 16-bits izay misy ireto sehatra manaraka ireto:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Ny tahirin-kevitra rehetra avy ao amin'ny sahan'i tsy ampy amin'ny IA-32 Architectures Software Developer ny Manual (Boky 1).
    ///
    /// Ny saha tokana misy ifandraisany amin'ireto kaody manaraka ireto dia ny PC, Control Precision.
    /// Ity saha ity dia mamaritra ny maha-marina ny asa ataon'ny FPU.
    /// Azo teo amin'ny:
    ///  - 0b00, fetra tokana ie, 32-bits
    ///  - 0b10, avo roa heny marina, 64-bits
    ///  - 0b11, avo roa heny voafetra, 80-bits (fanjakana misy anao) Ny sanda 0b01 dia natokana ary tsy tokony ampiasaina.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: ny torolàlana `fldcw` dia efa nohamarinina mba hiasa tsara
        // misy `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Mampiasa syntax ATT izahay hanohanana ny LLVM 8 sy LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Mametraka ny sahan'ny FPU mankany `T` ary mamerina `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Ampiasao ny sanda ho an'ny saha Control Precision izay mety amin'ny `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 sombiny
            8 => 0x0200, // 64 sombiny
            _ => 0x0300, // default, 80 bits
        };

        // Raiso ny sandan'ny teny fanaraha-maso tany am-boalohany mba hamerenana azy any aoriana, rehefa nilatsaka SAFETY ny firafitra `FPUControlWord`: ny torolàlana `fnstcw` dia efa voamarina fa afaka miasa tsara amin'ny `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Mampiasa syntax ATT izahay hanohanana ny LLVM 8 sy LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Mametraha ny teny fanaraha-maso amin'ny marim-pototra tadiavina.
        // Izany dia tanterahina amin'ny alàlan'ny fametahana ny volavolan-dalàna taloha (bits 8 sy 9, 0x300) ary soloina ny sainam-pirenena voatanisa etsy ambony.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Ny lalan'ny haingana an'i Bellerophon amin'ny fampiasana integer sy floats milina.
///
/// Izy io dia alaina ao anaty lahasa hafa mba hahafahana manandrana alohan'ny fananganana bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Mampitahainay amin'ny MAX_SIG akaiky ny farany ny sandany marina, fandavana haingana sy mora fotsiny izy io (ary koa manafaka ny ambin'ny kaody tsy manahy momba ny fidiran'ny rano).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Ny lalan-kaleha dia miankina amin'ny aritmetika ho boribory amin'ny isa marina raha tsy misy boribory eo anelanelany.
    // Ao amin'ny x86 (tsy misy SSE na SSE2) dia mila ovaina ny fametrahana ny fitahirizana x87 FPU ka mihodina mivantana mankany amin'ny 64/32 bit.
    // Ny lahasa `set_precision` dia mitandrina amin'ny fametrahana ny marina amin'ny maritrano izay mitaky fametrahana azy amin'ny fanovana ny fanjakana manerantany (toy ny teny fanaraha-maso ny x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ny tranga e <0 dia tsy azo aforitra ao amin'ny branch hafa.
    // Ny hery miiba dia miteraka ampahany miverina miverimberina amin'ny mimari-droa, izay boribory, izay miteraka lesoka tena izy (ary indraindray misy dikany lehibe!) Amin'ny valiny farany.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon dia kaody tsy misy dikany voamarina amin'ny famakafakana isa tsy misy dikany.
///
/// Mivezivezy `` f '' amin'ny float misy 64 bit significanceand ary mampitombo azy amin'ny fomba akaiky indrindra `10^e` (amin'ny endrika teboka mitsingevana mitovy).Matetika io dia ampy hahazoana ny valiny marina.
/// Na izany aza, rehefa manakaiky ny antsasaky ny fitsangatsanganana (ordinary) roa ny valiny, ny lesoka boribory mitambatra amin'ny fampitomboana fomba roa dia midika fa ny vokany dia mety ho tapaka bitika vitsivitsy.
/// Rehefa mitranga izany dia manamboatra ny zavatra rehetra ny Algorithm R miverimberina.
///
/// Ny "close to halfway" vita tanana dia natao marimarina tamin'ny famakafakana isa tao anaty taratasy.
/// Amin'ny tenin'i Clinger:
///
/// > Slop, aseho amin'ny singa bitika kely indrindra, dia tafiditra ao anatin'ny hadisoana
/// > nangonina nandritra ny kajy teboka mitsingevana ny fanakaiky ny f * 10 ^ e.(Slop dia
/// > tsy voafatotra amin'ny lesoka marina, fa fehezin'ny elanelam-potoana z sy
/// > ny fomba mety indrindra azo ampiasana izay mampiasa p bit ny significanceand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Ny tranga abs(e) <log5(2^N) dia ao amin'ny fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ampy ve ny tampon-trano ka mahavita miovaova rehefa mihodinkodina mankany amin'ny n b?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algorithme iterative izay manatsara ny teboka mitsingevana `f * 10^e`.
///
/// Ny iteration tsirairay dia mahazo singa iray amin'ny toerana farany akaiky kokoa, izay mazava ho azy fa maharitra ela tokoa ny fivangongoana raha toa ka tapaka kely i `z0`.
/// Soa ihany, rehefa ampiasaina ho fallback ho an'ny Bellerophon, ny fanombohana fanombohana dia miala amin'ny ULP iray.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Mitadiava integer `x`, `y` tsara ka `x / y` dia `(f *10^e) / (m* 2^k)`.
        // Tsy misoroka ny fiatrehana ireo mari-pamantarana `e` sy `k` fotsiny ihany koa isika fa manafoana ny herin'ny roa mahazatra amin'ny `10^e` sy `2^k` mba hahatonga ny isa ho kely kokoa.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ity dia nosoratana somary somary somary nanaitra ihany satria tsy manohana isa ratsy ireo bignum-tsika, noho izany dia ampiasainay ny mombamomba ny sanda + marika feno.
        // Ny fampitomboana miaraka amin'ny m_digits dia tsy afaka misondrotra.
        // Raha toa ka lehibe ny `x` na `y` ka mila manahy ny amin'ny fihoaram-pefy isika dia ampy ihany koa izy ireo ka nahenan'ny `make_ratio` ny sombin-javatra amin'ny isa 2 ^ 64 na mihoatra.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Aza mila x intsony, mitahiry clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Mbola mila y, manaova kopia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Raha nomena `x = f` sy `y = m` izay `f` dia maneho tarehimarika desimaly toy ny mahazatra ary `m` no tandindon'ny fanatonana teboka mitsingevana, ataovy mitovy ny `(f *10^e) / (m* 2^k)` ny tahan'ny `x / y`, mety ahena amin'ny herin'ny roa tonta.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, afa-tsy ny fihenan'ny hery roa ho roa.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Tsy mety hihoatra izany satria mitaky `e` tsara sy `k` ratsy, izay mety hitranga amin'ny sanda manakaiky ny 1 ihany, izay midika fa ho kely dia kely ny `e` sy `k`.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Tsy afaka miroborobo koa io, jereo etsy ambony.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), mihena indray amin'ny hery iraisan'ny roa.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Mifanaraka amin'izany, ny Algorithm M no fomba tsotra indrindra hanovana ny desimal ho float.
///
/// Isika dia mamorona tahan'ny izay mitovy amin'ny `f * 10^e`, avy eo manipy herin'ny roa mandra-pahatongany manome float signifikanand.
/// Ny exponent binary `k` dia ny isan'ny nampitomboantsika isa roa na isa ho isa, isaky ny `f *10^e` amin'ny fotoana rehetra dia mitovy `(u / v)* 2^k`.
/// Rehefa hitantsika fa tena ilaina dia mila mihodinkodina fotsiny isika amin'ny alàlan'ny fizahana ny ambiny fizarana, izay atao amin'ny asan'ny mpanampy lavitra etsy ambany.
///
///
/// Ity algorithm ity dia miadana be, na dia misy aza ny fanatsarana voalaza ao amin'ny `quick_start()`.
/// Na izany aza, io no algorithms tsotra indrindra hanamboarana ny valim-pifamoivoizana, ny fidiranana ary ny vokatra tsy mahazatra.
/// Ity fampiharana ity dia mandray andraikitra rehefa tototry ny tototry ny Bellerophon sy ny Algorithm R.
/// Mora ny mamantatra ny làlan-kizorana sy ny safo-drano: mbola tsy marimaritra iraisana ny tahan'ny, fa ny exponent minimum/maximum kosa dia tratra.
/// Raha tratry ny safo-drano dia miverina tsy misy fetra fotsiny isika.
///
/// Sarotra kokoa ny fikirakirana ny fidirana anaty sy ny subnormaly.
/// Ny olana lehibe iray dia ny, miaraka amin'ny exponent farafahakeliny, ny tahan'ny mety mbola lehibe loatra amin'ny hevand iray.
/// Jereo underflow() raha mila fanazavana.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME azo atao fanatsarana: ankapobeny ny big_to_fp hahafahantsika manao ny mitovy amin'ny fp_to_float(big_to_fp(u)) eto, raha tsy misy ny fihodinana roa.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Mila mijanona amin'ny exponent farafaharatsiny isika, raha miandry hatramin'ny `k < T::MIN_EXP_INT`, dia miala roa.
            // Mampalahelo fa midika izany fa tsy maintsy manokana isa ara-dalàna isika miaraka amin'ny exponent farafaharatsiny.
            // FIXME mahita famolavolana kanto kokoa, saingy tantano ny fitsapana `tiny-pow10` hahazoana antoka fa marina izany!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Mandingana ny ankamaroan'ny famerenana Algorithm M amin'ny fanamarinana ny halavany.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Ny halavan'ny bit dia tombantombana amin'ny fotodrafitrasa roa fototra, ary log(u / v) = log(u), log(v).
    // Ny tombana dia miala amin'ny ankapobeny 1, fa tombana ambany foana, ka ny lesoka amin'ny log(u) sy log(v) dia mitovy marika ary manafoana (raha samy lehibe).
    // Noho izany ny lesoka ho an'ny log(u / v) dia iray ihany koa.
    // Ny tahan'ny kendrena dia iray izay misy u/v ao anaty marindrano an-toerana.Noho izany ny fepetra famaranana antsika dia log2(u / v) satria ny bikan'ny significanceand, plus/minus iray.
    // FIXME Ny mijery ny faharoa dia afaka manatsara ny tombana ary misoroka fisarahana hafa.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow na subnormal.Avelao ho an'ny lahasa lehibe izany.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // TototraAvelao ho an'ny lahasa lehibe izany.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ny tahan'isa dia tsy misy marindrano misy elanelam-potoana farafahakeliny, noho izany dia mila mamoritra bits tafahoatra isika ary manitsy ny mpanara-baovao mifanaraka amin'izany.
    // Toy izao ny tena sandany:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(soloin'i Rem)
    //
    // Noho izany, rehefa ny bits boribory dia== 0.5 ULP dia manapa-kevitra samirery ny fihodinana izy ireo.
    // Rehefa mitovy izy ireo ary tsy aotra ny ambiny, dia mbola mila faribolana ny sandany.
    // Rehefa 1/2 ihany ny bitsika boribory ary zero ny ambiny dia manana toe-javatra antsasaky ny mitovy isika.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Orinasa mahazatra sy mahitsy, misavoritaka amin'ny alàlan'ny fihodinana miankina amin'ny ambin'ny fizarana iray.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}