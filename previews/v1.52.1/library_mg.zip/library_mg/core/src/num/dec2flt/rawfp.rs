//! Fikitika bitika amin'ny floats tsara IEEE 754.Ny tarehimarika ratsy dia tsy ary mila karakaraina.
//! Ny isa isa mitsingevana ara-dalàna dia manana solontena canonika toy ny (frac, exp) ka ny sandany dia 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) izay ny N no isan'ny bits.
//!
//! Ny subnormaly dia samy hafa kely sy hafahafa, saingy mihatra izany fitsipika izany.
//!
//! Eto anefa dia asehontsika azy ireo ho (sig, k) manana f miabo tsara, ka ny f *
//! 2 <sup>e</sup> .Ankoatry ny fanaovana mazava ny "hidden bit", ity dia manova ny mpanelanelana amin'ilay antsoina hoe fiovana mantissa.
//!
//! Amin'ny fomba hafa, ny floats mahazatra dia soratana ho (1) fa eto kosa dia soratana ho (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Antsoinay hoe (1) ny **fisoloana tena** ary (2) ny **fisoloana**.
//!
//! Fitaovana marobe amin'ity modely ity no mitazona isa mahazatra fotsiny.Ny fahazarana dec2flt dia mandray ny làlana miadana (Algorithm M) manerantany ho an'ny isa kely sy tena lehibe.
//! Io algorithm io dia mila next_float() fotsiny izay mitantana subnormaly sy aotra.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// trait mpanampy iray hialana amin'ny famerenana amin'ny laoniny ny kaody fiovam-po rehetra ho an'ny `f32` sy `f64`.
///
/// Jereo ny fanehoan-kevitry ny modely ho an'ny ray aman-dreny momba ny antony ilana izany.
///
/// Tsy tokony ampiharina amin'ny karazana hafa mihitsy ve ** ho an'ny karazany hafa na ampiasaina any ivelan'ny modely dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Karazana ampiasain'ny `to_bits` sy `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Manao transmutation manta amin'ny integer.
    fn to_bits(self) -> Self::Bits;

    /// Manao transmutation manta avy amin'ny integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Miverina ny sokajy tafiditra ao amin'ity isa ity.
    fn classify(self) -> FpCategory;

    /// Miverina ny mantissa, exponent ary manao sonia toy ny integer.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodes ny float.
    fn unpack(self) -> Unpacked;

    /// Casts avy amin'ny integer kely izay azo soloina tsara.
    /// Panic raha tsy azo soloina ny integer, ny kaody hafa ao amin'ity modely ity dia manome antoka fa tsy hamela izany hitranga mihitsy.
    fn from_int(x: u64) -> Self;

    /// Mahazo ny sanda 10 <sup>e</sup> amin'ny latabatra voaisa efa voaisa.
    /// Panics ho an'ny `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Izay lazain'ilay anarana.
    /// Mora kokoa ny kaody henjana noho ny mampihetsi-po amin'ny intrinsika ary manantena ny hamoritra azy tsy tapaka ny LLVM.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Conservative voafatotra amin'ireo tarehimarika fidiran'ny desimal tsy afaka mamokatra mihoatra na aotra na
    /// subnormaly.Angamba ny exponent desimaly ny sanda ara-dalàna indrindra, noho izany ny anarana.
    const MAX_NORMAL_DIGITS: usize;

    /// Rehefa manana isa toerana lehibe kokoa noho io ny tarehimarika decimal manan-danja indrindra dia azo antoka fa boribory hatramin'ny tsy manam-petra ny isa.
    ///
    const INF_CUTOFF: i64;

    /// Rehefa manana isa toerana ambany kokoa ny tarehimarika decimal manan-danja indrindra dia azo antoka fa boribory ho zero ny isa.
    ///
    const ZERO_CUTOFF: i64;

    /// Ny isan'ny bits amin'ny exponent.
    const EXP_BITS: u8;

    /// Ny isan'ny sombintsombiny ao amin'ny significanceand,*ao anatin'izany* ilay bitika miafina.
    const SIG_BITS: u8;

    /// Ny isan'ny sombintsombiny ao amin'ny significanceand,*tsy manilika* ny kely miafina.
    const EXPLICIT_SIG_BITS: u8;

    /// Ny exponent ara-dalàna faran'izay lehibe amin'ny fisoloana tena.
    const MAX_EXP: i16;

    /// Ny exponent ara-dalàna farafahakeliny amin'ny fisoloana tena, tsy anisany subnormaly.
    const MIN_EXP: i16;

    /// `MAX_EXP` ho an'ny solontena azo ampidirina, izany hoe ampiharina amin'ny fiovana.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encode (izany hoe, miaraka amin'ny fitongilanana)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ho an'ny solontena azo ampidirina, izany hoe ampiharina amin'ny fiovana.
    const MIN_EXP_INT: i16;

    /// Ny hevitry ny normalized ambony indrindra amin'ny solontena.
    const MAX_SIG: u64;

    /// Ny manan-danja voafaritra ara-dalàna amin'ny solontena.
    const MIN_SIG: u64;
}

// Ny ankamaroan'ny vahaolana amin'ny #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Miverina ny mantissa, exponent ary manao sonia toy ny integer.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Fitongilanana miandany + fiovan'ny mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe dia tsy azo antoka na `as` dia mihodina manodidina ny sehatra rehetra.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Miverina ny mantissa, exponent ary manao sonia toy ny integer.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Fitongilanana miandany + fiovan'ny mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe dia tsy azo antoka na `as` dia mihodina manodidina ny sehatra rehetra.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Mivadika `Fp` amin'ny karazana float machine akaiky indrindra.
/// Tsy mahazaka valiny tsy mahazatra.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f dia 64 bit, noho izany xe dia manana fiovan'ny mantissa 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Amboary ny tapa-64-bit ho an'ny T::SIG_BITS amin'ny antsasaky ny-even.
/// Tsy mahazaka ny fivezivezena be loatra.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Amboary ny fiovan'ny mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Mifanohitra amin'ny `RawFloat::unpack()` ho an'ny isa ara-dalàna.
/// Panics raha ny validand na exponent dia tsy manan-kery ho an'ny isa ara-dalàna.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Esory ny miafina kely
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Amboary ny exponent ho an'ny bias bias sy ny fiovan'ny mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Avelao ny mari-pamantarana amin'ny 0 ("+"), miisa tsara daholo ny tarehintsika
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Manamboara fomba mahazatra.Ny mantissa an'ny 0 dia avela ary hanangana zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Ny exponent en encode dia 0, ny bit ny sign dia 0, noho izany dia mila mandika fotsiny ny sombintsombiny isika.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Manodidina ny bignum miaraka amin'ny Fp.Manodidina ny 0.5 ULP miaraka amin'ny antsasaky ny-even.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Notapahinay ny sombintsombiny rehetra alohan'ny index `start`, izany hoe, miovaova mahomby amin'ny alàlan'ny `start` isika, noho izany dia ity ihany koa ny mpanentana ilaintsika.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) arakaraka ny bikan'ny truncated.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Mahita ny isa isa mitsingevana lehibe indrindra fa kely noho ny adihevitra.
/// Tsy mandray subnormals, aotra, na Exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Tadiavo ny isa kely mitsinkafona indrindra fa lehibe kokoa noho ilay adihevitra.
// Ity asa ity dia mahavoky, izany hoe, next_float(inf) ==inf.
// Tsy toy ny ankamaroan'ny kaody ato amin'ity maodely ity fa io fampiasa io dia mibaiko aotra, subnormaly ary infinities.
// Na izany aza, toy ny kaody hafa rehetra eto, dia tsy mifandraika amin'ny NaN sy ny isa ratsy izany.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Toa tsara loatra izany nefa tsy mandeha.
        // 0.0 dia voahodidin'ny teny zero rehetra.Ny subnormaly dia 0x000m ... m izay misy ny mantissa.
        // Manokana, ny faran'izay kely indrindra dia 0x0 ... 01 ary ny lehibe indrindra dia 0x000F ... F.
        // Ny isa ara-dalàna kely indrindra dia 0x0010 ... 0, ka io tranga zoro io koa dia mandeha.
        // Raha mihoatra ny mantissa ny fitomboana dia mampiakatra ny mpanelanelana araka ny itiavantsika azy ny tombony, ary lasa zero ny mantissa.
        // Noho ny fivoriambe bitika miafina dia ity koa no tena tadiavintsika!
        // Farany, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}