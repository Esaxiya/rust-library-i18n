//! Karazana lesoka amin'ny fiovam-po ho amina karazana tsy miankina.

use crate::convert::Infallible;
use crate::fmt;

/// Niverina ny karazana lesoka rehefa tsy nahomby ny fanovana karazana fanaraha-maso voaisa.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Aleo mifanentana fa tsy terena mba hahazoana antoka fa hiasa hatrany ny kaody toa ny `From<Infallible> for TryFromIntError` etsy ambony raha lasa alias ny `!` ny `Infallible`.
        //
        //
        match never {}
    }
}

/// Hadisoana izay azo averina rehefa manonitra integer.
///
/// Ity lesoka ity dia ampiasaina ho karazana hadisoana ho an'ny fiasa `from_str_radix()` amin'ireo karazana integer voalohany, toy ny [`i8::from_str_radix`].
///
/// # Antony mety hitranga
///
/// Anisan'ny antony hafa, `ParseIntError` dia azo atsipy noho ny fitarihana na ny fivoahana ny fotsifotsy ao amin'ny kofehy ohatra, rehefa azo avy amin'ny fampiasa mahazatra.
///
/// Ny fampiasana ny fomba [`str::trim()`] dia miantoka fa tsy misy toerana fotsy intsony alohan'ny famaritana.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum hitahiry ireo karazana lesoka isan-karazany izay mety hiteraka tsy fahombiazan'ny famaritana integer.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Foana ny lanjan'ila.
    ///
    /// Anisan'ny antony hafa, hamboarina io variant io rehefa manamboatra tadin-dokanga tsy misy izy.
    Empty,
    /// Ahitana tarehimarika tsy mety ao anatin'ny tontolon-keviny.
    ///
    /// Anisan'ireo antony hafa, hamboarina io variant io rehefa manamboatra kofehy misy char tsy ASCII.
    ///
    /// Io variant io dia namboarina ihany koa rehefa misy `+` na `-` diso toerana ao anaty kofehy na irery na eo afovoan'ny isa iray.
    ///
    ///
    InvalidDigit,
    /// Integer dia lehibe loatra ka tsy tehirizina ao anaty karazana integer kendrena.
    PosOverflow,
    /// Integer dia kely loatra ka tehirizina amin'ny karazana integer kendrena.
    NegOverflow,
    /// Ny sanda dia Zero
    ///
    /// Ity variant ity dia havoaka rehefa manana sanda nolavina ny tadin'ny parsing, izay tsy ara-dalàna amin'ny karazany tsy aotra.
    ///
    Zero,
}

impl ParseIntError {
    /// Mamoaka ny antony amin'ny antsipiriany amin'ny famaritana ny integer tsy mahomby.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}