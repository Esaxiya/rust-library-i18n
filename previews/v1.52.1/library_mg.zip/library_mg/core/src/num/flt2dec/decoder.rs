//! Mamaritra ny lanjan-teboka mitsingevana ho faritra sy elanelana diso.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Voamarina ny sanda voafetra tsy voasonia, toy izany:
///
/// - Ny sanda voalohany dia mitovy amin'ny `mant * 2^exp`.
///
/// - Ny isa rehetra avy amin'ny `(mant - minus)*2^exp` ka hatramin'ny `(mant + plus)* 2^exp` dia manodidina ny sanda voalohany.
/// Tsy tafiditra raha tsy rehefa `inclusive` dia `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Ny mantissa miakatra.
    pub mant: u64,
    /// Ny elanelan'ny hadisoana ambany.
    pub minus: u64,
    /// Ny elanelana diso ambony.
    pub plus: u64,
    /// Ilay exponent iraisana amin'ny base 2.
    pub exp: i16,
    /// Marina rehefa tafiditra ny elanelana diso.
    ///
    /// Ao amin'ny IEEE 754, dia marina izany rehefa nisy ny mantissa tany am-boalohany.
    pub inclusive: bool,
}

/// Nesorina ny sandan'ny tsy voasonia.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, na tsara na ratsy.
    Infinite,
    /// Zero, na tsara na ratsy.
    Zero,
    /// Isa voafetra miaraka amin'ireo sahan-kevitra voadika.
    Finite(Decoded),
}

/// Karazan-teboka mitsingevana izay mety ho `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Ny sanda ara-dalàna voafaritra farafahakeliny.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Miverina famantarana (marina rehefa ratsy) sy `FullDecoded` sarobidy avy nomena fotoana nitsinkafona isa.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // mpiara-monina: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode mitahiry mandrakariva ny mpandray anjara, noho izany dia mihena ny mantissa ho an'ny subnormaly.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // mpiara-monina: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // aiza ny maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // mpiara-monina: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}