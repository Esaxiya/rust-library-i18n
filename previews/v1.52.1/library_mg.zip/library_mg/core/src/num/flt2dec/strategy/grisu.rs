//! Rust fampifanarahana ny Grisu3 algorithm voalaza ao amin'ny "Pirinty natao tamin'ny nitsinkafona-Point Numbers haingana ary marina tsara ny amin'ny Integers" [^ 1].
//! Mampiasa tabilao efa voavoatra 1KB eo ho eo, ary avy eo, haingana be ho an'ny ankamaroan'ny fampidirana.
//!
//! [^1]: Florian Loitsch.2010. Fanontana nomerao isa mitsingevana haingana ary
//!   mifanaraka tsara amin'ny isa.SIGPLAN tsia.45, 6 (Jona 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// jereo ny hevitra ao amin'ny `format_shortest_opt` raha ny antony.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Nomena `x > 0`, mamerina `(k, 10^k)` toy izany `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Ny fampiharana fomba fohy indrindra ho an'i Grisu.
///
/// Miverina amin'ny `None` izy io rehefa mamerina solontena tsy hita hafa raha tsy izany.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // mila lafika telo fanampiny farafahakeliny isika

    // atombohy amin'ny sanda ara-dalàna miaraka amin'ny mpizara mahazatra
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // mitadiava `cached = 10^minusk` toy izany `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // satria namboarina `plus`, midika izany `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // raha omena ny safidintsika `ALPHA` sy `GAMMA`, ity dia mametraka `plus * cached` ho `[4, 2^32)`.
    //
    // Mazava ho azy fa faniriana ny hampitomboana ny `GAMMA - ALPHA`, mba tsy hila hery cache betsaka amin'ny 10, fa misy kosa ny fiheverana:
    //
    //
    // 1. te hitazona `floor(plus * cached)` ao anatin'ny `u32` izahay satria mila fizarana lafo.
    //    (tsy tena azo sorohina izany, takiana amin'ny tombana marina.)
    // 2.
    // ny ambin'ny `floor(plus * cached)` dia mihabetsaka hatrany amin'ny 10, ary tsy tokony hihoatra.
    //
    // ny voalohany manome `64 + GAMMA <= 32`, raha ny faharoa kosa manome `10 * 2^-ALPHA <= 2^64`;
    // -60 ary -32 no elanelana faran'izay avo indrindra amin'ity famerana ity, ary V8 koa dia mampiasa azy ireo.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // mizana fps.manome ny fahadisoana farany an'ny 1 ulp (voaporofo avy amin'ny Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-zotra minus tena izy
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // ambonin'ny `minus`, `v` ary `plus` dia fanisana * isa (error <1 ulp).
    // satria tsy fantatsika fa tsara na ratsy ny lesoka, dia manakaiky roa no ampiasainay ary manana ny hadisoana farany ambony 2 ulps.
    //
    // ny "unsafe region" dia elanelam-potoana malalaka izay novokarinay tamin'ny voalohany.
    // ny "safe region" dia elanelam-potoana mpandala ny nentin-drazana izay ekentsika ihany.
    // manomboka amin'ny repr marina ao anatin'ny faritra tsy azo antoka isika, ary manandrana mitady ny repr akaiky indrindra amin'ny `v` izay ao anatin'ny faritra azo antoka ihany koa.
    // raha tsy afaka isika dia milavo lefona.
    //
    let plus1 = plus.f + 1;
    // aoka plus0 = plus.f, 1;//raha mila fanazavana fotsiny dia avelao minus0 = minus.f + 1;//ho an'ny fanazavana ihany
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // exponent nizarana

    // zarao ny `plus1` ho ampahany tsy miova sy zara.
    // Ny ampahany tsy azo antoka dia azo antoka fa tafiditra ao amin'ny u32, satria ny herin'ny cache dia manome antoka ny `plus < 2^32` ary ny `plus.f` ara-dalàna dia ambany noho ny `2^64 - 2^4` foana noho ny fitakiana mazava tsara.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // kajy ny lehibe indrindra `10^max_kappa` tsy mihoatra ny `plus1` (toy izany no `plus1 < 10^(max_kappa+1)`).
    // ity dia fetra ambony `kappa` etsy ambany.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: raha `k` no integer st lehibe indrindra
    // `0 <= y mod 10^k <= y - x`,              dia `V = floor(y / 10^k) * 10^k` any `[x, y]` ary iray amin'ireo fanehoana fohy indrindra (miaraka amin'ny isan'ny manan-danja kely dia kely isa) amin'izany isan-karazany.
    //
    //
    // tadiavo ny halavan'ny tarehimarika `kappa` eo anelanelan'ny `(minus1, plus1)` toy ny isaky ny Theorem 6.2.
    // Theorem 6.2 dia azo raisina hanilihana `x` amin'ny fangatahana `y mod 10^k < y - x` fa tsy.
    // (oh: `x` =32000, `y` =32777; `kappa` =2 hatramin'ny `y mod 10 ^ 3=777 <y, x=777`.) ny algorithm dia miankina amin'ny dingana fanamarinana taty aoriana hanilihana ny `y`.
    //
    let delta1 = plus1 - minus1;
    // avelao ny delta1int=(delta1>> e) araka ny fampiasana;//ho an'ny fanazavana ihany
    let delta1frac = delta1 & ((1 << e) - 1);

    // manome ampahany tsy tapaka, raha manamarina ny maha-marina ny dingana tsirairay.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // tarehimarika mbola ho adika
    loop {
        // manana tarehimarika iray farafahakeliny farafahakeliny foana izahay, toy ny invariants `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (manaraka an'io `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // zarao `remainder` amin'ny `10^kappa`.samy voafintin'ny `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; hitanay ny `kappa` marina.
            let ten_kappa = (ten_kappa as u64) << e; // mizana 10 ^ kappa miverina amin'ny mpanelanelana nizara
            return round_and_weed(
                // SAFETY: nataonay voalohany io fahatsiarovana io etsy ambony.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // tapaho ny tadivavarana rehefa navoakanay ny isa tsy miova rehetra.
        // ny isan'ny tarehimarika dia `max_kappa + 1` ho `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // avereno ireo invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // manapaha ampahany sombiny, raha manamarina ny maha-marina ny dingana tsirairay.
    // amin'ity indray mitoraka ity dia miantehitra amin'ny fampitomboana miverimberina isika, satria ny fizarazarana ho very ny marina.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // ny tarehimarika manaraka dia tokony ho lehibe satria efa nosedraina izahay talohan'ny nanaparitahana ireo invariants, izay misy ny `m = max_kappa + 1` (#ny isa amin'ny ampahany lehibe):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // tsy hihoatra, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // zarao `remainder` amin'ny `10^kappa`.
        // samy esorina amin'ny `2^e / 10^kappa`, ka ity farany dia voatazona eto.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // mpanampy miharihary
            return round_and_weed(
                // SAFETY: nataonay voalohany io fahatsiarovana io etsy ambony.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // avereno ireo invariants
        kappa -= 1;
        remainder = r;
    }

    // izahay dia namorona isa lehibe rehetra `plus1`, saingy tsy azo antoka raha io no tsara indrindra.
    // ohatra, raha ny `minus1` dia 3.14153 ... ary ny `plus1` dia 3.14158 ..., misy solontena fohy 5 tsy mitovy amin'ny 3.14154 ka hatramin'ny 3.14158 fa isika irery no manana ny lehibe indrindra.
    // tsy maintsy ahenantsika tsikelikely ny tarehimarika farany ary jereo raha ity no repr tsara indrindra.
    // misy kandidà 9 farafaharatsiny (..1 ka ..9), ka haingana dia haingana izany.(Dingana "rounding")
    //
    // ny fiasa dia manamarina raha ity "optimal" repr ity dia ao anatin'ny elanelan'ny ulp, ary koa, azo inoana fa ny "second-to-optimal" repr dia mety ho tonga lafatra indrindra noho ny lesoka boribory.
    // amin'ny lafiny roa dia miverina `None` ity.
    // (Dingana "weeding")
    //
    // ny adihevitra rehetra eto dia esorina amin'ny sanda `k` mahazatra (fa implicit), ka:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (ary koa, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ary koa, `threshold > plus1v` avy amin'ireo invariants taloha)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // mamokatra fanakaikezana roa mankany `v` (tena `plus1 - v`) ao anatin'ny 1.5 ulps.
        // ny solontena vokariny dia tokony ho ny fanehoana akaiky indrindra azy roa.
        //
        // eto `plus1 - v` dia ampiasaina satria ny kajy dia atao amin'ny `plus1` mba hisorohana ny overflow/underflow (noho izany ireo anarana toa nivadika).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 am)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // ahenao ny tarehimarika farany ary mijanona amin'ny fisolo tena akaiky ny `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // miasa miaraka amin'ireo tarehimarika `w(n)` eo ho eo izahay, izay mitovy amin'ny `plus1 - plus1 % 10^kappa` amin'ny voalohany.rehefa avy nihazakazaka ny vatan'ny loop `n` fotoana, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // nametraka `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` izahay (arak'izany `sisa= plus1w(0)`) hanatsorana ny fanamarinana.
            // mariho fa ny `plus1w(n)` dia mitombo hatrany.
            //
            // manana fepetra telo hamaranana isika.na iza na iza amin'izy ireo dia hanao izay tsy ahafahan'ny loop mandroso, fa manana solontena marim-pototra iray farafaharatsiny fantatra ho akaiky an'i `v + 1 ulp` ihany izahay.
            // hanondro azy ireo ho TC1 amin'ny alàlan'ny TC3 ho an'ny fohy isika.
            //
            // TC1: `w(n) <= v + 1 ulp`, izany hoe ity no repr farany mety ho ny akaiky indrindra.
            // io dia mitovy amin'ny `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // atambatra amin'ny TC2 (izay manamarina raha `w(n+1)` is valid), izany dia manakana ny mety hihoarana ny fikajiana ny `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, izany hoe, ny repr manaraka dia azo antoka fa tsy boribory mankany `v`.
            // io dia mitovy amin'ny `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // ny lafiny ankavia dia mety hihoatra, fa fantatsika kosa `threshold > plus1v`, ka raha diso ny TC1 dia `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ary afaka mizaha soa aman-tsara isika raha `threshold - plus1w(n) < 10^kappa` kosa.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, izany hoe, ny repr manaraka dia
            // tsy akaiky kokoa ny `v + 1 ulp` noho ny amin'izao fotoana izao repr.
            // nomena `z(n) = plus1v_up - plus1w(n)`, lasa `abs(z(n)) <= abs(z(n+1))` ity.mihevitra indray fa diso ny TC1, manana `z(n) > 0` isika.manana tranga roa hodinihina isika:
            //
            // - rehefa `z(n+1) >= 0`: TC3 lasa `z(n) <= z(n+1)`.
            // satria mihabe ny `plus1w(n)` dia tokony hihena ny `z(n)` ary mazava fa diso izany.
            // - rehefa `z(n+1) < 0`:
            //   - TC3a: ny fepetra mialoha dia `plus1v_up < plus1w(n) + 10^kappa`.mihevitra fa diso ny TC2, `threshold >= plus1w(n) + 10^kappa` ka tsy afaka misondrotra.
            //   - TC3b: lasa `z(n) <= -z(n+1)` ny TC3, izany hoe `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   ny TC1 nolavina dia manome `plus1v_up > plus1w(n)`, noho izany dia tsy afaka misondrotra na midina izy rehefa atambatra amin'ny TC3a.
            //
            // Vokatr'izany dia tokony hijanona isika rehefa `TC1 || TC2 || (TC3a && TC3b)`.ity manaraka ity dia mitovy amin'ny inverse, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // ny repr fohy indrindra dia tsy afaka mifarana amin'ny `0`
                plus1w += ten_kappa;
            }
        }

        // zahao raha ity solontena ity ihany koa no fanehoana akaiky indrindra an'i `v - 1 ulp`.
        //
        // io dia mitovy amin'ny fepetra famaranana ho an'ny `v + 1 ulp`, miaraka amin'ny `plus1v_up` rehetra soloina `plus1v_down` fa tsy.
        // ny famakafakana tafahoatra dia mitazona mitovy.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Ankehitriny dia manana ny fisolo tena akaiky ny `v` isika eo anelanelan'ny `plus1` sy `minus1`.
        // malalaka loatra izany, na izany aza, noho izany dia lavinay ny `w(n)` tsy anelanelan'ny `plus0` sy `minus0`, izany hoe, `plus1 - plus1w(n) <= minus0` na `plus1 - plus1w(n) >= plus0`.
        // dia mampiasa ny zava-misy fa `threshold = plus1 - minus1` sy `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Ny fampiharana fomba fohy indrindra ho an'ny Grisu miaraka amin'ny fallback an'ny Dragon.
///
/// Tokony ampiasaina amin'ny ankamaroan'ny tranga izany.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SAFETY: Ny mpandinika indram-bola dia tsy ampy saina mba hamela antsika hampiasa `buf`
    // amin'ny branch faharoa, noho izany dia miala eto isika mandritra ny androm-piainana.
    // Fa tsy mampiasa afa-tsy `buf` izahay raha miverina `None` i X01 ka tsy maninona izany.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Ny fampiharana ny fomba marina sy raikitra ho an'i Grisu.
///
/// Miverina amin'ny `None` izy io rehefa mamerina solontena tsy hita hafa raha tsy izany.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // mila lafika telo fanampiny farafahakeliny isika
    assert!(!buf.is_empty());

    // normalize and scale `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // zarao ny `v` ho ampahany tsy miova sy zara.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // samy `v` taloha sy `v` vaovao (scaled by `10^-k`) dia misy lesoka <1 ulp (Theorem 5.1).
    // satria tsy fantatsika fa tsara na ratsy ny lesoka, dia manakaiky roa no ampiasainay ary manana ny hadisoana farany ambony 2 ulps (mitovy amin'ny tranga fohy indrindra).
    //
    //
    // ny tanjona dia ny hahitana ireo andiana tarehimarika boribory mifanentana izay iraisan'ny `v - 1 ulp` sy `v + 1 ulp`, ka matoky tanteraka izahay.
    // raha tsy azo atao izany dia tsy fantatsika hoe iza no marina output ho an'ny `v`, ka kivy izahay ary mihemotra.
    //
    // `err` dia voafaritra ho `1 ulp * 2^e` eto (mitovy amin'ny ulp ao amin'ny `vfrac`), ary horefesintsika izany isaky ny mizana `v`.
    //
    //
    //
    let mut err = 1;

    // kajy ny `10^max_kappa` lehibe indrindra tsy mihoatra ny `v` (araka izany `v < 10^(max_kappa+1)`).
    // ity dia fetra ambony `kappa` etsy ambany.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Raha miasa miaraka amin'ny fetra farany isa isika dia mila manafoana ny buffer alohan'ny tena fandefasana mba hisorohana ny fihodinana roa.
    //
    // mariho fa mila manitatra ny buffer indray isika rehefa mitranga ny fihodinana!
    let len = if exp <= limit {
        // oops, tsy afaka mamokatra isa * iray akory izahay.
        // azo atao izany rehefa, hoy, fa manana zavatra toa ny 9.5 isika ary mihodina ho 10.
        //
        // amin'ny fitsipika dia afaka miantso avy hatrany ny `possibly_round` amin'ny buffer foana isika, fa ny scaling `max_ten_kappa << e` amin'ny 10 dia mety hiteraka fihoaram-pefy.
        //
        // noho izany isika dia misavoritaka eto ary manitatra ny elanelana misy ny 10.
        // hampiakatra ny taha ratsy ratsy io, fa tena,*tena* kely fotsiny;
        // tsy misy dikany izany raha lehibe kokoa ny mantissa noho ny 60 bits.
        //
        // SAFETY: `len=0`, noho izany dia tsy misy dikany ny adidy fanatontosana an'ity fahatsiarovana ity.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // anaovanao faritra manontolo.
    // ny lesoka dia vaky tanteraka, ka tsy mila jerentsika amin'ity ampahany ity.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // tarehimarika mbola ho adika
    loop {
        // manana nomerao iray farafahakeliny farafaharatsiny izahay hanomezana invariants:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (Manaraka ho azy ny `remainder = vint % 10^(kappa+1)`)
        //
        //

        // zarao `remainder` amin'ny `10^kappa`.samy voafintin'ny `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // feno ve ny buffer?mihazakazaka ny passering boribory miaraka amin'ny ambiny.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SAFETY: efa nanomboka `len` byte maro izahay.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // tapaho ny tadivavarana rehefa navoakanay ny isa tsy miova rehetra.
        // ny isan'ny tarehimarika dia `max_kappa + 1` ho `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // avereno ireo invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // manome ampahany tapaka.
    //
    // amin'ny fitsipika dia afaka manohy ny nomerika farany misy isika ary manamarina ny tena marina.
    // indrisy fa miara-miasa amin'ny isa voafaritra refy izahay, ka mila criterion kely hahitantsika ny fiakaran'ny rano.
    // V8 mampiasa `remainder > err`, izay lasa diso rehefa tsy mitovy ny isa `i` voalohany misy `v - 1 ulp` sy `v`.
    // na izany aza dia mandà ny fampiasa tsy mitombina loatra.
    //
    // satria ny dingana manaraka dia manana detection overflow marina, fa ny criterion henjana kosa no ampiasainay:
    // manohy izahay mandra-pahatongan'ny `err` mihoatra ny `10^kappa / 2`, ka ny elanelana misy eo anelanelan'ny `v - 1 ulp` sy `v + 1 ulp` dia misy fisehoana roa na mihoatra boribory.
    //
    // io dia mitovy amin'ny fampitahana roa voalohany avy amin'ny `possibly_round`, ho an'ny referansa.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, izay `m = max_kappa + 1` (isa#amin'ny ampahany tsy miangatra):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // tsy hihoatra, `2^e * 10 < 2^64`
        err *= 10; // tsy hihoatra, `err * 10 < 2^e * 5 < 2^64`

        // zarao `remainder` amin'ny `10^kappa`.
        // samy esorina amin'ny `2^e / 10^kappa`, ka ity farany dia voatazona eto.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // feno ve ny buffer?mihazakazaka ny passering boribory miaraka amin'ny ambiny.
        if i == len {
            // SAFETY: efa nanomboka `len` byte maro izahay.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // avereno ireo invariants
        remainder = r;
    }

    // ny fikajiana fanampiny dia tsy misy ilana azy (`possibly_round` tena tsy mahomby), noho izany dia milavo lefona izahay.
    return None;

    // novokarinay ny laharana `v` rehetra nangatahina, izay tokony hitovy ihany koa amin'ireo tarehimarika `v - 1 ulp`.
    // ankehitriny izahay manamarina raha misy fisoloana tena miavaka zarain'ny `v - 1 ulp` sy `v + 1 ulp`;io dia mety hitovy amin'ny isa namboarina, na amin'ny kinova boribory amin'ireo tarehimarika ireo.
    //
    // raha toa ka misy fisehoan-javatra marobe mitovy halava ny elanelam-potoana, tsy azontsika antoka ary tokony hiverina `None` ho solony.
    //
    // ny adihevitra rehetra eto dia esorina amin'ny sanda `k` mahazatra (fa implicit), ka:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SAFETY: ny bytes `len` voalohany an'ny `buf` dia tsy maintsy atao voalohany.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (ho an'ny fanondroana, ny tsipika misy teboka dia manondro ny sandany marina amin'ny fisehoan-javatra amin'ny isa maromaro.)
        //
        //
        // lehibe loatra ny lesoka ka misy fisehoan-javatra telo farafaharatsiny eo anelanelan'ny `v - 1 ulp` sy `v + 1 ulp`.
        // tsy azontsika fantarina hoe iza no marina.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // raha ny marina, 1/2 ulp dia ampy hampidirana solontena roa mety hitranga.
        // (tadidio fa mila fisoloana tsy manam-paharoa isika ho an'ny `v - 1 ulp` sy ny «v + 1 ulp`.) tsy ho safo-drano izany, satria `ulp < ten_kappa` avy amin'ny fanamarinana voalohany.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // raha ny `v + 1 ulp` dia manakaiky kokoa ny fisehoana boribory (izay efa ao amin'ny `buf`), dia afaka miverina soa aman-tsara isika.
        // mariho fa `v - 1 ulp`*mety* ambany noho ny solontena ankehitriny, fa amin'ny `1 ulp < 10^kappa / 2` dia ampy io fepetra io:
        // ny elanelana misy eo `v - 1 ulp` sy ny solontena amin'izao fotoana izao dia tsy afaka mihoatra `10^kappa / 2`.
        //
        // ny fepetra dia mitovy amin'ny `remainder + ulp < 10^kappa / 2`.
        // satria mety hihoatra mora foana ity, zahao aloha raha `remainder < 10^kappa / 2`.
        // efa nohamarininay fa `ulp < 10^kappa / 2`, ka raha mbola tsy nihoatra ny `10^kappa` dia tsara ny fanamarinana faharoa.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SAFETY: ny mpiantso anay dia nanao izany fahatsiarovana izany.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------ambiny------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // Etsy ankilany, raha manakaiky kokoa ny fisoloan'ny boribory `v - 1 ulp` dia tokony boribory ary hiverina isika.
        // noho io antony io ihany dia tsy mila manamarina ny `v + 1 ulp` isika.
        //
        // ny fepetra dia mitovy amin'ny `remainder - ulp >= 10^kappa / 2`.
        // averinay indray aloha raha `remainder > ulp` (mariho fa tsy `remainder >= ulp` io, satria `10^kappa` dia tsy aotra mihitsy).
        //
        // mariho ihany koa fa `remainder - ulp <= 10^kappa`, ka ny fanamarinana faharoa dia tsy hihoatra.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SAFETY: ny mpiantso antsika dia tokony ho nanao an-tsaina izany fahatsiarovana izany.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // manampia tarehimarika fanampiny fotsiny rehefa nangatahinay ny mari-pahaizana raikitra.
                // mila manamarina ihany koa isika fa, raha foana ny buffer tany am-boalohany, dia azo ampiana ny isa fanampiny rehefa `exp == limit` (tranga edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SAFETY: izahay sy ny mpiantso anay dia nanao izany fahatsiarovana izany.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // raha tsy izany dia maty isika (ie, misy sanda eo anelanelan'ny `v - 1 ulp` sy `v + 1 ulp` mihodinkodina ary ny hafa mihodina) ary milavo lefona.
        //
        None
    }
}

/// Ny fampiharana ny fomba marina sy raikitra ho an'ny Grisu miaraka amin'ny fallback Dragon.
///
/// Tokony ampiasaina amin'ny ankamaroan'ny tranga izany.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SAFETY: Ny mpandinika indram-bola dia tsy ampy saina mba hamela antsika hampiasa `buf`
    // amin'ny branch faharoa, noho izany dia miala eto isika mandritra ny androm-piainana.
    // Fa tsy mampiasa afa-tsy `buf` izahay raha miverina `None` i X01 ka tsy maninona izany.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}