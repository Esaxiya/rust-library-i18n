//! Saika mivantana (fa nasiam-panatsarana kely) ny fandikan-dahatsoratra Rust an'ny sary 3 an'ny "Fanontana nomerao mitsingevana haingana sy marina" [^ 1].
//!
//!
//! [^1]: Burger, RG sy Dybvig, RK 1996. Manonta isa isa mitsingevana
//!   haingana sy marina.SIGPLAN tsia.31, 5 (Mey 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// arrays precalculated of `Digit`s for 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// azo ampiasaina ihany rehefa `x < 16 * scale`;`scaleN` dia tokony ho `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Ny fampiharana fomba fohy indrindra ho an'ny Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ny isa `v` hametrahana endrika dia fantatra fa:
    // - mitovy amin'ny `mant * 2^exp`;
    // - nialohavan'i `(mant - 2 *minus)* 2^exp` tamin'ny karazana tany am-boalohany;SY
    // - arahin'i `(mant + 2 *plus)* 2^exp` amin'ny karazana tany am-boalohany.
    //
    // mazava ho azy, `minus` sy `plus` dia tsy mety aotra.(ho an'ny infinities, mampiasa soatoavina ivelan'ny sakany izahay.) Ary mihevitra ihany koa izahay fa farafahakeliny isa iray no vokarina, izany hoe, `mant` dia tsy azo atao zero ihany koa.
    //
    // Midika koa izany fa ny isa rehetra eo anelanelan'ny `low = (mant - minus)*2^exp` sy `high = (mant + plus)* 2^exp` dia hametraka ity sarintany mitsingevana ity, miaraka amin'ny fetrany rehefa mitovy ny mantissa voalohany (ie, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` dia `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // tombano `k_0` avy amin'ny fampiasa tany am-boalohany manome fahafaham-po `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ny `k` tery tery izay mamatotra `10^(k-1) < high <= 10^k` dia isaina avy eo.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // ovay ny `{mant, plus, minus} * 2^exp` ho endri-tsoratra mba:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // zarao `mant` amin'ny `10^k`.ankehitriny `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // amboary rehefa `mant + plus > scale` (na `>=`).
    // tsy manova ny `scale` izahay, satria afaka mandingana ny fampitomboana voalohany.
    // ankehitriny `scale < mant + plus <= scale * 10` ary vonona hamokatra isa izahay.
    //
    // mariho fa `d[0]`*mety* aotra, rehefa `scale - plus < mant < scale`.
    // amin'ity tranga ity, ny toe-javatra mihodina (`up` etsy ambany) dia hipoitra avy hatrany.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // mitovy amin'ny scaling `scale` amin'ny 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // Cache `(2, 4, 8) * scale` ho an'ny taranaka tarehimarika.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, izay `d[0..n-1]` dia isa namboarina hatreto:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (araka izany `mant / scale < 10`) izay `d[i..j]` dia fohy ho an'ny `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // hiteraka tarehimarika iray: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ity dia famaritana tsotsotra ny algorithm Dragon novaina.
        // derivations antonony maro sy ny adihevitra feno dia nesorina mba tsy hanahirana.
        //
        // atombohy amin'ireo invariants novaina, satria nanavao ny `n` izahay:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // mihevitra fa `d[0..n-1]` no fohy indrindra eo amin'ny fanehoana `low` sy `high`, izany hoe, `d[0..n-1]` no mifanaraka tsara na ny manaraka, fa no tsy `d[0..n-2]`:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: isa manodidina ny `v`);SY
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (marina ny tarehimarika farany).
        //
        // ny fepetra faharoa dia manamora ny `2 * mant <= scale`.
        // ny famahana ireo invariants amin'ny `mant`, `low` ary `high` dia manome kinova tsotsotra kokoa amin'ny fepetra voalohany: `-plus < mant < minus`.
        // hatramin'ny `-plus < 0 <= mant` dia manana ny solontena fohy indrindra indrindra isika raha `mant < minus` sy `2 * mant <= scale`.
        // (lasa `mant <= minus` ilay teo aloha rehefa lasa mitovy ny mantissa voalohany.)
        //
        // rehefa tsy mitazona (`2 * mant> scale`) ny faharoa dia mila mampitombo ny isa farany isika.
        // ity dia ampy hamerenana amin'ny laoniny an'io toe-javatra io: efa fantatsika fa ny taranaka isa dia manome antoka ny `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // amin'ity tranga ity dia lasa `-plus < mant - scale < minus` ny fepetra voalohany.
        // satria `mant < scale` araka ny taranaka, dia manana `scale < mant + plus`.
        // (averiko indray, lasa `scale <= mant + plus` io rehefa mitovy ny mantissa voalohany.)
        //
        // raha afohezina:
        // - ajanony ary manodidina ny `down` (tazomy ny isa toy ny) rehefa `mant < minus` (na `<=`).
        // - ajanony ary manodidina ny `up` (ampitomboy ny isa farany) rehefa `scale < mant + plus` (na `<=`).
        // - mitoera foana raha tsy izany.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // manana ny solontena fohy indrindra izahay, mandroso amin'ny fihodinana

        // avereno ny invariants.
        // izany no mahatonga ny algorithm hamarana foana: `minus` sy `plus` mitombo foana, fa `mant` kosa dia voahidy modulo `scale` ary `scale` raikitra.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // Ny fihodinana dia mitranga rehefa i) ny fepetra fihodinana ihany no nateraka, na ii) ny toe-javatra roa dia nateraka ary ny famatahana fatotra dia aleony mihodina.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // raha manova ny halavany ny fihodinana dia tokony hiova koa ny mpanelanelana.
        // toa sarotra tokoa ny manome fahafaham-po (mety tsy ho vita) io toe-javatra io, saingy milamina sy tsy miovaova fotsiny isika eto.
        //
        // SAFETY: nataonay voalohany io fahatsiarovana io etsy ambony.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAFETY: nataonay voalohany io fahatsiarovana io etsy ambony.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Ny fampiharana ny fomba marina sy raikitra ho an'ny Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // tombano `k_0` avy amin'ny fampiasa tany am-boalohany manome fahafaham-po `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // zarao `mant` amin'ny `10^k`.ankehitriny `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // amboary rehefa `mant + plus >= scale`, izay `plus / scale = 10^-buf.len() / 2`.
    // mba hitazomana ny bignum habe raikitra dia tena `mant + floor(plus) >= scale` no ampiasainay.
    // tsy manova ny `scale` izahay, satria afaka mandingana ny fampitomboana voalohany.
    // indray miaraka amin'ny algorithm fohy indrindra, `d[0]` dia mety ho aotra fa hovarina amin'ny farany.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // mitovy amin'ny scaling `scale` amin'ny 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // Raha miasa miaraka amin'ny fetra farany isa isika dia mila manafoana ny buffer alohan'ny tena fandefasana mba hisorohana ny fihodinana roa.
    //
    // mariho fa mila manitatra ny buffer indray isika rehefa mitranga ny fihodinana!
    let mut len = if k < limit {
        // oops, tsy afaka mamokatra isa * iray akory izahay.
        // azo atao izany rehefa, hoy, fa manana zavatra toa ny 9.5 isika ary mihodina ho 10.
        // averinay ny buffer foana, ankoatry ny tranga boribory taty aoriana izay mitranga rehefa `k == limit` ary tsy maintsy mamokatra isa iray katroka.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // Cache `(2, 4, 8) * scale` ho an'ny taranaka tarehimarika.
        // (mety ho lafo io, koa aza fikajiana rehefa foana ny buffer.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ny isa manaraka dia zero daholo, mijanona eto izahay fa aza * manandrana manao boribory!fa fenoy ny isa sisa.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAFETY: nataonay voalohany io fahatsiarovana io etsy ambony.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // manodinkodina raha mijanona eo afovoan'ny tarehimarika isika raha toa ka 5000 ireto tarehin-tsoratra manaraka ireto ..., zahao ilay tarehimarika teo aloha ary andramo ny mihodina (izany hoe sorohy ny fihodinana rehefa mitovy ny isa teo aloha).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SAFETY: `buf[len-1]` dia voalahatra.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // raha manova ny halavany ny fihodinana dia tokony hiova koa ny mpanelanelana.
        // fa nangataka nomerao maromaro izahay, koa aza ovaina ny buffer ...
        // SAFETY: nataonay voalohany io fahatsiarovana io etsy ambony.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... raha tsy hoe angatahina aminao ny fametrahana mazava tsara fa tsy.
            // mila manamarina ihany koa isika fa, raha foana ny buffer tany am-boalohany, dia azo ampiana ny isa fanampiny rehefa `k == limit` (tranga edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAFETY: nataonay voalohany io fahatsiarovana io etsy ambony.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}