//! Constants manokana amin'ny karazana teboka mitsingevana tokana `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Isa isa manan-danja amin'ny matematika dia omena ao amin'ny maodelitra `consts`.
//!
//! Ho an'ireo Constants voafaritra mivantana ao amin'ity modely ity (tsy mitovy amin'ireo voafaritra ao amin'ny sub-module `consts`), ny kaody vaovao dia tokony hampiasa ireo Constants mifandraika voafaritra mivantana amin'ny `f32` karazana.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Ny radix na ny fototry ny solontenan'ny `f32`.
/// Mampiasà [`f32::RADIX`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // fomba natao
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Isan'ny isa manan-danja ao amin'ny base 2.
/// Mampiasà [`f32::MANTISSA_DIGITS`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // fomba natao
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Isa sahabo ho isa lehibe ao amin'ny base 10.
/// Mampiasà [`f32::DIGITS`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // fomba natao
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] sanda ho an'ny `f32`.
/// Mampiasà [`f32::EPSILON`] fa tsy.
///
/// Io no mahasamihafa ny `1.0` sy ny isa be solontena manaraka.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // fomba natao
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Sarobidy `f32` faran'izay kely indrindra.
/// Mampiasà [`f32::MIN`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // fomba natao
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Tombany `f32` ara-dalàna tsara indrindra kely indrindra.
/// Mampiasà [`f32::MIN_POSITIVE`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // fomba natao
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Sarany `f32` faran'izay lehibe indrindra.
/// Mampiasà [`f32::MAX`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // fomba natao
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Iray lehibe kokoa noho ny hery ara-dalàna farafahakeliny mety ho an'ny exponent 2.
/// Mampiasà [`f32::MIN_EXP`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // fomba natao
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Herin'ny hery faran'izay betsaka mety hitranga amin'ny exponent 2.
/// Mampiasà [`f32::MAX_EXP`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // fomba natao
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Herinaratra farany ambany farafahakeliny 10 exponent.
/// Mampiasà [`f32::MIN_10_EXP`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // fomba natao
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Hery farany ambony azo atao amin'ny 10 exponent.
/// Mampiasà [`f32::MAX_10_EXP`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // fomba natao
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Tsy isa (NaN).
/// Mampiasà [`f32::NAN`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // fomba natao
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Mampiasà [`f32::INFINITY`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // fomba natao
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Fahatarana tsy manam-petra (−∞).
/// Mampiasà [`f32::NEG_INFINITY`] fa tsy.
///
/// # Examples
///
/// ```rust
/// // fomba lany andro
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // fomba natao
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Constant matematika fototra.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: soloina hatrany ny matematika hatrany amin'ny cmath.

    /// X-(π) X maharitra an'ny Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Ny faribolana feno (τ) tsy tapaka
    ///
    /// Mitovy amin'ny 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Ny isa an'i Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Ny radix na ny fototry ny solontenan'ny `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Isan'ny isa manan-danja ao amin'ny base 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Isa sahabo ho isa lehibe ao amin'ny base 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] sanda ho an'ny `f32`.
    ///
    /// Io no mahasamihafa ny `1.0` sy ny isa be solontena manaraka.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Sarobidy `f32` faran'izay kely indrindra.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Tombany `f32` ara-dalàna tsara indrindra kely indrindra.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Sarany `f32` faran'izay lehibe indrindra.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Iray lehibe kokoa noho ny hery ara-dalàna farafahakeliny mety ho an'ny exponent 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Herin'ny hery faran'izay betsaka mety hitranga amin'ny exponent 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Herinaratra farany ambany farafahakeliny 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Hery farany ambony azo atao amin'ny 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Tsy isa (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Fahatarana tsy manam-petra (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Miverina `true` raha toa ka `NaN` ity sanda ity.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` dia tsy azon'ny besinimaro alefa noho ny fanahiany momba ny fivezivezena, ka io fampiharana io dia natao ho an'ny tsy miankina anatiny.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Miverina `true` raha tsy manam-petra positif na infinity ratsy io sanda io ary `false` raha tsy izany.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Miverina `true` raha toa ka tsy manam-petra na `NaN` io isa io.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Tsy ilaina ny mitantana ny NaN misaraka: raha ny tena dia NaN, ny fampitahana dia tsy marina, araka ny faniriana marina.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Miverina `true` raha [subnormal] ny isa.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Ny sanda eo anelanelan'ny `0` sy `min` dia Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Miverina `true` raha toa ka tsy zero, tsy manam-petra, [subnormal], na `NaN` ny isa.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Ny sanda eo anelanelan'ny `0` sy `min` dia Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Mamerina ny sokajy teboka mitsingevana an'ilay isa.
    /// Raha fananana iray ihany no hosedraina, haingana kokoa ny fampiasana ilay predicate manokana.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Miverina `true` raha toa ka misy fambara tsara ny `self`, ao anatin'izany ny `+0.0`, `NaN's with sign sign bit and positive infinity.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Miverina `true` raha `self` dia manana fambara ratsy, ao anatin'izany ny `-0.0`, `NaN's with sign sign bit and negative infinity.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // Hoy i IEEE754: Marina ny isSignMinus(x) raha ary raha x manana famantarana ratsy.
        // isSignMinus dia mihatra amin'ny zeros sy NaNs ihany koa.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Maka ny isa (inverse) mifamadika, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Mivadika radiana ho degre.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Mampiasà tsy tapaka ho an'ny marimarina kokoa.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Manova ny diplaoma ho radianina.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Mamerina ny ambony indrindra amin'ireo isa roa.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Raha ny iray amin'ireo tohan-kevitra dia NaN, dia averina ilay ady hevitra hafa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Mamerina ny farafaharatsiny amin'ireo isa roa.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Raha ny iray amin'ireo tohan-kevitra dia NaN, dia averina ilay ady hevitra hafa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Mihodina mankany aotra ary mihodina amin'ny karazana integer primitive, mihevitra fa ny soatoavina dia voafetra ary mifanaraka amin'io karazana io.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Ny sandany dia tsy maintsy:
    ///
    /// * Aza `NaN`
    /// * Aza manam-petra
    /// * Misehoa amin'ny endrika fiverenana `Int`, aorian'ny famongorana ny ampahany misy azy
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutation ho `u32`.
    ///
    /// Izy io dia mitovy amin'ny `transmute::<f32, u32>(self)` amin'ny sehatra rehetra.
    ///
    /// Jereo ny `from_bits` raha mila dinika kely momba ny fahaizan'ity hetsika ity (saika tsy misy olana).
    ///
    /// Mariho fa ity fiasa ity dia miavaka amin'ny casting `as`, izay manandrana mitazona ny isa * isa fa tsy ny sanda bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() tsy casting!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SAFETY: `u32` dia datatype taloha tsotra ka afaka mampita azy hatrany isika
        unsafe { mem::transmute(self) }
    }

    /// Famindrana manta avy amin'ny `u32`.
    ///
    /// Izy io dia mitovy amin'ny `transmute::<u32, f32>(v)` amin'ny sehatra rehetra.
    /// Hita fa azo entina mandehandeha ity, noho ny antony roa:
    ///
    /// * Floats sy Ints dia manana fiafarana mitovy amin'ny sehatra rehetra tohana.
    /// * Ny IEEE-754 dia mamaritra tsara ny fametrahana ny float.
    ///
    /// Na izany aza misy fampandrenesana iray: talohan'ny kinovan'ny IEEE-754 tamin'ny 2008, ny fomba fandikana ny bitika famantarana ny NaN dia tsy voalaza mazava.
    /// Ny ankamaroan'ny sehatra (indrindra ny x86 sy ny ARM) dia nisafidy ny fandikana izay namboarina tamin'ny taona 2008, fa ny sasany kosa tsy (indrindra ny MIPS).
    /// Vokatr'izany, ny NaN rehetra misy marika amin'ny MIPS dia NaNs mangina amin'ny x86, ary ny mifamadika amin'izany.
    ///
    /// Raha tokony hiezaka hitahiry ny cross-plateforme signaling-ness, ity fampiharana ity dia mankafy ny fitehirizana ireo sombin-javatra marina.
    /// Midika izany fa ny karama rehetra voahodidin'ny NaNs dia hotehirizina na dia alefa amin'ny alàlan'ny tamba-jotra aza ny valiny avy amin'ny masinina x86 ka hatramin'ny MIPS iray.
    ///
    ///
    /// Raha toa ka ny maritrano ihany no namolavola azy ireo ny vokatr'io fomba io dia tsy misy ahiahy amin'ny fitaterana.
    ///
    /// Raha tsy NaN ny fampidirana dia tsy misy ahiahy amin'ny fitaterana.
    ///
    /// Raha tsy miraharaha ny signalingness ianao (tena azo inoana), dia tsy misy ahiahy portability.
    ///
    /// Mariho fa ity fiasa ity dia miavaka amin'ny casting `as`, izay manandrana mitazona ny isa * isa fa tsy ny sanda bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SAFETY: `u32` dia datatype taloha tsotra ka hahafahantsika mandefa azy hatrany
        // Hay tafahoatra ny olana momba ny fiarovana amin'ny sNaN!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Avereno ny solontenan'ny fahatsiarovana an'ity isa mitsingevana ity ho toy ny laharana byte amin'ny baiko (network) byte big-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Avereno ny fisoloan'ny fahatsiarovana an'ity isa mitsingevana ity toy ny laharana byte amin'ny filaharana byte kely-endiana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Miverena ny fahatsiarovana fanehoana izany mitsingevana maro ho toy ny teboka byte voaomana amin'ny teratany mba byte.
    ///
    /// Rehefa ampiasaina ny endianness zanatany kendrena dia tokony hampiasa [`to_be_bytes`] na [`to_le_bytes`] ny kaody portable, raha tokony ho izy.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Miverena ny fahatsiarovana fanehoana izany mitsingevana maro ho toy ny teboka byte voaomana amin'ny teratany mba byte.
    ///
    ///
    /// [`to_ne_bytes`] tokony aleonao mihoatra an'io isaky ny azo atao.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SAFETY: `f32` dia datatype taloha tsotra ka afaka mampita azy hatrany isika
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Mamorona sanda teboka mitsingevana avy amin'ny fisoloany tena amin'ny byte array in big endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Mamorona sanda teboka mitsingevana avy amin'ny fisoloany tena amin'ny byte array amin'ny endiana kely.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Mamorona sanda teboka mitsingevana avy amin'ny fisoloany tena amin'ny byte array amin'ny teratany endiana.
    ///
    /// Rehefa ampiasaina ny fiafaran-tany zanatany kendrena, dia mety te hampiasa [`from_be_bytes`] na [`from_le_bytes`] ny kaody portable, raha tokony ho izy.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Miverina famandrihana eo anelanelan'ny tena sy ny soatoavina hafa.
    /// Tsy toy ny fampitahana fizarana mahazatra eo amin'ny isa isa mitsingevana, io fampitahana io dia mamoaka famandrihana hatrany mifanaraka amin'ny totalin'ny Mpanapaka izay voafaritra ao amin'ny fenitry ny teboka mitsitsy IEEE 754 (2008 fanitsiana).
    /// Ny soatoavina dia alahatra manaraka izao:
    /// - Mangina ratsy NaN
    /// - Fambara ratsy Negra NaN
    /// - Tsy manam-petra tsy mahasoa
    /// - Isa ratsy
    /// - Laharana ratsy tsy mahazatra
    /// - Aotra ratsy
    /// - Aotra tsara
    /// - Isa isa tsy mahazatra
    /// - Isa tsara
    /// - Tsy manam-petra tsara
    /// - Famaritana tsara NaN
    /// - Milamina tsara NaN
    ///
    /// Mariho fa io asa io dia tsy mifanaraka matetika amin'ny fampiharana [`PartialOrd`] sy [`PartialEq`] an'ny `f32`.Manokana, heverin'izy ireo ho mitovy ny aotra ratsy sy miabo fa ny `total_cmp` kosa tsy.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Raha sendra misy ny tsy fetezana dia aforeto ny sombintsombiny rehetra afa-tsy ny famantarana mba hahatratrarana lamina mitovy amin'ny isa ampitomboina roa
        //
        // Fa maninona no mandeha ity?IEEE 754 mitsingevana dia misy saha telo:
        // Sign bit, exponent ary mantissa.Ny setan'ny saha exponent sy mantissa amin'ny ankapobeny dia manana ny fananana ny filaharany bitwise dia mitovy amin'ny halehiben'ny isa izay faritana ny halehibeny.
        // Ny habeny dia tsy voafaritra matetika amin'ny sanda NaN, fa ny IEEE 754 totalOrder dia mamaritra ny soatoavina NaN koa hanaraka ny filaharana bitwise.Izany dia mitarika amin'ny filaminana hazavaina ao amin'ny fanehoan-kevitra momba ny dokotera.
        // Na izany aza, ny fanehoana ny habeny dia mitovy amin'ny isa ratsy sy miabo-ny takelaka famantarana ihany no tsy mitovy.
        // Mba hampitahàna mora ny floats ho toy ny integer nosoniavina dia mila atsimbadika ny bitika exponent sy mantissa raha toa ka misy isa ratsy.
        // Manova ny isa ho endrika "two's complement" izahay.
        //
        // Mba hanaovana flipping dia manamboatra sarontava sy XOR hanohitra azy izahay.
        // Branchlessly isika hanisa ny "all-ones except for the sign bit" saron-tava amin'ny ratsy-nanao sonia soatoavina: mifindrafindra tsara famantarana-nanitatra ny integer, Ka dia "fill" ny saron-tava amin'ny famantarana potika, ary avy eo niova ho unsigned ny manosika aotra kely iray hafa.
        //
        // Amin'ny sanda tsara, ny sarontava dia zerô avokoa, noho izany dia tsy misy safidy izany.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Ferana ny elanelam-potoana raha tsy NaN izany.
    ///
    /// Miverina `max` raha `self` lehibe kokoa noho `max`, ary `min` raha `self` ambany noho `min`.
    /// Raha tsy izany dia miverina `self`.
    ///
    /// Mariho fa ity asa ity dia mamerina ny NaN raha toa ka NaN ihany koa ny sanda voalohany.
    ///
    /// # Panics
    ///
    /// Panics raha `min > max`, `min` dia NaN, na `max` dia NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}