//! Constants ho an'ny karazana integer tsy misy sonia 8-bit.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Ny kaody vaovao dia tokony hampiasa ireo Constants mifandraika mivantana amin'ny karazana primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }