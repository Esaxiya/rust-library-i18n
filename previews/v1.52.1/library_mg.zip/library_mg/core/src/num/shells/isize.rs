//! Constants ho an'ny karazana integer vita sonia.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Ny kaody vaovao dia tokony hampiasa ireo Constants mifandraika mivantana amin'ny karazana primitive.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }