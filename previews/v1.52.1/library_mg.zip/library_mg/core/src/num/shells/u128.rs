//! Constants ho an'ny karazana integer tsy misy sonia 128-bit.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Ny kaody vaovao dia tokony hampiasa ireo Constants mifandraika mivantana amin'ny karazana primitive.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }