macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Ny sanda kely indrindra azo soloina an'io karazana isa io.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Ny sanda lehibe indrindra azo zakan'ity karazana integer ity.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Ny haben'ity karazana integer ity amin'ny sombintsombiny.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Mivadika sombin-tadiny ao anaty fotony omena ho an'ny isa iray.
        ///
        /// Ny kofehy dia antenaina ho marika `+` tsy maintsy arahana isa.
        ///
        /// Ny fotsy sy mitarika fotsy dia maneho hadisoana.
        /// Ny Digits dia ampahan'ireto tarehin-tsoratra ireto, miankina amin'ny `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ity fiasan'ny panics ity raha `radix` dia tsy eo anelanelan'ny 2 ka hatramin'ny 36.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Miverina ny isan'ny olona amin'ny fisoloan-tena binary an'ny `self`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Mamerina ny isan'ny zerô amin'ny fisoloan-tena binary an'ny `self`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Mamerina ny isan'ny zero mitarika amin'ny solontena binary an'ny `self`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Mamerina ny isan'ny zoro mivoaka amin'ny fisolo tena ny `self`.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Mamerina ny isan'ny mpitarika ao amin'ny solontena roa an'ny `self`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Mamerina ny isan'ny mpandeha amin'ny solontena roa an'ny `self`.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Avereno amin'ny sisiny haavo ny sombin-kazo amin'ny alàlan'ny isa voafaritra, `n`, famonosana ireo bitsika notapahina hatramin'ny faran'ny integer vokariny.
        ///
        ///
        /// Azafady mba mariho fa tsy mitovy amin'ny opération `<<` shifting ity!
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Avadiho ho eo ankavanana ny sombin-kazo amin'ny alàlan'ny isa voafaritra, `n`, famonosana ireo bitsika notapahina tamin'ny fiandohan'ny integer vokariny.
        ///
        ///
        /// Azafady mba mariho fa tsy mitovy amin'ny opération `>>` shifting ity!
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Mivadika ny filaharana byte an'ny integer.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// avelao m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Mivadika ny filaharan'ny sombintsombiny amin'ny isa.
        /// Ny bitika kely manan-danja indrindra dia lasa bitika manan-danja indrindra, ny faharoa bitika manan-danja indrindra dia lasa bitika faharoa lehibe indrindra, sns.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// avelao m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Manova ny integer manomboka amin'ny endiana lehibe ka hatramin'ny farany ny kendreny.
        ///
        /// Amin'ny endiana lehibe ity dia tsy misy safidy.
        /// Amin'ny endiana kely dia soloina ny bytes.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// raha cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } hafa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Mivadika integer avy amin'ny endiana kely ka hatramin'ny farany ny kendreny.
        ///
        /// Amin'ny endiana kely dia tsy misy safidy io.
        /// Amin'ny endiana lehibe dia avadika ny bytes.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// raha cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } hafa {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Manova `self` ho endiana lehibe avy amin'ny endyanness an'ny kendrena.
        ///
        /// Amin'ny endiana lehibe ity dia tsy misy safidy.
        /// Amin'ny endiana kely dia soloina ny bytes.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// raha cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } hafa { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // sa tsy ho?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Mivadika `self` ka hatramin'ny endiana kely avy amin'ny endyan'ny kendrena.
        ///
        /// Amin'ny endiana kely dia tsy misy safidy io.
        /// Amin'ny endiana lehibe dia avadika ny bytes.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// raha cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } hafa { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Fanampin'ny integer voamarina.
        /// Manisa `self + rhs`, mamerina `None` raha misy ny fihenan-tsasatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Fanampin'ny integer tsy voamarina.Mamaky `self + rhs`, mihevitra fa tsy mety hitranga ny fihoarana.
        /// Izany dia miteraka fihetsika tsy voafaritra rehefa
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Fanesorana integer voamarina.
        /// Manisa `self - rhs`, mamerina `None` raha misy ny fihenan-tsasatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Fanesorana ny integer tsy voamarina.Mamaky `self - rhs`, mihevitra fa tsy mety hitranga ny fihoarana.
        /// Izany dia miteraka fihetsika tsy voafaritra rehefa
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Fanamafisana integer voamarina.
        /// Manisa `self * rhs`, mamerina `None` raha misy ny fihenan-tsasatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Fampitomboana isa tsy voamarina.Mamaky `self * rhs`, mihevitra fa tsy mety hitranga ny fihoarana.
        /// Izany dia miteraka fihetsika tsy voafaritra rehefa
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Fizarana integer voamarina.
        /// Manisa `self / rhs`, mamerina `None` raha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div amin'ny aotra dia voamarina etsy ambony ary ny karazany tsy misy sonia dia tsy misy hafa
                // fomba tsy fahombiazan'ny fizarana
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Fizarana Euclidean nanamarina.
        /// Manisa `self.div_euclid(rhs)`, mamerina `None` raha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Voamarina ny ambiny isa.
        /// Manisa `self % rhs`, mamerina `None` raha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAFETY: div amin'ny aotra dia voamarina etsy ambony ary ny karazany tsy misy sonia dia tsy misy hafa
                // fomba tsy fahombiazan'ny fizarana
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Nanamarina modely Euclidean.
        /// Manisa `self.rem_euclid(rhs)`, mamerina `None` raha `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Nolavina voamarina.Mamaky `-self`, mamerina `None` raha tsy hoe `self==
        /// 0`.
        ///
        /// Mariho fa ny fanafoanana ny integer positif dia hitobaka.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Fiovana zahana ankavia.
        /// Manisa `self << rhs`, mamerina `None` raha `rhs` dia lehibe kokoa na mitovy amin'ny isan'ny bits amin'ny `self`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Checked fiovàna tsara.
        /// Manisa `self >> rhs`, mamerina `None` raha `rhs` dia lehibe kokoa na mitovy amin'ny isan'ny bits amin'ny `self`.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Fanamarihana exponentiation.
        /// Manisa `self.pow(exp)`, mamerina `None` raha misy ny fihenan-tsasatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // satria exp!=0, farany tokony ho 1 ny exp.
            // Ataovy misaraka ny sombin-dahatsoratra farany, satria tsy ilaina ny famolahana ny fotony ary mety hiteraka fihoarana tsy ilaina intsony.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Fanampiny integer saturating.
        /// Manisa `self + rhs`, mahavoky ny fari-tarehimarika fa tsy be loatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Fanesorana integer mahavoky.
        /// Manisa `self - rhs`, mahavoky ny fari-tarehimarika fa tsy be loatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Fampitomboana integer saturating.
        /// Manisa `self * rhs`, mahavoky ny fari-tarehimarika fa tsy be loatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Fampiroboroboana ny integer saturating.
        /// Manisa `self.pow(exp)`, mahavoky ny fari-tarehimarika fa tsy be loatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Famonosana fanampiny (modular).
        /// Mamaky `self + rhs`, mifono manodidina ny faritry ny karazany.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Famonosana ny famoahana (modular).
        /// Mamaky `self - rhs`, mifono manodidina ny faritry ny karazany.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Fonosana multiplier (modular).
        /// Mamaky `self * rhs`, mifono manodidina ny faritry ny karazany.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// Azafady mba mariho fa ity ohatra ity dia zaraina amin'ireo karazana integer.
        /// Izay manazava ny antony ampiasana `u8` eto.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Famonoana fizarana (modular).Mamaky `self / rhs`.
        /// Ny fizarana mifangaro amin'ny karazana tsy sonia dia fizarana ara-dalàna fotsiny.
        /// Tsy misy mihitsy ny fomba famonosana.
        /// Misy io fiasa io, ka ny asa rehetra dia voatanisa ao amin'ny hetsika famonosana.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Fonosana fizarana Euclidean.Mamaky `self.div_euclid(rhs)`.
        /// Ny fizarana mifangaro amin'ny karazana tsy sonia dia fizarana ara-dalàna fotsiny.
        /// Tsy misy mihitsy ny fomba famonosana.
        /// Misy io fiasa io, ka ny asa rehetra dia voatanisa ao amin'ny hetsika famonosana.
        /// Satria, ho an'ny integers tsara, ny famaritana mahazatra rehetra ny fizarana dia mitovy, dia mitovy tanteraka amin'ny `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Fonosana sisa tavela (modular).Mamaky `self % rhs`.
        /// Ny kajy sisa tavela amin'ny karazana tsy nasiana sonia dia ny kajy sisa tavela ihany.
        ///
        /// Tsy misy mihitsy ny fomba famonosana.
        /// Misy io fiasa io, ka ny asa rehetra dia voatanisa ao amin'ny hetsika famonosana.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Famonosana modely Euclidean.Mamaky `self.rem_euclid(rhs)`.
        /// Ny fikajiana modulo mifono amin'ny karazana tsy nasiana sonia dia ny kajy sisa tsy tapaka.
        /// Tsy misy mihitsy ny fomba famonosana.
        /// Misy io fiasa io, ka ny asa rehetra dia voatanisa ao amin'ny hetsika famonosana.
        /// Satria, ho an'ny integers tsara, ny famaritana mahazatra rehetra ny fizarana dia mitovy, dia mitovy tanteraka amin'ny `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Famonosana ny famafana (modular).
        /// Mamaky `-self`, mifono manodidina ny faritry ny karazany.
        ///
        /// Koa satria ny karazana tsy sonia dia tsy manana mitovy fitoviana ratsy dia hosakanana ny rindranasa rehetra amin'ity fampiasa ity (afa-tsy ny `-0`).
        /// Ho an'ny sanda kely kokoa noho ny ambony indrindra karazana voasonia dia mitovy ny famoahana ny soatoavina nosoniavina mifanaraka amin'izany.
        ///
        /// Ny sanda lehibe kokoa dia mitovy amin'ny `MAX + 1 - (val - MAX - 1)` izay `MAX` no ambony indrindra karazana voasonia.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// Azafady mba mariho fa ity ohatra ity dia zaraina amin'ireo karazana integer.
        /// Izay manazava ny antony ampiasana `i8` eto.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic tsy misy miovaova miankavia;
        /// mamoaka `self << mask(rhs)`, izay `mask` manala izay bitika avo lenta `rhs` izay mety hihoatra ny bitwidth an'ny karazana.
        ///
        /// Mariho fa ity dia *tsy* mitovy amin'ny fihodinan'ny havia;ny RHS amin'ny famonosana havia havia dia voafetra amin'ny isan-karazany amin'ny karazany fa tsy ny sombin-javatra nafindra avy amin'ny LHS izay naverina tamin'ny faran'ny hafa.
        /// Ny karazana integer primitive dia mampihatra asan'ny [`rotate_left`](Self::rotate_left) avokoa, izay mety izay tadiavinao.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAFETY: ny masking amin'ny bitsize an'ny karazany dia manome antoka fa tsy miova isika
            // ivelan'ny fetra
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-malalaka miovaova-miankavanana;
        /// mamoaka `self >> mask(rhs)`, izay `mask` manala izay bitika avo lenta `rhs` izay mety hihoatra ny bitwidth an'ny karazana.
        ///
        /// Mariho fa ity dia *tsy* mitovy amin'ny rotate-droite;ny RHS amin'ny famonosana-havanana famerana dia voafetra amin'ny isan-karazany amin'ny karazany, fa tsy ny sombin-javatra nafindra avy amin'ny LHS naverina tamin'ny farany.
        /// Ny karazana integer primitive dia mampihatra asan'ny [`rotate_right`](Self::rotate_right) avokoa, izay mety izay tadiavinao.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAFETY: ny masking amin'ny bitsize an'ny karazany dia manome antoka fa tsy miova isika
            // ivelan'ny fetra
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Fonosana exponentiation (modular).
        /// Mamaky `self.pow(exp)`, mifono manodidina ny faritry ny karazany.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // satria exp!=0, farany tokony ho 1 ny exp.
            // Ataovy misaraka ny sombin-dahatsoratra farany, satria tsy ilaina ny famolahana ny fotony ary mety hiteraka fihoarana tsy ilaina intsony.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Manisa `self` + `rhs`
        ///
        /// Miverina ny tuple an'ny fanampiana miaraka amin'ny boolean izay manondro raha hipoitra ny arithmetika.
        /// Raha nisy ny safo-drano dia niverina ny sanda fonosina.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Manisa `self`, `rhs`
        ///
        /// Miverina ny tuple an'ny fanesorana miaraka amin'ny boolean izay manondro raha hipoitra ny arithmetika.
        /// Raha nisy ny safo-drano dia niverina ny sanda fonosina.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Manisa ny fampitomboana ny `self` sy `rhs`.
        ///
        /// Mamerina ny tuple ny fampitomboana miaraka amin'ny boolean izay manondro raha hipoitra ny arithmetika.
        /// Raha nisy ny safo-drano dia niverina ny sanda fonosina.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// Azafady mba mariho fa ity ohatra ity dia zaraina amin'ireo karazana integer.
        /// Izay manazava ny antony ampiasana `u32` eto.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Kajy ny mpizara raha mizara `rhs` ny `self`.
        ///
        /// Miverina ny tuple an'ny mpizara miaraka amin'ny boolean izay manondro raha hipoitra ny arithmetika.
        /// Mariho fa ho an'ny overegeg tsy misy sonia dia tsy miseho mihitsy, ka `false` foana ny sandany faharoa.
        ///
        /// # Panics
        ///
        /// Ity fiasa ity dia panic raha `rhs` dia 0.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Kajy ny fitrandrahana ny fizarana Euclidean `self.div_euclid(rhs)`.
        ///
        /// Miverina ny tuple an'ny mpizara miaraka amin'ny boolean izay manondro raha hipoitra ny arithmetika.
        /// Mariho fa ho an'ny overegeg tsy misy sonia dia tsy miseho mihitsy, ka `false` foana ny sandany faharoa.
        /// Satria, ho an'ny integers tsara, ny famaritana mahazatra rehetra ny fizarana dia mitovy, dia mitovy tanteraka amin'ny `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ity fiasa ity dia panic raha `rhs` dia 0.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Kajy ny ambiny rehefa mizara `rhs` ny `self`.
        ///
        /// Miverina ny ambin'ny ambiny aorian'ny fizarana azy miaraka amin'ny boolean izay manondro raha hipoitra ny arithmetika.
        /// Mariho fa ho an'ny overegeg tsy misy sonia dia tsy miseho mihitsy, ka `false` foana ny sandany faharoa.
        ///
        /// # Panics
        ///
        /// Ity fiasa ity dia panic raha `rhs` dia 0.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Kajy ny sisa `self.rem_euclid(rhs)` toy ny hoe ny Euclidean fisarahana.
        ///
        /// Miverina ny tuple an'ny modulo aorian'ny fizarana azy miaraka amin'ny boolean izay manondro raha hipoitra ny arithmetika.
        /// Mariho fa ho an'ny overegeg tsy misy sonia dia tsy miseho mihitsy, ka `false` foana ny sandany faharoa.
        /// Satria, ho an'ny integers tsara, ny famaritana mahazatra rehetra ny fizarana dia mitovy, ity asa ity dia mitovy tanteraka amin'ny `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ity fiasa ity dia panic raha `rhs` dia 0.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Mandà tena amin'ny fomba mihoapampana.
        ///
        /// Miverina `!self + 1` amin'ny fampiasana ny fonosana fonosana hamerenana ny sanda izay maneho ny fandavana an'io sanda tsy voasonia io.
        /// Mariho fa ny soatoavina tsara tsy voasonia dia misy foana ny fihoaram-pefy, fa ny fandavana 0 dia tsy hihoatra.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Miova tena navelan'ny `rhs` bit.
        ///
        /// Miverina ny tuple an'ny fiovan'ny tena miova miaraka amin'ny boolean izay manondro raha lehibe kokoa noho ny na mitovy amin'ny isan'ny bits ny fiovana.
        /// Raha lehibe loatra ny sandan'ny fiovana, dia saron-tava (N-1) izay ny N no isan'ny bits, ary io sanda io no ampiasaina hanatanterahana ilay fiovana.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Miova mahitsy amin'ny alàlan'ny bitika `rhs`.
        ///
        /// Miverina ny tuple an'ny fiovan'ny tena miova miaraka amin'ny boolean izay manondro raha lehibe kokoa noho ny na mitovy amin'ny isan'ny bits ny fiovana.
        /// Raha lehibe loatra ny sandan'ny fiovana, dia saron-tava (N-1) izay ny N no isan'ny bits, ary io sanda io no ampiasaina hanatanterahana ilay fiovana.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Manandratra ny tenany amin'ny herin'ny `exp`, amin'ny fampiasana exponentiation amin'ny alàlan'ny squaring.
        ///
        /// Miverina ny tuple ny exponentiation miaraka amin'ny bool izay manondro raha nisy overflow nitranga.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, marina));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Toerana fikosoham-bary hitahiry ny valin'ny fandosinana_mul be loatra.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // satria exp!=0, farany tokony ho 1 ny exp.
            // Ataovy misaraka ny sombin-dahatsoratra farany, satria tsy ilaina ny famolahana ny fotony ary mety hiteraka fihoarana tsy ilaina intsony.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Manandratra ny tenany amin'ny herin'ny `exp`, amin'ny fampiasana exponentiation amin'ny alàlan'ny squaring.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // satria exp!=0, farany tokony ho 1 ny exp.
            // Ataovy misaraka ny sombin-dahatsoratra farany, satria tsy ilaina ny famolahana ny fotony ary mety hiteraka fihoarana tsy ilaina intsony.
            //
            //
            acc * base
        }

        /// Manao fizarana Euclidean.
        ///
        /// Satria, ho an'ny integers tsara, ny famaritana mahazatra rehetra ny fizarana dia mitovy, dia mitovy tanteraka amin'ny `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ity fiasa ity dia panic raha `rhs` dia 0.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Manisa ny sisa kely indrindra amin'ny `self (mod rhs)`.
        ///
        /// Satria, ho an'ny integers tsara, ny famaritana mahazatra rehetra ny fizarana dia mitovy, dia mitovy tanteraka amin'ny `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ity fiasa ity dia panic raha `rhs` dia 0.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Miverina `true` raha ary raha `self == 2^k` fotsiny ho an'ny `k` sasany.
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Miverina iray latsaky ny herin'ny roa manaraka.
        // (Ho an'ny 8u8 herin'ny manaraka dia 8u8 ary ho an'ny 6u8 dia 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Ity fomba ity dia tsy afa-manoatra, toy ny tranga `next_power_of_two` overflow kosa dia mamerina ny sanda farany ambony indrindra amin'ny karazany, ary afaka miverina 0 ho 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SAFETY: Satria `p > 0` dia tsy voatery ahitana zerô mitarika manontolo izy io.
            // Midika izany fa ao anaty fetra foana ny fiovana, ary ny mpikirakira sasany (toy ny intel pre-haswell) dia manana intrinsika ctlz mahomby kokoa rehefa tsy aotra ny fifamaliana.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Miverina ny hery kely indrindra amin'ny roa lehibe kokoa na mitovy amin'ny `self`.
        ///
        /// Rehefa mitobaka ny sandan'ny fiverenana (ie, `self > (1 << (N-1))` ho an'ny karazana `uN`), dia panics amin'ny fomba debug ary miverina ny lanjany miverina amin'ny 0 amin'ny fomba famotsorana (ny toe-javatra tokana ahafahan'ny fomba miverina 0).
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Miverina ny hery kely indrindra amin'ny roa lehibe kokoa na mitovy amin'ny `n`.
        /// Raha ny herin'ny roa manaraka dia lehibe kokoa noho ny sanda ambony indrindra an'ny karazany, dia miverina ny `None`, raha tsy izany dia mifono `Some` ny herin'ny roa.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Miverina ny hery kely indrindra amin'ny roa lehibe kokoa na mitovy amin'ny `n`.
        /// Raha ny hery manaraka an'ny roa dia lehibe kokoa noho ny sanda ambony indrindra an'ny karazany, dia averina amin'ny `0` ny sandan'ny fiverenana.
        ///
        ///
        /// # Examples
        ///
        /// Fampiasana fototra:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Avereno ny solontenan'ny fahatsiarovan'ity isa ity ho toy ny laharana byte amin'ny baiko big-endian (network) byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Avereno ny solontenan'ny fahatsiarovan'ity isa ity ho toy ny laharana byte amin'ny filaharana byte kely-endiana.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Avereno ny solontenan'ny fahatsiarovana an'ity isa ity ho toy ny laharana byte amin'ny filaharana byte teratany.
        ///
        /// Rehefa ampiasaina ny endianness zanatany kendrena dia tokony hampiasa [`to_be_bytes`] na [`to_le_bytes`] ny kaody portable, raha tokony ho izy.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, raha cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } hafa {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: feony satria ny integer dia datatypes taloha tsotra ka afaka foana isika
        // ampitao izy ireo amin'ny tsanganana bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAFETY: ny integer dia datatypes taloha tsotra mba hahafahantsika mampita azy ireo hatrany
            // filaharana bytes
            unsafe { mem::transmute(self) }
        }

        /// Avereno ny solontenan'ny fahatsiarovana an'ity isa ity ho toy ny laharana byte amin'ny filaharana byte teratany.
        ///
        ///
        /// [`to_ne_bytes`] tokony aleonao mihoatra an'io isaky ny azo atao.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// avelao ny bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, raha cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } hafa {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SAFETY: ny integer dia datatypes taloha tsotra mba hahafahantsika mampita azy ireo hatrany
            // filaharana bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Mamorona sanda integer teratany teratany avy amin'ny solontenany ho toy ny byte array in big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// mampiasa std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * fampidirana=fitsaharana;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Mamorona sanda integer teratany teratany avy amin'ny solontenany ho toy ny byte array amin'ny endiana kely.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// mampiasa std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * fampidirana=fitsaharana;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Mamorona sanda integer teratany teratany avy amin'ny solontenan'ny fahatsiarovana ho toy ny laharana byte amin'ny fiafarana tompon-tany.
        ///
        /// Rehefa ampiasaina ny fiafaran-tany zanatany kendrena, dia mety te hampiasa [`from_be_bytes`] na [`from_le_bytes`] ny kaody portable, raha tokony ho izy.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } hafa {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// mampiasa std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * fampidirana=fitsaharana;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAFETY: feony satria ny integer dia datatypes taloha tsotra ka afaka foana isika
        // mampita azy ireo
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAFETY: ny integer dia datatypes taloha mba hahafahantsika mampita azy ireo hatrany
            unsafe { mem::transmute(bytes) }
        }

        /// Kaody vaovao no tokony aleony ampiasaina
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Mamerina ny sanda kely indrindra azo soloina an'ity karazana integer ity.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Kaody vaovao no tokony aleony ampiasaina
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Mamerina ny sanda lehibe indrindra azo soloina an'ity karazana integer ity.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}