//! Fanodinkodinana kofehy.
//!
//! Raha mila tsipiriany misimisy kokoa, jereo ny maody [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ivelan'ny fetra
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. manomboka <=farany
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. fetra toetra
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // tadiavo ny toetra
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` dia tsy maintsy ho kely noho ny Len sy ny sisin-tany Char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Miverina ny halavan'ny `self`.
    ///
    /// Ity halavany ity dia amin'ny bytes fa tsy [`char`] na graphemes.
    /// Raha atao teny hafa, dia mety tsy ilay fiheveran'ny olombelona ny halavan'ny kofehy.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // manja f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Miverina `true` `self` raha manana halavan'ny oktety aotra.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Manamarina fa ny `index`-th byte no byte voalohany amin'ny filaharana teboka code UTF-8 na ny faran'ny string.
    ///
    ///
    /// Ny fiandohana sy ny faran'ny tadiny (rehefa `index== self.len()`) dia heverina ho fetra.
    ///
    /// Miverina `false` raha `index` dia lehibe noho `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // fanombohan'ny `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // byte faharoa an'ny `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // byte fahatelo an'ny `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ary len dia mety foana.
        // Fitsapana ny 0 mazava tsara mba hahafahany manatsara tsara ny fanamarinana ary mandingana ny angon-drakitra famakiana an'io tranga io.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Ity dia majika kely mitovy amin'ny: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Mivadika sombin-tadiny amin'ny sombin-byte.
    /// Raha te hanova ny sombin-byte hiverina ho tapa-tady dia ampiasao ny asan'ny [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAFETY: feony const satria mandefa karazany roa miaraka amina endrika mitovy isika
        unsafe { mem::transmute(self) }
    }

    /// Mampivadika sombin-tadiny azo ovaina ho voadidy byte azo ovaina.
    ///
    /// # Safety
    ///
    /// Ny mpiantso dia tsy maintsy azo antoka fa ny votoatin'ny ny silaka dia manan-kery eo anatrehan'ny Borrow UTF-8 faran'ny sy ny fototra `str` no ampiasaina.
    ///
    ///
    /// Ampiasao ny `str` izay tsy manan-kery Hevitra ato Anatiny ireo dia tsy voafaritra UTF-8 fitondran-tena.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: ny cast avy amin'ny `&str` ka hatramin'ny `&[u8]` dia azo antoka hatramin'ny `str`
        // manana ny fisehon'ny ihany araka ny `&[u8]` (libstd ihany no afaka manao izany antoka).
        // Ny dereferansa pointer dia azo antoka satria izy io dia avy amin'ny referable miovaova izay azo antoka fa manan-kery amin'ny fanoratana.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Mivadika sombin-tadiny ho any amin'ny mpanondro manta.
    ///
    /// Tahaka ny kofehy slices dia silaka oktety, manondro ny manta manondro ny [`u8`].
    /// Ity tondro ity dia hanondro ny byte voalohany amin'ny tapa-kofehy.
    ///
    /// Ny miantso dia tsy maintsy miantoka fa ny mpanondro naverina dia tsy nanoratra tamin'io mihitsy.
    /// Raha mila manova ny atin'ny sombin-tadiny ianao dia ampiasao [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Mampivadika sombin-tsipika azo ovaina amin'ny mpanondro manta.
    ///
    /// Tahaka ny kofehy slices dia silaka oktety, manondro ny manta manondro ny [`u8`].
    /// Ity tondro ity dia hanondro ny byte voalohany amin'ny tapa-kofehy.
    ///
    /// Anjaranao ny maka antoka fa ny sombin-tadiny dia tsy miova amin'ny fomba izay mijanona ho UTF-8 fotsiny.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Miverina subslice `str`.
    ///
    /// Ity no safidy hafa tsy hikorontana amin'ny fanondroana ny `str`.
    /// Miverina [`None`] isaky ny miasa ny indexing mitovy panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // index tsy amin'ny fetra filaharana UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ivelan'ny fetra
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Miverina subslice miovaova `str`.
    ///
    /// Ity no safidy hafa tsy hikorontana amin'ny fanondroana ny `str`.
    /// Miverina [`None`] isaky ny miasa ny indexing mitovy panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // marina halava
    /// assert!(v.get_mut(0..5).is_some());
    /// // ivelan'ny fetra
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Miverina subslice `str` tsy voamarina.
    ///
    /// Ity no safidy tsy voamarina amin'ny fanondroana ny `str`.
    ///
    /// # Safety
    ///
    /// Ireo miantso an'io lahasa io dia tompon'andraikitra fa afa-po ireo fepetra mialoha ireo:
    ///
    /// * Ny index fanombohana dia tsy tokony hihoatra ny index famaranana;
    /// * Ny index dia tsy maintsy ao anatin'ny fetra namboarina;
    /// * Ny index dia tsy maintsy mitoetra amin'ny fetra UTF-8.
    ///
    /// Mahomby izany, ny kofehy niverina silaka dia mety tsy manan-kery ny boky fitadidiana na mandika ny invariants ampitaina ny `str` karazana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked`;
        // ny silaka dia dereferencable satria `self` dia azo antoka momba.
        // Ny niverina manondro azo antoka satria ny `SliceIndex` impls tsy maintsy antoka fa.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Miverina subslice `str` azo ovaina sy tsy voamarina.
    ///
    /// Ity no safidy tsy voamarina amin'ny fanondroana ny `str`.
    ///
    /// # Safety
    ///
    /// Ireo miantso an'io lahasa io dia tompon'andraikitra fa afa-po ireo fepetra mialoha ireo:
    ///
    /// * Ny index fanombohana dia tsy tokony hihoatra ny index famaranana;
    /// * Ny index dia tsy maintsy ao anatin'ny fetra namboarina;
    /// * Ny index dia tsy maintsy mitoetra amin'ny fetra UTF-8.
    ///
    /// Mahomby izany, ny kofehy niverina silaka dia mety tsy manan-kery ny boky fitadidiana na mandika ny invariants ampitaina ny `str` karazana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked_mut`;
        // ny silaka dia dereferencable satria `self` dia azo antoka momba.
        // Ny niverina manondro azo antoka satria ny `SliceIndex` impls tsy maintsy antoka fa.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Miteraka tady tady silaka hafa silaka, nandika ny fiarovana ny taratasim-bola.
    ///
    /// Tsy amporisihina amin'ny ankapobeny izany, ampiasao am-pitandremana!Raha mila safidy azo antoka dia jereo ny [`str`] sy [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ity sombina vaovao ity dia manomboka amin'ny `begin` mankany `end`, ao anatin'izany ny `begin` fa tsy manilika ny `end`.
    ///
    /// Mba hahazoana kofehy mutable silaka fa tsy ianao, dia jereo ny fomba [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Ireo miantso an'io lahasa io dia tompon'andraikitra amin'ny fahafaham-po mialoha ny fepetra telo:
    ///
    /// * `begin` Tsy tokony hihoatra ny `end`.
    /// * `begin` ary `end` dia tokony ho toerana byte ao anatin'ny slice string.
    /// * `begin` ary dia tsy maintsy mitoetra eo `end` UTF-8 filaharany fetra.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked`;
        // ny silaka dia dereferencable satria `self` dia azo antoka momba.
        // Ny niverina manondro azo antoka satria ny `SliceIndex` impls tsy maintsy antoka fa.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Miteraka tady tady silaka hafa silaka, nandika ny fiarovana ny taratasim-bola.
    /// Izany dia amin'ny ankapobeny tsy soso-kevitra, amin'ny fampiasana mitandrina!Raha mila safidy azo antoka dia jereo ny [`str`] sy [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ity sombina vaovao ity dia manomboka amin'ny `begin` mankany `end`, ao anatin'izany ny `begin` fa tsy manilika ny `end`.
    ///
    /// Raha te hahazo silaka tadin-javatra tsy miovaova dia jereo ny fomba [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Ireo miantso an'io lahasa io dia tompon'andraikitra amin'ny fahafaham-po mialoha ny fepetra telo:
    ///
    /// * `begin` Tsy tokony hihoatra ny `end`.
    /// * `begin` ary `end` dia tokony ho toerana byte ao anatin'ny slice string.
    /// * `begin` ary dia tsy maintsy mitoetra eo `end` UTF-8 filaharany fetra.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked_mut`;
        // ny silaka dia dereferencable satria `self` dia azo antoka momba.
        // Ny niverina manondro azo antoka satria ny `SliceIndex` impls tsy maintsy antoka fa.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Zaraina roa ny tapa-tady iray amin'ny index.
    ///
    /// Ny adihevitra, `mid`, dia tokony ho byte offset hatramin'ny nanombohan'ny kofehy.
    /// Tokony ho eo amin'ny fari-kevitry ny kaody UTF-8 ihany koa izany.
    ///
    /// Niverina ireo sombin-tsolika roa dia nanomboka ny fiandohan'ny tapa-tady ka hatramin'ny `mid`, ary ny `mid` ka hatramin'ny faran'ny voadin'ny kofehy.
    ///
    /// Raha te haka silika azo ovaina azo soloina dia jereo ny fomba [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics raha toa ka tsy eo amin'ny fari-kaody UTF-8 ny `mid`, na raha mihoatra ny faran'ny teboka kaody farany amin'ilay sombin-dahatsoratra.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary taratasim-bola fa ny Fanondroana ao [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: zahana fotsiny fa `mid` dia eo amin'ny faritry ny char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Zaraina roa ny sombin-tadiny azo ovaina amin'ny index.
    ///
    /// Ny adihevitra, `mid`, dia tokony ho byte offset hatramin'ny nanombohan'ny kofehy.
    /// Tokony ho eo amin'ny fari-kevitry ny kaody UTF-8 ihany koa izany.
    ///
    /// Niverina ireo sombin-tsolika roa dia nanomboka ny fiandohan'ny tapa-tady ka hatramin'ny `mid`, ary ny `mid` ka hatramin'ny faran'ny voadin'ny kofehy.
    ///
    /// Mba hahazoana kofehy slices loha tsy mety miova fa ianao, dia jereo ny fomba [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics raha toa ka tsy eo amin'ny fari-kaody UTF-8 ny `mid`, na raha mihoatra ny faran'ny teboka kaody farany amin'ilay sombin-dahatsoratra.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary taratasim-bola fa ny Fanondroana ao [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: zahana fotsiny fa `mid` dia eo amin'ny faritry ny char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Miverina iterator amin'ny sakan'ny [`char`] amin'ny tapa-kofehy.
    ///
    /// Satria ny sombin-kofehy dia misy UTF-8 manankery, afaka miverina amin'ny alàlan'ny tapa-tady amin'ny [`char`] isika.
    /// Ity fomba ity dia mamerina iterator toy izany.
    ///
    /// Zava-dehibe ny mahatadidy fa ny [`char`] dia maneho soatoavina Unicode Scalar, ary mety tsy hifanaraka amin'ny hevitrao momba ny atao hoe 'character'.
    ///
    /// Mety ho izay tena tadiavinao ny fifandimbiasana ny sampahom-boaloboka.
    /// Ity fampiasa ity dia tsy omen'ny tranomboky mahazatra Rust, jereo crates.io fa tsy.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Aza adino, mety tsy mifanitsy amin'ny fomba fijerinao momba ny endri-tsoratra ny [`char`]:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // tsy 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Miverina miverimberina eo ambonin'ireo [`char`] amin'ny tapa-kofehy, sy ny toerany.
    ///
    /// Satria ny sombin-kofehy dia misy UTF-8 manankery, afaka miverina amin'ny alàlan'ny tapa-tady amin'ny [`char`] isika.
    /// Ity fomba ity dia mamerina ny mpandika azy roa amin'ireto [«char`] ireto, ary koa ny toerany byte.
    ///
    /// Ny iterator tuples mahavokatra.Ny toerana aloha, ny [`char`] faharoa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Aza adino, mety tsy mifanitsy amin'ny fomba fijerinao momba ny endri-tsoratra ny [`char`]:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // tsy (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // mariho ny 3 eto, ny farany roa toetra naka oktety
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Ny iterator noho ny Bytes ny tady silaka.
    ///
    /// Toy ny tady silaka ahitana fisesin-oktety, dia afaka iterate amin'ny alalan'ny tady silaka amin'ny byte.
    /// Ity fomba ity dia mamerina iterator toy izany.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Mizara fizarana kofehy amin'ny habaka fotsy.
    ///
    /// Ny iterator niverina dia hiverina tady slices izay sub-slices ny tany am-boalohany kofehy silaka, tafasaraka misy habetsahan'ny whitespace.
    ///
    ///
    /// 'Whitespace' dia faritana araka ny fepetra ao amin'ny Unicode Derived Core Property `White_Space`.
    /// Raha toa ianao ihany no te-raraka amin'ny marika ASCII whitespace fa, mampiasa [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ny karazan-java-fotsy rehetra dia raisina:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Mizara fizarana tadin'ny ASCII whitespace.
    ///
    /// Ny iterator niverina dia hiverina tady slices izay sub-slices ny tany am-boalohany kofehy silaka, nampisaraka misy habetsahan'ny marika ASCII whitespace.
    ///
    ///
    /// Raha hisaraka amin'ny Unicode `Whitespace` kosa dia ampiasao ny [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ny karazan-java-fotsy rehetra ASCII dia raisina:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Mpiverina eo ambonin'ny tsipika kofehy, toy ny kofehy.
    ///
    /// Ny tsipika dia mifarana na ny (`\n`) vaovao na ny fiverenan'ny kalesy misy (`\r\n`) fahana tsipika.
    ///
    /// Ny andalana farany fiafaran'ny dia tsy voatery.
    /// Ny kofehy mifarana amin'ny faran'ny tsipika farany dia hamerina ireo tsipika mitovy amin'ny tady iray hafa raha tsy misy tsipika famaranana.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Ny andalana farany fiafara dia tsy ilaina;
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Mpiverina eo amin'ny tsipika kofehy.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Miverina ny iterator ny `u16` eo amin'ny kofehy voafango ho UTF-16.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Miverina `true` raha toa ka mifanaraka amin'ny sombin-tsokajy ity sombin-dahatsoratra ity.
    ///
    /// Miverina `false` raha tsy.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Miverina `true` raha mifanitsy amina endrik'ity tapa-tady ity ny lamina omena.
    ///
    /// Miverina `false` raha tsy.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Miverina `true` raha toa ka mifanaraka amin'ny tovana an'io fehin-tadiny io ny lamina nomena.
    ///
    /// Miverina `false` raha tsy.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Miverina ny byte fanondroana ny toetra voalohany ity silaka laha-daza izay mifanandrify ny mari-trano.
    ///
    /// Miverina [`None`] raha tsy mifanaraka ny lamina.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Modely sarotra kokoa amin'ny fampiasana fomba tsy misy teboka sy fanidiana:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Tsy nahita ny lamina:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Miverina ny index byte ho an'ny mpandray anjara voalohany amin'ny lalao ankavanana indrindra amin'ny lamina ao amin'ity tapa-tady ity.
    ///
    /// Miverina [`None`] raha tsy mifanaraka ny lamina.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Lamina sarotra kokoa miaraka amin'ny fanidiana:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Tsy nahita ny lamina:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// An iterator ny substrings ity silaka kofehy, tafasaraka ny tarehin-tsoratra mifanaraka amin'ny modely.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny niverina iterator Ho [`DoubleEndedIterator`] raha mamela ny fomba fikarohana sy ny mifanohitra forward/reverse fikarohana ka nanaraka ny singa iray ihany.
    /// Marina izany ho an'ny, ohatra, [`char`], fa tsy ho an'ny `&str`.
    ///
    /// Raha ny fomba mamela ny mifanohitra fikarohana fa mety hitovy ny vokatra avy amin'ny nandroso fikarohana, ny fomba [`rsplit`] dia azo ampiasaina.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Raha ny fomba dia silaka chars, raraka amin'ny fisian'ny tsirairay ny zanaky ny anjara:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Ny modely sarotra kokoa, mampiasa ny fanakatonana:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Raha misy mpampisaraka mpampisaraka maro ny kofehy iray, dia hiafara amin'ny tady foana ao amin'ny vokatra ianao:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Contiguous separators dia tafasaraka foana ny tady.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separators tamin'ny voalohany na ny farany ny tady no neighbored amin'ny alalan'ny tady foana.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Rehefa ilay tohivakana foana no ampiasaina ho toy ny Separator, dia mampisaraka toetra rehetra ao amin'ny kofehy miaraka ny manomboka sy mifarana ny amin'ny kofehy.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Contiguous separators Mety hitarika ho amin'ny fitondran-tena mety mahagaga raha whitespace no ampiasaina ho toy ny Separator.Marina ity kaody ity:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Izany no _not_ manome anao:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Mampiasà [`split_whitespace`] ho an'ity fihetsika ity.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// An iterator ny substrings ity silaka kofehy, tafasaraka ny tarehin-tsoratra mifanaraka amin'ny modely.
    /// Ny tsy fitovizan'ny iterator novokarin'i `split` tamin'io `split_inclusive` dia mamela ny ampahany mifanentana amin'ny maha terminator an'ilay substring.
    ///
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Raha toa ny singa farany ny kofehy dia mifanentana, izay singa hodinihina Rakoto substring ny teo aloha.
    /// Izany substring no ho farany niverina ny zavatra iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// An iterator ny substrings ny kofehy nomena silaka, nampisaraka ny tarehin-tsoratra mifanaraka amin'ny modely ka afaka amin'ny mba mivadika.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny iterator niverina dia mitaky ny fanohanana ny lamina amin'ny fihoarana ny lamina, ary ho [`DoubleEndedIterator`] izany raha ny fikarohana forward/reverse dia miteraka singa mitovy.
    ///
    ///
    /// Ho an'ny fanaovana iter eo aloha dia azo ampiasaina ny fomba [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Ny modely sarotra kokoa, mampiasa ny fanakatonana:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Mpiverina amin'ny substrings amin'ilay tapa-kofehy nomena, nosarahan'ny litera mifanaraka amin'ny lamina iray.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Mitovy amin'ny [`split`], afa-tsy ny substring manara-dia nesorina raha foana.
    ///
    /// [`split`]: str::split
    ///
    /// Ity fomba ity dia azo ampiasaina amin'ny angona tahiry izay _terminated_ fa tsy _separated_ amin'ny lamina iray.
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny niverina iterator Ho [`DoubleEndedIterator`] raha mamela ny fomba fikarohana sy ny mifanohitra forward/reverse fikarohana ka nanaraka ny singa iray ihany.
    /// Marina izany ho an'ny, ohatra, [`char`], fa tsy ho an'ny `&str`.
    ///
    /// Raha mamela ny fikarohana miverimberina ny lamina saingy mety tsy hitovy amin'ny valin'ny fikarohana mialoha ny vokany dia azo ampiasaina ny fomba [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Mpiverina amin'ny substrings an'ny `self`, nosarahan'ny tarehin-tsoratra nifanaraka tamin'ny lamina iray ary nilefitra tamin'ny filaharana.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Mitovy amin'ny [`split`], afa-tsy ny substring manara-dia nesorina raha foana.
    ///
    /// [`split`]: str::split
    ///
    /// Ity fomba ity dia azo ampiasaina amin'ny angona tahiry izay _terminated_ fa tsy _separated_ amin'ny lamina iray.
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny iterator niverina dia mitaky ny fanohanana ny lamina amin'ny fihoarana ny lamina, ary ho tapitra indroa izy io raha mitady forward/reverse fitadiavana singa mitovy.
    ///
    ///
    /// Fa iterating avy aloha, ny fomba [`split_terminator`] dia azo ampiasaina.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// An iterator ny substrings ny kofehy nomena silaka, tafasaraka iray lamina, voafetra ho niverina amin'ny zavatra `n` indrindra.
    ///
    /// Raha miverina ny substrings `n`, ny substring farany (ny substring `n`th) dia misy ny sisa amin'ny kofehy.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ilay miverina miverina dia tsy ho tapitra indroa, satria tsy mahomby ny fanohanana.
    ///
    /// Raha mamela ny fikarohana miverimberina ny lamina, dia azo ampiasaina ny fomba [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Ny modely sarotra kokoa, mampiasa ny fanakatonana:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// An iterator ny substrings ity silaka kofehy, sarahan'ny modely, manomboka avy any amin'ny faran'ny ny kofehy, voafetra ho niverina amin'ny zavatra `n` indrindra.
    ///
    ///
    /// Raha miverina ny substrings `n`, ny substring farany (ny substring `n`th) dia misy ny sisa amin'ny kofehy.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ilay miverina miverina dia tsy ho tapitra indroa, satria tsy mahomby ny fanohanana.
    ///
    /// Ho an'ny fisarahana avy eo aloha dia azo ampiasaina ny fomba [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Ny modely sarotra kokoa, mampiasa ny fanakatonana:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Mizara ny tadiny amin'ny fisehoana voalohany ny famaritana voafaritra ary miverina première alohan'ny delimiter sy tovana aorian'ny delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Mamaky ny kofehy momba ny fisehoan-javatra farany 'ny mazava delimiter sy miverina eo anatrehan'ny delimiter tovona sy tovana aorian'ny delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ny iterator noho ny disjoint mifanaraka amin'ny modely ao anatin'ny nomena silaka tady.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny niverina iterator Ho [`DoubleEndedIterator`] raha mamela ny fomba fikarohana sy ny mifanohitra forward/reverse fikarohana ka nanaraka ny singa iray ihany.
    /// Marina izany ho an'ny, ohatra, [`char`], fa tsy ho an'ny `&str`.
    ///
    /// Raha ny fomba mamela ny mifanohitra fikarohana fa mety hitovy ny vokatra avy amin'ny nandroso fikarohana, ny fomba [`rmatches`] dia azo ampiasaina.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Mpiverina iray amin'ireo lalao mifanipaka amin'ny lamina ao anatin'ity tapa-kofehy ity, izay naterina tamin'ny filaharana.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny iterator niverina dia mitaky ny fanohanana ny lamina amin'ny fihoarana ny lamina, ary ho [`DoubleEndedIterator`] izany raha ny fikarohana forward/reverse dia miteraka singa mitovy.
    ///
    ///
    /// Ho an'ny fanaovana iter eo aloha dia azo ampiasaina ny fomba [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Mpiverina iray amin'ireo lalao mifanipaka amin'ny lamina ao anatin'ity tapa-tady ity ary koa ny index izay manomboka ny lalao.
    ///
    /// Ho an'ny lalao `pat` ao anatin'ny `self` izay mifanindry, ny indice mifandraika amin'ny lalao voalohany ihany no averina.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny niverina iterator Ho [`DoubleEndedIterator`] raha mamela ny fomba fikarohana sy ny mifanohitra forward/reverse fikarohana ka nanaraka ny singa iray ihany.
    /// Marina izany ho an'ny, ohatra, [`char`], fa tsy ho an'ny `&str`.
    ///
    /// Raha mamela ny fikarohana miverimberina ny lamina saingy mety tsy hitovy amin'ny valin'ny fikarohana mialoha ny vokany dia azo ampiasaina ny fomba [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // `aba` voalohany ihany
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Mpiverina iray amin'ireo lalao mifanipaka amin'ny lamina ao anatin'ny `self`, dia namoaka filaharana mifandimby miaraka amin'ny mari-panondroan'ny lalao.
    ///
    /// Fa ao anatin'ny lalao ny `pat` `self` izay hifanindry ihany ny indices mifanaraka amin'ny lalao farany dia niverina.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ny fitondran-tena
    ///
    /// Ny iterator niverina dia mitaky ny fanohanana ny lamina amin'ny fihoarana ny lamina, ary ho [`DoubleEndedIterator`] izany raha ny fikarohana forward/reverse dia miteraka singa mitovy.
    ///
    ///
    /// Fa iterating avy aloha, ny fomba [`match_indices`] dia azo ampiasaina.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ny `aba` farany ihany
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Miverina sombin-tadiny iray, nesorina ilay toerana fotsy sy mitarika.
    ///
    /// 'Whitespace' dia faritana araka ny fepetra ao amin'ny Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Miverina sombin-tadiny iray nesorina ilay toerana fotsy.
    ///
    /// 'Whitespace' dia faritana araka ny fepetra ao amin'ny Unicode Derived Core Property `White_Space`.
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// `start` amin'ny vanim-potoana io dia midika hoe ny toerana voalohany izany byte tady;ho an'ny fiteny miankavia sy miankavanana toa ny Anglisy na Rosiana, dia eo amin'ny ilany ankavia io, ary ho an'ny fiteny ankavanana miankavia toy ny Arabo na hebreo, dia io no ho lafiny ankavanana.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Miverina sombin-tadiny iray nesorina ilay vazaha fotsy.
    ///
    /// 'Whitespace' dia faritana araka ny fepetra ao amin'ny Unicode Derived Core Property `White_Space`.
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// `end` Amin'ity tontolon-kevitra ity dia midika ny toerana farany an'ny tadin'ny byte;ho ankavia-to-teny marina toy ny teny anglisy na rosiana, izany dia ho ankavanana, ary ny marina-to-teny sisa toy ny teny Arabo na ny teny hebreo, izany no ho lafiny ankavia.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Miverina sombin-tadiny iray nesorina ilay toerana fotsy.
    ///
    /// 'Whitespace' dia faritana araka ny fepetra ao amin'ny Unicode Derived Core Property `White_Space`.
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// 'Left' amin'ny vanim-potoana io dia midika hoe ny toerana voalohany izany byte tady;ho an'ny fiteny toa ny Arabo na hebreo izay 'havanana miankavia' fa tsy 'ankavia miankavanana', ity no ho _right_ fa tsy ny ankavia.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Miverina sombin-tadiny iray nesorina ilay vazaha fotsy.
    ///
    /// 'Whitespace' dia faritana araka ny fepetra ao amin'ny Unicode Derived Core Property `White_Space`.
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// 'Right' Amin'ity tontolon-kevitra ity dia midika ny toerana farany an'ny tadin'ny byte;ho an'ny fiteny toa ny Arabo na hebreo izay 'havanana miankavia' fa tsy 'ankavia miankavanana', ity no ho _left_ lafiny fa tsy ny havanana.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Miverina sombin-tadiny miaraka amina prefes sy tovana izay mifanaraka amin'ny lamina nesorina matetika.
    ///
    /// Ny [pattern] mety ho [`char`], silaka [: char`] s, na ny asa na ny fanakatonana izay mamaritra raha misy toetra lalao.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Ny modely sarotra kokoa, mampiasa ny fanakatonana:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Tsarovy voalohany fantatra lalao, hanitsy izany eto ambany raha
            // tsy mitovy ny lalao farany
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` dia fantatra fa miverina indice mety.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Miverina tapa-tady miaraka amina prefes rehetra mifanaraka amin'ny lamina nesorina matetika.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// `start` amin'ny vanim-potoana io dia midika hoe ny toerana voalohany izany byte tady;ho an'ny fiteny miankavia sy miankavanana toa ny Anglisy na Rosiana, dia eo amin'ny ilany ankavia io, ary ho an'ny fiteny ankavanana miankavia toy ny Arabo na hebreo, dia io no ho lafiny ankavanana.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` dia fantatra fa miverina indice mety.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Miverina ny kofehy silaka amin'ny tovona nesorina.
    ///
    /// Raha amin'ny kofehy manomboka amin'ny ny fomba `prefix`, miverina substring araka ny tovona, voahodidina lamban-`Some`.
    /// Tsy toy ny `trim_start_matches`, io fomba io dia manafoana ny prefika indray mandeha.
    ///
    /// Raha tsy manomboka amin'ny `prefix` ny tadiny dia avereno `None`.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Miverina ny kofehy silaka amin'ny tovana nesorina.
    ///
    /// Raha mifarana amin'ny lamina `suffix` ny tadiny dia avereno ny substring alohan'ny tovana, fonosina `Some`.
    /// Tsy toy ny `trim_end_matches`, fomba izany dia manala ny tovana marina indray mandeha.
    ///
    /// Raha tsy mifarana amin'ny `suffix` ny tadiny dia avereno `None`.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Miverina ny kofehy rehetra silaka suffixes izay mifanaraka amin'ny modely imbetsaka nesorina.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// `end` Amin'ity tontolon-kevitra ity dia midika ny toerana farany an'ny tadin'ny byte;ho ankavia-to-teny marina toy ny teny anglisy na rosiana, izany dia ho ankavanana, ary ny marina-to-teny sisa toy ny teny Arabo na ny teny hebreo, izany no ho lafiny ankavia.
    ///
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ny modely sarotra kokoa, mampiasa ny fanakatonana:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` dia fantatra fa miverina indice mety.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Miverina tapa-tady miaraka amina prefes rehetra mifanaraka amin'ny lamina nesorina matetika.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// 'Left' amin'ny vanim-potoana io dia midika hoe ny toerana voalohany izany byte tady;ho an'ny fiteny toa ny Arabo na hebreo izay 'havanana miankavia' fa tsy 'ankavia miankavanana', ity no ho _right_ fa tsy ny ankavia.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Miverina ny kofehy rehetra silaka suffixes izay mifanaraka amin'ny modely imbetsaka nesorina.
    ///
    /// Ny [pattern] dia mety ho `&str`, [`char`], sombin-[[char`] s, na fiasa na fanidiana mihidy raha mifanaraka ny toetra amam-panahy.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Toro lalana
    ///
    /// Ny tadiny dia filaharam-bytes.
    /// 'Right' Amin'ity tontolon-kevitra ity dia midika ny toerana farany an'ny tadin'ny byte;ho an'ny fiteny toa ny Arabo na hebreo izay 'havanana miankavia' fa tsy 'ankavia miankavanana', ity no ho _left_ lafiny fa tsy ny havanana.
    ///
    ///
    /// # Examples
    ///
    /// Lamina tsotra:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Ny modely sarotra kokoa, mampiasa ny fanakatonana:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses laha-daza io silaka ho karazana hafa.
    ///
    /// Satria `parse` dia ankapobeny, dia mety hiteraka olana amin'ny karazana inference.
    /// Araka izany, `parse` dia iray amin'ireo fotoana vitsy ahitanao ilay syntax fantatra amin'ny anarana hoe 'turbofish': `::<>`.
    ///
    /// Izany dia manampy ny inference algorithm hahatakatra izay manoratra manokana ianao miezaka ny ho hadihadiana.
    ///
    /// `parse` afaka mizaha karazana izay mampihatra ny [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Hiverina [`Err`] raha toa ka tsy azo atao ny mamaky ity tapa-kofehy ity amin'ny karazana irina.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Fampiasana fototra
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Amin'ny alalan'ny fampiasana ny 'turbofish' fa tsy annotating `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Tsy nahomby ny hadihadiana:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Hamarino raha ao anaty kisary ASCII daholo ny endri-tsoratra ato amin'ity kofehy ity.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Afaka hitondra byte tsirairay toy ny toetra eto: multibyte mpandray anjara rehetra manomboka amin'ny byte izay tsy ao amin'ny ascii isan-karazany, toy izany isika dia hijanona any sahady.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Taratasim-bola dia nisy roa lahy ireo ny marika ASCII kofehy raharaha-miraharaha lalao.
    ///
    /// Mitovy amin'ny `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, fa tsy mizara sy mandika vonjimaika.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Mamadika an'io kofehy io amin'ny ASCII misy tranga ambony mitovy amin'ny toerany.
    ///
    /// Ny litera ASCII 'a' ka hatramin'ny 'z' dia mapafao amin'ny 'A' ka hatramin'ny 'Z', fa ny litera tsy ASCII tsy miova.
    ///
    /// Mba hiverina vaovao uppercased sanda tsy manova ny efa misy iray, mampiasa [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SAFETY: azo antoka satria mampita karazany roa miaraka amina endrika mitovy isika.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Mamadika an'io kofehy io amin'ny ASCII misy litera kely eo an-toerana.
    ///
    /// Marika ASCII taratasy 'A' ho 'Z' dia tsarintany ny 'a' ho 'z', fa tsy marika ASCII taratasy dia niova.
    ///
    /// Mba hiverina vaovao lowercased sanda tsy manova ny efa misy iray, mampiasa [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SAFETY: azo antoka satria mampita karazany roa miaraka amina endrika mitovy isika.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Miverena iterator izay afa-mandositra ny tsirairay `self` Char tany amin'ny [`char::escape_debug`].
    ///
    ///
    /// Note: ihany no nampahazo grapheme codepoints izay manomboka amin'ny kofehy ho afa-nandositra.
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Avereno iterator izay afa-mandositra ny char tsirairay amin'ny `self` miaraka amin'ny [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Miverena iterator izay afa-mandositra ny tsirairay `self` Char tany amin'ny [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Mamorona str tsy misy na inona na inona
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Miteraka foana mutable p
    #[inline]
    fn default() -> Self {
        // SAFETY: UTF-8 ny tadiny tsy misy.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Karazana fn azo tononina, azo zahana
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAFETY: tsy azo antoka
        unsafe { from_utf8_unchecked(bytes) }
    };
}