//! Fomba famoronana `str` avy amin'ny slice bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Niova fo ho silaka ny oktety amin'ny tady silaka.
///
/// Ny slice ([`&str`]) dia vita amin'ny bytes ([`u8`]), ary ny byte slice ([`&[u8]`][byteslice]) dia vita amin'ny bytes, ka io asa io dia mivadika eo anelanelan'ny roa.
/// Tsy ny sombin-byte rehetra dia fehezan-dalàna misy tadiny, na izany aza: [`&str`] dia mitaky UTF-8 mety.
/// `from_utf8()` fanamarinana mba hahazoana antoka fa marina ny bytes UTF-8, ary avy eo manao ny fiovam-po.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Raha toa ianao ka antoka fa ny byte silaka dia manan-kery UTF-8, nefa tsy te-iharan 'ny ambony ny mampanankery maso, misy mampidi-doza ity dika asa, [`from_utf8_unchecked`], izay manana fihetsika toy izany koa fa skips ny maso.
///
///
/// Raha toa ka mila ny `String` fa tsy ny `&str`, Diniho [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Satria azonao atao ny manangona-manokana `[u8; N]`, ary afaka maka [`&[u8]`][byteslice] amin'izany ianao, io fiasa io dia fomba iray hananana kofehy natokana ho an'ny stack.Misy ohatra iray amin'izany ao amin'ireo fizarana ohatra etsy ambany.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Miverina `Err` raha silaka tsy UTF-8 amin'ny famaritana ny antony ny silaka dia tsy nanome UTF-8.
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::str;
///
/// // bytes sasany, ao amin'ny vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Fantatray fa manan-kery ireo byte ireo, ka ampiasao `unwrap()` fotsiny.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Diso bytes:
///
/// ```
/// use std::str;
///
/// // bytes tsy mety sasany, ao amin'ny vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Zahao ireo rakitra momba ny [`Utf8Error`] raha mila tsipiriany misimisy momba ireo karazana lesoka azo averina.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // oktety sasany, ao niisa-omena fihaingoana
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Fantatray fa manan-kery ireo byte ireo, ka ampiasao `unwrap()` fotsiny.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: fanamarinana vao vita.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Mamadika sombin-bytes azo ovaina ho voamadinika tadikely azo ovaina.
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" toy ny vector azo ovaina
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Raha fantatsika fa manan-kery ireo byte dia afaka mampiasa `unwrap()` isika
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Diso bytes:
///
/// ```
/// use std::str;
///
/// // Misy tsy mety ao amin'ny mutable oktety vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Zahao ireo rakitra momba ny [`Utf8Error`] raha mila tsipiriany misimisy momba ireo karazana lesoka azo averina.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: fanamarinana vao vita.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Mamadika sombin-bytes ho an'ny tsipika tsy tadidinao fa misy UTF-8 mety ny tadiny.
///
/// Jereo ny kinova azo antoka, [`from_utf8`], raha mila fanazavana fanampiny.
///
/// # Safety
///
/// Tsy azo antoka ity fiasa ity satria tsy manamarina raha mitentina UTF-8 ny bytes nolalovana tamin'io.
/// Raha izany no nandika tery be tsy voafaritra vokatry ny fitondran-tena, toy ny sisa Rust jerena, dia hoatran'ny hoe [`&str`] S dia manan-kery UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::str;
///
/// // bytes sasany, ao amin'ny vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: ny miantso dia tsy maintsy miantoka fa ny bytes `v` dia manan-kery UTF-8.
    // Ihany koa ny miantehitra amin'ny `&str` sy `&[u8]` manana izany fisehon'ny.
    unsafe { mem::transmute(v) }
}

/// Mamadika sombin-bytes ho an'ny tsipika tsy tadidinao fa misy UTF-8 manan-kery io tady io;kinova miovaova.
///
///
/// Jereo ny kinova tsy miova, [`from_utf8_unchecked()`] raha mila fanazavana fanampiny.
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // Famonjena, ny mpiantso antoka fa tsy maintsy ny oktety `v`
    // dia manan-kery UTF-8, dia toy izany ny hariana any `*mut str` voavonjy.
    // Ary azo antoka ihany koa ny fanodikodinana pointer satria io tondro io dia avy amin'ny tondro izay azo antoka fa manan-kery amin'ny fanoratana.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}