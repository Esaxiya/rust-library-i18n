//! Trait implementations for `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Mampihatra ny filaharana tadiny.
///
/// Ny kofehy dia baiko [lexicographically](Ord#lexicographical-comparison) amin'ny sanda byte.
/// Ity dia manome baiko ny kaody Unicode mifototra amin'ny toerana misy azy ireo amin'ny tabilao kaody.
/// Tsy voatery hitovy amin'ny filaharana "alphabetical" izany, izay miovaova arakaraka ny fiteny sy ny toerana eo an-toerana.
/// Ny fanasiana kofehy mifanaraka amin'ny fenitra eken'ny kolontsaina dia mitaky angona manokana ao an-toerana izay ivelan'ny faritry ny karazana `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Fampitahana fitaovana fandidiana eo amin'ny tady.
///
/// Kofehy no nampitaha [lexicographically](Ord#lexicographical-comparison) araka ny byte soatoavina.
/// Mampitaha ireo teboka kaody Unicode miorina amin'ny toerana misy azy ireo amin'ny tabilao kaody.
/// Tsy voatery hitovy amin'ny filaharana "alphabetical" izany, izay miovaova arakaraka ny fiteny sy ny toerana eo an-toerana.
/// Mampitaha tady araka ny kolontsaina-nanaiky fitsipika Mitaky locale-tahirin-kevitra manokana izay eo ivelan'ny sehatra ny `str` karazana.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Mampihatra fametahana substring miaraka amin'ny syntax `&self[..]` na `&mut self[..]`.
///
/// Miverina silaka rehetra kofehy, izany hoe, miverina `&self` na `&mut self`.Mitovy amin'ny: &tena [0 ..
/// len] `na`&mut tena [0 ..
/// len]`.
/// Tsy toy ny asa fanoratana hafa, tsy afaka panic mihitsy io.
///
/// Ity hetsika ity dia *O*(1).
///
/// Talohan'ny 1.20.0, ireo asa fanoratana ireo dia mbola notohanan'ny fampiharana mivantana ny `Index` sy `IndexMut`.
///
/// Mitovy amin'ny `&self[0 .. len]` na `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Mampihatra fametahana substring miaraka amin'ny syntax `&self[begin .. end]` na `&mut self[begin .. end]`.
///
/// Miverina ho silaka ny nomena avy amin'ny byte kofehy isan-karazany [`begin`, `end`).
///
/// Ity hetsika ity dia *O*(1).
///
/// Talohan'ny 1.20.0, ireo asa fanoratana ireo dia mbola notohanan'ny fampiharana mivantana ny `Index` sy `IndexMut`.
///
/// # Panics
///
/// Panics raha `begin` na `end` dia tsy manondro ny fanombohana byte offset ny toetra (araka ny famaritan'ny `is_char_boundary`), raha `begin > end`, na raha `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ireto dia panic:
/// // byte 2 mitoetra ao anatin'ny `ö`:
/// // &S [2 ..3];
///
/// // byte 8 dia mitoetra ao anatin'ny `老`&s [1 ..
/// // 8];
///
/// // byte 100 dia ivelan'ny string&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // Famonjena, homarinana avy amin'ny teny fotsiny fa `start` sy `end` dia teo amin'ny sisin Char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            // Nanamarina ihany koa ny fetra char izahay, ka UTF-8 io no marina.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // Famonjena, homarinana avy amin'ny teny fotsiny fa `start` sy `end` dia teo amin'ny sisin Char.
            // Fantatray fa tsy manam-paharoa ny pointer satria azontsika tamin'ny `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: ny miantso dia manome antoka fa `self` dia fehezin'ny `slice`
        // izay no mifanaraka tsara amin'ny toe-javatra ho an'ny `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: jereo ny hevitra momba ny `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary manamarina fa ny index dia ao amin'ny [0, .len()] tsy afaka mampiasa `get` toy ny etsy ambony, noho ny olana NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // Famonjena, homarinana avy amin'ny teny fotsiny fa `start` sy `end` dia teo amin'ny sisin Char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Fitaovana substring slicing amin'ny Syntaxe `&self[.. end]` na `&mut self[.. end]`.
///
/// Miverina sombin-kofehy nomena avy amin'ny sakany byte [`0`, `end`).
/// Mitovy amin'ny `&self[0 .. end]` na `&mut self[0 .. end]`.
///
/// Ity hetsika ity dia *O*(1).
///
/// Talohan'ny 1.20.0, ireo asa fanoratana ireo dia mbola notohanan'ny fampiharana mivantana ny `Index` sy `IndexMut`.
///
/// # Panics
///
/// Panics raha `end` dia tsy manondro ny fanombohana byte offset ny endri-tsoratra (araka ny famaritan'ny `is_char_boundary`), na raha `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: nanamarina fotsiny fa `end` dia eo amin'ny faritry ny char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAFETY: nanamarina fotsiny fa `end` dia eo amin'ny faritry ny char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAFETY: nanamarina fotsiny fa `end` dia eo amin'ny faritry ny char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Fitaovana substring slicing amin'ny Syntaxe `&self[begin ..]` na `&mut self[begin ..]`.
///
/// Miverina sombin-kofehy nomena avy amin'ny sakany byte [`begin`, `len`).Mitovy amin'ny `&tena [manomboka ..
/// Len], na: &mut tena [manomboka ..
/// len]`.
///
/// Ity hetsika ity dia *O*(1).
///
/// Talohan'ny 1.20.0, ireo asa fanoratana ireo dia mbola notohanan'ny fampiharana mivantana ny `Index` sy `IndexMut`.
///
/// # Panics
///
/// Panics `begin` raha tsy manondro ny manomboka byte offset ny toetra (izay nofaritan'ny `is_char_boundary`), na raha `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // Famonjena, homarinana avy amin'ny teny fotsiny fa `start` dia amin'ny sisin Char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // Famonjena, homarinana avy amin'ny teny fotsiny fa `start` dia amin'ny sisin Char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAFETY: ny miantso dia manome antoka fa `self` dia fehezin'ny `slice`
        // izay no mifanaraka tsara amin'ny toe-javatra ho an'ny `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAFETY: mitovy amin'ny `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // Famonjena, homarinana avy amin'ny teny fotsiny fa `start` dia amin'ny sisin Char,
            // ary dia nandalo tao amin'ny boky soa aman-tsara, toy izany koa ny miverina sarobidy ho iray ihany koa.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Mampihatra fametahana substring miaraka amin'ny syntax `&self[begin ..= end]` na `&mut self[begin ..= end]`.
///
/// Miverina silaka ny nomena kofehy avy amin'ny byte [`begin`, `end`] isan-karazany.Mitovy amin'ny `&self [begin .. end + 1]` na `&mut self[begin .. end + 1]`, afa-tsy raha `end` manana ny ambony indrindra ho an'ny `usize` sarobidy.
///
/// Ity hetsika ity dia *O*(1).
///
/// # Panics
///
/// Panics raha `begin` tsy manondro ny manomboka byte offset ny toetra (izay nofaritan'ny `is_char_boundary`), raha `end` no tsy manondro ny fiafarana byte offset ny mpandray anjara (`end + 1` dia na ny manomboka byte offset na mitovy ny `len`), raha `begin > end`, na raha `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Mampihatra fametahana substring miaraka amin'ny syntax `&self[..= end]` na `&mut self[..= end]`.
///
/// Miverina silaka ny nomena kofehy avy amin'ny byte [0, `end`] isan-karazany.
/// Mitovy amin'ny `&self [0 .. end + 1]`, afa-tsy raha `end` manana ny ambony indrindra ho an'ny `usize` sarobidy.
///
/// Ity hetsika ity dia *O*(1).
///
/// # Panics
///
/// Panics `end` raha tsy manondro ny fiafarana byte offset ny mpandray anjara (`end + 1` dia na ny manomboka byte offset izay nofaritan'ny `is_char_boundary`, na mitovy amin'i `len`), na raha `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Hadihadiana ny zava-dehibe avy amin'ny tady
///
/// Ny fomba [`from_str`] an'ny `FromStr` dia matetika ampiasaina an-tsokosoko, amin'ny alàlan'ny fomba [`parse`] an'i [`str`].
/// Jereo ny rakitsoratr'i [`parse`] ohatra.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` Tsy manana fari-piainana mandritra ny androm-piainany, ary noho izany dia azonao atao ihany ny mamaky karazana izay tsy misy fari-piainana mandritra ny androm-piainany.
///
/// Raha atao teny hafa, azonao atao ny mamaky `i32` amin'ny `FromStr`, fa tsy `&i32`.
/// Afaka hadihadiana ny struct izay ahitana ny `i32`, nefa tsy iray izay ahitana ny `&i32`.
///
/// # Examples
///
/// Fampiharana fototra `FromStr` amin'ny karazana `Point` ohatra:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Ny fahadisoana mifandray izay azo niverina avy parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Mametaka kofehy `s` hamerenana ny sandan'ity karazana ity.
    ///
    /// Raha mahomby ny famaritana dia avereno ny sanda ao anaty [`Ok`], raha tsy izany rehefa tsy voalamina ny endrika dia avereno hadisoana manokana ao anaty [`Err`].
    /// Ny karazana lesoka dia manokana amin'ny fampiharana ny trait.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra amin'ny [`i32`], karazana fampiharana `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Hadihadiana ny `bool` avy amin'ny tady.
    ///
    /// Mahavokatra ny `Result<bool, ParseBoolError>`, satria `s` mety na mety tsy ho parseable raha ny marina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Mariho, amin'ny tranga maro, ny fomba `.parse()` amin'ny `str` dia mety kokoa.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}