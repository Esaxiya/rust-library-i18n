//! Mamaritra ny karazana lesoka utf8.

use crate::fmt;

/// Fahadisoana izay mety hitranga rehefa manandrana mandika ny filaharana [`u8`] ho tadin-dokanga.
///
/// Araka izany, ny fianakaviana `from_utf8` misy ny fiasa sy ny fomba fampiasa ho an'ny [`String`] s sy [`&str`] dia mampiasa an'io hadisoana io, ohatra.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Ity karazana fahadisoana ny fomba azo ampiasaina mba hamoronana miasa toy ny antontan-javatra `String::from_utf8_lossy` tsy allocating fitadidiana:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Miverina ny index amin'ny tadiny nomena izay UTF-8 manamarina no voamarina.
    ///
    /// Io no index avo indrindra ka hiverina `Ok(_)` i `from_utf8(&input[..index])`.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::str;
    ///
    /// // bytes tsy mety sasany, ao amin'ny vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 hiverina ny Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ny faharoa dia tsy manan-kery eto byte
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Manome fampahalalana bebe kokoa momba ny tsy fahombiazana:
    ///
    /// * `None`: ny fiafaran'ny fahan'ny dia tonga tampoka.
    ///   `self.valid_up_to()` dia 1 hatramin'ny 3 bytes avy amin'ny faran'ny input.
    ///   Raha toa ka esorina miandalana ny renirano byte (toy ny fisie na ny valin'ny tamba-jotra) dia mety ho `char` manan-kery izay misy ny andiany UTF-8 byte mamaky sakana maromaro.
    ///
    ///
    /// * `Some(len)`: sendra byte tsy nampoizina no sendra azy.
    ///   Ny lavany dia nanome fa ny tsy manan-kery byte filaharany izay manomboka amin'ny Fanondroana nomen `valid_up_to()`.
    ///   Ny decoding dia tokony hitohy aorian'io filaharana io (aorian'ny fampidirana [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) raha toa ka misy decoding lossy.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Niverina ny lesoka iray rehefa tsy nahomby ny fametahana `bool` iray mampiasa [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}