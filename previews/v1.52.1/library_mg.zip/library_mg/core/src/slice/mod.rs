// ignore-tidy-filelength

//! Fitantanana ny silaka sy fanodinkodinana.
//!
//! Raha mila tsipiriany misimisy kokoa jereo [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Fampiharana memchr rust madio, nalaina avy tamin'ny rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ity asa ity dia ampahibemaso fotsiny satria tsy misy fomba hafa anaovana test heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Mamerina ny isan'ny singa ao amin'ilay silaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // Famonjena, feo const satria transmute ny lavany an-tsaha toy ny usize (izay tsy maintsy ho)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: azo antoka ity satria mitovy endrika ny `&[T]` sy `FatPtr<T>`.
            // `std` irery no afaka manome an'io antoka io.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Soloy ny `crate::ptr::metadata(self)` rehefa azo antoka izany.
            // Hatramin'ny nanoratanay ity dia miteraka error "Const-stable functions can only call other const-stable functions".
            //

            // SAFETY: Ny fidirana amin'ny sanda avy amin'ny firaisana `PtrRepr` dia azo antoka hatramin'ny * const T
            // ary ny PtrComponents<T>manana lamina fitadidiana mitovy.
            // std ihany no afaka manome an'io antoka io.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Miverina `true` raha toa ka manana 0 ny halavany.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Miverina ny singa voalohany amin'ny silaka, na `None` raha foana.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Miverina pointer azo ovaina amin'ny singa voalohany amin'ilay silaka, na `None` raha foana izy.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Avereno ny voalohany sy ny sisa rehetra amin'ireo singa amin'ilay silaka, na `None` raha foana izy.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Avereno ny voalohany sy ny sisa rehetra amin'ireo singa amin'ilay silaka, na `None` raha foana izy.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Mamerina ny farany sy ny sisa rehetra amin'ireo singa amin'ilay silaka, na `None` raha foana izy.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Mamerina ny farany sy ny sisa rehetra amin'ireo singa amin'ilay silaka, na `None` raha foana izy.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Miverina ny singa farany amin'ilay silaka, na `None` raha foana izy.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Miverina pointer azo ovaina amin'ny entana farany ao amin'ilay slice.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Miverina ny fanondroana singa na subslice miankina amin'ny karazana index.
    ///
    /// - Raha omena toerana dia avereno jerena ny singa amin'io toerana io na `None` raha toa ka ivelan'ny fetra.
    ///
    /// - Raha nomena isan-karazany, miverina ny subslice mifanaraka izany isan-karazany, na `None` raha avy ny fetra.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Miverina fanondroana miovaova amin'ny singa na subslice miankina amin'ny karazana index (jereo [`get`]) na `None` raha toa ka ivelan'ny fetra ny index.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Niverina fanondro ny singa na subslice, tsy manao fetra mijery.
    ///
    /// Raha mila safidy azo antoka dia jereo ny [`get`].
    ///
    /// # Safety
    ///
    /// Miantso fomba ity miaraka amin'ny avy-of-fetra fanondroana dia *[tsy voafaritra fitondran-tena]* na dia ny vokatry ny boky dia tsy ampiasaina.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: ny mpiantso dia tsy maintsy mitazona ny ankamaroan'ny fepetra takiana amin'ny `get_unchecked`;
        // ny silaka dia dereferencable satria `self` dia azo antoka momba.
        // Ny niverina manondro azo antoka satria ny `SliceIndex` impls tsy maintsy antoka fa.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Miverina fanondroana miovaova amin'ny singa na subslice, nefa tsy manao fanaraha-maso fetra.
    ///
    /// Raha mila safidy azo antoka dia jereo ny [`get_mut`].
    ///
    /// # Safety
    ///
    /// Miantso fomba ity miaraka amin'ny avy-of-fetra fanondroana dia *[tsy voafaritra fitondran-tena]* na dia ny vokatry ny boky dia tsy ampiasaina.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: ny miantso dia tsy maintsy manohana ny fepetra fiarovana ho an'ny `get_unchecked_mut`;
        // ny silaka dia dereferencable satria `self` dia azo antoka momba.
        // Ny niverina manondro azo antoka satria ny `SliceIndex` impls tsy maintsy antoka fa.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Mamerina ny tondro masaka ao amin'ny buffer an'ny silaka.
    ///
    /// Ny miantso dia tsy maintsy miantoka fa velona ny sombin-kaonty naverina ity asany ity, fa raha tsy izany dia hanondro ny fako izy.
    ///
    /// Dia tsy maintsy ihany koa ny mpiantso antoka fa manondro ny fahatsiarovana (non-transitively) manondro dia tsy voasoratra ho (afa-tsy ao anatin'ny iray `UnsafeCell`) mampiasa io manondro na homarinana avy amin'ny teny manondro azy.
    /// Raha mila manova ny atin'ny silaka ianao dia ampiasao [`as_mut_ptr`].
    ///
    /// Ny fanovana ny kaontenera voatonona amin'ity sombin-kazo ity dia mety hiteraka fametahana ny buffer-ny, izay mety hahatonga ny tondro any aminy tsy mety.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Miverina tondro azo ovaina tsy azo antoka amin'ny buffer an'ny silaka.
    ///
    /// Ny miantso dia tsy maintsy miantoka fa velona ny sombin-kaonty naverina ity asany ity, fa raha tsy izany dia hanondro ny fako izy.
    ///
    /// Ny fanovana ny kaontenera voatonona amin'ity sombin-kazo ity dia mety hiteraka fametahana ny buffer-ny, izay mety hahatonga ny tondro any aminy tsy mety.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Miverina roa sahaza manta naharitra ny silaka.
    ///
    /// Ny elanelam-potoana niverina dia misokatra misokatra, izay midika fa ny teboka farany mpanondro *iray lasa* ny singa farany amin'ilay silaka.
    /// Izany,-poana silaka dia aseho amin'ny alalan'ny sahaza roa mitovy, ary ny fahasamihafana eo amin'ny roa sahaza maneho ny haben'ny ny silaka.
    ///
    /// Jereo [`as_ptr`] raha mila fampitandremana amin'ny fampiasana ireo tondro ireo.Ny tondro farany dia mitaky fitandremana fanampiny, satria tsy manondro singa mety ao amin'ilay silaka io.
    ///
    /// Ity fampiasa ity dia ilaina amin'ny fifandraisana amin'ny atsy ivelany izay mampiasa tondro roa hilazana singa maromaro ao anaty fitadidiana, toy ny mahazatra ao amin'ny C++ .
    ///
    ///
    /// Mety ilaina koa ny manamarina raha manondro singa amin'ity singa ity ny tondro iray amin'ny singa iray:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: azo antoka ny `add` eto, satria:
        //
        //   - Ireo tondro roa ireo dia ampahany amin'ny zavatra iray ihany, satria ny manondro mivadika mandalo ilay zavatra dia manisa ihany koa.
        //
        //   - Ny haben'ny ny silaka dia lehibe kokoa noho ny tsy isize::MAX oktety, araka ny voalaza eto:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Tsy misy fonosana manodidina, satria ny slices dia tsy manarona ny faran'ny adiresy.
        //
        // Jereo ny tahirin-kevitra ny pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Miverina roa mampidi-doza mutable sahaza naharitra ny silaka.
    ///
    /// Ny elanelam-potoana niverina dia misokatra misokatra, izay midika fa ny teboka farany mpanondro *iray lasa* ny singa farany amin'ilay silaka.
    /// Izany,-poana silaka dia aseho amin'ny alalan'ny sahaza roa mitovy, ary ny fahasamihafana eo amin'ny roa sahaza maneho ny haben'ny ny silaka.
    ///
    /// Jereo [`as_mut_ptr`] ny fampitandremana momba ny fampiasana ireo sahaza.
    /// Manondro ny farany dia mitaky fanampiny mitandrina, toy ny tsy manondro ny manankery singa ao amin'ny silaka.
    ///
    /// Ity fampiasa ity dia ilaina amin'ny fifandraisana amin'ny atsy ivelany izay mampiasa tondro roa hilazana singa maromaro ao anaty fitadidiana, toy ny mahazatra ao amin'ny C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SAFETY: Jereo ny as_ptr_range() etsy ambony sao misy azo antoka ny `add` eto.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ampifamadiho ny singa roa amin'ilay silaka.
    ///
    /// # Arguments
    ///
    /// * a, Ny fanondroana ny singa voalohany
    /// * b, Ny fanondroana ny singa faharoa
    ///
    /// # Panics
    ///
    /// Panics raha toa ka ivelan'ny fetra ny `a` na `b`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Tsy afaka mandray indram-bola indramina miovaova amin'ny vector iray, noho izany dia ampiasao tondro manta.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SAFETY: `pa` sy `pb` dia noforonina avy amin'ny referrer azo soloina azo antoka sy refer
        // amin'ireo singa ao amin'ilay slice ary noho izany dia azo antoka fa mitombina sy mifanaraka.
        // Mariho fa ny fidirana amin'ireo singa ao ambadiky ny `a` sy `b` dia voamarina ary ho panic rehefa ivelan'ny fetra.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Mivadika ny filaharan'ny singa ao anaty silaka, amin'ny toerany.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Fa tena kely karazana, ny olona rehetra ao amin'ny ara-dalàna mamaky lalana zara raha manao.
        // Afaka manao tsaratsara kokoa isika, raha omena load/store tsy miovaova mahomby, amin'ny alàlan'ny famoahana ny sombin-javatra lehibe kokoa ary ny famadihana ny fisoratana anarana.
        //

        // Raha ny tokony ho izy dia hanao izany ho antsika i LLVM, satria fantany tsara kokoa noho ny ataontsika raha toa ka mahomby ny vakiteny tsy mifanaraka (satria miova izany eo amin'ny kinovan'ny ARM, ohatra) sy ny haben'ny potika tsara indrindra.
        // Mampalahelo fa toy ny LLVM 4.0 (2017-05) dia esoriny fotsiny ny loop, ka mila manao izany isika.
        // (Petra-kevitra: mifamadika no manahirana satria ny lafiny azo mifanaraka fomba hafa-dia ho, raha hafahafa ny lavany-dia tsy misy fomba emitting pre-sy postludes hampiasa tanteraka-mifanaraka SIMD eo afovoany.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Ampiasao ny llvm.bswap anaty hanova u8s amin'ny usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // Famonjena, Misy zavatra maro mba hanamarinana eto:
                //
                // - Mariho fa ny `chunk` dia 4 na 8 noho ny fanamarihana etsy ambony.Noho izany dia tsara `chunk - 1`.
                // - Ny indexing miaraka amin'ny index `i` dia tsara satria manome antoka ny loop check
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Tsara ny indexing miaraka amin'ny index `ln - i - chunk = ln - (i + chunk)`:
                //   - `i + chunk > 0` marina tsy misy dikany.
                //   - Ny valin'ny loop manome antoka:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, dia toy izany no subtraction no tsy underflow.
                // - Tsara ny antso `read_unaligned` sy `write_unaligned`:
                //   - `pa` manondro ny index `i` izay `i < ln / 2 - (chunk - 1)` (jereo etsy ambony) ary `pb` manondro ny index `ln - i - chunk`, ka samy farafahakeliny `chunk` byte lavitra ny faran'ny `self`.
                //
                //   - Izay fahatsiarovana voamarina rehetra dia mitombina `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Mampiasà-by-16 hanodinana ny u16 amin'ny u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SAFETY: Ny u32 tsy misy sonia dia azo vakiana amin'ny `i` raha `i + 1 < ln`
                // (ary mazava ho azy `i < ln`), satria ny singa tsirairay dia 2 bytes ary mamaky 4 isika.
                //
                // `i + chunk - 1 < ln / 2` # mandritra ny toe-javatra
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Satria latsaky ny halava zaraina roa izy, dia tokony ho ferana.
                //
                // Izany dia midika ihany koa fa ny toe-javatra foana `0 < i + chunk <= ln` nanaja, antoka ny `pb` manondro azo ampiasaina soa aman-tsara.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: `i` dia ambany noho ny antsasaky ny halavan'ny silaka ka
            // miditra `i` sy `ln - i - 1` dia azo antoka (`i` manomboka amin'ny 0 ka tsy handeha lavitra kokoa noho ny `ln / 2 - 1`).
            // Ny teboka vokatr'izany `pa` sy `pb` dia mitombina ary mifanaraka, ary azo vakiana sy soratana.
            //
            //
            unsafe {
                // Fivarotana tsy azo antoka mba hisorohana ireo fari-tany voafetra raha tsy azo antoka.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Miverina iterator amin'ilay sombin-javatra.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Miverina iterator izay mamela ny fanovana ny sanda tsirairay.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Miverina iterator amin'ny windows rehetra mifanindry lava `size`.
    /// Ny windows mifanindry.
    /// Raha fohy kokoa noho ny `size` ny silaka, dia tsy manome sanda ilay miverina.
    ///
    /// # Panics
    ///
    /// Panics raha `size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Raha fohy kokoa noho ny `size` ny silaka:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny fiandohan'ny silaka.
    ///
    /// Ny sakana dia silaka ary tsy mifanindry.Raha tsy mizara ny halavan'ny silaka i `chunk_size`, dia tsy hanana x00X ny halavany farany.
    ///
    /// Jereo [`chunks_exact`] raha tsy mitovy amin'ity iterator ity izay mamerina ireo singa `chunk_size` marina foana, ary [`rchunks`] ho an'ilay iterator iray ihany fa manomboka amin'ny faran'ny slice.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny fiandohan'ny silaka.
    ///
    /// Ny sakana dia silaka azo ovaina, ary aza mifanindry.Raha `chunk_size` tsy hizara ny lavan'ny silaka, avy eo ny farany dia tsy manan-chunk `chunk_size` halavany.
    ///
    /// Jereo [`chunks_exact_mut`] ho an'ny variant'ity iterator ity izay mamerina ireo singa `chunk_size` marina foana, ary [`rchunks_mut`] ho an'ilay iterator iray ihany fa manomboka amin'ny faran'ny slice.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny fiandohan'ny silaka.
    ///
    /// Ny sakana dia silaka ary tsy mifanindry.
    /// Raha tsy mizara ny halavan'ny slice i `chunk_size`, dia esorina ireo singa farany hatramin'ny `chunk_size-1` ary azo alaina amin'ny asan'ny `remainder` an'ny iterator.
    ///
    ///
    /// Noho ny tsimok'aretina tsirairay misy singa `chunk_size` tena izy, ny compiler dia matetika afaka manatsara ny kaody vokariny kokoa noho ny amin'ny [`chunks`].
    ///
    /// Jereo [`chunks`] ho an'ny variant'ity iterator ity izay mamerina ny ambiny ho chunk kely kokoa, ary [`rchunks_exact`] ho iterator iray ihany fa manomboka amin'ny faran'ny slice.
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny fiandohan'ny silaka.
    ///
    /// Ny sakana dia silaka azo ovaina, ary aza mifanindry.
    /// Raha `chunk_size` tsy hizara ny lavan'ny silaka, dia ny farany ho amin'ny `chunk_size-1` singa dia ho nesorina, ary azo homarinana avy amin'ny `into_remainder` asa ny iterator.
    ///
    ///
    /// Noho ny tsimok'aretina tsirairay misy singa `chunk_size` tena izy, ny compiler dia matetika afaka manatsara ny kaody vokariny kokoa noho ny amin'ny [`chunks_mut`].
    ///
    /// Jereo [`chunks_mut`] ho an'ny variant'ity iterator ity izay mamerina ny ambiny ho chunk kely kokoa, ary [`rchunks_exact_mut`] ho iterator iray ihany fa manomboka amin'ny faran'ny slice.
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Mamaky ny silaka ho silaka: N`-singa arrays, mihevitra ho manana ho fa tsy misy ny sisa.
    ///
    ///
    /// # Safety
    ///
    /// Ity dia mety antsoina ihany rehefa
    /// - Ny silaka dia mizara tsara amin'ny sakana `N'-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: ny singa 1-singa dia tsy misy ambiny
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SAFETY: ny sakan'ny halavan'ny (6) dia maromaro amin'ny 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ireo mety ho antoka ny zavatra resahin'ny:
    /// // aoka chunks: &[[_;5]]= slice.as_chunks_unchecked()//Ny halavany dia tsy maromaro amin'ny 5 avelao hikambana:&[[_;0]]= slice.as_chunks_unchecked()//Zero-lava no tsy namela chunks
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Ny precondition-nay no tena ilaina hiantsoana an'io
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Manipy singa `new_len * N` ao anaty izahay
        // sombina singa `new_len` singa `N` maro.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Mizara roa ny silaka iray ary apetaka amin'ny `N'-element arrays, manomboka amin'ny fiandohan'ny silaka, ary ny sisa tavela miaraka amin'ny halavany ambany noho ny `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `N` dia 0. Ity fanamarinana ity dia azo inoana fa hovana ho hadisoana amin'ny fotoana manangona alohan'ny hampiorenana ity fomba ity.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SAFETY: Efa nikoropaka noho ny aotra izahay ary niantoka ny fanamboarana
        // fa ny halavan'ny subslice dia maromaro an'ny N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Mizara roa ny silaka iray ary apetaka amin'ny `N'-element arrays, manomboka amin'ny faran'ny slice, ary ny sisa tavela miaraka amin'ny halavany ambany noho ny `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `N` dia 0. Ity fanamarinana ity dia azo inoana fa hovana ho hadisoana amin'ny fotoana manangona alohan'ny hampiorenana ity fomba ity.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SAFETY: Efa nikoropaka noho ny aotra izahay ary niantoka ny fanamboarana
        // fa ny halavan'ny subslice dia maromaro an'ny N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Miverina iterator mihoatra ny singa `N` amin'ilay silaka indray mandeha, manomboka amin'ny fiandohan'ny silaka.
    ///
    /// Ireo sakana dia fanondroana andalana ary tsy mifanindry.
    /// Raha tsy mizara ny halavan'ny slice i `N`, dia esorina ireo singa farany hatramin'ny `N-1` ary azo alaina amin'ny asan'ny `remainder` an'ny iterator.
    ///
    ///
    /// Ity fomba ity dia ny generic mitovy [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics raha `N` dia 0. Ity fanamarinana ity dia azo inoana fa hovana ho hadisoana amin'ny fotoana manangona alohan'ny hampiorenana ity fomba ity.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Mamaky ny silaka ho silaka: N`-singa arrays, mihevitra ho manana ho fa tsy misy ny sisa.
    ///
    ///
    /// # Safety
    ///
    /// Ity dia mety antsoina ihany rehefa
    /// - Ny silaka dia mizara tsara amin'ny sakana `N'-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: ny singa 1-singa dia tsy misy ambiny
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SAFETY: ny sakan'ny halavan'ny (6) dia maromaro amin'ny 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ireo mety ho antoka ny zavatra resahin'ny:
    /// // avelao ny tapa-kazo: &[[_;5]]= slice.as_chunks_unchecked_mut()//Ny halavany dia tsy maromaro amin'ny 5 avelao hikambana:&[[_;0]]=Tsy avela velively ny sakana slice.as_chunks_unchecked_mut()//
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SAFETY: Ny precondition-nay no tena ilaina hiantsoana an'io
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Manipy singa `new_len * N` ao anaty izahay
        // sombina singa `new_len` singa `N` maro.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Mizara roa ny silaka iray ary apetaka amin'ny `N'-element arrays, manomboka amin'ny fiandohan'ny silaka, ary ny sisa tavela miaraka amin'ny halavany ambany noho ny `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `N` dia 0. Ity fanamarinana ity dia azo inoana fa hovana ho hadisoana amin'ny fotoana manangona alohan'ny hampiorenana ity fomba ity.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SAFETY: Efa nikoropaka noho ny aotra izahay ary niantoka ny fanamboarana
        // fa ny halavan'ny subslice dia maromaro an'ny N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Mizara roa ny silaka iray ary apetaka amin'ny `N'-element arrays, manomboka amin'ny faran'ny slice, ary ny sisa tavela miaraka amin'ny halavany ambany noho ny `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `N` dia 0. Ity fanamarinana ity dia azo inoana fa hovana ho hadisoana amin'ny fotoana manangona alohan'ny hampiorenana ity fomba ity.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SAFETY: Efa nikoropaka noho ny aotra izahay ary niantoka ny fanamboarana
        // fa ny halavan'ny subslice dia maromaro an'ny N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Miverina iterator mihoatra ny singa `N` amin'ilay silaka indray mandeha, manomboka amin'ny fiandohan'ny silaka.
    ///
    /// Ireo sakana dia fanovozan-kevitra azo ovaina ary tsy mifanindry.
    /// Raha tsy mizara ny halavan'ny slice i `N`, dia esorina ireo singa farany hatramin'ny `N-1` ary azo alaina amin'ny asan'ny `into_remainder` an'ny iterator.
    ///
    ///
    /// Ity fomba ity dia ny generic mitovy [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics raha `N` dia 0. Ity fanamarinana ity dia azo inoana fa hovana ho hadisoana amin'ny fotoana manangona alohan'ny hampiorenana ity fomba ity.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Miverina ny iterator ny takela-barahina nifanindritsindry windows ny `N` singa iray silaka, nanomboka teo am-piandohan'ny ny silaka.
    ///
    ///
    /// Ity no mitovy generika [`windows`].
    ///
    /// Raha `N` dia lehibe noho ny haben'ny ny silaka, dia hiverina tsy windows.
    ///
    /// # Panics
    ///
    /// Panics raha `N` dia 0.
    /// Ity fanamarinana ity dia azo inoana fa hovana ho lesoka ara-potoana alohan'ny hampiorenana ity fomba ity.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny faran'ny slice.
    ///
    /// Ny sakana dia silaka ary tsy mifanindry.Raha tsy mizara ny halavan'ny silaka i `chunk_size`, dia tsy hanana x00X ny halavany farany.
    ///
    /// Jereo [`rchunks_exact`] raha tsy mitovy amin'ity iterator ity izay mamerina ireo singa `chunk_size` marina foana, ary [`chunks`] ho an'ilay iterator iray ihany fa manomboka amin'ny fiandohan'ny silaka.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny faran'ny slice.
    ///
    /// Ny sakana dia silaka azo ovaina, ary aza mifanindry.Raha `chunk_size` tsy hizara ny lavan'ny silaka, avy eo ny farany dia tsy manan-chunk `chunk_size` halavany.
    ///
    /// Jereo [`rchunks_exact_mut`] raha tsy mitovy amin'ity iterator ity izay mamerina ireo singa `chunk_size` marina foana, ary [`chunks_mut`] ho an'ilay iterator iray ihany fa manomboka amin'ny fiandohan'ny silaka.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny faran'ny slice.
    ///
    /// Ny sakana dia silaka ary tsy mifanindry.
    /// Raha tsy mizara ny halavan'ny slice i `chunk_size`, dia esorina ireo singa farany hatramin'ny `chunk_size-1` ary azo alaina amin'ny asan'ny `remainder` an'ny iterator.
    ///
    /// Noho ny tsimok'aretina tsirairay misy singa `chunk_size` tena izy, ny compiler dia matetika afaka manatsara ny kaody vokariny kokoa noho ny amin'ny [`chunks`].
    ///
    /// Jereo [`rchunks`] ho an'ny variant'ity iterator ity izay mamerina ny ambiny ho chunk kely kokoa, ary [`chunks_exact`] ho iterator iray ihany fa manomboka amin'ny fiandohan'ny silaka.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Miverina iterator mihoatra ny singa `chunk_size` amin'ilay silaka indray mandeha, manomboka amin'ny faran'ny slice.
    ///
    /// Ny sakana dia silaka azo ovaina, ary aza mifanindry.
    /// Raha `chunk_size` tsy hizara ny lavan'ny silaka, dia ny farany ho amin'ny `chunk_size-1` singa dia ho nesorina, ary azo homarinana avy amin'ny `into_remainder` asa ny iterator.
    ///
    /// Noho ny tsimok'aretina tsirairay misy singa `chunk_size` tena izy, ny compiler dia matetika afaka manatsara ny kaody vokariny kokoa noho ny amin'ny [`chunks_mut`].
    ///
    /// Jereo [`rchunks_mut`] ho an'ny variant'ity iterator ity izay mamerina ny ambiny ho chunk kely kokoa, ary [`chunks_exact_mut`] ho iterator iray ihany fa manomboka amin'ny fiandohan'ny silaka.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `chunk_size` dia 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Miverina iterator amin'ilay sombin-javatra mamokatra singa tsy mihozongozona amin'ny alàlan'ny predicate mba hampisaraka azy ireo.
    ///
    /// Ny predicate dia antsoina amin'ny singa roa manaraka ny tenany, midika izany fa ny predicate dia antsoina amin'ny `slice[0]` sy `slice[1]` avy eo amin'ny `slice[1]` sy `slice[2]` sns.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ity fomba ity dia azo ampiasaina hamoahana ireo lozisialy voalahatra:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Miverina iterator amin'ilay sombin-javatra mamokatra singa tsy azo ovaina miovaova amin'ny alàlan'ny predicate mba hampisaraka azy ireo.
    ///
    /// Ny predicate dia antsoina amin'ny singa roa manaraka ny tenany, midika izany fa ny predicate dia antsoina amin'ny `slice[0]` sy `slice[1]` avy eo amin'ny `slice[1]` sy `slice[2]` sns.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ity fomba ity dia azo ampiasaina hamoahana ireo lozisialy voalahatra:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Mizara roa ny silaka iray amin'ny index.
    ///
    /// Ny voalohany dia ahitana ny indices rehetra avy amin'ny `[0, mid)` (tsy manilika ny index `mid` mihitsy) ary ny faharoa kosa dia ahitana ny indices rehetra avy amin'ny `[mid, len)` (tsy manilika ny index `len` mihitsy).
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` sy `[mid; len]` dia ao anatin'ny `self`, izay
        // mahafeno ny fepetra takiana amin'ny `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Mizara fizarana miovaova iray ho roa amin'ny index.
    ///
    /// Ny voalohany dia ahitana ny indices rehetra avy amin'ny `[0, mid)` (tsy manilika ny index `mid` mihitsy) ary ny faharoa kosa dia ahitana ny indices rehetra avy amin'ny `[mid, len)` (tsy manilika ny index `len` mihitsy).
    ///
    ///
    /// # Panics
    ///
    /// Panics raha `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` sy `[mid; len]` dia ao anatin'ny `self`, izay
        // mahafeno ny fepetra takiana amin'ny `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Mizara roa ny silaka iray amin'ny index, nefa tsy manao fizahana fetra.
    ///
    /// Ny voalohany dia ahitana ny indices rehetra avy amin'ny `[0, mid)` (tsy manilika ny index `mid` mihitsy) ary ny faharoa kosa dia ahitana ny indices rehetra avy amin'ny `[mid, len)` (tsy manilika ny index `len` mihitsy).
    ///
    ///
    /// Raha mila safidy azo antoka dia jereo ny [`split_at`].
    ///
    /// # Safety
    ///
    /// Miantso fomba ity miaraka amin'ny avy-of-fetra fanondroana dia *[tsy voafaritra fitondran-tena]* na dia ny vokatry ny boky dia tsy ampiasaina.Ny miantso dia tsy maintsy miantoka fa `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SAFETY: Ny mpiantso dia mila manamarina an'io `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Mutable silaka iray mizara ho roa tao amin'ny Fanondroana, tsy manao fetra mijery.
    ///
    /// Ny voalohany dia ahitana ny indices rehetra avy amin'ny `[0, mid)` (tsy manilika ny index `mid` mihitsy) ary ny faharoa kosa dia ahitana ny indices rehetra avy amin'ny `[mid, len)` (tsy manilika ny index `len` mihitsy).
    ///
    ///
    /// Raha mila safidy azo antoka dia jereo ny [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Miantso fomba ity miaraka amin'ny avy-of-fetra fanondroana dia *[tsy voafaritra fitondran-tena]* na dia ny vokatry ny boky dia tsy ampiasaina.Ny miantso dia tsy maintsy miantoka fa `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SAFETY: Ny mpiantso dia mila manamarina an'io `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ary `[mid; len]` dia tsy takela-barahina nifanindritsindry, ka miverina ny mutable boky tsara.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Miverina iterator amin'ny lozisialy nosarahan'ny singa mifanaraka amin'ny `pred`.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Raha ampifandraisina ny singa voalohany dia ny sombin-javatra tsy misy no ho voalohany averin'ny iterator.
    /// Toy izany koa, raha ampifandraisina ny singa farany amin'ilay sombin-kazo, ny silaka poakaty no entana farany haverin'ilay iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Raha singa mifanentana roa mifanila mivantana, dia misy slice foana eo anelanelany:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Miverina iterator amin'ny lozisialy azo ovaina nosarahan'ny singa mifanaraka amin'ny `pred`.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Miverina iterator amin'ny lozisialy nosarahan'ny singa mifanaraka amin'ny `pred`.
    /// Ny mifanentana singa misy teny ao amin'ny faran'ny subslice teo aloha toy ny Rakoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Raha mifanaraka ny singa farany amin'ilay sombin-kazo dia heverina ho mpamarana ilay sombin-kazo teo aloha io singa io.
    ///
    /// Ity sombin-javatra ity no entana farany haverin'ilay miverina.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Miverina iterator amin'ny lozisialy azo ovaina nosarahan'ny singa mifanaraka amin'ny `pred`.
    /// Ny singa mifanaraka dia voarakitra ao amin'ilay subslice teo aloha ho terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Miverina iteratera amin'ny lozisialy nosarahan'ny singa mifanandrify amin'ny `pred`, manomboka amin'ny faran'ny sombin-kazo sy miasa mihemotra.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Toy ny `split()`, raha ny voalohany na ny farany singa dia mifanentana, silaka-poana no ho voalohany (na ny farany) zavatra niverina ny iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Miverina ny iterator ny mutable subslices nampisaraka ny singa izay mifanaraka `pred`, manomboka amin'ny faran'ny ny silaka sy miasa nihemotra.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Miverina iterator amin'ny lozisialy nosarahan'ny singa mifanaraka amin'ny `pred`, voafetra amin'ny fiverenana amin'ny ankamaroan'ny entana `n`.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// Niverina ny singa farany, raha misy, dia ahitana ny ambiny amin'ilay silaka.
    ///
    /// # Examples
    ///
    /// Ataovy pirinty ny sombin-tsinjara indray mandeha amin'ny isa zarazarain'ny 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Miverina iterator amin'ny lozisialy nosarahan'ny singa mifanaraka amin'ny `pred`, voafetra amin'ny fiverenana amin'ny ankamaroan'ny entana `n`.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// Niverina ny singa farany, raha misy, dia ahitana ny ambiny amin'ilay silaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Miverina iterator amin'ny lozisialy nosarahan'ny singa izay mifanaraka amin'ny `pred` voafetra amin'ny fiverenana amin'ny ankamaroan'ny entana `n`.
    /// Izany manomboka any amin'ny faran'ny ny silaka sy ny asa nihemotra.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// Niverina ny singa farany, raha misy, dia ahitana ny ambiny amin'ilay silaka.
    ///
    /// # Examples
    ///
    /// Ataovy pirinty indray mandeha ny fizarana, manomboka amin'ny farany, amin'ny isa zarazaraina ho 3 (izany hoe, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Miverina iterator amin'ny lozisialy nosarahan'ny singa izay mifanaraka amin'ny `pred` voafetra amin'ny fiverenana amin'ny ankamaroan'ny entana `n`.
    /// Izany manomboka any amin'ny faran'ny ny silaka sy ny asa nihemotra.
    /// Ny singa nifanaraka dia tsy hita ao amin'ireo fisoratana anarana.
    ///
    /// Niverina ny singa farany, raha misy, dia ahitana ny ambiny amin'ilay silaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Miverina `true` raha misy sombin-tsakafo miaraka amin'ilay sanda nomena.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Raha toa ka tsy manana `&T`, fa fotsiny `&U` izany fa `T: Borrow<U>` (oh
    /// `String: Borrow<str>`), azonao atao ny mampiasa `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // silaka `String`
    /// assert!(v.iter().any(|e| e == "hello")); // karohy amin'ny `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Miverina `true` raha `needle` dia aloan'ny silaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Miverina hatrany `true` raha dia foana `needle` silaka:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Miverina `true` raha `needle` dia tovana ny silaka.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Miverina hatrany `true` raha dia foana `needle` silaka:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Miverina ny subslice amin'ny tovona nesorina.
    ///
    /// Raha manomboka amin'ny `prefix` ny sombin-kazo dia avereno averina aorinan'ilay fisoratana anarana ny fonosana, aforeto amin'ny `Some`.
    /// Raha foana ny `prefix` dia avereno fotsiny ilay silaka tany am-boalohany.
    ///
    /// Raha tsy ny silaka manomboka amin'ny `prefix`, miverina `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ity fanatanterahana ity dia mila fanoratana indray raha toa ka oviana no lasa sophisticated kokoa ny SlicePattern.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Miverina subslice rehefa esorina ny tovana.
    ///
    /// Raha mifarana amin'ny `suffix` ny silaka dia avereno ny subslice alohan'ny tovana, fonosina `Some`.
    /// Raha foana ny `suffix` dia avereno fotsiny ilay silaka tany am-boalohany.
    ///
    /// Raha tsy mifarana amin'ny `suffix` ny silaka dia avereno `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ity fanatanterahana ity dia mila fanoratana indray raha toa ka oviana no lasa sophisticated kokoa ny SlicePattern.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary dia mitady an'io singa voasokajy io.
    ///
    /// Raha hita ny sanda dia miverina [`Result::Ok`], misy ny index an'ny singa mifangaro.
    /// Raha misy lalao maromaro, dia azo averina ny iray amin'ireo lalao.
    /// Raha tsy hita ny sanda dia averina [`Result::Err`], misy ny index izay azo ampidirina singa mifangaro raha mitazona ny filaharana milahatra.
    ///
    ///
    /// Jereo ihany koa [`binary_search_by`], [`binary_search_by_key`], ary [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Mitady andiana singa efatra.
    /// Ny voalohany dia hita, miaraka amina toerana voafaritra tokana;ny faharoa sy ny fahatelo tsy hita;ny fahefatra afaka mifanaraka misy toerana any `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Raha te hampiditra entana amina vector voasokajy ianao, raha mitazona ny filaharana:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Fikarohana mimari-droa nandamina izany silaka amin'ny comparator asany.
    ///
    /// Ny asa comparator dia tokony hametraka didy mifanaraka amin'ny karazana lamin 'ny fototra silaka, niverina ny mba fehezan-dalàna izay mampiseho na ny tohan-kevitra dia `Less`, `Equal` na `Greater` ny tiany kendrena.
    ///
    ///
    /// Raha hita ny sanda dia miverina [`Result::Ok`], misy ny index an'ny singa mifangaro.Raha misy lalao maromaro, dia azo averina ny iray amin'ireo lalao.
    /// Raha tsy hita ny sanda dia averina [`Result::Err`], misy ny index izay azo ampidirina singa mifangaro raha mitazona ny filaharana milahatra.
    ///
    /// Jereo ihany koa [`binary_search`], [`binary_search_by_key`], ary [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Mitady andiana singa efatra.Ny voalohany dia hita, miaraka amina toerana voafaritra tokana;ny faharoa sy ny fahatelo tsy hita;ny fahefatra dia afaka mifanaraka amin'ny toerana rehetra ao amin'ny `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // Famonjena, ny antso atao soa aman-tsara ny manaraka invariants:
            // - `mid >= 0`
            // - `mid < size`: `mid` dia voafetran'ny `[left; right)` voafatotra.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Ny antony ampiasantsika ny fifehezana if/else fa tsy ny lalao dia satria ny lalao fampitahana dia manitsy ny fampitahana, izay saro-pady.
            //
            // Ity dia x86 asm ho an'ny u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary dia mitady an'io voahitsaka voasokajy io miaraka amina laharam-pahamehana fanesorana.
    ///
    /// Nihevitra fa ny silaka dia nandamina ny fanalahidy, ohatra amin'i [`sort_by_key`] mampiasa ny asa fitrandrahana manan-danja toy izany koa.
    ///
    /// Raha hita ny sanda dia miverina [`Result::Ok`], misy ny index an'ny singa mifangaro.
    /// Raha misy lalao maromaro, dia azo averina ny iray amin'ireo lalao.
    /// Raha tsy hita ny sanda dia averina [`Result::Err`], misy ny index izay azo ampidirina singa mifangaro raha mitazona ny filaharana milahatra.
    ///
    ///
    /// Jereo ihany koa [`binary_search`], [`binary_search_by`], ary [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Jereo ny andiana singa efatra amin'ny tapa-tsiroaroa voasokajy araka ny singa faharoa.
    /// Ny voalohany dia hita, miaraka amina toerana voafaritra tokana;ny faharoa sy ny fahatelo tsy hita;ny fahefatra afaka mifanaraka misy toerana any `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links avela satria `slice::sort_by_key` dia ao amin'ny crate `alloc`, ary mbola tsy misy toy izany rehefa manangana `core`.
    //
    // rohy mankany amin'ny crate ambany: #74481.Satria ny primitives dia tsy voasoratra afa-tsy amin'ny libstd (#73423), izany dia tsy mitarika rohy tapaka mihitsy amin'ny fampiharana.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sivanina ny silaka, fa mety tsy hitahiry ny filaharan'ny singa mitovy.
    ///
    /// Izao, miovaova (izany hoe, mety reorder singa mitovy), in-toerana (izany hoe, tsy zarao), ary ry *(* n *\* log(*n*))-raharaha ratsy.
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm amin'izao fotoana izao dia mifototra amin'ny [pattern-defeating quicksort][pdqsort] avy amin'i Orson Peters, izay manambatra ny tranga antonony haingana ny quicksort randomized sy ny tranga ratsy indrindra amin'ny heapsort, raha toa ka mahatratra ny fotoana maharitra amin'ny sombin-kazo miaraka amina lamina sasany.
    /// Mampiasa randomisation kely izy hialana amin'ny tranga mihasimba, fa miaraka amin'ny seed raikitra mba hanomezana fitondran-tena maharitra.
    ///
    /// Matetika izy io dia haingana kokoa noho ny filaharana milamina, afa-tsy amin'ny tranga manokana vitsivitsy, ohatra, rehefa misy ny filaharana maromaro mifangaro mifangaro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Isan-karazany ny silaka amin'ny comparator asa, fa tsy hiaro ny lamin 'mitovy singa.
    ///
    /// Izao, miovaova (izany hoe, mety reorder singa mitovy), in-toerana (izany hoe, tsy zarao), ary ry *(* n *\* log(*n*))-raharaha ratsy.
    ///
    /// Ny fampitahana dia tsy maintsy mamaritra famaritana tanteraka ho an'ny singa ao amin'ilay silaka.Raha tsy feno ny fandefasana dia tsy voafaritra mazava ny filaharan'ireo singa.Ny kaonty dia baiko iray manontolo raha (ho an'ny `a`, `b` ary `c` rehetra):
    ///
    /// * total sy antisymmetric: marina ny iray amin'ny `a < b`, `a == b` na `a > b` dia marina, ary
    /// * transitive, `a < b` ary `b < c` dia midika `a < c`.Ny mitovy dia tsy maintsy mihazona ho an'ny `==` sy `>`.
    ///
    /// Ohatra, na dia tsy mampihatra [`Ord`] aza i [`f64`] satria `NaN != NaN`, azontsika atao ny mampiasa `partial_cmp` ho toy ny lahasa fanaovan-tsika rehefa fantatsika fa tsy misy `NaN` ilay sombina.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm amin'izao fotoana izao dia mifototra amin'ny [pattern-defeating quicksort][pdqsort] avy amin'i Orson Peters, izay manambatra ny tranga antonony haingana ny quicksort randomized sy ny tranga ratsy indrindra amin'ny heapsort, raha toa ka mahatratra ny fotoana maharitra amin'ny sombin-kazo miaraka amina lamina sasany.
    /// Mampiasa randomisation kely izy hialana amin'ny tranga mihasimba, fa miaraka amin'ny seed raikitra mba hanomezana fitondran-tena maharitra.
    ///
    /// Matetika izy io dia haingana kokoa noho ny filaharana milamina, afa-tsy amin'ny tranga manokana vitsivitsy, ohatra, rehefa misy ny filaharana maromaro mifangaro mifangaro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // fanasokajiana
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Isan-karazany ny silaka manan-danja amin'ny asa fitrandrahana, fa tsy hiaro ny lamin 'mitovy singa.
    ///
    /// Ity karazana ity dia milamina (ie, mety handamina indray ny singa mitovy), eo amin'ny toerany (ie, tsy mizara), ary *O*(m\* * n *\* log(*n*)) tranga ratsy indrindra, izay *O*(*M*).
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm amin'izao fotoana izao dia mifototra amin'ny [pattern-defeating quicksort][pdqsort] avy amin'i Orson Peters, izay manambatra ny tranga antonony haingana ny quicksort randomized sy ny tranga ratsy indrindra amin'ny heapsort, raha toa ka mahatratra ny fotoana maharitra amin'ny sombin-kazo miaraka amina lamina sasany.
    /// Mampiasa randomisation kely izy hialana amin'ny tranga mihasimba, fa miaraka amin'ny seed raikitra mba hanomezana fitondran-tena maharitra.
    ///
    /// Noho ny antso manan-danja paikady, [`sort_unstable_by_key`](#method.sort_unstable_by_key) dia mety ho miadana kokoa noho ny [`sort_by_cached_key`](#method.sort_by_cached_key) in tranga manan-danja izay ny asany dia lafo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Alaharo indray ny silaka ka ny singa ao amin'ny `index` dia eo amin'ny toerana voalahatra farany.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Alamino indray ny sombin-kazo miaraka amina asa fampitahana ka ny singa ao amin'ny `index` dia eo amin'ny toerana voalahatra farany.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Alamino indray ny sombin-kazo miaraka amina laharam-pahamehana fanesorana ka ny singa ao amin'ny `index` dia eo amin'ny toerana voalahatra farany.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Alaharo indray ny silaka ka ny singa ao amin'ny `index` dia eo amin'ny toerana voalahatra farany.
    ///
    /// Ity fanitsiana ity dia manana fananana fanampiny izay soatoavina amin'ny toerana `i < index` dia ambany na mitovy amin'ny sanda rehetra amin'ny laharana `j > index`.
    /// Ankoatra izany, io reordering, miovaova (izany hoe
    /// ny isan'ny singa mitovy dia mety hiafara amin'ny toerana `index`), eo amin'ny toerany (ie
    /// tsy mizara), ary tranga *O*(*n*) ratsy indrindra.
    /// Izany asa ihany koa/fantatra amin'ny anarana hoe "kth element" ao amin'ny tranomboky hafa.
    /// Miverina telo heny amin'ireto soatoavina manaraka ireto: ny singa rehetra latsaky ny iray amin'ilay nomeraon'isa nomena, ny sanda amin'ny fanondroana nomena, ary ny singa rehetra lehibe kokoa noho ilay ao amin'ny atiny nomena.
    ///
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm ankehitriny dia mifototra amin'ny ampaham-pifidianana haingana an'ilay algorithm quicksort izay ampiasaina amin'ny [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics rehefa `index >= len()`, midika izany fa panics foana amin'ny silaka foana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Tadiavo ny medianina
    /// v.select_nth_unstable(2);
    ///
    /// // Isika ihany no antoka ny silaka dia ho iray amin'ireo manaraka, miorina amin'ny fomba karazana mikasika ny lasa mihamatanjaka ny tondro.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Alamino indray ny sombin-kazo miaraka amina asa fampitahana ka ny singa ao amin'ny `index` dia eo amin'ny toerana voalahatra farany.
    ///
    /// Ity reordering fanampiny manana ny fananana fa ny zava-dehibe amin'ny toerana `i < index` dia ho latsaka na mitovy amin'ny zava-dehibe rehetra tao amin'ny toerana `j > index` mampiasa ny comparator asa.
    /// Fanampin'izany, tsy milamina io famerenana ity (ie mety misy singa mitovy mitovy amin'ny faran'ny `index`), eo an-toerana (izany hoe tsy mizara), ary ny tranga O *(* n *) ratsy indrindra.
    /// Ity fiasa ity dia fantatra amin'ny anarana hoe "kth element" amin'ny tranomboky hafa.
    /// Miverina telo heny amin'ireto soatoavina manaraka ireto: ny singa rehetra latsaky ny iray amin'ny nomeraon-tsoratra nomena, ny sanda amin'ny index nomena, ary ny singa rehetra lehibe kokoa noho ny iray amin'ny index nomena, amin'ny fampiasana ny asan'ny mpampitaha.
    ///
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm ankehitriny dia mifototra amin'ny ampaham-pifidianana haingana an'ilay algorithm quicksort izay ampiasaina amin'ny [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics rehefa `index >= len()`, midika izany fa panics foana amin'ny silaka foana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Tadiavo ny mediana toy ny hoe namboarina araka ny filaharana nidina ilay silaka.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Isika ihany no antoka ny silaka dia ho iray amin'ireo manaraka, miorina amin'ny fomba karazana mikasika ny lasa mihamatanjaka ny tondro.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Alamino indray ny sombin-kazo miaraka amina laharam-pahamehana fanesorana ka ny singa ao amin'ny `index` dia eo amin'ny toerana voalahatra farany.
    ///
    /// Ity fanitsiana ity dia manana fananana fanampiny izay soatoavina amin'ny toerana `i < index` dia ho latsaka na mitovy amin'ny sanda amin'ny toerana `j > index` mampiasa ny fitrandrahana tena ilaina.
    /// Fanampin'izany, tsy milamina io famerenana ity (ie mety misy singa mitovy mitovy amin'ny faran'ny `index`), eo an-toerana (izany hoe tsy mizara), ary ny tranga O *(* n *) ratsy indrindra.
    /// Ity fiasa ity dia fantatra amin'ny anarana hoe "kth element" amin'ny tranomboky hafa.
    /// Miverina telo heny amin'ireto soatoavina manaraka ireto: ny singa rehetra latsaky ny iray amin'ilay nomeraon-tsoratra nomena, ny sanda amin'ny fanondroana nomena, ary ny singa rehetra lehibe kokoa noho ny iray tamin'ny nomena nomena, amin'ny alàlan'ny fampiasana fitrandrahana lehibe.
    ///
    ///
    /// # Fanatanterahana ankehitriny
    ///
    /// Ny algorithm ankehitriny dia mifototra amin'ny ampaham-pifidianana haingana an'ilay algorithm quicksort izay ampiasaina amin'ny [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics rehefa `index >= len()`, midika izany fa panics foana amin'ny silaka foana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Miverena ny medianina toy ny fihaingoana no nandamina tanteraka araka ny vidiny.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Isika ihany no antoka ny silaka dia ho iray amin'ireo manaraka, miorina amin'ny fomba karazana mikasika ny lasa mihamatanjaka ny tondro.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Mamindra ny singa miverimberina miverimberina hatrany amin'ny faran'ny slice araka ny fampiharana [`PartialEq`] trait.
    ///
    ///
    /// Miverina silaka roa.Ny voalohany dia tsy misy singa miverimberina.
    /// Ny faharoa dia misy ny duplicate rehetra tsy misy filaharana voafaritra.
    ///
    /// Raha namboarina ny silaka dia tsy misy duplicate ilay sombin-kaverina voalohany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Mamindra ny rehetra, afa-tsy ny singa voalohany nisesy hatramin'ny faran'ny slice izay nahafa-po ny fifandraisana misy fitoviana.
    ///
    /// Miverina silaka roa.Ny voalohany dia tsy misy singa miverimberina.
    /// Ny faharoa dia misy ny duplicate rehetra tsy misy filaharana voafaritra.
    ///
    /// Ny asan'ny `same_bucket` dia ampitaina amin'ny singa roa avy amin'ilay sombin-kazo ary tsy maintsy mamaritra raha toa ka mitovy ny singa.
    /// Ireo singa dia ampitaina amin'ny filaharana mifanohitra amin'ny filaharany ao anaty silaka, ka raha miverina `true` i `same_bucket(a, b)` dia afindra amin'ny faran'ny tapany ny `a`.
    ///
    ///
    /// Raha namboarina ny silaka dia tsy misy duplicate ilay sombin-kaverina voalohany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Na dia manana referable miovaova amin'ny `self` aza izahay dia tsy afaka manova fanovana *arbitrary*.Ny antso `same_bucket` dia mety panic, noho izany dia tsy maintsy ataontsika antoka fa ny sombin-javatra dia amin'ny fanjakana manan-kery foana.
        //
        // Ny fomba itondrantsika azy dia amin'ny alàlan'ny fampiasana swap;Izahay dia mandinika ireo singa rehetra, mifanakalo rehefa mandeha, ka eo am-piandohana ireo singa tadiavinay hitazomana, ary ireo izay tianay holavina dia ao aorian'izay.
        // Afaka namaky ny silaka avy eo.
        // Ity hetsika ity dia mbola `O(n)`.
        //
        // Ohatra: Manomboka amin'ity fanjakana ity isika, izay anehoan'ny `r` ny "manaraka
        // vakio "ary `w` maneho" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Mampitaha ny self[r] amin'ny tena [w-1], tsy duplicate io, noho izany dia mifanakalo self[r] sy self[w] (tsy misy vokany toy ny r==w) ary avy eo mampitombo ny r sy ny w, mamela anay:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Mampitaha ny self[r] amin'ny tena [w-1], ity sanda ity dia duplicate, noho izany dia mampitombo ny `r` izahay fa mamela ny zavatra hafa rehetra tsy miova:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Mampitaha self[r] manohitra tena [W-1], tsy mitovy tsy misy valaka, ka swap self[r] sy self[w] sy mialoha R sy w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Tsy mitovy tsy misy valaka, avereno:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Atao avo roa heny, advance r. End an'ny silaka.Misaraka amin'ny w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAFETY: ny fepetra `while` dia manome antoka ny `next_read` sy `next_write`
        // dia latsaky ny `len`, dia toy izany no ao `self`.
        // `prev_ptr_write` manondro singa iray alohan'ny `ptr_write`, fa ny `next_write` dia manomboka amin'ny 1, ka `prev_ptr_write` dia tsy latsaky ny 0 mihitsy ary ao anatin'ilay sombin-kazo.
        // Izany dia mahafeno ny fepetra takiana amin'ny fanesorana ny `ptr_read`, `prev_ptr_write` ary `ptr_write`, ary ny fampiasana `ptr.add(next_read)`, `ptr.add(next_write - 1)` ary `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` koa dia nampitomboina farafahakeliny indray mandeha isaky ny tadiny, izay midika indrindra fa tsy misy singa tsy voailikilika rehefa mety mila soloina.
        //
        // `ptr_read` ary `prev_ptr_write` dia tsy manondro singa mitovy mihitsy.Takiana izany raha te-ho azo antoka ny `&mut *ptr_read`, `&mut* prev_ptr_write`.
        // Ny fanazavana dia tsotra fa `next_read >= next_write` dia marina foana, dia toy izany koa `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Aza atao fanaraha-maso fetra amin'ny alàlan'ny fampiasana tondro manta.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Hetsika rehetra, afa-tsy ny voalohany ny singa nisesy hatramin 'ny farany ny silaka izay tapa-kevitra ny fanalahidy iray ihany.
    ///
    ///
    /// Miverina silaka roa.Ny voalohany dia tsy misy singa miverimberina.
    /// Ny faharoa dia misy ny duplicate rehetra tsy misy filaharana voafaritra.
    ///
    /// Raha namboarina ny silaka dia tsy misy duplicate ilay sombin-kaverina voalohany.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Ahodina ny silaka eo amin'ny toerany ka ny singa `mid` voalohany amin'ilay silaka dia mihetsika hatramin'ny farany raha ny singa `self.len() - mid` farany kosa mihetsika mankany aloha.
    /// Rehefa avy niantso `rotate_left`, ny singa amin'ny fanondroana `mid` teo aloha ho tonga ny singa voalohany ao amin'ny silaka.
    ///
    /// # Panics
    ///
    /// Ity asa ity dia panic raha toa ka lehibe kokoa noho ny halavan'ny slice ny `mid`.Mariho fa `mid == self.len()` dia manao _not_ panic ary fihodinana no-op.
    ///
    /// # Complexity
    ///
    /// Maka linear (amin'ny fotoana `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Miodina ny subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // Famonjena, ny isan-karazany dia trivially `[p.add(mid) - mid, p.add(mid) + k)`
        // manan-kery amin'ny famakiana sy ny fanoratana, araka ny takian'i `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ahodina ny silaka eo amin'ny toerany ka ny singa `self.len() - k` voalohany amin'ilay silaka dia mihetsika hatramin'ny farany raha ny singa `k` farany kosa mihetsika mankany aloha.
    /// Aorian'ny fiantsoana ny `rotate_right`, ny singa teo aloha tamin'ny index `self.len() - k` dia ho lasa singa voalohany ao amin'ilay silaka.
    ///
    /// # Panics
    ///
    /// Ity asa ity dia panic raha toa ka lehibe kokoa noho ny halavan'ny slice ny `k`.Mariho fa `k == self.len()` no _not_ panic sady toy ny tsy fihodinan'ny-OP.
    ///
    /// # Complexity
    ///
    /// Maka linear (amin'ny fotoana `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Ahodino subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // Famonjena, ny isan-karazany dia trivially `[p.add(mid) - mid, p.add(mid) + k)`
        // manan-kery amin'ny famakiana sy ny fanoratana, araka ny takian'i `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Fenoy ny `self` amin'ny singa amin'ny alàlan'ny cloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Fenoy `self` miaraka amin'ireo singa niverina tamin'ny fiantsoana fanakatonana miverimberina.
    ///
    /// Mampiasa fomba iray ity mba hamoronana fanakatonana soatoavina vaovao.Raha aleonao [`Clone`] sanda nomena dia ampiasao [`fill`].
    /// Raha te hampiasa ny [`Default`] trait ianao hiteraka soatoavina dia azonao atao ny mandingana ny [`Default::default`] ho toy ny adihevitra.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Dika mitovy ny singa avy amin'ny `src` ho any `self`.
    ///
    /// Ny halavan'ny `src` dia tsy maintsy mitovy amin'ny `self`.
    ///
    /// Raha mampihatra `Copy` i `T`, dia azo atao kokoa ny mampiasa [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Izany no asa panic raha ny roa slices manana halava samy hafa.
    ///
    /// # Examples
    ///
    /// Fandefasana singa roa avy amin'ny silaka ho iray hafa:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Satria tsy maintsy hitovy ny halavany, dia tapahinay ny singa avy amin'ny singa efatra ka hatramin'ny roa.
    /// // panic izany raha tsy ataontsika izany.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust dia manamafy fa tsy misy afa-tsy rujukan iray azo ovaina ary tsy misy fanondroana tsy azo ovaina amin'ny sombin-data iray manokana ao anaty sehatra iray manokana.
    /// Noho io antony io, ny fanandramana hampiasa `clone_from_slice` amin'ny tapa-tokana dia hiteraka tsy fahombiazan'ny fanangonana:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// To ny asa manodidina izany, dia afaka mampiasa mba hamoronana [`split_at_mut`] roa miavaka tsara sub-slices avy amin'ny silaka:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Dika mitovy ny singa avy amin'ny `src` ho any `self`, mampiasa ny memcpy.
    ///
    /// Ny halavan'ny `src` dia tsy maintsy mitovy amin'ny `self`.
    ///
    /// Raha tsy mampihatra `Copy` ny `T` dia ampiasao [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Izany no asa panic raha ny roa slices manana halava samy hafa.
    ///
    /// # Examples
    ///
    /// Mandika singa roa avy amin'ny silaka ho iray hafa:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Satria tsy maintsy hitovy ny halavany, dia tapahinay ny singa avy amin'ny singa efatra ka hatramin'ny roa.
    /// // panic izany raha tsy ataontsika izany.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust dia manamafy fa tsy misy afa-tsy rujukan iray azo ovaina ary tsy misy fanondroana tsy azo ovaina amin'ny sombin-data iray manokana ao anaty sehatra iray manokana.
    /// Noho io antony io, ny fanandramana hampiasa `copy_from_slice` amin'ny tapa-tokana dia hiteraka tsy fahombiazan'ny fanangonana:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// To ny asa manodidina izany, dia afaka mampiasa mba hamoronana [`split_at_mut`] roa miavaka tsara sub-slices avy amin'ny silaka:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Ny lalan'ny kaody panic dia napetraka tamina lahasa mangatsiaka mba tsy hamontsina ny tranokalan'ny antso.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SAFETY: `self` dia manan-kery ho an'ny singa `self.len()` amin'ny famaritana, ary `src` dia
        // teny mba mitovy ny lavany.
        // Ireo silaka dia tsy afaka mifampitohy satria tsy azo ovaina ireo andinin-tsoratra miova.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Mandika singa avy amin'ny faritra iray amin'ilay slice mankany amin'ny faritra hafa ao aminy, amin'ny alàlan'ny memmove.
    ///
    /// `src` dia ny elanelana ao anatin'ny `self` maka tahaka.
    /// `dest` no index fanombohana ny elanelana ao anatin'ny `self` handika, izay hanana ny halavany mitovy amin'ny `src`.
    /// Mety hifanindry ireo elanelam-potoana roa.
    /// Ny faran 'ny tandavan-roa dia tsy maintsy ho latsaka na mitovy amin'ny `self.len()`.
    ///
    /// # Panics
    ///
    /// Izany asa na dia panic raha isan-karazany mihoatra ny faran'ny silaka, na raha ny faran'ny `src` eo anatrehan'i fanombohan'ny.
    ///
    ///
    /// # Examples
    ///
    /// Maka tahaka ny byte efatra ao anaty slice:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: ny fepetra momba ny `ptr::copy` dia voamarina etsy ambony daholo,
        // toy ireo ho an'ny `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Ampifamadiho ny singa rehetra amin'ny `self` amin'ireo ao amin'ny `other`.
    ///
    /// Ny halavan'ny `other` dia tsy maintsy mitovy amin'ny `self`.
    ///
    /// # Panics
    ///
    /// Izany no asa panic raha ny roa slices manana halava samy hafa.
    ///
    /// # Example
    ///
    /// Mampifamadika singa roa amin'ny slices:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust dia manamafy fa tsy misy afa-tsy fanondro iray azo ovaina amin'ny sombin-data iray amin'ny sehatra iray manokana.
    ///
    /// Noho io antony io, ny fanandramana hampiasa `swap_with_slice` amin'ny tapa-tokana dia hiteraka tsy fahombiazan'ny fanangonana:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// To ny asa manodidina izany, dia afaka mampiasa mba hamoronana [`split_at_mut`] roa miavaka tsara mutable sub-slices avy amin'ny silaka:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SAFETY: `self` dia manan-kery ho an'ny singa `self.len()` amin'ny famaritana, ary `src` dia
        // teny mba mitovy ny lavany.
        // Ireo silaka dia tsy afaka mifampitohy satria tsy azo ovaina ireo andinin-tsoratra miova.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Function mba hikajiana ny halavan'ny tapany afovoany sy ny lalana mankany `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ny zavatra hataontsika momba ny `rest` dia ny mamantatra hoe iza amin'ny `U azontsika apetraka amin'ny isa ambany indrindra amin'ny" T.
        //
        // Ary firy ny `T ilaintsika ho an'ny "multiple" toy izany.
        //
        // Diniho ohatra T=u8 U=u16.Avy eo isika dia afaka mametraka 1 U amin'ny 2 Ts.Tsotra.
        // Ankehitriny, Diniho ohatra ny tranga izay size_of: :<T>=16, size_of::<U>=24.</u>
        // Azontsika atao ny mametraka ny 2 Us ho solon'ny isaky ny 3 Ts ao amin'ilay slice `rest`.
        // Somary sarotra kokoa.
        //
        // Ny paikady hikajiana an'io dia:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Nitarina sy notsorina:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Soa ihany fa voamarina tsy tapaka izany rehetra izany ... tsy zava-dehibe ny fampisehoana eto!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative ny algorithm Stein mbola tokony hanao izany `const fn` (ary hiverina ho recursive algorithm raha manao), satria miantehitra amin'ny llvm ny consteval ... izany rehetra izany dia tsara, dia mahatonga ahy tsy mahazo aina.
            //
            //

            // Famonjena, `a` sy `b` no teny ho tsy aotra soatoavina.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // esory ny lafin-javatra rehetra an'ny 2 amin'ny b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SAFETY: `b` dia voamarina fa tsy aotra.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Nitondra izany fahalalana izany isika dia afaka mahita ny fomba maro: U`s azontsika antonona!
        let us_len = self.len() / ts * us;
        // Ary firy: T`s no ho ao amin'ny tanatin 'silaka!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Ampifamadiho ny silaka amin'ny sombin-javatra hafa, mba hiantohana ny fampifanarahana ireo karazany.
    ///
    /// Ity fomba ity dia mizara roa ny silaka ho telo miavaka: prezy, voadio afovoany mifanaraka tsara amin'ny karazany vaovao, ary ny tsiranoka tovana.
    /// Ny fomba mety hahatonga ny afovoany silaka ny halavan'ny lehibe indrindra izay azo atao ny karazana sy ny fandraisana anjara nomena silaka, fa ny fampisehoana ny algorithm tokony miankina amin'izany, fa tsy ny correct.
    ///
    /// Tsy azo atao ho an'ny rehetra ny fahan'ny niverina tahirin-kevitra ho toy ny tovona na tovana silaka.
    ///
    /// Ity fomba ity dia tsy misy tanjona raha ny singa `T` na ny singa output `U` dia mitovy habe ary hamerina ilay silaka tany am-boalohany nefa tsy mizara na inona na inona.
    ///
    /// # Safety
    ///
    /// Ity fomba ity dia tena `transmute` manoloana ireo singa ao amin'ilay tapany afovoany niverina, noho izany ny fampitandremana mahazatra rehetra momba ny `transmute::<T, U>` dia mihatra eto ihany koa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Mariho fa ny ankamaroan'ity asa ity dia ho voamarina tsy tapaka,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // tantano manokana ny ZST, izany hoe-aza tanterahina mihitsy izany.
            return (self, &[], &[]);
        }

        // Voalohany, mahita amin'ny inona no manondro isika no namaky teo anelanelan'ny voalohany sy ny 2 silaka.
        // Mora amin'ny ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Jereo ny fomba `align_to_mut` raha mila fanazavana momba ny fiarovana amin'ny antsipiriany.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: ankehitriny `rest` dia mifanaraka tokoa, ka `from_raw_parts` etsy ambany dia mety,
            // satria ny miantso dia manome antoka fa afaka mandefa `T` mankany `U` soa aman-tsara isika.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Ampifamadiho ny silaka amin'ny sombin-javatra hafa, mba hiantohana ny fampifanarahana ireo karazany.
    ///
    /// Ity fomba ity dia mizara roa ny silaka ho telo miavaka: prezy, voadio afovoany mifanaraka tsara amin'ny karazany vaovao, ary ny tsiranoka tovana.
    /// Ny fomba mety hahatonga ny afovoany silaka ny halavan'ny lehibe indrindra izay azo atao ny karazana sy ny fandraisana anjara nomena silaka, fa ny fampisehoana ny algorithm tokony miankina amin'izany, fa tsy ny correct.
    ///
    /// Tsy azo atao ho an'ny rehetra ny fahan'ny niverina tahirin-kevitra ho toy ny tovona na tovana silaka.
    ///
    /// Ity fomba ity dia tsy misy tanjona raha ny singa `T` na ny singa output `U` dia mitovy habe ary hamerina ilay silaka tany am-boalohany nefa tsy mizara na inona na inona.
    ///
    /// # Safety
    ///
    /// Ity fomba ity dia tena `transmute` manoloana ireo singa ao amin'ilay tapany afovoany niverina, noho izany ny fampitandremana mahazatra rehetra momba ny `transmute::<T, U>` dia mihatra eto ihany koa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Mariho fa ny ankamaroan'ity asa ity dia ho voamarina tsy tapaka,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // tantano manokana ny ZST, izany hoe-aza tanterahina mihitsy izany.
            return (self, &mut [], &mut []);
        }

        // Voalohany, mahita amin'ny inona no manondro isika no namaky teo anelanelan'ny voalohany sy ny 2 silaka.
        // Mora amin'ny ptr.align_offset.
        let ptr = self.as_ptr();
        // SAFETY: Eto izahay dia manome antoka fa hampiasa tondro mifanaraka amin'ny U ho an'ny
        // ny sisa amin'ny fomba.Izany dia atao amin'ny alàlan'ny fandefasana tondro any&[T] miaraka amina fampifanarahana kendrena ho an'i U.
        // `crate::ptr::align_offset` dia antsoina hoe mifanaraka amin'ny marina sy marim-pototra manondro `ptr` (dia avy amin'ny firesahana momba `self`) ary miaraka amin'ny habe izay ny herin'ny roa (satria avy amin'ny alignement ho an'ny U), fahafaham-po ny faneren'ny fiarovana.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Tsy afaka mampiasa `rest` indray isika aorian'io, izany dia hanala ny anarany `mut_ptr`!SAFETY: jereo ny hevitra momba ny `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Manamarina raha namboarina ny singa amin'ity sombin-kazo ity.
    ///
    /// Izany hoe, ho an'ny singa `a` tsirairay sy ny singa `b` manaraka, dia tsy maintsy mitazona ny `a <= b`.Raha zero na singa iray tokoa ny silaka dia averina `true`.
    ///
    /// Mariho fa raha `PartialOrd` `Self::Item` ihany, fa tsy `Ord`, ny famaritana etsy ambony dia midika fa asa io miverina `false` raha misy zavatra roa nisesy dia tsy ampy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Hamarino raha toa ka voasokajy ny singa amin'ity sombin-kazo ity amin'ny alàlan'ny asan'ny mpampitaha nomena.
    ///
    /// Raha tokony mampiasa `PartialOrd::partial_cmp`, asa io dia mampiasa ny `compare` nomena asa mba hamantarana ny zavatra antokony roa.
    /// Ankoatra izany, dia mitovy amin'ny [`is_sorted`];jereo ny antontan-taratasiny raha mila fanazavana fanampiny.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Hamarino raha namboarina ny singa amin'ity sombin-kazo ity amin'ny alàlan'ny fampiasana ny fitrandrahana manan-danja.
    ///
    /// Raha tokony hampitahanao mivantana ireo singa an'ny sombin-kazo, ity fampandehanana ity dia mampitaha ny lakilen'ireo singa, araka ny nofaritan'ny `f`.
    /// Ankoatra izany, dia mitovy amin'ny [`is_sorted`];jereo ny antontan-taratasiny raha mila fanazavana fanampiny.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Miverina ny fanondroana ny fizarazaran'I hevitra araka ny nomena enti-(ny fanondroana ny voalohany singa faharoa fisarahana).
    ///
    /// Ny slice dia heverina ho zarazaraina araka ny predicate nomena.
    /// Midika izany fa ny singa rehetra noho ny enti-miverina izay marina dia eo am-piandohan'ny ny silaka sy ny singa rehetra noho izay ny enti-diso miverina any amin'ny farany.
    ///
    /// , Ohatra, dia ny partitioned [7, 15, 3, 5, 4, 12, 6] ambanin'ny X% ny enti-2!=0 (hafahafa rehetra isa ireo tamin'ny voalohany, na dia rehetra amin'ny farany).
    ///
    /// Raha tsy partitioned silaka, ny vokany dia niverina tsy fantatra sy tsy misy antony, araka ny fomba fiasa io manao karazana fikarohana mimari-droa.
    ///
    /// Jereo ihany koa [`binary_search`], [`binary_search_by`], ary [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SAFETY: Rehefa `left < right`, `left <= mid < right`.
            // Noho izany dia mitombo hatrany ny `left` ary mihena hatrany ny `right`, ary voafantina ny iray amin'izy ireo.Amin'ireo tranga roa ireo dia afa-po ny `left <= right`.Noho izany raha `left < right` amin'ny dingana iray dia afa-po amin'ny dingana manaraka i `left <= right`.
            //
            // Noho izany raha mbola `left != right`, `0 <= left < right <= len` dia afa-po ary raha ity tranga ity `0 <= mid < len` dia afa-po koa.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Mila mivantana silaka azy ireo toy izany koa halavan'ny
        // mba hahamora ny fizotran'ny optimizer ny fisafoana.
        // Fa satria tsy azo ianteherana dia manana spécialisation mazava ho an'ny T: Copy ihany koa isika.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Mamorona silaka poakaty.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Mamorona silaka poakaty azo ovaina.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Ny Endriky ny slices, amin'izao fotoana izao, ihany no nampiasain'i `strip_prefix` sy `strip_suffix`.
/// Amin'ny teboka future, antenainay ny hampitomboana ny `core::str::Pattern` (izay amin'ny fotoana anoratana dia voafetra amin'ny `str`) ny tsipika, ary avy eo hosoloina na hofoanana io trait io.
///
pub trait SlicePattern {
    /// Ny karazana singa amin'ilay silaka ampifanarahana aminy.
    type Item;

    /// Amin'izao fotoana izao, ny mpanjifa `SlicePattern` dia mila tapany.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}