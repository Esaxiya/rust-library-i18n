//! Macro ampiasain'ny iterator an'ny silaka.

// Ny fampidirana is_empty sy len dia mampisy fahasamihafana goavana amin'ny fampisehoana
macro_rules! is_empty {
    // Ny fomba isa ny halavan'ny iray ZST iterator, miasa izany na ho an'ny ZST sy ny tsy ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Mba hialana amin'ny fanamarinana fetra sasany (jereo `position`), dia manisa ny halavany amin'ny fomba somary tsy ampoizina isika.
// (Notsapaina tamin'ny `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // indraindray ampiasaina ao anaty sakana tsy azo antoka isika

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ity _cannot_ dia mampiasa `unchecked_sub` satria miankina amin'ny fonosana izahay mba hanehoana ny halavan'ny zera lava ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Fantatsika fa `start <= end`, ka afaka manao tsara kokoa noho ny `offset_from`, izay mila miatrika sonia.
            // Amin'ny fametrahana sainam-pirenena mety eto dia azontsika atao ny milaza izany amin'ny LLVM, izay manampy azy io hanala ireo fanamarinana fetra.
            // SAFETY: Amin'ny karazana invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Amin'ny filazàna amin'ny LLVM ihany koa fa ny tondro dia miavaka amin'ny karazany marobe amin'ny habeny, afaka manatsara ny `len() == 0` mankany `start == end` izy fa tsy `(end - start) < size`.
            //
            // Famonjena, invariant Ny karazana, ny sahaza dia mifanaraka toy izany koa ny
            //         ny elanelana misy eo amin'izy ireo dia tokony ho haben'ny pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Ny Nizara famaritana ny `Iter` sy `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Miverina ny singa voalohany ary mamindra ny fanombohan'ny iterator amin'ny 1.
        // Manatsara be ny fampisehoana raha oharina amin'ny lahasa misy tsipika.
        // Ny miverina dia tsy tokony ho foana.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Mamerina ny singa farany ary mamindra ny faran'ny iterator mankany aoriana amin'ny 1.
        // Manatsara be ny fampisehoana raha oharina amin'ny lahasa misy tsipika.
        // Ny miverina dia tsy tokony ho foana.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Mampihena ny iterator rehefa T ny ZST, amin'ny alàlan'ny famindrana ny faran'ny iterator mankany aoriana amin'ny `n`.
        // `n` Tsy tokony hihoatra ny `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Mpanampy miasa noho ny famoronana silaka avy amin'ny iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // Famonjena, ny iterator noforonina avy amin'ny silaka amin'ny manondro
                // `self.ptr` ary ny halavany `len!(self)`.
                // Izany antoka fa ho an'ny rehetra ny zavatra takiana alohan'ny `from_raw_parts` no tanteraka.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Ny asan'ny mpanampy amin'ny famindrana ny fanombohan'ny iterator mandroso amin'ny singa `offset`, mamerina ny fanombohana taloha.
            //
            // Tsy azo antoka satria ny offset dia tsy tokony hihoatra ny `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: manome antoka ny mpiantso fa tsy mihoatra ny `self.len()` ny `offset`,
                    // toy izany vaovao izany ao manondro `self`, ary dia toy izany no antoka ho tsy tohivakana foana.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Miasa ny mpanampy amin'ny famindrana ny faran'ny iterator mankany aoriana amin'ny singa `offset`, mamerina ny fiafarana vaovao.
            //
            // Tsy azo antoka satria ny offset dia tsy tokony hihoatra ny `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: manome antoka ny mpiantso fa tsy mihoatra ny `self.len()` ny `offset`,
                    // izay azo antoka fa tsy hihoatra ny `isize`.
                    // Ary koa, ny valin-kafatra vokatr'izany dia ao anatin'ny fetran'ny `slice`, izay mahafeno ireo fepetra hafa takiana amin'ny `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // azo ampiharina amin'ny slices, fa izany fialana fetra taratasim-bola

                // SAFETY: `assume` antso azo antoka satria ny sombin-panondro iraisana
                // dia tokony ho tsy misy dikany, ary ny silaka mihoatra ny tsy ZST dia tokony hanana mpanondro faran'izay tsy manan-kery ihany koa.
                // Ny fiantsoana mankany `next_unchecked!` dia azo antoka satria jerentsika raha foana ny iterator.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Foana izao ity iteratera ity.
                    if mem::size_of::<T>() == 0 {
                        // Tokony hataontsika toy izao ny `ptr` mety tsy 0 mihitsy, fa `end` mety ho (noho ny famonosana).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAFETY: tsy mety 0 ny farany raha tsy ZST ny T satria ptr tsy 0 ary mifarana>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // Famonjena, amin'ny fetra izahay.`post_inc_start` dia manao zavatra mety na dia amin'ny ZST aza.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Manilika ny fampiharana default isika, izay mampiasa `try_fold`, satria ity fampiharana tsotra ity dia miteraka kely kokoa noho ny LLVM IR ary haingana kokoa ny manangona azy.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Manilika ny fampiharana default isika, izay mampiasa `try_fold`, satria ity fampiharana tsotra ity dia miteraka kely kokoa noho ny LLVM IR ary haingana kokoa ny manangona azy.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Manilika ny fampiharana default isika, izay mampiasa `try_fold`, satria ity fampiharana tsotra ity dia miteraka kely kokoa noho ny LLVM IR ary haingana kokoa ny manangona azy.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Manilika ny fampiharana default isika, izay mampiasa `try_fold`, satria ity fampiharana tsotra ity dia miteraka kely kokoa noho ny LLVM IR ary haingana kokoa ny manangona azy.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Manilika ny fampiharana default isika, izay mampiasa `try_fold`, satria ity fampiharana tsotra ity dia miteraka kely kokoa noho ny LLVM IR ary haingana kokoa ny manangona azy.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Manilika ny fampiharana default isika, izay mampiasa `try_fold`, satria ity fampiharana tsotra ity dia miteraka kely kokoa noho ny LLVM IR ary haingana kokoa ny manangona azy.
            // Ary koa, ny `assume` dia misoroka ny fizahana fetra.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // Famonjena, no antoka ho amin'ny fetra ny manome fitoerana invariant:
                        // rehefa `i >= n`, `self.next()` mamerina `None` ary tapaka ny loop.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Manilika ny fampiharana default isika, izay mampiasa `try_fold`, satria ity fampiharana tsotra ity dia miteraka kely kokoa noho ny LLVM IR ary haingana kokoa ny manangona azy.
            // Ary koa, ny `assume` dia misoroka ny fizahana fetra.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // Famonjena, dia tsy maintsy `i` ka lalina noho `n` satria manomboka amin'ny `n`
                        // ary mihena ihany.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAFETY: ny miantso dia tsy maintsy manome antoka fa `i` dia voafetra
                // ny silaka misy ifotony, noho izany `i` dia tsy afaka mihoatra ny `isize`, ary ny fiverenana resahina dia azo antoka fa manondro singa iray amin'ilay silaka ary azo antoka fa mitombina.
                //
                // Mariho ihany koa fa ny miantso dia manome toky ihany koa fa tsy nantsoina tamin'io index io intsony isika, ary tsy misy fomba hafa mety hiditra an'ity lisitra ity antsoina, noho izany dia mitombina ny fiverenan'ny referansa miverina amin'ny tranga
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // azo ampiharina amin'ny slices, fa izany fialana fetra taratasim-bola

                // SAFETY: `assume` antso azo antoka satria ny fanombohan'ilay sombin-tsoratra dia tokony tsy ho null,
                // ary ny silaka mihoatra ny tsy ZST dia tsy maintsy misy mpanondro farany tsy misy fotony ihany koa.
                // Ny fiantsoana mankany `next_back_unchecked!` dia azo antoka satria jerentsika raha foana ny iterator.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Foana izao ity iteratera ity.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // Famonjena, amin'ny fetra izahay.`pre_dec_end` manao ny tokony hatao ka ho ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}