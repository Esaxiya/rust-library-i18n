// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ny isan-karazany ary mihodinkodina `[mid-left, mid+right)` izany fa ny singa ao amin'ny `mid` lasa ny singa voalohany.Mitovy, mihodina ny elanelan'ny `left` miankavia na singa `right` miankavanana.
///
/// # Safety
///
/// Ny elanelam-potoana voalaza dia tsy maintsy mitombina amin'ny famakiana sy ny fanoratana.
///
/// # Algorithm
///
/// Algorithm 1 dia ampiasaina amin'ny sanda kely `left + right` na ho an'ny `T` lehibe.
/// Ireo singa dia afindra amin'ny toerany farany isaky ny mandeha manomboka amin'ny `mid - left` ary mandroso amin'ny dingana `right` modulo `left + right`, ka iray monja dia tsy ilaina izany.
/// Tamin'ny farany, dia tonga indray amin'ny `mid - left`.
/// Na izany aza, raha tsy `gcd(left + right, right)` dia 1, ireo dingana etsy ambony dia nandiso ireo singa.
/// Ohatra:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Soa ihany fa ny isan'ny nandingana ireo singa teo anelanelan'ny singa vita dia mitovy foana, mba hahafahantsika manonitra ny toerantsika manomboka ary manao boribory bebe kokoa (ny totalin'ny fihodinana dia ny `gcd(left + right, right)` value).
///
/// Ny vokatra farany dia ny singa rehetra dia vitaina indray mandeha ary indray mandeha ihany.
///
/// Algorithm 2 no ampiasaina raha malalaka, fa `left + right` `min(left, right)` dia ampy mba hifanaraka kely teo niisa buffer.
/// Ny singa `min(left, right)` dia adika amin'ny buffer, ny `memmove` dia ampiharina amin'ny hafa, ary ireo eo amin'ny buffer dia afindra any anaty lavaka amin'ny lafiny mifanohitra amin'ny niandohany.
///
/// Ny algorithm izay azo alefa amin'ny alàlan'ny volo dia ambony noho ny voalaza etsy ambony raha vao lasa lehibe `left + right`.
/// Ny Algorithm 1 dia azo alain-tahaka amin'ny alàlan'ny fametahana sy fanaovana fihodinana maro indray mandeha, saingy vitsy loatra ny fihodinana eo ho eo mandra-pahatongan'ny `left + right` goavana, ary ny tranga ratsy indrindra amin'ny fihodinana tokana dia eo foana.
/// Fa kosa, ny algorithm 3 dia mampiasa fifanakalozana miverimberina singa `min(left, right)` mandra-pahatongan'ny olana iray mihodina kely kokoa.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// rehefa `left < right` ny swapping mitranga avy amin'ny ankavia kosa.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ny algorithman etsy ambany dia mety tsy hahomby raha tsy voamarina ireo tranga ireo
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks dia manondro fa ny fahombiazan'ny fiovan'ny kisendrasendra dia tsara kokoa hatrany mandra-pahatongan'ny `left + right == 32`, fa ny tranga ratsy indrindra dia tapaka na dia manodidina ny 16 aza.
            // 24 no voafidy ho marimaritra iraisana.
            // Raha ny haben'ny `T` lehibe kokoa noho ny 4 usize, ity algorithm ity dia manoatra koa ny algorithma hafa.
            //
            //
            let x = unsafe { mid.sub(left) };
            // fanombohan'ny fihodinana voalohany
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` Afaka ny ho hita eo anatrehan'i tanana amin'ny fikajiana `gcd(left + right, right)`, nefa haingana kokoa ny manao izay manome fitoerana iray kajy ny GCD toy ny vokany, dia manao ny sisa amin'ny chunk
            //
            //
            let mut gcd = right;
            // benchmarks manambara fa haingana kokoa ny swap temporaries an-dalana rehetra fa tsy mamaky vonjimaika iray indray mandeha, maka tahaka aoriana, ary avy eo dia nanoratra fa vetivety amin'ny farany indrindra.
            // Mety noho ny fifanakalozana na fanoloana vonjimaika dia adiresy fahatsiarovana iray ihany no ampiasainao ao anaty tadivavarana fa tsy mila mitantana roa.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // Raha tokony hampitombo `i` ary avy eo manamarina raha ivelan'ny fetra, dia manamarina isika raha hivoaka ivelan'ny fetra i `i` amin'ny fiakarana manaraka.
                // Manakana ny famonosana tondro na `usize` izany.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // faran'ny fihodinana voalohany
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ity fepetra ity dia tsy maintsy eto raha `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // fenoy amina boribory bebe kokoa ny chunk
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` dia tsy karazan'olona mitovy habe aotra, ka tsy maninona ny mizara araka ny habeny.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 Ny `[T; 0]` eto dia hahazoana antoka fa mifanaraka tsara amin'ny T ity
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Misy fomba hafa ifanakalozana izay misy ny fitadiavana hoe aiza no hisy ny farany fiovana amin'ity algorithm ity, ary miovaova amin'ny alàlan'ny fampiasana io sombina farany io fa tsy miova ireo tapa-kazo mifanila aminy toa ity algorithm ity, saingy mbola haingana kokoa io fomba io.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}