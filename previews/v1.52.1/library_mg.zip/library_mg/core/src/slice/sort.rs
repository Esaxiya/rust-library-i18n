//! silaka fanasokajiana
//!
//! Ity modely ity dia misy algorithm manasokajy mifototra amin'ny fandresena resin'i Orson Peters izay navoaka tamin'ny: <https://github.com/orlp/pdqsort>
//!
//!
//! Ny fanasoketana tsy marin-toerana dia mifanaraka amin'ny libcore satria tsy mizara fahatsiarovana izany, tsy toy ny fampiharana fanasokajiana milamina.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rehefa nilatsaka dia kopia avy amin'ny `src` ka hatramin'ny `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // Famonjena, Ity no mpanampy kilasy.
        //          Azafady mba jereo ny fampiasana azy raha te hahitsy.
        //          Na izany aza, tsy maintsy matoky ianao fa ny `src` sy `dst` dia tsy mifindra araky ny takian'i `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Atsimbadika ankavanana ny singa voalohany mandra-pihaonany singa lehibe kokoa na mitovy.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Ny hetsika tsy azo antoka etsy ambany dia misy ny fanondroana raha tsy misy takelaka voafatotra (`get_unchecked` sy `get_unchecked_mut`)
    // ary maka tahaka ny memoara (`ptr::copy_nonoverlapping`).
    //
    // a.Fanoratana:
    //  1. Izahay dia nanamarina ny haben'ny laharana hatramin'ny>=2.
    //  2. Ny index rehetra hataontsika dia eo anelanelan'ny {0 <= index < len} farafaharatsiny.
    //
    // b.Memory kopia
    //  1. Mahazo fanondroana ireo fanondroana izay azo antoka fa mitombina.
    //  2. Tsy afaka mifanindry izy ireo satria mahazo tondro misy fahasamihafana amin'ny sombin-taratasy.
    //     Izany hoe, `i` sy `i-1`.
    //  3. Raha ny silaka dia mifanaraka tsara, araka ny tokony ho Ireo singa dia mifanaraka.
    //     Andraisan'ny mpiantso ny maka antoka fa mifanaraka tsara ilay silaka.
    //
    // Jereo ny hevitra etsy ambany raha mila fanazavana fanampiny.
    unsafe {
        // Raha toa ny singa roa voalohany dia avy-of-mba ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Vakio ny singa voalohany ho lasa mpanova-natokana.
            // Raha misy fampitahana manaraka panics, `hole` dia hidina ary soraty ho azy ao anaty silaka ilay singa.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Afindrao miankavia ny singa iray, toerana iray miankavia, ka manova ny lavaka miankavanana.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` milatsaka ary avy eo kopian'ny `tmp` ao anaty lavaka sisa tavela amin'ny `v`.
        }
    }
}

/// Nifandimby ny singa farany ho amin'ny ankavia mandra-pahatongany misedra kely kokoa na singa mitovy.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Ny hetsika tsy azo antoka etsy ambany dia misy ny fanondroana raha tsy misy takelaka voafatotra (`get_unchecked` sy `get_unchecked_mut`)
    // ary maka tahaka ny memoara (`ptr::copy_nonoverlapping`).
    //
    // a.Fanoratana:
    //  1. Izahay dia nanamarina ny haben'ny laharana hatramin'ny>=2.
    //  2. Ny index rehetra hataontsika dia eo anelanelan'ny `0 <= index < len-1` farafaharatsiny.
    //
    // b.Memory kopia
    //  1. Mahazo fanondroana ireo fanondroana izay azo antoka fa mitombina.
    //  2. Tsy afaka mifanindry izy ireo satria mahazo tondro misy fahasamihafana amin'ny sombin-taratasy.
    //     Izany hoe, `i` sy `i+1`.
    //  3. Raha ny silaka dia mifanaraka tsara, araka ny tokony ho Ireo singa dia mifanaraka.
    //     Andraisan'ny mpiantso ny maka antoka fa mifanaraka tsara ilay silaka.
    //
    // Jereo ny hevitra etsy ambany raha mila fanazavana fanampiny.
    unsafe {
        // Raha toa ny singa roa farany dia avy-of-mba ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Vakio ny singa farany ho mpanova-natokana.
            // Raha misy fampitahana manaraka panics, `hole` dia hidina ary soraty ho azy ao anaty silaka ilay singa.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Afindrao amin'ny toerana ankavanana ny singa iray, ary manova ny lavaka miankavia ianao.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` milatsaka ary avy eo kopian'ny `tmp` ao anaty lavaka sisa tavela amin'ny `v`.
        }
    }
}

/// Amin'ny ampahany isan-karazany ny silaka ny miovaova maro avy-of-mba singa manodidina.
///
/// Miverina `true` raha toa ka voalamina ny farany amin'ny farany.Izany asa izany *O*(*n*)-tranga ratsy indrindra.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Isan'ny farafahakeliny amin'ireo tsiroaroa tsy misy filaminana mifanakaiky izay hiova.
    const MAX_STEPS: usize = 5;
    // Raha fohy kokoa noho io ny silaka dia aza afindra singa.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAFETY: Efa nanao mazava tamin'ny `i < len` izahay.
        // Rehetra ny manaraka nirakitra anarana ihany any amin'ny isan-karazany `0 <= index < len`
        unsafe {
            // Tadiavo ireo mpivady manaraka izay singa tsy voatanisa manaraka.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Moa ve isika nataonao?
        if i == len {
            return true;
        }

        // Aza miova amin'ny zavatra fohy arrays, izay manana vola fampisehoana.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ampifamadiho ireo singa hita roa.Zavatra tsy manala azy ireo amin'ny filaharany marina.
        v.swap(i - 1, i);

        // Manilika kely singa ho amin'ny ankavia.
        shift_tail(&mut v[..i], is_less);
        // Avadiho miankavanana ny singa lehibe kokoa.
        shift_head(&mut v[i..], is_less);
    }

    // Tsy ny fitantanana ny manatsara ny silaka ao amin'ny voafetra ny isan'ny dingana.
    false
}

/// Manasokajy silaka amin'ny alàlan'ny karazana insertion, izay tranga *O*(*n*^ 2) ratsy indrindra.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Manasokajy `v` amin'ny fampiasana heapsort, izay manome antoka ny *O*(*n*\*log(* n*)) tranga ratsy indrindra.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ity antontam-bato mimari-droa manaja ny invariant `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Zanak'i `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Fidio ny ankizy lehibe kokoa.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Ajanony raha mihazona ny invariant amin'ny `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Ampifamadiho ny `node` amin'ilay zaza lehibe kokoa, mandroso midina ary tohizo ny fitifirana.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Hanao ny antontam-bato amin'ny fotoana Linear.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maximal singa avy ao amin'ny antontan-javatra.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partitions `v` ho singa kely kokoa noho `pivot`, arahin'ireo singa lehibe kokoa na mitovy amin'ny `pivot`.
///
///
/// Mamerina ny isan'ny singa kely kokoa noho ny `pivot`.
///
/// Ny fizarazaran-tany dia tanterahina isaky ny andalana mba hampihenana ny vidin'ny sampana.
/// Ity hevitra ity dia aseho ao amin'ny taratasy [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Isan'ny singa ao anaty sakana mahazatra.
    const BLOCK: usize = 128;

    // Ny algorithm fizarazarana dia mamerina ireto dingana manaraka ireto mandra-pahavitany:
    //
    // 1. Manorata sakana iray avy eo amin'ny ilany havia mba hahalalana ireo singa lehibe kokoa na mitovy amin'ny pivot.
    // 2. Mamantatra ny andian-tsoratra avy amin'ny ankavanana mba hamantatra zavatra kely noho ny andry fototry.
    // 3. Ampifamadiho ny elanelana voafaritra eo anelanelan'ny havia sy havanana.
    //
    // Izahay dia mitazona ireto miova ireto ho an'ny singa maromaro:
    //
    // 1. `block` - Isan'ny singa ao amin'ny sakana.
    // 2. `start` - Atombohy manondro any an-`offsets` fihaingoana.
    // 3. `end` - Hifarana manondro any an-`offsets` fihaingoana.
    // 4. `Maivana, Indices ny avy-of-mba singa ao anatin'ny andian-tsoratra.

    // Ny sakana amin'izao fotoana izao amin'ny ilany havia (avy amin'ny `l` ka hatramin'ny `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Ny sakana ankehitriny amin'ny ilany ankavanana (avy amin'ny `r.sub(block_r)` to `r`).
    // Famonjena, ny tahirin-kevitra manokana ho an'ny .add() milaza fa foana `vec.as_ptr().add(vec.len())` safe`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Rehefa mahazo VLA isika dia andramo ny mamorona laharana `min(v.len() lava, 2 * BLOCK) `fa tsy
    // noho ny roa-haben'ny arrays raikitra ny halavany `BLOCK`.Ny VLA dia mety ho mahomby amin'ny cache.

    // Miverina ny isan'ny singa eo sahaza `l` (inclusive) sy `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Vita amin'ny fizarazarana par-block izahay rehefa manakaiky ny `l` sy `r`.
        // Avy eo dia no misy Patch-up asa, mba fisarahana ny sisa singa ao anelanelan'ny.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Isan'ny singa sisa tavela (mbola tsy ampitahaina amin'ny pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Amboary ny haben'ny sakana mba tsy hifanindry ny sakana havia sy havanana, fa mifandanja tsara mba handrakofana ny banga sisa tavela.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Soritry `block_l` singa avy ao amin'ny ankavia.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // Famonjena, hetsika etsy ambany ny unsafety mahakasika ny fampiasana ny `offset`.
                //         Araka ny fepetra takian'ilay asa dia manome fahafaham-po azy ireo izahay satria:
                //         1. `offsets_l` dia natokana-natokana, ary amin'izany dia heverina ho zavatra natokana natokana.
                //         2. Ny asa `is_less` Niverina ny `bool`.
                //            Ny fandefasana `bool` dia tsy hihoatra ny `isize` mihitsy.
                //         3. Nanome toky izahay fa `block_l` dia `<= BLOCK`.
                //            Plus, `end_l` tamin'ny voalohany nametraka ny manomboka manondro ny `offsets_` izay nambara teo amin'ny stack.
                //            Noho izany, fantatsika fa na dia amin'ny tranga ratsy indrindra aza (ny fiantsoana rehetra an'ny `is_less` dia miverina diso) dia 1 farafahakeliny byte no handalo ny farany.
                //        Fandidiana tsy fandriam-pahalemana iray hafa eto dia ny fanesorana ny `elem`.
                //        Na dia izany aza, tamin'ny voalohany `elem` ny manomboka manondro ny silaka izay manan-kery foana.
                unsafe {
                    // Fampitahana tsy misy sampana.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Araho ireo singa `block_r` avy eo amin'ny ilany ankavanana.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // Famonjena, hetsika etsy ambany ny unsafety mahakasika ny fampiasana ny `offset`.
                //         Araka ny fepetra takian'ilay asa dia manome fahafaham-po azy ireo izahay satria:
                //         1. `offsets_r` dia natokana-natokana, ary amin'izany dia heverina ho zavatra natokana natokana.
                //         2. Ny asa `is_less` Niverina ny `bool`.
                //            Ny fandefasana `bool` dia tsy hihoatra ny `isize` mihitsy.
                //         3. Nanome toky izahay fa `block_r` dia `<= BLOCK`.
                //            Plus, `end_r` tamin'ny voalohany nametraka ny manomboka manondro ny `offsets_` izay nambara teo amin'ny stack.
                //            Noho izany, fantatsika fa na dia amin'ny tranga ratsy indrindra aza (ny fiantsoana rehetra an'ny `is_less` dia miverina marina) dia farafahakeliny 1 byte no handalo ny farany.
                //        Fandidiana tsy fandriam-pahalemana iray hafa eto dia ny fanesorana ny `elem`.
                //        Na dia izany aza, tamin'ny voalohany `elem` `1 *sizeof(T)` lasa ny farany ary decrement izany tamin'ny `1* sizeof(T)` alohan'ny fahazoana azy io.
                //        Plus, `block_r` dia nanamafy ho kely noho ny `BLOCK` sy `elem` ho Koa tamin'ny indrindra dia manondro ny fiandohan 'ny silaka.
                unsafe {
                    // Fampitahana tsy misy sampana.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Isan'ny avy-of-mba ho swap singa eo amin'ny ankavia sy ny ankavanana.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Raha tokony hanakalo mpivady iray amin'izay izy dia mahomby kokoa ny fanaovana permutation cyclic.
            // Izany no tsy tena mitovy amin'ny swapping, fa mahatonga vokany toy izany koa mampiasa asa fahatsiarovana vitsivitsy.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Nifindra avokoa ireo singa tsy voarindra ao amin'ny sakana ankavia.Mifindra amin'ny sakana manaraka.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Nifindra avokoa ireo singa tsy voarindra ao amin'ny sakana ankavanana.Mifindra amin'ny sakana teo aloha.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Ny sisa tavela ankehitriny dia farafahakeliny sakana iray (na ny ankavia na ny ankavanana) miaraka amin'ireo singa tsy tokony haleha izay tokony hafindra.
    // Ireo singa sisa tavela dia azo ovaina fotsiny hatramin'ny farany ao anatin'ny sakana misy azy ireo.
    //

    if start_l < end_l {
        // Mijanona ny sakana ankavia.
        // Afindra miankavanana miankavanana ireo singa sisa tsy voavidiny.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Ny andian-tsoratra tsara mitoetra.
        // Move ny sisa avy-of-mba singa ho an'ny sisa lavitra.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Tsy misy zavatra hafa tokony hatao, vita isika.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitions `v` ho singa kely kokoa noho `v[pivot]`, arahin'ireo singa lehibe kokoa na mitovy amin'ny `v[pivot]`.
///
///
/// Miverina ny tuple ny:
///
/// 1. Isan'ny singa kely kokoa noho ny `v[pivot]`.
/// 2. Marina raha toa ka `v` dia efa partitioned.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Apetraho amin'ny fiandohan'ny silaka ny pivot.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Vakio ny pivot ho variable natokana ho an'ny fahombiazany.
        // Raha miasa ny fampitahana panics manaraka, dia hosoratana ho azy indray ilay pivot.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Tadiavo ireo singa voalohany tsy voarindra.
        let mut l = 0;
        let mut r = v.len();

        // SAFETY: Ny tsy fandriampahalemana etsy ambany dia misy ny fanondroana filaharana.
        // Fa ny voalohany: Efa isika manao ny faritry mijery eto `l < r`.
        // Fa ny faharoa: manana isika `l == 0` voalohany sy `r == v.len()` ary homarinana avy amin'ny teny fa `l < r` isaky ny asa nirakitra anarana.
        //                     Avy eto dia fantatsika fa `r` dia tsy maintsy farafaharatsiny `r == l` izay naseho fa marina hatramin'ny voalohany.
        unsafe {
            // Tadiavo ny singa voalohany lehibe kokoa na mitovy amin'ny pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Tadiavo ny singa farany kely fa andry fototry.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` mivoaka amin'ny sehatra ary manoratra ny pivot (izay miovaova atokana ho an'ny stack) miverina ao amin'ilay faritra nisy azy tany am-boalohany.
        // Ity dingana zava-dehibe eo amin'ny fiantohana ny fiarovana!
        //
    };

    // Apetraho eo anelanelan'ny fizara roa ny pivot.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Ny fizarana `v` ho singa mitovy amin'ny `v[pivot]` arahin'ireo singa lehibe kokoa noho ny `v[pivot]`.
///
/// Mamerina ny isan'ny singa mitovy amin'ny pivot.
/// Heverina fa ny `v` dia tsy misy singa kely noho ny pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Apetraho amin'ny fiandohan'ny silaka ny pivot.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Vakio ny pivot ho variable natokana ho an'ny fahombiazany.
    // Raha miasa ny fampitahana panics manaraka, dia hosoratana ho azy indray ilay pivot.
    // SAFETY: Mitombina ny tondro eto satria azo avy amin'ny fanondroana silaka.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ary ny silaka fisarahana.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAFETY: Ny tsy fandriampahalemana etsy ambany dia misy ny fanondroana filaharana.
        // Fa ny voalohany: Efa isika manao ny faritry mijery eto `l < r`.
        // Fa ny faharoa: manana isika `l == 0` voalohany sy `r == v.len()` ary homarinana avy amin'ny teny fa `l < r` isaky ny asa nirakitra anarana.
        //                     Avy eto dia fantatsika fa `r` dia tsy maintsy farafaharatsiny `r == l` izay naseho fa marina hatramin'ny voalohany.
        unsafe {
            // Tadiavo ny voalohany singa lehibe noho ny andry fototry.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Tadiavo ny singa farany mitovy amin'ny pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Moa ve isika nataonao?
            if l >= r {
                break;
            }

            // Ampifamadiho ireo singa hita tsy misy filaminana intsony.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Hitanay ny singa `l` mitovy amin'ny pivot.Add 1 ny tantara ho an'ny andry fototry mihitsy.
    l + 1

    // `_pivot_guard` mivoaka amin'ny sehatra ary manoratra ny pivot (izay miovaova atokana ho an'ny stack) miverina ao amin'ilay faritra nisy azy tany am-boalohany.
    // Ity dingana zava-dehibe eo amin'ny fiantohana ny fiarovana!
}

/// Manaparitaka singa sasantsasany manodidina amin'ny fikasana hanapaka ireo lamina mety hiteraka fisarahana tsy mahay mandanjalanja ao amin'ny quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom number generator avy amin'ny taratasy "Xorshift RNGs" nataon'i George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Raiso nomerao maodely modulo ity isa ity.
        // Ny isa dia mifanaraka amin'ny `usize` satria ny `len` dia tsy lehibe noho ny `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Misy andry fototry kandidà ho ao amin'ny tondro teo akaiky teo izany.Ndeha randomize azy ireo.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Miteraha isa maody modulo `len`.
            // Na izany aza, mba hisorohana ny fandidiana lafo vidy isika aloha maka izany modulo ny herin'ny roa, ary avy eo dia hampihena ny `len` mandra-mifanaraka ho any amin'ny isan-karazany `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` dia azo antoka fa latsaky ny `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Misafidy pivot amin'ny `v` ary mamerina ny index sy `true` raha toa ka efa voalamina sahady ilay silaka.
///
/// Ireo singa in `v` mety ho reordered ao amin'ny dingana.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lava farafahakeliny mba hisafidianana ny fomba mediana-of-medians.
    // Fohy slices tsotra mampiasa ny Medianina-of-telo fomba fiasa.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Safidy farany azo atao azo atao amin'ity lahasa ity.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Telo indices akaiky izay tiantsika ny hifidy ny andry fototry.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Manisa ny totalin'ny swaps izay hataontsika eo am-panasokajiana ireo indeks.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps indices mba `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Mampifamadika ny index mba `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Mahita ny mediana `v[a - 1], v[a], v[a + 1]` ary mitahiry ny index mankany `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Mitadiava mediana ao amin'ny manodidina an'i `a`, `b`, ary `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Tadiavo ny mediana eo amin'ny `a`, `b`, ary `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Ny isan'ny swap farany ambony dia notanterahina.
        // Ny vintana dia mihena ny silaka na midina ny ankamaroany, noho izany ny fiverenana dia mety hanampy azy handamina azy io haingana kokoa.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Karazana `v` recursively.
///
/// Raha nisy mpialoha lalana ilay sombin-tsakafo dia namboarina ho `pred`.
///
/// `limit` dia ny isan'ny fizarana avela tsy voalanjalanja alohan'ny hifindrana amin'ny `heapsort`.
/// Raha aotra dia hiova avy hatrany amin'ny heapsort ity fiasa ity.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ny silaka mahatratra an'io halavany io dia alahatra amin'ny alàlan'ny karazana fampidirana.
    const MAX_INSERTION: usize = 20;

    // Marina raha voalanjalanja ny fizarazarana farany.
    let mut was_balanced = true;
    // Marina raha tsy nanova ny singa ny fizarazarana farany (efa nozarazaraina ny silaka).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Ny silaka fohy dia voasokajy amin'ny alàlan'ny karazana fampidirana.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Raha be loatra ny safidin'ny pivot ratsy natao dia miverena kely fotsiny any amin'ny heapsort mba hiantohana ny tranga ratsy indrindra `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Raha tsy voalanjalanja ny fizarazarana farany dia andramo ny mamaky lamina ao amin'ilay silaka amin'ny alàlan'ny fanovana ireo singa manodidina.
        // Enga anie isika hifidy Ho andry fototry tsaratsara kokoa amin'ity indray mitoraka ity.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Misafidiana pivot iray ary manandrama maminavina raha efa nalamina ilay silaka.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Raha ny fizarazarana farany tamin'ny mandanjalanja amim-pahamendrehana ary tsy dia akisaho singa, ary raha fantina mialoha andry fototry ny silaka dia azo inoana fa efa nandamina ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Andramo famantarana maro avy-of-mba singa sy miovaova azy ireo ho marina toerana.
            // Raha tapitra voasokajy tanteraka ilay silaka dia vita isika.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Raha ny pivot voafantina dia mitovy amin'ilay teo alohany, dia io no singa kely indrindra ao amin'ilay silaka.
        // Ampisarahana ny singa ho singa mitovy sy singa lehibe kokoa noho ny pivot.
        // Matetika io tranga io dia voadona rehefa misy singa duplicate maro ny slice.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Tohizo ny fanasokajiana singa lehibe kokoa noho ny pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Ampisarahana ny silaka.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Hizara ny silaka ho `left`, `pivot`, ary `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Avereno jerena ny lafiny fohy kokoa fotsiny mba hahafahana mampihena ny totalin'ny antso recursive ary handany toerana kely kokoa.
        // Avy eo manohy fotsiny amin'ny lafiny lava kokoa (mitovy amin'ny famerenan'ny rambony io).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// `v` isan-karazany mampiasa modely-handresy quicksort, izay *O*(*n*\*log(* n*))-raharaha ratsy.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ny fanasokajiana dia tsy misy fitondran-tena misy dikany amin'ny karazana zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Fero ny `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Ho an'ny silaka mahatratra an'io halavany io dia mety ho haingana kokoa ny manasokajy azy ireo tsotra izao.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Misafidiana pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Raha ny pivot voafantina dia mitovy amin'ilay teo alohany, dia io no singa kely indrindra ao amin'ilay silaka.
        // Ampisarahana ny singa ho singa mitovy sy singa lehibe kokoa noho ny pivot.
        // Matetika io tranga io dia voadona rehefa misy singa duplicate maro ny slice.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Raha nahavita ny index izahay, dia tsara izany.
                if mid > index {
                    return;
                }

                // Raha tsy izany, hanohy manavaka singa lehibe noho andry fototry.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Hizara ny silaka ho `left`, `pivot`, ary `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Raha==fanondroana tapaky ny volana, avy eo dia nataony isika, satria partition() antoka fa singa rehetra aorian'ny tapaky ny volana dia lehibe noho na mitovy amin'ny tapaky ny volana.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ny fanasokajiana dia tsy misy fitondran-tena misy dikany amin'ny karazana zero.Aza manao na inona na inona.
    } else if index == v.len() - 1 {
        // Mitadiava singa max ary apetraho amin'ny toerana farany an'ny laharana.
        // Afaka mampiasa `unwrap()` eto izahay satria fantatray fa tsy tokony foana ny v.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Mitadiava singa min ary apetraho amin'ny toerana voalohany amin'ny laharana.
        // Afaka mampiasa `unwrap()` eto izahay satria fantatray fa tsy tokony foana ny v.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}