//! Fandidiana amin'ny ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Hamarino raha ao anaty kisary ASCII daholo ny bytes ao amin'ity sombin-kazo ity.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Manamarina fa ny fehezam-boninkazo roa dia lalao ASCII tsy dia misy dikany.
    ///
    /// Mitovy amin'ny `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, fa tsy mizara sy mandika vonjimaika.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Mampivadika io sombin-taratasy io amin'ny ASCII ambony tranga mitovy amin'ny toerany.
    ///
    /// Ny litera ASCII 'a' ka hatramin'ny 'z' dia mapafao amin'ny 'A' ka hatramin'ny 'Z', fa ny litera tsy ASCII tsy miova.
    ///
    /// Raha hamerina sanda ambony ambony tsy misy fanovana ny efa misy dia ampiasao [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Mampivadika io sombin-kazo io amin'ny ASCII ambany ambany mitovy amin'ny toerany.
    ///
    /// Marika ASCII taratasy 'A' ho 'Z' dia tsarintany ny 'a' ho 'z', fa tsy marika ASCII taratasy dia niova.
    ///
    /// Raha mamerina sanda ambany ambany vaovao nefa tsy manova ny efa misy dia ampiasao [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Miverina `true` raha misy byte ny teny `v` dia nonascii (>=128).
/// Snarfed avy amin'ny `../str/mod.rs`, izay manao zavatra mitovy amin'ny fanamarinana utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimisé marika ASCII fitsapana izay hampiasa usize-at-a-potoana asa fa tsy byte-at-a-potoana asa (raha azo atao).
///
/// Ny algorithm ampiasaintsika eto dia tsotra be.Raha `s` fohy loatra, isika hijery fotsiny byte tsirairay ary hatao miaraka aminy.Raha tsy izany:
///
/// - Vakio ny teny voalohany miaraka amina enta-mavesatra tsy voalahatra.
/// - Ampifanaraho ny tondro, vakio ny teny manaraka mandra-paran'ny famaranana mifanaraka amin'ny entana.
/// - Vakio ny `usize` farany avy amin'ny `s` miaraka amina enta-mavesatra tsy voalahatra.
///
/// Raha misy amin'ireo enta-mavesatra ireo mamokatra zavatra izay averina `contains_nonascii` (above) marina, dia fantatsika fa diso ny valiny.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Raha tsy hahazo na inona na inona avy ny teny-at-a-ny fampiharana, lavo indray ny scalar manome fitoerana.
    //
    // Izahay koa dia manao izany ho an'ny maritrano izay tsy dia misy fampifanarahana `size_of::<usize>()` ho an'ny `usize`, satria tranga edge hafahafa.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Izahay dia mamaky foana ny teny voalohany tsy voalahatra, izay midika hoe `align_offset` dia
    // 0, dia hamaky ilay sanda mitovy indray izahay ho an'ny vakiteny mifanaraka.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAFETY: Manamarina `len < USIZE_SIZE` etsy ambony izahay.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Izahay dia nanamarina an'io etsy ambony, somary an-kolaka.
    // Mariho fa ny `offset_to_aligned` dia `align_offset` na `USIZE_SIZE`, samy voamarina mazava etsy ambony izy roa.
    //
    debug_assert!(offset_to_aligned <= len);

    // Famonjena, word_ptr no (araka ny tokony ho mifanaraka) usize ptr ampiasaintsika mba hamaky ny
    // tapany afovoan'ny silaka.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` dia index byte an'ny `word_ptr`, ampiasaina amin'ny fizahana faran'ny loop.
    let mut byte_pos = offset_to_aligned;

    // Paranoia manamarina momba ny fampifanarahana, satria efa hanao be dia be izahay.
    // Amin'ny fampiharana dia tokony tsy ho azo atao ny mandrara bug amin'ny `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Vakio ny teny manaraka mandra-pahatongan'ny teny namboarina farany, tsy manilika ny teny namboarina farany izy hatao ao anaty fanaraha-maso amin'ny rambony any aoriana, mba hahazoana antoka fa `usize` foana ny rambony raha oharina amin'ny branch `byte_pos == len` fanampiny.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Diniho ny fahadiovana fa voafaritra tsara ny vakiteny
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ary ny fiheveranay momba ny `byte_pos` mitazona.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // Famonjena, `word_ptr` Fantatsika fa araka ny tokony ho mifanaraka (noho ny
        // `Align_offset`), ary fantatsika fa manana ampy oktety eo `word_ptr` sy ny farany
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAFETY: Fantatsika fa `byte_pos <= len - USIZE_SIZE`, izay midika fa izany
        // aorian'ity `add` ity, `word_ptr` dia ho faran'ny iray farany.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Hamarino ny fahadiovana mba hahazoana antoka fa tena misy `usize` sisa.
    // Izany dia tokony hiantohana amin'ny toetrantsika loop.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: miankina amin'ny `len >= USIZE_SIZE` io, izay zahantsika eo am-piandohana.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}