//! Free miasa mba hamorona `&[T]` sy `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Mamorona sombina avy amin'ny tondro sy halavany.
///
/// Ny adihevitra `len` dia ny isan'ny singa ** **, fa tsy ny isan'ny bytes.
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `data` dia tsy maintsy ho [valid] ny mamaky ny `len * mem::size_of::<T>()` oktety maro, ary tsy maintsy ho araka ny tokony mifanaraka.Midika manokana izany:
///
///     * Ny haben'ny fahatsiarovana iray manontolo amin'ity sombin-kazo ity dia tsy maintsy ao anaty zavatra iray natokana!
///       Slices afaka na oviana na oviana span maro manerana zavatra omena.Jereo ny [below](#incorrect-usage) ohatra iray tsy mahadiso izany.
///     * `data` dia tsy maintsy atao tsy mivoana ary mifanaraka na dia amin'ny sombina lava aza.
///     Ny antony iray mahatonga an'io dia ny fanamafisana ny famolavolana enum dia mety hiankina amin'ny fanovozan-kevitra (ao anatin'izany ny sombina amin'ny halavany rehetra) mifanaraka sy tsy azo foanana hanavahana azy ireo amin'ny angona hafa.
///     Azonao atao ny mahazo pointer izay azo ampiasaina ho `data` ho an'ny sombina lava aotra mampiasa [`NonNull::dangling()`].
///
/// * `data` dia tsy maintsy manondro ny `len` misesy araka ny tokony ho karazana initialized soatoavin'ny `T`.
///
/// * Ny fahatsiarovana notondroin'ny silaka niverina dia tsy tokony hovaina mandritra ny androm-piainana `'a`, afa-tsy ao anaty `UnsafeCell` iray.
///
/// * Ny haben'ny `len * mem::size_of::<T>()` an'ny silaka dia tsy tokony ho lehibe noho `isize::MAX`.
///   Jereo ny antontan-taratasy fiarovana an'ny [`pointer::offset`].
///
/// # Caveat
///
/// Ny androm-piainan'ilay sombin-tsakafo niverina dia resahina amin'ny fampiasana azy.
/// Mba hisorohana ny fanararaotana tsy nahy, soso-kevitra ny hamatotra ny androm-piainany amin'izay loharanom-pahalalana azo antoka azo antoka ao anaty, toy ny fanomezana anjara asa fanampiana izay maka lanja mandritra ny androm-piainana ho an'ny silaka, na amin'ny fanamarihana mazava.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // maneho slice ho an'ny singa iray
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Fampiasana diso
///
/// Ity fiasa `join_slices` manaraka ity dia **tsy marim-pototra** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Ny filazana ambony miantoka `fst` sy `snd` dia contiguous, fa mety mbola ho hita ao anatin'ny _different allocated objects_, izay famoronana tranga ity dia tsy voafaritra silaka fitondran-tena.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ary `b` dia omena zavatra hafa ...
///     let a = 42;
///     let b = 27;
///     // ... izay mety hapetraka eo am-pahatsiarovana ihany anefa: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Manatanteraka fampiasa mitovy amin'ny [`from_raw_parts`], afa-tsy ny sombin-tsolika miverina no averina.
///
/// # Safety
///
/// Ny fitondran-tena dia tsy voafaritra raha misy ny mandika ireo fepetra manaraka ireto:
///
/// * `data` tokony ho [valid] ho an'ny roa mamaky ary manoratra ho `len * mem::size_of::<T>()` byte maro, ary tsy maintsy ampifanarahana tsara.Midika manokana izany:
///
///     * Ny haben'ny fahatsiarovana iray manontolo amin'ity sombin-kazo ity dia tsy maintsy ao anaty zavatra iray natokana!
///       Ny slices dia tsy afaka mamakivaky zavatra maro natokana.
///     * `data` dia tsy maintsy atao tsy mivoana ary mifanaraka na dia amin'ny sombina lava aza.
///     Ny antony iray mahatonga an'io dia ny fanamafisana ny famolavolana enum dia mety hiankina amin'ny fanovozan-kevitra (ao anatin'izany ny sombina amin'ny halavany rehetra) mifanaraka sy tsy azo foanana hanavahana azy ireo amin'ny angona hafa.
///
///     Azonao atao ny mahazo pointer izay azo ampiasaina ho `data` ho an'ny sombina lava aotra mampiasa [`NonNull::dangling()`].
///
/// * `data` dia tsy maintsy manondro ny `len` misesy araka ny tokony ho karazana initialized soatoavin'ny `T`.
///
/// * Ny fahatsiarovana notondroin'ny silaka niverina dia tsy tokony hiditra amin'ny alàlan'ny tondro hafa (tsy azo avy amin'ny sanda miverina) mandritra ny androm-piainana `'a`.
///   Samy namaky teny sy nanoratra accesses dia voarara.
///
/// * Ny haben'ny `len * mem::size_of::<T>()` an'ny silaka dia tsy tokony ho lehibe noho `isize::MAX`.
///   Jereo ny antontan-taratasy fiarovana an'ny [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: ny miantso dia tsy maintsy manohana ny fifanarahana fiarovana ho an'ny `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Manova ny fanondroana an'i T ho sombina amin'ny halavany 1 (tsy adika).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Manova ny fanondroana an'i T ho sombina amin'ny halavany 1 (tsy adika).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}