use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Ny wrapper ny manakana compiler avy niantso avy hatrany: ny destructor T`.
/// Ity wrapper dia 0-vola.
///
/// `ManuallyDrop<T>` dia iharan'ny fanatsarana endrika mitovy amin'ny `T`.
/// Vokatr'izany dia tsy misy fiatraikany * amin'ny fiheverana ataon'ny mpanangona momba ny atiny.
/// Ohatra, ny fanombohana `ManuallyDrop<&mut T>` misy [`mem::zeroed`] dia fihetsika tsy voafaritra.
/// Raha toa ka mila ny hiatrehana uninitialized angon-drakitra, fa tsy mampiasa [`MaybeUninit<T>`].
///
/// Mariho fa tena ilaina ao anatin'ny fahazoana ny `ManuallyDrop<T>` voavonjy.
/// Midika izany fa afa-po `ManuallyDrop<T>` izay efa nihena dia tsy maintsy amin'ny alalan'ny tsy ho hita ampahibemaso API azo antoka.
/// Correspondingly, `ManuallyDrop::drop` dia azo antoka.
///
/// # `ManuallyDrop` ary handao ny filaminana.
///
/// Rust manana voafaritra tsara [drop order] ny soatoavina.
/// Mba hahazoana antoka fa saha na ny an-toerana dia nandatsaka manokana mba, reorder ny fanambarana fa toy ny rano indray mitete tanteraka mba no marina iray ihany.
///
/// Azo atao ny mampiasa `ManuallyDrop` hifehy ny rano indray mitete mba, fa mampidi-doza mila izany fehezan-dalàna sy ny no Sarotra ny Manao tsara eo anatrehan'ny Ny fanajanonana.
///
///
/// Ohatra, raha te mba hahazoana antoka fa ny saha manokana dia nilatsaka araka ny hafa, ataovy ny saha farany ny struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` hilatsaka aorian'ny `children`.
///     // Rust saha dia manome antoka fa nandatsaka ny baikon'i fanambarana.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Fonosy soatoavina tokony haidina tanana.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Afaka Mbola miasa soa aman-tsara ny zava-dehibe
    /// assert_eq!(*x, "Hello");
    /// // Fa `Drop` dia tsy ho hihazakazaka eto
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Voajanahary koa omen'ny ny vidiny avy amin'ny `ManuallyDrop` fitoeran-javatra.
    ///
    /// Izany dia mamela ny zava-dehibe ho nandatsaka indray.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Izany nilatsaka ny `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Maka ny vidiny avy amin'ny `ManuallyDrop<T>` fitoeran-javatra avy.
    ///
    /// Io fomba no tena natao ho an'ny toetra mifindra avy amin'ny mitete.
    /// Raha tokony mampiasa tanana [`ManuallyDrop::drop`] mba handao ny zava-dehibe, dia afaka mampiasa fomba izany mba handray ny lanja sy ny mampiasa azy io anefa irina.
    ///
    /// Raha azo atao, dia tsaratsara kokoa ny mampiasa [`into_inner`][`ManuallyDrop::into_inner`] fa, izay misakana kopia ny afa-po ny `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ity asa ity dia mamindra ny sanda misy ary tsy misoroka ny fampiasana bebe kokoa, mamela ny fanjakan'ity kaontenera ity tsy miova.
    /// Izany no andraikitra mba hahazoana antoka fa `ManuallyDrop` dia tsy ampiasaina intsony.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // Famonjena, mamaky isika avy amin'ny boky, izay azo antoka
        // manankery amin'ny famakiana.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Arotsaho amin'ny tanana ny sanda misy.Izany mihitsy mitovy amin'ny niantso [`ptr::drop_in_place`] miaraka amin'ny manondro ny voarakitra sarobidy.
    /// Araka izany, raha ny hita dia feno vidy struct, ny destructor dia hatao hoe in-toerana tsy mihetsika ny lanjany, ary dia toy izany no azo ampiasaina soa aman-tsara handao [pinned] angona.
    ///
    /// Raha manana tompon'ny zava-dehibe ianao, dia afaka mampiasa [`ManuallyDrop::into_inner`] fa tsy.
    ///
    /// # Safety
    ///
    /// Izany asa mitantana ny destructor ny voarakitra sarobidy.
    /// Hafa noho ny fanovana ataon'ny destructor mihitsy, ny fahatsiarovana niova ihany no sisa, ary toy izany hatrany ny momba ny compiler mbola manana kely-endrika izay tsy manan-kery ho an'ny karazana `T`.
    ///
    ///
    /// Na izany aza, izany "zombie" sarobidy tokony tsy ho hita ny fehezan-dalàna soa aman-tsara, ary ity asa tsy tokony hatao hoe mihoatra ny indray mandeha.
    /// Hampiasa ny zava-dehibe rehefa ny efa nandatsaka, tokony hamotsotra ny sanda imbetsaka, mety Undefined Behavior (arakaraka izay no `drop`).
    /// Izany no tokony nisakana ny karazana rafitra, fa ny mpampiasa dia tsy maintsy manohana ireo `ManuallyDrop` antoka tsy misy fanampiana avy amin'ny compiler.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // Famonjena, isika nandatsaka ny vidiny Nanondro amin'ny alalan'ny boky mutable
        // izay azo antoka ho manan-kery ho an'ny manoratra.
        // Dia niakatra ho any amin'ny mpiantso mba hahazoana antoka fa tsy `slot` nitete intsony.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}