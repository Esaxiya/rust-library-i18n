//! Fototra asan'ny for rehefa mifandray amin'ny fahatsiarovana.
//!
//! Zavatra tsy mikendry misy asa ho an'ny querying ny habeny sy ny fampifanarahana ny karazana, nitranga teo am-ary mampiasa fahatsiarovana.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Mila tompony sy "forgets" momba ny lanja **tsy mihazakazaka ny destructor**.
///
/// Izay mety ho zava-dehibe mitantana harena, toy ny antontan-javatra ny antontan-taratasy fitadidiana na tahony, dia maharitra mandrakizay ao amin'ny fanjakana iresahana.Na izany aza, dia tsy manome antoka fa sahaza ho fahatsiarovana io dia manan-kery foana.
///
/// * Raha te-mandefa fahatsiarovana, dia jereo ny [`Box::leak`].
/// * Raha te-hahazo tondro mora amin'ny fahatsiarovana ianao dia jereo ny [`Box::into_raw`].
/// * Raha te-hanary sanda ara-dalàna ianao, alefaso ny mpanimba azy, jereo [`mem::drop`].
///
/// # Safety
///
/// `forget` Tsy marika toy ny `unsafe`, satria Rust antoka ny fiarovana dia tsy ahitana ny antoka fa ho foana destructors hiezaka.
/// , Ohatra, ny fandaharana dia afaka mamorona boky tsingerin'ny mampiasa [`Rc`][rc], na miantso [`process::exit`][exit] ny fivoahana tsy mihazakazaka destructors.
/// Noho izany, ny famelana `mem::forget` avy amin'ny kaody azo antoka dia tsy manova ifotony ny antoka fiarovana Rust.
///
/// Izany dia nilaza fa ny loharano mivoaka toy ny fahatsiarovana na zavatra I/O dia matetika no tsy ilaina.
/// Ny filàna dia mipoitra amin'ny tranga fampiasana manokana ho an'ny FFI na kaody tsy azo antoka, nefa na dia izany aza, [`ManuallyDrop`] dia aleony matetika.
///
/// Satria nanadino ny lanjan'izy ireo dia namela, misy `unsafe` no manoratra fehezan-dalàna dia tsy maintsy mamela ny mety izany.Tsy afaka mamerina sanda ianao ary manantena fa ny mpiantso dia hitarika ny mpanimba ny sandany.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ny azo antoka kanônika fampiasana ny `mem::forget` dia nandingana ny zava-dehibe ny destructor napetraky ny `Drop` trait.Izany, ohatra, no mandefa ny `File`, izany hoe
/// avereno ny habaka nalain'ny variable fa aza hanidy ny loharanom-pahefana.
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ilaina io rehefa nafindra tamin'ny kaody ivelan'ny Rust ny fananana ilay loharano fototra, ohatra, amin'ny alàlan'ny fandefasana ilay mpanazava rakitra ao amin'ny kaody C.
///
/// # Fifandraisana amin'i `ManuallyDrop`
///
/// Raha `mem::forget` Azo ampiasaina mba hamindra *fahatsiarovana* tompony, manao toy izany ny diso-mora.
/// [`ManuallyDrop`] tokony hampiasaina kosa.Diniho, ohatra, ity kaody ity:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Hanao `String` mampiasa ny votoatin'ny `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // mandefa `v` satria ny fahatsiarovana ankehitriny mitantana `s`
/// mem::forget(v);  // ERROR, v Tsy mety sy ny tsy ho lasa ho any amin'ny asa
/// assert_eq!(s, "Az");
/// // `s` dia tanteraka nihena sy ny fahatsiarovana deallocated.
/// ```
///
/// Misy olana roa amin'ny ohatra etsy ambony:
///
/// * Raha fehezan-dalàna bebe kokoa dia nanampy teo amin'ny fanorenana ny `String` sy ny fiantsoana ny `mem::forget()`, ny panic ao dia mety hiteraka roa maimaim-poana, satria iray ihany no ampiasaina fahatsiarovana ny samy `v` sy `s`.
/// * Rehefa avy niantso `v.as_mut_ptr()` sy fampitana ny tompon'ny angon-drakitra ho any amin'ny `s`, ny `v` sarobidy dia tsy manan-kery.
/// Na dia misy zava-dehibe no vao nifindra tany `mem::forget` (izay tsy maso izany), ny sasany dia manana karazana fepetra henjana eo amin'ny soatoavina izay mahatonga azy ireo tsy manan-kery, rehefa nihantona na tsy fananan'ny.
/// Ny fampiasana soatoavina tsy mety amin'ny fomba rehetra, ao anatin'izany ny fandefasana azy ireo na famerenana azy ireo amin'ny asany, dia fihetsika tsy voafaritra ary mety hanaparitaka ireo fiheverana nataon'ny mpanangom-baovao.
///
/// Ny fiovana amin'ny `ManuallyDrop` dia misoroka ireo olana roa ireo:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Alohan'ny disassemble `v` ho ny manta toko, ho azo antoka fa tsy hahazo nandatsaka!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Disassemble `v` ankehitriny.Ireo asa tsy afaka panic, ka dia tsy afaka ny ho iray mandefa.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Farany, hanorina `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` dia tanteraka nihena sy ny fahatsiarovana deallocated.
/// ```
///
/// `ManuallyDrop` manakana mafy ny maimaimpoana avo roa heny noho ny fanafoanana ny `` v '' mpanimba alohan'ny hanaovana zavatra hafa.
/// `mem::forget()` tsy mamela an'io satria mandany ny tohan-keviny, manery antsika hiantso azy raha tsy aorian'ny fitrandrahana izay ilaintsika amin'ny `v`.
/// Na dia panic aza dia nampidirina teo anelanelan'ny fananganana `ManuallyDrop` sy ny fananganana kofehy (izay tsy mety hitranga amin'ny kaody araka ny aseho) dia hiteraka fivoahana izany fa tsy maimaimpoana indroa.
/// Raha lazaina amin'ny teny hafa, `ManuallyDrop` dia diso amin'ny sisin'ny fivoahana fa tsy diso amin'ny sisin'ny (midina) mitete.
///
/// Ary koa, `ManuallyDrop` dia manakana antsika tsy hanana "touch" `v` aorian'ny famindrana ny fananana mankany `s`-ny dingana farany amin'ny fifandraisana amin'ny `v` hanary azy io nefa tsy mihazakazaka ny mpanimba azy.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Toy ny [`forget`], nefa koa manaiky sanda tsy voamarika.
///
/// Ity fiasa ity dia shim fotsiny natao hongotana rehefa mihamafy ny endri-javatra `unsized_locals`.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Mamerina ny haben'ny karazana bytes.
///
/// Raha ny tena marimarina kokoa, ity no offset amin'ny bytes eo anelanelan'ny singa mifandimby ao anaty laharana miaraka amin'ilay karazana entana ao anatin'izany ny padding alignment.
///
/// Noho izany, ho an'ny karazana `T` sy ny halavany `n`, `[T; n]` dia manana habe `n * size_of::<T>()`.
///
/// Amin'ny ankapobeny, ny haben'ny karazana iray dia tsy marin-toerana amin'ny famoronana, fa ny karazany manokana toy ny primitives dia.
///
/// Ity tabilao manaraka ity dia manome ny habeny ho an'ny primitives.
///
/// Karazana |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 Char |4
///
/// Ankoatr'izay, `usize` sy `isize` dia mitovy habe aminy.
///
/// Ny karazany `*const T`, `&T`, `Box<T>`, `Option<&T>`, ary `Option<Box<T>>` dia samy manana ny habeny.
/// Raha lehibe ny `T` dia mitovy amin'ny `usize` daholo ireo karazana rehetra ireo.
///
/// Ny fiovan'ny mpanondro dia tsy manova ny habeny.Araka izany, `&T` sy `&mut T` dia mitovy habe aminy.
/// Toy izany koa ho an'ny `*const T` sy `* mut T`.
///
/// # Haben'ny entana `#[repr(C)]`
///
/// Ny solontenan'ny `C` ho an'ny entana dia manana lamina voafaritra.
/// Miaraka amin'ity fisehosehoana ity dia milamina ihany koa ny haben'ny entana raha toa ka manana habe marin-toerana ny saha rehetra.
///
/// ## Haben'ny firafitra
///
/// Ho an'ny `structs`, ny habeny dia voafaritr'ity algorithm manaraka ity.
///
/// Ho an'ny saha tsirairay amin'ny rafitra baiko nomen'ny baiko fanambaràna:
///
/// 1. Ampio ny haben'ny saha.
/// 2. Ahodino ny habe amin'izao fotoana izao ho an'ny maro hafa akaikin'ny [alignment] amin'ny saha manaraka.
///
/// Farany, boribory ny haben'ny strany mankany amin'ny maro indrindra amin'ny [alignment].
/// Ny fampifanarahana ny estr dia matetika ny fampifanarahana lehibe indrindra amin'ny sehatra rehetra ao aminy;ity dia azo ovaina amin'ny fampiasana `repr(align(N))`.
///
/// Tsy toy ny `C`, ny zoro zotra zero dia tsy boribory hatramin'ny iray byte ny habeny.
///
/// ## Haben'ny Enum
///
/// Ireo enum izay tsy mitondra data hafa ankoatry ny manavakavaka dia manana habe mitovy amin'ny enum C amin'ny sehatra izay nanangonana azy ireo.
///
/// ## Haben'ny Sendika
///
/// Ny haben'ny sendika dia ny haben'ny saha lehibe indrindra ao aminy.
///
/// Tsy toy ny `C`, ny sindika zero dia tsy boribory hatramin'ny iray byte ny habeny.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Misy primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Ny sasany milahatra
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Manondro habe fitoviana
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Mampiasa `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ny haben'ny voalohany tanimbary dia 1, ka manampy 1 amin'ny habeny.Size dia 1.
/// // Ny fampifanarahana ny saha faharoa dia 2, koa ampio 1 amin'ny habe ho an'ny padding.Ny habe dia 2.
/// // Ny haben'ny tanimbary dia ny faharoa 2, ka manampy 2 ny habe.Size dia 4.
/// // Ny fampifanarahana ny saha fahatelo dia 1, koa ampio 0 ny habe ho an'ny padding.Ny habe dia 4.
/// // Ny haben'ny ny tanimbary dia 1 fahatelo, ka manampy 1 amin'ny habeny.Size dia 5.
/// // Farany, ny fampifanarahana ny struct dia 2 (satria ny lehibe indrindra anivon fampifanarahana ny saha dia 2), ka manampy 1 amin'ny habe ho padding.
/// // 6 ny habeny.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs manaraka fitsipika mitovy.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Mariho fa reordering ny saha dia afaka hampidina ny habeny.
/// // Afaka manala na padding oktety amin'ny alalan'ny fametrahana `third` teo anatrehan'i `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union habeny dia ny haben'ny ny lehibe indrindra an-tsaha.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Miverina ny haben'ny sanda tondro-to amin'ny bytes.
///
/// Matetika io dia mitovy amin'ny `size_of::<T>()`.
/// Na izany aza, rehefa `T`*tsy manana* habe fantatry ny statically, ohatra, ny slice [`[T]`][slice] na [trait object], dia azo ampiasaina ny `size_of_val` hahazoana ny habeny fantatry ny dynamika.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` dia referansa, noho izany dia mpanondro manta mety
    unsafe { intrinsics::size_of_val(val) }
}

/// Miverina ny haben'ny sanda tondro-to amin'ny bytes.
///
/// Matetika io dia mitovy amin'ny `size_of::<T>()`.Na izany aza, rehefa `T`*tsy manana* haben'ny statically-fantatra, ohatra, ny slice [`[T]`][slice] na [trait object], dia azo ampiasaina ny `size_of_val_raw` hahazoana ny habeny fantatry ny dynamika.
///
/// # Safety
///
/// Ity fiasa ity dia azo antoka ihany raha hiantsoana raha toa ka mihazona ireto fepetra manaraka ireto:
///
/// - Raha `Sized` dia `Sized`, dia azo antoka ny miantso an'io fiasa io hatrany.
/// - Raha ny unsized rambony ny `T` dia:
///     - [slice], avy eo ny halavan'ny rambony dia tokony ho integer voaloham-bokatra, ary ny haben'ny *sanda iray manontolo*(halavan'ny rambony mirindra + aorinan'ny refy statically) dia tsy maintsy ampidirina ao amin'ny `isize`.
///     - [trait object], avy eo ny ampahany mahitsy amin'ny tondro dia tsy maintsy manondro latabatra manan-kery azo avy amin'ny fanerena tsy mihozongozona, ary ny haben'ny *lanja iray manontolo*(halavan'ny rambony lava + aorinan'ny refy statically) dia tokony hipetraka ao amin'ny `isize`.
///
///     - (unstable) [extern type], dia azo antoka io antso io fa miantso foana, fa mety panic na raha tsy izany dia hamerina ny sandany ratsy, satria tsy fantatra ny firafitry ny karazana extern.
///     Io dia fihetsika mitovy amin'ny [`size_of_val`] amin'ny firesahana karazana iray misy rambony ivelany.
///     - raha tsy izany, dia tsy mahazo conservatively hiantso asa ity.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: ny miantso dia tsy maintsy manome pointer manta mety
    unsafe { intrinsics::size_of_val(val) }
}

/// Miverina ny fampifanarahana farafahakeliny fampiasa amin'ny karazana [ABI].
///
/// Ny referansa rehetra amin'ny sanda `T` dia tokony ho maromaro amin'ity isa ity.
///
/// Ity no fampifanarahana ampiasaina amin'ny sehatry ny str.Mety ho kely kokoa noho ny fampifanarahana tianao izy io.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Miverina ny fampifanarahana farafahakeliny [ABI] izay ilaina amin'ny karazana ny sanda izay tondroin'i `val`.
///
/// Ny referansa rehetra amin'ny sanda `T` dia tokony ho maromaro amin'ity isa ity.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: referansy ny val, noho izany dia mpanondro manta mety
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Miverina ny fampifanarahana farafahakeliny fampiasa amin'ny karazana [ABI].
///
/// Ny referansa rehetra amin'ny sanda `T` dia tokony ho maromaro amin'ity isa ity.
///
/// Ity no fampifanarahana ampiasaina amin'ny sehatry ny str.Mety ho kely kokoa noho ny fampifanarahana tianao izy io.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Miverina ny fampifanarahana farafahakeliny [ABI] izay ilaina amin'ny karazana ny sanda izay tondroin'i `val`.
///
/// Ny referansa rehetra amin'ny sanda `T` dia tokony ho maromaro amin'ity isa ity.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: referansy ny val, noho izany dia mpanondro manta mety
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Miverina ny fampifanarahana farafahakeliny [ABI] izay ilaina amin'ny karazana ny sanda izay tondroin'i `val`.
///
/// Ny referansa rehetra amin'ny sanda `T` dia tokony ho maromaro amin'ity isa ity.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ity fiasa ity dia azo antoka ihany raha hiantsoana raha toa ka mihazona ireto fepetra manaraka ireto:
///
/// - Raha `Sized` dia `Sized`, dia azo antoka ny miantso an'io fiasa io hatrany.
/// - Raha ny unsized rambony ny `T` dia:
///     - [slice], avy eo ny halavan'ny rambony dia tokony ho integer voaloham-bokatra, ary ny haben'ny *sanda iray manontolo*(halavan'ny rambony mirindra + aorinan'ny refy statically) dia tsy maintsy ampidirina ao amin'ny `isize`.
///     - [trait object], avy eo ny ampahany mahitsy amin'ny tondro dia tsy maintsy manondro latabatra manan-kery azo avy amin'ny fanerena tsy mihozongozona, ary ny haben'ny *lanja iray manontolo*(halavan'ny rambony lava + aorinan'ny refy statically) dia tokony hipetraka ao amin'ny `isize`.
///
///     - (unstable) [extern type], dia azo antoka io antso io fa miantso foana, fa mety panic na raha tsy izany dia hamerina ny sandany ratsy, satria tsy fantatra ny firafitry ny karazana extern.
///     Io dia fihetsika mitovy amin'ny [`align_of_val`] amin'ny firesahana karazana iray misy rambony ivelany.
///     - raha tsy izany, dia tsy mahazo conservatively hiantso asa ity.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: ny miantso dia tsy maintsy manome pointer manta mety
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Miverina `true` raha mandatsaka soatoavina amin'ny karazana `T`.
///
/// Soso-kevitra fanatsarana fotsiny io, ary azo ampiharina amin'ny fomba nentin-drazana:
/// mety hiverina `true` ho an'ireo karazana izay tsy mila arotsaka izany.
/// Raha toa ka miverina hatrany `true` dia mety ho fampiharana an'io asa io.Na izany aza raha toa ka miverina `false` ity fiasa ity dia azonao antoka fa tsy misy vokany ratsy ny mandao `T`.
///
/// Ny fampiharana ambany ny zavatra toy ny fanangonana, izay mila mandatsaka an-tanana ny angon-drakitra, dia tokony hampiasa io asa io mba hialana amin'ny fanandramana mandatsaka ny atiny rehetra rehefa simba izy ireo.
///
/// Mety tsy hitondra fahasamihafana amin'ny fananganana famoahana izany (izay tadiavina ary esorina mora foana ny loop izay tsy misy voka-dratsiny), nefa matetika no fandresena lehibe ho an'ny fananganana debug.
///
/// Mariho fa [`drop_in_place`] dia efa nanao an'io fanamarinana io, ka raha azo ahena ho vitsy kely ny antso [`drop_in_place`] ny enta-mavesatrao dia tsy ilaina izany.
/// Mariho manokana fa afaka [`drop_in_place`] silaka ianao, ary izany dia hanao fanamarinana ilaina_drop tokana ho an'ny sanda rehetra.
///
/// Ireo karazana toa ny Vec dia `drop_in_place(&mut self[..])` fotsiny nefa tsy mampiasa `needs_drop` mazava.
/// Ireo karazana toa ny [`HashMap`], etsy ankilany, dia tsy maintsy mandatsaka soatoavina tsirairay avy ary tokony hampiasa an'ity API ity.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ity misy ohatra iray momba ny fomba fampiasan'ny fanangonana `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // alatsaho ny angona
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Miverina ny sandan'ny karazana `T` soloin'ny lamina byte-zero rehetra.
///
/// Midika izany fa, ohatra, ny byte padding ao amin'ny `(u8, u16)` dia tsy voatery ho aotra.
///
/// Tsy misy antoka azo antoka fa ny maodely byte zero rehetra dia maneho lanja mety amin'ny karazana `T` sasany.
/// Ohatra, ny lamina byte rehetra-zero dia tsy sanda manan-kery ho an'ny karazana fanovozan-kevitra (`&T`, `&mut T`) sy ny tondro fiasa.
/// Ny fampiasana `zeroed` amin'ny karazana toy izany dia miteraka [undefined behavior][ub] eo noho eo satria ny [the Rust compiler assumes][inv] izay misy valiny manan-kery foana ao anaty variable izay heveriny fa voalohany.
///
///
/// Misy vokany mitovy amin'ny [`MaybeUninit::zeroed().assume_init()`][zeroed] izany.
/// Ilaina amin'ny FFI izy io indraindray, saingy tokony hialana amin'ny ankapobeny.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Fampiasana marina an'io fiasa io: fanombohana integer miaraka amin'ny aotra.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Tsy mety* fampiasana an'io fiasa io: fanombohana referansa misy aotra.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Undefined fitondran-tena!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ary averiko indray!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: ny miantso dia tsy maintsy manome antoka fa ny sanda nolavina rehetra dia manan-kery ho an'ny `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypass Rust dia fanamarinana fanombohana fahatsiarovana ara-dalàna amin'ny alàlan'ny mody mamokatra sanda `T`, nefa tsy manao na inona na inona mihitsy.
///
/// **Tsy miasa io fiasa io.** Mampiasà [`MaybeUninit<T>`] fa tsy.
///
/// Ny anton'ny fanilihana dia ny fiasa tsy azo ampiasaina tsara: manana ny vokany mitovy amin'ny [`MaybeUninit::uninit().assume_init()`][uninit] izy io.
///
/// Raha ny fanazavan'i [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] izay sanda dia voalahatra araka ny tokony ho izy.
/// Vokatr'izany, miantso eg
/// `mem::uninitialized::<bool>()` miteraka fihetsika tsy voafaritra eo noho eo noho ny famerenana `bool` izay tsy dia hoe `true` na `false`.
/// Ny fahatsiarovan-tena ratsy kokoa, tena tsy voalamina toy ny tafaverina eto dia manokana satria fantatry ny mpanangom-baovao fa tsy manana sanda raikitra izy io.
/// Izany dia mahatonga azy ho tsy voafaritra fihetsika manana angon-drakitra tsy voamarika anaty variable na dia manana integer karazana aza io variable io.
/// (Mariho fa ny fitsipika manodidina ny uninitialized integers tsy mbola nomanina, fa mandra-izy ireo, dia tokony hatao mba tsy azy ireo.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: ny miantso dia tsy maintsy miantoka fa ny sandan'ny unitial dia manan-kery ho an'ny `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ampifamadiho ny soatoavina amin'ny toerana roa azo ovaina, nefa tsy manafoana ny iray amin'izy ireo.
///
/// * Raha te hifanakalo amin'ny soatoavina default na dummy ianao dia jereo ny [`take`].
/// * Raha te hifanakalo amin'ny sanda lasa ianao, avereno ny sanda taloha, jereo [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SAFETY: ny tondro manta dia noforonina avy amin'ny loharanon-kevitra azo ovaina azo ovaina izay nahafa-po ny rehetra
    // teritery amin'ny `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Manolo ny `dest` amin'ny sanda default `T`, mamerina ny sanda `dest` teo aloha.
///
/// * Raha te hanolo ny sanda fiovana roa ianao dia jereo ny [`swap`].
/// * Raha te hisolo sanda lasa ianao fa tsy ny sanda default, dia jereo ny [`replace`].
///
/// # Examples
///
/// Ohatra tsotra:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` mamela ny fananana tompon'ny sehatra str amin'ny alàlan'ny fanoloana azy amin'ny sanda "empty".
/// Raha tsy misy `take` dia afaka mihazakazaka amin'ny olana toy ireto ianao:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Mariho fa ny `T` dia tsy voatery mampihatra [`Clone`], noho izany tsy afaka clone sy reset `self.buf` akory izy.
/// Fa `take` dia azo ampiasaina hanilihana ny sandan'ny `self.buf` tany am-boalohany avy amin'ny `self`, mamela azy io hiverina:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Mamindra ny `src` ao amin'ny `dest` voatondro, mamerina ny sanda `dest` teo aloha.
///
/// Samy tsy nilatsaka ny sanda.
///
/// * Raha te hanolo ny sanda fiovana roa ianao dia jereo ny [`swap`].
/// * Raha te hisolo sanda default ianao dia jereo [`take`].
///
/// # Examples
///
/// Ohatra tsotra:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` mamela ny fanjifana sehatra str amin'ny alàlan'ny fanoloana azy amin'ny sanda hafa.
/// Raha tsy misy `replace` dia afaka mihazakazaka amin'ny olana toy ireto ianao:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Mariho fa ny `T` dia tsy voatery hampihatra [`Clone`], noho izany tsy azontsika atao ny mi-clone `self.buf[i]` hisorohana ny hetsika.
/// Fa ny `replace` dia azo ampiasaina hanilihana ny sanda am-boalohany tamin'io index io avy amin'ny `self`, mamela azy io hiverina:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Mamaky ny `dest` izahay fa manoratra mivantana `src` ao anatiny avy eo,
    // toy izany ny soatoavina taloha dia tsy averina.
    // Tsy misy zavatra milatsaka ary tsy misy eto panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Fandroahana soatoavina.
///
/// Izany dia manao izany amin'ny fiantsoana ny fampiharana ny adihevitra momba ny [`Drop`][drop].
///
/// Izany dia tsy manao na inona na inona amin'ny karazana mampihatra `Copy`, ohatra
/// integers.
/// Ny sanda toy izany dia adika ary ny _then_ dia nafindra tao amin'ny lahasa, noho izany dia mitohy ny soatoavina aorian'ity antso ity.
///
///
/// Tsy majika io fiasa io;faritana ara-bakiteny hoe
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Satria nifindra tao amin'ilay asany ny `_x`, nilatsaka ho azy izy alohan'ny hiverenan'ny asa.
///
/// [drop]: Drop
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // Mitete mivantana ny vector
/// ```
///
/// Koa satria [`RefCell`] dia mampihatra ny lalàna findramam-bola indramina, `drop` dia afaka mamoaka findramana [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // hamoy ny mutable Borrow izany slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ny integer sy ny karazana fampiharana [`Copy`] dia tsy voakasiky ny `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // ny dika mitovy ny `x` dia nifindra ka nandatsaka
/// drop(y); // ny dika mitovy ny `y` dia nifindra ka nandatsaka
///
/// println!("x: {}, y: {}", x, y.0); // mbola misy
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Mandika ny `src` ho manana karazana `&U`, ary avy eo mamaky `src` nefa tsy mihetsika ny sanda voarakitra ao.
///
/// Ity fiasa ity dia hihevitra fa tsy azo antoka ny pointer `src` fa manan-kery ho an'ny [`size_of::<U>`][size_of] bytes amin'ny alàlan'ny fandefasana `&T` ka `&U` ary avy eo mamaky ny `&U` (ankoatr'izay dia vita amin'ny fomba marina izany na dia `&U` aza dia mitaky fepetra henjana kokoa noho ny `&T`).
/// Izy io koa dia hamorona tsy ampoizina kopian'ny sanda misy ao anatiny fa tsy hivoaka ny `src`.
///
/// Tsy lesoka fanangonana fotoana raha toa ka samy hafa ny haben'ny `T` sy `U`, saingy tena entanina ny hanao io fiasa io izay misy ny `T` sy `U` mitovy habe aminy.Io fiasa io dia mitarika [undefined behavior][ub] raha toa ka lehibe kokoa noho `T` ny `U`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Adikao ny angona avy 'foo_array' ka hitondra azy ho toy ny 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Hanova ny dika tahirin-kevitra
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Ny votoatin'ny 'foo_array' tsy tokony ho niova
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Raha manana fitakiana fampifanarahana ambony i U, dia mety tsy hifanaraka tsara i src.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` dia referansa izay azo antoka fa mitombina amin'ny famakiana.
        // Ny miantso dia tsy maintsy manome antoka fa azo antoka ny fandefasana azy.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` dia referansa izay azo antoka fa mitombina amin'ny famakiana.
        // Izahay dia nanamarina fotsiny fa mifanaraka tsara i `src as *const U`.
        // Ny miantso dia tsy maintsy manome antoka fa azo antoka ny fandefasana azy.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Karazana opaque maneho ny fanavakavahana enum.
///
/// Zahao ny asan'ny [`discriminant`] amin'ity modely ity raha mila fanazavana fanampiny.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ireo fampiharana trait ireo dia tsy azo alaina satria tsy mila fetrany amin'ny T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Miverina sanda manokana mampiavaka ny enum variant ao amin'ny `v`.
///
/// Raha tsy enum ny `T` dia tsy hiteraka fihetsika tsy voafaritra ny fiantsoana an'io fiasa io fa tsy voafaritra kosa ny sandan'ny fiverenana.
///
///
/// # Stability
///
/// Ny fanavakavahana karazana enum dia mety miova raha miova ny famaritana enum.
/// Ny fanavakavahana variant sasany dia tsy hiova eo amin'ny compilations miaraka amin'ilay compiler mitovy.
///
/// # Examples
///
/// Azo ampiasaina izy io hampitahana ireo enum izay mitondra data, nefa tsy miraharaha ny tena angona:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Mamerina ny isan'ny karazany ao amin'ny karazana enum `T`.
///
/// Raha tsy enum ny `T` dia tsy hiteraka fihetsika tsy voafaritra ny fiantsoana an'io fiasa io fa tsy voafaritra kosa ny sandan'ny fiverenana.
/// Toy izany koa, raha `T` dia enum misy karazany hafa noho ny `usize::MAX` dia tsy voafaritra ny sandan'ny fiverenana.
/// Hisaina ireo variant tsy misy mponina.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}