use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Ny wrapper karazana mba hanorina uninitialized ohatra ny `T`.
///
/// # Initialization invariant
///
/// Ny compiler, amin'ny ankapobeny, mieritreritra fa ny miova dia araka ny tokony ho initialized araka ny fepetra ny miova ny karazana.Ohatra, ny miova ny boky tsy maintsy mifanaraka ny karazana sy ny tsy-tohivakana foana.
/// Ity dia invariant izay tsy maintsy tandrovina * foana, na dia fehezan-dalàna tsy azo antoka aza.
/// Vokatr'izany, aotra-nitranga teo am-miova ny boky iray karazana mahatonga instantaneous [undefined behavior][ub], na raha mbola mahazo ny boky ampiasaina amin'ny fidirana fitadidiana:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // fihetsika tsy voafaritra!⚠️
/// // Ny kaody mitovy amin'ny `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // fihetsika tsy voafaritra!⚠️
/// ```
///
/// Izany dia nohararaotin'ny ny compiler ho an'ny isan-karazany optimizations, toy ny hazakazaka eliding-taratasim-bola sy fotoana optimizing `enum` fisehon'ny.
///
/// Toy izany koa, ny memoire uninitialized tanteraka dia mety misy atiny, raha `bool` dia tsy maintsy `true` na `false` foana.Noho izany, dia mamorona ny uninitialized `bool` dia tsy voafaritra fitondran-tena:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // fihetsika tsy voafaritra!⚠️
/// // Ny kaody mitovy amin'ny `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // fihetsika tsy voafaritra!⚠️
/// ```
///
/// Ankoatra izany, dia fahatsiarovana uninitialized manokana ao fa tsy manana sanda raikitra ("fixed" midika hoe "it won't change without being written to").Toy izany koa ny famakiana ny uninitialized byte fotoana maro samihafa afaka manome valiny.
/// Izany no mahatonga azy ho manana fitondran-tena tsy voafaritra uninitialized angon-drakitra ao amin'ny miova na dia miova manana integer karazana, izay raha tsy izany dia afaka mihazona na kely *raikitra* lamina:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // fihetsika tsy voafaritra!⚠️
/// // Ny fehezan-dalàna mitovy amin'ny `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // fihetsika tsy voafaritra!⚠️
/// ```
/// (Mariho fa ny fitsipika manodidina ny uninitialized integers tsy mbola nomanina, fa mandra-izy ireo, dia tokony hatao mba tsy azy ireo.)
///
/// Ankoatra izany, dia tadidio fa ny ankamaroan'ny karazana manana invariants fanampiny mihoatra fotsiny heverina ho karazana initialized amin'ny ambaratonga.
/// Ohatra, ny `1`-initialized [`Vec<T>`] heverina initialized (eo ambanin'ny fampiharana amin'izao fotoana izao, izany dia tsy anisan'ny antoka marin-toerana) satria ny hany fepetra takiana ny compiler mahalala izany dia ny angon-drakitra dia tsy maintsy ho tsy manondro-tohivakana foana.
/// Ny famoronana `Vec<T>` toy izany dia tsy miteraka fihetsika tsy voafaritra * eo noho eo, fa hiteraka fihetsika tsy voafaritra miaraka amina asa azo antoka indrindra (ao anatin'izany ny fandatsahana azy).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` dia mamela ny kaody tsy azo antoka hiatrehana ireo angona tsy voatanisa.
/// Izany dia tsato-kazo famantarana ho an'ny compiler manondro fa ny angona eto mety *tsy* ho initialized:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Hamorona ny mazava uninitialized Reference.
/// // Ny compiler dia mahafantatra fa ao anatin'ny tahirin-kevitra iray mba ho tsy manan-kery `MaybeUninit<T>`, ka noho izany dia tsy Ub:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Apetraho amin'ny sanda mety.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Hanesorana ny initialized akora-izany ihany no navela *taorian'ny* araka ny tokony ho nitranga teo am-`x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Ny compiler dia mahalala ny tsy manao tombantombana diso na optimizations ao amin'ny fehezan-dalàna io.
///
/// Afaka mieritreritra ny `MaybeUninit<T>` toy ny kely toy ny `Option<T>` fa tsy misy ny hazakazaka amin'ny fotoana ampy sy tsy misy ny fiarovana taratasim-bola.
///
/// ## out-pointers
///
/// Azonao atao ny mampiasa `MaybeUninit<T>` hampihatra "out-pointers": fa tsy hamerina angon-drakitra avy amina lahasa iray dia alefaso tondro ho an'ny fahatsiarovana (uninitialized) vitsivitsy hametrahana ny valiny.
/// Izany dia mety ho ilaina rehefa zava-dehibe ho an'ny mpiantso ny fanaraha-maso ny fomba ny fahatsiarovana ny vokatra dia voatahiry ao vokany omena, ka te-tsy ilaina hetsika.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` tsy handao taloha anatiny, izay zava-dehibe.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ary fantatsika `v` dia initialized!Izany koa dia mahatonga vokany antoka ny vector araka ny tokony ho nandatsaka.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Nitranga teo am-ny fihaingoana singa-by-singa
///
/// `MaybeUninit<T>` Azo ampiasaina initialize lehibe nahay singa-by-singa:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Hamorona ny uninitialized nahay ny `MaybeUninit`.
///     // Ny `assume_init` no azo antoka satria ny karazana milaza isika fa initialized eto dia bunch ny: MaybeUninit`s, izay tsy mitaky initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Nandatsaka ny `MaybeUninit` manao na inona na inona.
///     // Noho izany ny fampiasana ny fanondroana pointer manta fa tsy `ptr::write` dia tsy mahatonga ny soatoavina taloha tsy voadidy.
/////
///     // Koa raha misy manome fitoerana panic mandritra ity, manana fitadidiana mandefa, nefa tsy misy fahatsiarovana fiarovana olana.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Ny zava-drehetra dia initialized.
///     // Transmute ny fihaingoana ho an'ny initialized karazana.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Azonao atao koa ny miara-miasa amin'ny ampahany initialized arrays, izay mety ho hita ao amin'ny ambaratonga ambany-datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Hamorona ny uninitialized nahay ny `MaybeUninit`.
/// // Ny `assume_init` no azo antoka satria ny karazana milaza isika fa initialized eto dia bunch ny: MaybeUninit`s, izay tsy mitaky initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Isao ny isan'ny singa efa nanendrena.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Ho an'ny zavatra tsirairay ao amin'ny fihaingoana Mitete raha omena azy.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Nitranga teo am-tsaha ny struct-by-saha
///
/// Afaka mampiasa `MaybeUninit<T>`, ary ny [`std::ptr::addr_of_mut`] macro, mba initialize structs saha amin'ny saha:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Nitranga teo am-tsaha `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Nitranga teo am-tsaha `list` Raha misy panic eto, dia ny `String` any an-tsaha amin'ny `name` tete azo.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Ny saha rehetra dia voalahatra, ka miantso `assume_init` izahay mba hahazoana Foo voalohany.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` Azo antoka mba manana habe toy izany koa, fampifanarahana, sy Abi tahaka `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Na izany aza tadidio fa ny karazana *misy*`MaybeUninit<T>` dia tsy voatery hitovy endrika;Rust tsy amin'ny ankapobeny no antoka fa ny saha iray mitovy `Foo<T>` mba ho toy ny `Foo<U>` na dia `T` sy `U` manana ny mitovy habe sy ny fampifanarahana.
///
/// Koa satria misy vidiny kely dia manan-kery ho an'ny `MaybeUninit<T>` ny compiler tsy afaka mampihatra non-zero/niche-filling optimizations, mety niteraka habe lehibe kokoa:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Raha `T` dia FFI-azo antoka, dia toy izany ny `MaybeUninit<T>`.
///
/// Raha `MaybeUninit` no `#[repr(transparent)]` (milaza azy io ihany no miantoka ny habeny, fampifanarahana, sy Abi ho `T`), ity no *tsy* manova akory va ny teo aloha ny fampitandremana aorina.
/// `Option<T>` ary `Option<MaybeUninit<T>>` mety mbola manana habe samihafa, ary misy karazana saha ny karazana `T` mba halevina avy (sy salantsalany) raha tsy mitovy amin'ny saha dia `MaybeUninit<T>`.
/// `MaybeUninit` dia karazana firaisana, ary `#[repr(transparent)]` amin'ny sendika tsy milamina (jereo [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Rehefa mandeha ny fotoana, ny tena antoka ny `#[repr(transparent)]` amin'ny sendika dia mety nivoatra, ary `MaybeUninit` mety, na mba tsy hitoetra `#[repr(transparent)]`.
/// Izay nanao hoe: `MaybeUninit<T>` dia foana * * antoka fa manana ny mitovy habe, fampifanarahana, sy Abi ho `T`;izany fotsiny fa ny fomba fitaovana `MaybeUninit` antoka fa mba nivoatra.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang zavatra mba hahafahantsika mamatotra karazany hafa ao aminy.Ilaina amin'ny mpamokatra herinaratra izany.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Tsy niantso `T::clone()`, tsy afaka mahafantatra raha toa isika initialized ampy ho amin'izany.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Mamorona vaovao initialized `MaybeUninit<T>` ny vidiny nomena.
    /// Tsy azo antoka ny miantso [`assume_init`] ny fiverenan'ny asa sarobidy io.
    ///
    /// Mariho fa nandatsaka ny `MaybeUninit<T>` dia tsy hoe: T` ny fehezan-dalàna mitete.
    /// Izany no andraikitra mba hahazoana antoka `T` nilatsaka vokany raha natao initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Mamorona vaovao uninitialized `MaybeUninit<T>` amin'ny fanjakana.
    ///
    /// Mariho fa nandatsaka ny `MaybeUninit<T>` dia tsy hoe: T` ny fehezan-dalàna mitete.
    /// Izany no andraikitra mba hahazoana antoka `T` nilatsaka vokany raha natao initialized.
    ///
    /// Jereo ny [type-level documentation][MaybeUninit] nandritra ny ohatra.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Mamorona vaovao `MaybeUninit<T>` nahay ny zavatra, amin'ny uninitialized fanjakana.
    ///
    /// Note: amin'ny kinova future Rust ity fomba ity dia mety tsy ho ilaina intsony rehefa mamela ny [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ny syntax literal.
    ///
    /// Ny ohatra etsy ambany dia afaka mampiasa `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Miverina iray (mety ho kelikely kokoa) silaka tahirin-kevitra izay raha ny marina mamaky
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // Famonjena, Ny uninitialized `[MaybeUninit<_>; LEN]` no manan-kery.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Mamorona vaovao uninitialized `MaybeUninit<T>` amin'ny fanjakana, miaraka amin'ny fahatsiarovana ho feno `0` oktety.Miankina amin'ny `T` raha efa vita ny fanombohana araka ny tokony ho izy.
    ///
    /// , Ohatra, dia initialized `MaybeUninit<usize>::zeroed()`, nefa `MaybeUninit<&'static i32>::zeroed()` tsy noho ny andinin-tsoratra masina dia tsy maintsy tsy tohivakana foana.
    ///
    /// Mariho fa nandatsaka ny `MaybeUninit<T>` dia tsy hoe: T` ny fehezan-dalàna mitete.
    /// Izany no andraikitra mba hahazoana antoka `T` nilatsaka vokany raha natao initialized.
    ///
    /// # Example
    ///
    /// Hanitsy ny fampiasana izany asa: nitranga teo am-ny struct amin'ny aotra, izay rehetra saha momba ny struct dia afaka mihazona ny kely-modely 0 ho toy ny zava-dehibe manan-kery.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Diso* fampiasana ity asa: miantso `x.zeroed().assume_init()` rehefa `0` dia tsy manan-kery kely-lamina ho an'ny karazana:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inside roa, dia mamorona `NotZero` izay tsy manana discriminant manan-kery.
    /// // Izany dia fihetsika tsy voafaritra.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // Famonjena, `u.as_mut_ptr()` manondro omena fahatsiarovana.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Mamaritra ny hasarobidin'ny ny `MaybeUninit<T>`.
    /// Izany overwrites misy vidiny teo aloha tsy nandatsaka izany, ka mitandrema tsy hampiasa izany avo roa heny raha tsy te-dinganina nihazakazaka ny destructor.
    ///
    /// Mba tsy hanahirana anao, koa izany miverina ny mutable momba ny (soa aman-tsara ankehitriny initialized) votoatin'ny `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAFETY: Vao nanomboka ity sanda ity izahay.
        unsafe { self.assume_init_mut() }
    }

    /// Nahazo ny manondro ny voarakitra sarobidy.
    /// Famakiana avy amin'izany manondro na mamadika azy io ho boky dia tsy voafaritra fitondran-tena, raha tsy ny `MaybeUninit<T>` dia initialized.
    /// Nanoratra ho fahatsiarovana fa manondro (non-transitively) hevitra ny fitondran-tena dia tsy voafaritra (afa-tsy ao anatin'ny iray `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Fampiasana tsara an'io fomba io:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Mamorona boky ho any an-`MaybeUninit<T>`.Izany no ekena satria initialized izany.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Diso* fampiasana ity fomba fiasa:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Efa namorona momba ny uninitialized vector!Izany no fitondran-tena tsy voafaritra.️
    /// ```
    ///
    /// (Mariho fa ny fitsipika manodidina ny andinin-tsoratra masina amin'ny angon-drakitra uninitialized tsy mbola nomanina, fa mandra-izy ireo, dia tokony hatao mba tsy azy ireo.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ary `ManuallyDrop` Samy `repr(transparent)` mba hahafahantsika hanipy manondro.
        self as *const _ as *const T
    }

    /// Nahazo mutable manondro ny voarakitra sarobidy.
    /// Famakiana avy amin'izany manondro na mamadika azy io ho boky dia tsy voafaritra fitondran-tena, raha tsy ny `MaybeUninit<T>` dia initialized.
    ///
    /// # Examples
    ///
    /// Fampiasana tsara an'io fomba io:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Mamorona referansa ao amin'ny `MaybeUninit<Vec<u32>>`.
    /// // Izany no ekena satria initialized izany.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Diso* fampiasana ity fomba fiasa:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Efa namorona momba ny uninitialized vector!Izany no fitondran-tena tsy voafaritra.️
    /// ```
    ///
    /// (Mariho fa ny fitsipika manodidina ny andinin-tsoratra masina amin'ny angon-drakitra uninitialized tsy mbola nomanina, fa mandra-izy ireo, dia tokony hatao mba tsy azy ireo.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ary `ManuallyDrop` Samy `repr(transparent)` mba hahafahantsika hanipy manondro.
        self as *mut _ as *mut T
    }

    /// Voajanahary koa omen'ny ny vidiny avy amin'ny `MaybeUninit<T>` fitoeran-javatra.Izany no fomba lehibe mba hahazoana antoka fa ny antontan-kevitra no hatao nandatsaka, satria ny vokatry `T` dia manaiky ny mahazatra indray mitete fikirakirana.
    ///
    /// # Safety
    ///
    /// Dia niakatra ho any amin'ny mpiantso ho antoka fa ny `MaybeUninit<T>` tena amin'ny initialized fanjakana.Niantso izany rehefa mbola tsy afa-po tanteraka avy hatrany initialized antony tsy voafaritra fitondran-tena.
    /// Ny [type-level documentation][inv] dia misy fampahalalana bebe kokoa momba ity invariant fanombohana ity.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ankoatra izany, dia tadidio fa ny ankamaroan'ny karazana manana invariants fanampiny mihoatra fotsiny heverina ho karazana initialized amin'ny ambaratonga.
    /// Ohatra, ny `1`-initialized [`Vec<T>`] heverina initialized (eo ambanin'ny fampiharana amin'izao fotoana izao, izany dia tsy anisan'ny antoka marin-toerana) satria ny hany fepetra takiana ny compiler mahalala izany dia ny angon-drakitra dia tsy maintsy ho tsy manondro-tohivakana foana.
    ///
    /// Ny famoronana `Vec<T>` toy izany dia tsy miteraka fihetsika tsy voafaritra * eo noho eo, fa hiteraka fihetsika tsy voafaritra miaraka amina asa azo antoka indrindra (ao anatin'izany ny fandatsahana azy).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Fampiasana tsara an'io fomba io:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Diso* fampiasana ity fomba fiasa:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` tsy mbola initialized mbola, ka izany no nahatonga tsy voafaritra tsipika farany fitondran-tena.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // Famonjena, ny mpiantso antoka fa tsy maintsy `self` no initialized.
        // Izany dia midika ihany koa fa tsy maintsy ho `self` `value` Variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Mamaky ny zava-dehibe avy amin'ny `MaybeUninit<T>` fitoeran-javatra.Ny `T` vokatr'izany dia iharan'ny fikirakirana mahazatra.
    ///
    /// Raha azo atao, dia tsaratsara kokoa ny mampiasa [`assume_init`] fa, izay misakana kopia ny afa-po ny `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Dia niakatra ho any amin'ny mpiantso ho antoka fa ny `MaybeUninit<T>` tena amin'ny initialized fanjakana.Niantso izany rehefa mbola tsy afa-po tanteraka initialized fitondran-tena antony tsy voafaritra.
    /// Ny [type-level documentation][inv] dia misy fampahalalana bebe kokoa momba ity invariant fanombohana ity.
    ///
    /// Ankoatra izany, ity ny dika mitovy ny ravina koa ny angon-drakitra latsaka amin'ny `MaybeUninit<T>`.
    /// Rehefa mampiasa dika mitovy maro ny tahirin-kevitra (tamin'ny fiantsoana `assume_init_read` imbetsaka, na ny voalohany ary avy eo niantso `assume_init_read` [`assume_init`]), dia ny andraikitra mba hahazoana antoka fa ny angon-drakitra mba tokoa no hita.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Fampiasana tsara an'io fomba io:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` dia `Copy`, ka mety mamaky imbetsaka.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Kopia ny `None` sarobidy dia Eny, noho izany dia afaka mamaky imbetsaka.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Diso* fampiasana ity fomba fiasa:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Isika roa izao namorona dika mitovy iray ihany vector, nitarika ho roa-maimaim-poana ⚠️ rehefa roa get nandatsaka!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // Famonjena, ny mpiantso antoka fa tsy maintsy `self` no initialized.
        // Famakiana avy `self.as_ptr()` no azo antoka satria `self` tokony initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Nilatsaka ny voarakitra danja eo amin'ny toerany.
    ///
    /// Raha manana tompon'ny amin'ny `MaybeUninit`, azonao ampiasaina fa tsy [`assume_init`].
    ///
    /// # Safety
    ///
    /// Dia niakatra ho any amin'ny mpiantso ho antoka fa ny `MaybeUninit<T>` tena amin'ny initialized fanjakana.Niantso izany rehefa mbola tsy afa-po tanteraka initialized fitondran-tena antony tsy voafaritra.
    ///
    /// Ankoatra izany, hafa rehetra invariants ny karazana `T` tsy maintsy afa-po, toy ny `Drop` fampiharana `T` (na ny mpikambana) Mety hiantehitra amin'ity.
    /// Ohatra, ny `1`-initialized [`Vec<T>`] heverina initialized (eo ambanin'ny fampiharana amin'izao fotoana izao, izany dia tsy anisan'ny antoka marin-toerana) satria ny hany fepetra takiana ny compiler mahalala izany dia ny angon-drakitra dia tsy maintsy ho tsy manondro-tohivakana foana.
    ///
    /// Nandatsaka izany `Vec<T>` tsy voafaritra anefa ny hahatonga ny fitondran-tena.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // Famonjena, ny mpiantso antoka fa tsy maintsy `self` dia initialized sy
        // mahafapo ny invariants rehetra an'ny `T`.
        // Nandatsaka ny manampy eo amin'ny toerana azo antoka, raha izany no izy.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Nahazo nizara momba ny voarakitra sarobidy.
    ///
    /// Izany dia mety ho ilaina rehefa te-mahazo ny `MaybeUninit` izay efa initialized kanefa tsy manana tompon'ny amin'ny `MaybeUninit` (fisorohana ny fampiasana ny `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Niantso izany rehefa mbola tsy afa-po tanteraka initialized antony tsy voafaritra fitondran-tena izany, ka dia niakatra ho any amin'ny mpiantso ho antoka fa ny `MaybeUninit<T>` tena amin'ny initialized fanjakana.
    ///
    ///
    /// # Examples
    ///
    /// ### Fampiasana tsara an'io fomba io:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialize `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Izao fa ny `MaybeUninit<_>` fantatra ho initialized, dia ekena ny hananganana nizara momba azy;
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // Famonjena, `x` efa initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Diso* fomba fanaon'ny fomba ity:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Efa namorona momba ny uninitialized vector!Izany no fitondran-tena tsy voafaritra.️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialize ny `MaybeUninit` mampiasa `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Reference ho amin'ny uninitialized `Cell<bool>`: Ub!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // Famonjena, ny mpiantso antoka fa tsy maintsy `self` no initialized.
        // Izany dia midika ihany koa fa tsy maintsy ho `self` `value` Variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Nahazo mutable (unique) momba ny voarakitra sarobidy.
    ///
    /// Izany dia mety ho ilaina rehefa te-mahazo ny `MaybeUninit` izay efa initialized kanefa tsy manana tompon'ny amin'ny `MaybeUninit` (fisorohana ny fampiasana ny `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Niantso izany rehefa mbola tsy afa-po tanteraka initialized antony tsy voafaritra fitondran-tena izany, ka dia niakatra ho any amin'ny mpiantso ho antoka fa ny `MaybeUninit<T>` tena amin'ny initialized fanjakana.
    /// Ohatra, `.assume_init_mut()` dia tsy azo ampiasaina hanombohana `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Fampiasana tsara an'io fomba io:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initializes *rehetra* ny oktety amin'ny fahan'ny buffer.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ary fantatsika fa `buf` efa initialized, mba hahafahantsika `.assume_init()` izany.
    /// // Na izany aza, dia mety nahatonga an'ilay bibidia `.assume_init()` mampiasa ny `memcpy` 'ny 2048 oktety.
    /// // To milaza ny buffer efa initialized tsy fandikana azy io isika, dia hanatsarana ny `&mut MaybeUninit<[u8; 2048]>` amin'ny `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // Famonjena, `buf` efa initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ankehitriny dia afaka mampiasa `buf` ara-dalàna ho toy ny silaka:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Diso* fomba fanaon'ny fomba ity:
    ///
    /// Tsy afaka mampiasa `.assume_init_mut()` mba initialize ny zava-dehibe:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Efa namorona (mutable) momba ny uninitialized `bool`!
    ///     // Izany dia fihetsika tsy voafaritra.⚠️
    /// }
    /// ```
    ///
    /// Ohatra, tsy afaka ho any an-uninitialized [`Read`] buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) momba uninitialized fahatsiarovana!
    ///                             // Izany no fitondran-tena tsy voafaritra.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Tsy afaka mampiasa ny fidirana mivantana saha manao tao-by-tsaha tsikelikely initialization:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) momba uninitialized fahatsiarovana!
    ///                  // Izany no fitondran-tena tsy voafaritra.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) momba uninitialized fahatsiarovana!
    ///                  // Izany no fitondran-tena tsy voafaritra.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Izahay amin'izao fotoana izao miantehitra amin'ny ambony ho diso, izany hoe, manana andinin-tsoratra masina ho uninitialized tahirin-kevitra (ohatra, ao amin'ny `libcore/fmt/float.rs`).
    // Tokony handray fanapahan-kevitra farany momba ny lalàna isika alohan'ny hampiorenana azy.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // Famonjena, ny mpiantso antoka fa tsy maintsy `self` no initialized.
        // Izany dia midika ihany koa fa tsy maintsy ho `self` `value` Variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Voajanahary koa omen'ny ny soatoavina avy amin'ny nahay ny `MaybeUninit` kaontenera.
    ///
    /// # Safety
    ///
    /// Anjaran'ny miantso ny miantoka fa ny singa rehetra amin'ny laharam-pahamehana dia ao anaty fanjakana voalahatra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // Famonjena, Ary soa aman-tsara rehefa initialised singa rehetra
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Ny mpiantso antoka fa singa rehetra ao amin'ny fihaingoana no initialized
        // * `MaybeUninit<T>` ary T azo antoka fa ho toy izany no fisehon'ny
        // * MaybeUnint tsy Mitete, ka tsy misy roa-manafaka Ary dia toy izany ny fiovam-po dia azo antoka
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Mihevitra ho manana ny singa rehetra dia initialized, mahazo silaka ho azy ireo.
    ///
    /// # Safety
    ///
    /// Dia niakatra ho any amin'ny mpiantso mba antoka fa ny `MaybeUninit<T>` singa tena dia amin'ny initialized fanjakana.
    ///
    /// Ny fiantsoana an'io raha mbola tsy voalahatra tanteraka ny atiny dia miteraka fihetsika tsy voafaritra.
    ///
    /// Jereo [`assume_init_ref`] ho an'ny antsipirihany bebe kokoa sy ny ohatra.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // Famonjena, nanarato silaka ny `*const [T]` no azo antoka satria ny mpiantso antoka fa
        // `slice` dia initialized, and`MaybeUninit` Azo antoka mba mitovy ny fisehon'ny ho `T`.
        // Manondro azo dia manan-kery satria manondro ny fahatsiarovana nanana ny `slice` izay ny boky, ary dia toy izany no antoka ho manan-kery ho an'ny mamaky.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Mihevitra ho manana ny singa rehetra dia initialized, mahazo mutable silaka ho azy ireo.
    ///
    /// # Safety
    ///
    /// Dia niakatra ho any amin'ny mpiantso mba antoka fa ny `MaybeUninit<T>` singa tena dia amin'ny initialized fanjakana.
    ///
    /// Ny fiantsoana an'io raha mbola tsy voalahatra tanteraka ny atiny dia miteraka fihetsika tsy voafaritra.
    ///
    /// Jereo [`assume_init_mut`] ho an'ny antsipirihany bebe kokoa sy ny ohatra.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // Famonjena, fiarovana toy ny naoty ho an'ny `slice_get_ref`, fa manana
        // mutable koa ny boky izay azo antoka ho manan-kery ho an'ny manoratra.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Nahazo ny manondro ny singa voalohany ny fihaingoana.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Nahazo mutable manondro ny singa voalohany ny fihaingoana.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Dika mitovy ny singa avy amin'ny `src` ho `this`, niverina ny mutable momba ny ankehitriny initalized votoatin'ny `this`.
    ///
    /// Raha tsy mampihatra `Copy` ny `T` dia ampiasao [`write_slice_cloned`]
    ///
    /// Izany dia mitovy amin'ny [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Izany no asa panic raha ny roa slices manana halava samy hafa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Famonjena, isika vao adika ny singa rehetra ny Len ho any an-nanam fahafahana
    /// // singa voalohany src.len() ny već dia manan-kery ankehitriny.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // Famonjena,&[T] Ary&[MaybeUninit<T>] manana lamina mitovy
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAFETY: Ireo singa manan-kery dia efa nadikan'ny `this` ka napetraka
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones ny singa avy amin'ny `src` ho `this`, niverina ny mutable momba ny ankehitriny initalized votoatin'ny `this`.
    /// Izay singa efa niditra an-tsokosoko dia tsy hatsipy.
    ///
    /// Raha fitaovana `T` `Copy`, fampiasana [`write_slice`]
    ///
    /// Izany dia mitovy amin'ny [`slice::clone_from_slice`] nefa tsy handao efa misy singa.
    ///
    /// # Panics
    ///
    /// Izany no asa panic raha ny roa slices manana halava samy hafa izy na amin'ny fametrahana ny `Clone` panics.
    ///
    /// Raha misy panic, ny efa cloned singa ho nandatsaka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: vao avy namboarinay ireo singa rehetra an'ny len ao anaty fahafaha-manana
    /// // singa voalohany src.len() ny već dia manan-kery ankehitriny.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice tsy toy izany dia tsy miantso clone_from_slice eo amin'ny silaka izany dia satria tsy manatanteraka `MaybeUninit<T: Clone>` Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // Famonjena, silaka manta ity dia ahitana ihany no initialized zavatra
                // izany no mahatonga, dia avela handao azy.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Mila mivantana silaka azy ireo toy izany koa halavan'ny
        // ny fetra fanamarinana ho elided, ary ny optimizer dia hiteraka memcpy ho an'ny toe-javatra tsotra (ohatra T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // ilaina ny mpiambina b/c panic mety hitranga mandritra ny klone iray
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // Famonjena, Manan-kery singa Vao `this` voasoratra ho araka izany koa no initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}