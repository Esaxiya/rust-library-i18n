//! Module iray hiasa miaraka amin'ireo angona nindramina.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait amin'ny angona findramam-bola.
///
/// Ao Rust, dia mahazatra ny hanome fanehoana isan-karazany ny karazana ho an'ny fampiasana hafa tranga.
/// Ohatra, ny toerana fitehirizana sy ny fitantanana ny sanda iray dia azo fidina manokana raha ilaina amin'ny fampiasana manokana amin'ny alàlan'ny karazana pointer toa ny [`Box<T>`] na [`Rc<T>`].
/// Ankoatra ireo levitra wrappers izay azo ampiasaina amin'ny karazana rehetra, ny sasany tsy voatery manome karazana lafiny manome lafo mety miasa.
/// Ohatra iray ho toy izany no karazana [`String`] izay manampy ny fahafahana hanitatra ny tady ho any amin'ny fototra [`str`].
/// Izany dia mitaky tsy ilaina fitandremana fampahalalana fanampiny ho tsotra, loha tsy mety miova tady.
///
/// Ireo karazana manome fahafahana hahazo ny fototra amin'ny alalan'ny tahirin-kevitra mikasika ny karazana tahirin-kevitra izany.Voalaza fa 'nindrana' toy izany izy ireo.
/// Ohatra, [`Box<T>`] iray dia azo indramina amin'ny `T` raha [`String`] kosa azo indramina amin'ny `str`.
///
/// Types maneho fa azo nindramina araka izay ataon'ny sasany amin'ny alalan'ny fametrahana karazana `T` `Borrow<T>`, manome ny boky iray ao amin'ny trait `T` ny fomba [`borrow`].Ny karazana iray dia afaka mindrana maimaim-poana amin'ny karazany maro samihafa.
/// Raha maniry hindrana indramina amin'ny karazany izy-mamela ny angon-drakitra fototra hovaina, dia afaka mampihatra [`BorrowMut<T>`] fanampiny.
///
/// Ankoatra izany, rehefa manome implementations fanampiny traits, dia mila heverina raha toa ka tokony hitondra tena mitovy amin'ireo karazana ny fototra toy ny vokatry ny mitondra tena toy ny sarin 'ilay fototra karazana.
/// Generic kaody matetika dia mampiasa `Borrow<T>` rehefa miantehitra amin'ny fitondran-tena mitovy ireo trait fanampiny implementations.
/// Ireo traits dia mety hiseho ho trait bounds fanampiny.
///
/// Indrindra indrindra `Eq`, `Ord` sy `Hash` tsy maintsy mitovy ny nindramina, ary nanana toetra tsara: `x.borrow() == y.borrow()` tokony hanome ny vokatra ihany araka ny `x == y`.
///
/// Raha toa ka mila miasa amin'ny karazana rehetra afaka manome referansa ny karazana `T` mifandraika fotsiny ny kaody jeneraly dia matetika no tsara kokoa ny mampiasa [`AsRef<T>`] satria karazana maro kokoa no afaka mampihatra azy tsara.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Toy ny fanangonana antontan'isa, na [`HashMap<K, V>`] tompon'ny fanalahidy sy ny soatoavina.Raha ny tena manan-danja ny antontan-kevitra dia mifono ao anaty fitantanana karazana ny karazana, dia tokony, na izany aza, mbola tsy azo atao ny hitady zava-dehibe ny mampiasa ny momba ny manan-danja ny tahirin-kevitra.
/// Ohatra, raha ny fanalahidy dia laha-daza, dia azo inoana fa izany no voatahiry ny tenifototra sarintany toy ny [`String`], raha tokony ho azo atao ny mikaroka mampiasa [`&str`][`str`].
/// Noho izany, dia mila miasa `insert` amin'ny `String` `get` raha tokony ho afaka mampiasa ny `&str`.
///
/// Kely notsorina, ny mahasoa faritra `HashMap<K, V>` fijery toy izao:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // nesorina ny saha
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Ny sarintany hash iray manontolo dia iraisan'ny karazana `K` lehibe.Satria ireo fanalahidy ireo dia voatahiry ny tenifototra sarintany, io karazana tsy maintsy manana ny fanalahidy ny tahirin-kevitra.
/// Rehefa mampiditra mpivady manan-danja dia omena `K` toy izany ny sari-tany ary mila mahita ny siny hash tsara ary jereo raha efa eo ilay lakile mifototra amin'io `K` io.Noho izany dia mitaky `K: Hash + Eq`.
///
/// Rehefa mitady sanda amin'ny sarintany anefa, ny tsy maintsy hanomezana referansa `K` ho lakilen'ny fitadiavana dia mitaky famoronana soatoavina fananana toy izany hatrany.
/// Ho an'ny lakilen'ny string, midika izany fa tokony hatsangana ny soatoavina `String` ho an'ny fikarohana ireo tranga izay misy `str` fotsiny.
///
/// Kosa, ny fomba `get` no levitra noho ny karazana tahirin-kevitra manan-danja ny fototra, atao hoe `Q` amin'ny fomba sonian'ny ambony.Milaza izy fa `K` mindrana ho `Q` amin'ny fangatahana an'io `K: Borrow<Q>`.
/// By koa mitaky `Q: Hash + Eq`, dia famantarana ny fepetra takiana dia ny `K` sy `Q` manana implementations ny `Hash` sy `Eq` traits izay mamokatra vokatra mitovy.
///
/// Ny fampiharana ny `get` miantehitra indrindra indrindra amin'ny mitovy implementations ny `Hash` Tapa-kevitra ny manan-danja ny hash siny amin'ny fiantsoana `Hash::hash` ny `Q` sarobidy na dia nampidirina ny fanalahidy mifototra amin'ny vidiny ny tenifototra kajy avy amin'ny `K` sarobidy.
///
///
/// Vokatr'izany, ny tenifototra Map fiatoana raha `K` fanehoany ny `Q` miteraka sarobidy hafa noho ny `Q` hash.Ohatra, sary an-tsaina manana karazana izay Fonosiny ny laha-daza, fa mampitaha marika ASCII taratasy tsy miraharaha ny raharaha:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Satria mitovy toetra roa mila mamokatra izany hash sarobidy, ny fametrahana ny `Hash` mila miraharaha marika ASCII raharaha koa:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Afaka mampihatra `Borrow<str>` ve `CaseInsensitiveString`?Azo antoka fa afaka manome andinin-tsoratra momba ny tadin'ny tady amin'ny alàlan'ny tady ao anatiny izy.
/// Saingy satria tsy mitovy ny fampiharana `Hash` dia tsy mitovy amin'ny `str` ny fitondran-tenany ary tsy tokony hampihatra ny `Borrow<str>`.
/// Raha te-hamela ny hafa fahafahana hahazo ny fototra `str`, dia afaka manao izany amin'ny alalan'ny `AsRef<str>` izay tsy hitondra fepetra fanampiny.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutably mindran avy amin'ny nanana sanda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait ho an'ny angon-drakitra mampindram-bola.
///
/// Amin'ny maha mpiara-miasa amin'ny [`Borrow<T>`] ity trait dia mamela karazana mindrana ho karazana fototra amin'ny alàlan'ny fanomezana referato azo ovaina.
/// Jereo [`Borrow<T>`] Raha mila fanazavana fanampiny momba mindrana ho karazana iray hafa.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutably mindran avy amin'ny nanana sanda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}