//! Primitive traits sy ny karazana fototra izay maneho toetra mampiavaka ny karazana.
//!
//! Rust karazana azo sokajiana amin'ny fomba isan-karazany ilaina araka ny anaty fananana.
//! Ireo sokajy ireo dia aseho ho traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Karazana izay azo nafindra manerana kofehy fetra.
///
/// Izany trait dia ampiharina avy hatrany rehefa compiler mamaritra izany tsara.
///
/// Ohatra iray ny tsy `Send` karazana dia ny boky-manondro [`rc::Rc`][`Rc`] manisa.
/// Raha misy kofehy roa manandrana handahatra ny [`Rc`] izay manondro ny sandan'ny isa voatanisa, dia mety manandrana manavao ny isa isaina izy ireo amin'ny fotoana iray, dia ny [undefined behavior][ub] satria tsy mampiasa fiasan'ny atomika ny [`Rc`].
///
/// Ny rahalahiko [`sync::Arc`][arc] no mampiasa atomika asa (mizaka ambony ny sasany), ary toy izany no `Send`.
///
/// Jereo [the Nomicon](../../nomicon/send-and-sync.html) ho an'ny antsipirihany bebe kokoa.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Types amin'ny habeny fantatra foana amin'ny fotoana manangona.
///
/// Masontsivana karazana rehetra manana voafehy tanteraka ny `Sized`.Ny `?Sized` Syntaxe manokana dia azo ampiasaina mba hanala izany voafehy raha ny tsy mety.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//hadisoana: salantsalany tsy ampiharina ho [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Ny iray miavaka dia ny tanteraka `Self` trait karazana iray.
/// A trait Tsy manana `Sized` tanteraka namatotra tahaka izany no tsy mifanaraka amin'ny [trait zavatra] s izay, amin'ny alalan'ny famaritana, ny trait mila asa rehetra azo atao implementors, ary dia toy izany izay mety ho habeny.
///
///
/// Rust na dia handefa anareo namatotra `Sized` amin'ny trait, dia tsy ho afaka hampiasa azy io mba hanangana trait zavatra tatỳ aoriana:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // avelao y: &dyn Bar= &Impl;//fahadisoana: ny trait `Bar` tsy azo atao ho toy ny zavatra
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ho Default, ohatra, izay mitaky ny `[T]: !Default` ho evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Karazana izay afaka ho "unsized" ny dynamically-salantsalany karazana.
///
/// Ohatra, ny salantsalany nahay `[i8; 2]` karazana manatanteraka `Unsize<[i8]>` sy `Unsize<dyn fmt::Debug>`.
///
/// Implementations ny `Unsize` rehetra dia nanome avy hatrany ny compiler.
///
/// `Unsize` dia ampiharina for:
///
/// - `[T; N]` dia `Unsize<[T]>`
/// - `T` dia `Unsize<dyn Trait>` rehefa `T: Trait`
/// - `Foo<..., T, ...>` dia `Unsize<Foo<..., U, ...>>` raha:
///   - `T: Unsize<U>`
///   - Foo dia rafitra iray
///   - Ihany ny sahan'i `Foo` farany dia manana karazana mahakasika `T`
///   - `T` dia tsy tafiditra ao anatin'ny karazana hafa saha
///   - `Bar<T>: Unsize<Bar<U>>`, raha ny saha farany `Foo` dia misy karazana `Bar<T>`
///
/// `Unsize` dia ampiasaina miaraka amin'ny [`ops::CoerceUnsized`] mba hamela "user-defined" fitoeran toy ny [`Rc`] mba misy karazana dynamically-salantsalany.
/// Jereo ny [DST coercion RFC][RFC982] sy [the nomicon entry on coercion][nomicon-coerce] raha mila fanazavana fanampiny.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Ilaina trait for constants ampiasaina amin'ny fomba lalao.
///
/// Izay mety ho karazana fa notsoahina `PartialEq` hatrany manatanteraka izany trait, * na inona na inona + ny na ny karazana-masontsivana mampihatra `Eq`.
///
/// Raha misy `const` entana dia ahitana karazana izay tsy hampiharana io trait, dia ny karazana na (1.) tsy manatanteraka `PartialEq` (izany hoe ny tsy tapaka dia tsy hanome izany fampitahana fomba, izay fehezan-dalàna taranaka jerena, dia hoatran'ny tsy ampy), na (2.) izany fitaovana + ny azy * dikan-`PartialEq` (izay mihevitra tsy manaraka ny ara-drafitra-fitoviana fampitahana).
///
///
/// Amin'ireo toe-javatra roa voalaza etsy ambony ireo dia lavinay ny fampiasana tsy tapaka toy izany amin'ny lalao mifandanja.
///
/// Jereo koa ny [structural match RFC][RFC1445], ary [issue 63438] izay nahatonga nifindra monina avy famolavolana toetra-monina izany trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Ilaina trait for constants ampiasaina amin'ny fomba lalao.
///
/// Izay mety ho karazana fa notsoahina `Eq` hatrany manatanteraka izany trait, * na inona na inona + ny karazana na ny masontsivana mampihatra `Eq`.
///
/// Izany dia Hack miasa manodidina ny fetra eo amin 'ny rafi-karazana.
///
/// # Background
///
/// Tiantsika ny mitaky fa ny karazana consts ampiasaina amin'ny fomba lalao manana ny toetra `#[derive(PartialEq, Eq)]`.
///
/// Ao amin'ny tontolo idealy kokoa dia azontsika atao ny manamarina izany fepetra izany amin'ny alàlan'ny fanamarinana fotsiny fa ny karazana nomena dia samy mampihatra ny `StructuralPartialEq` trait *sy* ny `Eq` trait.
/// Na izany aza, dia afaka manana ADTs izay *manao*`derive(PartialEq, Eq)`, ka ho raharaha fa tiantsika ny compiler hanaiky, nefa ny atolotra tsy tapaka ny karazana tsy mahavita manatanteraka `Eq`.
///
/// Izany hoe, ny tranga tahaka izao:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Ny olana ao amin'ny fehezan-dalàna ambony dia `Wrap<fn(&())>` tsy manatanteraka `PartialEq`, na `Eq`, satria: fa < 'a> fn(&'a _)` does not implement those traits.)
///
/// Noho izany, tsy afaka miantehitra vendrana seky `StructuralPartialEq` sy `Eq` fotsiny.
///
/// Ho toy ny hack hiasa manodidina izany, mampiasa traits roa natsindrona tsirairay izahay avy amin'ny (`#[derive(PartialEq)]` sy `#[derive(Eq)]`) roa ary manamarina fa eo izy roa ireo ao anatin'ny fizahana ny lalao.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Ireo karazana izay azo averina tahaka ny soatoavina amin'ny alàlan'ny fandikana bits fotsiny.
///
/// Ny toerana misy anao, miova bindings manana 'hetsika haneho hevitra.'Raha lazaina amin'ny fomba hafa:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` dia nifindra tao `y`, sy ny sisa tsy azo ampiasaina
///
/// // println! ("{: ?}", x);//diso: fampiasana ny Nifindra sarobidy
/// ```
///
/// Na izany aza, raha misy karazana mampihatra `Copy`, dia manana 'semantika mandika' kosa:
///
/// ```
/// // Afaka misintona ny `Copy` fampiharana.
/// // `Clone` ilaina ihany koa, araka izany ny supertrait ny `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` dia ny dika mitovy `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Zava-dehibe ny manamarika fa ireo ohatra roa, ny hany fahasamihafana dia, raha Hianao no mahazo miditra `x` taorian'ny fanendrena.
/// Eo ambanin'ny Hood, na ny dika mitovy sy hetsika mety hiteraka potika rehefa nadika ho fahatsiarovana, na dia izany indraindray optimisé izy.
///
/// ## Ahoana no ahafahako mampihatra `Copy`?
///
/// Misy fomba roa hampiharana `Copy` amin'ny karazanyo.Ny tsotra indrindra dia ny mampiasa `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Azonao atao ihany koa hampihatra `Copy` sy `Clone` tanana;
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Misy kely roa samy hafa: ny `derive` tetika ihany koa ny hametraka ny `Copy` voafehy tamin'ny karazany masontsivana, na dia tsy tiany foana.
///
/// ## Inona no maha samy hafa ny `Copy` sy `Clone`?
///
/// Mitranga dika mitovy tanteraka, ohatra ho ampahany amin'ny andraikitra `y = x`.Ny fitondran-tenan'ny `Copy` dia tsy be loatra;dia tsotra kely foana-boky hendry.
///
/// Ny kloning dia hetsika mazava, `x.clone()`.Ny fampiharana ny [`Clone`] dia afaka manome fitondran-tena manokana ilaina hamerina ny soatoavina soa aman-tsara.
/// Ohatra, ny fametrahana ny [`Clone`] for [`String`] mila mandika ny fefy-ny tady buffer ao amin'ny antontan-javatra.
/// Ny kopia bitwise kely misy lanja [`String`] dia handika fotsiny ny tondro, izay mitarika maimaimpoana avo roa heny.
/// Noho izany antony izany, dia [`Clone`] [`String`] fa tsy `Copy`.
///
/// [`Clone`] dia supertrait ny `Copy`, ka ny zavatra rehetra izay tsy maintsy manatanteraka `Copy` [`Clone`].
/// Raha misy karazana no `Copy` avy eo ny [`Clone`] fampiharana ihany no mila miverina `*self` (jereo ny ohatra etsy ambony).
///
/// ## Rahoviana no mety ho `Copy` ny karazana ahy?
///
/// Ny karazana dia afaka hametraka `Copy` raha ny singa rehetra mampihatra `Copy`.Izany, ohatra, dia afaka ny ho `Copy` struct:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Ny rafitra dia mety ho `Copy`, ary [`i32`] dia `Copy`, noho izany `Point` dia azo ekena ho `Copy`.
/// Mifanohitra amin'izany, diniho
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Ny struct `PointList` tsy afaka manatanteraka `Copy`, satria tsy [`Vec<T>`] `Copy`.Raha miezaka ny misintona ny `Copy` fampiharana, dia Ho hahazo fahadisoana:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Nizara ihany koa ny andinin-tsoratra masina (`&T`) `Copy`, Dia toy izany ny mety ho karazana `Copy`, na dia izy io no misy dia nizara soratra masina ny karazana `T` izay *tsy*`Copy`.
/// Diniho izao manaraka izao struct, izay afaka hametraka `Copy`, satria iray ihany no mihazona *nizara boky* antsika tsy `Copy` `PointList` karazana avy any ambony;
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Raha *tsy* ny karazana ho `Copy`?
///
/// Karazana sasany dia tsy azo adika soa aman-tsara., Ohatra, dia maka tahaka `&mut T` hamorona ny aliased mutable Reference.
/// Ny fakana tahaka ny [`String`] dia hamerina andraikitra amin'ny fitantanana ny buffer [`String`], izay mitarika fahalalahana roa.
///
/// Generalizing ny tranga farany, misy karazana fametrahana [`Drop`] tsy afaka ny ho `Copy`, satria ny fitantanana ireo loharanon-karena afa-tsy ny azy [`size_of::<T>`] oktety.
///
/// Raha miezaka ny fampiharana `Copy` amin'ny struct na enum misy tsy `Copy` tahirin-kevitra, dia hahazo ny fahadisoana [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Rehefa *tokony* ny karazana ho `Copy`?
///
/// Amin'ny ankapobeny, raha ny karazana _can_ hametraka `Copy`, dia tokony.
/// Tadidio anefa fa fampiharana `Copy` dia ampahany amin'ny API-bahoaka ny karazana.
/// Raha ny mety ho karazana tsy `Copy` ao amin'ny future, dia mety ho manan-tsaina, ny fampiharana nosoratan'i ny `Copy` ankehitriny, mba tsy ho ny fandikana API fiovana.
///
/// ## Mpanatanteraka fanampiny
///
/// Ankoatra ny [implementors listed below][impls], izao manaraka izao ihany koa ny karazana manatanteraka `Copy`:
///
/// * Karazan-tsarimihetsika (ohatra, ireo karazana voafaritra voafaritra isaky ny asany)
/// * Manondro asa karazana (ohatra, `fn() -> i32`)
/// * Array karazana, habe rehetra, raha toa ilay zavatra ihany koa ny karazana manatanteraka `Copy` (ohatra, `[i32; 123456]`)
/// * Tuple karazany, raha manatanteraka ihany koa ny singa tsirairay `Copy` (ohatra, `()`, `(i32, bool)`)
/// * Fanakatonana karazana, raha tsy nahafaka danja avy ny tontolo iainana, na raha toa izany babo rehetra soatoavina `Copy` mampihatra ny tenany.
///   Mariho fa hiovaova nalain'ny nizara boky manatanteraka mandrakariva `Copy` (na dia tsy manao ny referent), raha hiovaova voasambotra ny boky mutable tsy manatanteraka `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Izany dia mamela ny karazana maka izay tsy manatanteraka afa-po `Copy` noho ny androm-piainany fetra (maka tahaka ihany `A<'_>` rehefa `A<'static>: Copy` sy `A<'_>: Clone`).
// Manana toetra izany eto amin'izao fotoana izao ihany satria misy olona maro efa misy specializations amin'ny `Copy` izay efa misy ao amin'ny fitsipika fitehirizam-boky, ary tsy misy fomba fitondran-tena soa aman-tsara manana izany amin'izao fotoana izao.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Misintona macro niteraka ny impl ny trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Types izay dia azo antoka ny anjara andinin-tsoratra masina eo amin'ny kofehy.
///
/// Izany trait dia ampiharina avy hatrany rehefa compiler mamaritra izany tsara.
///
/// Ny famaritana marina dia: karazana `T` no [`Sync`] raha toa ka raha `&T` no [`Send`].
/// Amin'ny teny hafa, raha tsy misy mety [undefined behavior][ub] (anisan'izany ny angon-drakitra fifaninanana) rehefa mandalo `&T` andinin-tsoratra masina eo amin'ny kofehy.
///
/// Rehefa hisy antenaina, faran'izay tsotra toy ny karazana [`u8`] sy [`f64`] no [`Sync`] rehetra, ary toy izany koa ireo karazana aggregate tsotra misy azy ireo, toy ny tuples, structs sy enums.
/// Ohatra bebe kokoa amin'ny karazana [`Sync`] fototra dia misy ny karazana "immutable" toy ny `&T`, ary ireo izay manana fiovàna tsotra nolovaina, toy ny [`Box<T>`][box], [`Vec<T>`][vec] ary ny ankamaroan'ny karazana fanangonana hafa.
///
/// (Generic masontsivana tokony ho [`Sync`] ny fitoeran-javatra mba ho [: Sync`].)
///
/// Ny somary mahagaga vokatry ny ny famaritana ny hoe `&mut T` no `Sync` (raha `T` no `Sync`) na dia toa toy izay mety manome unsynchronized mutation.
/// Ny fitaka dia ny boky mutable ambadiky ny nizara boky (izany hoe `& &mut T`) lasa namaky-ihany, toy ny hoe ny `& &T`.
/// Noho izany tsy misy mety ny angon-drakitra hazakazaka.
///
/// Types izay tsy `Sync` dia ireo izay manana "interior mutability" ao amin'ny tsy-kofehy-teny azo antoka, toy ny [`Cell`][cell] sy [`RefCell`][refcell].
/// Ireo karazana mamela ny mutation ny anatiny na dia amin'ny alalan'ny iray loha tsy mety miova, nizara ny boky.
/// Ohatra ny amin'ny fomba `set` [`Cell<T>`][cell] maka `&self`, ka dia mitaky ihany nizara boky [`&Cell<T>`][cell].
/// Ny fomba tsy manatanteraka synchronization, dia toy izany no tsy afaka ny ho [`Cell`][cell] `Sync`.
///
/// Ohatra iray hafa ny tsy `Sync` karazana dia ny boky-manondro [`Rc`][rc] manisa.
/// Raha jerena ny boky misy [`&Rc<T>`][rc], dia afaka Clone [`Rc<T>`][rc] vaovao, manova ny boky mandritry ny fitsidihana amin'ny fomba tsy atomika.
///
/// Fa misy tranga, rehefa mila manao kofehy-azo antoka anatiny mutability, Rust manome [atomic data types], ary koa amin'ny alalan'ny [`sync::Mutex`][mutex] mazava Fanidiana sy [`sync::RwLock`][rwlock].
/// Ireo karazana antoka fa ny mutation tsy afaka mahatonga angon-drakitra firazanana, noho izany ny karazana no `Sync`.
/// Toy izany koa, [`sync::Arc`][arc] dia manome analogue azo antoka amin'ny [`Rc`][rc].
///
/// Izay mety ho karazana amin'ny mutability anatiny dia tsy maintsy ihany koa ny mampiasa ny [`cell::UnsafeCell`][unsafecell] wrapper manodidina ny value(s) izay azo mutated amin'ny alalan'ny boky nozaraina.
/// Tsy nahomby ny manao izany [undefined behavior][ub].
/// Ohatra, ny [`transmute`][transmute]-ing avy amin'ny `&T` mankany `&mut T` dia tsy mety.
///
/// Jereo [the Nomicon][nomicon-send-and-sync] ho an'ny antsipirihany bebe kokoa momba ny `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): indray mandeha fanohanana mba hametraka an-tsoratra ao amin'ny beta `rustc_on_unimplemented` tany izy, ary izany dia efa omena mba hahitana raha mba misy fanakatonana dia na aiza na aiza ao amin'ny fepetra rojo, manolotra izany ho toy izany (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Karazana Zero-size ampiasaina hanamarihana ireo zavatra izay "act like" ananany `T`.
///
/// Manampy ny saha `PhantomData<T>` ny karazana dia milaza ny compiler fa ny karazana na dia miasa toy ny mitahiry ny zava-dehibe ny karazana `T`, na dia tsy tena.
/// Io fanazavan io dia ampiasaina rehefa computing fiarovana fananana sasany.
///
/// Ahitana fanazavana fanampiny ao amin'ny lalina fanazavana ny fomba fampiasana `PhantomData<T>`, dia jereo [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Fanamarihana mahatsikaiky 👻👻👻
///
/// Na dia samy manana anarana mampatahotra aza izy ireo, `PhantomData` sy 'karazana phantom' dia mifandray, fa tsy mitovy.A phantom karazana fikirana fotsiny fikirana karazana izay tsy ampiasaina.
/// Ao amin'ny Rust, matetika io no mahatonga ny compiler hitaraina, ary ny vahaolana dia ny manampy "dummy" amin'ny alàlan'ny `PhantomData`.
///
/// # Examples
///
/// ## Miasa androm-piainany masontsivana
///
/// Angamba ny fampiasana mahazatra indrindra tranga for `PhantomData` dia struct Izay manan-maromaro fikirana androm-piainany, matetika ao anatin'ny fehezan-dalàna sasany mampidi-doza.
/// Ohatra, ity misy struct `Slice` izay manana mpanondro ny karazany roa `*const T`, heverina ho toy ny fihaingoana nanondro any ho any:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ny eritreritra dia hoe ny antontan-kevitra fototra ihany no manan-kery ho an'ny `'a` androm-piainany, ka tsy tokony `Slice` ela velona kokoa noho `'a`.
/// Na izany aza, izany fikasana dia tsy voalaza ao amin'ny fehezan-dalàna, satria tsy misy fampiasana 'ny androm-piainany, ary noho izany `'a` Tsy mazava inona no angon-drakitra izany mihatra.
/// Azontsika atao ny manitsy izany amin'ny alàlan'ny filazanao amin'ny compiler mba hiasa *toy ny hoe* ny `Slice` str dia misy referansa `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Izany koa dia mitaky kosa ny Filazana fohy `T: 'a`, midika izany fa misy andinin-tsoratra masina ao amin'ny `T` dia manan-kery noho ny androm-piainany `'a`.
///
/// Rehefa nitranga teo am-ny `Slice` manome anao fotsiny fa sarobidy ho an'ny an-tsaha `PhantomData` `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Karazana maromaro masontsivana
///
/// Izany no mitranga indraindray fa manana karazana masontsivana maromaro izay manondro inona no karazana tahirin-kevitra iray dia "tied" struct ny, na dia ny tahirin-kevitra dia tsy tena hita ao amin'ny struct mihitsy.
/// Indro misy ohatra iray izay miseho amin'ny [FFI] izany.
/// Ny vahiny interface tsara fampiasana karazana famohana `*mut ()` mba hilazana Rust soatoavin'ny samy hafa karazana.
/// Tsy manara-maso ny karazana Rust mampiasa karazana phantom fikirana ny struct `ExternalResource` izay Fonosiny ny tahony.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Fananana sy fanamarinana mitete
///
/// Manampy ny sehatry ny karazana `PhantomData<T>` dia mampiseho fa ny karazana manana ny karazana `T` angon-drakitra.Io indray dia midika fa rehefa milatsaka ny karazana anao dia mety handatsaka tranga iray na maromaro amin'ilay karazana `T`.
/// Izany dia manana akony eo amin'ny Rust [drop check] compiler ny fanadihadiana.
///
/// Raha tsy manao ny struct raha ny marina * * ny angon-drakitra manokana ny karazana `T`, fa tsara ny mampiasa ny karazana boky, toy ny `PhantomData<&'a T>` (ideally) na `PhantomData<*const T>` (raha tsy misy androm-piainany dia mihatra), ka tsy midika fananany.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-trait anaty ampiasana dia milaza ny karazana enum discriminants.
///
/// Ity trait dia ampiharina ho an'ny karazana rehetra ary tsy manampy antoka amin'ny [`mem::Discriminant`].
/// **Fihetsika tsy voafaritra** ny mamindra eo anelanelan'ny `DiscriminantKind::Discriminant` sy `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Ny karazana ny discriminant, izay tsy maintsy fahafaham-po ny trait bounds takian'ny `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-trait anaty ampiasaina mba hamaritana raha mba misy ahitana karazana misy `UnsafeCell` anatiny, nefa tsy amin'ny alalan'ny indirection.
///
/// Izany vokany eo, ohatra, raha mba misy `static` izany dia apetraka ao amin'ny karazana namaky-voasakantsakan'ny ihany no fahatsiarovana na voasakantsakan'ny writable fitadidiana.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Karazana izay azo soa aman-tsara rehefa avy nifindra mipaingotra.
///
/// Rust tsy misy hevitra mihitsy ny karazana voahozongozona, ka mihevitra moves (ohatra, amin'ny alalan'ny fanendrena na [`mem::replace`]) mba ho azo antoka foana.
///
/// Ny [`Pin`][Pin] karazany no ampiasaina fa tsy mba hisorohana ny karazana moves amin'ny alalan'ny rafitra.Mpanondro `P<T>` nofonosina tao amin'ny [`Pin<P<T>>`][Pin] wrapper tsy hihetsika avy.
/// Jereo ny tahirin-kevitra [`pin` module] mila fanazavana fanampiny momba pinning.
///
/// Fampiharana ny `Unpin` trait for `T` manandratra ny faneriterena ny pinning ho eo amin'ny karazana, izay nampihetsi-po dia mamela `T` avy tany [`Pin<P<T>>`][Pin] amin'ny asa toy ny [`mem::replace`].
///
///
/// `Unpin` tsy misy mihitsy vokatry ny tsy mipaingotra angona.
/// Indrindra indrindra, faly [`mem::replace`] manosika `!Unpin` tahirin-kevitra (tsy miasa na inona na inona `&mut T`, fa tsy hoe rehefa `T: Unpin`).
/// Na izany aza, tsy afaka mampiasa [`mem::replace`] amin'ny angon-drakitra nofonosina tao anaty [`Pin<P<T>>`][Pin] satria tsy afaka mahazo ny `&mut T` ho ilainao izany, ary *izay* no mampanan-tontolo ity asa.
///
/// Ary izany, ohatra, dia afaka ihany no hatao amin'ny karazana fampiharana `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Mila referable miovaova isika hiantsoana `mem::replace`.
/// // Afaka mahazo izany ny boky avy (implicitly) fanononany ny fiandrianam-`Pin::deref_mut`, fa izay ihany no azo atao, satria misy fitaovana `String` `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Izany trait dia ampiharina avy hatrany fa saika isan-karazana.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Ny karazana fanamarihana toerana izay tsy manatanteraka `Unpin`.
///
/// Raha misy `PhantomPinned` karazana dia tsy hampihatra azy tsy mihetsika `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementations ny `Copy` ho an'ny karazana faran'izay tsotra.
///
/// Ny fampiharana izay tsy azo faritana ao amin'ny Rust dia ampiharina amin'ny `traits::SelectionContext::copy_clone_conditions()` amin'ny `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Nizara andinin-tsoratra masina dia azo adika, fa mutable andinin-tsoratra masina *tsy*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}