//! - Miasa ny antokony sy ny fampitahana.
//!
//! Ity modely ity dia misy fitaovana isan-karazany amin'ny fandaminana sy fampitahana ny soatoavina.Raha fintinina:
//!
//! * [`Eq`] ary [`PartialEq`] no traits izay mamela anao mamaritra tanteraka sy ampahany fitoviana eo amin'ny soatoavina, tsirairay avy.
//! Fampiharana azy ireo overloads ny `==` sy `!=` mpandraharaha.
//! * [`Ord`] ary [`PartialOrd`] dia traits izay ahafahanao mamaritra ny filaharana sy ny fizarana ampahany eo anelanelan'ny sanda.
//!
//! Fampiharana azy ireo overloads ny `<`, `<=`, `>`, ary `>=` mpandraharaha.
//! * [`Ordering`] dia enum niverina ny tena asa ny [`Ord`] sy [`PartialOrd`], ary milazalaza ny antokony.
//! * [`Reverse`] dia struct izay mamela anao hanova ny Ordering mora foana.
//! * [`max`] ary [`min`] no miasa fa manaova eny amin'ny [`Ord`] sy hamela anao mba hahita ny ambony indrindra na ny kely indrindra amin'ny soatoavina roa.
//!
//! Raha mila tsipiriany, dia jereo ny taratasy tsirairay ny zavatra tsirairay ao amin'ny lisitra.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait ho an'ny fampitahana fitoviana izay [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Zavatra tsy mamela ho an'ny ampahany trait fitovian-jo, ny karazana izay tsy manana fifandraisana feno equivalence.
/// Ohatra, amin'ny isa mitsingevana `NaN != NaN`, noho izany ny karazana teboka mitsingevana dia mampihatra `PartialEq` fa tsy [`trait@Eq`].
///
/// Raha ny tokony ho izy dia tsy maintsy misy ny fitoviana (ho an'ny `a`, `b`, `c` karazana `A`, `B`, `C`):
///
/// - Symmetric ** **: raha `A: PartialEq<B>` sy `B: PartialEq<A>`, avy eo: ny== **b`dia midika`amin '==a`**;SY
///
/// - **: transitive**: raha `A: PartialEq<B>` sy `B: PartialEq<C>` sy `A:
///   PartialEq<C>`, avy eo **` a==b`sy `b == c` dia midika hoe a=c`**.
///
/// Mariho fa ny `B: PartialEq<A>` (symmetric) sy `A: PartialEq<C>` (transitive) impls dia tsy terena hisy, fa mihatra ireo fepetra ireo isaky ny misy izany.
///
/// ## Derivable
///
/// Ity trait dia azo ampiasaina amin'ny `#[derive]`.Rehefa `derive`d amin'ny structs, ireo toe-javatra roa mitovy raha toa saha rehetra dia mitovy, ary tsy azo ampitahaina raha misy eny an-tsaha tsy mitovy.Rehefa `derive`d amin'ny enums, Variant tsirairay dia mitovy ho an'ny tenany sy tsy azo ampitahaina amin'ny hafa variants.
///
/// ## Ahoana no fomba ampiharako ny `PartialEq`?
///
/// `PartialEq` ihany no mitaky ny [`eq`] fomba tokony ampiharina;[`ne`] dia faritana amin'ny alàlan'ny default.Izay mety ho boky fametrahana ny [`ne`]* * tsy maintsy manaja ny fitsipika fa [`eq`] dia hentitra no mitifitra ny mifanohitra amin'ny [`ne`];izany hoe, `!(a == b)` raha ary raha `a != b` fotsiny.
///
/// Implementations ny `PartialEq`, [`PartialOrd`], ary [`Ord`]* * tsy maintsy miombon-kevitra amin'ny tsirairay.Mora ny nahy hahatonga azy ireo tsy mitovy hevitra amin'ny alalan'ny ka naka sasany tamin'ny traits sy tanana fampiharana ny hafa.
///
/// Ohatra iray fametrahana ho sehatra izay boky roa dia raisina boky toy izany koa raha toa ny ISBN lalao, na dia ny endrika maha samy hafa:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Inona no hanoharako roa isan-karazany?
///
/// Ny karazana azonao ampitahaina aminy dia fehezin'ny parameter par Part`Eq`.
/// Ohatra, andao hamboarina kely ny kaody teo alohanay:
///
/// ```
/// // Mampihatra ny vokatra<BookFormat>==<BookFormat>fampitahana
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Tanteraho<Book>==<BookFormat>fampitahana
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Tanteraho<BookFormat>==<Book>fampitahana
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Amin'ny fanovana ny `impl PartialEq for Book` ho `impl PartialEq<BookFormat> for Book`, avelantsika hampitahaina amin'ny `Book`s`s ny` BookFs`s.
///
/// Ny fampitahana toy ilay etsy ambony, izay tsy miraharaha ny sasany saha momba ny struct, mety hampidi-doza.Mety hitarika mora foana ho amin'ny unintended fandikana ny fepetra takiana ho an'ny ampahany equivalence fifandraisana.
/// Ohatra, raha nitandrina ny ambony fametrahana ny `PartialEq<Book>` for `BookFormat` ary nanampy ny fampiharana ny `PartialEq<Book>` for `Book` (na amin'ny alalan'ny iray `#[derive]` na amin'ny alalan'ny fametrahana ny boky avy any amin'ny voalohany ohatra) avy eo ny vokany dia mifanohitra transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Izany fomba fitsirihana for `self` sy `other` sarobidy ho mitovy, ary ampiasaina ny `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Izany fomba mizaha toetra ny `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Misintona macro niteraka ny impl ny trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait ho an'ny fampitahana fitoviana izay [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Midika izany, fa ankoatra ny `a == b` sy `a != b` ho hentitra inverses, ny fitoviana dia tsy maintsy (ho an'ny rehetra `a`, `b` sy `c`):
///
/// - reflexive: `a == a`;
/// - symmetric: `a == b` dia midika `b == a`;SY
/// - transitive: `a == b` sy `b == c` dia midika `a == c`.
///
/// Zavatra tsy fananana tsy ampy amin'ny compiler, ka noho izany dia midika `Eq` [`PartialEq`], ary tsy misy fomba fanampiny.
///
/// ## Derivable
///
/// Zavatra trait azo ampiasaina amin'ny `#[derive]`.
/// Rehefa `derive`d, satria `Eq` tsy manana fomba fanampiny, dia mampahafantatra ny compiler ihany fa dia equivalence fifandraisana fa tsy ny ampahany equivalence fifandraisana.
///
/// Mariho fa ny paikady `derive` dia mitaky `Eq` ny saha rehetra, izay tsy tadiavina foana.
///
/// ## Ahoana no fomba ampiharako ny `Eq`?
///
/// Raha toa ianao tsy afaka mampiasa ny `derive` tetika, mamaritra fa ny karazana fitaovana `Eq`, izay tsy misy fomba:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // fomba io dia ampiasaina fotsiny ny#[ka naka] ny filazana fa singa rehetra ny karazana fitaovana#[ka naka] ny tenany, ka naka ny foto-drafitr'asa amin'izao fotoana izao dia midika hoe manao izany filazana tsy mampiasa fomba trait ity dia saika tsy ho vita.
    //
    //
    // Tsy tokony hatao an-tanana velively izany.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Miorina makro mamorona impl an'ny trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ity str ity dia ampiasain'ny#[derive] fotsiny ho
// manamafy fa ny singa rehetra amin'ny karazana dia manatanteraka ny Eq.
//
// Tsy tokony hiseho amin'ny kaody mpampiasa mihitsy io firafitra io.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// An `Ordering` dia vokatry ny fampitahana eo amin'ny soatoavina roa.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Fandefasana izay sanda ampitahaina dia kely noho ny iray hafa.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Famandrihana iray izay ny soatoavina ampitahaina dia mitovy amin'ny iray hafa.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Famandrihana izay misy soatoavina ampitahaina dia lehibe kokoa noho ny iray hafa.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Miverina `true` raha toa ny antokony dia ny `Equal` Variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Miverina `true` raha tsy ny `Equal` dia miova.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Miverina `true` raha toa ka miova ny `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Miverina `true` raha toa ka miova ny `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Miverina `true` raha toa ny antokony dia na ny `Less` na `Equal` Variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Miverina `true` raha toa ny antokony dia na ny `Greater` na `Equal` Variant.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Mivadika ny `Ordering`.
    ///
    /// * `Less` lasa `Greater`.
    /// * `Greater` lasa `Less`.
    /// * `Equal` lasa `Equal`.
    ///
    /// # Examples
    ///
    /// Fomba fitondran-tena:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Izany fomba Azo ampiasaina hanova ny fampitahana:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // alaharo ny laharana hatramin'ny lehibe indrindra ka hatramin'ny kely indrindra.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Gadra roa orderings.
    ///
    /// Miverina `self` rehefa tsy `Equal`.Raha tsy izany dia miverina `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Rojo ny filaharana miaraka amin'ilay fiasa omena.
    ///
    /// Miverina `self` rehefa tsy `Equal`.
    /// Raha tsy izany dia miantso `f` ary mamerina ny valiny.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Fitaovana mpanampy amin'ny famandrihana miverina.
///
/// Io no mpanampy struct mba ho ampiasaina amin'ny asa toy ny [`Vec::sort_by_key`] ary azo ampiasaina mba hanova ny ampahany manan-danja iray.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait ho an'ny karazana mamorona [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Ny baiko dia tanteraka raha mba (ho an'ny rehetra `a`, `b` sy `c`):
///
/// - tanteraka sy ny asymmetric: katroka iray `a < b`, `a == b` na `a > b` dia marina;SY
/// - transitive, `a < b` ary `b < c` dia midika `a < c`.Ny mitovy dia tsy maintsy mihazona ho an'ny `==` sy `>`.
///
/// ## Derivable
///
/// Zavatra trait azo ampiasaina amin'ny `#[derive]`.
/// Rehefa `derive`d tamin'ny structs, dia hamokatra ny [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) Ordering miorina eo an-tampon'ny-to-ambany fanambarana lamin 'ny struct ny mpikambana.
///
/// Rehefa `derive`d tamin'ny enums, variants dia baiko araka ny ambony-to-ambany mba discriminant.
///
/// ## Fampitahana amin'ny diksionera
///
/// Ny fampitahana Lexicografika dia asa miaraka amin'ireto fananana manaraka ireto:
///  - Filaharana roa no ampitahaina amin'ny singa tsirairay.
///  - Ny singa tsy fitoviana voalohany dia mamaritra ny filaharana izay lexicografia kely na lehibe kokoa noho ny iray hafa.
///  - Raha misy filaharany dia tovona hafa, ny fohy kokoa lexicographically filaharana dia kely noho ny hafa.
///  - Raha dingana roa manana singa mitovy sy manana ny toe-halavan'ny, dia ny sequences dia lexicographically mitovy.
///  - - Poana dia lexicographically dingana kely noho ny tsy foana tsy mitondra fanatitra filaharany.
///  - Sequences roa foana no lexicographically mitovy.
///
/// ## Ahoana no fomba ampiharako ny `Ord`?
///
/// `Ord` mitaky ny [`PartialOrd`] sy [`Eq`] (izay mila [`PartialEq`]) ihany koa ny karazany.
///
/// Dia tsy maintsy atao ny fametrahana ho an'ny [`cmp`].Mety ho hitanao fa mahasoa ny mampiasa [`cmp`] eo amin'ny karazana ny an-tsaha.
///
/// Implementations ny [`PartialEq`], [`PartialOrd`], ary `Ord`* * tsy maintsy miombon-kevitra amin'ny tsirairay.
/// Izany hoe, raha toa `a.cmp(b) == Ordering::Equal` ary raha `a == b` sy `Some(a.cmp(b)) == a.partial_cmp(b)` ho an'ny rehetra sy `b` `a`.
/// Mora ny manao tsy fifanarahana tampoka azy ireo amin'ny alàlan'ny famoahana ny sasany amin'ny traits ary fampiharana ny hafa amin'ny tanana.
///
/// Ity ohatra toerana tianao ny manatsara ny olona ny hahavony ihany, tsy miraharaha `id` sy `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Ity fomba iray [`Ordering`] Niverina teo anelanelan'i `self` sy `other`.
    ///
    /// By fivoriambe, `self.cmp(&other)` miverina ny antokony mifanandrify amin'ny teny `self <operator> other` Raha toa ka marina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Mampitaha sy mamerina ny sanda roa farany ambony.
    ///
    /// Miverina ny tohan-kevitra faharoa raha mamaritra ny fampitahana azy ireo mba hitovy.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Mampitaha ary miverina ny kely indrindra ny soatoavina roa.
    ///
    /// Mamerina ny adihevitra voalohany raha toa ka mamaritra azy ireo hitovy ny fampitahana.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Ferana ny elanelam-potoana iray.
    ///
    /// Miverina `max` raha `self` lehibe kokoa noho `max`, ary `min` raha `self` ambany noho `min`.
    /// Raha tsy izany dia miverina `self`.
    ///
    /// # Panics
    ///
    /// Panics raha `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Miorina makro mamorona impl an'ny trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait ho an'ny sanda azo oharina amin'ny filaharana.
///
/// Ny fampitahana dia tsy maintsy manome fahafaham-po, ho an'ny `a`, `b` ary `c` rehetra:
///
/// - asymmetrika: raha `a < b` dia `!(a > b)`, ary koa `a > b` milaza `!(a < b)`;SY
/// - transitivity: `a < b` sy `b < c` midika `a < c`.Ny mitovy dia tsy maintsy mihazona ho an'ny `==` sy `>`.
///
/// Mariho fa ireo fepetra takiana ireo dia midika fa ny trait mihitsy dia tsy maintsy ampiharina symmetrika ary mandalo: raha `T: PartialOrd<U>` sy `U: PartialOrd<V>` dia `U: PartialOrd<T>` sy `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ity trait dia azo ampiasaina amin'ny `#[derive]`.Rehefa `derive`d amin'ny kofehy dia hamokatra filaharana lexicographique miorina amin'ny filaharana fanambarana ambony sy ambany ho an'ireo mpikambana ao amin'ny strat.
/// Rehefa `derive`d tamin'ny enums, variants dia baiko araka ny ambony-to-ambany mba discriminant.
///
/// ## Ahoana no fomba ampiharako ny `PartialOrd`?
///
/// `PartialOrd` mila fampiharana ny fomba [`partial_cmp`] ihany, miaraka amin'ireo hafa vokarina amin'ny fampiharana default.
///
/// Na izany aza dia mbola azo atao ny mampihatra ny hafa misaraka amin'ireo karazana izay tsy manana filaminana feno.
/// Ohatra, noho ny hevitra mitsingevana isa, `NaN < 0 == false` sy `NaN >= 0 == false` (cf.
/// IEEE 754-2008 fizarana 5.11).
///
/// `PartialOrd` dia mitaky ny karazana mba ho [`PartialEq`].
///
/// Implementations ny [`PartialEq`], `PartialOrd`, ary [`Ord`]* * tsy maintsy miombon-kevitra amin'ny tsirairay.
/// Mora ny manao tsy fifanarahana tampoka azy ireo amin'ny alàlan'ny famoahana ny sasany amin'ny traits ary fampiharana ny hafa amin'ny tanana.
///
/// Raha [`Ord`] ny karazanyo dia azonao atao ny mampihatra ny [`partial_cmp`] amin'ny fampiasana [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Azonao atao koa ny mahita fa ilaina ny mampiasa [`partial_cmp`] eo amin'ny karazana ny an-tsaha.
/// Indro misy ohatra iray ny `Person` karazana izay manana mitsinkafona-teboka `height` saha izay saha ihany no tokony ampiasaina amin'ny fanasokajiana:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Ity fomba ity dia mamerina fandaminana eo anelanelan'ny sanda `self` sy `other` raha misy ny iray.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Rehefa tsy azo atao ny mampitaha:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Ity fomba ity dia mizaha toetra latsaky ny (ho an'ny `self` sy `other`) ary ampiasain'ny mpandraharaha `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Izany fomba fitsirihana latsaka na mitovy amin'ny (fa `self` sy `other`) ary ampiasain'ny `<=` mpandraharaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Ity fomba ity dia mizaha toetra lehibe kokoa noho ny (ho an'ny `self` sy `other`) ary ampiasain'ny mpandraharaha `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Izany fomba mizaha toetra lehibe noho na mitovy ny (for `self` sy `other`) ary ampiasain'ny `>=` mpandraharaha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Misintona macro niteraka ny impl ny trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Mampitaha ary miverina ny kely indrindra ny soatoavina roa.
///
/// Mamerina ny adihevitra voalohany raha toa ka mamaritra azy ireo hitovy ny fampitahana.
///
/// Mampiasa solon'anarana mankany [`Ord::min`] ny ao anatiny.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Mamerina ny farafahakeliny soatoavina roa momba ny fampitahana voafaritra.
///
/// Mamerina ny adihevitra voalohany raha toa ka mamaritra azy ireo hitovy ny fampitahana.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Miverina ny singa izay manome ny vidiny ambany indrindra amin'ny asa voafaritra.
///
/// Mamerina ny adihevitra voalohany raha toa ka mamaritra azy ireo hitovy ny fampitahana.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Mampitaha sy mamerina ny sanda roa farany ambony.
///
/// Miverina ny tohan-kevitra faharoa raha mamaritra ny fampitahana azy ireo mba hitovy.
///
/// Mampiasa solon'anarana mankany [`Ord::max`] ny ao anatiny.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Miverina ny faratampony ny toetra roa Ho fanajana ny lasa mihamatanjaka ny fampitahana ny asa.
///
/// Miverina ny tohan-kevitra faharoa raha mamaritra ny fampitahana azy ireo mba hitovy.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Miverina ny singa izay manome ny vidiny ambony indrindra avy amin'ny asa voafaritra.
///
/// Miverina ny tohan-kevitra faharoa raha mamaritra ny fampitahana azy ireo mba hitovy.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Fampiharana PartialEq, Eq, PartialOrd ary Ord ho an'ny karazana primitive
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Ny baiko eto dia zava-dehibe ny hiteraka fiangonana tandrify kokoa.
                    // Jereo <https://github.com/rust-lang/rust/issues/63758> raha mila fanazavana fanampiny.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Ny fandefasana any amin'ny i8 ary ny famadihana ny fahasamihafana amin'ny Ordering dia miteraka fivoriambe tsara kokoa.
            //
            // Jereo <https://github.com/rust-lang/rust/issues/66780> for more info.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool as i8 mamerina 0 na 1, ka ny fahasamihafana dia tsy mety ho zavatra hafa
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &sahaza

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}