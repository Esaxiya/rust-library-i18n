//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Ny fehezan-dalàna manan-kery avo indrindra teboka iray `char` afaka.
    ///
    /// A `char` dia [Unicode Scalar Value], izay midika fa dia [Code Point], afa-tsy ireo ao anatin'ny iray isan-karazany.
    /// `MAX` no avo indrindra fehezan-dalàna manan-kery izany teboka iray [Unicode Scalar Value] mitombina.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () dia ampiasaina ao amin'ny Unicode hanehoana ny lesoka diso.
    ///
    /// Mety hitranga, ohatra, rehefa manome Bytes UTF-8 ratsy endrika amin'ny [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Ny kinova [Unicode](http://www.unicode.org/) izay ny fizarana Unicode amin'ny fomba `char` sy `str` dia miorina.
    ///
    /// New dika amin'ny Unicode dia nivoaka tsy tapaka sy fomba rehetra taty aoriana ao amin'ny tranomboky fitsipika miankina amin'ny Unicode dia nohavaozina.
    /// Noho izany ny fihetsika sasany `char` sy `str` fomba ary ny sandan'ity fanovana tsy tapaka ity dia miova rehefa mandeha ny fotoana.
    /// Ity dia *tsy* heverina ho fiovana manimba.
    ///
    /// Ny teti-panondroana ny kinovan'ny kinova dia hazavaina ao amin'ny [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Miteraka ny iterator ambonin'ny UTF-16 voafango ao amin'ny fehezan-dalàna hevitra `iter`, niverina unpaired surrogates toy ny `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// A lossy decoder dia afaka ho azo amin'ny alalan'ny fanoloana `Err` vokatry ny fanoloana toetra:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Niova fo ny `u32` ny `char`.
    ///
    /// Mariho fa ny `char`s rehetra dia manan-kery [`u32`] s, ary azo alefa amin'ny iray miaraka aminy
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Na izany aza, ny mifamadika tsy marina; tsy manan-kery rehetra [: u32`] S dia manan-kery`char`s.
    /// `from_u32()` hiverina `None` raha toa ka tsy valiny manan-kery ho an'ny `char` ny fampidirana.
    ///
    /// Raha mila kinova tsy azo antoka amin'ity fiasa ity izay tsy miraharaha ireo fanamarinana ireo dia jereo ny [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` rehefa niverina ny fahan'ny dia tsy manan-kery `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Mamadika `u32` ho `char`, tsy miraharaha ny fahamendrehana.
    ///
    /// Mariho fa ny `char`s rehetra dia manan-kery [`u32`] s, ary azo alefa amin'ny iray miaraka aminy
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Na izany aza, ny mifamadika tsy marina; tsy manan-kery rehetra [: u32`] S dia manan-kery`char`s.
    /// `from_u32_unchecked()` tsy hiraharaha izany, ary handefa an-jambany any `char`, mety hamorona iray tsy mety.
    ///
    ///
    /// # Safety
    ///
    /// Tsy azo antoka ity fiasa ity satria mety hanangana sanda `char` tsy mety.
    ///
    /// Raha mila kinova azo antoka amin'ity asa ity ianao dia jereo ny fiasan'ny [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SAFETY: ny fifanarahana fiarovana dia tsy maintsy tohanan'ny mpiantso.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Manova ny tarehimarika ao amin'ilay radix nomena ho `char`.
    ///
    /// A 'radix' eto indraindray koa antsoina hoe 'base'.
    /// Ny radix roa mimari-droa dia manondro ny maro, ny radix folo, decimal, ary ny radix ny enina ambin'ny folo, hexadecimal, mba hanome ny sasany soatoavina iombonana.
    ///
    /// Manohana ireo radice tsy mitongilana.
    ///
    /// `from_digit()` dia hiverina `None` raha toa ka tsy tarehimarika ao amin'ny radix nomena ny fampidirana.
    ///
    /// # Panics
    ///
    /// Panics raha nomena radix lehibe noho 36.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 dia isa tokana amin'ny base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Miverina `None` rehefa tsy tarehimarika ny fampidirana:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Mandalo radix lehibe, miteraka panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Manamarina raha `char` dia tarehimarika ao amin'ny radix nomena.
    ///
    /// A 'radix' eto indraindray koa antsoina hoe 'base'.
    /// Ny radix roa mimari-droa dia manondro ny maro, ny radix folo, decimal, ary ny radix ny enina ambin'ny folo, hexadecimal, mba hanome ny sasany soatoavina iombonana.
    ///
    /// Manohana ireo radice tsy mitongilana.
    ///
    /// Raha oharina amin'ny [`is_numeric()`], asa io ihany no Manaiky ny endri-tsoratra `0-9`, `a-z` sy `A-Z`.
    ///
    /// 'Digit' dia faritana ho amin'ny teny anjara:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Raha te hahalala bebe kokoa momba ny 'digit', jereo [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics raha nomena radix lehibe noho 36.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Mandalo radix lehibe, miteraka panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Mamadika `char` ho an'ny isa amin'ny radix nomena.
    ///
    /// A 'radix' eto indraindray koa antsoina hoe 'base'.
    /// Ny radix roa mimari-droa dia manondro ny maro, ny radix folo, decimal, ary ny radix ny enina ambin'ny folo, hexadecimal, mba hanome ny sasany soatoavina iombonana.
    ///
    /// Manohana ireo radice tsy mitongilana.
    ///
    /// 'Digit' dia faritana ho amin'ny teny anjara:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Miverina `None` raha toa ka ny `char` dia tsy miresaka tarehimarika ao amin'ilay radix nomena.
    ///
    /// # Panics
    ///
    /// Panics raha nomena radix lehibe noho 36.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ny fandefasana valiny tsy misy isa dia miteraka tsy fahombiazana:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Mandalo radix lehibe, miteraka panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // mizara eto ny kaody hanatsarana ny hafainganan'ny famonoana ho an'ireo tranga izay tsy miova ny `radix` ary 10 na kely kokoa
        //
        let val = if likely(radix <= 10) {
            // Raha tsy tarehimarika dia hamorona isa lehibe kokoa noho ny radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Miverina iterator izay manome ny hexadecimal Unicode fandosirana ny toetra amam-panahy ho `char`s.
    ///
    /// Izany tarehin-tsoratra ho afa-mandositra ny Rust Syntaxe ny endrika `NNNNNN` `\u{NNNNNN}` izay dia hexadecimal fanehoana.
    ///
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // na-ing 1 dia manome antoka fa ho an'ny c==0 ny kaody dia manisa fa ny isa iray dia tokony hatao pirinty ary (izay mitovy) dia misoroka ny (31, 32) ao anaty
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ny fanondroana ny manan-danja indrindra hex tarehimarika
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Ny dikan-`escape_debug` maharitra fa mamela afa-nandositra optionally Extended Grapheme codepoints.
    /// Io dia ahafahantsika mamolavola endri-tsoratra toa ny tsy fanondroana mari-tsoratra tsara kokoa rehefa eo am-piandohan'ny tadiny.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Miverina ny iterator ka nanaraka ara-bakiteny izay afaka fehezan-dalàna ny toetra toy ny `char`s.
    ///
    /// Hialana amin'ireo endri-tsoratra mitovy amin'ny fampiharana `Debug` an'ny `str` na `char` ity.
    ///
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Miverina ny iterator ka nanaraka ara-bakiteny izay afaka fehezan-dalàna ny toetra toy ny `char`s.
    ///
    /// Ny default dia voafidy miaraka amin'ny fitongilanana amin'ny famokarana literatiora izay ara-dalàna amin'ny fiteny isan-karazany, ao anatin'izany ny C++ 11 sy ny fitoviana C-fianakaviana mitovy amin'izany.
    /// Ny fitsipika tena izy dia:
    ///
    /// * Tab dia efa afaka tahaka `\t`.
    /// * Ny fiverenan'ny kalesy dia afaka tamin'ny `\r`.
    /// * Line fahana dia efa afaka tahaka `\n`.
    /// * Single notsongaina dia efa afaka tahaka `\'`.
    /// * Ny X-`\"` X X dia nandositra ny fitanisana indroa
    /// * Backslash dia efa afaka tahaka `\\`.
    /// * Izay mety ho toetra ao amin'ny "Zavatra tsy marika ASCII 'isan-karazany .. `0x20` `0x7e` manontolo dia tsy afa-nandositra.
    /// * Ny endri-tsoratra hafa rehetra dia omena hexadecimal Unicode fandosirana;jereo [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Mamerina ny isan'ny bytes ilain'ity `char` ity raha voahodidin'ny UTF-8.
    ///
    /// Izany isan'ny oktety foana eo anelanelan'ny 1 sy 4, manontolo.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Ny karazana `&str` dia manome antoka fa ny atiny dia UTF-8, ary noho izany dia azontsika atao ny mampitaha ny halavany raha toa ka aseho ho `char` vs `&str` mihitsy ny teboka kaody tsirairay:
    ///
    ///
    /// ```
    /// // toy ny chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // samy azo soloina ho bytes telo
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // toy ny &str, ireo zavatra roa ireo no voafango ao UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // hitantsika fa mandray enina byte total ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... toy ny &str ihany
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Miverina ny isan'ny 16-bit vondrona fehezan-dalàna ity dia mila `char` raha voafango ao UTF-16.
    ///
    ///
    /// Jereo ny antontan-taratasy momba ny [`len_utf8()`] raha mila fanazavana bebe kokoa momba an'io hevitra io.
    /// Io asa dia fitaratra, fa ho UTF-16 fa tsy UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Mametaka ity toetra ity ho UTF-8 ao anaty buffer byte omena, ary avy eo averiny ny subslice an'ny buffer izay misy ilay toetra voafefy.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha ny buffer tsy ampy lehibe.
    /// Ny buffer iray amin'ny halavany efatra dia ampy hametrahana `char` rehetra.
    ///
    /// # Examples
    ///
    /// Amin'ireto ohatra roa ireto, 'ß' dia maka bytes roa handefasana.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Buffer kely loatra:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // Famonjena, `char` Tsy surrogate, ka izany no manan-kery UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Encodes toetra io ho toy UTF-16 ho any amin'ny nanome `u16` buffer, ary avy eo dia miverina ny subslice ny buffer izay ahitana ny voafango toetra.
    ///
    ///
    /// # Panics
    ///
    /// Panics raha ny buffer tsy ampy lehibe.
    /// Ny buffer ny lavany 2 dia malalaka ny isa misy `char`.
    ///
    /// # Examples
    ///
    /// Samy ireo ohatra, roa maka '𝕊': u16`s ny isa.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Buffer kely loatra:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Miverina `true` raha toa ka manana ny fananana `Alphabetic` ity `char` ity.
    ///
    /// `Alphabetic` dia voalaza ao amin'ny Toko 4 (Character Properties) an'ny [Unicode Standard] ary voalaza ao amin'ny [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ny fitiavana dia zavatra maro, fa tsy abidia
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Miverina `true` raha toa ka manana ny fananana `Lowercase` ity `char` ity.
    ///
    /// `Lowercase` dia voalaza ao amin'ny Toko 4 (Character Properties) an'ny [Unicode Standard] ary voalaza ao amin'ny [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Tsy manana tranga ny soratra sy ny mari-tsoratra sinoa isan-karazany, ka noho izany:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Miverina `true` raha manana ny `Uppercase` `char` fananana.
    ///
    /// `Uppercase` dia voalaza ao amin'ny Toko 4 (Character Properties) an'ny [Unicode Standard] ary voalaza ao amin'ny [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Tsy manana tranga ny soratra sy ny mari-tsoratra sinoa isan-karazany, ka noho izany:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Miverina `true` raha toa ka manana ny fananana `White_Space` ity `char` ity.
    ///
    /// `White_Space` dia voalaza ao amin'ny [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // toerana tsy vaky
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Miverina `true` raha toa ka [`is_alphabetic()`] na [`is_numeric()`] no manome fahafaham-po an'ity `char` ity.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Miverina `true` raha ity `char` ity dia manana ny sokajy ankapobeny amin'ny kaody fanaraha-maso.
    ///
    /// Control Laharana (fehezan-hevitra amin'ny ankapobeny sokajy `Cc`) dia voalaza tao amin'ny Toko 4 (Character Properties) ny [Unicode Standard] sy voalaza ao amin'ny [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // U + 009C, TERMINATOR mahery
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Miverina `true` raha manana ny `Grapheme_Extend` `char` fananana.
    ///
    /// `Grapheme_Extend` dia voafaritra ao amin'ny [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] sy voalaza ao amin'ny [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Miverina `true` raha ity `char` ity dia misy iray amin'ireo sokajy ankapobeny ho an'ny isa.
    ///
    /// Ny sokajy ankapobeny ho an'ny tarehimarika (`Nd` for decimal isa, `Nl` ho an'ny soratra toy numeric tarehin-tsoratra, ary ho an'ny hafa `No` numeric litera) dia faritana ao amin'ny [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Miverina ny iterator izay ka nanaraka ny lowercase sarintany ity `char` toy ny iray na maromaro
    /// `char`s.
    ///
    /// Raha `char` tsy manana lowercase saritany, ka nanaraka ny iterator `char` iray ihany.
    ///
    /// Raha manana iray `char`-to-iray lowercase sarintany nomen'ny [Unicode Character Database][ucd] [`UnicodeData.txt`], ny iterator vokatra fa `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Raha toa ka mila fiheverana manokana ity `char` ity (ohatra hoe `char` maro) dia manome ny`char` (s) nomen'i [`SpecialCasing.txt`] ny iterator.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ity hetsika manao ny tsy misy fepetra tsarintany tsy fanjairana.Izany hoe tsy miankina amin'ny resaka sy ny fiteny ny fiovam-po.
    ///
    /// Ao amin'ny [Unicode Standard], Chapter 4 (Toetra Properties) dia miresaka raharaha sarintany amin'ny ankapobeny sy Chapter 3 (Conformance) dia miresaka momba ny toerana misy anao algorithm fiovam-po ho an'ny raharaha.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Indraindray ny vokany dia mihoatra ny iray toetra:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Tarehin-tsoratra izay tsy manana na litera kapitaly sy ny lowercase niova fo ho tenany.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Miverina iterator izay manome ny sarintany ambony an'ity `char` ity ho iray na maromaro
    /// `char`s.
    ///
    /// Raha `char` tsy manana ny litera kapitaly saritany, ka nanaraka ny iterator `char` iray ihany.
    ///
    /// Raha ity `char` ity dia manana sarintany iray amin'ny iray lehibe iray nomen'ny [Unicode Character Database][ucd] [`UnicodeData.txt`], dia manome io `char` io ilay mpandidy.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Raha toa ka mila fiheverana manokana ity `char` ity (ohatra hoe `char` maro) dia manome ny`char` (s) nomen'i [`SpecialCasing.txt`] ny iterator.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ity hetsika manao ny tsy misy fepetra tsarintany tsy fanjairana.Izany hoe tsy miankina amin'ny resaka sy ny fiteny ny fiovam-po.
    ///
    /// Ao amin'ny [Unicode Standard], Chapter 4 (Toetra Properties) dia miresaka raharaha sarintany amin'ny ankapobeny sy Chapter 3 (Conformance) dia miresaka momba ny toerana misy anao algorithm fiovam-po ho an'ny raharaha.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Amin'ny maha-iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Mampiasa `println!` mivantana:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Samy dia mitovy amin'ny:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Mampiasa `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Indraindray ny vokany dia mihoatra ny iray toetra:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Tarehin-tsoratra izay tsy manana na litera kapitaly sy ny lowercase niova fo ho tenany.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Fanamarihana eo an-toerana
    ///
    /// Ao Tiorka, ny mitovy amin'ny 'i' amin'ny teny latinina dia manana endrika dimy fa tsy roa:
    ///
    /// * 'Dotless': I/ı, indraindray voasoratro dia
    /// * 'Dotted': İ/i
    ///
    /// Mariho fa ny lowercase Miravaka 'i' dia mitovy amin'ny teny latinina.Noho izany:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Ny zava-dehibe ny miantehitra `upper_i` eto an-teny ny soratra; raha ao `en-US` izahay, dia tokony ho `"I"`, fa raha izahay ao amin'ny `tr_TR`, dia tokony ho `"İ"`.
    /// `to_uppercase()` tsy mandray izany tafiditra ao, sy ny sisa;
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// mihazona fiteny maro.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Taratasim-bola raha toa ny sandan'ny ao amin'ny marika ASCII isan-karazany.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Manao dika mitovy amin'ny zava-dehibe amin'ny tranga mitovy marika ASCII ambony.
    ///
    /// Ny litera ASCII 'a' ka hatramin'ny 'z' dia mapafao amin'ny 'A' ka hatramin'ny 'Z', fa ny litera tsy ASCII tsy miova.
    ///
    /// Mba litera kapitaly ny tena ilaina in-toerana, mampiasa [`make_ascii_uppercase()`].
    ///
    /// Ny litera kapitaly endritsoratra ASCII, ankoatra ny tsy endritsoratra ASCII, mampiasa [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Manao kopia iray amin'ny sanda amin'ny ASCII ambany ambany.
    ///
    /// Marika ASCII taratasy 'A' ho 'Z' dia tsarintany ny 'a' ho 'z', fa tsy marika ASCII taratasy dia niova.
    ///
    /// Raha hampidina ny sandam-bola eo an-toerana dia ampiasao ny [`make_ascii_lowercase()`].
    ///
    /// Raha hampidina ny litera ASCII ankoatry ny litera tsy ASCII dia ampiasao [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Manamarina fa ny soatoavina roa dia lalao ASCII tsy dia misy dikany.
    ///
    /// Mitovy amin'ny `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Mampivadika an'io karazana io amin'ny ASCII case ambony mitovy aminy eo amin'ny toerany.
    ///
    /// Ny litera ASCII 'a' ka hatramin'ny 'z' dia mapafao amin'ny 'A' ka hatramin'ny 'Z', fa ny litera tsy ASCII tsy miova.
    ///
    /// Mba hiverina vaovao uppercased sanda tsy manova ny efa misy iray, mampiasa [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Niova fo ity ho any amin'ny marika ASCII karazana tranga mitovy ambany in-toerana.
    ///
    /// Marika ASCII taratasy 'A' ho 'Z' dia tsarintany ny 'a' ho 'z', fa tsy marika ASCII taratasy dia niova.
    ///
    /// Mba hiverina vaovao lowercased sanda tsy manova ny efa misy iray, mampiasa [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Manamarina raha toetra abidia ASCII ny sanda:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', na
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Manamarina raha toa ka ASCII endri-tsoratra lehibe ny sandany:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Taratasim-bola raha toa ka tena ilaina dia marika ASCII lowercase toetra:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Taratasim-bola raha toa ka tena ilaina dia marika ASCII alphanumeric toetra:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', na
    /// - U + 0061 'a' ..=U + 007A 'z', na
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Hamarino raha tarehimarika decimal ASCII ny sanda:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Taratasim-bola raha toa ka tena ilaina dia marika ASCII hexadecimal tarehimarika:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', na
    /// - U + 0041 'A' ..=U + 0046 'F', na
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Taratasim-bola raha toa ka tena ilaina dia marika ASCII mari-piatoana toetra:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, na
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, na
    /// - U + 005B ..=U + 0060 `` [\] ^ _: ``, na
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Manamarina raha toa ka ASCII sary an-tsary ny sandany:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Manamarina raha toa ka toetran'ny fotsy fotsy ASCII ny sanda:
    /// U + 0020 SPACE, U + 0009 TAB HORIZONTAL, U + 000A LINE FEED, U + 000C FORM FEED, na U + 000D CARRIAGE RETURN.
    ///
    /// Rust mampiasa ny WhatWG Infra Standard ny [definition of ASCII whitespace][infra-aw].Misy famaritana maro hafa amin'ny fampiasana betsaka.
    /// Ohatra, [the POSIX locale][pct] dia ahitana U + 000B VERTICAL TAB ary koa ireo endri-tsoratra etsy ambony rehetra, fa - avy amin'ilay famaritana mitovy ihany- [ny lalàna misy default ho an'ny "field splitting" ao amin'ny Bourne shell][bfs] dia mihevitra * * SPACE, TAB HORIZONTAL, ary LINE FEED toy ny toerana fotsy.
    ///
    ///
    /// Raha manoratra programa hanodinana endrika fisie efa misy ianao dia zahao izay famaritan'io endrika io ny toerana fotsy alohan'ny hampiasana io asa io.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Taratasim-bola raha toa ka tena ilaina dia marika ASCII fanaraha-maso ny toetra:
    /// U + 0000 NUL ..=U + 001F UNITAR SEPARATOR, na U + 007F Delete.
    /// Mariho fa ny ankamaroan'ny marika ASCII whitespace tarehin-tsoratra ireo tarehin-tsoratra fanaraha-maso, fa tsy SPACE.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Encodes ny manta u32 sarobidy toy ny UTF-8 ho any amin'ny nanome byte buffer, ary avy eo dia miverina ny subslice ny buffer izay ahitana ny voafango toetra.
///
///
/// Tsy toy ny `char::encode_utf8`, izany ihany koa ny fomba mitantam codepoints ao amin'ny surrogate isan-karazany.
/// (Fananganana ny `char` ao amin'ny surrogate isan-karazany dia Ub.) Ny vokatr'izany dia manan-kery fa tsy manan-kery [generalized UTF-8] UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics raha ny buffer tsy ampy lehibe.
/// Ny buffer iray amin'ny halavany efatra dia ampy hametrahana `char` rehetra.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Encodes ny manta u32 sarobidy toy ny UTF-16 ho any amin'ny nanome `u16` buffer, ary avy eo dia miverina ny subslice ny buffer izay ahitana ny voafango toetra.
///
///
/// Tsy toy ny `char::encode_utf16`, io fomba io ihany koa no mitantana codepoints ao amin'ny faritra misolo azy.
/// (Fananganana ny `char` ao amin'ny surrogate isan-karazany dia Ub.)
///
/// # Panics
///
/// Panics raha ny buffer tsy ampy lehibe.
/// Ny buffer ny lavany 2 dia malalaka ny isa misy `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAFETY: ny sandry tsirairay dia manamarina raha misy sombiny ampy hanoratanao
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Latsaka ny BMP
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ny fiaramanidina fanampiny dia lasa mpisolo toerana.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}