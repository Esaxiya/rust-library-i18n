//! Famadihana toetra.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Niova fo ny `u32` ny `char`.
///
/// Mariho fa ny [`char`] rehetra dia manan-kery [`u32`] s, ary afaka atsipy miaraka aminy
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Na izany aza, tsy marina ny mifamadika: tsy ny rehetra [`u32`] s no mitombina [`char`] s.
/// `from_u32()` hiverina `None` raha toa ka tsy valiny manan-kery ho an'ny [`char`] ny fampidirana.
///
/// Raha mila kinova tsy azo antoka amin'ity fiasa ity izay tsy miraharaha ireo fanamarinana ireo dia jereo ny [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Averina `None` rehefa tsy [`char`] manan-kery ny fidirana:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Mamadika `u32` ho `char`, tsy miraharaha ny fahamendrehana.
///
/// Mariho fa ny [`char`] rehetra dia manan-kery [`u32`] s, ary afaka atsipy miaraka aminy
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Na izany aza, tsy marina ny mifamadika: tsy ny rehetra [`u32`] s no mitombina [`char`] s.
/// `from_u32_unchecked()` tsy hiraharaha izany, ary handefa an-jambany any [`char`], mety hamorona iray tsy mety.
///
///
/// # Safety
///
/// Tsy azo antoka ity fiasa ity satria mety hanangana sanda `char` tsy mety.
///
/// Raha mila kinova azo antoka amin'ity asa ity ianao dia jereo ny fiasan'ny [`from_u32`].
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SAFETY: ny miantso dia tsy maintsy manome antoka fa `i` dia soatoavina char manan-kery.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Manova [`char`] ho [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Niova fo ny [`char`] ho [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Ny char dia atsipy amin'ny sandan'ny teboka kaody, avy eo averina aotra amin'ny 64 bit.
        // Jereo [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Niova fo ny [`char`] ho [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Ny Char dia casted ho zava-dehibe ny fotoana ny fehezan-dalàna, dia aotra-omena ny 128 kely.
        // Jereo [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Maps ny byte in 0x00 ..=0xFF ny `char` izay manana ny fehezan-dalàna mitovy hevitra sarobidy, ao amin'ny U + 0000 ..=U + 00FF.
///
/// Unicode dia natao toy izany amim-pahombiazana decodes oktety miaraka amin'ny toetra karazana litera fa niantso IANA ISO-8859-1.
/// Ity karazana litera mifanaraka amin'ny marika ASCII.
///
/// Mariho fa tsy mitovy amin'ny ISO/IEC 8859-1 aka
/// ISO 8859-1 (iray tsy panohizana), izay mamela ny sasany "blanks", byte soatoavina izay tsy voatendry na toetra.
/// ISO-8859-1 (ny IANA iray) manome azy ireo ny C0 sy C1 Laharana fanaraha-maso.
///
/// Mariho fa * * koa * tsy mitovy amin'ny Windows-1252 aka
/// kaody pejy 1252, izay superset ISO/IEC 8859-1 izay manome ny banga sasany (tsy izy rehetra!) amin'ny mari-tsoratra sy litera latina isan-karazany.
///
/// Mba hampisafotofoto ny zava-misy, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, ary `windows-1252` dia aliasza rehetra ho an'ny superset an'ny Windows-1252 izay mameno ny banga sisa miaraka amin'ireo kaody mifehy C0 sy C1 mifandraika amin'izany.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Manova [`u8`] ho [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Hadisoana izay azo averina rehefa manamboatra char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SAFETY: nanamarina fa sanda unicode ara-dalàna io
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Niverina ny karazana lesoka rehefa tsy nahomby ny fiovam-po avy amin'ny u32 ho char.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Manova ny tarehimarika ao amin'ilay radix nomena ho `char`.
///
/// A 'radix' eto indraindray koa antsoina hoe 'base'.
/// Ny radix roa mimari-droa dia manondro ny maro, ny radix folo, decimal, ary ny radix ny enina ambin'ny folo, hexadecimal, mba hanome ny sasany soatoavina iombonana.
///
/// Manohana ireo radice tsy mitongilana.
///
/// `from_digit()` dia hiverina `None` raha toa ka tsy tarehimarika ao amin'ny radix nomena ny fampidirana.
///
/// # Panics
///
/// Panics raha nomena radix lehibe noho 36.
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 dia isa tokana amin'ny base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Miverina `None` rehefa tsy tarehimarika ny fampidirana:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Mandalo radix lehibe, miteraka panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}