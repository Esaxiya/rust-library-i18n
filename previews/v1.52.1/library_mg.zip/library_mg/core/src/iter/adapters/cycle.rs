use crate::{iter::FusedIterator, ops::Try};

/// Mpiverina izay miverimberina tsy misy farany.
///
/// Izany `struct` no namorona ny [`cycle`] amin'ny fomba [`Iterator`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // ny tsingerina iterator dia na foana na tsy manam-petra
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // iterate tanteraka ny amin'izao fotoana izao iterator.
        // Ilaina izany satria mety ho banga `self.iter` na dia `self.orig` dia tsy
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // feno tanteraka tsingerin'ny, ny fitandremana ny lalana ny Nandeha bisikileta na iterator Foana na tsia.
        // tokony hiverina am-piandohan'ny raharaha foana iterator ho fisorohana ny tsy manam-petra manome fitoerana
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Tsy misy fihoarana `fold`, satria `fold` tsy misy dikany loatra amin'ny `Cycle`, ary tsy afaka manao zavatra tsara kokoa noho ny toerana misy anao isika.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}