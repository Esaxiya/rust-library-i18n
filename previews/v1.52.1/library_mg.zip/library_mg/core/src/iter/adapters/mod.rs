use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Izany dia manome trait: transitive ny fidirana amin'ny loharano-tsehatra tao amin'ny interator-adaptatera fantsona ambanin'ny toe-piainana
/// * ny loharano iterator `S` mihitsy manatanteraka `SourceIter<Source = S>`
/// * misy mamindra fampiharana izany ho an'ny tsirairay trait adaptatera ao amin'ny fantsona eo ny loharano sy ny fantsona mpanjifa.
///
/// Raha ny loharanom-baovao dia hividy iterator struct (antsoina matetika hoe `IntoIter`) dia mety ho ilaina ny manokana [`FromIterator`] implementations na singa fampahiratana ny sisa tavela taorian'ny iterator no ampahany reraka.
///
///
/// Mariho fa tsy voatery implementations voatery manome fahafahana hahazo ny efi-tena loharanom-ny fantsona.Ny adaptatera mpanelanelana amin'ny fanjakana dia mety hanombatombana fatratra ny ampahan'ny fantsona ary hampiharihary ny fitehirizana anatiny ho loharano.
///
/// Ny trait dia mampidi-doza satria dia tsy maintsy manohana implementers fiarovana fanampiny fananana.
/// Jereo [`as_inner`] ho an'ny antsipirihany.
///
/// # Examples
///
/// Retrieving nandevona ny ampahany loharano:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Ny loharanom-baovao iterator sehatra ao amin'ny fantsona.
    type Source: Iterator;

    /// Retrieve ny loharanom-baovao iray iterator fantsona.
    ///
    /// # Safety
    ///
    /// Implementations ny tsy maintsy hiverina mitovy mutable momba ny androm-piainany, raha tsy nosoloina mpiantso.
    /// Mety mpiantso ny boky ihany no hisolo rehefa nitsahatra iteration ka handao ny iterator fantsona rehefa hakana ny loharanom-baovao.
    ///
    /// Midika izany iterator adapters dia afaka miantehitra amin'ny loharanom-baovao tsy miova mandritra iteration fa tsy afaka miantehitra izany eo amin'ny Drop implementations.
    ///
    /// Izany dia midika hoe mametraka fomba adapters hamoy-tsy miankina ihany no mahazo ny loharano ary mety ihany no antoka nahatonga miantehitra amin'ny fomba mifototra amin'ny karazana mpandray.
    /// Ny tsy fisian'ny fahafahana miditra voafetra ihany izany ihany koa dia mitaky ny tsy maintsy manohana adapters ny loharanom-baovao ny API-bahoaka na dia efa mahazo ny internals.
    ///
    /// Mpiantso kosa manantena ny loharanom-baovao dia tsy maintsy ho amin'ny fanjakana rehetra izay mifanaraka amin'ny API ny vahoaka satria adapters nipetraka teo aminy sy ny loharano iray ihany no mahazo.
    /// Indrindra fa adaptatera mety ho levona tanteraka mihoatra noho ny zavatra ilaina.
    ///
    /// Ny tanjona ankapobeny ireo fepetra takiana dia ny hamela ny mpanjifa ny fampiasana fantsona
    /// * izay mijanona ao anaty loharano aorian'ny fijanonany dia nijanona
    /// * ny fahatsiarovana izay lasa tsy ampiasaina amin'ny alàlan'ny fampiroboroboana iterator mandany
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Ny iterator adaptatera izay mamokatra Output raha mbola ny fototra iterator `Result::Ok` mamokatra sanda.
///
///
/// Raha toa misy fahadisoana dia nihaona, ny iterator mijanona sy ny fahadisoana no voatahiry.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Alefaso ilay iterator nomena toy ny hoe nanome `T` fa tsy `Result<T, _>`.
/// Ny fahadisoana dia hampitsahatra ny anatiny iterator sy ny vokatra ankapobeny dia ho fahadisoana.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}