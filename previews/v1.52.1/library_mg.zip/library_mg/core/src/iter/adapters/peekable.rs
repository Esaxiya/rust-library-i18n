use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// Ny iterator amin'ny `peek()` miverina ho voatery momba ny singa manaraka.
///
///
/// Izany `struct` no namorona ny [`peekable`] amin'ny fomba [`Iterator`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Tsarovy ny nitsikilo danja, na dia tsy nisy.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable dia tsy maintsy mahatsiaro raha misy Tsy misy no hita ao amin'ny `.peek()` fomba.
// Izany no miantoka fa `.peek();.peek();` na `.peek();.next();` mandroso ihany ny fototra amin'ny ankamaroan'ny iterator indray mandeha.
// Tsy ho azy hanao ny iterator fused.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Miverina referansa ny sanda next() nefa tsy mandroso ilay iterator.
    ///
    /// Toa an'i [`next`], raha misy zava-dehibe, dia mifono ao amin'ny `Some(T)`.
    /// Fa raha tapitra ilay iteration dia averina `None`.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Satria `peek()` niverina ny boky, ary maro iterators iterate ny andinin-tsoratra masina, dia angamba mety ho toe-javatra izay mampisaraka ny miverina vidy dia avo roa heny ny boky.
    /// Afaka mahita izany fiantraikany ao amin'ny ohatra etsy ambany.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() manome fahafahana antsika hahita any an-future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Ny iterator dia tsy handroso isika, na dia imbetsaka `peek`
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Rehefa vita ny iterator, dia toy izany `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Miverina ny mutable momba ny next() sarobidy tsy misy fampandrosoana ny iterator.
    ///
    /// Toa an'i [`next`], raha misy zava-dehibe, dia mifono ao amin'ny `Some(T)`.
    /// Fa raha tapitra ilay iteration dia averina `None`.
    ///
    /// Satria `peek_mut()` niverina ny boky, ary maro iterators iterate ny andinin-tsoratra masina, dia angamba mety ho toe-javatra izay mampisaraka ny miverina vidy dia avo roa heny ny boky.
    /// Afaka mahita izany fiantraikany ao amin'ny ohatra etsy ambany.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Toy ny amin'ny `peek()` isika dia afaka mahita ao an-future tsy nandroso ny iterator.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Pijery eo an-iterator, ary nametraka ny vidiny ambadiky ny mutable boky.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Ny zava-dehibe dia nataony tao reappears toy ny iterator mitohy.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Araraoty ary avereno ny sanda manaraka iterator raha toa ka marina ny fepetra iray.
    /// Raha `func` mamerina `true` ho an'ny sandam-bola manaraka amin'ity iterator ity dia lano ary avereno.
    /// Raha tsy izany dia avereno `None`.
    /// # Examples
    /// Manjifa isa raha mitovy amin'ny 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Ny zavatra voalohany dia ny iterator 0;hahafongana azy.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Ny entana manaraka niverina dia 1 izao, ka `consume` hiverina `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` mamonjy ny hasarobidin'ny zavatra manaraka raha tsy mitovy `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Araraoty ny isa latsaky ny 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Lany ny isa rehetra latsaky ny 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Ny zava-dehibe manaraka niverina ho 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Koa satria antsoina hoe `self.next()`, dia nandevona `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Aringano ary hiverina ny manaraka raha zavatra mitovy `expected`.
    /// # Example
    /// Manjifa isa raha mitovy amin'ny 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Ny zavatra voalohany dia ny iterator 0;hahafongana azy.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Ny entana manaraka niverina dia 1 izao, ka `consume` hiverina `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` mamonjy ny hasarobidin'ny zavatra manaraka raha tsy mitovy `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // Famonjena, asa mampidi-doza nanatitra ho amin'ny asa mampidi-doza toy izany koa takiana
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}