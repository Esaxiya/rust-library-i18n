//! Composable iteration ivelany.
//!
//! Raha efa nahita ny tenanao amin'ny famoriam-bola ny sasany-karazany, ary ilaina mba hanao fandidiana eo amin'ny singa ny nilaza fanangonana, mihazakazaka haingana ianao ho any 'iterators'.
//! Iterators dia mavesatra ampiasaina amin'ny idiomatic Rust fehezan-dalàna, noho izany dia mendrika ny hahalalana tsara azy ireo.
//!
//! Alohan'ny hanazavana bebe kokoa dia andao hiresaka ny fomba fandrafetana ity modely ity:
//!
//! # Organization
//!
//! Module amin'ny ankapobeny ity dia nokarakarain'ny karazana:
//!
//! * [Traits] no fototra anjara: ireo traits mamaritra inona no iterators misy ary inona no azonao atao aminy.Ireo fomba ireo dia mendrika traits fanampiny mametraka ny sasany ny fotoana fianarana ho.
//! * [Functions] manomeza fomba manampy vitsivitsy hamoronana iterator tsotra.
//! * [Structs] matetika ny fiverenana karazana ny fomba isan-karazany izao ny traits Module.Matetika ianao te-hijery ny fomba izay mahatonga ny `struct`, fa tsy ny `struct` mihitsy.
//! Raha mila tsipiriany misimisy momba ny antony dia jereo ny '[Implementing Iterator](#implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Dia izay!Andao handavaka azy io.
//!
//! # Iterator
//!
//! Ny fo sy ny fanahin'ity modely ity dia ny [`Iterator`] trait.Ny fototry ny [`Iterator`] mijery tahaka izao:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! An iterator manana fomba, [`next`], izay raha atao hoe, miverina ho [`Option`]<Item>`.
//! [`next`] dia hiverina [`Some(Item)`] raha mbola misy ny singa, ary indray mandeha izy rehetra efa efa reraka, dia hiverina `None` mba milaza fa iteration Vita.
//! Iterators tsirairay dia afaka misafidy ny indray iteration, sy ny [`next`] indray niantso mety na tsy hanomboka farany [`Some(Item)`] niverina indray amin'ny fotoana iray (ohatra, jereo ny [`TryIter`]).
//!
//!
//! [`Iterator`] 's feno dia ahitana famaritana maro ny fomba hafa ihany koa, fa izy ireo fomba toerana misy anao, naorina teo ambony [`next`], ary mba haka azy ho maimaim-poana.
//!
//! Iterators koa composable, ary ny mpahazo ny rojo azy ireo ho manao zavatra bebe kokoa sarotra ampy fanodinana.Jereo ny [Adapters](#adapters) fizarana eto ambany ho an'ny antsipirihany bebe kokoa.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Ny telo endrika iteration
//!
//! Misy fomba telo fahita izay afaka mamorona iterators avy amin'ny famoriam-bola:
//!
//! * `iter()`, izay iterates ny `&T`.
//! * `iter_mut()`, izay miverina mihoatra ny `&mut T`.
//! * `into_iter()`, izay iterates ny `T`.
//!
//! Maro ny zavatra ao amin'ny fitsipika tranomboky dia mety hametraka ny iray na mihoatra ny telo, raha ilaina.
//!
//! # fampiharana Iterator
//!
//! Famoronana ny iterator mitaky lehibe eo amin'ny dingana roa: famoronana `struct` hihazona ny iterator ny fanjakana, ary avy eo ho an'ny [`Iterator`] fampiharana izany `struct`.
//! Izany no antony misy maro: struct`s ity Module: iray no ho an'ny tsirairay sy ny iterator iterator adaptatera.
//!
//! Andeha manao iterator `Counter` izay atao hoe zava-dehibe avy any `1` ho `5`:
//!
//! ```
//! // Voalohany, ny struct:
//!
//! /// Mpiverina izay manisa hatramin'ny iray ka hatramin'ny dimy
//! struct Counter {
//!     count: usize,
//! }
//!
//! // Tianay ny hanombohanay isa amin'ny iray, ka aleo manampy fomba new() hanampiana.
//! // Izany no tsy tena ilaina, fa mety.
//! // Mariho fa manomboka `count` amin'ny zero isika, ho hitantsika ny antony amin'ny fampiharana `next()`'s etsy ambany.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Avy eo, mampihatra `Iterator` ho an'ny `Counter` izahay:
//!
//! impl Iterator for Counter {
//!     // Ny fisiana ara-isika dia ho amin'ny usize
//!     type Item = usize;
//!
//!     // next() no hany takiana fomba
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Ampitomboy ny fanisanay.Izany no antony nanomboka amin'ny aotra.
//!         self.count += 1;
//!
//!         // Hamarino raha nahavita nanisa izahay na tsia.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ary ankehitriny isika dia afaka mampiasa azy io!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Calling [`next`] mahazo izany miverimberina.Rust manana fanamboarana izay afaka miantso [`next`] amin'ny iterator, mandra-mahatratra `None`.Andao hojerentsika manaraka izany.
//!
//! Koa mariho fa manome toerana misy anao `Iterator` fampiharana ny fomba toy ny `nth` sy `fold` izay miantso `next` anatiny.
//! Na izany aza, dia azo atao ihany koa ny manoratra ny fomba amam-panao toy ny fametrahana ny fomba `nth` sy `fold` raha misy iterator afaka mahomby kokoa compute azy ireo tsy miantso `next`.
//!
//! # `for` tadivavarana ary `IntoIterator`
//!
//! Ny `for` Rust Syntaxe raha ny marina manome fitoerana ho an'ny iterators siramamy.Ity misy ohatra `for` fototra:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Izany dia pirinty ny isa iray amin'ny alalan'ny dimy, samy amin'ny ny tsipika.Mariho fa ianao zavatra eto: na oviana na oviana isika hoe na inona na inona eo amin'ny vector hamokatra ny iterator.Inona no manome?
//!
//! Misy trait ao amin'ny fitsipika ho an'ny trano famakiam-boky ho toy ny manova zavatra iterator: [`IntoIterator`].
//! Io trait dia manana fomba iray, [`into_iter`], izay manova ny zavatra fampiharana [`IntoIterator`] ho any an-iterator.
//! Andeha hojerentsika izay `for` manome fitoerana indray, ary inona no niova fo ny compiler eo an-:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars ity ho:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Voalohany, antsointsika hoe `into_iter()` ny vidiny.Avy eo, dia mitovy amin'ny iterator miverina, miantso [`next`] hatrany mandra-mahita `None`.
//! Tamin'izany fotoana, dia `break` avy teo amin'ny manome fitoerana, ary nahavita iterating.
//!
//! Misy iray hafa kolaka kely eto: ny fitsipika tranomboky mahaliana ahitana fametrahana [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Amin'ny teny hafa, rehetra [: Iterator`] S hametraka [`IntoIterator`], amin'ny alalan'ny miverina fotsiny ny tenany.Midika izany zavatra roa:
//!
//! 1. Raha manoratra [`Iterator`] ianao dia azonao ampiasaina amin'ny loop `for`.
//! 2. Raha toa ianao mamorona ny famoriam-bola, fametrahana [`IntoIterator`] fa hamela ny famoriam-bola mba ho ampiasaina amin'ny `for` manome fitoerana.
//!
//! # Iterating ny reference
//!
//! Koa satria [`into_iter()`] maka `self` amin'ny vidy, amin'ny fampiasana ny `for` manome fitoerana ho iterate nandritra ny famoriam-bola manimba ny famoriam-bola.Matetika, azonao atao ny iterate mahery famoriam-bola tsy mandevona azy io.
//! Maro ny fanangonana manolotra fomba izay manome iterators ny andinin-tsoratra masina, conventionally niantso `iter()` sy `iter_mut()` tsirairay avy:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` mbola fananan'ity asa ity.
//! ```
//!
//! Raha misy famoriam-bola dia manome karazana `C` `iter()`, dia matetika ihany koa ny manatanteraka `IntoIterator` for `&C`, miaraka amin'ny fanatanterahana izay miantso `iter()` fotsiny.
//! Toy izany koa, ny famoriam-bola izay manome `iter_mut()` `C` amin'ny ankapobeny manatanteraka `IntoIterator` for `&mut C` amin'ny mamindra ny `iter_mut()`.Izany dia ahafahana manao fohy fohy:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // mitovy amin'ny `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // mitovy amin'ny `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Raha maro ny fanangonana manolotra `iter()`, tsy ny `iter_mut()` rehetra no manolotra.
//! Ohatra, mutating ny fanalahidin 'ny [`HashSet<T>`] na [`HashMap<K, V>`] afaka hametraka ny famoriam-bola ho any an-panjakana raha tsy mifanaraka ny famaha hashes fiovana, ka ireo ihany no manolotra `iter()` fanantazan-drakitra.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Functions izay maka ny [`Iterator`] sy hiverina [`Iterator`] iray hafa dia matetika antsoina hoe 'iterator adapters', toy ny ry zareo ny endriky ny 'adaptatera
//! pattern'.
//!
//! Common iterator adapters ahitana [`map`], [`take`], ary [`filter`].
//! Raha mila fanazavana, dia jereo ny tahirin-kevitra.
//!
//! Raha misy iterator adaptatera panics, ny iterator dia ho ao amin'ny tsy fantatra (fa fitadidiana soa aman-tsara) fanjakana.
//! Io fanjakana ihany koa tsy hijanona antoka toy izany koa manerana dikan ny Rust, ka tokony tsy miantehitra amin'ny marina soatoavina niverina iray iterator izay raiki-tahotra.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (ary ny iterator [adapters](#adapters)) dia *kamo*. Midika izany fa ny famoronana iterator fotsiny dia tsy _do_ be loatra. Tsy misy zavatra mitranga raha tsy miantso [`next`] ianao.
//! Izany no indraindray loharanom-fifanjevoana rehefa iterator famoronana fotsiny noho ny vokany.
//! Ohatra, ny fomba [`map`] dia miantso fanakatonana isaky ny singa miverina ao:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Tsy hanonta sanda misy ity, satria iterator ihany no noforoninay fa tsy mampiasa azy.Ny compiler dia mampitandrina antsika ny momba izany karazana fitondran-tena:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Ny fomba idiomatic mba hanoratra ny [`map`] noho ny vokany dia ny mampiasa ny `for` manome fitoerana na hiantso ny fomba [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Fomba mahazatra iray hafa hanombanana ny iterator dia ny mampiasa ny fomba [`collect`] ny ho lasa famoriam-bola vaovao.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators dia tsy mila voafetra.Ohatra, misokatra-tapitra isan-karazany dia tsy manam-petra iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Matetika ny fampiasana ny adapter iterator [`take`] dia mamadika ny iterator tsy manam-petra ho lasa finite:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Izany dia pirinty ny isa `0` amin'ny alalan'ny `4`, samy amin'ny ny tsipika.
//!
//! Tadidio fa tamin'ny fomba tsy manam-petra iterators, na dia ireo izay vokatr'izany azo tapa-kevitra ny kajy amin'ny fotoana voafetra, dia tsy hamarana.
//! Manokana, toy ny fomba [`min`], izay eo amin'ny raharaha ankapobeny mitaky mamakivaky singa rehetra ao amin'ny iterator, dia azo inoana fa tsy mba hiverina soa aman-tsara na inona na inona iterators tsy manam-petra.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Tsia!Loop tsy manam-petra!
//! // `ones.min()` mahatonga ny tsy manam-petra manome fitoerana, ka dia tsy hahatratra io izany!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;