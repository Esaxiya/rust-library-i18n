/// Ny iterator izay mahalala ny marina ny halavany.
///
/// Betsaka [`Iterator`] no tsy mahalala hoe impiry izy ireo no miverina, fa ny sasany kosa mahalala.
/// Raha misy iterator mahalala hoe impiry afaka iterate, manome fidirana izay mety ho fanazavana ilaina.
/// Ohatra, raha te-iterate aoriana, tsara fanombohana dia ny mahalala izay ny farany.
///
/// Rehefa fampiharana ny `ExactSizeIterator`, dia tsy maintsy ihany koa ny manatanteraka [`Iterator`].
/// Rehefa manao izany, ny fampiharana [`Iterator::size_hint`]*dia tokony* hamerina ny haben'ny iterator.
///
/// Ny fomba [`len`] dia manana toerana misy anao fampiharana, mba matetika tsy manatanteraka izany.
/// Na izany aza, mety ho afaka manome fampiharana fampiharana bebe kokoa noho ny toerana misy anao ianao, ka misy dikany ny fihoarana azy amin'ity tranga ity.
///
///
/// Mariho fa io dia azo antoka trait trait Ary amin'izany, misy *tsy* ary *tsy* afaka antoka fa ny halavan'ny niverina marina.
/// Midika izany fa ny kaody `unsafe`**dia tsy tokony** miankina amin'ny fahamarinan'ny [`Iterator::size_hint`].
/// Ny [`TrustedLen`](super::marker::TrustedLen) trait tsy mitombina sy tsy azo antoka dia manome io antoka io.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// // ny faritra voafetra dia mahalala tsara hoe impiry izy io no hiverina
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Ao amin'ny [module-level docs], dia ampiharina ny [`Iterator`], `Counter`.
/// Andao hampiharina `ExactSizeIterator` ho azy koa:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Azontsika atao ny mikajiana ny isa sisa iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ary ankehitriny isika dia afaka mampiasa azy io!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Miverina ny tena halavan'ny iterator.
    ///
    /// No miantoka ny fampiharana ny iterator fa hiverina marina `len()` fotoana bebe kokoa ny [`Some(T)`] sarobidy, talohan'ny niverenany [`None`].
    ///
    /// Fomba io dia manana ny toerana misy anao fampiharana, mba matetika tsy tokony manatanteraka izany mivantana.
    /// Na izany aza, raha afaka manome ny fampiharana mahomby kokoa, dia afaka manao izany.
    /// Jereo ny [trait-level] Docs ho ohatra.
    ///
    /// Izany asa izany dia manana ny antoka fiarovana toy ny [`Iterator::size_hint`] asa.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // ny faritra voafetra dia mahalala tsara hoe impiry izy io no hiverina
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Izany filazana izany dia hiaro tena loatra, fa manamarina ny invariant
        // iantohan'ny ny trait.
        // Raha izany dia rust trait-anatiny, dia afaka mampiasa debug_assert !;assert_eq!dia jereo ny mpampiasa Rust implementations koa.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Miverina `true` raha ny iterator dia foana.
    ///
    /// Ity dia manana toerana misy anao fomba fampiharana mampiasa [`ExactSizeIterator::len()`], ka tsy tokony ho fampiharana izany ny tenanao.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}