use crate::ops::{ControlFlow, Try};

/// An iterator afaka manolo singa avy amin'ny sisiny roa.
///
/// Zavatra izay fitaovana iray fanampiny `DoubleEndedIterator` manana fahaizany ny zavatra izay fitaovana [`Iterator`]: ny fahafahana: Item`s koa haka amin'ny indray, ary koa ny anoloana.
///
///
/// Zava-dehibe ny manamarika fa samy mandroso sy miverina eo amin'ny asa isan-karazany izany, ka tsy hazo fijaliana; iteration dia ny rehefa mihaona eo afovoany.
///
/// Ao koa lamaody ho an'ny [`Iterator`] protocole, indray mandeha isan-`DoubleEndedIterator` hiverina [`None`] avy [`next_back()`], ka nantsoiny hoe indray dia mety na tsy mbola hiverina [`Some`] indray.
/// [`next()`] ary [`next_back()`] dia interchangeable noho izany tanjona.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Manaisotra ary miverina ny singa avy any amin'ny faran'ny iterator.
    ///
    /// Miverina `None` raha misy singa intsony.
    ///
    /// Ny [trait-level] Docs misy tsipiriany bebe kokoa.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Ireo singa amidy ny: DoubleEndedIterator`ny fomba mety maha samy hafa ireo nanolotra ny [`Iterator`] 's fomba:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Mandroso ny iterator avy any aoriana amin'ny alàlan'ny singa `n`.
    ///
    /// `advance_back_by` dia ny mifanohitra dikan-[`advance_by`].Izany fomba dinganina dia mafy `n` singa manomboka amin'ny indray tamin'ny fiantsoana [`next_back`] niakatra ho any `n` fotoana mandra-[`None`] no nihaona.
    ///
    /// `advance_back_by(n)` dia hiverina [`Ok(())`] raha mandroso soa aman-tsara ny iterator amin'ny `n` singa, na [`Err(k)`] raha [`None`] no nihaona, izay `k` no isan'ny singa ny iterator dia nandroso teo anatrehany nihazakazaka avy singa (izany hoe
    /// ny lavan'ny iterator).
    /// Mariho fa foana `k` latsaky ny `n`.
    ///
    /// Calling `advance_back_by(0)` tsy handevona misy singa, ary miverina hatrany [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` ihany no mifalihavanja
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Miverina ny `n`th singa avy any amin'ny faran'ny iterator.
    ///
    /// Izany no indrindra ny mivadika dikan-[`Iterator::nth()`].
    /// Na dia toy ny nirakitra anarana ny ankamaroan'ny asa, ny fanisam manomboka amin'ny aotra, ka miverina voalohany `nth_back(0)` vidiny avy any amin'ny faran'ny, `nth_back(1)` ny faharoa, sy ny sisa.
    ///
    ///
    /// Mariho fa singa rehetra eo amin'ny farany sy ny niverina singa no hahalany ritra azy, anisan'izany ny singa niverina.
    /// Midika koa izany fa ny fiantsoana `nth_back(0)` imbetsaka amin'ilay iterator iray ihany dia hamerina singa samihafa.
    ///
    /// `nth_back()` dia hiverina [`None`] raha `n` dia lehibe noho na mitovy ny halavan'ny ny iterator.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Calling `nth_back()` fotoana maro tsy rewind ny iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Niverina `None` raha misy latsaka `n + 1` singa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Izany no mifanohitra dikan-[`Iterator::try_fold()`]: mila singa manomboka amin'ny indray ny iterator.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Satria fohy-circuited, ny sisa mbola misy singa amin'ny alalan'ny iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ny iterator fomba izay mampihena ny iterator ny singa ho iray, farany vidiny, manomboka avy any aoriana.
    ///
    /// Izany no mifanohitra dikan-[`Iterator::fold()`]: mila singa manomboka amin'ny indray ny iterator.
    ///
    /// `rfold()` maka kevitra roa: ny voalohany vidiny, ary ny fanakatonana roa kevitra: ny 'accumulator', ary ny singa.
    /// Ny fanidiana dia mamerina ny sanda tokony hananan'ny mpanangona ny famerenana manaraka.
    ///
    /// Ny voalohany dia ny lanjan'ny sarobidy ny accumulator ho amin'ny antso voalohany.
    ///
    /// Rehefa avy fampiharana izany fanakatonana ny singa rehetra ny iterator, `rfold()` miverina ny accumulator.
    ///
    /// Io hetsika io indraindray antsoina hoe 'reduce' na 'inject'.
    ///
    /// Ilaina ny mivalona isaky ny manana fanangonana zavatra iray ianao ary te-hamokatra sanda tokana avy amin'izany.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ny fitambaran'ny singa rehetra a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ity ohatra iray manao laha-daza, manomboka amin'ny voalohany ka hatrany amin'ny lanjany ny singa tsirairay avy aoriana mandra-anoloana:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Fikarohana ho singa iray avy aoriana iterator izay no mifanaraka tsara ho enti-.
    ///
    /// `rfind()` maka fanakatonana miverina `true` na `false`.
    /// Azo ampiharina io fanakatonana tsirairay ny iterator singa, manomboka amin'ny farany, ary raha misy amin'izy ireo hiverina `true`, dia niverina `rfind()` [`Some(element)`].
    /// Raha miverina `false` izy rehetra, dia miverina [`None`].
    ///
    /// `rfind()` Fohy-circuiting;amin'ny teny hafa, hijanona ny fikarakarana raha vantany vao miverina `true` ny fanidiana.
    ///
    /// Satria `rfind()` maka boky, ary maro iterators iterate ny andinin-tsoratra masina, izany dia mitarika amin'ny toe-javatra iray izay mety mampisaraka ny tohan-kevitra dia avo roa heny ny boky.
    ///
    /// Afaka mahita izany fiantraikany ao amin'ny ohatra etsy ambany, miaraka `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Nijanona tamin'ny voalohany `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // mbola afaka mampiasa `iter` isika, satria misy singa bebe kokoa.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}