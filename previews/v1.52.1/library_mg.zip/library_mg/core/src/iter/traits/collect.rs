/// Fiovam-po avy amin'ny [`Iterator`].
///
/// Amin'ny fampiharana `FromIterator` ho an'ny karazana iray dia faritanao ny fomba hamoronana azy io amin'ny iterator.
/// Izany no mahazatra ny karazana izay mamaritra ny famoriam-bola ny karazana.
///
/// [`FromIterator::from_iter()`] dia zara raha atao hoe mazava, ary raha tokony ampiasaina amin'ny alalan'ny fomba [`Iterator::collect()`].
///
/// Jereo ny tahirin-kevitra [`Iterator::collect()`]'s ohatra bebe kokoa.
///
/// Jereo ihany koa: [`IntoIterator`].
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Mampiasa [`Iterator::collect()`] ny mampiasa ankolaka `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Fampiharana `FromIterator` noho ny karazana:
///
/// ```
/// use std::iter::FromIterator;
///
/// // A santionany famoriam-bola, izany fotsiny wrapper eo već<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Andao omena fomba vitsivitsy izy io hahafahantsika mamorona iray ary manampy zavatra ao aminy.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ary hampihatra avy amin'ny FromIterator izahay
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ankehitriny isika dia afaka manao iterator vaovao ...
/// let iter = (0..5).into_iter();
///
/// // ... ary manao MyCollection avy ao aminy
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // asa manangona koa!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Mamorona sanda amin'ny iterator.
    ///
    /// Jereo ny [module-level documentation] raha mila fanazavana fanampiny.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Ny fiovam-po ho any an-[`Iterator`].
///
/// Amin'ny alalan'ny fampiharana `IntoIterator` ho karazana, no mamaritra ny fomba izany dia hiova fo ho amin'ny iterator.
/// Izany no mahazatra ny karazana izay mamaritra ny famoriam-bola ny karazana.
///
/// Mahasoa antsika ny fametrahana `IntoIterator` dia ny karazana no [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Jereo ihany koa: [`FromIterator`].
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Fampiharana `IntoIterator` noho ny karazana:
///
/// ```
/// // A santionany famoriam-bola, izany fotsiny wrapper eo već<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Andao omena fomba vitsivitsy izy io hahafahantsika mamorona iray ary manampy zavatra ao aminy.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ary hampihatra IntoIterator izahay
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Afaka manao fanangonana vaovao isika izao ...
/// let mut c = MyCollection::new();
///
/// // ... asio zavatra ao aminy ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ary avy eo dia miala izany ho toy ny Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Zava-mahazatra ny mampiasa `IntoIterator` ho toy ny trait bound.Io dia mamela ny karazana fanangonana fidirana hiova, raha mbola iterator izy io.
/// Ny fetra fanampiny dia azo faritana amin'ny famerana ny
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Ny karazan'ireto singa ireto izay miverimberina.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Izay karazana iterator isika no mamadika izany ho any?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Miteraka ny iterator avy amin'ny zava-dehibe.
    ///
    /// Jereo ny [module-level documentation] raha mila fanazavana fanampiny.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Hanitatra ny famoriam-bola ny anatiny iray iterator.
///
/// Iterators dia mamokatra andiana soatoavina, ary ny fanangonana dia azo heverina ho andiana soatoavina.
/// Ny `Extend` trait tetezana io hantsana, namela anao hanitatra ny famoriam-bola amin'ny alalan'ny anisan'izany ny votoatin'ny izany iterator.
/// Rehefa ny fanolorana ny famoriam-bola miaraka amin'ny efa misy manan-danja, izay misy fanavaozana, na teny, eo amin'ny raharaha izay hamela maromaro manangona ampy amin'ny fanalahidy mitovy, fa ny teny nakambana.
///
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// // Afaka manitatra ny String sasany chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Mampihatra `Extend`:
///
/// ```
/// // A santionany famoriam-bola, izany fotsiny wrapper eo već<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Andao omena fomba vitsivitsy izy io hahafahantsika mamorona iray ary manampy zavatra ao aminy.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection satria manana ny lisitry ny i32s, dia manatanteraka Mandrosoa ho i32
/// impl Extend<i32> for MyCollection {
///
///     // Izany no kely tsotsotra miaraka amin'ny karazana simenitra sonia: afaka miantso manolotra amin'ny zavatra izay azo nivadika ho any an-Iterator izay manome antsika i32s.
///     // Satria mila i32s hametraka an-MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Ny fampiharana dia mahitsy: mihodina amin'ny alàlan'ilay iterator, ary add() ny singa tsirairay ho an'ny tenantsika.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // aoka ny hanitatra ny famoriam-bola amin'ny isa telo
/// c.extend(vec![1, 2, 3]);
///
/// // dia efa nanampy ireo singa tao ny farany
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Manitatra fanangonana misy ny atin'ny iterator.
    ///
    /// Satria io no hany fomba takiana ilaina amin'ity trait ity, ireo rakitra [trait-level] dia misy antsipiriany bebe kokoa.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // Afaka manitatra ny String sasany chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Maneho ny famoriam-bola miaraka amin'ny singa iray katroka.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserves fahafahana amin'ny famoriam-bola ho an'ny nomena isan'ny singa fanampiny.
    ///
    /// Ny fampiharana default dia tsy manao na inona na inona.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}