// ignore-tidy-filelength Ity rakitra ity dia saika ny famaritana ny `Iterator` fotsiny.
// Tsy azontsika zaraina ho fisie marobe izany.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Ny interface tsara fa mifandray amin'ny iterators.
///
/// Izany no tena iterator trait.
/// Fa bebe kokoa momba ny hevitry ny hoe iterators ankapobeny, dia jereo ny [module-level documentation].
/// Indrindra indrindra, azonao atao ny hahafantatra ny fomba [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Ny karazan'ireto singa ireto izay miverimberina.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Mandroso ny iterator ary mamerina ny sanda manaraka.
    ///
    /// Miverina [`None`] rehefa vita ny famerenana.
    /// Iterator implementations tsirairay dia afaka misafidy ny indray iteration, sy ny `next()` indray niantso mety na tsy hanomboka farany [`Some(Item)`] niverina indray amin'ny fotoana iray.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Ny antso ho next() miverina ny vidiny manaraka ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ary avy eo Tsy misy intsony rehefa vita.
    /// assert_eq!(None, iter.next());
    ///
    /// // More antso mety na tsy hiverina `None`.Eto izy ireo dia hanao foana.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Mamerina ny fetra amin'ny halavan'ny iterator sisa.
    ///
    /// Manokana, `size_hint()` niverina ny tuple izay singa voalohany dia ambany nafatotra, ary ny faharoa dia ny ambony singa mifatotra.
    ///
    /// Ny faharoa dia ny antsasaky ny tuple izay niverina dia [`Option`]: <: [`usize`]> `.
    /// A [`None`] eto dia midika fa na misy tsy fantatra ambony voafehy, na ny vatony ambony dia lehibe kokoa noho namatotra [`usize`].
    ///
    /// # fanatanterahana-tsoratra
    ///
    /// Tsy ampiharina fa ny fampiharana iterator nanambara ka nanaraka ny isan'ny singa.A voatiry iterator Mety fahavokarany ambany kely noho ny namatotra na ny ambony mihoatra noho ny namatotra ny singa.
    ///
    /// `size_hint()` dia tena natao ho ampiasaina amin'ny optimizations toy ny hamandrika toerana ho an'ny zavatra ny iterator, fa tsy tokony itokisana ny ohatra, nosoratan'i fetra taratasim-bola ao amin'ny fehezan-dalàna mampidi-doza.
    /// Ny fametrahana ny `size_hint()` diso tsy tokony hitarika ny fitadidiana fanitsakitsahana fiarovana.
    ///
    /// Izany hoe, ny fanatanterahana ny marina dia tokony hanome tombany, satria raha tsy izany dia mety ho fandikana ny fifanarahana ny trait.
    ///
    /// Ny fampiharana default dia miverina `(0,` [`Tsy misy`]`)` izay marina ho an'ny iterator rehetra.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Ny ohatra sarotra kokoa:
    ///
    /// ```
    /// // Ny isa avy amin'ny aotra mihitsy aza ny folo.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mety iterate amin'ny aotra ny im-polo.
    /// // Ny fahafantarana fa dimy marina dia tsy ho tanteraka raha tsy manatanteraka filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Andeha isika manampy dimy isa amin'ny chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ankehitriny dia samy nitombo dimy ny fetra roa
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// `None` niverina ho ambony mifatotra:
    ///
    /// ```
    /// // iterator tsy manam-petra no tsy ambony nafatotra sy ny faran'ny ambony indrindra azo atao ambany
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Mandoro ny iterator, manisa ny isan'ny iterations sy fiainana indray izany.
    ///
    /// Izany fomba [`next`] Hiantso foana mandra-[`None`] no nihaona, niverina ny isan'ny fotoana dia nahita [`Some`].
    /// Mariho fa [`next`] tsy maintsy hatao hoe, fara fahakeliny, indray mandeha na dia ny iterator tsy misy singa.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Fihetsika tafahoatra
    ///
    /// Ny fomba dia tsy miambina amin'ny tondra-drano loatra, noho izany ny fanisana singa misy iterator misy singa mihoatra ny [`usize::MAX`] dia mety hamokatra valiny diso na panics.
    ///
    /// Raha azo atao ny fanamafisana debug dia azo antoka ny panic.
    ///
    /// # Panics
    ///
    /// Ity fiasa ity dia mety panic raha toa ka mihoatra ny [`usize::MAX`] ny singa iterator.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Mandany ny iterator, mamerina ny singa farany.
    ///
    /// Izany no fomba hanombanana ny iterator mandra-miverina [`None`].
    /// Raha manao izany, dia manara-maso foana ny amin'izao fotoana izao ny singa.
    /// Rehefa [`None`] dia niverina, `last()` dia hiverina ny farany dia singa dia nahita.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Mandroso ny iterator amin'ny `n` singa.
    ///
    /// Izany fomba dinganina dia mafy `n` singa tamin'ny fiantsoana [`next`] niakatra ho any `n` fotoana mandra-[`None`] no nihaona.
    ///
    /// `advance_by(n)` dia hiverina [`Ok(())`][Ok] raha mandroso soa aman-tsara ny iterator amin'ny `n` singa, na [`Err(k)`][Err] raha [`None`] no nihaona, izay `k` no isan'ny singa ny iterator dia nandroso teo anatrehany nihazakazaka avy singa (izany hoe
    /// ny lavan'ny iterator).
    /// Mariho fa foana `k` latsaky ny `n`.
    ///
    /// Calling `advance_by(0)` tsy handevona misy singa, ary miverina hatrany [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` ihany no mifalihavanja
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Miverina ny `n`th singa ny iterator.
    ///
    /// Toy ny ankamaroan'ny asa nirakitra anarana, ny fanisam manomboka amin'ny aotra, ka miverina `nth(0)` ny vidiny voalohany, `nth(1)` ny faharoa, sy ny sisa.
    ///
    /// Mariho fa singa rehetra teo aloha, ary koa ny singa tafaverina, dia ho ringan'ny amin'ny iterator.
    /// Midika izany fa ny singa teo aloha dia nariana, ary koa fa niantso `nth(0)` imbetsaka eo amin'ny iterator ihany dia hiverina singa samihafa.
    ///
    ///
    /// `nth()` dia hiverina [`None`] raha `n` dia lehibe noho na mitovy ny halavan'ny ny iterator.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Calling `nth()` fotoana maro tsy rewind ny iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Niverina `None` raha misy latsaka `n + 1` singa:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Miteraka ny iterator manomboka amin'ny hevitra toy izany, fa hanitsaka ny vola nomena isaky ny iteration.
    ///
    /// Fanamarihana 1: Ny singa voalohany ny iterator ho niverina foana, na inona na inona nomena ny dingana.
    ///
    /// Fanamarihana 2: The time amin'ny singa izay tsy niraharaha no nisintona tsy raikitra.
    /// `StepBy` mitondra tena toy ny dingana `next(), nth(step-1), nth(step-1),…`, fa maimaim-poana ihany koa ny mitondra tena toy ny filaharana
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// No lalana no ampiasaina dia mety hiova ho an'ny sasany ny antony iterators noho ny fampisehoana.
    /// Ny fomba faharoa dia handroso ny iterator tany aloha, ary haringako zavatra bebe kokoa.
    ///
    /// `advance_n_and_return_first` no mitovy amin'ny:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Ny fomba dia panic raha ny dingana nomena dia `0`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Maka iterators roa sy mamorona vaovao iterator ny na amin'ny filaharany.
    ///
    /// `chain()` dia hiverina vaovao iterator izay aloha iterate ny soatoavina avy iterator voalohany ary avy eo ny soatoavina avy amin'ny iterator faharoa.
    ///
    /// Amin'ny teny hafa, dia mampifandray iterators roa miaraka, amin'ny rojo vy.🔗
    ///
    /// [`once`] dia matetika ampiasaina hanamboarana sanda tokana ho rojom-pitiavana iteration hafa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Koa satria ny tohan-kevitra ho `chain()` mampiasa [`IntoIterator`], dia afaka mandeha na inona na inona izay mety hiova fo ho any an-[`Iterator`], fa tsy ny [`Iterator`] mihitsy.
    /// Ohatra, slices (`&[T]`) [`IntoIterator`] fanatanterahana, sy ny sisa azo lasa any `chain()` mivantana:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Raha miasa amin'ny Windows API ianao dia azonao atao ny manova ny [`OsStr`] ho `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zip up' iterator roa ho iterator tsiroaroa.
    ///
    /// `zip()` mamerina iterator vaovao izay hitetika iterator roa hafa, mamerina tuple izay ny singa voalohany dia avy amin'ny iterator voalohany, ary ny singa faharoa dia avy amin'ny iterator faharoa.
    ///
    ///
    /// Amin'ny teny hafa, dia zips iterators roa miaraka, ho iray ny iray.
    ///
    /// Raha miverina [`None`] ny iterator, dia hiverina [`None`] ny [`next`] avy amin'ilay iterator zip.
    /// Raha ny voalohany iterator niverina [`None`], `zip` dia fohy-faritra sy `next` dia tsy hatao hoe eo amin'ny iterator faharoa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Koa satria ny tohan-kevitra ho `zip()` mampiasa [`IntoIterator`], dia afaka mandeha na inona na inona izay mety hiova fo ho any an-[`Iterator`], fa tsy ny [`Iterator`] mihitsy.
    /// Ohatra, slices (`&[T]`) [`IntoIterator`] fanatanterahana, sy ny sisa azo lasa any `zip()` mivantana:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` Matetika no ampiasaina mba kaody iterator tsy manam-petra amin'ny voafetra iray.
    /// Izy io dia miasa satria ny iterator voafetra dia hiverina [`None`] amin'ny farany, mamarana ny zipper.Zipping amin'ny `(0..)` afaka mijery be dia be toy ny [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Mamorona vaovao iterator izay mametraka ny dika mitovy `separator` eo mifanila zavatra tany am-boalohany iterator.
    ///
    /// Raha toa izy tsy manatanteraka `separator` [`Clone`] na tokony computed isaky ny, mampiasa [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Singa voalohany avy any `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ilay mampisaraka.
    /// assert_eq!(a.next(), Some(&1));   // Ny singa manaraka avy amin'ny `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ilay mampisaraka.
    /// assert_eq!(a.next(), Some(&2));   // Ny singa farany avy amin'ny `a`.
    /// assert_eq!(a.next(), None);       // Ny iterator dia vita.
    /// ```
    ///
    /// `intersperse` mety ho tena ilaina mba hanatevin-daharana ny iterator ny zavatra iraisana mampiasa singa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Mamorona vaovao iterator izay mametraka ny zavatra niteraka ny `separator` eo akaikin'ny zavatra tany am-boalohany iterator.
    ///
    /// Ny fanakatonana dia hatao hoe tanteraka indray mandeha isaky ny zavatra iray dia napetraka eo anelanelan'ny zavatra roa mifanakaiky avy any amin'ny fototra iterator;
    /// manokana, ny fanakatonana tsy hoe raha toa ny vokatra fototra iterator Tsy ampy roa zavatra ary rehefa farany dia nanolotra zavatra.
    ///
    ///
    /// Raha ny zavatra iterator [`Clone`] fitaovana, dia mety ho mora kokoa ny mampiasa [`intersperse`].
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Singa voalohany avy any `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ilay mampisaraka.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Ny singa manaraka avy `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ilay mampisaraka.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Ny singa farany avy amin'ny `v`.
    /// assert_eq!(it.next(), None);               // Ny iterator dia vita.
    /// ```
    ///
    /// `intersperse_with` dia azo ampiasaina amin'ny toe-javatra izay ny Separator tokony computed:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Ny fanakatonana mutably mindran ny teny manodidina mba hiteraka zavatra iray.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Maka fanidiana ary mamorona iterator izay miantso izany fanidiana izany amin'ny singa tsirairay.
    ///
    /// `map()` manova iterator iray any amin'ny hafa, amin'ny alalan'ny ny tohan-kevitra:
    /// zavatra izay manatanteraka [`FnMut`].Izany dia mahatonga vaovao iterator izay miantso fanakatonana ity eo amin'ny singa tsirairay iterator tany am-boalohany.
    ///
    /// Raha toa ianao ka mahay mieritreritra ao karazana, dia afaka mieritreritra ny `map()` toy izao:
    /// Raha manana iterator izay manome anao karazana singa sasany `A`, ary tianao ny iterator ny hafa karazana `B`, dia afaka mampiasa `map()`, mandalo ny fanakatonana izay maka ny `A` sy miverina ny `B`.
    ///
    ///
    /// `map()` dia conceptually Mitovy amin'ny [`for`] manome fitoerana.Na izany aza, satria kamo `map()`, dia ampiasaina tsara indrindra izy io rehefa efa miara-miasa amin'ireo iteratera hafa ianao.
    /// Raha toa ianao manao karazana looping ho vokany, dia heverina ho idiomatic kokoa ny mampiasa [`for`] noho `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Raha toa ianao ka manao karazana effets effets de effets dia aleony [`for`] ka `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // aza manao an'ity:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // dia tsy dia hampihatra tahaka ny kamo.Rust dia hampitandrina anao momba izany.
    ///
    /// // Kosa, ampiasaina amin'ny:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Miantso fanakatonana amin'ny singa tsirairay amin'ny iterator.
    ///
    /// Izany dia mitovy amin'ny mampiasa [`for`] manome fitoerana teo amin'ny iterator, na dia `break` sy `continue` dia tsy azo atao avy amin'ny fanakatonana.
    /// Tena ankapobeny idiomatic kokoa ny mampiasa ny `for` manome fitoerana, fa mety kokoa `for_each` legible, rehefa zavatra fanodinana any amin'ny faran'ny iterator rojo intsony.
    ///
    /// Amin'ny toe-javatra sasany, dia mety koa ho `for_each` haingana kokoa noho ny manome fitoerana, satria dia hampiasa anatiny iteration amin'ny adapters toy ny `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Fa toy izany kely, ohatra, ny `for` manome fitoerana ho madio, fa mety ho tsaratsara kokoa `for_each` foana ny asany amin'ny fomba iterators intsony;
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Mamorona iterator izay mampiasa fanidiana hanidiana raha toa ka tokony homena singa iray.
    ///
    /// Noho ny singa tsy maintsy hiverina ny fanakatonana `true` na `false`.Ny niverina iterator dia hilefitra ihany ny singa izay fanakatonana hiverina marina.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Satria ny fanakatonana nampitaina tamin'ny `filter()` dia mila referansa, ary maro ny iteratera no miverimberina noho ny fanovozan-kevitra, izany dia mitarika toe-javatra mety hisavoritaka, izay ny karazan'ilay fanidiana dia loharano roa:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // mila roa * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mahazatra ny mampiasa manimba amin'ny tohan-kevitra hialana amin'ny iray:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // samy&sy *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// na izy roa:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // roa &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ireo sosona.
    ///
    /// Mariho fa ny `iter.filter(f).next()` dia mitovy amin'ny `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Mamorona iterator izay sady manivana no sarintany.
    ///
    /// Ny iterator niverina ka nanaraka ihany: value`s noho izay namatsy hiverina `Some(value)` fanakatonana.
    ///
    /// `filter_map` Azo ampiasaina hanaovana gadran 'ny [`filter`] sy [`map`] fohy kokoa.
    /// Ny ohatra eto ambany ity dia mampiseho ny fomba iray azo fohy `map().filter().map()` ho iray antso `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ity misy ohatra iray ihany, fa amin'ny [`filter`] sy [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Miteraka ny iterator izay manome ny fotoana fanisana iteration ary koa ny zava-dehibe manaraka.
    ///
    /// Ny vokatra niverina iterator tsiroaroa `(i, val)`, izay `i` no amin'izao fotoana izao sy ny fanondroana ny iteration `val` no zava-dehibe ny iterator niverina.
    ///
    ///
    /// `enumerate()` foana ny vidiny toy ny [`usize`].
    /// Raha te hanisa isam-bolana hafa ianao, ny lahasa [`zip`] dia manome fampiasa mitovy amin'izany.
    ///
    /// # Fihetsika tafahoatra
    ///
    /// Ny fomba no tsy miambina manohitra, feno mitafotafo ny, ka nitanisa mihoatra noho ny [`usize::MAX`] singa diso na mamokatra vokatra na panics.
    /// Raha azo atao ny fanamafisana debug dia azo antoka ny panic.
    ///
    /// # Panics
    ///
    /// Ny niverina iterator mety panic raha ny to-ho-niverina ny Foto-kevitra ho tondraka ny [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Mamorona iterator izay afaka mampiasa [`peek`] hijerena ny singa manaraka amin'ilay iterator nefa tsy mandany azy.
    ///
    /// Manampy ny [`peek`] fomba iray iterator.Jereo ny fandraketana raha mila fanazavana fanampiny.
    ///
    /// Mariho fa ny fototra iterator mbola nandroso raha [`peek`] antsoina hoe voalohany: Mba retrieve ny singa manaraka, [`next`] dia niantso ny fototra iterator, noho izany misy vokany (izany hoe
    ///
    /// na inona na inona afa-tsy ny hoe haka sarobidy manaraka) ny fomba [`next`] hitranga.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() manome fahafahana antsika hahita any an-future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // afaka peek() im-betsaka isika, tsy handroso ilay iterator
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // rehefa vita ny iterator, dia toy izany peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Miteraka ny iterator fa [: skip`] S singa mifototra amin'ny enti-.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` maka fanakatonana ho fifamaliana.Ho hiantso fanakatonana ity eo amin'ny singa tsirairay ny iterator, ka tsy miraharaha zavatra raha tsy miverina `false`.
    ///
    /// Rehefa `false` dia niverina, dia ny asa `skip_while()`'s, ary ny sisa dia nanolotra ny singa.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Satria lasa ny fanakatonana ny `skip_while()` maka boky, ary maro iterators iterate ny andinin-tsoratra masina, izany dia mitarika amin'ny toe-javatra iray mety mampisaraka, izay ny karazana tohan-kevitra ny fanakatonana dia roa boky:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // mila roa * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nijanona taorian'ny `false` voalohany:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // raha izany dia ho efa-diso, satria efa nahazo diso, skip_while() dia tsy ampiasaina intsony
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Miteraka ny vokatra singa iterator fa mifototra amin'ny enti-.
    ///
    /// `take_while()` maka fanakatonana ho fifamaliana.Ho hiantso fanakatonana ity eo amin'ny singa tsirairay ny iterator, ary atolory ny zavatra raha miverina `true`.
    ///
    /// Rehefa `false` dia niverina, dia ny asa `take_while()`'s, ary ny sisa dia tsy niraharaha ny zavatra.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Satria lasa ny fanakatonana ny `take_while()` maka boky, ary maro iterators iterate ny andinin-tsoratra masina, izany dia mitarika amin'ny toe-javatra iray mety mampisaraka, izay ny karazana ny fanakatonana dia roa boky:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // mila roa * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nijanona taorian'ny `false` voalohany:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Manana bebe kokoa singa izay latsaky ny aotra, Fa hatrizay efa nahazo diso, take_while() dia tsy ampiasaina intsony
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Satria `take_while()` Mila mijery ny zava-dehibe mba hijery raha tokony ho tafiditra na tsia, mandany iterators ho hitanao fa nesorina:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ny `3` intsony ao, satria ritra mba hahitana raha ny iteration tokony hijanona, fa tsy nametraka niverina ho any an-iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Miteraka ny vokatra iterator fa samy singa mifototra amin'ny enti-sy sarintany.
    ///
    /// `map_while()` maka fanakatonana toy ny tohan-kevitra.
    /// Ho hiantso fanakatonana ity eo amin'ny singa tsirairay ny iterator, ary atolory ny zavatra raha miverina [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ity ny tahaka izany koa, fa [`take_while`] sy [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nijanona taorian'ny [`None`] voalohany:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Manana zavatra bebe kokoa izay mety antonona ao u32 (4, 5), fa niverina `map_while` `None` for `-3` (toy ny `predicate` niverina `None`) sy `collect` mijanona tamin'ny voalohany nihaona `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Satria `map_while()` Mila mijery ny zava-dehibe mba hijery raha tokony ho tafiditra na tsia, mandany iterators ho hitanao fa nesorina:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// Ny `-3` intsony ao, satria ritra mba hahitana raha ny iteration tokony hijanona, fa tsy nametraka niverina ho any an-iterator.
    ///
    /// Mariho fa tsy toy ny [`take_while`] ity iterator ity dia **tsy** miangona.
    /// Ny tsy mazava koa izay hevitry ny teny miverina iterator taorian'ny [`None`] voalohany dia niverina.
    /// Raha toa ka mila fused iterator, mampiasa [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Izay miteraka ny iterator skips voalohany `n` singa.
    ///
    /// Rehefa avy izy ireo efa levon'ny, ny sisa Ireo singa dia nanolotra.
    /// Tsy miahy ny fomba mivantana izany, fa tsy fomba handresentsika ny `nth`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Miteraka ny iterator izay mahavokatra ny singa `n` voalohany.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` dia matetika no ampiasaina miaraka amin'ny tsy manam-petra iterator, mba ataovy voafetra:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Raha latsaky ny `n` singa misy, `take` dia mametra ny tenany ho ny haben'ny ny fototra iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An iterator adaptatera mitovy amin'ny [`fold`] izay mihazona fanjakana anatiny sy mamokatra iterator vaovao.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` maka kevitra roa: voalohany, izay sanda ambioka ny anatiny fanjakana, ary ny fanakatonana roa tohan-kevitra, ny voalohany maha-mutable anatiny momba ny fanjakana sy ny faharoa dia ny iterator singa.
    ///
    /// Ny fanakatonana dia afaka manendry ny anatiny fanjakana hizara ny fanjakana eo iterations.
    ///
    /// Amin'ny fandefasana azy, ny fanidiana dia hampiharina amin'ny singa tsirairay amin'ilay iterator ary ny sandan'ny fiverenana avy amin'ny fanidiana, [`Option`], dia omen'ny iterator.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // iteration tsirairay, dia Ho hampitombo ny fanjakana ny singa
    ///     *state = *state * x;
    ///
    ///     // Avy eo, dia Ho hilefitra ny negation de l'Etat
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Miteraka ny iterator izay miasa toy ny sarintany, fa flattens nested rafitra.
    ///
    /// Ny [`map`] adaptatera no tena ilaina, fa raha tsy miteraka ny fanakatonana soatoavina tohan-kevitra.
    /// Raha mahatonga ny iterator fa, misy fanampiny sosona indirection.
    /// `flat_map()` hesoriny izany fanampiny sosona amin'ny ny azy.
    ///
    /// Afaka mieritreritra ny `flat_map(f)` ho toy ny zotran mitovy ny [: map`] Ping, ary avy eo [`flatten`]` ary toy ny ao amin'ny `map(f).flatten()`.
    ///
    /// Fomba iray hafa ny mieritreritra `flat_map()`: [`map`] 's fanakatonana miverina zavatra iray isaky ny singa, ary `flat_map()`'s fanakatonana ny iterator miverina isaky ny singa.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mamerina iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Izay miteraka ny iterator flattens nested rafitra.
    ///
    /// Izany no mahasoa rehefa manana iterator ny iterators na iterator ny zavatra izay afaka ho tonga iterators ary te-hanaisotra ny indirection ambaratonga iray.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Sarintany ary apetaho avy eo:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mamerina iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Azonao atao koa ny mamerina manoratra izany eo amin'ny [`flat_map()`], izay tsaratsara kokoa amin'ity tranga ity no nampitain'i finiavana satria mazava kokoa:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mamerina iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ny flattening dia manala ambaratonga iray isaky ny indray mandeha:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Eto isika dia mahita fa `flatten()` tsy manao ny "deep" flatten.
    /// Kosa, iray ihany no haavon'ny akany esorina.Izany hoe, raha `flatten()` telo amin'ny lafiny nitsangana, ny vokany dia ho amin'ny lafiny roa fa tsy tokana.
    /// Mba hahazoana tokana rafitra, tsy maintsy `flatten()` indray.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Izay miteraka ny iterator Mifarana taorian'ny [`None`] voalohany.
    ///
    /// Rehefa niverina ny iterator [`None`], future antso mety na tsy hahavokatra [`Some(T)`] intsony.
    /// `fuse()` adapts ny iterator, antoka fa rehefa ny [`None`] omena, dia hiverina foana [`None`] mandrakizay.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// // ny iterator izay mpisolo eo ny sasany ary tsy misy
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // raha izany aza, Some(i32), Tsy misy hafa
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // dia afaka mahita ny iterator mandeha sy miverina
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Na izany aza, indray mandeha mampifangaro azy io izahay ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // dia hiverina foana `None` taorian'ny fotoana voalohany.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Manao zavatra amin'ny tsirairay iterator singa iray, mandalo ny hasarobidin'ny on.
    ///
    /// Rehefa mampiasa iterators, matetika ianao rojo maro ny azy ireo.
    /// Mandritra ny fiasa amin'ny kaody toy izany dia azonao atao ny manamarina ny zava-mitranga amin'ny faritra maro ao amin'ny fantsona.Mba hanaovana izany, dia ampidiro eto ny antso `inspect()`.
    ///
    /// Matetika kokoa ny `inspect()` dia ampiasaina ho fitaovana debugging toy izay misy ao amin'ny kaody farany anao, saingy mety ho hitan'ny fampiharana fa ilaina amin'ny toe-javatra sasany izany rehefa mila soratana ny lesoka alohan'ny fanariana azy.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // iterator ity filaharany dia sarotra.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // andao ampiana antso inspect() hanadihady ny zava-mitranga
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Izany dia pirinty:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Miditra fahadisoana alohan'ny hanariana azy;
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Izany dia pirinty:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Mindran ny iterator, fa tsy mandany izany.
    ///
    /// Izany no ilaina ny mamela hampihatra iterator adapters raha mbola notazonina tompon'ny iterator tany am-boalohany.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // raha miezaka ny mampiasa iter indray, dia tsy miasa.
    /// // Ireto andalana manaraka ireto dia manome "lesoka: fampiasana sanda nafindra: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // aoka ny hanandrana izany indray
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // fa, dia hametraka ao amin'ny .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // tsara izao:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Manova ny iterator ho famoriam-bola.
    ///
    /// `collect()` afaka mandray iterable rehetra, ary mamadika azy ho toy ny fanangonana mifandraika.
    /// Izany no iray amin'ireo fomba mahery kokoa ao amin'ny fitsipika tranomboky, ampiasaina amin'ny toe-javatra isan-karazany.
    ///
    /// Ny tena fototra lamina izay `collect()` no ampiasaina dia ny hiverina iray ho famoriam-bola iray hafa.
    /// Ianao maka famoriam-bola, miantso [`iter`] eo aminy, manao ny bunch ny fiovana, ary avy eo `collect()` amin'ny farany.
    ///
    /// `collect()` atao koa ny mamorona ohatra ny karazana izay tsy mahazatra fanangonana.
    /// Ohatra, ny [`String`] azo naorina avy amin'ny [: char`] s, ary ny iterator ny [`Result<T, E>`][`Result`] zavatra azo nangonina any `Result<Collection<T>, E>`.
    ///
    /// Jereo ireto ohatra etsy ambany ireto raha te hahalala bebe kokoa.
    ///
    /// Satria `collect()` dia ankapobeny, dia mety hiteraka olana amin'ny karazana inference.
    /// Araka izany, `collect()` dia iray amin'ireo fotoana vitsy ahitanao ilay syntax fantatra amin'ny anarana hoe 'turbofish': `::<>`.
    /// Manampy ny algorithm fehin-kevitra hahalala manokana izay fanangonana tadiavinao angonina.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Mariho fa nila ny `: Vec<i32>` eo amin'ny ankaviany-tanana ilany.Ny antony dia satria isika afaka manangona an, ohatra, fa tsy ny [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Amin'ny alalan'ny fampiasana ny 'turbofish' fa tsy annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Satria `collect()` ihany no miahy izay tena fanangonana an, ianao mbola afaka mampiasa ampahany Soso-kevitra karazana, `_`, ny turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Mampiasa `collect()` mba manao [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Raha manana lisitr'ireo [`Result<T, E>`][: Result`] s, dia afaka mampiasa `collect()` mba hahitana raha tsy misy azy ireo:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // manome antsika ny lesoka voalohany
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // manome antsika ny lisitry ny valiny
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Mandevona ny iterator, famoronana fanangonana roa avy amin'izany.
    ///
    /// Ny predicate nalefa tamin'ny `partition()` dia afaka miverina `true`, na `false`.
    /// `partition()` miverina roa, ny singa rehetra noho izay niverina `true`, ary ny singa rehetra noho izay niverina `false`.
    ///
    ///
    /// Jereo koa ny [`is_partitioned()`] sy [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders ny singa ity iterator *in-toerana* araka ny nomena enti, fa toy ireo rehetra izay niverina `true` hialoha izay rehetra hiverina `false`.
    ///
    /// Miverina ny isan'ny singa `true` hita.
    ///
    /// Ny havany mba ny partitioned zavatra tsy foana.
    ///
    /// Jereo koa ny [`is_partitioned()`] sy [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Fizarazaran'I in-toerana eo amin'ny evens sy ny mifanohitra
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: Tokony hatahotra ve isika momba ny fanisam tondraka?Ny hany fomba kokoa noho ny
        // `usize::MAX` mutable andinin-tsoratra masina no momba ZSTs, izay tsy mahasoa ny fisarahana ...

        // Ireo fiasa fanakatonana "factory" ireo dia misy mba hisorohana ny fahalalahana amin'ny `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Avereno jerena ny `false` voalohany ary ovao amin'ny `true` farany.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Taratasim-bola raha ny singa io dia partitioned iterator araka ny nomena enti, fa toy ireo rehetra izay niverina `true` hialoha izay rehetra hiverina `false`.
    ///
    ///
    /// Jereo koa ny [`partition()`] sy [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Na ny singa rehetra maka fanahy `true`, na ny tapany voalohany amin'ny `false` mijanona ary mijery fa tsy misy intsony `true` zavatra taorian'izay.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Ny fomba iterator izay mampihatra ny asa raha mbola miverina soa aman-tsara, mamokatra iray, sarobidy farany.
    ///
    /// `try_fold()` maka kevitra roa: ny voalohany vidiny, ary ny fanakatonana roa kevitra: ny 'accumulator', ary ny singa.
    /// Ny fanakatonana na miverina soa aman-tsara, ny zava-dehibe fa ny accumulator tokony ho ny manaraka iteration, na dia miverina tsy fahombiazana, miaraka amin'ny fahadisoana sarobidy izay aelin'ny indray ny mpiantso (short-circuiting) avy hatrany.
    ///
    ///
    /// Ny voalohany dia ny lanjan'ny sarobidy ny accumulator ho amin'ny antso voalohany.Raha nahomby ny fampiharana ny fanakatonana amin'izay rehetra singa ny iterator, `try_fold()` accumulator miverina ny farany toy ny fahombiazana.
    ///
    /// Ilaina ny mivalona isaky ny manana fanangonana zavatra iray ianao ary te-hamokatra sanda tokana avy amin'izany.
    ///
    /// # Fanamarihana ho an'ny mpampihatra
    ///
    /// Maro ny fomba hafa dia manana toerana misy anao (forward) implementations amin'ny resaka ity iray ity, ka miezaka ho fampiharana izany mazava tsara raha afaka manao zavatra tsara kokoa noho ny toerana misy anao `for` fampiharana manome fitoerana.
    ///
    /// Indrindra indrindra, miezaka manana antso ity `try_fold()` eo amin'ny faritra anatiny izay iterator ity dia ahitana.
    /// Raha antso maro no ilaina, ny mpandraharaha `?` mety ho mety ho an'ny chaining ny accumulator sarobidy miaraka, fa mitandrema izay invariants, izay tokony ho nanohana ireo tany am-boalohany alohan'ny miverina.
    /// Izany no fomba iray `&mut self`, ka mila ho iteration resumable rehefa avy mikapoka fahadisoana eto.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ny teny isan'ny singa rehetra ireo 'ny fihaingoana
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Tondraka vola io rehefa manampy ny 100 singa
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Satria fohy-circuited, ny sisa mbola misy singa amin'ny alalan'ny iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ny fomba iterator izay mampihatra ny hadisoana miasa ny zavatra tsirairay ao amin'ny iterator, nijanona tamin'ny voalohany fahadisoana sy fiainana indray izany fahadisoana.
    ///
    ///
    /// Izany koa dia nieritreritra toy ny hadisoana amin'ny teny [`for_each()`] na toy ny manana zom-pirenena dikan-[`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Tsy fohy-circuited, toy izany koa ny zavatra sisa mbola ao an-iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Vala ho toy ny singa rehetra accumulator amin'ny alalan'ny fampiharana ny fandidiana, niverina ny vokatra farany.
    ///
    /// `fold()` maka kevitra roa: ny voalohany vidiny, ary ny fanakatonana roa kevitra: ny 'accumulator', ary ny singa.
    /// Ny fanidiana dia mamerina ny sanda tokony hananan'ny mpanangona ny famerenana manaraka.
    ///
    /// Ny voalohany dia ny lanjan'ny sarobidy ny accumulator ho amin'ny antso voalohany.
    ///
    /// Aorian'ny fampiharana an'io fanidiana io amin'ny singa rehetra ao amin'ilay iterator, `fold()` dia mamerina ilay mpanangona.
    ///
    /// Io hetsika io indraindray antsoina hoe 'reduce' na 'inject'.
    ///
    /// Ilaina ny mivalona isaky ny manana fanangonana zavatra iray ianao ary te-hamokatra sanda tokana avy amin'izany.
    ///
    /// Note: `fold()`, ary mitovy fomba izay nita ny iterator manontolo, tsy hamarana ho an'ny tsy manam-petra iterators, na dia amin'ny traits izay ny vokany dia determinable amin'ny fotoana voafetra.
    ///
    /// Note: [`reduce()`] Azo ampiasaina hampiasa ny voalohany ho toy ny singa sarobidy voalohany, raha ny accumulator karazana sy ny zavatra karazana iray ihany izany.
    ///
    /// # Fanamarihana ho an'ny mpampihatra
    ///
    /// Maro ny fomba hafa dia manana toerana misy anao (forward) implementations amin'ny resaka ity iray ity, ka miezaka ho fampiharana izany mazava tsara raha afaka manao zavatra tsara kokoa noho ny toerana misy anao `for` fampiharana manome fitoerana.
    ///
    ///
    /// Indrindra indrindra, miezaka manana antso ity `fold()` eo amin'ny faritra anatiny izay iterator ity dia ahitana.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ny isan'ny singa rehetra ireo 'ny fihaingoana
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Andeha hodiavintsika eto ny dingana tsirairay amin'ilay famerenana:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Ary noho izany, ny valiny farany, `6`.
    ///
    /// Izany dia midika hoe mahazatra ho an'ny olona izay tsy nampiasa iterators betsaka ny mampiasa `for` manome fitoerana miaraka amin'ny lisitry ny zavatra mba hanangana vokatr'izany.Ireo dia afaka ho tonga `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // fa manome fitoerana:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // toy izany koa ry zareo
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Mampihena singa iray amin'ny singa tokana, amin'ny alàlan'ny fampiharana miverimberina fihenam-bidy.
    ///
    /// Raha ny iterator Foana, niverina [`None`];raha tsy izany, miverina ny vokatry ny fampihenana.
    ///
    /// Ho an'ireo iteratera manana singa iray farafahakeliny, dia mitovy amin'ny [`fold()`] ity misy ny singa voalohany amin'ilay iterator ho sanda voalohany, mamoritra ireo singa manaraka rehetra ao aminy.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Tadiavo ny ambony indrindra vidiny:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Fitsapana raha mifanaraka amin'ny predicate ny singa rehetra amin'ilay iterator.
    ///
    /// `all()` maka fanakatonana miverina `true` na `false`.Azo ampiharina izany fanakatonana ny singa tsirairay ny iterator, ary raha hiverina `true` izy rehetra, dia toy izany no `all()`.
    /// Ary raha misy amin'ny hiverina `false`, dia miverina `false`.
    ///
    /// `all()` dia mivezivezy fohy;amin'ny teny hafa, dia intsony fanodinana raha vao mahita ny `false`, nomena fa tsy misy na inona na inona koa no mitranga, ny vokany dia ho `false` koa.
    ///
    ///
    /// Ny iterator foana dia mamerina `true`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Nijanona tamin'ny voalohany `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // mbola afaka mampiasa `iter` isika, satria misy singa bebe kokoa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Fitsapana raha misy singa amin'ny iterator mifanandrify amina enti-.
    ///
    /// `any()` maka fanakatonana miverina `true` na `false`.Azo ampiharina izany fanakatonana ny singa tsirairay ny iterator, ary raha misy amin'izy ireo hiverina `true`, dia toy izany no `any()`.
    /// Raha miverina `false` izy rehetra, dia miverina `false`.
    ///
    /// `any()` Fohy-circuiting;amin'ny teny hafa, dia intsony fanodinana raha vao mahita ny `true`, nomena fa tsy misy na inona na inona koa no mitranga, ny vokany dia ho `true` koa.
    ///
    ///
    /// - Poana iterator hiverina `false`.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Nijanona tamin'ny voalohany `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // mbola afaka mampiasa `iter` isika, satria misy singa bebe kokoa.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Fikarohana ho singa iray iterator izay no mifanaraka tsara ho enti-.
    ///
    /// `find()` maka fanakatonana miverina `true` na `false`.
    /// Azo ampiharina izany fanakatonana ny singa tsirairay ny iterator, ary raha misy amin'izy ireo hiverina `true`, dia niverina `find()` [`Some(element)`].
    /// Raha miverina `false` izy rehetra, dia miverina [`None`].
    ///
    /// `find()` Fohy-circuiting;amin'ny teny hafa, hijanona ny fikarakarana raha vantany vao miverina `true` ny fanidiana.
    ///
    /// Satria `find()` maka boky, ary maro iterators iterate ny andinin-tsoratra masina, izany dia mitarika amin'ny toe-javatra iray izay mety mampisaraka ny tohan-kevitra dia avo roa heny ny boky.
    ///
    /// Afaka mahita izany fiantraikany ao amin'ny ohatra etsy ambany, miaraka `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Nijanona tamin'ny voalohany `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // mbola afaka mampiasa `iter` isika, satria misy singa bebe kokoa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Mariho fa `iter.find(f)` dia mitovy amin'ny `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Mihatra miasa ny singa iterator sy miverina voalohany tsy misy vokany.
    ///
    ///
    /// `iter.find_map(f)` dia mitovy `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Mihatra miasa ny singa iterator sy miverina voalohany vokatra marina na ny fahadisoana voalohany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Fikarohana ho singa ao amin'ny iterator, niverina ny tondro.
    ///
    /// `position()` maka fanakatonana miverina `true` na `false`.
    /// Azo ampiharina izany fanakatonana ny singa tsirairay ny iterator, ary ny iray tamin'izy ireo raha miverina `true`, dia niverina `position()` [`Some(index)`].
    /// Raha miverina `false` izy rehetra dia mamerina [`None`].
    ///
    /// `position()` Fohy-circuiting;amin'ny teny hafa, dia intsony fanodinana raha vao mahita ny `true`.
    ///
    /// # Fihetsika tafahoatra
    ///
    /// Ny fomba dia tsy miambina amin'ny tondra-drano loatra, koa raha misy mihoatra ny singa [`usize::MAX`] tsy mifanandrify, dia mety hamokatra valiny diso na panics.
    ///
    /// Raha azo atao ny fanamafisana debug dia azo antoka ny panic.
    ///
    /// # Panics
    ///
    /// Ity fiasa ity dia mety panic raha ny iterator dia mihoatra ny `usize::MAX` singa tsy mitovy.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Nijanona tamin'ny voalohany `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // mbola afaka mampiasa `iter` isika, satria misy singa bebe kokoa.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Ny tondro niverina miankina amin'ny fanjakana iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Fikarohana ho singa ao amin'ny iterator avy any ankavanana, niverina ny tondro.
    ///
    /// `rposition()` maka fanakatonana miverina `true` na `false`.
    /// Azo ampiharina izany fanakatonana ny singa tsirairay ny iterator, manomboka avy ny farany, ary ny iray tamin'izy ireo raha miverina `true`, dia niverina `rposition()` [`Some(index)`].
    ///
    /// Raha miverina `false` izy rehetra dia mamerina [`None`].
    ///
    /// `rposition()` Fohy-circuiting;amin'ny teny hafa, dia intsony fanodinana raha vao mahita ny `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Nijanona tamin'ny voalohany `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // mbola afaka mampiasa `iter` isika, satria misy singa bebe kokoa.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Tsy misy ilaina ny mijery be ny vokatra eto, satria `ExactSizeIterator` dia midika fa ny isan'ny singa mifanentana ho `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Miverina ny ambony indrindra iterator singa iray.
    ///
    /// Raha singa maromaro mitovy farafahakeliny dia averina ny singa farany.
    /// Raha ny iterator Foana, [`None`] dia niverina.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Miverina ny kely indrindra singa iray iterator.
    ///
    /// Raha maro Dia samy singa kely indrindra, ny singa voalohany dia niverina.
    /// Raha ny iterator Foana, [`None`] dia niverina.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Miverina ny singa izay manome ny vidiny ambony indrindra avy amin'ny asa voafaritra.
    ///
    ///
    /// Raha singa maromaro mitovy farafahakeliny dia averina ny singa farany.
    /// Raha ny iterator Foana, [`None`] dia niverina.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Miverina ny singa manome ny sanda ambony indrindra momba ny fampitahana voafaritra.
    ///
    ///
    /// Raha singa maromaro mitovy farafahakeliny dia averina ny singa farany.
    /// Raha ny iterator Foana, [`None`] dia niverina.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Miverina ny singa izay manome ny vidiny ambany indrindra amin'ny asa voafaritra.
    ///
    ///
    /// Raha maro Dia samy singa kely indrindra, ny singa voalohany dia niverina.
    /// Raha ny iterator Foana, [`None`] dia niverina.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Miverina ny singa izay manome ny vidiny ambany indrindra amin'ny fanajana ny lasa mihamatanjaka ny fampitahana ny asa.
    ///
    ///
    /// Raha maro Dia samy singa kely indrindra, ny singa voalohany dia niverina.
    /// Raha ny iterator Foana, [`None`] dia niverina.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Zavatra mampalahelo ny iterator ny tari-dalana.
    ///
    /// Matetika, iterators iterate avy eo ankavia miankavanana.
    /// Rehefa mampiasa `rev()`, fa tsy ho iray iterator iterate avy any ankavanana miankavia.
    ///
    /// Tsy azo atao izany raha tsy misy farany ny iterator, ka `rev()` dia miasa amin'ny [DoubleEndedIterator`] ihany.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Manova ny iterator an'ny tsiroaroa ho lasa kaontenera roa.
    ///
    /// `unzip()` mandevona iray manontolo iterator ny tsiroaroa, mamokatra fanangonana roa: ny iray avy amin'ny ankavia singa ny tsiroaroa, ary ny iray avy any ankavanana singa.
    ///
    ///
    /// Izany asa izany, amin'ny lafiny sasany, ny mifanohitra amin'ny [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Mamorona iterator izay mandika ny singa rehetra ao aminy.
    ///
    /// Izany no mahasoa rehefa manana iterator ny `&T`, fa mila ny iterator ny `T`.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // nadika dia toy .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Mamorona iterator izay [`clone`] ny singa rehetra ao aminy.
    ///
    /// Izany no mahasoa rehefa manana iterator ny `&T`, fa mila ny iterator ny `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned dia mitovy amin'ny .map(|&x| x), fa integers
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Mamerina ny iterator hiaina mandrakizay isika.
    ///
    /// Fa tsy nijanona tao [`None`], fa tsy ny iterator dia manomboka indray, hatrany am-piandohana.Rehefa avy iterating indray, dia manomboka amin'ny voalohany indray.Ary indray.
    /// Ary indray.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Mamintina ny singa iray iterator.
    ///
    /// Raiso ny singa tsirairay, ampiarahan'izy ireo ary averina ny valiny.
    ///
    /// - Poana iterator miverina ny aotra sarobidy ny karazana.
    ///
    /// # Panics
    ///
    /// Rehefa niantso `sum()` sy faran'izay tsotra karazana integer dia ho tafaverina, io no fomba panic raha ny computation sy ny debug, feno mitafotafo ny fanizingizinana no alefa.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates nandritra ny manontolo iterator, hahamaro ny singa rehetra
    ///
    /// Ny iterator foana dia mamerina ny lanjan'ilay karazany.
    ///
    /// # Panics
    ///
    /// Rehefa niantso `product()` sy ny faran'izay tsotra dia integer karazana rehefa niverina, dia panic fomba raha ny computation sy ny debug, feno mitafotafo ny fanizingizinana no alefa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) mampitaha ny singa ity amin'ny [`Iterator`] ny an'ny hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) mampitaha ny singa ity [`Iterator`] amin'ireo iray hafa mikasika ny lasa mihamatanjaka ny fampitahana ny asa.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) mampitaha ny singa ity amin'ny [`Iterator`] ny an'ny hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) mampitaha ny singa ity [`Iterator`] amin'ireo iray hafa mikasika ny lasa mihamatanjaka ny fampitahana ny asa.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Mamaritra raha toa ny singa io [`Iterator`] dia mitovy ny an'ny hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Mamaritra raha toa ka mitovy amin'ny an'ny iray hafa ny singa amin'ity [`Iterator`] ity raha oharina amin'ilay asa fitoviana voalaza.
    ///
    ///
    /// # Examples
    ///
    /// Fampiasana fototra:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Mamaritra raha toa ny singa ity dia mitovy [`Iterator`] ho ny an'ny hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Famaritana raha ny singa amin'ity [`Iterator`] ity dia [lexicographically](Ord#lexicographical-comparison) kely kokoa noho ireo an'ny hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Mamaritra raha toa ny singa ity dia [lexicographically](Ord#lexicographical-comparison) [`Iterator`] na kely na mitovy amin'ny ny an'ny hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Mamaritra raha toa ny singa ity [lexicographically](Ord#lexicographical-comparison) [`Iterator`] dia lehibe noho ny an'ny hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Mamaritra raha toa ny singa ity [lexicographically](Ord#lexicographical-comparison) [`Iterator`] dia lehibe noho na mitovy ho an'ireo iray hafa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Taratasim-bola raha ny singa ity dia nandamina iterator.
    ///
    /// Izany hoe, ho an'ny tsirairay sy ny singa `a` singa manaraka `b`, dia tsy maintsy mihazona `a <= b`.Raha toa ka nanaraka ny iterator katroka aotra na ny singa, `true` dia niverina.
    ///
    /// Mariho fa raha `PartialOrd` `Self::Item` ihany, fa tsy `Ord`, ny famaritana etsy ambony dia midika fa asa io miverina `false` raha misy zavatra roa nisesy dia tsy ampy.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Taratasim-bola raha ny singa ity dia nandamina iterator mampiasa ny comparator nomena asa.
    ///
    /// Raha tokony mampiasa `PartialOrd::partial_cmp`, asa io dia mampiasa ny `compare` nomena asa mba hamantarana ny zavatra antokony roa.
    /// Ankoatra izany, dia mitovy amin'ny [`is_sorted`];jereo ny antontan-taratasiny raha mila fanazavana fanampiny.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Taratasim-bola raha ny singa ity dia nandamina iterator mampiasa ny fanalahidy nomena asa fitrandrahana.
    ///
    /// Raha tokony fampitahana ny iterator ny singa mivantana, izany asa mampitaha ny fanalahidin 'ny singa, araka ny faritan'ny `f`.
    /// Ankoatra izany, dia mitovy amin'ny [`is_sorted`];jereo ny antontan-taratasiny raha mila fanazavana fanampiny.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Jereo ny [TrustedRandomAccess]
    // Ny anarana mahazatra dia ny tsy anarana fifandonana eo amin'ny fomba fanapahan-kevitra jereo #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}