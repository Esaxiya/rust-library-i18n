/// Ny iterator izay mbola hilefitra foana `None` rehefa reraka.
///
/// Niantso manaraka amin'ny fused iterator izay niverina indray mandeha `None` azo antoka mba hiverina [`None`] indray.
/// Izany dia tokony ho trait napetraky iterators rehetra izay mitondra tena izany satria mamela optimizing [`Iterator::fuse()`].
///
///
/// Note: Amin'ny ankapobeny, tsy tokony hampiasa `FusedIterator` in levitra fetra raha toa ka mila fused iterator.
/// Kosa, dia tokony hiantso fotsiny [`Iterator::fuse()`] ny iterator.
/// Raha ny iterator dia efa fused, ny fanampiny [`Fuse`] wrapper ho tsy-OP tsy misy fampisehoana sazy.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Mpiverina izay mitatitra ny halavany marina amin'ny fampiasana size_hint.
///
/// Ny iterator dia mitatitra fambara habe iray izay mety ho marina (ny fatorana ambany dia mitovy amin'ny fatorana ambony), na ny fika ambony dia [`None`].
///
/// Ny faran'ny ambony ihany no tsy maintsy ho [`None`] raha ny tena halavan'ny iterator dia lehibe kokoa noho ny [`usize::MAX`].
/// Amin'izay dia tsy maintsy [`usize::MAX`] ny faran'ny ambany, ary miteraka [`Iterator::size_hint()`] `(usize::MAX, None)`.
///
/// Ny iterator dia tsy maintsy mamokatra marina ny isan'ny singa notateriny na navadika alohan'ny hahatongavany amin'ny farany.
///
/// # Safety
///
/// Ity trait ity dia tsy maintsy ampiharina rehefa voatazona ny fifanarahana.
/// Mpanjifa izany dia tsy maintsy nandinika [`Iterator::size_hint()`]’s trait ambony mifatotra.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ny iterator fa rehefa mandefitra ny zavatra dia efa iray, fara fahakeliny singa avy amin'ny fototra [`SourceIter`].
///
/// Calling misy fomba izay mandroso ny iterator, ohatra
/// [`next()`] na [`try_fold()`], antoka fa isaky ny dingana iray, fara fahakeliny lanjan'ny fototra ny iterator ny loharanom-baovao dia nifindra ka ny vokatry ny rojo iterator azo asisika amin'ny fitoerany iny, mihevitra ho manana ho ara-drafitra faneren'ny ny loharanom-baovao mamela toy izany fampidirana.
///
/// Amin'ny teny hafa izany dia mampiseho fa ny trait fantsona iterator azo nangonina amin'ny toerany.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}