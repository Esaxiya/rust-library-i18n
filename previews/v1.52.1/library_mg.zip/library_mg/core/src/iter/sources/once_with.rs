use crate::iter::{FusedIterator, TrustedLen};

/// Mamorona iterator izay mamorona kamo amin'ny fomba kamo iray indray mandeha monja amin'ny fiantsoana ilay fanidiana natolotra.
///
/// Izany dia fampiasa mba mampifanaraka sanda iray gropy ho any amin'ny [`chain()`] hafa karazana iteration.
/// Angamba ianao manana iterator fa saika ny zava-drehetra fonony, fa mila fanampiny tranga manokana.
/// Angamba manana asa izay miasa amin'ny iterators, fa ianao ihany no mila ny fandraisana zava-dehibe iray.
///
/// Tsy toy ny [`once()`], asa izany dia kamo hiteraka ny hasarobidin'ny amin'ny fangatahana.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::iter;
///
/// // ny anankiray no loneliest isa
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // iray monja dia izay ihany no azontsika
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining miaraka iterator hafa.
/// Andeha hatao hoe tsy tiantsika ny iterate ny antontan-taratasy tsirairay ny `.foo` Directory, fa koa ny fanahafana rakitra,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // tokony hiova avy iterator ny DirEntry-s ho amin'ny iterator ny PathBufs, noho izany dia mampiasa sarintany
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ankehitriny, ry iterator fotsiny ny config rakitra
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // iterators gadra roa ho eo an iray lehibe iterator
/// let files = dirs.chain(config);
///
/// // izany dia hanome antsika rehetra ny raki-daza amin .foo ary koa .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Ny iterator izay mahavokatra iray karazana singa `A` amin'ny alalan'ny fampiharana ny nanome `F: FnOnce() -> A` fanakatonana.
///
///
/// Ity `struct` ity dia noforonin'ny fiasa [`once_with()`].
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}