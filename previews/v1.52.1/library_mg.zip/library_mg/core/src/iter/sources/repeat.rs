use crate::iter::{FusedIterator, TrustedLen};

/// Mamorona vaovao iterator izay mamerina tsy misy farany ny singa iray.
///
/// Ny fiasan'ny `repeat()` dia mamerina soatoavina tokana hatrany hatrany hatrany.
///
/// Tsy manam-petra toy ny `repeat()` iterators dia matetika ampiasaina miaraka amin'ny adapters tahaka [`Iterator::take()`], mba hahatonga azy ireo ho voafetra.
///
/// Raha toa ny singa karazana ny iterator ilainao `Clone` tsy manatanteraka, na raha tsy te-hitandrina ny miverimberina singa ho fahatsiarovana, fa tsy afaka mampiasa ny asa [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::iter;
///
/// // ny isa efatra 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Ya, mbola efa-
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Going voafetra amin'ny [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // io ohatra farany io dia efatra be loatra.Ndao efatra ihany no mandia tongotra efatra.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... Ary ankehitriny isika dia nanao
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Mpiverina izay mamerina singa iray tsy misy farany.
///
/// Izany `struct` no namorona ny [`repeat()`] asa.Jereo ny tahirin-kevitra ho an'ny hafa.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}