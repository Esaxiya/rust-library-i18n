use crate::iter::{FusedIterator, TrustedLen};

/// Mamorona iterator izay manome singa iray indray mandeha.
///
/// Izany dia fampiasa mba mampifanaraka zava-dehibe iray ho [`chain()`] hafa karazana iteration.
/// Angamba ianao manana iterator fa saika ny zava-drehetra fonony, fa mila fanampiny tranga manokana.
/// Angamba manana asa izay miasa amin'ny iterators, fa ianao ihany no mila ny fandraisana zava-dehibe iray.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::iter;
///
/// // ny anankiray no loneliest isa
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // iray monja dia izay ihany no azontsika
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining miaraka iterator hafa.
/// Andeha hatao hoe tsy tiantsika ny iterate ny antontan-taratasy tsirairay ny `.foo` Directory, fa koa ny fanahafana rakitra,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // tokony hiova avy iterator ny DirEntry-s ho amin'ny iterator ny PathBufs, noho izany dia mampiasa sarintany
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ankehitriny, ry iterator fotsiny ny config rakitra
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // iterators gadra roa ho eo an iray lehibe iterator
/// let files = dirs.chain(config);
///
/// // izany dia hanome antsika rehetra ny raki-daza amin .foo ary koa .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Mpiverina izay manome singa iray indray mandeha.
///
/// Ity `struct` ity dia noforonin'ny fiasa [`once()`].Jereo ny tahirin-kevitra ho an'ny hafa.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}