use crate::iter::{FusedIterator, TrustedLen};

/// Mamorona vaovao iterator izay mamerina ny karazana singa `A` mitsahatra amin'ny alalan'ny fampiharana ny nanome fanakatonana, ny repeater, `F: FnMut() -> A`.
///
/// Ny asa `repeat_with()` miantso ny repeater hatrany hatrany.
///
/// Tsy manam-petra toy ny `repeat_with()` iterators dia matetika ampiasaina miaraka amin'ny adapters tahaka [`Iterator::take()`], mba hahatonga azy ireo ho voafetra.
///
/// Raha toa ny singa iterator karazana ny fitaovana ilainao [`Clone`], ary izany dia OK ny hitandrina ny loharanom-baovao singa ho fahatsiarovana, fa tsy tokony hampiasa ny [`repeat()`] asa.
///
///
/// Iterator iray novokarin'ny `repeat_with()` tsy [`DoubleEndedIterator`].
/// Raha mila `repeat_with()` ianao hamerina [`DoubleEndedIterator`], azafady mba sokafy ny olana GitHub manazava ny tranga fampiasanao.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Fampiasana fototra:
///
/// ```
/// use std::iter;
///
/// // aoka ny mihevitra isika manana ilaina ny karazana izay tsy `Clone`, na izay tsy te-hanana fahatsiarovana fotsiny satria mbola lafo:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // manokana sanda mandrakizay:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Amin'ny alalan'ny fampiasana mutation sy handeha voafetra:
///
/// ```rust
/// use std::iter;
///
/// // Avy amin'ny zeroth ho any amin'ny fahatelo hery roa:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... Ary ankehitriny isika dia nanao
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ny iterator izay mamerina ny karazana singa `A` mitsahatra amin'ny alalan'ny fampiharana ny nanome `F: FnMut() -> A` fanakatonana.
///
///
/// Izany `struct` no namorona ny [`repeat_with()`] asa.
/// Jereo ny antontan-taratasy momba azy bebe kokoa.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}