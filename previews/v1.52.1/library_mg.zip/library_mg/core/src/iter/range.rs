use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Zavatra izay manana hevitra ny mpandimby * **ary nodimbiasany* asa.
///
/// Ny mpandimby * * moves hetsika manoloana ny soatoavina izay ampitahao amin'ny lehibe.
/// Ny hetsika *teo alohany* dia miroso mankany amin'ny soatoavina izay mampitaha kely kokoa.
///
/// # Safety
///
/// Izany no `unsafe` trait, satria ny fanatanterahana dia tsy maintsy ho marina ho amin'ny fiarovana ny `unsafe trait TrustedLen` implementations, ary ny vokatry ny fampiasana ity raha tsy izany dia afaka trait azo itokisana ny `unsafe` fehezan-dalàna ho marina sy hanatanteraka ny andraikitra voalaza.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Miverina ny isan'ny *mpandimby* dingana takiana mba avy `start` ho `end`.
    ///
    /// Miverina `None` raha ny isan'ny dingana dia tondraka `usize` (na dia tsy manam-petra, na raha `end` mety tsy ho tonga).
    ///
    ///
    /// # Invariants
    ///
    /// Fa misy `a`, `b`, ary `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` raha ary raha `Step::forward_checked(&a, n) == Some(b)` fotsiny
    /// * `steps_between(&a, &b) == Some(n)` raha toa ka raha `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` raha `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` raha toa ka raha `a == b`
    ///   * Mariho fa `a <= b` no _not_ midika `steps_between(&a, &b) != None`;
    ///     izany no mitranga rehefa mety mitaky mihoatra noho `usize::MAX` dingana hahatongavana any `b`
    /// * `steps_between(&a, &b) == None` raha `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Miverina ny vidiny izay ho azo amin'ny alalan'ny fanaovana ny *mpandimby* ny `self` `count` fotoana.
    ///
    /// Raha izany no tondraka ny soatoavina isan-karazany tohanan'ny `Self`, miverina `None`.
    ///
    /// # Invariants
    ///
    /// Fa misy `a`, `n`, ary `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Fa misy `a`, `n`, ary `m` izay `n + m` no tsy tondraka:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Fa misy `a` sy `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Miverina ny vidiny izay ho azo amin'ny alalan'ny fanaovana ny *mpandimby* ny `self` `count` fotoana.
    ///
    /// Raha izany no tondraka ny soatoavina isan-karazany tohanan'ny `Self`, asa io dia avela panic, Wrap, na Hamelombelona.
    ///
    /// Ny soso-kevitra ny fitondran-tena dia ny panic debug rehefa fanizingizinana dia afaka, ary ny mamatotra na hamelombelona raha tsy izany.
    ///
    /// Fehezan-dalàna mampidi-doza tsy tokony hiantehitra amin'ny correct ny fitondran-tena, rehefa vokatra.
    ///
    /// # Invariants
    ///
    /// Fa misy `a`, `n`, sy `m`, izay tsy vokatra miseho:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Fa misy `a` sy `n`, izay tsy vokatra miseho:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Miverina ny vidiny izay ho azo amin'ny alalan'ny fanaovana ny *mpandimby* ny `self` `count` fotoana.
    ///
    /// # Safety
    ///
    /// Fihetsika tsy voafaritra ho an'ity fandidiana ity ny fandehanana mihoatra ny isan'ireo sanda tohanan'ny `Self`.
    /// Raha toa ka tsy afaka manome antoka fa izany dia tsy anananareo betsaka, fampiasana `forward` na `forward_checked` fa tsy.
    ///
    /// # Invariants
    ///
    /// Ho an'ny `a` rehetra:
    ///
    /// * raha misy `b` izany fa `b > a`, dia azo antoka ny miantso `Step::forward_unchecked(a, 1)`
    /// * raha misy `b`, `n` izany fa `steps_between(&a, &b) == Some(n)`, dia azo antoka ny miantso `m <= n` `Step::forward_unchecked(a, m)` na inona na inona.
    ///
    ///
    /// Fa misy `a` sy `n`, izay tsy vokatra miseho:
    ///
    /// * `Step::forward_unchecked(a, n)` dia mitovy `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Miverina ny vidiny izay ho azo amin'ny alalan'ny fanaovana ny *nodimbiasany* ny `self` `count` fotoana.
    ///
    /// Raha izany no tondraka ny soatoavina isan-karazany tohanan'ny `Self`, miverina `None`.
    ///
    /// # Invariants
    ///
    /// Fa misy `a`, `n`, ary `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Fa misy `a` sy `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Miverina ny vidiny izay ho azo amin'ny alalan'ny fanaovana ny *nodimbiasany* ny `self` `count` fotoana.
    ///
    /// Raha izany no tondraka ny soatoavina isan-karazany tohanan'ny `Self`, asa io dia avela panic, Wrap, na Hamelombelona.
    ///
    /// Ny soso-kevitra ny fitondran-tena dia ny panic debug rehefa fanizingizinana dia afaka, ary ny mamatotra na hamelombelona raha tsy izany.
    ///
    /// Fehezan-dalàna mampidi-doza tsy tokony hiantehitra amin'ny correct ny fitondran-tena, rehefa vokatra.
    ///
    /// # Invariants
    ///
    /// Fa misy `a`, `n`, sy `m`, izay tsy vokatra miseho:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Fa misy `a` sy `n`, izay tsy vokatra miseho:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Miverina ny vidiny izay ho azo amin'ny alalan'ny fanaovana ny *nodimbiasany* ny `self` `count` fotoana.
    ///
    /// # Safety
    ///
    /// Fihetsika tsy voafaritra ho an'ity fandidiana ity ny fandehanana mihoatra ny isan'ireo sanda tohanan'ny `Self`.
    /// Raha tsy afaka manome toky ianao fa tsy hihoatra izany dia ampiasao `backward` na `backward_checked` fa tsy.
    ///
    /// # Invariants
    ///
    /// Ho an'ny `a` rehetra:
    ///
    /// * raha misy `b` izany fa `b < a`, dia azo antoka ny miantso `Step::backward_unchecked(a, 1)`
    /// * raha misy `b`, `n` izany fa `steps_between(&b, &a) == Some(n)`, dia azo antoka ny miantso `m <= n` `Step::backward_unchecked(a, m)` na inona na inona.
    ///
    ///
    /// Fa misy `a` sy `n`, izay tsy vokatra miseho:
    ///
    /// * `Step::backward_unchecked(a, n)` dia mitovy `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Ireo dia mbola vokarin'ny makroara ihany satria ny litera integera dia mivaha amin'ny karazany samy hafa.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // Famonjena, ny mpiantso tsy maintsy antoka fa tsy `start + n` no vokatra.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // Famonjena, ny mpiantso tsy maintsy antoka fa tsy `start - n` no vokatra.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Amin'ny manao debug, nahatonga an'ilay bibidia ny panic ny vokatra.
            // Tokony manatsara tanteraka avy amin'ny famotsorana no mampandroso.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Ve fanehoany matematika mba hamela ohatra `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Amin'ny manao debug, nahatonga an'ilay bibidia ny panic ny vokatra.
            // Tokony manatsara tanteraka avy amin'ny famotsorana no mampandroso.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Ve fanehoany matematika mba hamela ohatra `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Miankina amin'ny $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // raha N dia avy isan-karazany, `unsigned_start + n` loatra
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // raha tsy lavitra ny n, `unsigned_start - n` koa
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Miankina amin'ny $i_narrower <=usize
                        //
                        // Mandatsaka ny isize nanitatra ny sakany, fa miaro ny famantarana.
                        // Ampiasao wrapping_sub in isize toerana sy nandatsaka ny usize mba compute ny fahasamihafana izay mety tsy mifanaraka ao anatin'ny karazana isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping famohana tranga tahaka `Step::forward(-120_i8, 200) == Some(80_i8)`, na dia 200 no avy isan-karazany ho an'ny i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Ankoatra nanasaforany
                            }
                        }
                        // Raha N dia avy isan-karazany ohatra:
                        // u8, Avy eo dia lehibe kokoa noho ny isan-karazany ho an'ny i8 manontolo dia malalaka ka voatery `any_i8 + n` Tondraka i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Wrapping famohana tranga tahaka `Step::forward(-120_i8, 200) == Some(80_i8)`, na dia 200 no avy isan-karazany ho an'ny i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Nihoatra ny fanesorana
                            }
                        }
                        // Raha N dia avy isan-karazany ohatra:
                        // u8, avy eo lehibe kokoa noho ny elanelam-potoana manontolo ho an'ny i8 ny sakany ka `any_i8 - n` dia mihoa-pefy i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Raha lehibe loatra ny tsy fitoviana ohatra
                            // i128, izy io koa dia ho lehibe loatra ka tsy afaka ampiasaina amin'ny bitika kely kokoa.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SAFETY: res dia scalar unicode manan-kery
            // (Eto ambany 0x110000 fa tsy in 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SAFETY: res dia scalar unicode manan-kery
        // (Eto ambany 0x110000 fa tsy in 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // Famonjena, dia tsy maintsy manome antoka ny mpiantso fa izany no tsy tondraka
        // ny isan'ireo sanda ho an'ny char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // Famonjena, dia tsy maintsy manome antoka ny mpiantso fa izany no tsy tondraka
            // ny isan'ireo sanda ho an'ny char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // Famonjena, noho ny fifanekena teo aloha, azo antoka izany
        // ny mpiantso ho char mety.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // Famonjena, dia tsy maintsy manome antoka ny mpiantso fa izany no tsy tondraka
        // ny isan'ireo sanda ho an'ny char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // Famonjena, dia tsy maintsy manome antoka ny mpiantso fa izany no tsy tondraka
            // ny isan'ireo sanda ho an'ny char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // Famonjena, noho ny fifanekena teo aloha, azo antoka izany
        // ny mpiantso ho char mety.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: precondition vao nozahana
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SAFETY: precondition vao nozahana
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ireo macros hiteraka `ExactSizeIterator` impls ho an'ny isan-karazany samihafa karazana.
//
// * `ExactSizeIterator::len` dia takiana mba hiverina ny marina foana `usize`, ka tsy misy isan-karazany mety ho ela kokoa noho `usize::MAX`.
//
// * Fa integer karazana in `Range<_>` izany no tranga ho an'ny karazana teritery kokoa noho ny na toy ny sakany ho `usize`.
//   Fa integer karazana in `RangeInclusive<_>` izany no tranga ho an'ny karazana * * hentitra teritery kokoa noho ny `usize` satria ohatra
//   `(0..=u64::MAX).len()` dia `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Ireo dia fampidirina isaky ny antony etsy ambony, fa ny fanesorana azy ireo dia fiovana manimba satria niorina tamin'ny Rust 1.0.0.
    // Noho izany ohatra
    // `(0..66_000_u32).len()` ohatra dia tsy misy hadisoana, na manangona fampitandremana tamin'ny 16-bit sehatra, fa mbola manohy manome ny vokatra ratsy.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Ireo no incorect isaky ny Fandresen-dahatra ambony, fa manala azy ireo dia ho famakiana fiovana araka izay voahozongozona amin'ny Rust 1.26.0.
    // Noho izany ohatra
    // `(0..=u16::MAX).len()` ohatra dia tsy misy hadisoana, na manangona fampitandremana tamin'ny 16-bit sehatra, fa mbola manohy manome ny vokatra ratsy.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAFETY: precondition vao nozahana
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SAFETY: precondition vao nozahana
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: precondition vao nozahana
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: precondition vao nozahana
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAFETY: precondition vao nozahana
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAFETY: precondition vao nozahana
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}