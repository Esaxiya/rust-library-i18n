//! Panic fanohanana libcore
//!
//! Ny famakiam-boky fototra dia tsy afaka mamaritra ny fikorontanana, fa *manambara* ny fikoropahana.
//! Midika izany fa avela mankany panic ireo fiasa ao anaty libcore, fa raha ilaina kosa ny crate any ambony dia tokony hamaritra ny fikoropahana mba hampiasana libcore.
//! Ny interface amin'izao fotoana izao amin'ny panicking dia:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ity famaritana ity dia ahafahana mikoropaka amin'ny hafatra ankapobeny, saingy tsy mamela ny tsy fahombiazana amin'ny sanda `Box<Any>`.
//! (`PanicInfo` dia misy `&(dyn Any + Send)` fotsiny, izay hamenoantsika soatoavina dummy ao amin'ny `PanicInfo: : internal_constructor`.) Ny anton'izany dia tsy avela hanome ny libcore.
//!
//!
//! Ity modely ity dia misy fantsom-panafihana hafa vitsivitsy, saingy ireto fotsiny ireo entana ilaina fotsiny ho an'ny mpanangona.Ny panics rehetra dia alefa amin'ny alàlan'ity asa iray ity.
//! Ny tena izy dia ambara amin'ny alàlan'ny toetra `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Ny fampiharana fototra ny makro `panic!` libcore rehefa tsy misy endrika ampiasaina.
#[cold]
// aza milahatra na oviana na oviana raha tsy panic_im Mediate_abort hisorohana ny fehezan-dalàna amin'ny tranokalan'ny antso araka izay tratra
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ilain'ny codegen ho an'ny panic amin'ny fihoaram-pefy ary ireo mpamarana `Assert` MIR hafa
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Mampiasà Arguments::new_v1 fa tsy format_args! ("{}", Expr) mety hampihena ny haben'ny overhead.
    // Ny format_args!Ny makro dia mampiasa ny Display trait an'ny str hanoratana expr, izay miantso Formatter::pad, izay tsy maintsy mahazaka truncation string sy padding (na dia tsy misy ampiasaina eto aza).
    //
    // Ny fampiasana Arguments::new_v1 dia mety hamela ny mpanangona hanala an'i Formatter::pad amin'ny binary binary, mitahiry hatramin'ny kilobytes vitsivitsy.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // ilaina ho an'ny panics voavaly
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // ilain'ny codegen ho an'ny panic amin'ny fidirana OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Ny fampiharana fototra ny makro `panic!` libcore rehefa ampiasaina ny fanaingoana.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NAOTY Ity fiasa ity dia tsy miampita ny fetra FFI velively;antso Rust-to-Rust izay voavaha amin'ny asan'ny `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAFETY: `panic_impl` dia voafaritra ao anaty kaody Rust azo antoka ka azo antoka ny miantso azy.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fampiasana anaty ho an'ny makro `assert_eq!` sy `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}