use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miadana loatra i Miri
fn exact_sanity_test() {
    // Io fitsapana faran ka nihazakazaka izay hany azoko atao dia ny sasany mihevitra fa nankany jorony-raharaha ny `exp2` famakiam-boky ny asa, voafaritra na inona na inona C runtime isika dia mampiasa.
    // Tamin'ny VS 2013 dia toa nanana bibikely ity fiasa ity satria tsy nahomby ity fitsapana ity rehefa nampifandraisina, saingy miaraka amin'ny VS 2015 dia toa raikitra ny bug rehefa mandeha tsara ny fitsapana.
    //
    // Ny bibikely dia toa ho fahasamihafana eo amin'ny miverina hasarobidin'ny `exp2(-1057)`, izay ao amin'ny VS 2013 dia miverina ho avo roa heny amin'ny endriky ny kely 0x2 sy VS 2015 dia miverina 0x20000.
    //
    //
    // Aza adino fotsiny izao ity fitsapana ity amin'ny MSVC satria efa notsapaina tany an-toeran-kafa izany ary tsy dia liana amin'ny fitsapana ny fampiharana exp2 an'ny sehatra tsirairay izahay.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}