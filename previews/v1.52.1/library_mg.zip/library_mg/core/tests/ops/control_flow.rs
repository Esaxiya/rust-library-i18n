use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Tsy marin-toerana ambonin'ny faritra, fa dia manampy `?` mora teo amin'izy ireo, na dia tsy afaka foana LLVM manararaotra izany amin'izao fotoana izao.
    //
    // (Tsy dia mifanaraka ny valiny sy ny safidy mampalahelo, noho izany dia tsy afaka mifanandrify roa ny ControlFlow.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}