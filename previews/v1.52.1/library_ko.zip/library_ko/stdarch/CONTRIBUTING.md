# stdarch에 기여

`stdarch` crate 는 기부를 기꺼이 받아들이는 것 이상입니다!먼저 저장소를 확인하고 테스트를 통과했는지 확인해야 할 것입니다.

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

여기서 `<your-target-arch>` 는 `rustup` 에서 사용하는 목표 트리플입니다 (예: `x86_x64-unknown-linux-gnu` (앞의 `nightly-` 또는 유사 없음)).
또한이 저장소에는 Rust 의 야간 채널이 필요합니다!
위의 테스트에서는 실제로 `rustup default nightly` (및 `rustup default stable` 를 사용하여 되돌림)를 사용하도록 설정하기 위해 야간 rust 가 시스템의 기본값이되어야합니다.

위 단계 중 하나라도 작동하지 않으면 [please let us know][new]!

다음으로 [find an issue][issues] 를 사용하여 도움을받을 수 있습니다. 특히 도움이 될 수있는 [`help wanted`][help] 및 [`impl-period`][impl] 태그로 몇 가지를 선택했습니다. 
x86 에서 모든 공급 업체 내장 함수를 구현하는 [#40][vendor] 에 가장 관심이있을 수 있습니다.이 문제는 어디서부터 시작해야할지에 대한 좋은 조언이 있습니다!

일반적인 질문이있는 경우 [join us on gitter][gitter] 로 부담없이 문의하십시오!질문이 있으면@BurntSushi 또는@alexcrichton에 자유롭게 핑하세요.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# stdarch 내장 함수에 대한 예제를 작성하는 방법

지정된 내장 함수가 제대로 작동하려면 활성화해야하는 몇 가지 기능이 있으며 해당 기능이 CPU에서 지원되는 경우에만 `cargo test --doc` 에서 예제를 실행해야합니다.

결과적으로 `rustdoc` 에 의해 생성 된 기본 `fn main` 는 작동하지 않습니다 (대부분의 경우).
다음을 가이드로 사용하여 예제가 예상대로 작동하는지 확인하십시오.

```rust
/// # // 예제를 확인하려면 cfg_target_feature가 필요합니다.
/// # // CPU가 기능을 지원할 때 `cargo test --doc` 에 의해 실행
/// # #![feature(cfg_target_feature)]
/// # // 내장 함수가 작동하려면 target_feature가 필요합니다.
/// # #![feature(target_feature)]
/// #
/// # // rustdoc은 기본적으로 `extern crate stdarch` 를 사용하지만
/// # // `#[macro_use]`
/// # # [매크로 사용] extern crate stdarch;
/// #
/// # // 실제 주요 기능
/// # fn main() {
/// #     // `<target feature>` 가 지원되는 경우에만 실행하십시오.
/// #     cfg_feature_enabled! ("<target feature>"){
/// #         // 대상 기능이있는 경우에만 실행되는 `worker` 기능을 만듭니다.
/// #         // 지원되고 작업자에 대해 `target_feature` 가 활성화되어 있는지 확인하십시오.
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         안전하지 않은 fn worker() {
/// // 여기에 예제를 작성하십시오.기능별 내장 함수가 여기에서 작동합니다!야성!
///
/// #         }
///
/// #         안전하지 않은 { worker(); }
/// #     }
/// # }
```

위의 구문 중 일부가 익숙하지 않은 경우 [Rust Book] 의 [Documentation as tests] 섹션에서 `rustdoc` 구문을 잘 설명합니다.
항상 그렇듯이 [join us on gitter][gitter] 에 부담을주지 않고 문제가 발생했는지 문의하고 `stdarch` 의 문서를 개선하는 데 도움을 주셔서 감사합니다!

# 대체 테스트 지침

일반적으로 `ci/run.sh` 를 사용하여 테스트를 실행하는 것이 좋습니다.
그러나 이것은 예를 들어 Windows 를 사용하는 경우 작동하지 않을 수 있습니다.

이 경우 코드 생성을 테스트하기 위해 `cargo +nightly test` 및 `cargo +nightly test --release -p core_arch` 를 다시 실행할 수 있습니다.
이를 위해서는 야간 툴체인을 설치하고 `rustc` 가 타겟 트리플과 CPU에 대해 알고 있어야합니다.
특히 `ci/run.sh` 에서와 같이 `TARGET` 환경 변수를 설정해야합니다.
또한 대상 기능을 나타 내기 위해 `RUSTCFLAGS` (`C` 필요)를 설정해야합니다 (예 : `RUSTCFLAGS="-C -target-features=+avx2"`.
현재 CPU에 대해 "just" 를 개발하는 경우 `-C -target-cpu=native` 를 설정할 수도 있습니다.

이러한 대체 지침을 사용할 때 [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], 예를 들어
명령어 생성 테스트는 디스어셈블러에서 이름이 다르기 때문에 실패 할 수 있습니다.
동일하게 작동하더라도 `aesenc` 명령어 대신 `vaesenc` 를 생성 할 수 있습니다.
또한 이러한 명령은 일반적으로 수행되는 것보다 적은 테스트를 실행하므로 결국 풀 요청을 수행 할 때 여기에서 다루지 않은 테스트에 대해 일부 오류가 나타날 수 있다는 사실에 놀라지 마십시오.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






