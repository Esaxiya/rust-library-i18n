#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) 를 참조하십시오.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) 를 참조하십시오.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) 를 참조하십시오.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) 를 참조하십시오.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) 를 참조하십시오.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) 를 참조하십시오.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// 주어진 `rw` 및 `locality` 를 사용하여 주소 `p` 를 포함하는 캐시 라인을 가져옵니다.
///
/// `rw` 는 다음 중 하나 여야합니다.
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): 프리 페치가 읽기를 준비 중입니다.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): 프리 페치가 쓰기를 준비 중입니다.
///
/// `locality` 는 다음 중 하나 여야합니다.
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): 한 번만 사용되는 데이터의 경우 스트리밍 또는 비 시간적 프리 페치.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): 레벨 3 캐시로 가져옵니다.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): 레벨 2 캐시로 가져옵니다.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): 레벨 1 캐시로 가져옵니다.
///
/// 프리 페치 메모리 명령은 메모리가 지정된 주소에서 액세스하는 메모리 시스템에 신호를 보냅니다. future 근처에서 발생할 가능성이 높습니다.
/// 메모리 시스템은 지정된 주소를 하나 이상의 캐시에 미리로드하는 등 메모리 액세스 속도를 높일 것으로 예상되는 조치를 취하여 대응할 수 있습니다.
///
/// 이러한 신호는 힌트 일 뿐이므로 특정 CPU가 모든 프리 페치 명령을 NOP로 처리하는 것은 유효합니다.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // `cache type` =1 (데이터 캐시) 인 `llvm.prefetch` 내장 함수를 사용합니다.
    // `rw` `strategy` 는 기능 매개 변수를 기반으로합니다.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}