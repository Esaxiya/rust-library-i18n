`core::arch` - Rust 의 핵심 라이브러리 아키텍처 별 내장 함수
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` 모듈은 아키텍처에 따른 내장 함수 (예: SIMD)를 구현합니다.

# Usage 

`core::arch` `libcore` 의 일부로 사용할 수 있으며 `libstd` 에서 다시 내보낼 수 있습니다.이 crate 를 사용하는 것보다 `core::arch` 또는 `std::arch` 를 통해 사용하는 것이 좋습니다.
불안정한 기능은 종종 `feature(stdsimd)` 를 통해 야간 Rust 에서 사용할 수 있습니다.

이 crate 를 통해 `core::arch` 를 사용하려면 야간 Rust 가 필요하며 자주 중단 될 수 있습니다.이 crate 를 통해 사용을 고려해야하는 유일한 경우는 다음과 같습니다.

* 예를 들어 `libcore`/`libstd` 에 대해 활성화되지 않은 특정 대상 기능을 활성화하여 `core::arch` 를 직접 다시 컴파일해야하는 경우.
Note: 비표준 타겟에 대해 다시 컴파일해야하는 경우이 crate 를 사용하는 대신 `xargo` 를 사용하고 적절하게 `libcore`/`libstd` 를 다시 컴파일하는 것이 좋습니다.
  
* 불안정한 Rust 기능 뒤에서도 사용할 수없는 일부 기능을 사용합니다.우리는 이것들을 최소한으로 유지하려고 노력합니다.
이러한 기능 중 일부를 사용해야하는 경우 야간 Rust 에서 해당 기능을 노출하고 거기에서 사용할 수 있도록 이슈를여십시오.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` 주로 MIT 라이선스와 Apache 라이선스 (버전 2.0)의 조건에 따라 배포되며, 일부는 다양한 BSD 유사 라이선스가 적용됩니다.

자세한 내용은 LICENSE-APACHE 및 LICENSE-MIT를 참조하십시오.

# Contribution

달리 명시하지 않는 한, Apache-2.0 라이선스에 정의 된대로 귀하가 `core_arch` 에 포함하기 위해 의도적으로 제출 한 모든 기여는 추가 조건없이 위와 같이 이중 라이선스가 부여됩니다.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












