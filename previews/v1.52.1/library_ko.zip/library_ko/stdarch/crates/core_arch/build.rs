use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // `#[assert_instr]` 주석에 모든 simd 내장 함수를 사용하여 코드 생성을 테스트 할 수 있음을 알리는 데 사용됩니다. 일부는 현재 `#[target_feature]` 에 해당하지 않는 추가 `-Ctarget-feature=+unimplemented-simd128` 뒤에 게이트되기 때문입니다.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}