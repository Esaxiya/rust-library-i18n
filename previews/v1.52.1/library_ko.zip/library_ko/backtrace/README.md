# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust 의 런타임에 역 추적을 수집하기위한 라이브러리입니다.
이 라이브러리는 작업 할 프로그래밍 인터페이스를 제공하여 표준 라이브러리의 지원을 강화하는 것을 목표로하지만 libstd의 panics 와 같이 현재 역 추적을 쉽게 인쇄 할 수도 있습니다.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

단순히 역 추적을 캡처하고 나중에 처리를 연기하려면 최상위 수준 `Backtrace` 유형을 사용할 수 있습니다.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

그러나 실제 추적 기능에 대한 더 많은 원시 액세스를 원하면 `trace` 및 `resolve` 함수를 직접 사용할 수 있습니다.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // 이 명령어 포인터를 기호 이름으로 해석
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // 다음 프레임으로 계속 이동
    });
}
```

# License

이 프로젝트는

 * Apache 라이센스, 버전 2.0, ([LICENSE-APACHE](LICENSE-APACHE) 또는 http://www.apache.org/licenses/LICENSE-2.0)
 * MIT 라이센스 ([LICENSE-MIT](LICENSE-MIT) 또는 http://opensource.org/licenses/MIT)

귀하의 선택에.

### Contribution

명시 적으로 달리 명시하지 않는 한, Apache-2.0 라이선스에 정의 된대로 귀하가 backtrace-rs에 포함하기 위해 의도적으로 제출 한 모든 기여는 추가 약관없이 위와 같이 이중 라이선스가 부여됩니다.







