//! Windows 에서 dbghelp 바인딩 관리를 지원하는 모듈
//!
//! Windows (적어도 MSVC의 경우)의 역 추적은 주로 `dbghelp.dll` 및 포함 된 다양한 기능을 통해 제공됩니다.
//! 이러한 함수는 현재 `dbghelp.dll` 에 정적으로 연결되지 않고 *동적으로* 로드됩니다.
//! 이것은 현재 표준 라이브러리에 의해 수행되지만 (이론상 필요함), 역 추적은 일반적으로 매우 선택 사항이므로 라이브러리의 정적 dll 종속성을 줄이기위한 노력입니다.
//!
//! 즉, `dbghelp.dll` 는 거의 항상 Windows 에 성공적으로로드됩니다.
//!
//! 이 모든 지원을 동적으로로드하기 때문에 실제로 `winapi` 에서 원시 정의를 사용할 수는 없지만 함수 포인터 유형을 직접 정의하고 사용해야합니다.
//! 우리는 winapi를 복제하는 사업에 참여하고 싶지 않기 때문에 모든 바인딩이 winapi의 바인딩과 일치하고 CI에서이 기능이 활성화되어 있다고 주장하는 Cargo 기능 `verify-winapi` 가 있습니다.
//!
//! 마지막으로 `dbghelp.dll` 용 dll은 언로드되지 않으며 현재 의도적 인 것임을 알 수 있습니다.
//! 우리는이를 전역 적으로 캐시하고 API 호출간에 사용할 수 있으므로 값 비싼 loads/unloads 를 피할 수 있습니다.
//! 이것이 누출 감지기에 문제가된다면 우리는 그곳에 도착했을 때 다리를 건널 수 있습니다.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// winapi 자체에 존재하지 않는 `SymGetOptions` 및 `SymSetOptions` 를 해결합니다.
// 그렇지 않으면 이것은 우리가 winapi에 대해 유형을 재확인 할 때만 사용됩니다.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // 아직 winapi에 정의되지 않았습니다.
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // 이것은 winapi에 정의되어 있지만 올바르지 않습니다 (FIXME winapi-rs#768).
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // 아직 winapi에 정의되지 않았습니다.
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// 이 매크로는로드 할 수있는 모든 함수 포인터를 내부적으로 포함하는 `Dbghelp` 구조를 정의하는 데 사용됩니다.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` 용로드 된 DLL
            dll: HMODULE,

            // 우리가 사용할 수있는 각 함수에 대한 각 함수 포인터
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // 처음에는 DLL을로드하지 않았습니다.
            dll: 0 as *mut _,
            // Initiall 모든 함수는 동적으로로드되어야 함을 나타 내기 위해 0으로 설정됩니다.
            //
            $($name: 0,)*
        };

        // 각 기능 유형에 대한 편의 typedef.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` 열기를 시도합니다.
            /// 작동하면 성공을 반환하고 `LoadLibraryW` 가 실패하면 오류를 반환합니다.
            ///
            /// 라이브러리가 이미로드 된 경우 Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // 우리가 사용하고자하는 각 방법에 대한 기능.
            // 호출되면 캐시 된 함수 포인터를 읽거나로드하고로드 된 값을 반환합니다.
            // 로드가 성공한 것으로 확인됩니다.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // dbghelp 함수를 참조하기 위해 정리 잠금을 사용하는 편리한 프록시.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// 이 crate 에서 `dbghelp` API 기능에 액세스하는 데 필요한 모든 지원을 초기화합니다.
///
///
/// 이 함수는 **안전** 하며 내부적으로 자체 동기화가 있습니다.
/// 또한이 함수를 재귀 적으로 여러 번 호출하는 것이 안전합니다.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // 가장 먼저해야 할 일은이 함수를 동기화하는 것입니다.다른 스레드에서 동시에 호출하거나 한 스레드 내에서 재귀 적으로 호출 할 수 있습니다.
        // 여기서 사용하는 `dbghelp`,*또한* 는이 프로세스에서 `dbghelp` 에 대한 다른 모든 호출자와 동기화되어야하므로 그보다 까다 롭습니다.
        //
        // 일반적으로 동일한 프로세스 내에서 `dbghelp` 에 대한 호출이 그렇게 많지 않으며, 우리가 그것에 액세스하는 유일한 사람이라고 안전하게 가정 할 수 있습니다.
        // 그러나 아이러니하게도 우리가 걱정해야 할 다른 주요 사용자가 있지만 표준 라이브러리에 있습니다.
        // Rust 표준 라이브러리는 역 추적 지원을 위해이 crate 에 의존하며이 crate 는 crates.io 에도 존재합니다.
        // 즉, 표준 라이브러리가 panic 역 추적을 인쇄하는 경우 crates.io 에서 오는이 crate 와 경쟁하여 segfault를 유발할 수 있습니다.
        //
        // 이 동기화 문제를 해결하기 위해 여기서는 Windows 관련 트릭을 사용합니다 (동기화에 대한 Windows 관련 제한).
        // 이 호출을 보호하기 위해 mutex라는 *session-local* 을 만듭니다.
        // 여기서의 의도는 표준 라이브러리와이 crate 가 여기서 동기화하기 위해 Rust 수준 API를 공유 할 필요가 없지만 대신 백그라운드에서 작업하여 서로 동기화되는지 확인할 수 있다는 것입니다.
        //
        // 이렇게하면이 함수가 표준 라이브러리 또는 crates.io 를 통해 호출 될 때 동일한 뮤텍스가 획득되고 있음을 확인할 수 있습니다.
        //
        // 따라서 여기서 가장 먼저하는 일은 Windows 에서 명명 된 뮤텍스 인 `HANDLE` 를 원자 적으로 만드는 것입니다.
        // 이 기능을 특별히 공유하는 다른 스레드와 약간 동기화하고이 함수의 인스턴스 당 하나의 핸들 만 생성되도록합니다.
        // 핸들은 전역에 저장되면 닫히지 않습니다.
        //
        // 우리가 실제로 자물쇠를 얻은 후에 우리는 단순히 그것을 획득하고 우리가 나눠주는 `Init` 핸들은 결국 그것을 떨어 뜨릴 책임이 있습니다.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // 좋아, 휴!이제 우리 모두 안전하게 동기화되었으므로 실제로 모든 것을 처리하기 시작하겠습니다.
        // 먼저 `dbghelp.dll` 가이 프로세스에 실제로로드되었는지 확인해야합니다.
        // 정적 종속성을 피하기 위해 동적으로 수행합니다.
        // 이것은 역사적으로 이상한 연결 문제를 해결하기 위해 수행되었으며 주로 디버깅 유틸리티이기 때문에 바이너리를 좀 더 이식성있게 만들기위한 것입니다.
        //
        //
        // `dbghelp.dll` 를 연 후에는 몇 가지 초기화 함수를 호출해야합니다. 자세한 내용은 아래에서 설명합니다.
        // 하지만이 작업은 한 번만 수행하므로 아직 완료되었는지 여부를 나타내는 전역 부울이 있습니다.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // MSVC의 자체 문서에 따르면 "This is the fastest, most efficient way to use the symbol handler." 에 따라 `SYMOPT_DEFERRED_LOADS` 플래그가 설정되어 있는지 확인하십시오.
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // 실제로 MSVC로 기호를 초기화합니다.실패 할 수 있지만 무시합니다.
        // 이에 대한 선행 기술은 많지 않지만 LLVM은 내부적으로 여기에서 반환 값을 무시하는 것처럼 보이며 LLVM의 새니 타이 저 라이브러리 중 하나는 이것이 실패하면 무서운 경고를 인쇄하지만 기본적으로 장기적으로 무시합니다.
        //
        //
        // 이것이 Rust 에 대해 많이 등장하는 한 가지 경우는 표준 라이브러리와 crates.io 의이 crate 가 모두 `SymInitializeW` 를 놓고 경쟁하기를 원한다는 것입니다.
        // 표준 라이브러리는 역사적으로 대부분의 시간을 초기화하고 정리하기를 원했지만 이제이 crate 를 사용하고 있으므로 누군가가 먼저 초기화하고 다른 사람이 해당 초기화를 선택한다는 의미입니다.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}