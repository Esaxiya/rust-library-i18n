//! Windows 에서 `dbghelp.dll` 를 사용하는 기호화 전략, MSVC에만 사용됨
//!
//! 이 기호화 전략은 역 추적과 마찬가지로 `dbghelp.dll` 에서 동적으로로드 된 정보를 사용합니다.
//! (동적으로로드되는 이유에 대한 정보는 `src/dbghelp.rs` 를 참조하십시오).
//!
//! 이 API는 제공된 프레임 또는 현재 보유한 정보를 기반으로 해결 전략을 선택합니다.
//! `StackWalkEx` 의 프레임이 제공되면 유사한 API를 사용하여 인라인 함수에 대한 올바른 정보를 생성합니다.
//! 그렇지 않고 우리가 가지고있는 것이 주소 나 `StackWalk64` 의 이전 스택 프레임이면 기호화를 위해 이전 API를 사용합니다.
//!
//! 이 모듈에는 많은 지원이 있지만 그 중 좋은 부분은 Windows 유형과 Rust 유형간에 앞뒤로 변환하는 것입니다.
//!
//! 예를 들어 기호는 넓은 문자열로 우리에게 와서 가능하면 utf-8 문자열로 변환합니다.
//!
//!
//!
//!

#![allow(bad_style)]

use super::super::{backtrace::StackFrame, dbghelp, windows::*};
use super::{BytesOrWideString, ResolveWhat, SymbolName};
use core::char;
use core::ffi::c_void;
use core::marker;
use core::mem;
use core::slice;

// std 에 OsString을 저장하여 심볼 이름과 파일 이름을 제공 할 수 있습니다.
pub struct Symbol<'a> {
    name: *const [u8],
    addr: *mut c_void,
    line: Option<u32>,
    filename: Option<*const [u16]>,
    #[cfg(feature = "std")]
    _filename_cache: Option<::std::ffi::OsString>,
    #[cfg(not(feature = "std"))]
    _filename_cache: (),
    _marker: marker::PhantomData<&'a i32>,
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        Some(SymbolName::new(unsafe { &*self.name }))
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        Some(self.addr as *mut _)
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename
            .map(|slice| unsafe { BytesOrWideString::Wide(&*slice) })
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }

    pub fn lineno(&self) -> Option<u32> {
        self.line
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        self._filename_cache.as_ref().map(Path::new)
    }
}

#[repr(C, align(8))]
struct Aligned8<T>(T);

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    // 이 프로세스의 기호가 초기화되었는지 확인
    let dbghelp = match dbghelp::init() {
        Ok(dbghelp) => dbghelp,
        Err(()) => return, // 아 글쎄 ...
    };

    match what {
        ResolveWhat::Address(_) => resolve_without_inline(&dbghelp, what.address_or_ip(), cb),
        ResolveWhat::Frame(frame) => match &frame.inner.stack_frame {
            StackFrame::New(frame) => resolve_with_inline(&dbghelp, frame, cb),
            StackFrame::Old(_) => resolve_without_inline(&dbghelp, frame.ip(), cb),
        },
    }
}

unsafe fn resolve_with_inline(
    dbghelp: &dbghelp::Init,
    frame: &STACKFRAME_EX,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    do_resolve(
        |info| {
            dbghelp.SymFromInlineContextW()(
                GetCurrentProcess(),
                super::adjust_ip(frame.AddrPC.Offset as *mut _) as u64,
                frame.InlineFrameContext,
                &mut 0,
                info,
            )
        },
        |line| {
            dbghelp.SymGetLineFromInlineContextW()(
                GetCurrentProcess(),
                super::adjust_ip(frame.AddrPC.Offset as *mut _) as u64,
                frame.InlineFrameContext,
                0,
                &mut 0,
                line,
            )
        },
        cb,
    )
}

unsafe fn resolve_without_inline(
    dbghelp: &dbghelp::Init,
    addr: *mut c_void,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    do_resolve(
        |info| dbghelp.SymFromAddrW()(GetCurrentProcess(), addr as DWORD64, &mut 0, info),
        |line| dbghelp.SymGetLineFromAddrW64()(GetCurrentProcess(), addr as DWORD64, &mut 0, line),
        cb,
    )
}

unsafe fn do_resolve(
    sym_from_addr: impl FnOnce(*mut SYMBOL_INFOW) -> BOOL,
    get_line_from_addr: impl FnOnce(&mut IMAGEHLP_LINEW64) -> BOOL,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    const SIZE: usize = 2 * MAX_SYM_NAME + mem::size_of::<SYMBOL_INFOW>();
    let mut data = Aligned8([0u8; SIZE]);
    let data = &mut data.0;
    let info = &mut *(data.as_mut_ptr() as *mut SYMBOL_INFOW);
    info.MaxNameLen = MAX_SYM_NAME as ULONG;
    // C의 구조체 크기.
    // 구조체 정렬로 인해 값이 `size_of::<SYMBOL_INFOW>() - MAX_SYM_NAME + 1` (==81)와 다릅니다.
    //
    info.SizeOfStruct = 88;

    if sym_from_addr(info) != TRUE {
        return;
    }

    // 심볼 이름이 MaxNameLen보다 크면 SymFromAddrW는 (MaxNameLen, 1) 문자의 버퍼를 제공하고 NameLen을 실제 값으로 설정합니다.
    //
    //
    let name_len = ::core::cmp::min(info.NameLen as usize, info.MaxNameLen as usize - 1);
    let name_ptr = info.Name.as_ptr() as *const u16;
    let name = slice::from_raw_parts(name_ptr, name_len);

    // 다른 모든 플랫폼과 마찬가지로 `SymbolName::new` 를 사용할 수 있도록 utf-16 기호를 utf-8 로 다시 인코딩합니다.
    //
    let mut name_len = 0;
    let mut name_buffer = [0; 256];
    {
        let mut remaining = &mut name_buffer[..];
        for c in char::decode_utf16(name.iter().cloned()) {
            let c = c.unwrap_or(char::REPLACEMENT_CHARACTER);
            let len = c.len_utf8();
            if len < remaining.len() {
                c.encode_utf8(remaining);
                let tmp = remaining;
                remaining = &mut tmp[len..];
                name_len += len;
            } else {
                break;
            }
        }
    }
    let name = &name_buffer[..name_len] as *const [u8];

    let mut line = mem::zeroed::<IMAGEHLP_LINEW64>();
    line.SizeOfStruct = mem::size_of::<IMAGEHLP_LINEW64>() as DWORD;

    let mut filename = None;
    let mut lineno = None;
    if get_line_from_addr(&mut line) == TRUE {
        lineno = Some(line.LineNumber as u32);

        let base = line.FileName;
        let mut len = 0;
        while *base.offset(len) != 0 {
            len += 1;
        }

        let len = len as usize;

        filename = Some(slice::from_raw_parts(base, len) as *const [u16]);
    }

    cb(&super::Symbol {
        inner: Symbol {
            name,
            addr: info.Address as *mut _,
            line: lineno,
            filename,
            _filename_cache: cache(filename),
            _marker: marker::PhantomData,
        },
    })
}

#[cfg(feature = "std")]
unsafe fn cache(filename: Option<*const [u16]>) -> Option<::std::ffi::OsString> {
    use std::os::windows::ffi::OsStringExt;
    filename.map(|f| ::std::ffi::OsString::from_wide(&*f))
}

#[cfg(not(feature = "std"))]
unsafe fn cache(_filename: Option<*const [u16]>) {}

pub unsafe fn clear_symbol_cache() {}