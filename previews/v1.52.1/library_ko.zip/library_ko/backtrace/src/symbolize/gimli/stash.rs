// 지금은 Linux 에서만 사용되므로 다른 곳에 데드 코드 허용
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// 바이트 버퍼를위한 간단한 아레나 할당 자.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// 지정된 크기의 버퍼를 할당하고 이에 대한 가변 참조를 반환합니다.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // 안전: 이것은 가변성을 생성하는 유일한 함수입니다.
        // `self.buffers` 를 참조하십시오.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // 안전: `self.buffers` 에서 요소를 제거하지 않으므로
        // 버퍼 내부의 데이터는 `self` 만큼 오래 유지됩니다.
        &mut buffers[i]
    }
}