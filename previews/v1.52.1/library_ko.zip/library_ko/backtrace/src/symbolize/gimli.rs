//! crates.io 에서 `gimli` crate 를 사용한 기호화 지원
//!
//! 이것은 Rust 의 기본 기호화 구현입니다.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // '정적 수명은 자체 참조 구조체에 대한 지원 부족을 해킹하는 거짓말입니다.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 심볼은 `map` 와 `stash` 만 빌려야하고 아래에서 보존하고 있으므로 '정적 수명'으로 변환합니다.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows 에서 네이티브 라이브러리를로드하려면 여기에서 다양한 전략에 대한 rust-lang/rust#71060 에 대한 토론을 참조하십시오.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW 라이브러리는 현재 ASLR (rust-lang/rust#16514) 를 지원하지 않지만 DLL은 여전히 주소 공간에서 재배치 될 수 있습니다.
            // 디버그 정보의 주소는 모두이 라이브러리가 COFF 파일 헤더의 필드 인 "image base" 에서로드 된 것과 같습니다.
            // 이것이 debuginfo가 나열하는 것처럼 보이므로 심볼 테이블을 구문 분석하고 라이브러리가 "image base" 에서로드 된 것처럼 주소를 저장합니다.
            //
            // 그러나 라이브러리는 "image base" 에서로드되지 않을 수 있습니다.
            // (아마도 거기에 다른 것이로드 될 수 있습니까?) 여기에서 `bias` 필드가 작동하고 여기서 `bias` 의 값을 알아 내야합니다.불행히도로드 된 모듈에서 이것을 얻는 방법은 명확하지 않습니다.
            // 그러나 우리가 가진 것은 실제로드 주소 (`modBaseAddr`) 입니다.
            //
            // 지금은 파일을 mmap하고 파일 헤더 정보를 읽은 다음 mmap을 삭제합니다.나중에 mmap을 다시 열 것이기 때문에 낭비 적이지만 지금은 충분히 작동 할 것입니다.
            //
            // `image_base` (원하는로드 위치)와 `base_addr` (실제로드 위치)가 있으면 `bias` (실제로드 위치와 원하는로드 위치의 차이)를 채울 수 있으며 각 세그먼트의 명시된 주소는 파일이 말하는 것이므로 `image_base` 입니다.
            //
            //
            // 지금은 ELF/MachO 와 달리 `modBaseSize` 를 전체 크기로 사용하여 라이브러리 당 하나의 세그먼트로 작업을 수행 할 수있는 것으로 보입니다.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O 파일 형식을 사용하고 DYLD 특정 API를 사용하여 애플리케이션의 일부인 기본 라이브러리 목록을로드합니다.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // 로드 할 경로에 해당하는이 라이브러리의 이름도 가져옵니다.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // 이 라이브러리의 이미지 헤더를로드하고 `object` 에 위임하여 여기에 관련된 모든 세그먼트를 파악할 수 있도록 모든로드 명령을 구문 분석합니다.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // 세그먼트를 반복하고 찾은 세그먼트에 대해 알려진 영역을 등록합니다.
            // 또한 나중에 처리 할 텍스트 세그먼트에 대한 정보를 기록합니다. 아래 설명을 참조하십시오.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // 이 라이브러리의 "slide" 를 결정하여 메모리 개체가로드되는 위치를 파악하는 데 사용하는 편향이됩니다.
            // 이것은 약간의 이상한 계산이며, 야생에서 몇 가지를 시도하고 무엇이 달라지는 지 확인한 결과입니다.
            //
            // 일반적인 아이디어는 `bias` 와 세그먼트의 `stated_virtual_memory_address` 가 실제 주소 공간에서 세그먼트가 상주하는 위치에 있다는 것입니다.
            // 하지만 우리가 의존하는 또 다른 것은 `bias` 를 제외한 실제 주소가 심볼 테이블과 debuginfo에서 조회 할 인덱스라는 것입니다.
            //
            // 그러나 시스템로드 라이브러리의 경우 이러한 계산이 올바르지 않습니다.그러나 기본 실행 파일의 경우 올바른 것으로 보입니다.
            // LLDB의 소스에서 일부 논리를 해제하면 크기가 0이 아닌 파일 오프셋 0에서로드 된 첫 번째 `__TEXT` 섹션에 대한 특수 케이스가 있습니다.
            // 이것이 존재하는 이유가 무엇이든 심볼 테이블이 라이브러리의 vmaddr 슬라이드와 관련이 있음을 의미하는 것처럼 보입니다.
            // 존재하지 *않으면* 기호 테이블은 vmaddr 슬라이드와 세그먼트의 명시된 주소에 상대적입니다.
            //
            // 이 상황을 처리하기 위해 파일 오프셋 0에서 텍스트 섹션을 찾지 *않으면* 첫 번째 텍스트 섹션의 명시된 주소만큼 편향을 높이고 명시된 모든 주소도 그 양만큼 줄입니다.
            //
            // 이렇게하면 심볼 테이블이 항상 라이브러리의 바이어스 양에 상대적으로 나타납니다.
            // 이것은 기호 테이블을 통한 기호화에 대한 올바른 결과를 갖는 것으로 보입니다.
            //
            // 솔직히 나는 이것이 옳은지 또는 이것을 수행하는 방법을 나타내는 다른 것이 있는지 완전히 확신하지 못합니다.
            // 현재로서는 (?) 가 충분히 잘 작동하는 것처럼 보이지만 필요한 경우 시간이 지남에 따라 항상 조정할 수 있어야합니다.
            //
            // 자세한 내용은 #318 를 참조하십시오.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // 기타 Unix (예 :
        // Linux) 플랫폼은 ELF를 객체 파일 형식으로 사용하며 일반적으로 `dl_iterate_phdr` 라는 API를 구현하여 네이티브 라이브러리를로드합니다.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` 유효한 포인터 여야합니다.
        // `vec` `std::Vec` 에 대한 유효한 포인터 여야합니다.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 기본적으로 디버그 정보를 지원하지 않지만 빌드 시스템은 `romfs:/debug_info.elf` 경로에 디버그 정보를 배치합니다.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // 다른 모든 것은 ELF를 사용해야하지만 네이티브 라이브러리를로드하는 방법을 모릅니다.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// 로드 된 알려진 모든 공유 라이브러리.
    libraries: Vec<Library>,

    /// 파싱 된 드워프 정보를 보관하는 매핑 캐시.
    ///
    /// 이 목록은 증가하지 않는 전체 리프팅 시간에 대해 고정 된 용량을 가지고 있습니다.
    /// 각 쌍의 `usize` 요소는 위의 `libraries` 에 대한 색인입니다. 여기서 `usize::max_value()` 는 현재 실행 파일을 나타냅니다.
    ///
    /// `Mapping` 는 해당 구문 분석 된 왜성 정보입니다.
    ///
    /// 이것은 기본적으로 LRU 캐시이며 주소를 상징 할 때 여기에서 물건을 이동시킬 것입니다.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// 이 라이브러리의 세그먼트는 메모리에로드되고로드되는 위치입니다.
    segments: Vec<LibrarySegment>,
    /// 일반적으로 메모리에로드되는이 라이브러리의 "bias" 입니다.
    /// 이 값은 세그먼트가로드되는 실제 가상 메모리 주소를 가져 오기 위해 각 세그먼트의 명시된 주소에 추가됩니다.
    /// 또한이 바이어스는 실제 가상 메모리 주소에서 빼서 debuginfo 및 기호 테이블에 색인화합니다.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// 오브젝트 파일에서이 세그먼트의 명시된 주소입니다.
    /// 이것은 실제로 세그먼트가로드되는 위치가 아니라이 주소와 포함 라이브러리의 `bias` 가 세그먼트를 찾을 위치입니다.
    ///
    stated_virtual_memory_address: usize,
    /// 메모리에있는 세그먼트의 크기입니다.
    len: usize,
}

// 외부에서 동기화해야하므로 안전하지 않습니다.
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // 외부에서 동기화해야하므로 안전하지 않습니다.
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // 디버그 정보 매핑을위한 매우 작고 간단한 LRU 캐시입니다.
        //
        // 일반적인 스택은 많은 공유 라이브러리간에 교차하지 않기 때문에 적중률은 매우 높아야합니다.
        //
        // `addr2line::Context` 구조는 만드는 데 상당히 비쌉니다.
        // 그 비용은 후속 `locate` 쿼리에 의해 상각 될 것으로 예상되며, 이는`addr2line: : Context`를 구성 할 때 구축 된 구조를 활용하여 멋진 속도 향상을 얻습니다.
        //
        // 우리가이 캐시가 없다면, 그 상각은 결코 일어나지 않을 것이고, 상징적 인 역 추적은 ssssllllooooowwww가 될 것입니다.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // 먼저이 `lib` 에 `addr` (재배치 처리)를 포함하는 세그먼트가 있는지 테스트합니다.이 검사가 통과되면 아래에서 계속 진행하여 실제로 주소를 번역 할 수 있습니다.
                //
                // 여기서는 오버플로 검사를 피하기 위해 `wrapping_add` 를 사용하고 있습니다.야생에서 SVMA + 바이어스 계산이 오버플로되는 것으로 나타났습니다.
                // 일어날 수있는 일이 조금 이상해 보이지만 공간을 가리킬 가능성이 높기 때문에 해당 세그먼트를 무시하는 것 외에 우리가 할 수있는 일이 많지 않습니다.
                //
                // 이것은 원래 rust-lang/backtrace-rs#329 에서 나왔습니다.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // 이제 `lib` 에 `addr` 가 포함되어 있음을 알았으므로 지정된 가상 메모리 주소를 찾기 위해 편향으로 오프셋 할 수 있습니다.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // 불변: 이 조건이 조기 반환없이 완료된 후
        // 오류로 인해이 경로의 캐시 항목은 인덱스 0에 있습니다.

        if let Some(idx) = idx {
            // 매핑이 이미 캐시에있는 경우 맨 앞으로 이동합니다.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // 매핑이 캐시에없는 경우 새 매핑을 만들고 캐시 전면에 삽입하고 필요한 경우 가장 오래된 캐시 항목을 제거합니다.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` 수명을 유출하지 말고 우리 자신에게만 적용되도록하십시오.
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // 안타깝게도 여기에 필요하므로 `sym` 의 수명을 `'static` 로 연장합니다. 그러나 참조로 사용되기 때문에이 프레임을 넘어서는 참조가 유지되지 않아야합니다.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // 마지막으로 캐시 된 매핑을 가져 오거나이 파일에 대한 새 매핑을 만들고 DWARF 정보를 평가하여이 주소에 대한 file/line/name 를 찾습니다.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// 이 심볼에 대한 프레임 정보를 찾을 수 있었고`addr2line`의 프레임은 내부적으로 모든 핵심 세부 사항을 가지고 있습니다.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// 디버그 정보를 찾을 수 없지만 elf 실행 파일의 기호 테이블에서 찾았습니다.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}