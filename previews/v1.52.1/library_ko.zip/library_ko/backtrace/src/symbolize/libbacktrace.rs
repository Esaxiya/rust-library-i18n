//! libbacktrace에서 DWARF 구문 분석 코드를 사용하는 기호화 전략.
//!
//! 일반적으로 gcc 와 함께 배포되는 libbacktrace C 라이브러리는 역 추적 (실제로 사용하지 않음)을 생성 할뿐만 아니라 역 추적을 상징화하고 인라인 프레임 등의 항목에 대한 난쟁이 디버그 정보를 처리하는 것을 지원합니다.
//!
//!
//! 여기에는 다양한 문제가 많기 때문에 비교적 복잡하지만 기본 아이디어는 다음과 같습니다.
//!
//! * 먼저 `backtrace_syminfo` 라고합니다.가능한 경우 동적 기호 테이블에서 기호 정보를 가져옵니다.
//! * 다음으로 `backtrace_pcinfo` 를 호출합니다.이것은 사용 가능한 경우 debuginfo 테이블을 구문 분석하고 인라인 프레임, 파일 이름, 줄 번호 등에 대한 정보를 복구 할 수 있도록합니다.
//!
//! dwarf 테이블을 libbacktrace로 가져 오는 방법에는 많은 속임수가 있지만, 이것이 세상의 끝이 아니기를 바라며 아래에서 읽을 때 충분히 명확합니다.
//!
//! 이것은 비 MSVC 및 비 OSX 플랫폼에 대한 기본 기호화 전략입니다.libstd에서는 이것이 OSX의 기본 전략입니다.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // 가능한 경우 debuginfo에서 가져온 `function` 이름을 선호하며 일반적으로 인라인 프레임에 대해 더 정확할 수 있습니다.
                // 그것이 존재하지 않지만 `symname` 에 지정된 기호 테이블 이름으로 돌아가십시오.
                //
                // 예를 들어 `try<i32,closure>` 가 `std::panicking::try::do_call` 가 아닌 것으로 표시되는 경우와 같이 `function` 가 다소 덜 정확하다고 느낄 수 있습니다.
                //
                // 이유는 명확하지 않지만 전반적으로 `function` 이름이 더 정확 해 보입니다.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // 지금은 아무것도하지 마세요
}

/// `syminfo_cb` 에 전달 된 `data` 포인터의 유형
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // 해결을 시작할 때 `backtrace_syminfo` 에서이 콜백이 호출되면 `backtrace_pcinfo` 를 호출합니다.
    // `backtrace_pcinfo` 기능은 디버그 정보를 참조하고 인라인 프레임뿐만 아니라 file/line 정보 복구와 같은 작업을 수행합니다.
    // 디버그 정보가 없으면 `backtrace_pcinfo` 가 실패하거나 많은 작업을 수행하지 않을 수 있으므로 이러한 상황이 발생하면 `syminfo_cb` 에서 적어도 하나의 기호를 사용하여 콜백을 호출해야합니다.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb` 에 전달 된 `data` 포인터의 유형
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API는 상태 생성을 지원하지만 상태 삭제는 지원하지 않습니다.
// 나는 개인적으로 이것을 상태가 창조되고 영원히 살도록 의미한다고 생각합니다.
//
// 이 상태를 정리하는 at_exit() 핸들러를 등록하고 싶지만 libbacktrace는 그렇게 할 수있는 방법을 제공하지 않습니다.
//
// 이러한 제약 조건으로이 함수는 처음 요청 될 때 계산되는 정적으로 캐시 된 상태를 갖습니다.
//
// 역 추적은 모두 연속적으로 발생합니다 (하나의 전역 잠금).
//
// 여기서 동기화의 부족은 `resolve` 가 외부 적으로 동기화되어야하기 때문입니다.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // libbacktrace의 스레드 세이프 기능은 항상 동기화 된 방식으로 호출하므로 사용하지 마십시오.
        //
        0,
        error_cb,
        ptr::null_mut(), // 추가 데이터 없음
    );

    return STATE;

    // libbacktrace가 전혀 작동하려면 현재 실행 파일에 대한 DWARF 디버그 정보를 찾아야합니다.일반적으로 다음을 포함하되 이에 국한되지 않는 여러 메커니즘을 통해이를 수행합니다.
    //
    // * /proc/self/exe 지원되는 플랫폼
    // * 상태를 만들 때 명시 적으로 전달 된 파일 이름
    //
    // libbacktrace 라이브러리는 C 코드의 큰 덩어리입니다.이것은 당연히, 특히 잘못된 디버그 정보를 처리 할 때 메모리 안전 취약성이 있음을 의미합니다.
    // Libstd는 역사적으로 많은 것을 겪었습니다.
    //
    // /proc/self/exe 를 사용하면 일반적으로 libbacktrace가 "mostly correct" 라고 가정하고 "attempted to be correct" 난쟁이 디버그 정보로 이상한 일을하지 않는다고 가정하므로 일반적으로이를 무시할 수 있습니다.
    //
    //
    // 그러나 파일 이름을 전달하면 일부 플랫폼 (예: BSD)에서 악의적 인 행위자가 해당 위치에 임의의 파일을 배치 할 수 있습니다.
    // 이것은 libbacktrace에 파일 이름에 대해 알려 주면 임의의 파일을 사용하여 segfault를 유발할 수 있음을 의미합니다.
    // libbacktrace에 아무것도 알려주지 않으면 /proc/self/exe 와 같은 경로를 지원하지 않는 플랫폼에서는 아무 작업도 수행하지 않습니다!
    //
    // 가능한 모든 것을 감안할 때 파일 이름을 전달하지 *않도록* 노력하지만 /proc/self/exe 를 전혀 지원하지 않는 플랫폼을 사용해야합니다.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // 이상적으로는 `std::env::current_exe` 를 사용하지만 여기서는 `std` 가 필요하지 않습니다.
            //
            // `_NSGetExecutablePath` 를 사용하여 현재 실행 가능한 경로를 정적 영역에로드합니다 (너무 작 으면 포기).
            //
            //
            // 여기서 우리는 libbacktrace가 손상된 실행 파일로 인해 죽지 않기 위해 진지하게 신뢰하고 있지만 확실히 그렇습니다.
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows 파일을 연 후에는 삭제할 수없는 모드가 있습니다.
            // 이는 일반적으로 libbacktrace에 실행 파일을 넘긴 후 실행 파일이 변경되지 않도록하고 임의의 데이터를 libbacktrace (잘못 처리 될 수 있음)로 전달하는 기능을 완화하기를 원하기 때문에 여기서 원하는 것입니다.
            //
            //
            // 우리 자신의 이미지에 일종의 고정을 시도하기 위해 여기서 약간의 춤을 춘다는 것을 감안할 때 :
            //
            // * 현재 프로세스에 대한 핸들을 가져오고 파일 이름을로드합니다.
            // * 올바른 플래그를 사용하여 해당 파일 이름으로 파일을 엽니 다.
            // * 현재 프로세스의 파일 이름을 다시로드하여 동일한 지 확인하십시오.
            //
            // 이 모든 과정이 이론적으로 우리가 실제로 프로세스의 파일을 열었다면 변경되지 않을 것입니다.FWIW는 역사적으로 libstd에서 복사 한 것이므로 이것이 무슨 일이 일어 났는지에 대한 최선의 해석입니다.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // 이것은 우리가 반환 할 수 있도록 정적 메모리에 있습니다.
                static mut BUF: [i8; N] = [0; N];
                // ... 그리고 이것은 일시적이기 때문에 스택에 있습니다.
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // `handle` 를 열면이 파일 이름에 대한 잠금이 유지되므로 의도적으로 여기에서 `handle` 를 누출합니다.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // nul로 끝나는 슬라이스를 반환하고 싶으므로 모든 것이 채워져 있고 전체 길이와 같으면 실패와 동일합니다.
                //
                //
                // 그렇지 않으면 성공을 반환 할 때 nul 바이트가 슬라이스에 포함되어 있는지 확인하십시오.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // 역 추적 오류는 현재 깔개 아래로 휩쓸립니다.
    let state = init_state();
    if state.is_null() {
        return;
    }

    // (코드 읽기에서) `syminfo_cb` 를 정확히 한 번 호출해야하는 `backtrace_syminfo` API를 호출합니다 (또는 아마도 오류와 함께 실패).
    // 그런 다음 `syminfo_cb` 내에서 더 많은 것을 처리합니다.
    //
    // 바이너리에 디버그 정보가 없더라도 `syminfo` 가 심볼 테이블을 참조하여 심볼 이름을 찾기 때문에이 작업을 수행합니다.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}