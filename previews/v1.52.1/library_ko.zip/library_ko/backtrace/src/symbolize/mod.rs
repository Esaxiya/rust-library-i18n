use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// 지정된 클로저에 기호를 전달하여 주소를 기호로 해석합니다.
///
/// 이 함수는 로컬 심볼 테이블, 동적 심볼 테이블 또는 DWARF 디버그 정보 (활성화 된 구현에 따라 다름)와 같은 영역에서 주어진 주소를 조회하여 양보 할 심볼을 찾습니다.
///
///
/// 해결을 수행 할 수없는 경우 클로저가 호출되지 않을 수 있으며 인라인 함수의 경우 두 번 이상 호출 될 수도 있습니다.
///
/// 생성 된 기호는 지정된 `addr` 에서의 실행을 나타내며 해당 주소에 대한 file/line 쌍을 반환합니다 (사용 가능한 경우).
///
/// `Frame` 가있는 경우이 기능 대신 `resolve_frame` 기능을 사용하는 것이 좋습니다.
///
/// # 필수 기능
///
/// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
///
/// # Panics
///
/// 이 기능은 절대 panic 를 사용하지 않으려 고 노력하지만 `cb` 가 panics 를 제공했다면 일부 플랫폼은 이중 panic 가 프로세스를 중단하도록 강제합니다.
/// 일부 플랫폼은 풀 수없는 콜백을 내부적으로 사용하는 C 라이브러리를 사용하므로 `cb` 에서 당황하면 프로세스 중단이 트리거 될 수 있습니다.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // 상단 프레임 만 봐
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// 이전에 캡처 한 프레임을 심볼로 확인하고 심볼을 지정된 클로저로 전달합니다.
///
/// 이 functin은 주소 대신 인수로 `Frame` 를 사용한다는 점을 제외하면 `resolve` 와 동일한 기능을 수행합니다.
/// 이것은 예를 들어, 더 정확한 심볼 정보 또는 인라인 프레임에 대한 정보를 제공하기 위해 백 트레이싱의 일부 플랫폼 구현을 허용 할 수 있습니다.
///
/// 가능하다면 이것을 사용하는 것이 좋습니다.
///
/// # 필수 기능
///
/// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
///
/// # Panics
///
/// 이 기능은 절대 panic 를 사용하지 않으려 고 노력하지만 `cb` 가 panics 를 제공했다면 일부 플랫폼은 이중 panic 가 프로세스를 중단하도록 강제합니다.
/// 일부 플랫폼은 풀 수없는 콜백을 내부적으로 사용하는 C 라이브러리를 사용하므로 `cb` 에서 당황하면 프로세스 중단이 트리거 될 수 있습니다.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // 상단 프레임 만 봐
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// 스택 프레임의 IP 값은 일반적으로 실제 스택 추적 인 호출 *후* 명령의 (always?) 입니다.
// 이것을 상징화하면 filename/line 번호가 하나 앞에 있고 함수의 끝 부분에 가까워지면 공백이 될 수 있습니다.
//
// 이것은 기본적으로 모든 플랫폼에서 항상 발생하는 것처럼 보이므로 항상 반환되는 명령 대신 이전 호출 명령으로 해결하기 위해 해결 된 ip에서 하나를 뺍니다.
//
//
// 이상적으로 우리는 이것을하지 않을 것입니다.
// 이상적으로는 여기에서 `resolve` API의 호출자가 -1 를 수동으로 수행하고 현재가 아닌 *이전* 명령에 대한 위치 정보를 원한다고 설명해야합니다.
// 이상적으로는 우리가 실제로 다음 명령어의 주소이거나 현재의 주소라면 `Frame` 에 노출하는 것입니다.
//
// 현재로서는 이것이 매우 틈새 시장의 문제이므로 내부적으로 항상 하나를 뺍니다.
// 소비자는 계속 일하고 꽤 좋은 결과를 얻어야하므로 우리는 충분히 잘해야합니다.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` 와 동일하지만 동기화되지 않았기 때문에 안전하지 않습니다.
///
/// 이 기능은 동기화가 보장되지 않지만이 crate 의 `std` 기능이 컴파일되지 않은 경우 사용할 수 있습니다.
/// 더 많은 문서와 예제는 `resolve` 함수를 참조하십시오.
///
/// # Panics
///
/// `cb` 패닉에 대한 경고는 `resolve` 에 대한 정보를 참조하십시오.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` 와 동일하지만 동기화되지 않았기 때문에 안전하지 않습니다.
///
/// 이 기능은 동기화가 보장되지 않지만이 crate 의 `std` 기능이 컴파일되지 않은 경우 사용할 수 있습니다.
/// 더 많은 문서와 예제는 `resolve_frame` 함수를 참조하십시오.
///
/// # Panics
///
/// `cb` 패닉에 대한 경고는 `resolve_frame` 에 대한 정보를 참조하십시오.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// 파일에서 심볼의 해상도를 나타내는 trait 입니다.
///
/// 이 trait 는 `backtrace::resolve` 함수에 주어진 클로저에 trait 객체로 양보되며, 어떤 구현이 뒤에 있는지 알 수 없기 때문에 가상으로 전달됩니다.
///
///
/// 기호는 이름, 파일 이름, 줄 번호, 정확한 주소 등과 같은 기능에 대한 컨텍스트 정보를 제공 할 수 있습니다.
/// 그러나 심볼에서 모든 정보를 항상 사용할 수있는 것은 아니므로 모든 메서드는 `Option` 를 반환합니다.
///
///
pub struct Symbol {
    // TODO: 이 수명 제한은 결국 `Symbol` 로 유지되어야합니다.
    // 그러나 그것은 현재 획기적인 변화입니다.
    // 지금은 `Symbol` 가 참조로만 배포되고 복제 할 수 없기 때문에 안전합니다.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// 이 함수의 이름을 반환합니다.
    ///
    /// 반환 된 구조는 심볼 이름에 대한 다양한 속성을 쿼리하는 데 사용할 수 있습니다.
    ///
    ///
    /// * `Display` 구현은 꺾인 기호를 인쇄합니다.
    /// * 기호의 원시 `str` 값에 액세스 할 수 있습니다 (유효한 utf-8 인 경우).
    /// * 기호 이름의 원시 바이트에 액세스 할 수 있습니다.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// 이 함수의 시작 주소를 반환합니다.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// 원시 파일 이름을 조각으로 반환합니다.
    /// 이것은 주로 `no_std` 환경에 유용합니다.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// 이 기호가 현재 실행중인 열 번호를 반환합니다.
    ///
    /// 현재 gimli만이 여기에 값을 제공하고 `filename` 가 `Some` 를 반환하는 경우에만 값을 제공하므로 결과적으로 유사한 경고가 적용됩니다.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// 이 기호가 현재 실행중인 곳의 줄 번호를 반환합니다.
    ///
    /// `filename` 가 `Some` 를 반환하는 경우이 반환 값은 일반적으로 `Some` 이며 결과적으로 유사한 경고가 적용됩니다.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// 이 함수가 정의 된 파일 이름을 반환합니다.
    ///
    /// 이것은 현재 libbacktrace 또는 gimli를 사용하는 경우에만 사용할 수 있습니다 (예 :
    /// unix 플랫폼 기타) 및 바이너리가 debuginfo로 컴파일 될 때.
    /// 이러한 조건이 모두 충족되지 않으면 `None` 를 반환 할 가능성이 높습니다.
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Rust 로 망가진 기호를 구문 분석하지 못한 경우 구문 분석 된 C++ 기호 일 수 있습니다.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // `cpp_demangle` 기능이 비활성화되었을 때 비용이 들지 않도록이 크기를 0으로 유지하십시오.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// demangled 이름, 원시 바이트, 원시 문자열 등에 인체 공학적 접근자를 제공하기 위해 기호 이름을 감싸는 래퍼입니다.
///
// `cpp_demangle` 기능이 활성화되지 않은 경우 데드 코드를 허용합니다.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// 원시 기본 바이트에서 새 기호 이름을 만듭니다.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// 기호가 유효한 utf-8 인 경우 원시 (mangled) 기호 이름을 `str` 로 반환합니다.
    ///
    /// 디 앵글 버전을 원하면 `Display` 구현을 사용하십시오.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// 원시 기호 이름을 바이트 목록으로 반환합니다.
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // 꺾인 기호가 실제로 유효하지 않은 경우 인쇄 할 수 있으므로 오류를 바깥쪽으로 전파하지 않음으로써 여기서 오류를 정상적으로 처리하십시오.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// 주소를 기호화하는 데 사용 된 캐시 된 메모리를 회수 해보십시오.
///
/// 이 메서드는 일반적으로 구문 분석 된 DWARF 정보 또는 이와 유사한 것을 나타내는 스레드 또는 전역 적으로 캐시 된 모든 전역 데이터 구조를 해제하려고 시도합니다.
///
///
/// # Caveats
///
/// 이 기능은 항상 사용할 수 있지만 실제로 대부분의 구현에서 아무 작업도 수행하지 않습니다.
/// dbghelp 또는 libbacktrace와 같은 라이브러리는 상태를 할당 해제하고 할당 된 메모리를 관리하는 기능을 제공하지 않습니다.
/// 현재이 crate 의 `gimli-symbolize` 기능은이 기능이 효과가있는 유일한 기능입니다.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}