use core::ffi::c_void;
use core::fmt;

/// 현재 호출 스택을 검사하여 모든 활성 프레임을 제공된 클로저로 전달하여 스택 추적을 계산합니다.
///
/// 이 함수는 프로그램에 대한 스택 추적을 계산할 때이 라이브러리의 핵심 요소입니다.주어진 클로저 `cb` 는 스택의 해당 호출 프레임에 대한 정보를 나타내는 `Frame` 의 인스턴스를 생성합니다.
/// 클로저는 하향식 방식으로 프레임을 생성합니다 (가장 최근에는 함수라고 함).
///
/// 클로저의 반환 값은 역 추적이 계속되어야하는지 여부를 나타냅니다.`false` 의 반환 값은 역 추적을 종료하고 즉시 반환합니다.
///
/// `Frame` 가 획득되면 `backtrace::resolve` 를 호출하여 `ip` (명령 포인터) 또는 기호 주소를 이름 및/또는 파일 이름/라인 번호를 학습 할 수있는 `Symbol` 로 변환 할 수 있습니다.
///
///
/// 이것은 상대적으로 낮은 수준의 함수이며, 예를 들어 나중에 검사 할 역 추적을 캡처하려는 경우 `Backtrace` 유형이 더 적합 할 수 있습니다.
///
/// # 필수 기능
///
/// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
///
/// # Panics
///
/// 이 기능은 절대 panic 를 사용하지 않으려 고 노력하지만 `cb` 가 panics 를 제공했다면 일부 플랫폼은 이중 panic 가 프로세스를 중단하도록 강제합니다.
/// 일부 플랫폼은 풀 수없는 콜백을 내부적으로 사용하는 C 라이브러리를 사용하므로 `cb` 에서 당황하면 프로세스 중단이 트리거 될 수 있습니다.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // 역 추적 계속
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` 와 동일하지만 동기화되지 않았기 때문에 안전하지 않습니다.
///
/// 이 기능은 동기화가 보장되지 않지만이 crate 의 `std` 기능이 컴파일되지 않은 경우 사용할 수 있습니다.
/// 더 많은 문서와 예제는 `trace` 함수를 참조하십시오.
///
/// # Panics
///
/// `cb` 패닉에 대한 경고는 `trace` 에 대한 정보를 참조하십시오.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// 역 추적의 한 프레임을 나타내는 trait 는이 crate 의 `trace` 기능에 양보됩니다.
///
/// 추적 함수의 클로저는 프레임이 생성되며, 기본 구현이 런타임까지 항상 알려지지 않았으므로 프레임이 가상으로 전달됩니다.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// 이 프레임의 현재 명령 포인터를 반환합니다.
    ///
    /// 이것은 일반적으로 프레임에서 실행되는 다음 명령이지만 모든 구현이 100% 정확도로 나열하지는 않습니다 (하지만 일반적으로 매우 유사합니다).
    ///
    ///
    /// 이 값을 `backtrace::resolve` 에 전달하여 기호 이름으로 바꾸는 것이 좋습니다.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// 이 프레임의 현재 스택 포인터를 반환합니다.
    ///
    /// 백엔드가이 프레임에 대한 스택 포인터를 복구 할 수없는 경우 널 포인터가 리턴됩니다.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// 이 함수 프레임의 시작 심볼 주소를 반환합니다.
    ///
    /// `ip` 가 반환 한 명령어 포인터를 함수의 시작 부분으로 되 감아 해당 값을 반환합니다.
    ///
    /// 그러나 어떤 경우에는 백엔드가이 함수에서 `ip` 만 반환합니다.
    ///
    /// 위의 `ip` 에서 `backtrace::resolve` 가 실패한 경우 반환 된 값을 사용할 수 있습니다.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// 프레임이 속한 모듈의 기본 주소를 반환합니다.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Miri가 호스트 플랫폼보다 우선권을 갖도록하려면 이것이 먼저 이루어져야합니다.
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // dbghelp symbolize에서만 사용됩니다.
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}