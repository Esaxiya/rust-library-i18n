//! 다른 구현이 적절하지 않을 때 사용되는 해제의 빈 구현입니다.
//!

use core::ffi::c_void;

#[inline(always)]
pub fn trace(_cb: &mut dyn FnMut(&super::Frame) -> bool) {}

#[derive(Clone)]
pub struct Frame;

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        0 as *mut _
    }

    pub fn sp(&self) -> *mut c_void {
        0 as *mut _
    }

    pub fn symbol_address(&self) -> *mut c_void {
        0 as *mut _
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}