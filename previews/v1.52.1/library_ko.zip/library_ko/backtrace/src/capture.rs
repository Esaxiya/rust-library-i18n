use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// 소유 및 자체 포함 된 역 추적을 나타냅니다.
///
/// 이 구조는 프로그램의 다양한 지점에서 역 추적을 캡처하는 데 사용할 수 있으며 나중에 그 당시 역 추적이 무엇이 었는지 검사하는 데 사용할 수 있습니다.
///
///
/// `Backtrace` `Debug` 구현을 통해 역 추적의 예쁜 인쇄를 지원합니다.
///
/// # 필수 기능
///
/// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // 여기에있는 프레임은 스택의 위에서 아래로 나열됩니다.
    frames: Vec<BacktraceFrame>,
    // 우리가 믿는 인덱스는 `Backtrace::new` 및 `backtrace::trace` 와 같은 프레임을 생략 한 백 트레이스의 실제 시작입니다.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// 역 추적에서 캡처 된 프레임 버전입니다.
///
/// 이 유형은 `Backtrace::frames` 에서 목록으로 반환되며 캡처 된 역 추적에서 하나의 스택 프레임을 나타냅니다.
///
/// # 필수 기능
///
/// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// 역 추적에서 캡처 된 심볼 버전입니다.
///
/// 이 유형은 `BacktraceFrame::symbols` 에서 목록으로 반환되며 역 추적의 기호에 대한 메타 데이터를 나타냅니다.
///
/// # 필수 기능
///
/// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// 이 함수의 호출 사이트에서 역 추적을 캡처하여 소유 된 표현을 반환합니다.
    ///
    /// 이 함수는 백 트레이스를 Rust 의 객체로 표현하는 데 유용합니다.이 반환 된 값은 스레드를 통해 전송되고 다른 곳에서 인쇄 될 수 있으며이 값의 목적은 완전히 자체 포함되는 것입니다.
    ///
    /// 일부 플랫폼에서는 전체 역 추적을 획득하고이를 해결하는 데 매우 많은 비용이들 수 있습니다.
    /// 비용이 애플리케이션에 너무 많은 경우 대신 `Backtrace::new_unresolved()` 를 사용하는 것이 좋습니다. `Backtrace::new_unresolved()` 는 일반적으로 가장 오래 걸리는 기호 해결 단계를 피하고 나중에이를 지연시킬 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // 제거 할 프레임이 있는지 확인하고 싶습니다.
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// 심볼을 확인하지 않는다는 점을 제외하면 `new` 와 유사하지만 단순히 주소 목록으로 역 추적을 캡처합니다.
    ///
    /// 나중에 `resolve` 함수를 호출하여이 역 추적 기호를 읽을 수있는 이름으로 해석 할 수 있습니다.
    /// 이 기능은 해결 프로세스가 때때로 상당한 시간이 걸릴 수 있지만 하나의 역 추적이 거의 인쇄되지 않을 수 있기 때문에 존재합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // 기호 이름 없음
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // 이제 기호 이름이 있습니다.
    /// ```
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    ///
    ///
    #[inline(never)] // 제거 할 프레임이 있는지 확인하고 싶습니다.
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// 이 역 추적이 캡처 된 시점의 프레임을 반환합니다.
    ///
    /// 이 슬라이스의 첫 번째 항목은 `Backtrace::new` 함수일 가능성이 높고 마지막 프레임은이 스레드 또는 주 함수가 시작된 방법에 대한 것입니다.
    ///
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// 이 역 추적이 `new_unresolved` 에서 생성 된 경우이 함수는 역 추적의 모든 주소를 기호 이름으로 해석합니다.
    ///
    ///
    /// 이 역 추적이 이전에 해결되었거나 `new` 를 통해 생성 된 경우이 함수는 아무 작업도 수행하지 않습니다.
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// 이 프레임이 해당하는 심볼 목록을 반환합니다.
    ///
    /// 일반적으로 프레임 당 하나의 심볼 만 있지만 때로는 여러 함수가 하나의 프레임에 인라인되는 경우 여러 심볼이 반환됩니다.
    /// 나열된 첫 번째 기호는 "innermost function" 이고 마지막 기호는 가장 바깥 쪽 (마지막 호출자)입니다.
    ///
    /// 이 프레임이 해결되지 않은 역 추적에서 온 경우 빈 목록이 반환됩니다.
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` 와 동일
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // 경로를 인쇄 할 때 cwd가 있으면 제거하려고합니다. 그렇지 않으면 경로를 그대로 인쇄합니다.
        // 짧은 형식에 대해서만이 작업을 수행합니다. 꽉 차면 모든 것을 인쇄하기를 원하기 때문입니다.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}