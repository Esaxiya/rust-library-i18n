#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// 역 추적을위한 포맷터.
///
/// 이 유형은 역 추적 자체의 출처에 관계없이 역 추적을 인쇄하는 데 사용할 수 있습니다.
/// `Backtrace` 유형이있는 경우 해당 `Debug` 구현은 이미이 인쇄 형식을 사용합니다.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// 우리가 인쇄 할 수있는 인쇄 스타일
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// 이상적으로는 관련 정보 만 포함하는 간결한 역 추적을 인쇄합니다.
    Short,
    /// 가능한 모든 정보를 포함하는 역 추적을 인쇄합니다.
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// 제공된 `fmt` 에 출력을 쓸 새 `BacktraceFmt` 를 만듭니다.
    ///
    /// `format` 인수는 역 추적이 인쇄되는 스타일을 제어하고 `print_path` 인수는 파일 이름의 `BytesOrWideString` 인스턴스를 인쇄하는 데 사용됩니다.
    /// 이 유형 자체는 파일 이름을 인쇄하지 않지만이를 수행하려면이 콜백이 필요합니다.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// 인쇄 될 역 추적에 대한 프리앰블을 인쇄합니다.
    ///
    /// 이것은 역 추적이 나중에 완전히 기호화되기 위해 일부 플랫폼에서 필요하며, 그렇지 않으면 `BacktraceFmt` 를 생성 한 후 호출하는 첫 번째 메서드 여야합니다.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// 역 추적 출력에 프레임을 추가합니다.
    ///
    /// 이 커밋은 실제로 프레임을 인쇄하는 데 사용할 수있는 `BacktraceFrameFmt` 의 RAII 인스턴스를 반환하며, 파괴시 프레임 카운터를 증가시킵니다.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// 역 추적 출력을 완료합니다.
    ///
    /// 이것은 현재 작동하지 않지만 역 추적 형식과의 future 호환성을 위해 추가되었습니다.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // 현재는이 hook 를 포함하여 future 추가를 허용합니다.
        Ok(())
    }
}

/// 역 추적의 한 프레임에 대한 포맷터입니다.
///
/// 이 유형은 `BacktraceFmt::frame` 함수에 의해 생성됩니다.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// 이 프레임 포맷터로 `BacktraceFrame` 를 인쇄합니다.
    ///
    /// 그러면 `BacktraceFrame` 내의 모든 `BacktraceSymbol` 인스턴스가 재귀 적으로 인쇄됩니다.
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` 내에서 `BacktraceSymbol` 를 인쇄합니다.
    ///
    /// # 필수 기능
    ///
    /// 이 기능을 사용하려면 `backtrace` crate 의 `std` 기능이 활성화되어 있어야하며 `std` 기능은 기본적으로 활성화되어 있습니다.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: 이것은 우리가 아무것도 인쇄하지 않는 것이 좋지 않습니다.
            // UTF8이 아닌 파일 이름으로.
            // 고맙게도 거의 모든 것이 utf8 이므로 너무 나쁘지는 않습니다.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// 일반적으로이 crate 의 원시 콜백 내에서 추적 된 원시 `Frame` 및 `Symbol` 를 인쇄합니다.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// 역 추적 출력에 원시 프레임을 추가합니다.
    ///
    /// 이 메서드는 이전과 달리 다른 위치에서 소스 인 경우 원시 인수를 사용합니다.
    /// 한 프레임에 대해 여러 번 호출 될 수 있습니다.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// 열 정보를 포함하여 역 추적 출력에 원시 프레임을 추가합니다.
    ///
    /// 이 메서드는 이전과 마찬가지로 다른 위치에서 소스 인 경우 원시 인수를 사용합니다.
    /// 한 프레임에 대해 여러 번 호출 될 수 있습니다.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia는 프로세스 내에서 상징화 할 수 없으므로 나중에 상징화하는 데 사용할 수있는 특별한 형식을 가지고 있습니다.
        // 여기에 자체 형식으로 주소를 인쇄하는 대신 인쇄하십시오.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" 프레임을 인쇄 할 필요가 없습니다. 기본적으로 시스템 역 추적이 매우 멀리 추적하기를 원한다는 것을 의미합니다.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx 엔 클레이브에서 TCB 크기를 줄이기 위해 심볼 확인 기능을 구현하고 싶지 않습니다.
        // 오히려 여기에 주소의 오프셋을 인쇄 할 수 있으며 나중에 올바른 기능에 매핑 할 수 있습니다.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // 프레임의 인덱스와 프레임의 선택적 명령어 포인터를 인쇄합니다.
        // 이 프레임의 첫 번째 기호를 벗어나면 적절한 공백 만 인쇄합니다.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // 다음으로 전체 역추적인 경우 추가 정보를 위해 대체 형식을 사용하여 기호 이름을 작성합니다.
        // 여기서는 이름이없는 기호도 처리합니다.
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // 마지막으로 가능한 경우 filename/line 번호를 인쇄하십시오.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line 기호 이름 아래의 줄에 인쇄되므로 적절한 공백을 인쇄하여 일종의 오른쪽 정렬합니다.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // 내부 콜백에 위임하여 파일 이름을 인쇄 한 다음 줄 번호를 인쇄합니다.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // 가능한 경우 열 번호를 추가하십시오.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // 우리는 프레임의 첫 번째 심볼에만 관심이 있습니다.
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}