use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr은 프로세스에 연결된 모든 DSO에 대해 dl_phdr_info 포인터를 수신하는 콜백을받습니다.
    // dl_iterate_phdr은 또한 반복의 시작부터 끝까지 동적 링커가 잠기도록합니다.
    // 콜백이 0이 아닌 값을 반환하면 반복이 일찍 종료됩니다.
    // 'data' 호출 할 때마다 콜백에 세 번째 인수로 전달됩니다.
    // 'size' dl_phdr_info의 크기를 제공합니다.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// 빌드 ID와 몇 가지 기본 프로그램 헤더 데이터를 파싱해야합니다. 즉, ELF 사양에서도 약간의 정보가 필요합니다.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// 이제 fuchsia의 현재 동적 링커에서 사용하는 dl_phdr_info 유형의 구조를 비트 단위로 복제해야합니다.
// Chromium에는이 ABI 경계와 크래시 패드도 있습니다.
// 결국 우리는 이러한 사례를 elf-search를 사용하도록 옮기고 싶지만 SDK에서 제공해야하고 아직 완료되지 않았습니다.
//
// 따라서 우리 (그리고 그들)는 자홍색 libc와 긴밀한 결합을 일으키는이 방법을 사용해야합니다.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // e_phoff와 e_phnum이 유효한지 확인할 방법이 없습니다.
    // libc는 우리를 위해 이것을 보장해야하므로 여기서 슬라이스를 형성하는 것이 안전합니다.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr은 대상 아키텍처의 엔디안에서 64 비트 ELF 프로그램 헤더를 나타냅니다.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr은 유효한 ELF 프로그램 헤더와 그 내용을 나타냅니다.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // p_addr 또는 p_memsz가 유효한지 확인할 방법이 없습니다.
    // Fuchsia의 libc는 먼저 노트를 구문 분석하므로 여기에 있으므로 이러한 헤더가 유효해야합니다.
    //
    // NoteIter는 기본 데이터가 유효 할 필요는 없지만 경계가 유효해야합니다.
    // 우리는 libc가 이것이 우리의 경우임을 확인했다고 믿습니다.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// 빌드 ID의 메모 유형입니다.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr은 대상 엔디안의 ELF 노트 헤더를 나타냅니다.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// 노트는 ELF 노트 (헤더 + 내용)를 나타냅니다.
// 이름은 항상 null로 끝나지 않고 rust 로 인해 바이트가 어느 쪽이든 일치하는지 쉽게 확인할 수 있기 때문에 u8 슬라이스로 남습니다.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter를 사용하면 메모 세그먼트를 안전하게 반복 할 수 있습니다.
// 오류가 발생하거나 더 이상 메모가없는 즉시 종료됩니다.
// 유효하지 않은 데이터를 반복하면 메모가없는 것처럼 작동합니다.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // 주어진 포인터와 크기가 모두 읽을 수있는 유효한 바이트 범위를 나타내는 것은 함수의 불변입니다.
    // 이 바이트의 내용은 무엇이든 될 수 있지만 안전하려면 범위가 유효해야합니다.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to는 'to' 가 2의 거듭 제곱이라고 가정하고 'x' 를 'to'바이트 정렬로 정렬합니다.
// 이것은 (x + to, 1)&-to 가 사용되는 C/C ++ ELF 구문 분석 코드의 표준 패턴을 따릅니다.
// Rust 는 사용을 부정하게하지 않기 때문에
// 2's-complement 변환을 재현합니다.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4는 슬라이스 (있는 경우)에서 num 바이트를 사용하고 추가로 최종 슬라이스가 적절하게 정렬되도록합니다.
// 요청 된 바이트 수가 너무 크거나 남아있는 바이트가 충분하지 않아 나중에 조각을 재정렬 할 수없는 경우 None이 반환되고 조각이 수정되지 않습니다.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// 이 함수에는 'bytes' 가 성능 (및 일부 아키텍처의 정확성)을 위해 정렬되어야한다는 것 외에 호출자가 유지해야하는 실제 불변이 없습니다.
// Elf_Nhdr 필드의 값은 말도 안되지만이 함수는 그런 것을 보장하지 않습니다.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // 이것은 충분한 공간이있는 한 안전하며 위의 if 문에서 이것이 안전하지 않아야 함을 확인했습니다.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // sice_of: :<Elf_Nhdr>()는 항상 4 바이트로 정렬됩니다.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // 우리가 끝에 도달했는지 확인하십시오.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // nhdr을 변환하지만 결과 구조체를 신중하게 고려합니다.
        // 우리는 namesz 또는 descsz를 신뢰하지 않으며 유형에 따라 안전하지 않은 결정을 내리지 않습니다.
        //
        // 그래서 우리가 완전한 쓰레기를 버려도 우리는 여전히 안전해야합니다.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// 세그먼트가 실행 가능함을 나타냅니다.
const PERM_X: u32 = 0b00000001;
/// 세그먼트가 쓰기 가능함을 나타냅니다.
const PERM_W: u32 = 0b00000010;
/// 세그먼트를 읽을 수 있음을 나타냅니다.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// 런타임시 ELF 세그먼트를 나타냅니다.
struct Segment {
    /// 이 세그먼트 내용의 런타임 가상 주소를 제공합니다.
    addr: usize,
    /// 이 세그먼트 내용의 메모리 크기를 제공합니다.
    size: usize,
    /// ELF 파일과 함께이 세그먼트의 모듈 가상 주소를 제공합니다.
    mod_rel_addr: usize,
    /// ELF 파일에서 찾은 권한을 제공합니다.
    /// 그러나 이러한 권한이 반드시 런타임에 존재하는 권한은 아닙니다.
    flags: Perm,
}

/// DSO에서 세그먼트를 반복 할 수 있습니다.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (동적 공유 객체)를 나타냅니다.
/// 이 유형은 자체 복사본을 만드는 대신 실제 DSO에 저장된 데이터를 참조합니다.
struct Dso<'a> {
    /// 동적 링커는 이름이 비어 있어도 항상 이름을 제공합니다.
    /// 주 실행 파일의 경우이 이름은 비어 있습니다.
    /// 공유 객체의 경우에는 soname이됩니다 (DT_SONAME 참조).
    name: &'a str,
    /// Fuchsia에서는 거의 모든 바이너리에 빌드 ID가 있지만 이것이 엄격한 요구 사항은 아닙니다.
    /// build_id가 없으면 나중에 DSO 정보를 실제 ELF 파일과 일치시킬 방법이 없으므로 모든 DSO가 여기에 있어야합니다.
    ///
    /// build_id가없는 DSO는 무시됩니다.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// 이 DSO의 세그먼트에 대한 반복자를 리턴합니다.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// 이러한 오류는 각 DSO에 대한 정보를 구문 분석하는 동안 발생하는 문제를 인코딩합니다.
///
enum Error {
    /// NameError는 C 스타일 문자열을 rust 문자열로 변환하는 동안 오류가 발생했음을 의미합니다.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError는 빌드 ID를 찾지 못했음을 의미합니다.
    /// 이는 DSO에 빌드 ID가 없거나 빌드 ID가 포함 된 세그먼트의 형식이 잘못 되었기 때문일 수 있습니다.
    ///
    BuildIDError,
}

/// 동적 링커에 의해 프로세스에 연결된 각 DSO에 대해 'dso' 또는 'error' 를 호출합니다.
///
///
/// # Arguments
///
/// * `visitor` - foreach DSO라는 eats 메서드 중 하나가있는 DsoPrinter입니다.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr은 info.name 가 유효한 위치를 가리 키도록합니다.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// 이 함수는 DSO에 포함 된 모든 정보에 대한 Fuchsia 심볼 라이저 마크 업을 인쇄합니다.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}