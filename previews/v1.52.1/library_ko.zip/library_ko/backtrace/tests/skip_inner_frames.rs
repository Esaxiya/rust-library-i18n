use backtrace::Backtrace;

// 이 테스트는 심볼의 시작 주소를보고하는 프레임에 대해 작동하는 `symbol_address` 기능이있는 플랫폼에서만 작동합니다.
// 결과적으로 일부 플랫폼에서만 활성화됩니다.
//
const ENABLED: bool = cfg!(all(
    // Windows 실제로 테스트되지 않았으며 OSX는 실제로 둘러싸는 프레임 찾기를 지원하지 않으므로이 기능을 비활성화하십시오.
    //
    target_os = "linux",
    // ARM에서 둘러싸는 함수를 찾는 것은 단순히 ip 자체를 반환하는 것입니다.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}