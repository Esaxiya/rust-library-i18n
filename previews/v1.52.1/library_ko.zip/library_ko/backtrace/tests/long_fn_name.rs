use backtrace::Backtrace;

// 50 자 모듈 이름
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50 자 구조체 이름
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// 긴 함수 이름은 (MAX_SYM_NAME, 1) 문자로 잘 려야합니다.
// gnu 는 모든 프레임에 대해 "<no info>" 를 인쇄하므로 msvc에 대해서만이 테스트를 실행하십시오.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 구조체 이름을 10 번 반복하므로 정규화 된 함수 이름은 10 *(50 + 50)* 2=2000 자 이상입니다.
    //
    // `::`, `<>` 및 현재 모듈의 이름도 포함되어 있기 때문에 실제로 더 깁니다.
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}