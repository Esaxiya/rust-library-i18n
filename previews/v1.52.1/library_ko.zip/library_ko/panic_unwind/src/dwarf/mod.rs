//! DWARF로 인코딩 된 데이터 스트림을 구문 분석하기위한 유틸리티입니다.
//! <http://www.dwarfstd.org>, DWARF-4 표준, 섹션 7, "Data Representation" 참조
//!

// 이 모듈은 현재 x86_64-pc-windows-gnu 에서만 사용되지만 회귀를 피하기 위해 모든 곳에서 컴파일하고 있습니다.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF 스트림은 압축되므로 예를 들어 u32 가 반드시 4 바이트 경계에 정렬되는 것은 아닙니다.
    // 이로 인해 정렬 요구 사항이 엄격한 플랫폼에서 문제가 발생할 수 있습니다.
    // "packed" 구조체에 데이터를 래핑하여 백엔드에 "misalignment-safe" 코드를 생성하도록 지시합니다.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 및 SLEB128 인코딩은 섹션 7.6, "Variable Length Data" 에 정의되어 있습니다.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}