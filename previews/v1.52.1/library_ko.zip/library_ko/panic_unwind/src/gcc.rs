//! libgcc/libunwind 가 지원하는 panics 구현 (일부 형태).
//!
//! 예외 처리 및 스택 해제에 대한 배경 정보는 "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) 및 링크 된 문서를 참조하십시오.
//! 이것들은 또한 좋은 읽기입니다.
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## 간략한 요약
//!
//! 예외 처리는 검색 단계와 정리 단계의 두 단계로 발생합니다.
//!
//! 두 단계 모두에서 언 와인 더는 현재 프로세스 모듈의 스택 프레임 언 와인드 섹션의 정보를 사용하여 스택 프레임을 위에서 아래로 이동합니다 (여기서 "module" 는 OS 모듈, 즉 실행 파일 또는 동적 라이브러리를 나타냄).
//!
//!
//! 각 스택 프레임에 대해 관련 "personality routine" 를 호출하며 해당 주소는 해제 정보 섹션에도 저장됩니다.
//!
//! 검색 단계에서 성격 루틴의 역할은 throw되는 예외 객체를 검사하고 해당 스택 프레임에서 포착되어야하는지 여부를 결정하는 것입니다.핸들러 프레임이 식별되면 정리 단계가 시작됩니다.
//!
//! 정리 단계에서 언 와인 더는 각 성격 루틴을 다시 호출합니다.
//! 이번에는 현재 스택 프레임에 대해 실행해야하는 정리 코드 (있는 경우)를 결정합니다.그렇다면 컨트롤은 함수 본문의 특수 branch, "landing pad" 로 전송되어 소멸자를 호출하고 메모리를 해제합니다.
//! 랜딩 패드의 끝에서 제어가 언 와인 더로 다시 전송되고 풀기가 다시 시작됩니다.
//!
//! 스택이 핸들러 프레임 레벨까지 풀리면 풀기 중지되고 마지막 성격 루틴이 제어를 catch 블록으로 전송합니다.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust 의 예외 클래스 식별자.
// 이는 퍼스낼리티 루틴에서 자체 런타임에서 예외가 발생했는지 여부를 판별하는 데 사용됩니다.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-공급 업체, 언어
    0x4d4f5a_00_52555354
}

// 레지스터 ID는 각 아키텍처에 대해 LLVM의 TargetLowering::getExceptionPointerRegister() 및 TargetLowering::getExceptionSelectorRegister() 에서 가져온 다음 레지스터 정의 테이블 (일반적으로)을 통해 DWARF 레지스터 번호에 매핑되었습니다.<arch>RegisterInfo.td, "DwarfRegNum" 검색).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register 도 참조하십시오.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// 다음 코드는 GCC 의 C 및 C++ 성격 루틴을 기반으로합니다.참고로 다음을 참조하십시오.
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI 성격 루틴.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS SjLj 해제를 사용하므로 대신 기본 루틴을 사용합니다.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM의 역 추적은 상태==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // 이 경우 스택을 계속 풀고 싶지 않으면 모든 역 추적이 __rust_try에서 끝납니다.
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF 언 와인 더는 _Unwind_Context가 함수 및 LSDA 포인터와 같은 것을 보유한다고 가정하지만 ARM EHABI는이를 예외 객체에 배치합니다.
            // 컨텍스트 포인터 만 사용하는 _Unwind_GetLanguageSpecificData() 와 같은 함수의 서명을 유지하기 위해 GCC 특성 루틴은 ARM의 "scratch register" (r12) 에 예약 된 위치를 사용하여 컨텍스트에서 exception_object에 대한 포인터를 숨 깁니다.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ...보다 원칙적인 접근 방식은 libunwind 바인딩에서 ARM의 _Unwind_Context에 대한 전체 정의를 제공하고 DWARF 호환성 함수를 우회하여 필요한 데이터를 직접 가져 오는 것입니다.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI는 예외 개체의 배리어 캐시에서 SP 값을 업데이트하기 위해 성격 루틴이 필요합니다.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI에서 성격 루틴은 반환하기 전에 실제로 단일 스택 프레임을 해제하는 역할을합니다 (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc에 정의 됨
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // 대부분의 대상에서 직접 사용되며 SEH를 통해 Windows x86_64 에서 간접적으로 사용되는 기본 성격 루틴.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW 대상에서 해제 메커니즘은 SEH이지만 해제 처리기 데이터 (일명 LSDA)는 GCC 호환 인코딩을 사용합니다.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // 대부분의 목표에 대한 성격 루틴.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // 반환 주소는 LSDA 범위 테이블의 다음 IP 범위에있을 수있는 호출 명령어를지나 1 바이트를 가리 킵니다.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// 프레임 풀기 정보 등록
//
// 각 모듈의 이미지에는 프레임 해제 정보 섹션 (일반적으로 ".eh_frame")이 포함되어 있습니다.모듈이 프로세스에 loaded/unloaded 인 경우 언 와인 더는 메모리에서이 섹션의 위치를 알려야합니다.이를 달성하는 방법은 플랫폼에 따라 다릅니다.
// 일부 (예: Linux)에서 언 와인 더는 자체적으로 언 와인 더 정보 섹션을 발견 할 수 있습니다 (dl_iterate_phdr() API and finding their ".eh_frame" sections) 를 통해 현재로드 된 모듈을 동적으로 열거함으로써; Windows 와 같은 다른 것들은 모듈이 언 와인 더 API를 통해 해제 정보 섹션을 적극적으로 등록하도록 요구합니다.
//
//
// 이 모듈은 GCC 런타임에 정보를 등록하기 위해 rsbegin.rs 에서 참조 및 호출되는 두 개의 기호를 정의합니다.
// 스택 해제의 구현은 (현재로서는) libgcc_eh로 연기되지만 Rust crates 는 GCC 런타임과의 잠재적 충돌을 피하기 위해 이러한 Rust 특정 진입 점을 사용합니다.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}