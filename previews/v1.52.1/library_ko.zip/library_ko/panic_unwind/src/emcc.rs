//! *emscripten* 대상에 대한 해제 중입니다.
//!
//! Unix 플랫폼에 대한 Rust 의 일반적인 해제 구현은 libunwind API를 직접 호출하지만 Emscripten에서는 대신 C++ 해제 API를 호출합니다.
//! Emscripten의 런타임은 항상 이러한 API를 구현하고 libunwind를 구현하지 않기 때문에 이것은 단지 편의입니다.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// 이것은 C++ 의 std::type_info 레이아웃과 일치합니다.
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // 여기서 선행 `\x01` 바이트는 실제로 `_` 문자 접두어와 같은 다른 맹 글링을 적용하지 *않도록* LLVM에 보내는 마법 신호입니다.
    //
    //
    // 이 기호는 C++ 의 `std::type_info` 에서 사용하는 vtable입니다.
    // 형식 설명자인 `std::type_info` 형식의 개체에는이 테이블에 대한 포인터가 있습니다.
    // 유형 설명자는 위에서 정의한 C++ EH 구조에 의해 참조되며 아래에서 구성합니다.
    //
    // 실제 크기는 3 usize보다 크지 만 세 번째 요소를 가리키는 vtable 만 필요합니다.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info rust_panic 클래스의 경우
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // 일반적으로 .as_ptr().add(2) 를 사용하지만 const 컨텍스트에서는 작동하지 않습니다.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // C ++가 Rust panics 를 생성하거나 잡을 수 없도록하기 때문에 의도적으로 정상적인 이름 맹 글링 체계를 사용하지 않습니다.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // 이것은 C++ 코드가 std::exception_ptr 로 실행을 캡처하고 다른 스레드에서도 여러 번 다시 던질 수 있기 때문에 필요합니다.
    //
    //
    caught: AtomicBool,

    // 이것은 객체의 수명이 C++ 의미 체계를 따르기 때문에 Option이어야합니다. catch_unwind가 Box를 예외 밖으로 이동할 때 해당 소멸자가 __cxa_end_catch에 의해 여전히 호출 될 것이기 때문에 예외 객체를 유효한 상태로 남겨 두어야합니다.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try 실제로이 구조에 대한 포인터를 제공합니다.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() 는 panic 에 허용되지 않으므로 대신 중단합니다.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}