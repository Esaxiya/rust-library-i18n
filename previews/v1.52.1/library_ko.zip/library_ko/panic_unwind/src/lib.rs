//! 스택 해제를 통한 panics 구현
//!
//! 이 crate 는 이것이 컴파일되는 플랫폼의 "most native" 스택 해제 메커니즘을 사용하여 Rust 의 panics 구현입니다.
//! 이것은 본질적으로 현재 세 가지 버킷으로 분류됩니다.
//!
//! 1. MSVC 대상은 `seh.rs` 파일에서 SEH를 사용합니다.
//! 2. Emscripten은 `emcc.rs` 파일에서 C++ 예외를 사용합니다.
//! 3. 다른 모든 대상은 `gcc.rs` 파일에서 libunwind/libgcc 를 사용합니다.
//!
//! 각 구현에 대한 자세한 문서는 각 모듈에서 찾을 수 있습니다.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` Miri와 함께 사용되지 않으므로 경고를 음소거합니다.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust 런타임의 시작 개체는 이러한 기호에 따라 달라 지므로이를 공개합니다.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // 풀기를 지원하지 않는 대상.
        // - arch=wasm32
        // - os=none ("bare metal" 대상)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Miri 런타임을 사용하십시오.
        // rustc 는 거기에서 특정 lang 항목이 정의 될 것으로 예상하므로 위의 일반 런타임도로드해야합니다.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // 실제 런타임을 사용하십시오.
        use real_imp as imp;
    }
}

extern "C" {
    /// libstd의 핸들러는 panic 객체가 `catch_unwind` 외부로 떨어질 때 호출됩니다.
    ///
    fn __rust_drop_panic() -> !;

    /// 외부 예외가 발견되면 libstd의 핸들러가 호출됩니다.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// 예외 발생을위한 진입 점으로 플랫폼 별 구현에 위임합니다.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}