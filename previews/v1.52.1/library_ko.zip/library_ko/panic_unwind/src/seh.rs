//! Windows SEH
//!
//! Windows (현재 MSVC에서만)에서 기본 예외 처리 메커니즘은 구조적 예외 처리 (SEH) 입니다.
//! 이것은 컴파일러 내부 측면에서 Dwarf 기반 예외 처리 (예: 다른 unix 플랫폼에서 사용하는 것)와는 상당히 다르므로 LLVM은 SEH에 대한 많은 추가 지원을 필요로합니다.
//!
//! 간단히 말해서 여기서 일어나는 일은 다음과 같습니다.
//!
//! 1. `panic` 함수는 표준 Windows 함수 `_CxxThrowException` 를 호출하여 C++ 와 유사한 예외를 발생시켜 풀기 프로세스를 트리거합니다.
//! 2.
//! 컴파일러에 의해 생성 된 모든 랜딩 패드는 CRT의 함수 인 특성 함수 `__CxxFrameHandler3` 를 사용하고 Windows 의 해제 코드는이 특성 함수를 사용하여 스택의 모든 정리 코드를 실행합니다.
//!
//! 3. `invoke` 에 대한 모든 컴파일러 생성 호출에는 정리 루틴의 시작을 나타내는 `cleanuppad` LLVM 명령어로 설정된 랜딩 패드가 있습니다.
//! 성격 (CRT에 정의 된 2 단계)은 정리 루틴 실행을 담당합니다.
//! 4. 결국 `try` 내장 (컴파일러에 의해 생성됨)의 "catch" 코드가 실행되고 제어가 Rust 로 돌아와야 함을 나타냅니다.
//! 이것은 LLVM IR 용어로 `catchswitch` 와 `catchpad` 명령을 통해 수행되며, 최종적으로 `catchret` 명령을 사용하여 프로그램에 일반 제어를 반환합니다.
//!
//! gcc 기반 예외 처리와의 몇 가지 구체적인 차이점은 다음과 같습니다.
//!
//! * Rust 에는 사용자 지정 성격 기능이 없으며 대신 *항상*`__CxxFrameHandler3` 입니다.또한 추가 필터링이 수행되지 않으므로 우리가 던지는 종류와 유사한 C++ 예외를 포착하게됩니다.
//! Rust 에 예외를 던지는 것은 어쨌든 정의되지 않은 동작이므로 괜찮을 것입니다.
//! * 풀기 경계, 특히 `Box<dyn Any + Send>` 를 통해 전송할 데이터가 있습니다.Dwarf 예외와 마찬가지로이 두 포인터는 예외 자체에 페이로드로 저장됩니다.
//! 그러나 MSVC에서는 필터 함수가 실행되는 동안 호출 스택이 보존되기 때문에 추가 힙 할당이 필요하지 않습니다.
//! 즉, 포인터가 `_CxxThrowException` 로 직접 전달 된 다음 필터 함수에서 복구되어 `try` 내장 함수의 스택 프레임에 기록됩니다.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // 참조로 예외를 포착하고 그 소멸자가 C++ 런타임에 의해 실행되기 때문에 이것은 Option이어야합니다.
    // Box를 예외에서 제거 할 때 해당 소멸자가 Box를 두 번 드롭하지 않고 실행되도록 예외를 유효한 상태로 두어야합니다.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// 먼저, 전체 유형 정의입니다.여기에는 몇 가지 플랫폼 별 이상한 점이 있으며 LLVM에서 뻔뻔스럽게 복사 한 것들이 많습니다.이 모든 목적은 `_CxxThrowException` 호출을 통해 아래의 `panic` 기능을 구현하는 것입니다.
//
// 이 함수는 두 개의 인수를 사용합니다.첫 번째는 우리가 전달하는 데이터에 대한 포인터이며,이 경우에는 trait 객체입니다.쉽게 찾을 수 있습니다!그러나 다음은 더 복잡합니다.
// 이것은 `_ThrowInfo` 구조에 대한 포인터이며 일반적으로 throw되는 예외를 설명하기위한 것입니다.
//
// 현재이 유형의 [1] 의 정의는 다소 모호하며, 주요 이상한 점 (온라인 기사와의 차이점)은 32 비트에서는 포인터가 포인터이지만 64 비트에서는 포인터가 32 비트 오프셋으로 표현된다는 것입니다. `__ImageBase` 기호.
//
// 아래 모듈의 `ptr_t` 및 `ptr!` 매크로는이를 표현하는 데 사용됩니다.
//
// 유형 정의의 미로는 이러한 종류의 작업을 위해 LLVM이 방출하는 것을 거의 따릅니다.예를 들어, MSVC에서이 C++ 코드를 컴파일하고 LLVM IR을 내보내는 경우 :
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      무효 foo() { rust_panic a = {0, 1};
//          던지다;}
//
// 그것이 본질적으로 우리가 모방하려는 것입니다.아래의 대부분의 상수 값은 LLVM에서 복사 한 것입니다.
//
// 어쨌든 이러한 구조는 모두 비슷한 방식으로 구성되어 있으며 우리에게는 다소 장황합니다.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// 여기서는 의도적으로 이름 맹 글링 규칙을 무시합니다. C++ 가 단순히 `struct rust_panic` 를 선언하여 Rust panics 를 포착 할 수있는 것을 원하지 않습니다.
//
//
// 수정할 때 유형 이름 문자열이 `compiler/rustc_codegen_llvm/src/intrinsic.rs` 에서 사용 된 문자열과 정확히 일치하는지 확인하십시오.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // 여기서 선행 `\x01` 바이트는 실제로 `_` 문자 접두어와 같은 다른 맹 글링을 적용하지 *않도록* LLVM에 보내는 마법 신호입니다.
    //
    //
    // 이 기호는 C++ 의 `std::type_info` 에서 사용하는 vtable입니다.
    // 형식 설명자인 `std::type_info` 형식의 개체에는이 테이블에 대한 포인터가 있습니다.
    // 유형 설명자는 위에서 정의한 C++ EH 구조에 의해 참조되며 아래에서 구성합니다.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// 이 유형 설명자는 예외를 던질 때만 사용됩니다.
// catch 부분은 자체 TypeDescriptor를 생성하는 try 내장 함수에 의해 처리됩니다.
//
// MSVC 런타임은 형식 이름에 대한 문자열 비교를 사용하여 포인터 같음이 아닌 TypeDescriptors를 일치시키기 때문에 괜찮습니다.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// C ++ 코드가 예외를 캡처하고 전파하지 않고 삭제하기로 결정한 경우 사용되는 소멸자입니다.
// try 내장 함수의 catch 부분은 예외 객체의 첫 번째 단어를 0으로 설정하여 소멸자가 건너 뛰도록합니다.
//
// x86 Windows 는 기본 "C" 호출 규칙 대신 C++ 멤버 함수에 "thiscall" 호출 규칙을 사용합니다.
//
// 여기서 exception_copy 함수는 약간 특별합니다. try/catch 블록 아래에서 MSVC 런타임에 의해 호출되며 여기서 생성 한 panic 는 예외 복사의 결과로 사용됩니다.
//
// 이것은 C++ 런타임에서 std::exception_ptr 로 예외 캡처를 지원하는 데 사용됩니다. Box<dyn Any>복제 할 수 없습니다.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException은이 스택 프레임에서 완전히 실행되므로 `data` 를 힙으로 전송할 필요가 없습니다.
    // 이 함수에 스택 포인터를 전달합니다.
    //
    // 해제 할 때 Exception이 삭제되는 것을 원하지 않기 때문에 여기서는 ManualDrop이 필요합니다.
    // 대신 C++ 런타임에 의해 호출되는 exception_cleanup에 의해 삭제됩니다.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // 이건 ... 놀랍게 보일 수도 있고, 정당하게도 그렇습니다.32 비트 MSVC에서 이러한 구조 사이의 포인터는 포인터입니다.
    // 그러나 64 비트 MSVC에서는 구조 간의 포인터가 `__ImageBase` 의 32 비트 오프셋으로 표시됩니다.
    //
    // 따라서 32 비트 MSVC에서는 위의 'static'에서 이러한 모든 포인터를 선언 할 수 있습니다.
    // 64 비트 MSVC에서는 Rust 가 현재 허용하지 않는 정적 포인터의 빼기를 표현해야하므로 실제로 그렇게 할 수 없습니다.
    //
    // 차선책은 런타임에 이러한 구조를 채우는 것입니다 (패닉은 이미 "slow path" 입니다).
    // 따라서 여기에서는 이러한 모든 포인터 필드를 32 비트 정수로 재 해석 한 다음 관련 값을 여기에 저장합니다 (원자 적으로 panics 가 발생할 수 있으므로).
    //
    // 기술적으로 런타임은 아마도 이러한 필드의 비원 자적 읽기를 수행하지만 이론적으로는 *잘못된* 값을 읽지 않으므로 너무 나쁘지 않아야합니다.
    //
    // 어쨌든, 우리는 기본적으로 더 많은 연산을 통계로 표현할 수있을 때까지 이와 같은 작업을해야합니다.
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // 여기서 NULL 페이로드는 __rust_try의 (...) catch에서 여기에 왔음을 의미합니다.
    // 이것은 Rust 가 아닌 외부 예외가 발견 될 때 발생합니다.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// 이것은 컴파일러가 존재하는 데 필요합니다 (예: lang 항목). 그러나 __C_specific_handler 또는 _except_handler3가 항상 사용되는 성격 함수이기 때문에 실제로 컴파일러에 의해 호출되지 않습니다.
//
// 따라서 이것은 중단하는 스텁 일뿐입니다.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}