//! Miri 용 panics 풀기.
use alloc::boxed::Box;
use core::any::Any;

// Miri 엔진이 풀기를 통해 전파하는 페이로드의 유형입니다.
// 포인터 크기 여야합니다.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// 풀기 시작하기 위해 미리 제공하는 extern 기능.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic` 에 전달하는 페이로드는 아래의 `cleanup` 에서 얻는 인수와 정확히 일치합니다.
    // 그래서 우리는 포인터 크기를 얻기 위해 한 번만 상자에 넣습니다.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // 기본 `Box` 를 복구합니다.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}