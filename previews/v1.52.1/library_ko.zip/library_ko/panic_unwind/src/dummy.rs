//! *wasm32* 대상에 대한 해제 중입니다.
//!
//! 지금은이를 지원하지 않으므로 이것은 단지 스텁 일뿐입니다.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}