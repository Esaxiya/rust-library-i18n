//! 프로세스 중단을 통한 Rust panics 구현
//!
//! 해제를 통한 구현과 비교할 때이 crate 는 *훨씬* 더 간단합니다!즉, 다재다능하지는 않지만 여기에 있습니다!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" 문제의 플랫폼에서 관련 중단에 대한 페이로드 및 심.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal 에 전화
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows 에서는 프로세서 별 __fastfail 메커니즘을 사용합니다.Windows 8 이상에서는 프로세스 내 예외 처리기를 실행하지 않고 즉시 프로세스를 종료합니다.
            // 이전 버전의 Windows 에서이 명령 시퀀스는 액세스 위반으로 처리되어 프로세스를 종료하지만 반드시 모든 예외 처리기를 우회하지는 않습니다.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: 이것은 libstd의 `abort_internal` 에서와 동일한 구현입니다.
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// 이건 ... 좀 이상해.tl; dr;이것은 올바르게 링크하는 데 필요하다는 것입니다. 더 긴 설명은 아래에 있습니다.
//
// 현재 우리가 제공하는 libcore/libstd 바이너리는 모두 `-C panic=unwind` 로 컴파일됩니다.이는 바이너리가 가능한 한 많은 상황과 최대한 호환되도록하기 위해 수행됩니다.
// 그러나 컴파일러에는 `-C panic=unwind` 로 컴파일 된 모든 함수에 대해 "personality function" 가 필요합니다.이 특성 함수는 기호 `rust_eh_personality` 로 하드 코딩되며 `eh_personality` lang 항목으로 정의됩니다.
//
// So...
// 여기서 lang 항목을 정의하지 않는 이유는 무엇입니까?좋은 질문!panic 런타임이 연결되는 방식은 실제로 컴파일러의 crate 저장소에서 "sort of" 라는 점에서 약간 미묘하지만 실제로 다른 것이 실제로 연결되지 않은 경우에만 연결됩니다.
//
// 이는 결국이 crate 와 panic_unwind crate 가 컴파일러의 crate 저장소에 나타날 수 있으며 둘 다 `eh_personality` lang 항목을 정의하면 오류가 발생한다는 것을 의미합니다.
//
// 이를 처리하기 위해 컴파일러는 링크되는 panic 런타임이 해제 런타임 인 경우에만 `eh_personality` 가 정의되어야하며 그렇지 않은 경우 정의 할 필요가 없습니다 (정확히 그렇습니다).
// 그러나이 경우이 라이브러리는이 기호를 정의하기 만하면 어딘가에 최소한의 성격이 있습니다.
//
// 기본적으로이 기호는 libcore/libstd 바이너리에 연결되도록 정의되었지만 해제되는 런타임에서 전혀 링크하지 않으므로 호출해서는 안됩니다.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // x86_64-pc-windows-gnu 에서는 모든 프레임을 전달할 때 `ExceptionContinueSearch` 를 반환해야하는 고유 한 성격 함수를 사용합니다.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // 위와 유사하게 현재 Emscripten에서만 사용되는 `eh_catch_typeinfo` lang 항목에 해당합니다.
    //
    // panics 는 예외를 생성하지 않고 외부 예외는 현재 -C panic=abort (변경 될 수 있음)와 함께 UB이므로 catch_unwind 호출은이 typeinfo를 사용하지 않습니다.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // 이 두 가지는 i686-pc-windows-gnu 의 시작 개체에 의해 호출되지만 아무것도 할 필요가 없으므로 본문이 nops입니다.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}