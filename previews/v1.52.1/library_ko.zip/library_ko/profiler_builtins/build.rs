//! `compiler-rt` 라이브러리의 프로파일 러 부분을 컴파일합니다.
//!
//! 자세한 내용은 libcompiler_builtins crate 에 대한 build.rs 를 참조하십시오.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` 지시문은 현재 생성되지 않으며 빌드 스크립트
    // 이러한 소스 파일 또는 여기에 포함 된 헤더의 변경 사항에 대해 다시 실행되지 않습니다.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // 이 파일은 LLVM 10에서 이름이 변경되었습니다.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // 이 파일은 LLVM 11에 추가되었습니다.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC에서 추가 라이브러리를 가져 오지 마십시오.
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc 등의 다양한 기능을 끄십시오. 대부분은 이미 compiler-rt의 빌드 시스템을 복사합니다.
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // 우리가 이것을 구축하는 유닉스에서 fnctl() 를 사용할 수 있다고 가정합니다.
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // 이것은 COMPILER_RT_HAS_ATOMICS를 설정할 때 꽤 좋은 휴리스틱이어야합니다.
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // 실행하려는 경우 이것이 존재해야합니다 (그렇지 않으면 프로파일 러 내장 기능을 전혀 빌드하지 않습니다).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}