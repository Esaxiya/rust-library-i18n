#![feature(no_core)]
#![no_core]

// 이 crate 가 필요한 이유는 rustc-std-workspace-core를 참조하십시오.

// liballoc의 alloc 모듈과 충돌하지 않도록 crate 의 이름을 변경하십시오.
extern crate alloc as foo;

pub use foo::*;