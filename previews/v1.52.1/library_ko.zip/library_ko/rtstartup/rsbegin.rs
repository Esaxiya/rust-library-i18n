// rsbegin.o rsend.o 는 소위 "compiler runtime startup objects" 입니다.
// 컴파일러 런타임을 올바르게 초기화하는 데 필요한 코드가 포함되어 있습니다.
//
// 실행 파일 또는 dylib 이미지가 링크되면 모든 사용자 코드와 라이브러리는이 두 개체 파일 사이에서 "sandwiched" 이므로 rsbegin.o 의 코드 또는 데이터는 이미지의 각 섹션에서 첫 번째가되고 rsend.o 의 코드와 데이터는 마지막 항목이됩니다.
// 이 효과는 섹션의 시작 또는 끝에 기호를 배치하고 필요한 머리글 또는 바닥 글을 삽입하는 데 사용할 수 있습니다.
//
// 실제 모듈 진입 점은 C 런타임 시작 개체 (일반적으로 `crtX.o` 라고 함)에 있으며,이 개체는 다른 런타임 구성 요소의 초기화 콜백을 호출합니다 (또 다른 특수 이미지 섹션을 통해 등록됨).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // 스택 프레임 해제 정보 섹션의 시작을 표시합니다.
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // 언 와인 더의 내부 장부를위한 스크래치 공간.
    // 이것은 $ GCC/unwind-dw2-fde.h에서 `struct object` 로 정의됩니다.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // 정보 registration/deregistration 루틴을 해제합니다.
    // libpanic_unwind의 문서를 참조하십시오.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // 모듈 시작시 해제 정보 등록
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // 종료시 등록 취소
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW 특정 init/uninit 루틴 등록
    pub mod mingw_init {
        // MinGW의 시작 개체 (crt0.o/dllcrt0.o)는 시작 및 종료시 .ctors 및 .dtors 섹션에서 전역 생성자를 호출합니다.
        // DLL의 경우 DLL이로드되고 언로드 될 때이 작업이 수행됩니다.
        //
        // 링커는 섹션을 정렬하여 콜백이 목록 끝에 있는지 확인합니다.
        // 생성자는 역순으로 실행되므로 콜백이 실행되는 첫 번째 및 마지막 콜백이됩니다.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C 초기화 콜백
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C 종료 콜백
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}