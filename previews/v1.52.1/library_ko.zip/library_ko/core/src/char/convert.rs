//! 문자 변환.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` 를 `char` 로 변환합니다.
///
/// 모든 [`char`]은 유효한 [`u32`]이며 다음을 사용하여 하나로 캐스팅 할 수 있습니다.
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// 그러나 그 반대는 사실이 아닙니다. 모든 유효한 [`u32`]가 유효한 [`char`] 인 것은 아닙니다.
/// `from_u32()` 입력이 [`char`] 에 대해 유효한 값이 아닌 경우 `None` 를 반환합니다.
///
/// 이러한 검사를 무시하는이 함수의 안전하지 않은 버전은 [`from_u32_unchecked`] 를 참조하십시오.
///
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// 입력이 유효한 [`char`] 가 아닐 때 `None` 반환 :
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// 유효성을 무시하고 `u32` 를 `char` 로 변환합니다.
///
/// 모든 [`char`]은 유효한 [`u32`]이며 다음을 사용하여 하나로 캐스팅 할 수 있습니다.
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// 그러나 그 반대는 사실이 아닙니다. 모든 유효한 [`u32`]가 유효한 [`char`] 인 것은 아닙니다.
/// `from_u32_unchecked()` 이것을 무시하고 맹목적으로 [`char`] 로 캐스팅하여 유효하지 않은 것을 생성합니다.
///
///
/// # Safety
///
/// 이 함수는 잘못된 `char` 값을 생성 할 수 있으므로 안전하지 않습니다.
///
/// 이 기능의 안전한 버전은 [`from_u32`] 기능을 참조하십시오.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // 안전: 호출자는 `i` 가 유효한 char 값임을 보장해야합니다.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] 를 [`u32`] 로 변환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] 를 [`u64`] 로 변환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // 문자는 코드 포인트의 값으로 캐스트 된 다음 64 비트로 0 확장됩니다.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] 참조
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] 를 [`u128`] 로 변환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // 문자는 코드 포인트의 값으로 캐스팅 된 다음 128 비트로 0 확장됩니다.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] 참조
        c as u128
    }
}

/// 0x00 ..=0xFF의 바이트를 코드 포인트가 U + 0000 ..=U + 00FF에서 동일한 값을 갖는 `char` 로 매핑합니다.
///
/// 유니 코드는 IANA가 ISO-8859-1이라고 부르는 문자 인코딩으로 바이트를 효과적으로 디코딩하도록 설계되었습니다.
/// 이 인코딩은 ASCII와 호환됩니다.
///
/// 이것은 일명 ISO/IEC 8859-1과 다릅니다.
/// ISO 8859-1 (하이픈이 하나 적음)은 문자에 할당되지 않은 일부 "blanks" 바이트 값을 남깁니다.
/// ISO-8859-1 (IAA)은이를 C0 및 C1 제어 코드에 할당합니다.
///
/// 이것은 Windows-1252 aka와 *또한* 다릅니다.
/// 코드 페이지 1252는 문장 부호와 다양한 라틴 문자에 일부 (전부는 아님) 공백을 할당하는 수퍼 세트 ISO/IEC 8859-1입니다.
///
/// 더 혼동하기 위해 [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` 및 `windows-1252` 는 모두 해당 C0 및 C1 제어 코드로 나머지 공백을 채우는 Windows-1252 상위 집합의 별칭입니다.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] 를 [`char`] 로 변환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// 문자를 구문 분석 할 때 반환 될 수있는 오류입니다.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // 안전: 유효한 유니 코드 값인지 확인했습니다.
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 에서 char 로의 변환이 실패 할 때 반환되는 오류 유형입니다.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// 주어진 기수의 숫자를 `char` 로 변환합니다.
///
/// 여기서 'radix' 는 때때로 'base' 라고도합니다.
/// 기수 2는 이진수, 기수 10, 십진수, 기수 16, 16 진수를 나타내며 일부 공통 값을 제공합니다.
///
/// 임의의 기수가 지원됩니다.
///
/// `from_digit()` 입력이 주어진 기수의 숫자가 아니면 `None` 를 반환합니다.
///
/// # Panics
///
/// 기수가 36보다 큰 경우 Panics 입니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // 10 진수 11은 16 진법의 단일 숫자입니다.
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// 입력이 숫자가 아닌 경우 `None` 반환 :
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// 큰 기수를 전달하여 panic :
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}