//! impl 문자 {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` 가 가질 수있는 가장 높은 유효한 코드 포인트.
    ///
    /// `char` 는 [Unicode Scalar Value] 입니다. 즉, [Code Point] 이지만 특정 범위 내에있는 것입니다.
    /// `MAX` 유효한 [Unicode Scalar Value] 인 가장 높은 유효 코드 포인트입니다.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () 는 유니 코드에서 디코딩 오류를 나타내는 데 사용됩니다.
    ///
    /// 예를 들어, 잘못된 형식의 UTF-8 바이트를 [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) 에 제공 할 때 발생할 수 있습니다.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` 및 `str` 메서드의 유니 코드 부분이 기반으로하는 [Unicode](http://www.unicode.org/) 버전입니다.
    ///
    /// 새 버전의 유니 코드가 정기적으로 릴리스되고 이후 유니 코드에 따라 표준 라이브러리의 모든 메서드가 업데이트됩니다.
    /// 따라서 일부 `char` 및 `str` 메서드의 동작과이 상수 값은 시간이 지남에 따라 변경됩니다.
    /// 이는 주요 변경 사항으로 간주되지 *않습니다*.
    ///
    /// 버전 번호 지정 체계는 [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) 에 설명되어 있습니다.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` 에서 UTF-16 로 인코딩 된 코드 포인트에 대해 반복기를 만들고 쌍을 이루지 않은 서로 게이트를`Err`로 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// 손실 디코더는 `Err` 결과를 대체 문자로 대체하여 얻을 수 있습니다.
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` 를 `char` 로 변환합니다.
    ///
    /// 모든`char`는 유효한 [`u32`]이며 다음을 사용하여 하나로 캐스팅 할 수 있습니다.
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// 그러나 그 반대는 사실이 아닙니다. 유효한 모든 [`u32`]가 유효한`char`는 아닙니다.
    /// `from_u32()` 입력이 `char` 에 대해 유효한 값이 아닌 경우 `None` 를 반환합니다.
    ///
    /// 이러한 검사를 무시하는이 함수의 안전하지 않은 버전은 [`from_u32_unchecked`] 를 참조하십시오.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// 입력이 유효한 `char` 가 아닐 때 `None` 반환 :
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// 유효성을 무시하고 `u32` 를 `char` 로 변환합니다.
    ///
    /// 모든`char`는 유효한 [`u32`]이며 다음을 사용하여 하나로 캐스팅 할 수 있습니다.
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// 그러나 그 반대는 사실이 아닙니다. 유효한 모든 [`u32`]가 유효한`char`는 아닙니다.
    /// `from_u32_unchecked()` 이것을 무시하고 맹목적으로 `char` 로 캐스팅하여 유효하지 않은 것을 생성합니다.
    ///
    ///
    /// # Safety
    ///
    /// 이 함수는 잘못된 `char` 값을 생성 할 수 있으므로 안전하지 않습니다.
    ///
    /// 이 기능의 안전한 버전은 [`from_u32`] 기능을 참조하십시오.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // 안전: 발신자가 안전 계약을 유지해야합니다.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// 주어진 기수의 숫자를 `char` 로 변환합니다.
    ///
    /// 여기서 'radix' 는 때때로 'base' 라고도합니다.
    /// 기수 2는 이진수, 기수 10, 십진수, 기수 16, 16 진수를 나타내며 일부 공통 값을 제공합니다.
    ///
    /// 임의의 기수가 지원됩니다.
    ///
    /// `from_digit()` 입력이 주어진 기수의 숫자가 아니면 `None` 를 반환합니다.
    ///
    /// # Panics
    ///
    /// 기수가 36보다 큰 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 10 진수 11은 16 진법의 단일 숫자입니다.
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// 입력이 숫자가 아닌 경우 `None` 반환 :
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// 큰 기수를 전달하여 panic :
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` 가 주어진 기수의 숫자인지 확인합니다.
    ///
    /// 여기서 'radix' 는 때때로 'base' 라고도합니다.
    /// 기수 2는 이진수, 기수 10, 십진수, 기수 16, 16 진수를 나타내며 일부 공통 값을 제공합니다.
    ///
    /// 임의의 기수가 지원됩니다.
    ///
    /// [`is_numeric()`] 와 비교할 때이 기능은 `0-9`, `a-z` 및 `A-Z` 문자 만 인식합니다.
    ///
    /// 'Digit' 다음 문자로만 정의됩니다.
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' 에 대한보다 포괄적 인 이해는 [`is_numeric()`] 를 참조하십시오.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 기수가 36보다 큰 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// 큰 기수를 전달하여 panic :
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` 를 주어진 기수의 숫자로 변환합니다.
    ///
    /// 여기서 'radix' 는 때때로 'base' 라고도합니다.
    /// 기수 2는 이진수, 기수 10, 십진수, 기수 16, 16 진수를 나타내며 일부 공통 값을 제공합니다.
    ///
    /// 임의의 기수가 지원됩니다.
    ///
    /// 'Digit' 다음 문자로만 정의됩니다.
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `char` 가 주어진 기수의 숫자를 참조하지 않으면 `None` 를 반환합니다.
    ///
    /// # Panics
    ///
    /// 기수가 36보다 큰 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// 숫자가 아닌 값을 전달하면 실패합니다.
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// 큰 기수를 전달하여 panic :
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` 가 일정하고 10 이하인 경우 실행 속도를 향상시키기 위해 코드가 분할됩니다.
        //
        let val = if likely(radix <= 10) {
            // 숫자가 아니면 기수보다 큰 숫자가 생성됩니다.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// 문자의 16 진수 유니 코드 이스케이프를`char`로 생성하는 반복자를 반환합니다.
    ///
    /// 이것은 `\u{NNNNNN}` 형식의 Rust 구문으로 문자를 이스케이프합니다. 여기서 `NNNNNN` 는 16 진수 표현입니다.
    ///
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1은 c==0에 대해 코드가 한 자리가 인쇄되어야한다고 계산하고 (동일 함)(31, 32) 언더 플로를 방지합니다.
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // 최상위 16 진수의 인덱스
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Extended Grapheme 코드 포인트 이스케이프를 선택적으로 허용하는 `escape_debug` 의 확장 버전입니다.
    /// 이를 통해 공백이없는 표시와 같은 문자가 문자열의 시작 부분에있을 때 더 나은 형식을 지정할 수 있습니다.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// 문자의 리터럴 이스케이프 코드를 'char'로 생성하는 반복자를 반환합니다.
    ///
    /// 이것은 `str` 또는 `char` 의 `Debug` 구현과 유사한 문자를 이스케이프합니다.
    ///
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// 문자의 리터럴 이스케이프 코드를 'char'로 생성하는 반복자를 반환합니다.
    ///
    /// 기본값은 C++ 11 및 유사한 C 계열 언어를 포함하여 다양한 언어에서 합법적 인 리터럴을 생성하는 편향으로 선택됩니다.
    /// 정확한 규칙은 다음과 같습니다.
    ///
    /// * 탭은 `\t` 로 이스케이프됩니다.
    /// * 캐리지 리턴은 `\r` 로 이스케이프됩니다.
    /// * 줄 바꿈은 `\n` 로 이스케이프됩니다.
    /// * 작은 따옴표는 `\'` 로 이스케이프됩니다.
    /// * 큰 따옴표는 `\"` 로 이스케이프됩니다.
    /// * 백 슬래시는 `\\` 로 이스케이프됩니다.
    /// * '인쇄 가능한 ASCII'범위 `0x20` .. `0x7e` 포함의 모든 문자는 이스케이프되지 않습니다.
    /// * 다른 모든 문자에는 16 진 유니 코드 이스케이프가 제공됩니다.[`escape_unicode`] 를 참조하십시오.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 로 인코딩 된 경우이 `char` 에 필요한 바이트 수를 반환합니다.
    ///
    /// 이 바이트 수는 항상 1과 4 사이입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` 유형은 해당 내용이 UTF-8 임을 보장하므로 각 코드 포인트가 `char` 로 표현 된 경우와 `&str` 자체에서 표시되는 경우 걸리는 길이를 비교할 수 있습니다.
    ///
    ///
    /// ```
    /// // 문자로
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // 둘 다 3 바이트로 표시 될 수 있습니다.
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str 로이 두 가지는 UTF-8 로 인코딩됩니다.
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // 총 6 바이트를 차지한다는 것을 알 수 있습니다.
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str 처럼
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 로 인코딩 된 경우이 `char` 에 필요한 16 비트 코드 단위의 수를 반환합니다.
    ///
    ///
    /// 이 개념에 대한 자세한 설명은 [`len_utf8()`] 설명서를 참조하십시오.
    /// 이 기능은 미러이지만 UTF-8 대신 UTF-16 용입니다.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// 이 문자를 제공된 바이트 버퍼에 UTF-8 로 인코딩 한 다음 인코딩 된 문자가 포함 된 버퍼의 하위 조각을 반환합니다.
    ///
    ///
    /// # Panics
    ///
    /// 버퍼가 충분히 크지 않은 경우 Panics.
    /// 길이가 4 인 버퍼는 `char` 를 인코딩하기에 충분히 큽니다.
    ///
    /// # Examples
    ///
    /// 이 두 예제에서 'ß' 는 인코딩하는 데 2 바이트를 사용합니다.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 너무 작은 버퍼 :
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // 안전: `char` 는 대리자가 아니므로 유효한 UTF-8 입니다.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// 이 문자를 제공된 `u16` 버퍼에 UTF-16 로 인코딩 한 다음 인코딩 된 문자가 포함 된 버퍼의 하위 조각을 반환합니다.
    ///
    ///
    /// # Panics
    ///
    /// 버퍼가 충분히 크지 않은 경우 Panics.
    /// 길이 2의 버퍼는 `char` 를 인코딩하기에 충분히 큽니다.
    ///
    /// # Examples
    ///
    /// 이 두 예에서 '𝕊' 는 인코딩하는 데 두 개의 'u16'을 사용합니다.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 너무 작은 버퍼 :
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// 이 `char` 에 `Alphabetic` 속성이 있으면 `true` 를 반환합니다.
    ///
    /// `Alphabetic` [Unicode Standard] 의 4 장 (캐릭터 속성)에 설명되어 있으며 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 에 지정되어 있습니다.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // 사랑은 많은 것이지만 알파벳이 아닙니다
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// 이 `char` 에 `Lowercase` 속성이 있으면 `true` 를 반환합니다.
    ///
    /// `Lowercase` [Unicode Standard] 의 4 장 (캐릭터 속성)에 설명되어 있으며 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 에 지정되어 있습니다.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // 다양한 중국어 스크립트와 구두점에는 대소 문자가 없습니다.
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// 이 `char` 에 `Uppercase` 속성이 있으면 `true` 를 반환합니다.
    ///
    /// `Uppercase` [Unicode Standard] 의 4 장 (캐릭터 속성)에 설명되어 있으며 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 에 지정되어 있습니다.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // 다양한 중국어 스크립트와 구두점에는 대소 문자가 없습니다.
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// 이 `char` 에 `White_Space` 속성이 있으면 `true` 를 반환합니다.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] 에 지정되어 있습니다.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // 깨지지 않는 공간
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// 이 `char` 가 [`is_alphabetic()`] 또는 [`is_numeric()`] 를 충족하면 `true` 를 반환합니다.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// 이 `char` 에 제어 코드에 대한 일반 범주가 있으면 `true` 를 반환합니다.
    ///
    /// 제어 코드 (일반 범주가 `Cc` 인 코드 포인트)는 [Unicode Standard] 의 4 장 (문자 속성)에 설명되어 있으며 [Unicode Character Database][ucd] [`UnicodeData.txt`] 에 지정되어 있습니다.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // U + 009C, 스트링 터미네이터
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// 이 `char` 에 `Grapheme_Extend` 속성이 있으면 `true` 를 반환합니다.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] 에 설명되어 있고 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 에 지정되어 있습니다.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// 이 `char` 에 숫자에 대한 일반 범주 중 하나가 있으면 `true` 를 반환합니다.
    ///
    /// 숫자의 일반 범주 (10 진수는 `Nd`, 문자와 유사한 숫자의 경우 `Nl`, 기타 숫자의 경우 `No`)는 [Unicode Character Database][ucd] [`UnicodeData.txt`] 에 지정되어 있습니다.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// 이 `char` 의 소문자 매핑을 하나 이상으로 생성하는 반복기를 반환합니다.
    /// `char`s.
    ///
    /// 이 `char` 에 소문자 매핑이 없으면 반복기는 동일한 `char` 를 생성합니다.
    ///
    /// 이 `char` 에 [Unicode Character Database][ucd] [`UnicodeData.txt`] 가 제공하는 일대일 소문자 매핑이있는 경우 반복기는 해당 `char` 를 생성합니다.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// 이 `char` 가 특별한 고려 사항 (예: 여러`char`)을 필요로하는 경우 반복기는 [`SpecialCasing.txt`] 에서 제공하는`char` (s)를 생성합니다.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// 이 작업은 조정없이 무조건 매핑을 수행합니다.즉, 변환은 컨텍스트 및 언어와 무관합니다.
    ///
    /// [Unicode Standard] 에서 4 장 (문자 속성)에서는 일반적인 대소 문자 매핑을 설명하고 3 장 (Conformance) 에서는 대소 문자 변환을위한 기본 알고리즘에 대해 설명합니다.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // 때로는 결과가 두 개 이상의 문자가됩니다.
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // 대문자와 소문자가 모두없는 문자는 자체적으로 변환됩니다.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// 이 `char` 의 대문자 매핑을 하나 이상으로 생성하는 반복기를 반환합니다.
    /// `char`s.
    ///
    /// 이 `char` 에 대문자 매핑이없는 경우 반복기는 동일한 `char` 를 생성합니다.
    ///
    /// 이 `char` 에 [Unicode Character Database][ucd] [`UnicodeData.txt`] 가 제공하는 일대일 대문자 매핑이있는 경우 반복기는 해당 `char` 를 생성합니다.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// 이 `char` 가 특별한 고려 사항 (예: 여러`char`)을 필요로하는 경우 반복기는 [`SpecialCasing.txt`] 에서 제공하는`char` (s)를 생성합니다.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// 이 작업은 조정없이 무조건 매핑을 수행합니다.즉, 변환은 컨텍스트 및 언어와 무관합니다.
    ///
    /// [Unicode Standard] 에서 4 장 (문자 속성)에서는 일반적인 대소 문자 매핑을 설명하고 3 장 (Conformance) 에서는 대소 문자 변환을위한 기본 알고리즘에 대해 설명합니다.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // 때로는 결과가 두 개 이상의 문자가됩니다.
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // 대문자와 소문자가 모두없는 문자는 자체적으로 변환됩니다.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # 로케일에 대한 참고 사항
    ///
    /// 터키어에서 라틴어로 'i' 에 해당하는 것은 두 가지가 아닌 다섯 가지 형태를가집니다.
    ///
    /// * 'Dotless': I/ı, 가끔 ï 작성
    /// * 'Dotted': İ/나는
    ///
    /// 점선으로 된 소문자 'i' 는 라틴어와 동일합니다.따라서:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// 여기서 `upper_i` 의 값은 텍스트 언어에 따라 달라집니다. `en-US` 에있는 경우 `"I"` 여야하지만 `tr_TR` 에있는 경우 `"İ"` 여야합니다.
    /// `to_uppercase()` 이를 고려하지 않으므로 :
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// 여러 언어로 유지됩니다.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// 값이 ASCII 범위 내에 있는지 확인합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// ASCII 대문자에 해당하는 값의 복사본을 만듭니다.
    ///
    /// ASCII 문자 'a'-'z' 는 'A'-'Z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 내부 값을 대문자로 바꾸려면 [`make_ascii_uppercase()`] 를 사용하십시오.
    ///
    /// 비 ASCII 문자 외에 ASCII 문자를 대문자로하려면 [`to_uppercase()`] 를 사용하십시오.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 해당 ASCII 소문자로 값을 복사합니다.
    ///
    /// ASCII 문자 'A'-'Z' 는 'a'-'z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 제자리에서 값을 소문자로 지정하려면 [`make_ascii_lowercase()`] 를 사용합니다.
    ///
    /// 비 ASCII 문자 외에 ASCII 문자를 소문자로하려면 [`to_lowercase()`] 를 사용하십시오.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 두 값이 ASCII 대소 문자를 구분하지 않는 일치인지 확인합니다.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 와 동일합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// 이 형식을 해당 위치에 해당하는 ASCII 대문자로 변환합니다.
    ///
    /// ASCII 문자 'a'-'z' 는 'A'-'Z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 기존 값을 수정하지 않고 새 대문자 값을 반환하려면 [`to_ascii_uppercase()`] 를 사용합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// 이 형식을 해당 위치에 해당하는 ASCII 소문자로 변환합니다.
    ///
    /// ASCII 문자 'A'-'Z' 는 'a'-'z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 기존 값을 수정하지 않고 새 소문자 값을 반환하려면 [`to_ascii_lowercase()`] 를 사용합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// 값이 ASCII 알파벳 문자인지 확인합니다.
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', 또는
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// 값이 ASCII 대문자인지 확인합니다.
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// 값이 ASCII 소문자인지 확인합니다.
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// 값이 ASCII 영숫자 문자인지 확인합니다.
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', 또는
    /// - U + 0061 'a' ..=U + 007A 'z', 또는
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// 값이 ASCII 십진수인지 확인합니다.
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// 값이 ASCII 16 진수인지 확인합니다.
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', 또는
    /// - U + 0041 'A' ..=U + 0046 'F', 또는
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// 값이 ASCII 구두점 문자인지 확인합니다.
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, 또는
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, 또는
    /// - U + 005B ..=U + 0060``[\] ^ _``, 또는
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// 값이 ASCII 그래픽 문자인지 확인합니다.
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// 값이 ASCII 공백 문자인지 확인합니다.
    /// U + 0020 스페이스, U + 0009 수평 탭, U + 000A 라인 피드, U + 000C 양식 피드 또는 U + 000D 캐리지 리턴.
    ///
    /// Rust 는 WhatWG Infra Standard의 [definition of ASCII whitespace][infra-aw] 를 사용합니다.널리 사용되는 몇 가지 다른 정의가 있습니다.
    /// 예를 들어 [the POSIX locale][pct] 에는 U + 000B VERTICAL TAB과 위의 모든 문자가 포함되어 있지만 매우 동일한 사양에서 [Bourne shell 의 "field splitting" 에 대한 기본 규칙][bfs]는 *only* SPACE, HORIZONTAL TAB 및 공백으로 LINE FEED.
    ///
    ///
    /// 기존 파일 형식을 처리하는 프로그램을 작성하는 경우이 함수를 사용하기 전에 해당 형식의 공백 정의가 무엇인지 확인하십시오.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// 값이 ASCII 제어 문자인지 확인합니다.
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR 또는 U + 007F DELETE.
    /// 대부분의 ASCII 공백 문자는 제어 문자이지만 SPACE는 그렇지 않습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// 원시 u32 값을 UTF-8 로 제공된 바이트 버퍼에 인코딩 한 다음 인코딩 된 문자가 포함 된 버퍼의 부분 조각을 반환합니다.
///
///
/// `char::encode_utf8` 와 달리이 메서드는 서로 게이트 범위의 코드 포인트도 처리합니다.
/// (대리 범위에서 `char` 를 만드는 것은 UB입니다.) 결과는 유효한 [generalized UTF-8] 이지만 유효한 UTF-8 는 아닙니다.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// 버퍼가 충분히 크지 않은 경우 Panics.
/// 길이가 4 인 버퍼는 `char` 를 인코딩하기에 충분히 큽니다.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// 원시 u32 값을 UTF-16 로 제공된 `u16` 버퍼에 인코딩 한 다음 인코딩 된 문자를 포함하는 버퍼의 하위 조각을 반환합니다.
///
///
/// `char::encode_utf16` 와 달리이 메서드는 서로 게이트 범위의 코드 포인트도 처리합니다.
/// (대리 범위에서 `char` 를 만드는 것은 UB입니다.)
///
/// # Panics
///
/// 버퍼가 충분히 크지 않은 경우 Panics.
/// 길이 2의 버퍼는 `char` 를 인코딩하기에 충분히 큽니다.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // 안전: 각 암은 쓰기에 충분한 비트가 있는지 확인합니다.
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP는
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // 보조 평면은 서로 게이트로 나뉩니다.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}