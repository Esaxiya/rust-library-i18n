//! libcore에 대한 Panic 지원
//!
//! 코어 라이브러리는 패닉을 정의 할 수 없지만 패닉을 *선언* 합니다.
//! 즉, libcore 내부의 함수는 panic 에 허용되지만 업스트림 crate 가 유용하려면 libcore가 사용할 패닉을 정의해야합니다.
//! 패닉에 대한 현재 인터페이스는 다음과 같습니다.
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! 이 정의는 모든 일반 메시지에서 패닉을 허용하지만 `Box<Any>` 값으로 실패하는 것은 허용하지 않습니다.
//! (`PanicInfo` 는 단지 `&(dyn Any + Send)` 를 포함하고 있기 때문에`PanicInfo: : internal_constructor`에 더미 값을 입력합니다.) 그 이유는 libcore가 할당 할 수 없기 때문입니다.
//!
//!
//! 이 모듈에는 몇 가지 다른 패닉 기능이 포함되어 있지만 이들은 컴파일러에 필요한 lang 항목 일뿐입니다.모든 panics 는이 하나의 기능을 통해 유입됩니다.
//! 실제 기호는 `#[panic_handler]` 속성을 통해 선언됩니다.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// 형식이 사용되지 않을 때 libcore의 `panic!` 매크로의 기본 구현입니다.
#[cold]
// 가능한 한 호출 사이트에서 코드 부풀림을 피하기 위해 panic_immediate_abort가 아니면 인라인하지 마십시오.
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // 오버플로 및 기타 `Assert` MIR 종결 자에서 panic 용 codegen에 필요
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // 잠재적으로 크기 오버 헤드를 줄이려면 format_args! ("{}", expr) 대신 Arguments::new_v1 를 사용하십시오.
    // format_args!매크로는 str의 Display trait 를 사용하여 expr을 작성합니다.이 expr은 Formatter::pad 를 호출합니다. 이는 문자열 자르기 및 패딩을 수용해야합니다 (여기서는 아무 것도 사용되지 않더라도).
    //
    // Arguments::new_v1 를 사용하면 컴파일러가 출력 바이너리에서 Formatter::pad 를 생략하여 최대 몇 킬로바이트까지 절약 할 수 있습니다.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // const-evaluated panics 에 필요
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice 액세스의 panic 에 대한 codegen에 필요
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// 형식화가 사용될 때 libcore의 `panic!` 매크로의 기본 구현입니다.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // 참고이 함수는 FFI 경계를 넘지 않습니다.`#[panic_handler]` 함수로 확인되는 Rust-to-Rust 호출입니다.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // 안전: `panic_impl` 는 안전한 Rust 코드에 정의되어 있으므로 안전하게 호출 할 수 있습니다.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` 및 `assert_ne!` 매크로에 대한 내부 기능
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}