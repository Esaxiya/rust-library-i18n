//! 원자 유형
//!
//! 원자 유형은 스레드 간의 원시 공유 메모리 통신을 제공하며 다른 동시 유형의 빌딩 블록입니다.
//!
//! 이 모듈은 [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] 등을 포함하여 선택된 기본 유형의 원자 버전을 정의합니다.
//! 원자 유형은 올바르게 사용될 경우 스레드간에 업데이트를 동기화하는 작업을 나타냅니다.
//!
//! 각 방법은 해당 작업에 대한 메모리 장벽의 강도를 나타내는 [`Ordering`] 를 사용합니다.이러한 순서는 [C++20 atomic orderings][1] 와 동일합니다.자세한 내용은 [nomicon][2] 를 참조하십시오.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! 원자 변수는 스레드간에 공유하기에 안전하지만 ([`Sync`] 를 구현 함) 자체적으로 공유 메커니즘을 제공하지 않고 Rust 의 [threading model](../../../std/thread/index.html#the-threading-model) 를 따릅니다.
//!
//! 원자 변수를 공유하는 가장 일반적인 방법은 [`Arc`][arc] (원자 참조로 계산되는 공유 포인터)에 넣는 것입니다.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! 원자 유형은 [`AtomicBool::new`] 와 같은 상수 이니셜 라이저를 사용하여 초기화 된 정적 변수에 저장 될 수 있습니다.원자 정적은 종종 지연 전역 초기화에 사용됩니다.
//!
//! # Portability
//!
//! 이 모듈의 모든 원자 유형은 가능한 경우 [lock-free] 로 보장됩니다.이는 내부적으로 글로벌 뮤텍스를 획득하지 않음을 의미합니다.원자 유형 및 작업은 대기가 보장되지 않습니다.
//! 이는 `fetch_or` 와 같은 작업이 비교 및 교체 루프로 구현 될 수 있음을 의미합니다.
//!
//! 원자 연산은 더 큰 크기의 원자로 명령 계층에서 구현 될 수 있습니다.예를 들어 일부 플랫폼은 4 바이트 원자 적 명령어를 사용하여 `AtomicI8` 를 구현합니다.
//! 이 에뮬레이션은 코드의 정확성에 영향을주지 않아야하며 단지 알아 두어야 할 사항입니다.
//!
//! 이 모듈의 원자 유형은 모든 플랫폼에서 사용 가능하지 않을 수 있습니다.그러나 여기서 원자 유형은 모두 널리 사용 가능하며 일반적으로 기존에 신뢰할 수 있습니다.몇 가지 주목할만한 예외는 다음과 같습니다.
//!
//! * PowerPC 32 비트 포인터가있는 MIPS 플랫폼에는 `AtomicU64` 또는 `AtomicI64` 유형이 없습니다.
//! * ARM Linux 용이 아닌 `armv5te` 와 같은 플랫폼은 `load` 및 `store` 작업 만 제공하며 `swap`, `fetch_add` 등과 같은 (CAS) 비교 및 스왑 작업은 지원하지 않습니다.
//! 또한 Linux 에서 이러한 CAS 작업은 [operating system support] 를 통해 구현되므로 성능이 저하 될 수 있습니다.
//! * ARM `thumbv6m` 가있는 대상은 `load` 및 `store` 작업 만 제공하며 `swap`, `fetch_add` 등과 같은 (CAS) 비교 및 교체 작업은 지원하지 않습니다.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! 일부 원자 작업을 지원하지 않는 future 플랫폼이 추가 될 수 있습니다.최대한 이식 가능한 코드는 어떤 원자 유형이 사용되는지주의해야합니다.
//! `AtomicUsize` `AtomicIsize` 는 일반적으로 가장 휴대 성이 뛰어나지 만 모든 곳에서 사용할 수 없습니다.
//! 참고로 `std` 라이브러리에는 포인터 크기의 원자가 필요하지만 `core` 는 그렇지 않습니다.
//!
//! 현재는 기본적으로 원 자성을 사용하여 코드를 조건부로 컴파일하기 위해 `#[cfg(target_arch)]` 를 사용해야합니다.future 에서 안정화 될 수있는 불안정한 `#[cfg(target_has_atomic)]` 도 있습니다.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! 간단한 스핀 락 :
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // 다른 스레드가 잠금을 해제 할 때까지 기다립니다.
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! 라이브 스레드의 글로벌 수를 유지하십시오.
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// 스레드간에 안전하게 공유 할 수있는 부울 유형입니다.
///
/// 이 유형은 [`bool`] 와 동일한 메모리 내 표현을 갖습니다.
///
/// **참고**: 이 유형은 `u8` 의 원자로드 및 저장을 지원하는 플랫폼에서만 사용할 수 있습니다.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` 로 초기화 된 `AtomicBool` 를 생성합니다.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send는 AtomicBool에 대해 암시 적으로 구현됩니다.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// 스레드간에 안전하게 공유 할 수있는 원시 포인터 유형입니다.
///
/// 이 유형은 `*mut T` 와 동일한 메모리 내 표현을 갖습니다.
///
/// **참고**: 이 유형은 원자로드 및 포인터 저장을 지원하는 플랫폼에서만 사용할 수 있습니다.
/// 크기는 대상 포인터의 크기에 따라 다릅니다.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// 널 `AtomicPtr<T>` 를 작성합니다.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// 원자 메모리 순서
///
/// 메모리 순서는 원자 적 작업이 메모리를 동기화하는 방식을 지정합니다.
/// 가장 약한 [`Ordering::Relaxed`] 에서는 작업에 직접 닿은 메모리 만 동기화됩니다.
/// 반면에 저장-로드 [`Ordering::SeqCst`] 작업 쌍은 다른 메모리를 동기화하는 동시에 모든 스레드에서 이러한 작업의 총 순서를 추가로 유지합니다.
///
///
/// Rust 의 메모리 순서는 [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) 입니다.
///
/// 자세한 내용은 [nomicon] 를 참조하십시오.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// 순서 제약이없고 원자 적 연산 만 있습니다.
    ///
    /// C ++ 20의 [`memory_order_relaxed`] 에 해당합니다.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// 상점과 결합되면 이전의 모든 작업이 [`Acquire`] (또는 더 강력한) 순서로이 값이로드되기 전에 순서가 지정됩니다.
    ///
    /// 특히, 모든 이전 쓰기는이 값의 [`Acquire`] (또는 더 강력한)로드를 수행하는 모든 스레드에 표시됩니다.
    ///
    /// 로드와 저장을 결합하는 작업에이 순서를 사용하면 [`Relaxed`] 로드 작업이 수행됩니다!
    ///
    /// 이 주문은 상점을 수행 할 수있는 작업에만 적용됩니다.
    ///
    /// C ++ 20의 [`memory_order_release`] 에 해당합니다.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// 로드와 결합 될 때로드 된 값이 [`Release`] (또는 더 강력한) 순서로 저장 작업에 의해 기록 된 경우 모든 후속 작업은 해당 저장 후에 순서가 지정됩니다.
    /// 특히 이후의 모든로드에는 저장소 이전에 기록 된 데이터가 표시됩니다.
    ///
    /// 로드와 저장을 결합하는 작업에이 순서를 사용하면 [`Relaxed`] 저장 작업이 수행됩니다!
    ///
    /// 이 순서는로드를 수행 할 수있는 작업에만 적용됩니다.
    ///
    /// C ++ 20의 [`memory_order_acquire`] 에 해당합니다.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] 와 [`Release`] 의 효과가 함께 있습니다.
    /// 부하의 경우 [`Acquire`] 순서를 사용합니다.상점의 경우 [`Release`] 주문을 사용합니다.
    ///
    /// `compare_and_swap` 의 경우 작업이 저장을 수행하지 않고 결국 [`Acquire`] 주문 만있을 수 있습니다.
    ///
    /// 그러나 `AcqRel` 는 [`Relaxed`] 액세스를 수행하지 않습니다.
    ///
    /// 이 순서는로드와 저장을 결합하는 작업에만 적용됩니다.
    ///
    /// C ++ 20의 [`memory_order_acq_rel`] 에 해당합니다.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`Acquire`]/[`Release`]/[`AcqRel`](각각로드, 저장 및 저장과 함께로드 작업의 경우)과 같이 모든 스레드가 동일한 순서로 모든 순차적으로 일관된 작업을 볼 수 있다는 추가 보장이 있습니다. .
    ///
    ///
    /// C ++ 20의 [`memory_order_seq_cst`] 에 해당합니다.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// `false` 로 초기화 된 [`AtomicBool`].
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// 새 `AtomicBool` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// 기본 [`bool`] 에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// 변경 가능한 참조는 다른 스레드가 원자 데이터에 동시에 액세스하지 않도록 보장하기 때문에 안전합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // 안전: 가변 참조는 고유 한 소유권을 보장합니다.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` 에 대한 원자 적 액세스 권한을 얻으십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // 안전: 가변 참조는 고유 한 소유권을 보장합니다.
        // `bool` 와 `Self` 의 정렬은 1입니다.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// 원 자성을 소비하고 포함 된 값을 반환합니다.
    ///
    /// `self` 를 값으로 전달하면 다른 스레드가 원자 데이터에 동시에 액세스하지 않도록 보장하므로 안전합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool 에서 값을로드합니다.
    ///
    /// `load` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
    /// 가능한 값은 [`SeqCst`], [`Acquire`] 및 [`Relaxed`] 입니다.
    ///
    /// # Panics
    ///
    /// `order` 가 [`Release`] 또는 [`AcqRel`] 인 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // 안전: 모든 데이터 경쟁은 원자 내장 및 원시
        // 전달 된 포인터는 참조에서 가져 왔기 때문에 유효합니다.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool 에 값을 저장합니다.
    ///
    /// `store` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
    /// 가능한 값은 [`SeqCst`], [`Release`] 및 [`Relaxed`] 입니다.
    ///
    /// # Panics
    ///
    /// `order` 가 [`Acquire`] 또는 [`AcqRel`] 인 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // 안전: 모든 데이터 경쟁은 원자 내장 및 원시
        // 전달 된 포인터는 참조에서 가져 왔기 때문에 유효합니다.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool 에 값을 저장하고 이전 값을 반환합니다.
    ///
    /// `swap` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// 현재 값이 `current` 값과 동일한 경우 값을 [`bool`] 에 저장합니다.
    ///
    /// 반환 값은 항상 이전 값입니다.`current` 와 같으면 값이 업데이트 된 것입니다.
    ///
    /// `compare_and_swap` 또한이 작업의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
    /// [`AcqRel`] 를 사용하는 경우에도 작업이 실패하여 `Acquire` 로드 만 수행 할 수 있지만 `Release` 의미 체계는 없습니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # `compare_exchange` 및 `compare_exchange_weak` 로 마이그레이션
    ///
    /// `compare_and_swap` 메모리 순서에 대한 다음 매핑이있는 `compare_exchange` 와 동일합니다.
    ///
    /// 원본 |성공 |실패
    /// -------- | ------- | -------
    /// 편안한 |편안한 |편안한 취득 |취득 |릴리스 획득 |출시 |편안한 AcqRel |AcqRel |SeqCst 취득 |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` 비교가 성공하더라도 가짜로 실패 할 수 있으므로 비교 및 스왑이 루프에서 사용될 때 컴파일러가 더 나은 어셈블리 코드를 생성 할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 현재 값이 `current` 값과 동일한 경우 값을 [`bool`] 에 저장합니다.
    ///
    /// 반환 값은 새 값이 작성되었는지 여부를 나타내는 결과이며 이전 값을 포함합니다.
    /// 성공시이 값은 `current` 와 동일하게 보장됩니다.
    ///
    /// `compare_exchange` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
    /// `success` `current` 와의 비교가 성공할 경우 발생하는 읽기-수정-쓰기 작업에 필요한 순서를 설명합니다.
    /// `failure` 비교가 실패 할 때 발생하는로드 작업에 필요한 순서를 설명합니다.
    /// [`Acquire`] 를 성공 순서로 사용하면 저장이이 작업 [`Relaxed`] 의 일부가되고 [`Release`] 를 사용하면 [`Relaxed`] 가 성공적으로로드됩니다.
    ///
    /// 실패 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 같거나 더 약해야합니다.
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// 현재 값이 `current` 값과 동일한 경우 값을 [`bool`] 에 저장합니다.
    ///
    /// [`AtomicBool::compare_exchange`] 와 달리이 함수는 비교가 성공하더라도 가짜로 실패 할 수 있으므로 일부 플랫폼에서 더 효율적인 코드를 생성 할 수 있습니다.
    ///
    /// 반환 값은 새 값이 작성되었는지 여부를 나타내는 결과이며 이전 값을 포함합니다.
    ///
    /// `compare_exchange_weak` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
    /// `success` `current` 와의 비교가 성공할 경우 발생하는 읽기-수정-쓰기 작업에 필요한 순서를 설명합니다.
    /// `failure` 비교가 실패 할 때 발생하는로드 작업에 필요한 순서를 설명합니다.
    /// [`Acquire`] 를 성공 순서로 사용하면 저장이이 작업 [`Relaxed`] 의 일부가되고 [`Release`] 를 사용하면 [`Relaxed`] 가 성공적으로로드됩니다.
    /// 실패 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 같거나 더 약해야합니다.
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// 부울 값이있는 논리 "and" 입니다.
    ///
    /// 현재 값과 인수 `val` 에 대해 논리적 "and" 연산을 수행하고 새 값을 결과로 설정합니다.
    ///
    /// 이전 값을 반환합니다.
    ///
    /// `fetch_and` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// 부울 값이있는 논리 "nand" 입니다.
    ///
    /// 현재 값과 인수 `val` 에 대해 논리적 "nand" 연산을 수행하고 새 값을 결과로 설정합니다.
    ///
    /// 이전 값을 반환합니다.
    ///
    /// `fetch_nand` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // 여기서는 atomic_nand를 사용할 수 없습니다. 잘못된 값이있는 bool 가 될 수 있기 때문입니다.
        // 이는 원자 연산이 내부적으로 8 비트 정수로 수행되어 상위 7 비트를 설정하기 때문에 발생합니다.
        //
        // 그래서 우리는 대신 fetch_xor 또는 swap을 사용합니다.
        if val {
            // ! (x&true)== !x bool 를 반전해야합니다.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true bool 를 true로 설정해야합니다.
            //
            self.swap(true, order)
        }
    }

    /// 부울 값이있는 논리 "or" 입니다.
    ///
    /// 현재 값과 인수 `val` 에 대해 논리적 "or" 연산을 수행하고 새 값을 결과로 설정합니다.
    ///
    /// 이전 값을 반환합니다.
    ///
    /// `fetch_or` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// 부울 값이있는 논리 "xor" 입니다.
    ///
    /// 현재 값과 인수 `val` 에 대해 논리적 "xor" 연산을 수행하고 새 값을 결과로 설정합니다.
    ///
    /// 이전 값을 반환합니다.
    ///
    /// `fetch_xor` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// 기본 [`bool`] 에 대한 변경 가능한 포인터를 반환합니다.
    ///
    /// 결과 정수에 대해 비원 자적 읽기 및 쓰기를 수행하면 데이터 경쟁이 발생할 수 있습니다.
    /// 이 방법은 함수 서명이 `&AtomicBool` 대신 `*mut bool` 를 사용할 수있는 FFI에 주로 유용합니다.
    ///
    /// 이 원자에 대한 공유 참조에서 `*mut` 포인터를 반환하는 것은 원자 유형이 내부 가변성과 함께 작동하기 때문에 안전합니다.
    /// 원자의 모든 수정은 공유 참조를 통해 값을 변경하며 원자 연산을 사용하는 한 안전하게 수행 할 수 있습니다.
    /// 반환 된 원시 포인터를 사용하려면 `unsafe` 블록이 필요하며 여전히 동일한 제한을 유지해야합니다. 이에 대한 작업은 원자 적이어야합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// 값을 가져오고 선택적 새 값을 반환하는 함수를 적용합니다.함수가 `Some(_)` 를 반환하면 `Ok(previous_value)` 의 `Result` 를 반환하고, 그렇지 않으면 `Err(previous_value)` 를 반환합니다.
    ///
    /// Note: 함수가 `Some(_)` 를 반환하는 한 그 동안 다른 스레드에서 값이 변경된 경우 함수를 여러 번 호출 할 수 있지만 함수는 저장된 값에 한 번만 적용됩니다.
    ///
    ///
    /// `fetch_update` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
    /// 첫 번째는 작업이 마침내 성공할 때 필요한 순서를 설명하고 두 번째는로드에 필요한 순서를 설명합니다.
    /// 이들은 각각 [`AtomicBool::compare_exchange`] 의 성공 및 실패 순서에 해당합니다.
    ///
    /// [`Acquire`] 를 성공 순서로 사용하면이 작업 [`Relaxed`] 의 저장 부분이되고 [`Release`] 를 사용하면 최종로드 [`Relaxed`] 가 성공합니다.
    /// (failed) 로드 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 동일하거나 약해야합니다.
    ///
    /// **Note:** 이 방법은 `u8` 에서 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// 새 `AtomicPtr` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// 기본 포인터에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// 변경 가능한 참조는 다른 스레드가 원자 데이터에 동시에 액세스하지 않도록 보장하기 때문에 안전합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// 포인터에 대한 원자 적 액세스를 얻습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - 가변 참조는 고유 한 소유권을 보장합니다.
        //  - `*mut T` 및 `Self` 의 정렬은 위에서 확인한대로 rust 가 지원하는 모든 플랫폼에서 동일합니다.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// 원 자성을 소비하고 포함 된 값을 반환합니다.
    ///
    /// `self` 를 값으로 전달하면 다른 스레드가 원자 데이터에 동시에 액세스하지 않도록 보장하므로 안전합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// 포인터에서 값을로드합니다.
    ///
    /// `load` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
    /// 가능한 값은 [`SeqCst`], [`Acquire`] 및 [`Relaxed`] 입니다.
    ///
    /// # Panics
    ///
    /// `order` 가 [`Release`] 또는 [`AcqRel`] 인 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// 포인터에 값을 저장합니다.
    ///
    /// `store` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
    /// 가능한 값은 [`SeqCst`], [`Release`] 및 [`Relaxed`] 입니다.
    ///
    /// # Panics
    ///
    /// `order` 가 [`Acquire`] 또는 [`AcqRel`] 인 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// 포인터에 값을 저장하고 이전 값을 반환합니다.
    ///
    /// `swap` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    ///
    /// **Note:** 이 메서드는 포인터에 대한 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// 현재 값이 `current` 값과 같은 경우 포인터에 값을 저장합니다.
    ///
    /// 반환 값은 항상 이전 값입니다.`current` 와 같으면 값이 업데이트 된 것입니다.
    ///
    /// `compare_and_swap` 또한이 작업의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
    /// [`AcqRel`] 를 사용하는 경우에도 작업이 실패하여 `Acquire` 로드 만 수행 할 수 있지만 `Release` 의미 체계는 없습니다.
    /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
    ///
    /// **Note:** 이 메서드는 포인터에 대한 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # `compare_exchange` 및 `compare_exchange_weak` 로 마이그레이션
    ///
    /// `compare_and_swap` 메모리 순서에 대한 다음 매핑이있는 `compare_exchange` 와 동일합니다.
    ///
    /// 원본 |성공 |실패
    /// -------- | ------- | -------
    /// 편안한 |편안한 |편안한 취득 |취득 |릴리스 획득 |출시 |편안한 AcqRel |AcqRel |SeqCst 취득 |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` 비교가 성공하더라도 가짜로 실패 할 수 있으므로 비교 및 스왑이 루프에서 사용될 때 컴파일러가 더 나은 어셈블리 코드를 생성 할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 현재 값이 `current` 값과 같은 경우 포인터에 값을 저장합니다.
    ///
    /// 반환 값은 새 값이 작성되었는지 여부를 나타내는 결과이며 이전 값을 포함합니다.
    /// 성공시이 값은 `current` 와 동일하게 보장됩니다.
    ///
    /// `compare_exchange` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
    /// `success` `current` 와의 비교가 성공할 경우 발생하는 읽기-수정-쓰기 작업에 필요한 순서를 설명합니다.
    /// `failure` 비교가 실패 할 때 발생하는로드 작업에 필요한 순서를 설명합니다.
    /// [`Acquire`] 를 성공 순서로 사용하면 저장이이 작업 [`Relaxed`] 의 일부가되고 [`Release`] 를 사용하면 [`Relaxed`] 가 성공적으로로드됩니다.
    ///
    /// 실패 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 같거나 더 약해야합니다.
    ///
    /// **Note:** 이 메서드는 포인터에 대한 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// 현재 값이 `current` 값과 같은 경우 포인터에 값을 저장합니다.
    ///
    /// [`AtomicPtr::compare_exchange`] 와 달리이 함수는 비교가 성공하더라도 가짜로 실패 할 수 있으므로 일부 플랫폼에서 더 효율적인 코드를 생성 할 수 있습니다.
    ///
    /// 반환 값은 새 값이 작성되었는지 여부를 나타내는 결과이며 이전 값을 포함합니다.
    ///
    /// `compare_exchange_weak` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
    /// `success` `current` 와의 비교가 성공할 경우 발생하는 읽기-수정-쓰기 작업에 필요한 순서를 설명합니다.
    /// `failure` 비교가 실패 할 때 발생하는로드 작업에 필요한 순서를 설명합니다.
    /// [`Acquire`] 를 성공 순서로 사용하면 저장이이 작업 [`Relaxed`] 의 일부가되고 [`Release`] 를 사용하면 [`Relaxed`] 가 성공적으로로드됩니다.
    /// 실패 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 같거나 더 약해야합니다.
    ///
    /// **Note:** 이 메서드는 포인터에 대한 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // 안전: 이 내장 함수는 원시 포인터에서 작동하므로 안전하지 않습니다.
        // 그러나 우리는 포인터가 유효하다는 것을 확실히 알고 (우리가 참조로 가지고있는 `UnsafeCell` 에서 방금 얻었습니다) 원자 적 연산 자체를 통해 `UnsafeCell` 내용을 안전하게 변경할 수 있습니다.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// 값을 가져오고 선택적 새 값을 반환하는 함수를 적용합니다.함수가 `Some(_)` 를 반환하면 `Ok(previous_value)` 의 `Result` 를 반환하고, 그렇지 않으면 `Err(previous_value)` 를 반환합니다.
    ///
    /// Note: 함수가 `Some(_)` 를 반환하는 한 그 동안 다른 스레드에서 값이 변경된 경우 함수를 여러 번 호출 할 수 있지만 함수는 저장된 값에 한 번만 적용됩니다.
    ///
    ///
    /// `fetch_update` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
    /// 첫 번째는 작업이 마침내 성공할 때 필요한 순서를 설명하고 두 번째는로드에 필요한 순서를 설명합니다.
    /// 이들은 각각 [`AtomicPtr::compare_exchange`] 의 성공 및 실패 순서에 해당합니다.
    ///
    /// [`Acquire`] 를 성공 순서로 사용하면이 작업 [`Relaxed`] 의 저장 부분이되고 [`Release`] 를 사용하면 최종로드 [`Relaxed`] 가 성공합니다.
    /// (failed) 로드 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 동일하거나 약해야합니다.
    ///
    /// **Note:** 이 메서드는 포인터에 대한 원자 적 연산을 지원하는 플랫폼에서만 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` 를 `AtomicBool` 로 변환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // 이 매크로는 일부 아키텍처에서 사용되지 않습니다.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// 스레드간에 안전하게 공유 할 수있는 정수 유형입니다.
        ///
        /// 이 유형은 기본 정수 유형 [`과 동일한 메모리 내 표현을 갖습니다.
        ///
        #[doc = $s_int_type]
        /// `].
        /// 원자 유형과 비 원자 유형의 차이점과이 유형의 이식성에 대한 정보는 [module-level documentation] 를 참조하십시오.
        ///
        ///
        /// **Note:** 이 유형은 원자로드 및 [`의 저장을 지원하는 플랫폼에서만 사용할 수 있습니다.
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// `0` 로 초기화 된 원자 정수입니다.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // 보내기는 암시 적으로 구현됩니다.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// 새로운 원자 정수를 만듭니다.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// 기본 정수에 대한 변경 가능한 참조를 반환합니다.
            ///
            /// 변경 가능한 참조는 다른 스레드가 원자 데이터에 동시에 액세스하지 않도록 보장하기 때문에 안전합니다.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - 가변 참조는 고유 한 소유권을 보장합니다.
                //  - `$int_type` 와 `Self` 의 정렬은 $cfg_align 에서 약속하고 위에서 확인한대로 동일합니다.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// 원 자성을 소비하고 포함 된 값을 반환합니다.
            ///
            /// `self` 를 값으로 전달하면 다른 스레드가 원자 데이터에 동시에 액세스하지 않도록 보장하므로 안전합니다.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// 원자 정수에서 값을로드합니다.
            ///
            /// `load` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
            /// 가능한 값은 [`SeqCst`], [`Acquire`] 및 [`Relaxed`] 입니다.
            ///
            /// # Panics
            ///
            /// `order` 가 [`Release`] 또는 [`AcqRel`] 인 경우 Panics 입니다.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// 원자 정수에 값을 저장합니다.
            ///
            /// `store` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
            ///  가능한 값은 [`SeqCst`], [`Release`] 및 [`Relaxed`] 입니다.
            ///
            /// # Panics
            ///
            /// `order` 가 [`Acquire`] 또는 [`AcqRel`] 인 경우 Panics 입니다.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// 원자 정수에 값을 저장하고 이전 값을 반환합니다.
            ///
            /// `swap` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// 현재 값이 `current` 값과 같은 경우 원자 정수에 값을 저장합니다.
            ///
            /// 반환 값은 항상 이전 값입니다.`current` 와 같으면 값이 업데이트 된 것입니다.
            ///
            /// `compare_and_swap` 또한이 작업의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.
            /// [`AcqRel`] 를 사용하는 경우에도 작업이 실패하여 `Acquire` 로드 만 수행 할 수 있지만 `Release` 의미 체계는 없습니다.
            ///
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` 및 `compare_exchange_weak` 로 마이그레이션
            ///
            /// `compare_and_swap` 메모리 순서에 대한 다음 매핑이있는 `compare_exchange` 와 동일합니다.
            ///
            /// 원본 |성공 |실패
            /// -------- | ------- | -------
            /// 편안한 |편안한 |편안한 취득 |취득 |릴리스 획득 |출시 |편안한 AcqRel |AcqRel |SeqCst 취득 |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` 비교가 성공하더라도 가짜로 실패 할 수 있으므로 비교 및 스왑이 루프에서 사용될 때 컴파일러가 더 나은 어셈블리 코드를 생성 할 수 있습니다.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// 현재 값이 `current` 값과 같은 경우 원자 정수에 값을 저장합니다.
            ///
            /// 반환 값은 새 값이 작성되었는지 여부를 나타내는 결과이며 이전 값을 포함합니다.
            /// 성공시이 값은 `current` 와 동일하게 보장됩니다.
            ///
            /// `compare_exchange` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
            /// `success` `current` 와의 비교가 성공할 경우 발생하는 읽기-수정-쓰기 작업에 필요한 순서를 설명합니다.
            /// `failure` 비교가 실패 할 때 발생하는로드 작업에 필요한 순서를 설명합니다.
            /// [`Acquire`] 를 성공 순서로 사용하면 저장이이 작업 [`Relaxed`] 의 일부가되고 [`Release`] 를 사용하면 [`Relaxed`] 가 성공적으로로드됩니다.
            ///
            /// 실패 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 같거나 더 약해야합니다.
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// 현재 값이 `current` 값과 같은 경우 원자 정수에 값을 저장합니다.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// 이 함수는 비교가 성공하더라도 허위로 실패 할 수 있으므로 일부 플랫폼에서 더 효율적인 코드를 생성 할 수 있습니다.
            /// 반환 값은 새 값이 작성되었는지 여부를 나타내는 결과이며 이전 값을 포함합니다.
            ///
            /// `compare_exchange_weak` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
            /// `success` `current` 와의 비교가 성공할 경우 발생하는 읽기-수정-쓰기 작업에 필요한 순서를 설명합니다.
            /// `failure` 비교가 실패 할 때 발생하는로드 작업에 필요한 순서를 설명합니다.
            /// [`Acquire`] 를 성공 순서로 사용하면 저장이이 작업 [`Relaxed`] 의 일부가되고 [`Release`] 를 사용하면 [`Relaxed`] 가 성공적으로로드됩니다.
            ///
            /// 실패 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 같거나 더 약해야합니다.
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut old= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } 와 일치}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// 현재 값에 더하여 이전 값을 반환합니다.
            ///
            /// 이 작업은 오버플로를 래핑합니다.
            ///
            /// `fetch_add` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// 현재 값에서 빼고 이전 값을 반환합니다.
            ///
            /// 이 작업은 오버플로를 래핑합니다.
            ///
            /// `fetch_sub` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// 현재 값이있는 비트 단위 "and".
            ///
            /// 현재 값과 인수 `val` 에 대해 비트 단위 "and" 연산을 수행하고 새 값을 결과로 설정합니다.
            ///
            /// 이전 값을 반환합니다.
            ///
            /// `fetch_and` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// 현재 값이있는 비트 단위 "nand".
            ///
            /// 현재 값과 인수 `val` 에 대해 비트 단위 "nand" 연산을 수행하고 새 값을 결과로 설정합니다.
            ///
            /// 이전 값을 반환합니다.
            ///
            /// `fetch_nand` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 및 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// 현재 값이있는 비트 단위 "or".
            ///
            /// 현재 값과 인수 `val` 에 대해 비트 단위 "or" 연산을 수행하고 새 값을 결과로 설정합니다.
            ///
            /// 이전 값을 반환합니다.
            ///
            /// `fetch_or` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// 현재 값이있는 비트 단위 "xor".
            ///
            /// 현재 값과 인수 `val` 에 대해 비트 단위 "xor" 연산을 수행하고 새 값을 결과로 설정합니다.
            ///
            /// 이전 값을 반환합니다.
            ///
            /// `fetch_xor` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// 값을 가져오고 선택적 새 값을 반환하는 함수를 적용합니다.함수가 `Some(_)` 를 반환하면 `Ok(previous_value)` 의 `Result` 를 반환하고, 그렇지 않으면 `Err(previous_value)` 를 반환합니다.
            ///
            /// Note: 함수가 `Some(_)` 를 반환하는 한 그 동안 다른 스레드에서 값이 변경된 경우 함수를 여러 번 호출 할 수 있지만 함수는 저장된 값에 한 번만 적용됩니다.
            ///
            ///
            /// `fetch_update` 이 작업의 메모리 순서를 설명하기 위해 두 개의 [`Ordering`] 인수를 사용합니다.
            /// 첫 번째는 작업이 마침내 성공할 때 필요한 순서를 설명하고 두 번째는로드에 필요한 순서를 설명합니다.이는 성공 및 실패 순서에 해당합니다.
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] 를 성공 순서로 사용하면이 작업 [`Relaxed`] 의 저장 부분이되고 [`Release`] 를 사용하면 최종로드 [`Relaxed`] 가 성공합니다.
            /// (failed) 로드 순서는 [`SeqCst`], [`Acquire`] 또는 [`Relaxed`] 만 가능하며 성공 순서와 동일하거나 약해야합니다.
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// 현재 값으로 최대.
            ///
            /// 현재 값과 인수 `val` 의 최대 값을 찾고 결과에 새 값을 설정합니다.
            ///
            /// 이전 값을 반환합니다.
            ///
            /// `fetch_max` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// let max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// assert! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// 현재 값으로 최소.
            ///
            /// 현재 값과 인수 `val` 의 최소값을 찾아 결과에 새 값을 설정합니다.
            ///
            /// 이전 값을 반환합니다.
            ///
            /// `fetch_min` 이 연산의 메모리 순서를 설명하는 [`Ordering`] 인수를 사용합니다.모든 주문 모드가 가능합니다.
            /// [`Acquire`] 를 사용하면이 작업의 저장 부분이 [`Relaxed`] 가되고 [`Release`] 를 사용하면로드 부분이 [`Relaxed`] 가됩니다.
            ///
            ///
            /// **참고**: 이 방법은 원자 적 작업을 지원하는 플랫폼에서만 사용할 수 있습니다.
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=12;
            /// let min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // 안전: 데이터 경쟁은 원자 내장 함수에 의해 방지됩니다.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// 기본 정수에 대한 가변 포인터를 반환합니다.
            ///
            /// 결과 정수에 대해 비원 자적 읽기 및 쓰기를 수행하면 데이터 경쟁이 발생할 수 있습니다.
            /// 이 방법은 함수 서명이 사용할 수있는 FFI에 주로 유용합니다.
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// 이 원자에 대한 공유 참조에서 `*mut` 포인터를 반환하는 것은 원자 유형이 내부 가변성과 함께 작동하기 때문에 안전합니다.
            /// 원자의 모든 수정은 공유 참조를 통해 값을 변경하며 원자 연산을 사용하는 한 안전하게 수행 할 수 있습니다.
            /// 반환 된 원시 포인터를 사용하려면 `unsafe` 블록이 필요하며 여전히 동일한 제한을 유지해야합니다. 이에 대한 작업은 원자 적이어야합니다.
            ///
            ///
            /// # Examples
            ///
            /// ``(extern-declaration) 무시
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // 안전: `my_atomic_op` 가 원자 적이면 안전합니다.
            /// 안전하지 않은 {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // 안전: 발신자는 `atomic_store` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_load` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_swap` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// 이전 값 (예: __sync_fetch_and_add)을 반환합니다.
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_add` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// 이전 값 (예: __sync_fetch_and_sub)을 반환합니다.
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_sub` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // 안전: 발신자는 `atomic_compare_exchange` 에 대한 안전 계약을 유지해야합니다.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // 안전: 발신자는 `atomic_compare_exchange_weak` 에 대한 안전 계약을 유지해야합니다.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_and` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_nand` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_or` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_xor` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// 최대 값을 반환합니다 (부호있는 비교).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_max` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// 최소값을 반환합니다 (부호있는 비교).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_min` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// 최대 값을 반환합니다 (부호없는 비교).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_umax` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// 최소값을 반환합니다 (부호없는 비교).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 안전: 발신자는 `atomic_umin` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// 원자 울타리.
///
/// 지정된 순서에 따라 펜스는 컴파일러와 CPU가 특정 유형의 메모리 작업을 재정렬하는 것을 방지합니다.
/// 그것은 그것과 원자 적 작업 또는 다른 스레드의 울타리 사이의 관계와 동기화를 생성합니다.
///
/// (적어도) [`Release`] 순서 의미 체계를 가진 펜스 'A' 는 (적어도) [`Acquire`] 의미 체계를 가진 펜스 'B' 와 동기화합니다. X, Y는 B와 Y가 M으로의 변화를 관찰하기 전에 동기화됩니다.
/// 이것은 A와 B 사이에 발생 전 의존성을 제공합니다.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] 또는 [`Acquire`] 의미 체계를 사용한 원자 적 작업은 펜스와 동기화 할 수도 있습니다.
///
/// [`SeqCst`] 순서가있는 펜스는 [`Acquire`] 및 [`Release`] 의미 체계를 모두 갖는 것 외에도 다른 [`SeqCst`] 작업 및/또는 펜스의 글로벌 프로그램 순서에 참여합니다.
///
/// [`Acquire`], [`Release`], [`AcqRel`] 및 [`SeqCst`] 주문을 수락합니다.
///
/// # Panics
///
/// `order` 가 [`Relaxed`] 이면 Panics 입니다.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // 스핀 록을 기반으로하는 상호 배제 프리미티브.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // 이전 값이 `false` 가 될 때까지 기다리십시오.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // 이 펜스는 `unlock` 의 저장소와 동기화됩니다.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // 안전: 원자 울타리를 사용하는 것이 안전합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// 컴파일러 메모리 펜스.
///
/// `compiler_fence` 기계 코드를 내 보내지 않지만 컴파일러가 수행 할 수있는 메모리 재정렬의 종류를 제한합니다.특히, 주어진 [`Ordering`] 의미 체계에 따라 컴파일러는 `compiler_fence` 호출의 다른 쪽 호출 전후에서 읽기 또는 쓰기를 이동하는 것이 허용되지 않을 수 있습니다.*하드웨어* 가 이러한 재주문을하는 것을 막지는 **아닙니다**.
///
/// 단일 스레드 실행 컨텍스트에서는 문제가되지 않지만 다른 스레드가 동시에 메모리를 수정할 수있는 경우 [`fence`] 와 같은 강력한 동기화 기본 요소가 필요합니다.
///
/// 다른 순서 의미 체계에 의해 방지되는 재정렬은 다음과 같습니다.
///
///  - [`SeqCst`] 를 사용하면이 시점에서 읽기 및 쓰기의 순서를 변경할 수 없습니다.
///  - [`Release`] 를 사용하면 선행 읽기 및 쓰기를 후속 쓰기 이후로 이동할 수 없습니다.
///  - [`Acquire`] 를 사용하면 후속 읽기 및 쓰기를 이전 읽기보다 먼저 이동할 수 없습니다.
///  - [`AcqRel`] 에서는 위의 두 규칙이 모두 적용됩니다.
///
/// `compiler_fence` 일반적으로 스레드가 *자신과* 경주하는 것을 방지하는 데만 유용합니다.즉, 주어진 스레드가 코드 한 조각을 실행 한 다음 중단되고 다른 곳에서 코드 실행을 시작하는 경우 (동일한 스레드에 있고 개념적으로는 여전히 동일한 코어에 있음).기존 프로그램에서는 신호 처리기가 등록 된 경우에만 발생할 수 있습니다.
/// 더 낮은 수준의 코드에서 이러한 상황은 인터럽트를 처리 할 때, 선점으로 녹색 스레드를 구현할 때도 발생할 수 있습니다.
/// 호기심 많은 독자들은 [memory barriers] 에 대한 Linux 커널의 토론을 읽어 보시기 바랍니다.
///
/// # Panics
///
/// `order` 가 [`Relaxed`] 이면 Panics 입니다.
///
/// # Examples
///
/// `compiler_fence` 가 없으면 다음 코드의 `assert_eq!` 가 단일 스레드에서 모든 일이 발생하더라도 성공을 보장하지 *않습니다*.
/// 이유를 확인하려면 컴파일러가 저장소를 `IMPORTANT_VARIABLE` 및 `IS_READ` 로 자유롭게 바꿀 수 있습니다. 둘 다 `Ordering::Relaxed` 이기 때문입니다.그렇다면 `IS_READY` 가 업데이트 된 직후에 신호 처리기가 호출되면 신호 처리기는 `IS_READY=1` 가 표시되지만 `IMPORTANT_VARIABLE=0` 가 표시됩니다.
/// `compiler_fence` 를 사용하면이 상황을 해결할 수 있습니다.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // 이전 쓰기가이 지점 이상으로 이동하지 못하도록 방지
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // 안전: 원자 울타리를 사용하는 것이 안전합니다.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// 프로세서가 busy-wait 스핀 루프 ("스핀 잠금") 내에 있음을 알립니다.
///
/// 이 함수 대신 [`hint::spin_loop`] 가 사용됩니다.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}