//! 오버로드 가능한 연산자.
//!
//! 이러한 traits 를 구현하면 특정 연산자를 오버로드 할 수 있습니다.
//!
//! 이러한 traits 중 일부는 prelude 에서 가져 오기 때문에 모든 Rust 프로그램에서 사용할 수 있습니다.traits 가 지원하는 연산자 만 오버로드 할 수 있습니다.
//! 예를 들어 덧셈 연산자 (`+`) 는 [`Add`] trait 를 통해 오버로드 될 수 있지만 할당 연산자 (`=`) 에는 지원 trait 가 없으므로 의미를 오버로드 할 방법이 없습니다.
//! 또한이 모듈은 새 연산자를 만드는 메커니즘을 제공하지 않습니다.
//! 트레이 트없는 오버로딩 또는 사용자 정의 연산자가 필요한 경우 매크로 또는 컴파일러 플러그인을 찾아 Rust 의 구문을 확장해야합니다.
//!
//! 연산자 traits 의 구현은 일반적인 의미와 [operator precedence] 를 염두에두고 각 컨텍스트에서 놀랍지 않아야합니다.
//! 예를 들어 [`Mul`] 를 구현할 때 연산은 곱셈과 유사해야합니다 (그리고 연관성과 같은 예상 속성을 공유).
//!
//! `&&` 및 `||` 연산자는 단락됩니다. 즉, 결과에 기여하는 경우에만 두 번째 피연산자를 평가합니다.이 동작은 traits 에서 적용 할 수 없으므로 `&&` 및 `||` 는 오버로드 가능한 연산자로 지원되지 않습니다.
//!
//! 많은 연산자는 값으로 피연산자를 사용합니다.기본 제공 유형이 포함 된 비 제네릭 컨텍스트에서는 일반적으로 문제가되지 않습니다.
//! 그러나 일반 코드에서 이러한 연산자를 사용하면 연산자가 값을 소비하는 대신 값을 재사용해야하는 경우주의가 필요합니다.한 가지 옵션은 가끔 [`clone`] 를 사용하는 것입니다.
//! 또 다른 옵션은 참조에 대한 추가 연산자 구현을 제공하는 관련 유형에 의존하는 것입니다.
//! 예를 들어, 추가를 지원해야하는 사용자 정의 유형 `T` 의 경우 불필요한 복제없이 일반 코드를 작성할 수 있도록 `T` 와 `&T` 모두 traits [`Add<T>`][`Add`] 및 [`Add<&T>`][`Add`] 를 구현하는 것이 좋습니다.
//!
//!
//! # Examples
//!
//! 이 예제에서는 [`Add`] 및 [`Sub`] 를 구현하는 `Point` 구조체를 만든 다음 두 개의 'Point'를 더하고 빼는 방법을 보여줍니다.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! 구현 예는 각 trait 에 대한 설명서를 참조하십시오.
//!
//! [`Fn`], [`FnMut`] 및 [`FnOnce`] traits 는 함수처럼 호출 할 수있는 유형으로 구현됩니다.[`Fn`] 는 `&self`, [`FnMut`] 는 `&mut self`, [`FnOnce`] 는 `self` 를 사용합니다.
//! 이는 인스턴스에서 호출 할 수있는 세 가지 유형의 메서드 인 참조 별 호출, 변경 가능한 참조 별 호출 및 값별 호출에 해당합니다.
//! 이러한 traits 의 가장 일반적인 용도는 함수 또는 클로저를 인수로 사용하는 상위 수준 함수에 대한 경계 역할을하는 것입니다.
//!
//! [`Fn`] 를 매개 변수로 사용 :
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] 를 매개 변수로 사용 :
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] 를 매개 변수로 사용 :
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` 캡처 된 변수를 사용하므로 두 번 이상 실행할 수 없습니다.
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` 를 다시 호출하려고하면 `func` 에 대한 `use of moved value` 오류가 발생합니다.
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` 이 시점에서 더 이상 호출 할 수 없습니다.
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;