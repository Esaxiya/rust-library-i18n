/// 소멸자 내의 사용자 지정 코드.
///
/// 값이 더 이상 필요하지 않으면 Rust 는 해당 값에 대해 "destructor" 를 실행합니다.
/// 값이 더 이상 필요하지 않은 가장 일반적인 방법은 범위를 벗어날 때입니다.소멸자는 여전히 다른 상황에서 실행될 수 있지만 여기서 예제의 범위에 초점을 맞출 것입니다.
/// 다른 경우에 대해 알아 보려면 소멸자에 대한 [the reference] 섹션을 참조하십시오.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// 이 소멸자는 두 가지 구성 요소로 구성됩니다.
/// - 해당 유형에 대해이 특수 `Drop` trait 가 구현 된 경우 해당 값에 대한 `Drop::drop` 호출.
/// - 이 값의 모든 필드의 소멸자를 재귀 적으로 호출하는 자동 생성 "drop glue" 입니다.
///
/// Rust 는 포함 된 모든 필드의 소멸자를 자동으로 호출하므로 대부분의 경우 `Drop` 를 구현할 필요가 없습니다.
/// 그러나 리소스를 직접 관리하는 유형과 같이 유용한 경우가 있습니다.
/// 그 리소스는 메모리 일 수도 있고 파일 디스크립터 일 수도 있고 네트워크 소켓 일 수도 있습니다.
/// 해당 유형의 값이 더 이상 사용되지 않으면 메모리를 해제하거나 파일 또는 소켓을 닫아 리소스를 "clean up" 해야합니다.
/// 이것은 소멸자의 작업이므로 `Drop::drop` 의 작업입니다.
///
/// ## Examples
///
/// 작동중인 소멸자를 보려면 다음 프로그램을 살펴 보겠습니다.
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust 는 먼저 `_x` 에 대해 `Drop::drop` 를 호출 한 다음 `_x.one` 와 `_x.two` 모두에 대해 호출합니다.
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// `HasTwoDrop` 용 `Drop` 구현을 제거하더라도 해당 필드의 소멸자는 여전히 호출됩니다.
/// 이로 인해
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop` 를 직접 호출 할 수 없습니다.
///
/// `Drop::drop` 는 값을 정리하는 데 사용되기 때문에 메서드가 호출 된 후이 값을 사용하는 것은 위험 할 수 있습니다.
/// `Drop::drop` 는 입력에 대한 소유권을 갖지 않으므로 Rust 는 `Drop::drop` 를 직접 호출하지 못하도록하여 오용을 방지합니다.
///
/// 즉, 위의 예에서 `Drop::drop` 를 명시 적으로 호출하려고하면 컴파일러 오류가 발생합니다.
///
/// 값의 소멸자를 명시 적으로 호출하려면 [`mem::drop`] 를 대신 사용할 수 있습니다.
///
/// [`mem::drop`]: drop
///
/// ## 드롭 주문
///
/// 하지만 두 `HasDrop` 중 어느 것이 먼저 떨어질까요?구조체의 경우 선언 된 순서와 동일합니다. 먼저 `one`, `two` 순입니다.
/// 직접 해보고 싶다면 정수와 같은 일부 데이터를 포함하도록 위의 `HasDrop` 를 수정 한 다음 `Drop` 내부의 `println!` 에서 사용할 수 있습니다.
/// 이 동작은 언어에 의해 보장됩니다.
///
/// 구조체와 달리 지역 변수는 역순으로 삭제됩니다.
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// 이것은 인쇄됩니다
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// 전체 규칙은 [the reference] 를 참조하십시오.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` `Drop` 는 배타적입니다.
///
/// 동일한 유형에서 [`Copy`] 와 `Drop` 를 모두 구현할 수 없습니다.`Copy` 유형은 컴파일러에 의해 암시 적으로 복제되므로 소멸자가 실행되는시기와 빈도를 예측하기가 매우 어렵습니다.
///
/// 따라서 이러한 유형은 소멸자를 가질 수 없습니다.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// 이 유형의 소멸자를 실행합니다.
    ///
    /// 이 메서드는 값이 범위를 벗어날 때 암시 적으로 호출되며 명시 적으로 호출 할 수 없습니다 (컴파일러 오류 [E0040]).
    /// 그러나 prelude 의 [`mem::drop`] 함수는 인수의 `Drop` 구현을 호출하는 데 사용할 수 있습니다.
    ///
    /// 이 메서드가 호출되었을 때 `self` 는 아직 할당 해제되지 않았습니다.
    /// 그것은 방법이 끝난 후에 만 발생합니다.
    /// 그렇지 않은 경우 `self` 는 매달린 참조가됩니다.
    ///
    /// # Panics
    ///
    /// [`panic!`] 가 풀릴 때 `drop` 를 호출한다는 점을 감안할 때 `drop` 구현의 모든 [`panic!`] 는 중단 될 가능성이 높습니다.
    ///
    /// 이 panics 이더라도 값은 삭제 된 것으로 간주됩니다.
    /// `drop` 를 다시 호출하지 않아야합니다.
    /// 이는 일반적으로 컴파일러에 의해 자동으로 처리되지만 안전하지 않은 코드를 사용할 때 특히 [`ptr::drop_in_place`] 를 사용할 때 의도하지 않게 발생할 수 있습니다.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}