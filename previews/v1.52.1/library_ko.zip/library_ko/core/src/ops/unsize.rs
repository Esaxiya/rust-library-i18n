use crate::marker::Unsize;

/// Trait 는 이것이 포인터 또는 포인터에 대한 래퍼임을 나타내며, pointee에서 크기 조정을 수행 할 수 있습니다.
///
/// 자세한 내용은 [DST coercion RFC][dst-coerce] 및 [the nomicon entry on coercion][nomicon-coerce] 를 참조하십시오.
///
/// 내장 포인터 유형의 경우 `T` 에 대한 포인터는 얇은 포인터에서 팻 포인터로 변환하여 `T: Unsize<U>` 인 경우 `U` 에 대한 포인터로 강제 변환됩니다.
///
/// 사용자 정의 유형의 경우 여기에서 강제 변환은 `CoerceUnsized<Foo<U>> for Foo<T>` 의 impl이 존재하는 경우 `Foo<T>` 를 `Foo<U>` 로 강제 변환하여 작동합니다.
/// 이러한 impl은 `Foo<T>` 에 `T` 와 관련된 하나의 팬텀 데이터가 아닌 필드 만있는 경우에만 작성할 수 있습니다.
/// 해당 필드의 유형이 `Bar<T>` 이면 `CoerceUnsized<Bar<U>> for Bar<T>` 구현이 존재해야합니다.
/// 강제 변환은 `Bar<T>` 필드를 `Bar<U>` 로 강제 변환하고 `Foo<T>` 의 나머지 필드를 채워 `Foo<U>` 를 만드는 방식으로 작동합니다.
/// 이렇게하면 포인터 필드로 효과적으로 드릴 다운하여 강제 할 수 있습니다.
///
/// 일반적으로 스마트 포인터의 경우 `T` 자체에 바인딩 된 선택적 `?Sized` 와 함께 `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` 를 구현합니다.
/// `Cell<T>` 및 `RefCell<T>` 와 같이 `T` 를 직접 포함하는 래퍼 유형의 경우 `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` 를 직접 구현할 수 있습니다.
///
/// 이렇게하면 `Cell<Box<T>>` 와 같은 유형의 강제가 작동합니다.
///
/// [`Unsize`][unsize] 포인터 뒤에있는 경우 DST로 강제 변환 될 수있는 유형을 표시하는 데 사용됩니다.컴파일러에 의해 자동으로 구현됩니다.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * 뮤트 U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// 이것은 메소드의 수신자 유형이 디스패치 될 수 있는지 확인하기 위해 객체 안전에 사용됩니다.
///
/// trait 의 구현 예 :
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}