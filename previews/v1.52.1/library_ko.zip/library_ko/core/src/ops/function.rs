/// 변경 불가능한 수신자를받는 호출 연산자의 버전입니다.
///
/// `Fn` 의 인스턴스는 상태를 변경하지 않고 반복적으로 호출 할 수 있습니다.
///
/// *이 trait (`Fn`) 를 [function pointers] (`fn`) 와 혼동하지 마십시오.*
///
/// `Fn` (safe) [function pointers] 뿐만 아니라 캡처 된 변수에 대한 변경 불가능한 참조 만 취하거나 전혀 캡처하지 않는 클로저에 의해 자동으로 구현됩니다 (자세한 내용은 설명서를 참조하십시오).
///
/// 또한 `Fn` 를 구현하는 `F` 유형의 경우 `&F` 도 `Fn` 를 구현합니다.
///
/// [`FnMut`] 와 [`FnOnce`] 는 모두 `Fn` 의 상위 특성이므로 `Fn` 의 모든 인스턴스는 [`FnMut`] 또는 [`FnOnce`] 가 예상되는 매개 변수로 사용할 수 있습니다.
///
/// 함수와 같은 유형의 매개 변수를 허용하고 상태를 변경하지 않고 반복적으로 호출해야하는 경우 (예: 동시에 호출 할 때) `Fn` 를 경계로 사용하십시오.
/// 이러한 엄격한 요구 사항이 필요하지 않은 경우 [`FnMut`] 또는 [`FnOnce`] 를 경계로 사용하십시오.
///
/// 이 주제에 대한 자세한 정보는 [chapter on closures in *The Rust Programming Language*][book] 를 참조하십시오.
///
/// 또한 `Fn` traits 의 특수 구문 (예 :
/// `Fn(usize, bool) -> usize`).이것의 기술적 세부 사항에 관심이있는 사람들은 [the relevant section in the *Rustonomicon*][nomicon] 를 참조 할 수 있습니다.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## 클로저 호출
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` 매개 변수 사용
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // regex 가 `&str: !FnMut` 를 신뢰할 수 있도록
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// 통화 작업을 수행합니다.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// 변경 가능한 수신기를받는 호출 연산자의 버전입니다.
///
/// `FnMut` 의 인스턴스는 반복적으로 호출 될 수 있으며 상태를 변경할 수 있습니다.
///
/// `FnMut` 캡처 된 변수에 대한 변경 가능한 참조와 [`Fn`] 를 구현하는 모든 유형 (예: (safe) [function pointers])을 사용하는 클로저에 의해 자동으로 구현됩니다 (`FnMut` 는 [`Fn`] 의 상위 특성이므로).
/// 또한 `FnMut` 를 구현하는 `F` 유형의 경우 `&mut F` 도 `FnMut` 를 구현합니다.
///
/// [`FnOnce`] 는 `FnMut` 의 상위 특성이므로 [`FnOnce`] 가 예상되는 곳에 `FnMut` 의 모든 인스턴스를 사용할 수 있으며 [`Fn`] 는 `FnMut` 의 하위 특성이므로 `FnMut` 가 예상되는 곳에 [`Fn`] 의 모든 인스턴스를 사용할 수 있습니다.
///
/// 함수와 같은 유형의 매개 변수를 받아들이고이를 반복적으로 호출해야하는 경우 `FnMut` 를 경계로 사용하여 상태를 변경할 수 있습니다.
/// 매개 변수가 상태를 변경하지 않도록하려면 [`Fn`] 를 경계로 사용하십시오.반복적으로 호출 할 필요가 없으면 [`FnOnce`] 를 사용하십시오.
///
/// 이 주제에 대한 자세한 정보는 [chapter on closures in *The Rust Programming Language*][book] 를 참조하십시오.
///
/// 또한 `Fn` traits 의 특수 구문 (예 :
/// `Fn(usize, bool) -> usize`).이것의 기술적 세부 사항에 관심이있는 사람들은 [the relevant section in the *Rustonomicon*][nomicon] 를 참조 할 수 있습니다.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## 가변 캡처 클로저 호출
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` 매개 변수 사용
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // regex 가 `&str: !FnMut` 를 신뢰할 수 있도록
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// 통화 작업을 수행합니다.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// 값별 수신자를 취하는 호출 연산자의 버전입니다.
///
/// `FnOnce` 의 인스턴스는 호출 할 수 있지만 여러 번 호출 할 수는 없습니다.이 때문에 타입에 대해 알려진 유일한 것이 `FnOnce` 를 구현하는 것이라면 한 번만 호출 할 수 있습니다.
///
/// `FnOnce` 캡처 된 변수를 사용할 수있는 클로저와 [`FnMut`] 를 구현하는 모든 유형 (예: (safe) [function pointers])에 의해 자동으로 구현됩니다 (`FnOnce` 는 [`FnMut`] 의 상위 특성이므로).
///
///
/// [`Fn`] 와 [`FnMut`] 는 모두 `FnOnce` 의 하위 특성이므로 `FnOnce` 가 예상되는 곳에 [`Fn`] 또는 [`FnMut`] 의 모든 인스턴스를 사용할 수 있습니다.
///
/// 함수와 같은 유형의 매개 변수를 허용하고 한 번만 호출하면되는 경우 `FnOnce` 를 경계로 사용하십시오.
/// 매개 변수를 반복적으로 호출해야하는 경우 [`FnMut`] 를 경계로 사용하십시오.상태를 변경하지 않으려면 [`Fn`] 를 사용하십시오.
///
/// 이 주제에 대한 자세한 정보는 [chapter on closures in *The Rust Programming Language*][book] 를 참조하십시오.
///
/// 또한 `Fn` traits 의 특수 구문 (예 :
/// `Fn(usize, bool) -> usize`).이것의 기술적 세부 사항에 관심이있는 사람들은 [the relevant section in the *Rustonomicon*][nomicon] 를 참조 할 수 있습니다.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` 매개 변수 사용
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` 캡처 된 변수를 사용하므로 두 번 이상 실행할 수 없습니다.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` 를 다시 호출하려고하면 `func` 에 대한 `use of moved value` 오류가 발생합니다.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` 이 시점에서 더 이상 호출 할 수 없습니다.
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // regex 가 `&str: !FnMut` 를 신뢰할 수 있도록
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// 호출 연산자가 사용 된 후 반환되는 유형입니다.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// 통화 작업을 수행합니다.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}