use crate::marker::Unpin;
use crate::pin::Pin;

/// 발전기 재개 결과.
///
/// 이 열거 형은 `Generator::resume` 메서드에서 반환되며 생성기의 가능한 반환 값을 나타냅니다.
/// 현재 이것은 서스펜션 지점 (`Yielded`) 또는 종료 지점 (`Complete`) 에 해당합니다.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// 생성기는 값으로 중단되었습니다.
    ///
    /// 이 상태는 생성기가 일시 중지되었음을 나타내며 일반적으로 `yield` 문에 해당합니다.
    /// 이 변형에 제공된 값은 `yield` 에 전달 된 표현식에 해당하며 생성자가 산출 할 때마다 값을 제공 할 수 있도록합니다.
    ///
    ///
    Yielded(Y),

    /// 생성기가 반환 값으로 완료되었습니다.
    ///
    /// 이 상태는 생성기가 제공된 값으로 실행을 완료했음을 나타냅니다.
    /// 생성기가 `Complete` 를 반환하면 `resume` 를 다시 호출하는 것은 프로그래머 오류로 간주됩니다.
    ///
    Complete(R),
}

/// 내장 생성기 유형으로 구현 된 trait 입니다.
///
/// 일반적으로 코 루틴이라고도하는 생성기는 현재 Rust 의 실험적인 언어 기능입니다.
/// [RFC 2033] 생성기에 추가 된 것은 현재 주로 async/await 구문에 대한 빌딩 블록을 제공하기위한 것이지만 반복기 및 기타 기본 요소에 대한 인체 공학적 정의도 제공하도록 확장 될 것입니다.
///
///
/// 생성기의 구문과 의미는 불안정하며 안정화를 위해 추가 RFC가 필요합니다.그러나 현재 구문은 클로저와 유사합니다.
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// 생성기에 대한 더 많은 문서는 불안정한 책에서 찾을 수 있습니다.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// 이 생성기가 산출하는 값의 유형입니다.
    ///
    /// 이 관련 유형은 `yield` 표현식 및 생성기가 양보 할 때마다 반환 될 수있는 값에 해당합니다.
    ///
    /// 예를 들어 생성자로서의 반복자는이 유형을 `T` 로 가질 가능성이 높으며 유형은 반복됩니다.
    ///
    type Yield;

    /// 이 생성기가 반환하는 값의 유형입니다.
    ///
    /// 이는 `return` 문을 사용하거나 생성기 리터럴의 마지막 표현식으로 암시 적으로 생성기에서 반환 된 유형에 해당합니다.
    /// 예를 들어 futures 는 완료된 future 를 나타내므로 이것을 `Result<T, E>` 로 사용합니다.
    ///
    ///
    type Return;

    /// 이 생성기의 실행을 재개합니다.
    ///
    /// 이 함수는 생성기 실행을 다시 시작하거나 아직 실행하지 않은 경우 실행을 시작합니다.
    /// 이 호출은 생성기의 마지막 일시 중지 지점으로 돌아가서 최신 `yield` 에서 실행을 다시 시작합니다.
    /// 생성기는 양보하거나 반환 할 때까지 계속 실행되며이 지점에서이 함수가 반환됩니다.
    ///
    /// # 반환 값
    ///
    /// 이 함수에서 반환 된 `GeneratorState` 열거 형은 반환시 생성기가 어떤 상태인지를 나타냅니다.
    /// `Yielded` 변형이 반환되면 발전기가 정지 지점에 도달하고 값이 산출 된 것입니다.
    /// 이 상태의 생성기는 나중에 재개 할 수 있습니다.
    ///
    /// `Complete` 가 반환되면 생성기는 제공된 값으로 완전히 완료된 것입니다.생성기를 다시 재개하는 것은 유효하지 않습니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 이전에 `Complete` 변형이 반환 된 후 호출되면 panic 가 될 수 있습니다.
    /// 언어의 생성기 리터럴은 `Complete` 이후 재개시 panic 로 보장되지만 `Generator` trait 의 모든 구현에 대해 보장되지는 않습니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}