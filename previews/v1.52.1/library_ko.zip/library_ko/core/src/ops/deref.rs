/// `*v` 와 같은 변경 불가능한 역 참조 작업에 사용됩니다.
///
/// 변경 불가능한 컨텍스트에서 (unary) `*` 연산자를 사용하여 명시 적 역 참조 작업에 사용되는 것 외에도 `Deref` 는 여러 상황에서 컴파일러에 의해 암시 적으로 사용됩니다.
/// 이 메커니즘을 ['`Deref` coercion'][more] 라고합니다.
/// 가변 컨텍스트에서는 [`DerefMut`] 가 사용됩니다.
///
/// 스마트 포인터 용 `Deref` 를 구현하면 뒤에있는 데이터에 편리하게 액세스 할 수 있으므로 `Deref` 를 구현합니다.
/// 반면에 `Deref` 및 [`DerefMut`] 에 관한 규칙은 스마트 포인터를 수용하도록 특별히 설계되었습니다.
/// 이 때문에 **`Deref`는 혼동을 피하기 위해 스마트 포인터** 에 대해서만 구현되어야합니다.
///
/// 비슷한 이유로 **이 trait 는 절대 실패하지 않아야합니다**.역 참조 중 실패는 `Deref` 가 암시 적으로 호출 될 때 매우 혼란 스러울 수 있습니다.
///
/// # `Deref` 강제에 대한 추가 정보
///
/// `T` 가 `Deref<Target = U>` 를 구현하고 `x` 가 `T` 유형의 값인 경우 :
///
/// * 변경 불가능한 컨텍스트에서 `*x` (`T` 는 참조도 아니고 원시 포인터도 아님)는 `* Deref::deref(&x)` 와 동일합니다.
/// * `&T` 유형의 값은 `&U` 유형의 값으로 강제 변환됩니다.
/// * `T` `U` 유형의 모든 (immutable) 메서드를 암시 적으로 구현합니다.
///
/// 자세한 내용은 [the chapter in *The Rust Programming Language*][book] 와 [the dereference operator][ref-deref-op], [method resolution] 및 [type coercions] 에 대한 참조 섹션을 참조하십시오.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 구조체를 역 참조하여 액세스 할 수있는 단일 필드가있는 구조체입니다.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// 역 참조 후 결과 유형입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// 값을 역 참조합니다.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` 에서와 같이 변경 가능한 역 참조 작업에 사용됩니다.
///
/// 변경 가능한 컨텍스트에서 (unary) `*` 연산자를 사용하여 명시 적 역 참조 작업에 사용되는 것 외에도 `DerefMut` 는 많은 상황에서 컴파일러에 의해 암시 적으로 사용됩니다.
/// 이 메커니즘을 ['`Deref` coercion'][more] 라고합니다.
/// 변경 불가능한 컨텍스트에서는 [`Deref`] 가 사용됩니다.
///
/// 스마트 포인터를 위해 `DerefMut` 를 구현하면 뒤에있는 데이터를 편리하게 변형 할 수 있으므로 `DerefMut` 를 구현합니다.
/// 반면에 [`Deref`] 및 `DerefMut` 에 관한 규칙은 스마트 포인터를 수용하도록 특별히 설계되었습니다.
/// 이 때문에 **`DerefMut`은 혼동을 피하기 위해 스마트 포인터에 대해서만 구현되어야합니다**.
///
/// 비슷한 이유로 **이 trait 는 절대 실패하지 않아야합니다**.역 참조 중 실패는 `DerefMut` 가 암시 적으로 호출 될 때 매우 혼란 스러울 수 있습니다.
///
/// # `Deref` 강제에 대한 추가 정보
///
/// `T` 가 `DerefMut<Target = U>` 를 구현하고 `x` 가 `T` 유형의 값인 경우 :
///
/// * 변경 가능한 컨텍스트에서 `*x` (여기서 `T` 는 참조도 아니고 원시 포인터도 아님)는 `* DerefMut::deref_mut(&mut x)` 와 동일합니다.
/// * `&mut T` 유형의 값은 `&mut U` 유형의 값으로 강제 변환됩니다.
/// * `T` `U` 유형의 모든 (mutable) 메서드를 암시 적으로 구현합니다.
///
/// 자세한 내용은 [the chapter in *The Rust Programming Language*][book] 와 [the dereference operator][ref-deref-op], [method resolution] 및 [type coercions] 에 대한 참조 섹션을 참조하십시오.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 구조체를 역 참조하여 수정할 수있는 단일 필드가있는 구조체입니다.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// 값을 상호 참조 해제합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` 기능없이 구조체를 메서드 수신기로 사용할 수 있음을 나타냅니다.
///
/// 이것은 `Box<T>`, `Rc<T>`, `&T` 및 `Pin<P>` 와 같은 stdlib 포인터 유형에 의해 구현됩니다.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}