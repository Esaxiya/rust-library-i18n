/// `?` 연산자의 동작을 사용자 정의하기위한 trait 입니다.
///
/// `Try` 를 구현하는 유형은 success/failure 이분법으로 볼 수있는 표준 방식을 가진 유형입니다.
/// 이 trait 를 사용하면 기존 인스턴스에서 성공 또는 실패 값을 추출하고 성공 또는 실패 값에서 새 인스턴스를 만들 수 있습니다.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// 성공한 것으로 볼 때이 값의 유형입니다.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// 실패한 것으로 볼 때이 값의 유형입니다.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" 연산자를 적용합니다.`Ok(t)` 가 반환되면 실행이 정상적으로 계속되어야하며 `?` 의 결과는 `t` 값입니다.
    /// `Err(e)` 가 반환되면 실행이 branch 가 가장 안쪽에있는 `catch` 로 돌아가거나 함수에서 반환되어야 함을 의미합니다.
    ///
    /// `Err(e)` 결과가 반환되면 바깥 쪽 범위의 반환 유형에서 `e` 값은 "wrapped" 가됩니다 (이는 자체적으로 `Try` 를 구현해야 함).
    ///
    /// 특히 값 `X::from_error(From::from(e))` 가 반환됩니다. 여기서 `X` 는 둘러싸는 함수의 반환 유형입니다.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// 복합 결과를 구성하기 위해 오류 값을 래핑합니다.
    /// 예를 들어 `Result::Err(x)` 와 `Result::from_error(x)` 는 동일합니다.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// OK 값을 래핑하여 합성 결과를 생성합니다.
    /// 예를 들어 `Result::Ok(x)` 와 `Result::from_ok(x)` 는 동일합니다.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}