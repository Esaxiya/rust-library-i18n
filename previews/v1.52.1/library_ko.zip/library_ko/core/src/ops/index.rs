/// 변경 불가능한 컨텍스트에서 (`container[index]`) 작업을 인덱싱하는 데 사용됩니다.
///
/// `container[index]` 실제로 `*container.index(index)` 의 구문 설탕이지만 변경 불가능한 값으로 사용되는 경우에만 해당됩니다.
/// 변경 가능한 값이 요청되면 [`IndexMut`] 가 대신 사용됩니다.
/// 이것은 `value` 유형이 [`Copy`] 를 구현하는 경우 `let value = v[index]` 와 같은 멋진 것들을 허용합니다.
///
/// # Examples
///
/// 다음 예제는 읽기 전용 `NucleotideCount` 컨테이너에서 `Index` 를 구현하여 인덱스 구문으로 개별 개수를 검색 할 수 있도록합니다.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// 인덱싱 후 반환 된 유형입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// 인덱싱 (`container[index]`) 작업을 수행합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// 가변 컨텍스트에서 (`container[index]`) 작업을 인덱싱하는 데 사용됩니다.
///
/// `container[index]` 실제로 `*container.index_mut(index)` 의 구문 설탕이지만 변경 가능한 값으로 사용되는 경우에만 해당됩니다.
/// 변경 불가능한 값이 요청되면 [`Index`] trait 가 대신 사용됩니다.
/// 이것은 `v[index] = value` 와 같은 좋은 것들을 허용합니다.
///
/// # Examples
///
/// 두 변이있는 `Balance` 구조체의 매우 간단한 구현으로, 각 변이 변경 가능하고 변경 불가능하게 인덱싱 될 수 있습니다.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // 이 경우 `balance[Side::Right]` 는 `*balance.index(Side::Right)` 의 설탕입니다. 왜냐하면 우리는 `balance[Side::Right]` 를 쓰지 않고* 읽고 * 있기 때문입니다.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // 그러나이 경우 `balance[Side::Left]` 를 작성하고 있으므로 `balance[Side::Left]` 는 `*balance.index_mut(Side::Left)` 의 설탕입니다.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// 가변 인덱싱 (`container[index]`) 작업을 수행합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}