//! 문자열 형식화 및 인쇄를위한 유틸리티.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` 에서 반환 된 가능한 정렬
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// 내용이 왼쪽 정렬되어야 함을 나타냅니다.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// 내용이 오른쪽 정렬되어야 함을 나타냅니다.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// 내용이 가운데 정렬되어야 함을 나타냅니다.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// 포맷터 메서드에서 반환 된 형식입니다.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// 메시지를 스트림으로 형식화하여 리턴되는 오류 유형입니다.
///
/// 이 유형은 오류가 발생한 것 이외의 오류 전송을 지원하지 않습니다.
/// 추가 정보는 다른 수단을 통해 전송되도록 조정되어야합니다.
///
/// 기억해야 할 중요한 점은 `fmt::Error` 유형을 범위에 포함 할 수있는 [`std::io::Error`] 또는 [`std::error::Error`] 와 혼동해서는 안된다는 것입니다.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// 유니 코드 허용 버퍼 또는 스트림에 쓰거나 형식화하기위한 trait 입니다.
///
/// 이 trait 는 UTF-8로 인코딩 된 데이터 만 허용하며 [flushable] 가 아닙니다.
/// 유니 코드 만 허용하고 플러싱이 필요하지 않은 경우이 trait 를 구현해야합니다.
/// 그렇지 않으면 [`std::io::Write`] 를 구현해야합니다.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// 쓰기 성공 여부를 반환하는이 라이터에 문자열 조각을 씁니다.
    ///
    /// 이 메서드는 전체 문자열 조각이 성공적으로 기록 된 경우에만 성공할 수 있으며 모든 데이터가 기록되거나 오류가 발생할 때까지이 메서드는 반환되지 않습니다.
    ///
    ///
    /// # Errors
    ///
    /// 이 함수는 오류시 [`Error`] 의 인스턴스를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// [`char`] 를이 라이터에 기록하고 쓰기 성공 여부를 반환합니다.
    ///
    /// 단일 [`char`] 는 둘 이상의 바이트로 인코딩 될 수 있습니다.
    /// 이 메서드는 전체 바이트 시퀀스가 성공적으로 기록 된 경우에만 성공할 수 있으며 모든 데이터가 기록되거나 오류가 발생할 때까지이 메서드는 반환되지 않습니다.
    ///
    ///
    /// # Errors
    ///
    /// 이 함수는 오류시 [`Error`] 의 인스턴스를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// 이 trait 의 구현 자와 함께 [`write!`] 매크로를 사용하기위한 접착제입니다.
    ///
    /// 이 메서드는 일반적으로 수동으로 호출하는 것이 아니라 [`write!`] 매크로 자체를 통해 호출해야합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// 포맷을위한 구성.
///
/// `Formatter` 는 서식과 관련된 다양한 옵션을 나타냅니다.
/// 사용자는`포맷터`를 직접 구성하지 않습니다.하나에 대한 변경 가능한 참조는 [`Debug`] 및 [`Display`] 와 같은 모든 형식 traits 의 `fmt` 메서드에 전달됩니다.
///
///
/// `Formatter` 와 상호 작용하려면 다양한 메서드를 호출하여 서식과 관련된 다양한 옵션을 변경합니다.
/// 예를 들어, 아래 `Formatter` 에 정의 된 메서드의 문서를 참조하십시오.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// 인수는 기본적으로 `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` 에 해당하는 최적화 된 부분 적용 형식 지정 함수입니다.

extern "C" {
    type Opaque;
}

/// 이 구조체는 Xprintf 함수 제품군에서 사용하는 일반 "argument" 를 나타냅니다.주어진 값을 형식화하는 함수를 포함합니다.
/// 컴파일 타임에 함수와 값의 형식이 올바른지 확인한 다음이 구조체를 사용하여 인수를 한 형식으로 정규화합니다.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// 이것은 형식화 인프라에서 indices/counts 와 연관된 함수 포인터에 대해 하나의 안정된 값을 보장합니다.
//
// 이렇게 정의 된 함수는 항상 unnamed_addr 태그가 지정되고 현재는 LLVM IR로 낮아 지므로 해당 주소는 LLVM에 중요하지 않으며 as_usize 캐스트가 잘못 컴파일되었을 수 있습니다.
//
// 실제로, 사용하지 않는 데이터를 포함하는 데이터에 대해 as_usize를 호출하지 않습니다 (포맷 인수의 정적 생성 문제로).
//
// 우리는 주로 `USIZE_MARKER` 의 함수 포인터가 `&usize` 를 첫 번째 인수로 사용하는 함수에 *only* 에 해당하는 주소를 갖도록하고 싶습니다.
// 여기서 read_volatile은 전달 된 참조에서 사용을 안전하게 준비 할 수 있고이 주소가 사용하지 않는 함수를 가리 키지 않도록합니다.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // 안전: ptr은 참조입니다.
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // 안전: `mem::transmute(x)` 는 안전합니다.
        //     1. `&'b T` `'b` 에서 시작된 수명을 유지합니다 (무제한 수명을 갖지 않도록).
        //     2.
        //     `&'b T` `&'b Opaque` 는 동일한 메모리 레이아웃을 갖습니다 (`T` 가 `Sized` 인 경우 여기에 있음). `fn(&T, &mut Formatter<'_>) -> Result` 와 `fn(&Opaque, &mut Formatter<'_>) -> Result` 는 동일한 ABI를 갖기 때문에 `mem::transmute(f)` 는 안전합니다 (`T` 가 `Sized` 인 한).
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // 안전: `formatter` 필드는 다음과 같은 경우에만 USIZE_MARKER로 설정됩니다.
            // 가치는 usize이므로 이것은 안전합니다
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// format_args의 v1 형식에서 사용 가능한 플래그
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// format_args! () 매크로를 사용할 때이 함수는 Arguments 구조를 생성하는 데 사용됩니다.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// 이 함수는 비표준 형식화 매개 변수를 지정하는 데 사용됩니다.
    /// `pieces` 배열은 유효한 Arguments 구조를 구성하기 위해 최소한 `fmt` 이상이어야합니다.
    /// 또한 `CountIsParam` 또는 `CountIsNextParam` 인 `fmt` 내의 모든 `Count` 는 `argumentusize` 로 만든 인수를 가리켜 야합니다.
    ///
    /// 그러나 그렇게하지 않으면 안전하지 않지만 invalid는 무시됩니다.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// 서식이 지정된 텍스트의 길이를 추정합니다.
    ///
    /// `format!` 를 사용할 때 초기 `String` 용량을 설정하는 데 사용됩니다.
    /// Note: 이것은 하한도 아니고 상한도 아닙니다.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // 형식 문자열이 인수로 시작하는 경우 조각의 길이가 중요하지 않는 한 아무 것도 미리 할당하지 마십시오.
            //
            //
            0
        } else {
            // 몇 가지 인수가 있으므로 추가 푸시는 문자열을 재 할당합니다.
            //
            // 이를 피하기 위해 우리는 여기서 용량을 "pre-doubling" 입니다.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// 이 구조는 형식 문자열과 그 인수의 안전하게 미리 컴파일 된 버전을 나타냅니다.
/// 안전하게 수행 할 수 없기 때문에 런타임에 생성 할 수 없으므로 생성자가 제공되지 않으며 필드는 수정을 방지하기 위해 비공개입니다.
///
///
/// [`format_args!`] 매크로는이 구조의 인스턴스를 안전하게 생성합니다.
/// 매크로는 컴파일 타임에 형식 문자열의 유효성을 검사하므로 [`write()`] 및 [`format()`] 함수를 안전하게 사용할 수 있습니다.
///
/// 아래와 같이 [`format_args!`] 가 `Debug` 및 `Display` 컨텍스트에서 반환하는 `Arguments<'a>` 를 사용할 수 있습니다.
/// 이 예에서는 `Debug` 및 `Display` 형식이 동일한 것으로 표시됩니다. `format_args!` 의 보간 형식 문자열입니다.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // 인쇄 할 문자열 조각을 포맷합니다.
    pieces: &'a [&'static str],

    // 자리 표시 자 사양 또는 모든 사양이 기본값 인 경우 `None` ("{}{}" 에서와 같이).
    fmt: Option<&'a [rt::v1::Argument]>,

    // 보간을위한 동적 인수는 문자열 조각으로 인터리브됩니다.
    // (모든 인수 앞에는 문자열 조각이옵니다.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// 형식화 할 인수가없는 경우 형식화 된 문자열을 가져옵니다.
    ///
    /// 이것은 가장 사소한 경우 할당을 피하는 데 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` 프로그래머 용 디버깅 컨텍스트에서 출력 형식을 지정해야합니다.
///
/// 일반적으로 `derive` 는 `Debug` 구현 만해야합니다.
///
/// 대체 형식 지정자 `#?` 와 함께 사용하면 출력이 예쁘게 인쇄됩니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// 이 trait 는 모든 필드가 `Debug` 를 구현하는 경우 `#[derive]` 와 함께 사용할 수 있습니다.
/// 구조체에 대해 '파생'되면 `struct`, `{`, 각 필드의 이름과 `Debug` 값의 쉼표로 구분 된 목록, `}` 순으로 사용됩니다.
/// `enum`의 경우 변형 이름을 사용하고 해당되는 경우 `(`, 필드의 `Debug` 값, `)` 를 차례로 사용합니다.
///
/// # Stability
///
/// 파생 된 `Debug` 형식은 안정적이지 않으므로 future Rust 버전으로 변경 될 수 있습니다.
/// 또한 표준 라이브러리 (`libstd`, `libcore`, `liballoc` 등)에서 제공하는 유형의 `Debug` 구현은 안정적이지 않으며 future Rust 버전에서도 변경 될 수 있습니다.
///
///
/// # Examples
///
/// 구현 도출 :
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// 수동으로 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] 와 같은 수동 구현에 도움이되는 [`Formatter`] 구조체에는 여러 가지 도우미 메서드가 있습니다.
///
/// `Debug` `derive` 또는 [`Formatter`] 에서 디버그 빌더 API를 사용하는 구현은 대체 플래그를 사용하여 예쁜 인쇄를 지원합니다. `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` 로 예쁜 인쇄 :
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` 없이 prelude 에서 매크로 `Debug` 를 다시 내보내려면 모듈을 분리하십시오.
pub(crate) mod macros {
    /// trait `Debug` 의 impl을 생성하는 매크로를 유도합니다.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// 빈 형식의 경우 trait 형식, `{}`.
///
/// `Display` [`Debug`] 와 유사하지만 `Display` 는 사용자 용 출력이므로 파생 될 수 없습니다.
///
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// 유형에 `Display` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait 는 base-8 의 숫자로 출력 형식을 지정해야합니다.
///
/// 원시 부호있는 정수 (`i8` ~ `i128` 및 `isize`)의 경우 음수 값은 2의 보수 표현으로 형식이 지정됩니다.
///
///
/// 대체 플래그 인 `#` 는 출력 앞에 `0o` 를 추가합니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` 의 기본 사용법 :
///
/// ```
/// let x = 42; // 42는 8 진수로 '52' 입니다.
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// 유형에 `Octal` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 구현에 위임
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait 는 출력 형식을 2 진수 숫자로 지정해야합니다.
///
/// 원시 부호있는 정수 ([`i8`] ~ [`i128`] 및 [`isize`])의 경우 음수 값은 2의 보수 표현으로 형식이 지정됩니다.
///
///
/// 대체 플래그 인 `#` 는 출력 앞에 `0b` 를 추가합니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] 의 기본 사용법 :
///
/// ```
/// let x = 42; // 42는 바이너리 '101010' 입니다.
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// 유형에 `Binary` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 구현에 위임
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait 는 출력 형식을 16 진수 숫자로 지정해야하며 소문자는 `a` 부터 `f` 까지입니다.
///
/// 원시 부호있는 정수 (`i8` ~ `i128` 및 `isize`)의 경우 음수 값은 2의 보수 표현으로 형식이 지정됩니다.
///
///
/// 대체 플래그 인 `#` 는 출력 앞에 `0x` 를 추가합니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` 의 기본 사용법 :
///
/// ```
/// let x = 42; // 42는 16 진수 '2a' 입니다.
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// 유형에 `LowerHex` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 구현에 위임
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait 는 출력 형식을 16 진수 숫자로 지정해야하며 대문자는 `A` 에서 `F` 까지입니다.
///
/// 원시 부호있는 정수 (`i8` ~ `i128` 및 `isize`)의 경우 음수 값은 2의 보수 표현으로 형식이 지정됩니다.
///
///
/// 대체 플래그 인 `#` 는 출력 앞에 `0x` 를 추가합니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` 의 기본 사용법 :
///
/// ```
/// let x = 42; // 42는 16 진수 '2A' 입니다.
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// 유형에 `UpperHex` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 구현에 위임
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait 는 출력을 메모리 위치로 포맷해야합니다.
/// 일반적으로 16 진수로 표시됩니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` 의 기본 사용법 :
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // 이것은 '0x7f06092ac6d0' 와 같은 것을 생성합니다.
/// ```
///
/// 유형에 `Pointer` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `as` 를 사용하여 포인터를 구현하는 `*const T` 로 변환합니다.
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait 는 소문자 `e` 를 사용하여 과학적 표기법으로 출력 형식을 지정해야합니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` 의 기본 사용법 :
///
/// ```
/// let x = 42.0; // 42.0 과학적 표기법의 '4.2e1'
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// 유형에 `LowerExp` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64의 구현에 위임
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait 는 대문자 `E` 를 사용하여 과학적 표기법으로 출력 형식을 지정해야합니다.
///
/// 포맷터에 대한 자세한 내용은 [the module-level documentation][module] 를 참조하십시오.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` 의 기본 사용법 :
///
/// ```
/// let x = 42.0; // 42.0 과학적 표기법의 '4.2E1'
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// 유형에 `UpperExp` 구현 :
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64의 구현에 위임
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// 주어진 포맷터를 사용하여 값을 포맷합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` 함수는 출력 스트림과 `format_args!` 매크로로 미리 컴파일 할 수있는 `Arguments` 구조체를 사용합니다.
///
///
/// 인수는 지정된 형식 문자열에 따라 제공된 출력 스트림으로 형식화됩니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// [`write!`] 를 사용하는 것이 바람직 할 수 있습니다.예:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // 모든 인수에 기본 형식화 매개 변수를 사용할 수 있습니다.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // 모든 사양에는 문자열 조각이 앞에 오는 해당 인수가 있습니다.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // 안전: arg와 args.args 는 동일한 인수에서 나옵니다.
                // 인덱스가 항상 범위 내에 있음을 보장합니다.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // 후행 문자열 조각은 하나만 남을 수 있습니다.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // 안전: arg와 args는 동일한 Arguments에서 나옵니다.
    // 인덱스가 항상 범위 내에 있음을 보장합니다.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // 올바른 인수 추출
    debug_assert!(arg.position < args.len());
    // 안전: arg와 args는 동일한 Arguments에서 나옵니다.
    // 인덱스가 항상 범위 내에 있음을 보장합니다.
    let value = unsafe { args.get_unchecked(arg.position) };

    // 그런 다음 실제로 인쇄를
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // 안전: cnt 및 args는 동일한 인수에서 나옵니다.
            // 이 인덱스가 항상 범위 내에 있음을 보장합니다.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// 무언가의 끝에 패딩.`Formatter::padding` 에서 반환합니다.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// 이 게시물 패딩을 작성하십시오.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // 우리는 이것을 바꾸고 싶다
            buf: wrap(self.buf),

            // 그리고 이것들을 보존하십시오
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // 모든 형식 지정 traits 에서 사용할 수있는 형식 지정 인수를 채우고 처리하는 데 사용되는 도우미 메서드입니다.
    //

    /// str에 이미 방출 된 정수에 대해 올바른 채우기를 수행합니다.
    /// str은이 메서드에 의해 추가 될 정수에 대한 부호를 포함하지 *않아야* 합니다.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, 원래 정수가 양수인지 0인지 여부.
    /// * 접두사, '#' 문자 (Alternate) 가 제공되는 경우 번호 앞에 붙일 접두사입니다.
    ///
    /// * buf, 숫자가 포맷 된 바이트 배열
    ///
    /// 이 함수는 제공된 플래그와 최소 너비를 올바르게 고려합니다.
    /// 정밀도는 고려하지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // 숫자 출력에서 "-" 를 제거해야합니다.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // 존재하는 경우 부호를 쓰고 요청 된 경우 접두사를 씁니다.
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // `width` 필드는이 시점에서 `min-width` 매개 변수에 가깝습니다.
        match self.width {
            // 최소 길이 요구 사항이 없으면 바이트 만 쓸 수 있습니다.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // 최소 너비를 초과하는지 확인하십시오. 그렇다면 바이트를 쓸 수도 있습니다.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // 채우기 문자가 0이면 부호와 접두사가 패딩 앞에옵니다.
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // 그렇지 않으면 부호와 접두사가 패딩 뒤에옵니다.
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// 이 함수는 문자열 슬라이스를 가져와 지정된 관련 형식화 플래그를 적용한 후 내부 버퍼로 내 보냅니다.
    /// 일반 문자열에 대해 인식되는 플래그는 다음과 같습니다.
    ///
    /// * 너비, 방출 할 최소 너비
    /// * fill/align - 제공된 문자열을 패딩해야하는 경우 방출 할 항목 및 방출 할 위치
    /// * 정밀도, 방출 할 최대 길이,이 길이보다 길면 문자열이 잘립니다.
    ///
    /// 특히이 함수는 `flag` 매개 변수를 무시합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // 빠른 경로가 있는지 확인하십시오.
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` 필드는 형식화되는 문자열에 대해 `max-width` 로 해석 될 수 있습니다.
        //
        let s = if let Some(max) = self.precision {
            // 문자열이 정밀도보다 길면 잘림이 있어야합니다.
            // 그러나 `fill`, `width` 및 `align` 와 같은 다른 플래그는 항상 작동해야합니다.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // 여기서 LLVM은 `..i` 가 panic `&s[..i]` 가 아니라는 것을 증명할 수 없지만 panic 는 할 수 없다는 것을 알고 있습니다.
                // `get` + `unwrap_or` 를 사용하여 `unsafe` 를 피하고 그렇지 않으면 여기에서 panic 관련 코드를 내 보내지 마십시오.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // `width` 필드는이 시점에서 `min-width` 매개 변수에 가깝습니다.
        match self.width {
            // 최대 길이 미만이고 최소 길이 요구 사항이 없으면 문자열을 내보낼 수 있습니다.
            //
            None => self.buf.write_str(s),
            // 최대 너비 미만이면 최소 너비를 초과하는지 확인하십시오. 그렇다면 문자열을 방출하는 것만 큼 쉽습니다.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // 최대 너비와 최소 너비 아래에 있으면 지정된 문자열 + 약간의 정렬로 최소 너비를 채 웁니다.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// 사전 패딩을 작성하고 작성되지 않은 포스트 패딩을 반환합니다.
    /// 호출자는 패딩되는 항목 뒤에 포스트 패딩이 작성되도록 할 책임이 있습니다.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// 형식화 된 부분을 가져 와서 패딩을 적용합니다.
    /// 호출자가 이미 필요한 정밀도로 부품을 렌더링 했으므로 `self.precision` 를 무시할 수 있다고 가정합니다.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // 부호 인식 제로 패딩의 경우 부호를 먼저 렌더링하고 처음부터 부호가없는 것처럼 동작합니다.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // 사인이 항상 먼저 간다
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // 서식이 지정된 부분에서 기호 제거
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // 나머지 부분은 일반적인 패딩 프로세스를 거칩니다.
            let len = formatted.len();
            let ret = if width <= len {
                // 패딩 없음
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // 이것은 일반적인 경우이며 지름길을 사용합니다.
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // 안전: `flt2dec::Part::Num` 및 `flt2dec::Part::Copy` 에 사용됩니다.
            // 모든 문자 `c` 는 `b'0'` 와 `b'9'` 사이에 있으므로 `flt2dec::Part::Num` 에 사용하는 것이 안전합니다. 즉, `s` 가 유효한 UTF-8 임을 의미합니다.
            // `buf` 는 일반 ASCII 여야하므로 실제로 `flt2dec::Part::Copy(buf)` 에 사용하는 것이 안전 할 수 있지만 공개 함수이기 때문에 누군가가 `buf` 에 대한 잘못된 값을 `flt2dec::to_shortest_str` 에 전달할 수 있습니다.
            //
            // FIXME: 이것이 UB가 될 수 있는지 확인합니다.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 개의 0
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// 이 포맷터에 포함 된 기본 버퍼에 일부 데이터를 씁니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // 이것은 다음과 동일합니다.
    ///         // 쓰기! (포맷터, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// 이 인스턴스에 형식화 된 정보를 씁니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// 형식화를위한 플래그
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// 정렬이있을 때마다 'fill' 로 사용되는 문자입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ">" 를 사용하여 오른쪽으로 정렬합니다.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// 요청 된 정렬 형식을 나타내는 플래그입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// 출력이되어야하는 선택적으로 지정된 정수 너비입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // 너비를 받으면 사용합니다.
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // 그렇지 않으면 우리는 특별한 일을하지 않습니다
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// 숫자 유형에 대해 선택적으로 지정된 정밀도.
    /// 또는 문자열 유형의 최대 너비입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // 정밀도를 받으면 사용합니다.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // 그렇지 않으면 기본값은 2입니다.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` 플래그가 지정되었는지 판별합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` 플래그가 지정되었는지 판별합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // 마이너스 기호를 원하십니까?하나 가져라!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` 플래그가 지정되었는지 판별합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` 플래그가 지정되었는지 판별합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // 포맷터의 옵션을 무시합니다.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: 이 두 플래그에 대해 원하는 공용 API를 결정하십시오.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// 구조체에 대한 [`fmt::Debug`] 구현 생성을 지원하도록 설계된 [`DebugStruct`] 빌더를 만듭니다.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// 튜플 구조체에 대한 `fmt::Debug` 구현 생성을 지원하도록 설계된 `DebugTuple` 빌더를 만듭니다.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// 목록과 유사한 구조에 대한 `fmt::Debug` 구현 작성을 지원하도록 설계된 `DebugList` 빌더를 작성합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// 집합 형 구조에 대한 `fmt::Debug` 구현 생성을 지원하도록 설계된 `DebugSet` 빌더를 만듭니다.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// 이 더 복잡한 예제에서는 [`format_args!`] 및 `.debug_set()` 를 사용하여 매치 암 목록을 작성합니다.
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// 맵과 유사한 구조에 대한 `fmt::Debug` 구현 작성을 지원하도록 설계된 `DebugMap` 빌더를 작성합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// 핵심 서식 traits 의 구현

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // char 이스케이프가 필요하면 지금까지 백 로그를 비우고 쓰십시오.
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // 대체 플래그는 LowerHex에 의해 이미 특수한 것으로 처리되어 0x 접두사를 사용할지 여부를 나타냅니다.
        // 우리는 그것을 사용하여 0 확장 여부를 결정한 다음 무조건 접두사를 얻도록 설정합니다.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// 다양한 코어 유형을위한 Display/Debug 구현

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell은 가변적으로 차용되었으므로 여기서 그 가치를 볼 수 없습니다.
                // 대신 자리 표시자를 표시하십시오.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// 여기에 테스트가있을 것으로 예상했다면 core/tests/fmt.rs 파일을 대신 살펴보십시오. 여기에서 모든 rt::Piece 구조를 만드는 것보다 훨씬 쉽습니다.
//
// 할당이 필요한 테스트를 위해 alloc crate 에도 테스트가 있습니다.