//! ifmt!에서 사용하는 내부 모듈입니다.실행 시간.이러한 구조는 형식 문자열을 미리 컴파일하기 위해 정적 배열로 내보내집니다.
//!
//! 이러한 정의는 `ct` 에 해당하는 것과 유사하지만 정적으로 할당 될 수 있고 런타임에 약간 최적화된다는 점이 다릅니다.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// 형식 지정 지시문의 일부로 요청할 수있는 가능한 정렬입니다.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// 내용이 왼쪽 정렬되어야 함을 나타냅니다.
    Left,
    /// 내용이 오른쪽 정렬되어야 함을 나타냅니다.
    Right,
    /// 내용이 가운데 정렬되어야 함을 나타냅니다.
    Center,
    /// 정렬이 요청되지 않았습니다.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) 및 [precision](https://doc.rust-lang.org/std/fmt/#precision) 지정자에서 사용됩니다.
#[derive(Copy, Clone)]
pub enum Count {
    /// 리터럴 숫자로 지정되고 값을 저장합니다.
    Is(usize),
    /// `$` 및 `*` 구문을 사용하여 지정되며 인덱스를 `args` 에 저장합니다.
    Param(usize),
    /// 명시되지 않은
    Implied,
}