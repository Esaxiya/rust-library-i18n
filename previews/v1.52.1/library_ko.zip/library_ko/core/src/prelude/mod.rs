//! libcore prelude
//!
//! 이 모듈은 libstd에 링크되지 않은 libcore 사용자를위한 것입니다.
//! 이 모듈은 `#![no_std]` 가 표준 라이브러리의 prelude 와 동일한 방식으로 사용될 때 기본적으로 가져옵니다.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 코어 prelude 의 2015 버전입니다.
///
/// 자세한 내용은 [module-level documentation](self) 를 참조하십시오.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 코어 prelude 의 2018 버전입니다.
///
/// 자세한 내용은 [module-level documentation](self) 를 참조하십시오.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 코어 prelude 의 2021 버전.
///
/// 자세한 내용은 [module-level documentation](self) 를 참조하십시오.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: 더 많은 것을 추가하십시오.
}