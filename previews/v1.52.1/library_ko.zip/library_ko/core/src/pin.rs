//! 데이터를 메모리의 해당 위치에 고정하는 유형입니다.
//!
//! 메모리에서의 위치가 변경되지 않고 따라서 신뢰할 수 있다는 점에서 움직이지 않도록 보장되는 객체를 갖는 것이 때때로 유용합니다.
//! 이러한 시나리오의 대표적인 예는 자체 참조 구조체를 만드는 것입니다. 자체 포인터가있는 개체를 이동하면 무효화되어 정의되지 않은 동작이 발생할 수 있습니다.
//!
//! 높은 수준에서 [`Pin<P>`] 는 포인터 유형 `P` 의 포인터가 메모리에서 안정적인 위치를 갖도록 보장합니다. 즉, 다른 위치로 이동할 수 없으며 메모리가 삭제 될 때까지 할당 해제 될 수 없습니다.pointee는 "pinned" 라고 말합니다.고정 된 데이터와 고정되지 않은 데이터를 결합하는 유형을 논의 할 때 상황이 더 미묘 해집니다.자세한 내용은 [see below](#projections-and-structural-pinning) 를 참조하십시오.
//!
//! 기본적으로 Rust 의 모든 유형은 이동 가능합니다.
//! Rust 는 모든 유형을 값으로 전달할 수 있으며 [`Box<T>`] 및 `&mut T` 와 같은 일반적인 스마트 포인터 유형을 사용하면 포함 된 값을 바꾸고 이동할 수 있습니다. [`Box<T>`] 밖으로 이동하거나 [`mem::swap`] 를 사용할 수 있습니다.
//! [`Pin<P>`] 포인터 유형 `P` 를 래핑하므로 [`Pin`]`<`[`Box`]`<T>>`기능은 일반
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`]`<T>>`가 삭제되고 내용도 삭제되고 메모리가
//!
//! 할당 해제되었습니다.마찬가지로 [`Pin`]`<&mut T>`는 `&mut T` 와 매우 유사합니다.그러나 [`Pin<P>`] 는 클라이언트가 고정 된 데이터에 대한 [`Box<T>`] 또는 `&mut T` 를 실제로 얻도록 허용하지 않습니다. 이는 [`mem::swap`] 와 같은 작업을 사용할 수 없음을 의미합니다.
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` `&mut T` 가 필요하지만 얻을 수 없습니다.
//!     // 우리는이 참조의 내용을 바꿀 수 없습니다.
//!     // `Pin::get_unchecked_mut` 를 사용할 수 있지만 다음과 같은 이유로 안전하지 않습니다.
//!     // `Pin` 에서 물건을 옮기는 데 사용할 수 없습니다.
//! }
//! ```
//!
//! [`Pin<P>`] 는 Rust 컴파일러가 모든 유형을 이동 가능하다고 간주한다는 사실을 변경하지 *않습니다*.[`mem::swap`] 는 모든 `T` 에 대해 호출 가능합니다.대신 [`Pin<P>`] 는 `&mut T` 가 필요한 메서드 (예: [`mem::swap`])를 호출 할 수 없도록하여 특정 *값*([`Pin<P>`] 로 래핑 된 포인터로 가리키는)이 이동되는 것을 방지합니다.
//!
//! [`Pin<P>`] 포인터 유형 `P` 를 래핑하는 데 사용할 수 있으므로 [`Deref`] 및 [`DerefMut`] 와 상호 작용합니다.`P: Deref` 가 고정 된 `P::Target` 에 대한 "`P`-style pointer" 로 간주되어야하는 [`Pin<P>`]-따라서 [`Pin`]`<`[`Box`]`<T>>`는 고정 된 `T` 및 [`Pin`]`<`[`Rc`]`에 대한 소유 포인터입니다.<T>>`는 고정 된 `T` 에 대한 참조 횟수 포인터입니다.
//! 정확성을 위해 [`Pin<P>`] 는 [`Deref`] 및 [`DerefMut`] 의 구현에 의존하여 `self` 매개 변수를 벗어나지 않고 고정 된 포인터에서 호출 될 때 고정 된 데이터에 대한 포인터 만 반환합니다.
//!
//! # `Unpin`
//!
//! 많은 유형은 고정 된 주소에 의존하지 않기 때문에 고정 된 경우에도 항상 자유롭게 이동할 수 있습니다.여기에는 모든 기본 유형 (예: [`bool`], [`i32`] 및 참조)과 이러한 유형으로 만 구성된 유형이 포함됩니다.고정에 신경 쓰지 않는 유형은 [`Pin<P>`] 의 효과를 취소하는 [`Unpin`] auto-trait 를 구현합니다.
//! `T: Unpin` 의 경우 [`Pin`]`<`[`Box`]`<T>>`및 [`Box<T>`] 는 [`Pin`]`<&mut T>`및 `&mut T` 와 동일하게 작동합니다.
//!
//! 고정 및 [`Unpin`] 는 [`Pin<P>`] 에 래핑 된 포인터 유형 `P` 자체가 아니라 지정 대상 유형 `P::Target` 에만 영향을줍니다.예를 들어 [`Box<T>`] 가 [`Unpin`] 인지 여부는 [`Pin`]`<`[`Box`]`의 동작에 영향을주지 않습니다.<T>>`(여기서 `T` 는 지시 유형입니다).
//!
//! # 예: 자기 참조 구조체
//!
//! `Pin<T>` 와 관련된 보증 및 선택 사항을 자세히 설명하기 전에 `Pin<T>` 를 사용하는 방법에 대한 몇 가지 예를 논의합니다.
//! [skip to where the theoretical discussion continues](#drop-guarantee) 를 자유롭게 사용하십시오.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // 슬라이스 필드가 데이터 필드를 가리 키기 때문에 이것은 자기 참조 구조체입니다.
//! // 이 패턴은 일반적인 차용 규칙으로 설명 할 수 없으므로 일반적인 참조로는 컴파일러에 알릴 수 없습니다.
//! //
//! // 대신에 우리는 그것이 문자열을 가리키고 있다는 것을 알기 때문에 null이 아닌 것으로 알려진 포인터를 사용합니다.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // 함수가 반환 될 때 데이터가 이동하지 않도록하기 위해 객체의 수명 동안 유지되는 힙에 데이터를 배치하고 데이터에 액세스하는 유일한 방법은 포인터를 통해서입니다.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // 데이터가 제자리에있을 때만 포인터를 만듭니다. 그렇지 않으면 시작하기 전에 이미 이동했을 것입니다.
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // 필드를 수정해도 전체 구조체가 이동하지 않기 때문에 이것이 안전하다는 것을 알고 있습니다.
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // 구조체가 이동하지 않은 한 포인터는 올바른 위치를 가리켜 야합니다.
//! //
//! // 한편, 포인터를 자유롭게 움직일 수 있습니다.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // 우리 유형은 Unpin을 구현하지 않기 때문에 컴파일에 실패합니다.
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # 예: 침입적인 이중 연결 목록
//!
//! 침입 형 이중 연결 목록에서 컬렉션은 실제로 요소 자체에 메모리를 할당하지 않습니다.
//! 할당은 클라이언트에 의해 제어되며 요소는 컬렉션보다 수명이 짧은 스택 프레임에있을 수 있습니다.
//!
//! 이 작업을 수행하기 위해 모든 요소에는 목록에있는 선행 및 후속 요소에 대한 포인터가 있습니다.요소를 이동하면 포인터가 무효화되므로 요소가 고정 된 경우에만 추가 할 수 있습니다.또한, 연결 목록 요소의 [`Drop`] 구현은 이전 및 후속 요소의 포인터를 패치하여 목록에서 자신을 제거합니다.
//!
//! 결정적으로 우리는 [`drop`] 가 호출되는 것에 의존 할 수 있어야합니다.요소가 [`drop`] 를 호출하지 않고 할당 해제되거나 그렇지 않으면 무효화 될 수있는 경우, 인접 요소에서 해당 요소에 대한 포인터가 무효화되어 데이터 구조가 손상됩니다.
//!
//! 따라서 고정에는 [`drop`] 관련 보증도 함께 제공됩니다.
//!
//! # `Drop` guarantee
//!
//! 고정의 목적은 메모리의 일부 데이터 배치에 의존 할 수 있도록하는 것입니다.
//! 이 작업을 수행하려면 데이터 이동 만 제한되는 것이 아닙니다.데이터를 저장하는 데 사용되는 메모리의 할당 해제, 용도 변경 또는 기타 무효화도 제한됩니다.
//! 구체적으로, 고정 된 데이터의 경우 고정 된 순간부터 [`drop`] 가 호출 될 때까지 해당 메모리가 무효화되거나 용도가 변경되지 않는다는 불변성을 유지해야합니다 *.[`drop`] 가 반환되거나 panics 가 한 번만 메모리를 재사용 할 수 있습니다.
//!
//! 메모리는 할당 해제에 의해 "invalidated" 가 될 수 있지만 [`Some(v)`] 를 [`None`] 로 대체하거나 [`Vec::set_len`] 를 "kill" 로 호출하여 vector 의 일부 요소를 "kill" 로 호출 할 수도 있습니다.[`ptr::write`] 를 사용하여 소멸자를 먼저 호출하지 않고 덮어 쓰면 용도를 변경할 수 있습니다.[`drop`] 를 호출하지 않고 고정 된 데이터에는이 중 어느 것도 허용되지 않습니다.
//!
//! 이것은 이전 섹션의 침입 연결 목록이 올바르게 작동해야한다는 보장입니다.
//!
//! 이 보증은 메모리가 누출되지 않는다는 의미가 *아닙니다*.고정 된 요소에서 [`drop`] 를 호출하지 않는 것은 여전히 완전히 괜찮습니다 (예: [`Pin`]`<`[`Box`]`에서 여전히 [`mem::forget`] 를 호출 할 수 있음).<T>>`).이중 연결 목록의 예에서 해당 요소는 목록에 남아 있습니다.그러나 *[`drop`]* 을 호출하지 않고 저장 용량을 확보하거나 재사용 할 수 없습니다.
//!
//! # `Drop` implementation
//!
//! 유형이 고정을 사용하는 경우 (예: 위의 두 가지 예) [`Drop`] 를 구현할 때주의해야합니다.[`drop`] 함수는 `&mut self` 를 사용하지만 *이전에 유형이 고정 된 경우에도* 호출됩니다!컴파일러가 자동으로 [`Pin::get_unchecked_mut`] 를 호출하는 것과 같습니다.
//!
//! 고정에 의존하는 유형을 구현하려면 안전하지 않은 코드가 필요하기 때문에 안전한 코드에서 문제가 발생하지 않습니다. 그러나 유형에서 고정을 사용하기로 결정하는 경우 (예: [`Pin`]`<&Self에서 일부 작업 구현) >`또는 [`Pin`]`<&mut Self>`)는 [`Drop`] 구현에도 영향을 미칩니다. 유형의 요소가 고정되었을 수있는 경우 [`Drop`] 를 암시 적으로 [`Pin`]`<&mut을 취하는 것으로 처리해야합니다. Self>`.
//!
//!
//! 예를 들어 다음과 같이 `Drop` 를 구현할 수 있습니다.
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` 이 값이 삭제 된 후에 다시 사용되지 않는다는 것을 알고 있기 때문에 괜찮습니다.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // 실제 드롭 코드는 여기에 있습니다.
//!         }
//!     }
//! }
//! ```
//!
//! `inner_drop` 함수에는 [`drop`]*반드시* 유형이 있으므로 고정과 충돌하는 방식으로 실수로 `self`/`this` 를 사용하지 않도록합니다.
//!
//! 또한 유형이 `#[repr(packed)]` 인 경우 컴파일러는 필드를 삭제할 수 있도록 자동으로 필드를 이동합니다.충분히 정렬 된 필드에 대해서도 그렇게 할 수 있습니다.따라서 `#[repr(packed)]` 유형에는 고정을 사용할 수 없습니다.
//!
//! # 투영 및 구조적 고정
//!
//! 고정 된 구조체로 작업 할 때 [`Pin`]`<&mut Struct>`만 사용하는 메서드에서 해당 구조체의 필드에 액세스 할 수있는 방법이 문제가됩니다.
//! 일반적인 접근 방식은 [`Pin`]`<&mut Struct>`를 필드에 대한 참조로 바꾸는 도우미 메서드 (소위 *프로젝션*)를 작성하는 것입니다.하지만 해당 참조에는 어떤 유형이 있어야합니까?[`Pin`]`<&mut Field>`또는 `&mut Field` 입니까?
//! `enum` 의 필드와 [`Vec<T>`], [`Box<T>`] 또는 [`RefCell<T>`] 와 같은 container/wrapper 유형을 고려할 때도 동일한 질문이 발생합니다.
//! (이 질문은 변경 가능한 참조와 공유 참조 모두에 적용되며, 여기서는 설명을 위해 변경 가능한 참조의 더 일반적인 경우를 사용합니다.)
//!
//! 특정 필드에 대한 고정 된 투영이 [`Pin`]`<&mut Struct>`를 [`Pin`]`<&mut Field>`로 변환할지 여부를 결정하는 것은 실제로 데이터 구조 작성자에게 달려 있습니다. `&mut Field`.하지만 몇 가지 제약이 있으며 가장 중요한 제약은 *일관성* 입니다.
//! 모든 필드는 고정 된 참조에 *둘 중 하나* 프로젝션되거나 프로젝션의 일부로 *또는* 고정이 제거 될 수 있습니다.
//! 둘 다 동일한 분야에 대해 수행되면 불건전 할 것입니다!
//!
//! 데이터 구조의 작성자는 "propagates" 를이 필드에 고정할지 여부를 각 필드에 대해 결정할 수 있습니다.
//! 전파되는 고정은 유형의 구조를 따르기 때문에 "structural" 라고도합니다.
//! 다음 하위 섹션에서는 두 가지 선택에 대해 고려해야 할 사항을 설명합니다.
//!
//! ## 고정은 `field` 의 구조적 *아님*
//!
//! 고정 된 구조체의 필드가 고정되지 않을 수 있다는 것은 직관에 반하는 것처럼 보일 수 있지만 실제로는 가장 쉬운 선택입니다. [`Pin`]`<&mut Field>`가 생성되지 않으면 아무 것도 잘못 될 수 없습니다!따라서 일부 필드에 구조적 고정이없는 것으로 결정한 경우 해당 필드에 대한 고정 된 참조를 만들지 않기 만하면됩니다.
//!
//! 구조적 고정이없는 필드에는 [`Pin`]`<&mut Struct>`를 `&mut Field` 로 바꾸는 투영 방법이있을 수 있습니다.
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // `field` 는 고정 된 것으로 간주되지 않으므로 괜찮습니다.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! `field` 유형이 [`Unpin`] 가 아닌 경우에도 *`impl Unpin for Struct`* 를 사용할 수 있습니다.해당 유형이 고정에 대해 생각하는 것은 [`Pin`]`<&mut Field>`가 생성되지 않은 경우 관련이 없습니다.
//!
//! ## 고정 *is*`field` 의 구조
//!
//! 다른 옵션은 `field` 에 대해 고정이 "structural" 라고 결정하는 것입니다. 즉, 구조체가 고정되면 필드도 고정됩니다.
//!
//! 이렇게하면 [`Pin`]`<&mut Field>`를 만드는 프로젝션을 작성할 수 있으므로 필드가 고정되었는지 확인할 수 있습니다.
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // `self` 가있을 때 `field` 가 고정되기 때문에 괜찮습니다.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! 그러나 구조적 고정에는 몇 가지 추가 요구 사항이 있습니다.
//!
//! 1. 모든 구조 필드가 [`Unpin`] 인 경우 구조체는 [`Unpin`] 여야합니다.이것이 기본값이지만 [`Unpin`] 는 안전한 trait 이므로 구조체 작성자로서 `impl<T> Unpin for Struct<T>` 와 같은 것을 추가하는 것은 *아닌* 책임입니다.
//! (프로젝션 작업을 추가하려면 안전하지 않은 코드가 필요하므로 [`Unpin`] 가 안전한 trait 라는 사실은 'unsafe'를 사용하는 경우에만 걱정하면된다는 원칙을 위반하지 않습니다.)
//! 2. 구조체의 소멸자는 인수에서 구조적 필드를 이동해서는 안됩니다.이것은 [previous section][drop-impl] 에서 제기 된 정확한 지점입니다. `drop` 는 `&mut self` 를 사용하지만 구조체 (및 따라서 해당 필드)는 이전에 고정되었을 수 있습니다.
//!     [`Drop`] 구현 내에서 필드를 이동하지 않도록 보장해야합니다.
//!     특히 이전에 설명한 것처럼 이것은 구조체가 `#[repr(packed)]` 가 *안* 되어서는 안됨을 의미합니다.
//!     컴파일러가 실수로 고정을 중단하지 않도록 도와주는 방식으로 [`drop`] 를 작성하는 방법은 해당 섹션을 참조하십시오.
//! 3. [`Drop` guarantee][drop-guarantee] 를지지하는지 확인해야합니다.
//!     구조체가 고정되면 콘텐츠의 소멸자를 호출하지 않고 콘텐츠가 포함 된 메모리를 덮어 쓰거나 할당 취소하지 않습니다.
//!     이것은 [`VecDeque<T>`] 에서 목격 한 것처럼 까다로울 수 있습니다. [`VecDeque<T>`] 의 소멸자는 소멸자 중 하나가 panics 인 경우 모든 요소에서 [`drop`] 를 호출하지 못할 수 있습니다.이것은 소멸자가 호출되지 않고 요소가 할당 해제 될 수 있기 때문에 [`Drop`] 보증을 위반합니다.([`VecDeque<T>`] 에는 고정 돌기가 없으므로 소리가 나지 않습니다.)
//! 4. 유형이 고정 될 때 데이터가 구조 필드 밖으로 이동 될 수있는 다른 작업을 제공해서는 안됩니다.예를 들어 구조체에 [`Option<T>`] 가 포함되어 있고 `fn(Pin<&mut Struct<T>>) -> Option<T>` 유형의 '테이크'와 유사한 작업이있는 경우 해당 작업을 사용하여 고정 된 `Struct<T>` 에서 `T` 를 이동할 수 있습니다. 즉,이 작업을 포함하는 필드에 대해 고정이 구조화 될 수 없음을 의미합니다. 데이터.
//!
//!     고정 된 유형에서 데이터를 이동하는 더 복잡한 예제를 보려면 [`RefCell<T>`] 에 `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` 메서드가 있다고 가정 해보십시오.
//!     그런 다음 다음을 수행 할 수 있습니다.
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     이것은 치명적입니다. 먼저 [`RefCell<T>`] 의 내용을 고정한 다음 (`RefCell::get_pin_mut` 사용) 나중에 얻은 변경 가능한 참조를 사용하여 해당 내용을 이동할 수 있습니다.
//!
//! ## Examples
//!
//! [`Vec<T>`] 와 같은 유형의 경우 두 가지 가능성 (구조적 고정 여부)이 의미가 있습니다.
//! 구조적 고정이있는 [`Vec<T>`] 에는 요소에 대한 고정 된 참조를 가져 오는 `get_pin`/`get_pin_mut` 메서드가있을 수 있습니다.그러나 고정 된 [`Vec<T>`] 에서 [`pop`][Vec::pop] 를 호출하는 것은 (구조적으로 고정 된) 내용을 이동시킬 수 있기 때문에 *할 수 없습니다*!또한 [`push`][Vec::push] 를 허용하지 않아 콘텐츠를 재 할당하여 이동할 수도 있습니다.
//!
//! 구조적 고정이없는 [`Vec<T>`] 는 내용이 고정되지 않고 [`Vec<T>`] 자체도 이동해도 괜찮 기 때문에 `impl<T> Unpin for Vec<T>` 가 될 수 있습니다.
//! 그 시점에서 고정은 vector 에 전혀 영향을 미치지 않습니다.
//!
//! 표준 라이브러리에서 포인터 유형은 일반적으로 구조적 고정이 없으므로 고정 투영을 제공하지 않습니다.이것이 `Box<T>: Unpin` 가 모든 `T` 를 유지하는 이유입니다.
//! `Box<T>` 를 이동해도 실제로 `T` 가 이동하지 않기 때문에 포인터 유형에 대해이 작업을 수행하는 것이 합리적입니다. `T` 가 아닌 경우에도 [`Box<T>`] 를 자유롭게 이동할 수 있습니다 (일명 `Unpin`).사실, [`Pin`]`<`[`Box`]`<T>>`및 [`Pin`]`<&mut T>`는 동일한 이유로 항상 [`Unpin`] 자체입니다. 해당 내용 (`T`)은 고정되지만 고정 된 데이터를 이동하지 않고도 포인터 자체를 이동할 수 있습니다.
//! [`Box<T>`] 및 [`Pin`]`<`[`Box`]`모두<T>>`, 콘텐츠 고정 여부는 포인터 고정 여부와 완전히 무관합니다. 즉, 고정은 구조적이지 *않습니다*.
//!
//! [`Future`] 결합자를 구현할 때 [`poll`] 를 호출하기 위해 고정 된 참조를 가져와야하므로 일반적으로 중첩 된 futures 에 대한 구조적 고정이 필요합니다.
//! 그러나 combinator에 고정 할 필요가없는 다른 데이터가 포함되어있는 경우 해당 필드를 구조적이지 않게 만들 수 있으므로 [`Pin`]`<&mut Self>`만있는 경우에도 가변 참조를 사용하여 자유롭게 액세스 할 수 있습니다. 자신의 [`poll`] 구현에서와 같이).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// 고정 된 포인터.
///
/// 이것은 포인터 "pin" 를 제자리에있는 값으로 만드는 일종의 포인터를 감싸는 래퍼로, [`Unpin`] 를 구현하지 않는 한 해당 포인터가 참조하는 값이 이동되는 것을 방지합니다.
///
///
/// *고정에 대한 설명은 [`pin` module] 설명서를 참조하십시오.*
///
/// [`pin` module]: self
///
// Note: 아래의 `Clone` 파생은 구현할 수 있으므로 불건전 함을 유발합니다.
// `Clone` 변경 가능한 참조를 위해.
// 자세한 내용은 <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> 를 참조하십시오.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// 다음 구현은 건전성 문제를 피하기 위해 파생되지 않았습니다.
// `&self.pointer` 신뢰할 수없는 trait 구현에 액세스 할 수 없어야합니다.
//
// 자세한 내용은 <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> 를 참조하십시오.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// [`Unpin`] 를 구현하는 유형의 일부 데이터에 대한 포인터 주위에 새로운 `Pin<P>` 를 생성합니다.
    ///
    /// `Pin::new_unchecked` 와 달리이 메서드는 `P` 포인터가 고정 보장을 취소하는 [`Unpin`] 유형을 역 참조하므로 안전합니다.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // 안전: 지적 된 값은 `Unpin` 이므로 요구 사항이 없습니다.
        // 고정.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// 기본 포인터를 리턴하는이 `Pin<P>` 를 랩핑 해제합니다.
    ///
    /// 이를 위해서는이 `Pin` 내부의 데이터가 [`Unpin`] 여야하므로이를 풀 때 고정 불변을 무시할 수 있습니다.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Unpin` 를 구현하거나 구현하지 않을 수있는 유형의 일부 데이터에 대한 참조 주위에 새로운 `Pin<P>` 를 생성합니다.
    ///
    /// `pointer` 가 `Unpin` 유형을 역 참조하는 경우 `Pin::new` 를 대신 사용해야합니다.
    ///
    /// # Safety
    ///
    /// 이 생성자는 `pointer` 가 가리키는 데이터가 고정되어 있음을 보장 할 수 없기 때문에 안전하지 않습니다. 즉, 데이터가 삭제 될 때까지 데이터가 이동되지 않거나 해당 저장소가 무효화된다는 것을 의미합니다.
    /// 생성 된 `Pin<P>` 가 `P` 가 가리키는 데이터가 고정 된 것을 보장하지 않는 경우 이는 API 계약 위반이며 이후 (safe) 작업에서 정의되지 않은 동작을 유발할 수 있습니다.
    ///
    /// 이 방법을 사용하면 `P::Deref` 및 `P::DerefMut` 구현 (존재하는 경우)에 대한 promise 를 만듭니다.
    /// 가장 중요한 것은 `self` 인수에서 벗어나지 않아야한다는 것입니다. `Pin::as_mut` 및 `Pin::as_ref` 는 *고정 된 포인터* 에서 `DerefMut::deref_mut` 및 `Deref::deref` 를 호출하고 이러한 메서드가 고정 불변을 유지하기를 기대합니다.
    /// 또한이 메서드를 호출하면 참조 `P` 가 역 참조하는 promise 가 다시 이동되지 않습니다.특히, `&mut P::Target` 를 얻은 다음 해당 참조에서 벗어나는 것이 가능하지 않아야합니다 (예: [`mem::swap`] 사용).
    ///
    ///
    /// 예를 들어 `&'a mut T` 에서 `Pin::new_unchecked` 를 호출하는 것은 주어진 수명 `'a` 동안 고정 할 수 있지만 `'a` 가 종료되면 고정 상태를 유지할지 여부를 제어 할 수 없기 때문에 안전하지 않습니다.
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // 이것은 pointee `a` 가 다시는 움직일 수 없음을 의미합니다.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a` 의 주소가 'b'의 스택 슬롯으로 변경되어 이전에 고정 했음에도 불구하고 `a` 가 이동되었습니다!고정 API 계약을 위반했습니다.
    /////
    /// }
    /// ```
    ///
    /// 고정 된 값은 해당 유형이 `Unpin` 를 구현하지 않는 한 영원히 고정 된 상태로 유지되어야합니다.
    ///
    /// 마찬가지로, `Rc<T>` 에서 `Pin::new_unchecked` 를 호출하는 것은 고정 제한이 적용되지 않는 동일한 데이터에 대한 별칭이있을 수 있으므로 안전하지 않습니다.
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // 이것은 pointee가 다시는 움직일 수 없다는 것을 의미합니다.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // 이제 `x` 가 유일한 참조 인 경우 위에서 고정한 데이터에 대한 가변 참조가 있으며, 이전 예제에서 보았던 것처럼 데이터를 이동하는 데 사용할 수 있습니다.
    ///     // 고정 API 계약을 위반했습니다.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// 고정 된 포인터에서 고정 된 공유 참조를 가져옵니다.
    ///
    /// 이것은 `&Pin<Pointer<T>>` 에서 `Pin<&T>` 로 이동하는 일반적인 방법입니다.
    /// `Pin::new_unchecked` 계약의 일부로 `Pin<Pointer<T>>` 가 생성 된 후에는 pointee가 이동할 수 없기 때문에 안전합니다.
    ///
    /// "Malicious" `Pointer::Deref` 의 구현은 마찬가지로 `Pin::new_unchecked` 의 계약에 의해 배제됩니다.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // 안전: 이 기능에 대한 문서 참조
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// 기본 포인터를 리턴하는이 `Pin<P>` 를 랩핑 해제합니다.
    ///
    /// # Safety
    ///
    /// 이 기능은 안전하지 않습니다.이 함수를 호출 한 후에도 포인터 `P` 를 고정 된 것으로 계속 처리하여 `Pin` 유형의 불변을 유지할 수 있도록 보장해야합니다.
    /// 결과 `P` 를 사용하는 코드가 API 계약을 위반하는 고정 불변을 계속 유지하지 않으면 이후 (safe) 작업에서 정의되지 않은 동작이 발생할 수 있습니다.
    ///
    ///
    /// 기본 데이터가 [`Unpin`] 이면 대신 [`Pin::into_inner`] 를 사용해야합니다.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// 고정 된 포인터에서 고정 된 가변 참조를 가져옵니다.
    ///
    /// 이것은 `&mut Pin<Pointer<T>>` 에서 `Pin<&mut T>` 로 이동하는 일반적인 방법입니다.
    /// `Pin::new_unchecked` 계약의 일부로 `Pin<Pointer<T>>` 가 생성 된 후에는 pointee가 이동할 수 없기 때문에 안전합니다.
    ///
    /// "Malicious" `Pointer::DerefMut` 의 구현은 마찬가지로 `Pin::new_unchecked` 의 계약에 의해 배제됩니다.
    ///
    /// 이 메서드는 고정 된 유형을 사용하는 함수를 여러 번 호출 할 때 유용합니다.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // 뭔가 해
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` 를 소비하므로 `as_mut` 를 통해 `Pin<&mut Self>` 를 다시 빌리십시오.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // 안전: 이 기능에 대한 문서 참조
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// 고정 된 참조 뒤의 메모리에 새 값을 할당합니다.
    ///
    /// 이렇게하면 고정 된 데이터를 덮어 쓰지만 괜찮습니다. 소멸자가 덮어 쓰기 전에 실행되므로 고정 보장을 위반하지 않습니다.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// 내부 값을 매핑하여 새 핀을 구성합니다.
    ///
    /// 예를 들어, 어떤 필드의 `Pin` 를 얻으려면 이것을 사용하여 한 줄의 코드로 해당 필드에 액세스 할 수 있습니다.
    /// 그러나 이러한 "pinning projections" 에는 몇 가지 문제가 있습니다.
    /// 해당 주제에 대한 자세한 내용은 [`pin` module] 설명서를 참조하십시오.
    ///
    /// # Safety
    ///
    /// 이 기능은 안전하지 않습니다.
    /// 반환하는 데이터는 인수 값이 이동하지 않는 한 (예: 해당 값의 필드 중 하나이기 때문에) 이동하지 않으며 수신 한 인수에서 벗어나지 않도록해야합니다. 내부 기능.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // 안전: `new_unchecked` 에 대한 안전 계약은
        // 발신자가지지합니다.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// 핀에서 공유 참조를 가져옵니다.
    ///
    /// 이것은 공유 참조에서 이동할 수 없기 때문에 안전합니다.
    /// 여기에 내부 가변성에 문제가있는 것처럼 보일 수 있습니다. 사실, `T` 를 `&RefCell<T>` 밖으로 이동하는 것이 *가능* 합니다.
    /// 그러나 동일한 데이터를 가리키는 `Pin<&T>` 가 존재하지 않는 한 문제가되지 않으며 `RefCell<T>` 를 사용하여 해당 내용에 대한 고정 참조를 만들 수 없습니다.
    ///
    /// 자세한 내용은 ["pinning projections"] 에 대한 토론을 참조하십시오.
    ///
    /// Note: `Pin` 는 또한 `Deref` 를 대상에 구현하여 내부 값에 액세스하는 데 사용할 수 있습니다.
    /// 그러나 `Deref` 는 `Pin` 자체의 수명이 아니라 `Pin` 를 빌리는 동안 지속되는 참조 만 제공합니다.
    /// 이 방법을 사용하면 `Pin` 를 원래 `Pin` 와 수명이 동일한 참조로 변환 할 수 있습니다.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// 이 `Pin<&mut T>` 를 동일한 수명의 `Pin<&T>` 로 변환합니다.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// 이 `Pin` 내부의 데이터에 대한 변경 가능한 참조를 가져옵니다.
    ///
    /// 이를 위해서는이 `Pin` 내부의 데이터가 `Unpin` 여야합니다.
    ///
    /// Note: `Pin` 는 또한 내부 값에 액세스하는 데 사용할 수있는 데이터에 `DerefMut` 를 구현합니다.
    /// 그러나 `DerefMut` 는 `Pin` 자체의 수명이 아니라 `Pin` 를 빌리는 동안 지속되는 참조 만 제공합니다.
    ///
    /// 이 방법을 사용하면 `Pin` 를 원래 `Pin` 와 수명이 동일한 참조로 변환 할 수 있습니다.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// 이 `Pin` 내부의 데이터에 대한 변경 가능한 참조를 가져옵니다.
    ///
    /// # Safety
    ///
    /// 이 기능은 안전하지 않습니다.
    /// 이 함수를 호출 할 때 수신 한 가변 참조에서 데이터를 절대 이동하지 않도록 보장해야 `Pin` 유형의 불변이 유지 될 수 있습니다.
    ///
    ///
    /// 기본 데이터가 `Unpin` 이면 대신 `Pin::get_mut` 를 사용해야합니다.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// 내부 값을 매핑하여 새 핀을 만듭니다.
    ///
    /// 예를 들어, 어떤 필드의 `Pin` 를 얻으려면 이것을 사용하여 한 줄의 코드로 해당 필드에 액세스 할 수 있습니다.
    /// 그러나 이러한 "pinning projections" 에는 몇 가지 문제가 있습니다.
    /// 해당 주제에 대한 자세한 내용은 [`pin` module] 설명서를 참조하십시오.
    ///
    /// # Safety
    ///
    /// 이 기능은 안전하지 않습니다.
    /// 반환하는 데이터는 인수 값이 이동하지 않는 한 (예: 해당 값의 필드 중 하나이기 때문에) 이동하지 않으며 수신 한 인수에서 벗어나지 않도록해야합니다. 내부 기능.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // 안전: 발신자는 이동하지 않을 책임이 있습니다.
        // 이 참조에서 값.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // 안전: `this` 의 가치가 보장되지 않기 때문에
        // 이 `new_unchecked` 호출은 안전합니다.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// 정적 참조에서 고정 된 참조를 가져옵니다.
    ///
    /// `T` 는 `'static` 수명 동안 빌려서 끝나지 않기 때문에 안전합니다.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // 안전: '정적 차용은 데이터가
        // moved/invalidated 떨어질 때까지 (절대 안됨).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// 정적 가변 참조에서 고정 된 가변 참조를 가져옵니다.
    ///
    /// `T` 는 `'static` 수명 동안 빌려서 끝나지 않기 때문에 안전합니다.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // 안전: '정적 차용은 데이터가
        // moved/invalidated 떨어질 때까지 (절대 안됨).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: 이것은 강제를 허용하는 `CoerceUnsized` 의 모든 impl을 의미합니다.
// `Deref<Target=impl !Unpin>` 를 `Deref<Target=Unpin>` 를 의미하지 않는 유형으로 단순화하는 유형.
// 그러나 그러한 impl은 아마도 다른 이유로 불건전 할 것입니다. 그래서 우리는 그러한 impl이 std 에 착륙하는 것을 허용하지 않도록주의해야합니다.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}