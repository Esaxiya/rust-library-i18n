#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! 컴파일러 내장 유형의 레이아웃에 대한 구조체 정의를 포함합니다.
//!
//! 원시 표현을 직접 조작하기 위해 안전하지 않은 코드에서 변환 대상으로 사용할 수 있습니다.
//!
//!
//! 정의는 항상 `rustc_middle::ty::layout` 에 정의 된 ABI와 일치해야합니다.
//!

/// `&dyn SomeTrait` 와 같은 trait 개체의 표현입니다.
///
/// 이 구조체는 `&dyn SomeTrait` 및 `Box<dyn AnotherTrait>` 와 같은 유형과 동일한 레이아웃을 갖습니다.
///
/// `TraitObject` 레이아웃과 일치하는 것이 보장되지만 trait 객체의 유형이 아니며 (예: `&dyn SomeTrait` 에서 필드에 직접 액세스 할 수 없음) 해당 레이아웃을 제어하지 않습니다 (정의를 변경해도 `&dyn SomeTrait` 의 레이아웃이 변경되지 않음).
///
/// 낮은 수준의 세부 정보를 조작해야하는 안전하지 않은 코드에서만 사용하도록 설계되었습니다.
///
/// 모든 trait 객체를 일반적으로 참조 할 수있는 방법이 없으므로이 유형의 값을 만드는 유일한 방법은 [`std::mem::transmute`][transmute] 와 같은 함수를 사용하는 것입니다.
/// 마찬가지로 `TraitObject` 값에서 진정한 trait 개체를 만드는 유일한 방법은 `transmute` 를 사용하는 것입니다.
///
/// [transmute]: crate::intrinsics::transmute
///
/// trait 개체를 일치하지 않는 유형 (vtable이 데이터 포인터가 가리키는 값의 유형과 일치하지 않는 유형)으로 합성하면 정의되지 않은 동작이 발생할 가능성이 높습니다.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // 예제 trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // 컴파일러가 trait 객체를 만들도록합니다.
/// let object: &dyn Foo = &value;
///
/// // 원시 표현을 봐
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // 데이터 포인터는 `value` 의 주소입니다.
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` 의 `i32` vtable을 사용하도록주의하면서 다른 `i32` 를 가리키는 새 개체를 구성합니다.
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // `other_value` 에서 직접 trait 객체를 생성 한 것처럼 작동합니다.
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}