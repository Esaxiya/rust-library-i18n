//! # Rust 코어 라이브러리
//!
//! Rust 코어 라이브러리는 [The Rust Standard Library](../std/index.html) 의 종속성이없는 [^ free] 기반입니다.
//! 모든 Rust 코드의 기본 및 기본 구성 요소를 정의하는 언어와 라이브러리 간의 이식 가능한 접착제입니다.
//!
//! 업스트림 라이브러리, 시스템 라이브러리 및 libc에 연결되지 않습니다.
//!
//! [^free]: Strictly 말하자면, 필요한 몇 가지 기호가 있지만
//!          항상 필요한 것은 아닙니다.
//!
//! 코어 라이브러리는 *최소* 입니다. 힙 할당도 인식하지 못하며 동시성 또는 I/O 를 제공하지도 않습니다.
//! 이러한 것에는 플랫폼 통합이 필요하며이 라이브러리는 플랫폼에 구애받지 않습니다.
//!
//! # 핵심 라이브러리 사용 방법
//!
//! 이러한 모든 세부 정보는 현재 안정적인 것으로 간주되지 않습니다.
//!
//!
//!
// FIXME: 인터페이스가 안정되면 더 자세히 입력 해주세요.
//! 이 라이브러리는 몇 가지 기존 기호를 가정하여 구축되었습니다.
//!
//! * `memcpy`, `memcmp`, `memset`, 이들은 종종 LLVM에 의해 생성되는 핵심 메모리 루틴입니다.
//! 또한이 라이브러리는 이러한 함수를 명시 적으로 호출 할 수 있습니다.
//! 그들의 서명은 C에서 발견 된 것과 동일합니다.
//!   이러한 기능은 시스템 libc에서 제공하는 경우가 많지만 [compiler-builtins crate](https://crates.io/crates/compiler_builtins) 에서도 제공 할 수 있습니다.
//!
//!
//! * `rust_begin_panic` - 이 함수는 4 개의 인수, `fmt::Arguments`, `&'static str` 및 2 개의 'u32'를 사용합니다.
//! 이 네 가지 인수는 panic 메시지, panic 가 호출 된 파일 및 파일 내부의 행과 열을 나타냅니다.
//! 이 panic 함수를 정의하는 것은이 코어 라이브러리의 소비자에게 달려 있습니다.절대 돌아 오지 않는 것만 필요합니다.
//! 이를 위해서는 `panic_impl` 라는 `lang` 속성이 필요합니다.
//!
//! * `rust_eh_personality` - 컴파일러의 실패 메커니즘에서 사용됩니다.
//! 이것은 종종 GCC 의 성격 기능에 매핑되지만 panic 를 트리거하지 않는 crates 는이 기능이 호출되지 않음을 보장 할 수 있습니다.
//! `lang` 속성은 `eh_personality` 라고합니다.
//!
//!
//!

// libcore는 많은 기본 lang 항목을 정의하므로 모든 테스트는 기괴한 문제를 피하기 위해 별도의 crate 인 libcoretest에 있습니다.
//
// 여기서 우리는 테스트 할 때이 전체 crate 를 명시 적으로#[cfg]-out합니다.
// 이렇게하지 않으면 생성 된 테스트 아티팩트와 연결된 libtest (전 이적으로 libcore를 포함 함)가 모두 동일한 lang 항목 집합을 정의하고 이로 인해 E0152 "found duplicate lang item" 오류가 발생합니다.
//
// 자세한 내용은 #50466 의 토론을 참조하십시오.
//
// 이 cfg는 문서 테스트에 영향을주지 않습니다.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // #65860 참조
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: 공개 할 필요가 없습니다
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// `core_arch` crate 를 libcore로 직접 가져옵니다.`core_arch` 의 내용은 다른 저장소에 있습니다. rust-lang/stdarch.
//
// `core_arch` libcore에 따라 다르지만이 모듈의 내용은 crate 가이 crate 를 libcore로 사용하도록 여기에서 직접 끌어 오는 방식으로 설정됩니다.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: 이 주석은 clashing_extern_declarations가 완료되면 rust-lang/stdarch 로 이동해야합니다.
// 병합되었습니다.lint 가 아직 정의되지 않았기 때문에 부트 스트랩이 실패하기 때문에 현재는 불가능합니다.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;