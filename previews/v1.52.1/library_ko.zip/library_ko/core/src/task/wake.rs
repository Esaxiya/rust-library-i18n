#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` 를 사용하면 작업 실행자의 구현자가 사용자 정의 된 wakeup 동작을 제공하는 [`Waker`] 를 만들 수 있습니다.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// 데이터 포인터와 `RawWaker` 의 동작을 사용자 지정하는 [virtual function pointer table (vtable)][vtable] 로 구성됩니다.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// 실행자가 필요로하는 임의의 데이터를 저장하는 데 사용할 수있는 데이터 포인터입니다.
    /// 이것은 예를 들어
    /// 태스크와 연관된 `Arc` 에 대한 유형 소거 된 포인터.
    /// 이 필드의 값은 vtable의 일부인 모든 함수에 첫 번째 매개 변수로 전달됩니다.
    ///
    data: *const (),
    /// 이 웨이 커의 동작을 사용자 지정하는 가상 함수 포인터 테이블입니다.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// 제공된 `data` 포인터 및 `vtable` 에서 새 `RawWaker` 를 만듭니다.
    ///
    /// `data` 포인터는 실행 프로그램이 필요로하는 임의의 데이터를 저장하는 데 사용할 수 있습니다.이것은 예를 들어
    /// 태스크와 연관된 `Arc` 에 대한 유형 소거 된 포인터.
    /// 이 포인터의 값은 첫 번째 매개 변수로 `vtable` 의 일부인 모든 함수에 전달됩니다.
    ///
    /// `vtable` 는 `RawWaker` 에서 생성되는 `Waker` 의 동작을 사용자 정의합니다.
    /// `Waker` 의 각 작업에 대해 기본 `RawWaker` 의 `vtable` 에있는 관련 함수가 호출됩니다.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`] 의 동작을 지정하는 가상 함수 포인터 테이블 (vtable).
///
/// vtable 내부의 모든 함수에 전달 된 포인터는 둘러싸는 [`RawWaker`] 개체의 `data` 포인터입니다.
///
/// 이 구조체 내부의 함수는 [`RawWaker`] 구현 내부에서 적절하게 구성된 [`RawWaker`] 개체의 `data` 포인터에서만 호출됩니다.
/// 다른 `data` 포인터를 사용하여 포함 된 함수 중 하나를 호출하면 정의되지 않은 동작이 발생합니다.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// 이 함수는 [`RawWaker`] 가 복제 될 때 호출됩니다 (예: [`RawWaker`] 가 저장된 [`Waker`] 가 복제 될 때).
    ///
    /// 이 기능의 구현은이 추가 [`RawWaker`] 인스턴스 및 관련 작업에 필요한 모든 리소스를 유지해야합니다.
    /// 결과 [`RawWaker`] 에서 `wake` 를 호출하면 원래 [`RawWaker`] 에 의해 깨어 난 동일한 작업이 깨어납니다.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// 이 함수는 [`Waker`] 에서 `wake` 가 호출 될 때 호출됩니다.
    /// 이 [`RawWaker`] 와 관련된 작업을 깨워 야합니다.
    ///
    /// 이 기능의 구현은이 [`RawWaker`] 인스턴스 및 연관된 태스크와 연관된 모든 자원을 해제해야합니다.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// 이 함수는 [`Waker`] 에서 `wake_by_ref` 가 호출 될 때 호출됩니다.
    /// 이 [`RawWaker`] 와 관련된 작업을 깨워 야합니다.
    ///
    /// 이 함수는 `wake` 와 유사하지만 제공된 데이터 포인터를 사용해서는 안됩니다.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// 이 함수는 [`RawWaker`] 가 드롭 될 때 호출됩니다.
    ///
    /// 이 기능의 구현은이 [`RawWaker`] 인스턴스 및 연관된 태스크와 연관된 모든 자원을 해제해야합니다.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// 제공된 `clone`, `wake`, `wake_by_ref` 및 `drop` 함수에서 새 `RawWakerVTable` 를 만듭니다.
    ///
    /// # `clone`
    ///
    /// 이 함수는 [`RawWaker`] 가 복제 될 때 호출됩니다 (예: [`RawWaker`] 가 저장된 [`Waker`] 가 복제 될 때).
    ///
    /// 이 기능의 구현은이 추가 [`RawWaker`] 인스턴스 및 관련 작업에 필요한 모든 리소스를 유지해야합니다.
    /// 결과 [`RawWaker`] 에서 `wake` 를 호출하면 원래 [`RawWaker`] 에 의해 깨어 난 동일한 작업이 깨어납니다.
    ///
    /// # `wake`
    ///
    /// 이 함수는 [`Waker`] 에서 `wake` 가 호출 될 때 호출됩니다.
    /// 이 [`RawWaker`] 와 관련된 작업을 깨워 야합니다.
    ///
    /// 이 기능의 구현은이 [`RawWaker`] 인스턴스 및 연관된 태스크와 연관된 모든 자원을 해제해야합니다.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// 이 함수는 [`Waker`] 에서 `wake_by_ref` 가 호출 될 때 호출됩니다.
    /// 이 [`RawWaker`] 와 관련된 작업을 깨워 야합니다.
    ///
    /// 이 함수는 `wake` 와 유사하지만 제공된 데이터 포인터를 사용해서는 안됩니다.
    ///
    /// # `drop`
    ///
    /// 이 함수는 [`RawWaker`] 가 드롭 될 때 호출됩니다.
    ///
    /// 이 기능의 구현은이 [`RawWaker`] 인스턴스 및 연관된 태스크와 연관된 모든 자원을 해제해야합니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// 비동기 작업의 `Context` 입니다.
///
/// 현재 `Context` 는 현재 작업을 깨우는 데 사용할 수있는 `&Waker` 에 대한 액세스 만 제공합니다.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // 수명을 불변으로 강제하여 분산 변경에 대해 future-증명하는지 확인합니다 (인수 위치 수명은 반 변성이고 반환 위치 수명은 공변).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` 에서 새 `Context` 를 만듭니다.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// 현재 작업에 대한 `Waker` 에 대한 참조를 반환합니다.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` 는 실행할 준비가되었음을 실행자에게 알려 작업을 깨우기위한 핸들입니다.
///
/// 이 핸들은 실행 기별 wakeup 동작을 정의하는 [`RawWaker`] 인스턴스를 캡슐화합니다.
///
///
/// [`Clone`], [`Send`] 및 [`Sync`] 를 구현합니다.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// 이 `Waker` 와 관련된 작업을 시작합니다.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // 실제 wakeup 호출은 가상 함수 호출을 통해 실행자가 정의한 구현에 위임됩니다.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` 를 호출하지 마십시오. 웨이 커는 `wake` 에 의해 소비됩니다.
        crate::mem::forget(self);

        // 안전: `Waker::from_raw` 가 유일한 방법이기 때문에 안전합니다.
        // `wake` 및 `data` 를 초기화하려면 사용자가 `RawWaker` 의 계약이 유지됨을 확인해야합니다.
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` 를 사용하지 않고이 `Waker` 와 관련된 작업을 깨 웁니다.
    ///
    /// 이것은 `wake` 와 유사하지만 소유 한 `Waker` 를 사용할 수있는 경우에는 약간 덜 효율적일 수 있습니다.
    /// 이 방법은 `waker.clone().wake()` 를 호출하는 것보다 선호되어야합니다.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // 실제 wakeup 호출은 가상 함수 호출을 통해 실행자가 정의한 구현에 위임됩니다.
        //

        // 안전: `wake` 참조
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// 이 `Waker` 와 다른 `Waker` 가 동일한 작업을 깨우면 `true` 를 반환합니다.
    ///
    /// 이 함수는 최선을 다해 작동하며 'Waker'가 동일한 작업을 깨우더라도 false를 반환 할 수 있습니다.
    /// 그러나이 함수가 `true` 를 반환하면 'Waker'가 동일한 작업을 깨우는 것이 보장됩니다.
    ///
    /// 이 기능은 주로 최적화 목적으로 사용됩니다.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] 에서 새 `Waker` 를 만듭니다.
    ///
    /// 반환 된 `Waker` 의 동작은 [`RawWaker`]와 [`RawWakerVTable`]의 문서에 정의 된 계약이 유지되지 않는 경우 정의되지 않습니다.
    ///
    /// 따라서이 방법은 안전하지 않습니다.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // 안전: `Waker::from_raw` 가 유일한 방법이기 때문에 안전합니다.
            // `clone` 및 `data` 를 초기화하려면 사용자가 [`RawWaker`] 의 계약이 유지됨을 확인해야합니다.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // 안전: `Waker::from_raw` 가 유일한 방법이기 때문에 안전합니다.
        // `drop` 및 `data` 를 초기화하려면 사용자가 `RawWaker` 의 계약이 유지됨을 확인해야합니다.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}