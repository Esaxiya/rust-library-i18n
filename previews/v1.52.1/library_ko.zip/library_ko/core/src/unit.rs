use crate::iter::FromIterator;

/// 반복기의 모든 단위 항목을 하나로 축소합니다.
///
/// 이것은 오류 만 신경 쓰는 `Result<(), E>` 에 수집하는 것과 같이 더 높은 수준의 추상화와 결합 할 때 더 유용합니다.
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}