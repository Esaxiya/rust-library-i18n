use crate::{fmt, iter::FusedIterator};

/// 각 연속 항목이 이전 항목을 기반으로 계산되는 새 반복기를 만듭니다.
///
/// 반복기는 주어진 첫 번째 항목 (있는 경우)으로 시작하고 지정된 `FnMut(&T) -> Option<T>` 클로저를 호출하여 각 항목의 후속 항목을 계산합니다.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // 이 함수가 `impl Iterator<Item=T>` 를 반환하면 `unfold` 를 기반으로 할 수 있으며 전용 유형이 필요하지 않습니다.
    //
    // 그러나 명명 된 `Successors<T, F>` 유형을 사용하면 `T` 및 `F` 가있을 때 `Clone` 가 될 수 있습니다.
    Successors { next: first, succ }
}

/// 각 연속 항목이 이전 항목을 기반으로 계산되는 새 반복기입니다.
///
/// 이 `struct` 는 [`iter::successors()`] 기능에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}