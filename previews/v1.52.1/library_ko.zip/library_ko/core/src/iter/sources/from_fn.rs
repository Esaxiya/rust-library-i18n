use crate::fmt;

/// 각 반복이 제공된 클로저 `F: FnMut() -> Option<T>` 를 호출하는 새 반복기를 만듭니다.
///
/// 이를 통해 전용 유형을 만들고 [`Iterator`] trait 를 구현하는보다 자세한 구문을 사용하지 않고도 모든 동작으로 사용자 지정 반복기를 만들 수 있습니다.
///
/// `FromFn` 반복자는 클로저의 동작에 대해 가정하지 않으므로 보수적으로 [`FusedIterator`] 를 구현하지 않거나 기본 `(0, None)` 에서 [`Iterator::size_hint()`] 를 재정의하지 않습니다.
///
///
/// 클로저는 캡처와 그 환경을 사용하여 반복에서 상태를 추적 할 수 있습니다.반복기가 사용되는 방식에 따라 클로저에 [`move`] 키워드를 지정해야 할 수 있습니다.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation] 에서 카운터 반복기를 다시 구현해 보겠습니다.
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // 카운트를 늘립니다.이것이 우리가 0에서 시작한 이유입니다.
///     count += 1;
///
///     // 계산이 끝났는지 확인하십시오.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// 각 반복이 제공된 클로저 `F: FnMut() -> Option<T>` 를 호출하는 반복기입니다.
///
/// 이 `struct` 는 [`iter::from_fn()`] 기능에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}