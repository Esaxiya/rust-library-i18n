use crate::iter::{FusedIterator, TrustedLen};

/// 제공된 클로저를 호출하여 정확히 한 번 값을 느리게 생성하는 반복기를 만듭니다.
///
/// 이것은 일반적으로 단일 값 생성기를 다른 종류의 반복 [`chain()`] 에 적용하는 데 사용됩니다.
/// 거의 모든 것을 다루는 반복자가있을 수 있지만 특별한 경우가 더 필요합니다.
/// 반복자에서 작동하는 함수가있을 수 있지만 하나의 값만 처리하면됩니다.
///
/// [`once()`] 와 달리이 함수는 요청시 값을 느리게 생성합니다.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::iter;
///
/// // 하나는 가장 외로운 숫자
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // 그게 우리가 얻는 전부
/// assert_eq!(None, one.next());
/// ```
///
/// 다른 반복자와 함께 연결.
/// `.foo` 디렉토리의 각 파일과 구성 파일을 반복한다고 가정 해 보겠습니다.
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // DirEntry-s의 반복자에서 PathBufs의 반복자로 변환해야하므로 map을 사용합니다.
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // 이제 설정 파일에 대한 반복자
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // 두 반복자를 하나의 큰 반복자로 연결
/// let files = dirs.chain(config);
///
/// // 그러면 .foo 와 .foorc 의 모든 파일이 제공됩니다.
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// 제공된 클로저 `F: FnOnce() -> A` 를 적용하여 `A` 유형의 단일 요소를 생성하는 반복기입니다.
///
///
/// 이 `struct` 는 [`once_with()`] 기능에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}