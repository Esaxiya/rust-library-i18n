use crate::iter::{FusedIterator, TrustedLen};

/// 제공된 클로저 인 repeater를 적용하여 `A` 유형의 요소를 끝없이 반복하는 새 반복기를 작성합니다. `F: FnMut() -> A`.
///
/// `repeat_with()` 함수는 반복기를 반복해서 호출합니다.
///
/// `repeat_with()` 와 같은 무한 반복기는 유한하게 만들기 위해 [`Iterator::take()`] 와 같은 어댑터와 함께 자주 사용됩니다.
///
/// 필요한 이터레이터의 요소 유형이 [`Clone`] 를 구현하고 소스 요소를 메모리에 유지해도 괜찮다면 [`repeat()`] 함수를 대신 사용해야합니다.
///
///
/// `repeat_with()` 에 의해 생성 된 반복자는 [`DoubleEndedIterator`] 가 아닙니다.
/// [`DoubleEndedIterator`] 를 반환하기 위해 `repeat_with()` 가 필요한 경우 사용 사례를 설명하는 GitHub 문제를여십시오.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::iter;
///
/// // `Clone` 가 아니거나 비싸기 때문에 아직 메모리에 갖고 싶지 않은 유형의 값이 있다고 가정 해 보겠습니다.
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // 영원히 특별한 가치 :
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// 변이를 사용하고 유한하게 :
///
/// ```rust
/// use std::iter;
///
/// // 0에서 2의 3 제곱까지 :
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... 이제 끝났습니다
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// 제공된 클로저 `F: FnMut() -> A` 를 적용하여 `A` 유형의 요소를 끝없이 반복하는 반복기입니다.
///
///
/// 이 `struct` 는 [`repeat_with()`] 기능에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}