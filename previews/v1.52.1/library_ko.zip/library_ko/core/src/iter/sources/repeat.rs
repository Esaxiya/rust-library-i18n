use crate::iter::{FusedIterator, TrustedLen};

/// 단일 요소를 끝없이 반복하는 새 반복기를 만듭니다.
///
/// `repeat()` 기능은 단일 값을 반복해서 반복합니다.
///
/// `repeat()` 와 같은 무한 반복기는 유한하게 만들기 위해 [`Iterator::take()`] 와 같은 어댑터와 함께 자주 사용됩니다.
///
/// 필요한 반복기의 요소 유형이 `Clone` 를 구현하지 않거나 반복 된 요소를 메모리에 유지하지 않으려면 대신 [`repeat_with()`] 함수를 사용할 수 있습니다.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::iter;
///
/// // 4 번 4ever :
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // 그래, 아직 4
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] 로 제한됨 :
///
/// ```
/// use std::iter;
///
/// // 마지막 예는 너무 많은 4입니다.4 개만합시다.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... 이제 끝났습니다
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// 요소를 끝없이 반복하는 반복기입니다.
///
/// 이 `struct` 는 [`repeat()`] 기능에 의해 생성됩니다.자세한 내용은 설명서를 참조하십시오.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}