//! 구성 가능한 외부 반복.
//!
//! 어떤 종류의 컬렉션을 발견하고 해당 컬렉션의 요소에 대한 작업을 수행해야하는 경우 'iterators' 를 빠르게 실행할 수 있습니다.
//! 반복자는 관용적 인 Rust 코드에서 많이 사용되므로 익숙해 질 가치가 있습니다.
//!
//! 자세히 설명하기 전에이 모듈의 구조에 대해 이야기 해 보겠습니다.
//!
//! # Organization
//!
//! 이 모듈은 주로 유형별로 구성됩니다.
//!
//! * [Traits] 핵심 부분입니다.이 traits 는 어떤 종류의 이터레이터가 존재하고 이로 할 수있는 작업을 정의합니다.이 traits 의 방법은 추가 학습 시간을 투자 할 가치가 있습니다.
//! * [Functions] 몇 가지 기본 반복자를 만드는 데 유용한 방법을 제공합니다.
//! * [Structs] 종종이 모듈의 traits 에있는 다양한 메소드의 반환 유형입니다.일반적으로 `struct` 자체보다는 `struct` 를 생성하는 방법을보고 싶을 것입니다.
//! 이유에 대한 자세한 내용은 '[Implementing Iterator](#implementing-iterator)'를 참조하세요.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! 그게 다야!반복자를 살펴 보겠습니다.
//!
//! # Iterator
//!
//! 이 모듈의 핵심은 [`Iterator`] trait 입니다.[`Iterator`] 의 핵심은 다음과 같습니다.
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! 이터레이터에는 [`next`] 라는 메서드가 있으며 호출시 [`Option`]`을 반환합니다.<Item>`.
//! [`next`] 요소가있는 한 [`Some(Item)`] 를 반환하고 모든 요소가 소진되면 `None` 를 반환하여 반복이 완료되었음을 나타냅니다.
//! 개별 반복자는 반복을 재개하도록 선택할 수 있으므로 [`next`] 를 다시 호출하면 결국 특정 시점에서 [`Some(Item)`] 를 다시 반환 할 수도 있고 그렇지 않을 수도 있습니다 (예: [`TryIter`] 참조).
//!
//!
//! [`Iterator`]의 전체 정의에는 다른 여러 메서드도 포함되어 있지만 [`next`] 위에 빌드 된 기본 메서드이므로 무료로 얻을 수 있습니다.
//!
//! 반복자도 구성 가능하며 더 복잡한 형태의 처리를 수행하기 위해 함께 연결하는 것이 일반적입니다.자세한 내용은 아래 [Adapters](#adapters) 섹션을 참조하십시오.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # 세 가지 형태의 반복
//!
//! 컬렉션에서 반복자를 만들 수있는 세 가지 일반적인 메서드가 있습니다.
//!
//! * `iter()`, `&T` 를 반복합니다.
//! * `iter_mut()`, `&mut T` 를 반복합니다.
//! * `into_iter()`, `T` 를 반복합니다.
//!
//! 표준 라이브러리의 다양한 요소는 적절한 경우 세 가지 중 하나 이상을 구현할 수 있습니다.
//!
//! # 반복자 구현
//!
//! 자체 반복기를 생성하려면 두 단계가 필요합니다. 반복기의 상태를 유지하기 위해 `struct` 를 생성 한 다음 해당 `struct` 에 대해 [`Iterator`] 를 구현하는 것입니다.
//! 이것이이 모듈에 너무 많은`struct`가있는 이유입니다. 각 반복기와 반복기 어댑터에 대해 하나씩 있습니다.
//!
//! `1` 에서 `5` 까지 세는 `Counter` 라는 이터레이터를 만들어 보겠습니다.
//!
//! ```
//! // 첫째, 구조체 :
//!
//! /// 1에서 5까지 세는 반복기
//! struct Counter {
//!     count: usize,
//! }
//!
//! // 카운트가 1부터 시작되기를 원하므로 new() 메서드를 추가하여 도움을 드리겠습니다.
//! // 이것은 꼭 필요한 것은 아니지만 편리합니다.
//! // `count` 는 0에서 시작합니다. 아래 `next()`'s 구현에서 그 이유를 알 수 있습니다.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // 그런 다음 `Counter` 에 대해 `Iterator` 를 구현합니다.
//!
//! impl Iterator for Counter {
//!     // 우리는 usize와 함께 셀 것입니다
//!     type Item = usize;
//!
//!     // next() 유일한 필수 방법입니다.
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // 카운트를 늘립니다.이것이 우리가 0에서 시작한 이유입니다.
//!         self.count += 1;
//!
//!         // 계산이 끝났는지 확인하십시오.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // 이제 우리는 그것을 사용할 수 있습니다!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! 이런 식으로 [`next`] 를 호출하면 반복됩니다.Rust 에는 `None` 에 도달 할 때까지 반복기에서 [`next`] 를 호출 할 수있는 구조가 있습니다.다음에 그것에 대해 살펴 보겠습니다.
//!
//! 또한 `Iterator` 는 `next` 를 내부적으로 호출하는 `nth` 및 `fold` 와 같은 메서드의 기본 구현을 제공합니다.
//! 그러나 반복기가 `next` 를 호출하지 않고 더 효율적으로 계산할 수있는 경우 `nth` 및 `fold` 와 같은 메서드의 사용자 지정 구현을 작성할 수도 있습니다.
//!
//! # `for` 루프 및 `IntoIterator`
//!
//! Rust 의 `for` 루프 구문은 실제로 반복자를위한 설탕입니다.다음은 `for` 의 기본 예입니다.
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! 이렇게하면 각 줄에 1부터 5까지의 숫자가 인쇄됩니다.하지만 여기서 뭔가 눈치 채 셨을 것입니다. 우리는 반복자를 생성하기 위해 vector 에서 아무것도 호출하지 않았습니다.무엇을 제공합니까?
//!
//! 표준 라이브러리에는 어떤 것을 반복자로 변환하기위한 trait 가 있습니다. [`IntoIterator`].
//! 이 trait 에는 [`IntoIterator`] 를 구현하는 것을 반복자로 변환하는 [`into_iter`] 라는 하나의 메서드가 있습니다.
//! `for` 루프를 다시 살펴보고 컴파일러가이를 다음으로 변환하는 방법을 살펴 보겠습니다.
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust 는 설탕을 다음과 같이 제거합니다.
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! 먼저 값에 대해 `into_iter()` 를 호출합니다.그런 다음 반환되는 반복기를 일치시켜 `None` 를 볼 때까지 [`next`] 를 계속해서 호출합니다.
//! 이 시점에서 루프에서 `break` 를 수행하고 반복 작업을 마쳤습니다.
//!
//! 여기에 미묘한 부분이 하나 더 있습니다. 표준 라이브러리에는 흥미로운 [`IntoIterator`] 구현이 포함되어 있습니다.
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! 즉, 모든 [`Iterator`]는 자신을 반환하여 [`IntoIterator`] 를 구현합니다.이것은 두 가지를 의미합니다.
//!
//! 1. [`Iterator`] 를 작성하는 경우 `for` 루프와 함께 사용할 수 있습니다.
//! 2. 컬렉션을 만드는 경우 [`IntoIterator`] 를 구현하면 컬렉션을 `for` 루프와 함께 사용할 수 있습니다.
//!
//! # 참조로 반복
//!
//! [`into_iter()`] 는 `self` 를 값으로 사용하므로 `for` 루프를 사용하여 컬렉션을 반복하면 해당 컬렉션이 소비됩니다.종종 컬렉션을 소비하지 않고 반복 할 수 있습니다.
//! 많은 컬렉션은 일반적으로 각각 `iter()` 및 `iter_mut()` 라고하는 참조에 대한 반복자를 제공하는 메서드를 제공합니다.
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` 이 함수는 여전히 소유하고 있습니다.
//! ```
//!
//! 컬렉션 유형 `C` 가 `iter()` 를 제공하는 경우 일반적으로 `iter()` 만 호출하는 구현으로 `&C` 용 `IntoIterator` 도 구현합니다.
//! 마찬가지로 `iter_mut()` 를 제공하는 컬렉션 `C` 는 일반적으로 `iter_mut()` 에 위임하여 `&mut C` 용 `IntoIterator` 를 구현합니다.이렇게하면 편리한 속기가 가능합니다.
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` 와 동일
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` 와 동일
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! 많은 컬렉션이 `iter()` 를 제공하지만 모든 컬렉션이 `iter_mut()` 를 제공하는 것은 아닙니다.
//! 예를 들어 [`HashSet<T>`] 또는 [`HashMap<K, V>`] 의 키를 변경하면 키 해시가 변경되면 컬렉션이 일관성없는 상태가 될 수 있으므로 이러한 컬렉션은 `iter()` 만 제공합니다.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] 를 받고 또 다른 [`Iterator`] 를 반환하는 함수는 '어댑터'의 한 형태이기 때문에 종종 '반복자 어댑터'라고합니다.
//! pattern'.
//!
//! 공통 반복기 어댑터에는 [`map`], [`take`] 및 [`filter`] 가 포함됩니다.
//! 자세한 내용은 설명서를 참조하십시오.
//!
//! 반복기 어댑터 panics 인 경우 반복기는 지정되지 않은 (하지만 메모리 안전) 상태가됩니다.
//! 이 상태는 Rust 버전간에 동일하게 유지된다는 보장도 없으므로 당황한 반복자가 반환 한 정확한 값에 의존하지 않아야합니다.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! 반복자 (및 반복자 [adapters](#adapters)) 는 *지연* 입니다. 이것은 반복자를 만드는 것만으로는 _do_ 가 많이 발생하지 않는다는 것을 의미합니다. [`next`] 를 호출 할 때까지 아무 일도 일어나지 않습니다.
//! 이것은 부작용만을 위해 반복자를 만들 때 때때로 혼란의 원인이됩니다.
//! 예를 들어 [`map`] 메서드는 반복되는 각 요소에 대해 클로저를 호출합니다.
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! 이터레이터를 사용하지 않고 생성했을 뿐이므로 값을 인쇄하지 않습니다.컴파일러는 이러한 종류의 동작에 대해 경고합니다.
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! 부작용에 대한 [`map`] 를 작성하는 관용적 인 방법은 `for` 루프를 사용하거나 [`for_each`] 메서드를 호출하는 것입니다.
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! 반복기를 평가하는 또 다른 일반적인 방법은 [`collect`] 메서드를 사용하여 새 컬렉션을 생성하는 것입니다.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! 반복자는 유한 할 필요가 없습니다.예를 들어 개방형 범위는 무한 반복기입니다.
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! [`take`] 반복기 어댑터를 사용하여 무한 반복기를 유한 반복기로 바꾸는 것이 일반적입니다.
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! 이렇게하면 `0` 에서 `4` 까지의 숫자가 각 줄에 인쇄됩니다.
//!
//! 무한 반복기에 대한 메서드는 결과가 유한 한 시간 내에 수학적으로 결정될 수있는 메서드라도 종료되지 않을 수 있습니다.
//! 특히 일반적으로 반복기의 모든 요소를 통과해야하는 [`min`] 와 같은 메서드는 무한 반복기에 대해 성공적으로 반환되지 않을 가능성이 높습니다.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // 오 안돼!무한 루프!
//! // `ones.min()` 무한 루프가 발생하므로이 지점에 도달하지 않습니다!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;