use crate::iter;
use crate::num::Wrapping;

/// Trait 는 반복기를 합산하여 생성 할 수있는 유형을 나타냅니다.
///
/// 이 trait 는 반복기에서 [`sum()`] 메서드를 구현하는 데 사용됩니다.
/// trait 를 구현하는 유형은 [`sum()`] 메소드로 생성 할 수 있습니다.
/// [`FromIterator`] 와 마찬가지로이 trait 는 거의 직접 호출되지 않고 대신 [`Iterator::sum()`] 를 통해 상호 작용해야합니다.
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// 반복자를 취하고 항목을 "summing up" 로 요소에서 `Self` 를 생성하는 메소드입니다.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait 는 반복기의 요소를 곱하여 만들 수있는 형식을 나타냅니다.
///
/// 이 trait 는 반복기에서 [`product()`] 메서드를 구현하는 데 사용됩니다.
/// trait 를 구현하는 유형은 [`product()`] 메소드로 생성 할 수 있습니다.
/// [`FromIterator`] 와 마찬가지로이 trait 는 거의 직접 호출되지 않고 대신 [`Iterator::product()`] 를 통해 상호 작용해야합니다.
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// 반복자를 취하고 항목을 곱하여 요소에서 `Self` 를 생성하는 메소드입니다.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// [`Iterator`] 의 각 요소를 가져옵니다. [`Err`] 이면 더 이상 요소를 가져 오지 않고 [`Err`] 가 반환됩니다.
    /// [`Err`] 가 발생하지 않으면 모든 요소의 합계가 반환됩니다.
    ///
    /// # Examples
    ///
    /// 이것은 vector 의 모든 정수를 합산하여 음수 요소가 발견되면 합계를 거부합니다.
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// [`Iterator`] 의 각 요소를 가져옵니다. [`Err`] 이면 더 이상 요소를 가져 오지 않고 [`Err`] 가 반환됩니다.
    /// [`Err`] 가 발생하지 않으면 모든 요소의 곱이 반환됩니다.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// [`Iterator`] 의 각 요소를 가져옵니다. [`None`] 이면 더 이상 요소를 가져 오지 않고 [`None`] 가 반환됩니다.
    /// [`None`] 가 발생하지 않으면 모든 요소의 합계가 반환됩니다.
    ///
    /// # Examples
    ///
    /// 이것은 문자열의 vector 에서 문자 'a' 의 위치를 합산합니다. 단어에 문자 'a' 가없는 경우 연산은 `None` 를 반환합니다.
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// [`Iterator`] 의 각 요소를 가져옵니다. [`None`] 이면 더 이상 요소를 가져 오지 않고 [`None`] 가 반환됩니다.
    /// [`None`] 가 발생하지 않으면 모든 요소의 곱이 반환됩니다.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}