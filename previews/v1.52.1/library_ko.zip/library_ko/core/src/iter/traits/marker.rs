/// 소진되었을 때 항상 `None` 를 계속 산출하는 반복기입니다.
///
/// `None` 를 한 번 반환 한 융합 반복기에서 next를 호출하면 [`None`] 가 다시 반환됩니다.
/// 이 trait 는 [`Iterator::fuse()`] 를 최적화 할 수 있기 때문에 이러한 방식으로 동작하는 모든 반복기에 의해 구현되어야합니다.
///
///
/// Note: 일반적으로 통합 반복기가 필요한 경우 제네릭 경계에서 `FusedIterator` 를 사용해서는 안됩니다.
/// 대신 반복기에서 [`Iterator::fuse()`] 를 호출해야합니다.
/// 반복기가 이미 융합 된 경우 추가 [`Fuse`] 래퍼는 성능 저하없이 작동하지 않습니다.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// size_hint를 사용하여 정확한 길이를보고하는 반복기입니다.
///
/// 반복기는 정확하거나 (하한이 상한과 같음) 상한이 [`None`] 인 크기 힌트를보고합니다.
///
/// 실제 반복기 길이가 [`usize::MAX`] 보다 큰 경우 상한은 [`None`] 여야합니다.
/// 이 경우 하한은 [`usize::MAX`] 여야하므로 [`Iterator::size_hint()`] 는 `(usize::MAX, None)` 가됩니다.
///
/// 반복자는보고 한 요소 수를 정확히 생성하거나 끝에 도달하기 전에 분기해야합니다.
///
/// # Safety
///
/// 이 trait 는 계약이 유지 될 때만 구현되어야합니다.
/// 이 trait 의 소비자는 [`Iterator::size_hint()`]’s 상한을 검사해야합니다.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// 항목을 산출 할 때 기본 [`SourceIter`] 에서 하나 이상의 요소를 가져 오는 반복기입니다.
///
/// 반복자를 진행하는 모든 메서드 호출, 예 :
/// [`next()`] 또는 [`try_fold()`] 는 각 단계에 대해 반복기의 기본 소스 중 적어도 하나의 값이 밖으로 이동되고 반복기 체인의 결과가 소스의 구조적 제약이 그러한 삽입을 허용한다고 가정하여 그 자리에 삽입 될 수 있음을 보장합니다.
///
/// 즉,이 trait 는 반복기 파이프 라인을 제자리에서 수집 할 수 있음을 나타냅니다.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}