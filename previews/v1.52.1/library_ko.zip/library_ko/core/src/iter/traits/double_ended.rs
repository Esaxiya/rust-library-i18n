use crate::ops::{ControlFlow, Try};

/// 양쪽 끝에서 요소를 생성 할 수있는 반복기입니다.
///
/// `DoubleEndedIterator` 를 구현하는 것은 [`Iterator`] 를 구현하는 것보다 하나의 추가 기능을 가지고 있습니다. 바로 앞과 뒤에서 '항목'을 가져 오는 기능입니다.
///
///
/// 앞뒤가 모두 동일한 범위에서 작동하고 교차하지 않는다는 점에 유의하는 것이 중요합니다. 중간에서 만나면 반복이 끝납니다.
///
/// [`Iterator`] 프로토콜과 비슷한 방식으로 `DoubleEndedIterator` 가 [`next_back()`] 에서 [`None`] 를 반환하면 다시 호출하면 [`Some`] 를 다시 반환 할 수도 있고 반환하지 않을 수도 있습니다.
/// [`next()`] 이 목적을 위해 [`next_back()`] 와 상호 교환이 가능합니다.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// 반복기의 끝에서 요소를 제거하고 반환합니다.
    ///
    /// 더 이상 요소가 없으면 `None` 를 반환합니다.
    ///
    /// [trait-level] 문서에는 자세한 내용이 포함되어 있습니다.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator`의 메서드에 의해 생성 된 요소는 [`Iterator`]의 메서드에 의해 생성 된 요소와 다를 수 있습니다.
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` 요소에 의해 뒤에서 반복기를 진행합니다.
    ///
    /// `advance_back_by` [`advance_by`] 의 역 버전입니다.이 메서드는 [`None`] 를 만날 때까지 [`next_back`] 를 최대 `n` 번 호출하여 뒤에서 시작하여 `n` 요소를 간절히 건너 뜁니다.
    ///
    /// `advance_back_by(n)` 반복기가 `n` 요소만큼 성공적으로 진행되면 [`Ok(())`] 를 반환하고 [`None`] 가 발생하면 [`Err(k)`] 를 반환합니다. 여기서 `k` 는 요소가 부족하기 전에 반복기가 진행되는 요소의 수입니다 (예 :
    /// 반복기의 길이).
    /// `k` 는 항상 `n` 보다 작습니다.
    ///
    /// `advance_back_by(0)` 를 호출하면 요소가 사용되지 않고 항상 [`Ok(())`] 가 반환됩니다.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` 만 건너 뛰었습니다.
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// 반복자의 끝에서 n 번째 요소를 반환합니다.
    ///
    /// 이것은 본질적으로 [`Iterator::nth()`] 의 역 버전입니다.
    /// 대부분의 인덱싱 작업과 마찬가지로 개수는 0부터 시작하므로 `nth_back(0)` 는 끝에서 첫 번째 값을 반환하고 `nth_back(1)` 는 두 번째 값을 반환합니다.
    ///
    ///
    /// 반환 된 요소를 포함하여 끝과 반환 된 요소 사이의 모든 요소가 사용됩니다.
    /// 이것은 또한 동일한 반복기에서 `nth_back(0)` 를 여러 번 호출하면 다른 요소가 반환됨을 의미합니다.
    ///
    /// `nth_back()` `n` 가 반복기의 길이보다 크거나 같으면 [`None`] 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` 를 여러 번 호출해도 반복기가 되 감지 않습니다.
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` 요소보다 작은 경우 `None` 반환 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// 이것은 [`Iterator::try_fold()`] 의 역 버전입니다. 이터레이터의 뒤에서 시작하는 요소를 사용합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // 단락 되었기 때문에 나머지 요소는 반복기를 통해 계속 사용할 수 있습니다.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// 반복기의 요소를 뒤에서 시작하여 단일 최종 값으로 줄이는 반복기 메서드입니다.
    ///
    /// 이것은 [`Iterator::fold()`] 의 역 버전입니다. 이터레이터의 뒤에서 시작하는 요소를 사용합니다.
    ///
    /// `rfold()` 두 개의 인수, 즉 초기 값과 두 개의 인수 ('accumulator' 및 요소)가있는 클로저를 사용합니다.
    /// 클로저는 누산기가 다음 반복을 위해 가져야하는 값을 반환합니다.
    ///
    /// 초기 값은 누산기가 첫 번째 호출에서 가질 값입니다.
    ///
    /// 이 클로저를 반복기의 모든 요소에 적용한 후 `rfold()` 는 누산기를 반환합니다.
    ///
    /// 이 작업을 'reduce' 또는 'inject' 라고도합니다.
    ///
    /// 접기는 무언가의 컬렉션이 있고 그로부터 단일 값을 생성하고자 할 때 유용합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // 모든 요소의 합
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// 이 예제는 초기 값으로 시작하여 뒤에서 앞까지 각 요소로 계속되는 문자열을 작성합니다.
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// 술어를 만족하는 뒤에서 반복기의 요소를 검색합니다.
    ///
    /// `rfind()` `true` 또는 `false` 를 반환하는 클로저를 사용합니다.
    /// 끝에서 시작하여 반복기의 각 요소에이 클로저를 적용하고, 이들 중 하나가 `true` 를 반환하면 `rfind()` 는 [`Some(element)`] 를 반환합니다.
    /// 모두 `false` 를 반환하면 [`None`] 를 반환합니다.
    ///
    /// `rfind()` 단락 됨;즉, 클로저가 `true` 를 반환하자마자 처리를 중지합니다.
    ///
    /// `rfind()` 는 참조를 취하고 많은 반복기가 참조를 반복하기 때문에 인수가 이중 참조 인 경우 혼란 스러울 수있는 상황이 발생합니다.
    ///
    /// 이 효과는 `&&x` 의 아래 예에서 볼 수 있습니다.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// 첫 번째 `true` 에서 중지 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // 더 많은 요소가 있으므로 여전히 `iter` 를 사용할 수 있습니다.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}