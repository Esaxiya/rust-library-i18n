// ignore-tidy-filelength이 파일은 거의 독점적으로 `Iterator` 의 정의로 구성됩니다.
// 여러 파일로 분할 할 수 없습니다.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// 반복자를 처리하기위한 인터페이스입니다.
///
/// 이것이 주 반복자 trait 입니다.
/// 일반적으로 반복기의 개념에 대한 자세한 내용은 [module-level documentation] 를 참조하십시오.
/// 특히 [implement `Iterator`][impl] 방법을 알고 싶을 수 있습니다.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// 반복되는 요소의 유형입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// 반복기를 진행하고 다음 값을 반환합니다.
    ///
    /// 반복이 완료되면 [`None`] 를 반환합니다.
    /// 개별 반복기 구현은 반복을 재개하도록 선택할 수 있으므로 `next()` 를 다시 호출하면 결국 어떤 시점에서 [`Some(Item)`] 를 다시 반환하기 시작할 수도 있고 그렇지 않을 수도 있습니다.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() 를 호출하면 다음 값이 반환됩니다.
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... 끝나면 None.
    /// assert_eq!(None, iter.next());
    ///
    /// // 더 많은 호출은 `None` 를 반환하거나 반환하지 않을 수 있습니다.여기서 그들은 항상 그렇게 할 것입니다.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// 반복기의 나머지 길이에 대한 경계를 반환합니다.
    ///
    /// 특히 `size_hint()` 는 첫 번째 요소가 하한이고 두 번째 요소가 상한 인 튜플을 반환합니다.
    ///
    /// 반환되는 튜플의 나머지 절반은 [`Option`]`<`[`usize`]`>`입니다.
    /// 여기서 [`None`] 는 알려진 상한이 없거나 상한이 [`usize`] 보다 크다는 것을 의미합니다.
    ///
    /// # 구현 참고 사항
    ///
    /// 반복기 구현이 선언 된 요소 수를 산출하도록 강제되지 않습니다.버그가있는 반복기는 요소의 하한보다 적거나 상한보다 더 많이 산출 할 수 있습니다.
    ///
    /// `size_hint()` 주로 반복기의 요소를위한 공간을 예약하는 것과 같은 최적화에 사용하기위한 것이지만 안전하지 않은 코드에서 경계 검사를 생략하는 것과 같이 신뢰할 수 없어야합니다.
    /// `size_hint()` 의 잘못된 구현은 메모리 안전 위반으로 이어지지 않아야합니다.
    ///
    /// 즉, 구현시 올바른 추정치를 제공해야합니다. 그렇지 않으면 trait 의 프로토콜을 위반하게됩니다.
    ///
    /// 기본 구현은 모든 이터레이터에 맞는`(0,`[`None`]`)`을 반환합니다.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// 더 복잡한 예 :
    ///
    /// ```
    /// // 0에서 10까지의 짝수.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // 0 번에서 10 번까지 반복 할 수 있습니다.
    /// // 정확히 5 개라는 것을 아는 것은 filter() 를 실행하지 않고는 불가능합니다.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() 로 5 개의 숫자를 더 추가합시다
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // 이제 두 경계가 5 씩 증가합니다.
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// 상한값에 대한 `None` 반환 :
    ///
    /// ```
    /// // 무한 반복기에는 상한이없고 가능한 최대 하한이 있습니다.
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// 반복자를 사용하여 반복 횟수를 계산하고 반환합니다.
    ///
    /// 이 메서드는 [`None`] 를 만날 때까지 반복적으로 [`next`] 를 호출하여 [`Some`] 를 본 횟수를 반환합니다.
    /// 반복기에 요소가없는 경우에도 [`next`] 는 적어도 한 번 호출해야합니다.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # 오버플로 동작
    ///
    /// 이 메서드는 오버플로를 방지하지 않으므로 [`usize::MAX`] 요소를 초과하는 반복기의 요소를 계산하면 잘못된 결과 또는 panics 가 생성됩니다.
    ///
    /// 디버그 어설 션이 활성화 된 경우 panic 가 보장됩니다.
    ///
    /// # Panics
    ///
    /// 반복기에 [`usize::MAX`] 요소가 더 많은 경우이 함수는 panic 가 될 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// 반복기를 사용하여 마지막 요소를 반환합니다.
    ///
    /// 이 메서드는 [`None`] 를 반환 할 때까지 반복기를 평가합니다.
    /// 그렇게하는 동안 현재 요소를 추적합니다.
    /// [`None`] 가 반환 된 후 `last()` 는 마지막으로 본 요소를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// 반복기를 `n` 요소로 진행합니다.
    ///
    /// 이 메서드는 [`None`] 를 만날 때까지 [`next`] 를 최대 `n` 번 호출하여 `n` 요소를 간절히 건너 뜁니다.
    ///
    /// `advance_by(n)` 반복기가 `n` 요소만큼 성공적으로 진행되면 [`Ok(())`][Ok] 를 반환하고 [`None`] 가 발생하면 [`Err(k)`][Err] 를 반환합니다. 여기서 `k` 는 요소가 부족하기 전에 반복기가 진행되는 요소의 수입니다 (예 :
    /// 반복기의 길이).
    /// `k` 는 항상 `n` 보다 작습니다.
    ///
    /// `advance_by(0)` 를 호출하면 요소가 사용되지 않고 항상 [`Ok(())`][Ok] 가 반환됩니다.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` 만 건너 뛰었습니다.
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// 이터레이터의 n 번째 요소를 반환합니다.
    ///
    /// 대부분의 인덱싱 작업과 마찬가지로 개수는 0부터 시작하므로 `nth(0)` 는 첫 번째 값을 반환하고 `nth(1)` 는 두 번째 값을 반환합니다.
    ///
    /// 모든 선행 요소와 반환 된 요소는 반복기에서 사용됩니다.
    /// 즉, 이전 요소가 삭제되고 동일한 반복기에서 `nth(0)` 를 여러 번 호출하면 다른 요소가 반환됩니다.
    ///
    ///
    /// `nth()` `n` 가 반복기의 길이보다 크거나 같으면 [`None`] 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` 를 여러 번 호출해도 반복기가 되 감지 않습니다.
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` 요소보다 작은 경우 `None` 반환 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// 동일한 지점에서 시작하지만 각 반복에서 주어진 양만큼 단계적으로 반복기를 만듭니다.
    ///
    /// 참고 1: 주어진 단계에 관계없이 반복기의 첫 번째 요소가 항상 반환됩니다.
    ///
    /// 참고 2: 무시 된 요소를 가져 오는 시간은 고정되지 않습니다.
    /// `StepBy` 시퀀스 `next(), nth(step-1), nth(step-1),…` 처럼 동작하지만 시퀀스처럼 동작 할 수도 있습니다.
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// 사용되는 방법은 성능상의 이유로 일부 반복기에서 변경 될 수 있습니다.
    /// 두 번째 방법은 반복기를 더 빨리 진행하고 더 많은 항목을 소비 할 수 있습니다.
    ///
    /// `advance_n_and_return_first` 다음과 같습니다.
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// 주어진 단계가 `0` 인 경우 메서드는 panic 입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// 두 개의 반복자를 취하고 두 반복자를 순서대로 새 반복자를 만듭니다.
    ///
    /// `chain()` 첫 번째 반복기의 값을 먼저 반복 한 다음 두 번째 반복자의 값을 반복하는 새 반복기를 반환합니다.
    ///
    /// 즉, 두 개의 반복자를 하나의 체인으로 연결합니다.🔗
    ///
    /// [`once`] 일반적으로 단일 값을 다른 종류의 반복 체인에 적용하는 데 사용됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` 에 대한 인수는 [`IntoIterator`] 를 사용하므로 [`Iterator`] 자체뿐만 아니라 [`Iterator`] 로 변환 할 수있는 모든 것을 전달할 수 있습니다.
    /// 예를 들어 슬라이스 (`&[T]`) 는 [`IntoIterator`] 를 구현하므로 `chain()` 에 직접 전달할 수 있습니다.
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Windows API로 작업하는 경우 [`OsStr`] 를 `Vec<u16>` 로 변환 할 수 있습니다.
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 두 반복자를 쌍의 단일 반복기로 '압축'합니다.
    ///
    /// `zip()` 두 개의 다른 이터레이터를 반복 할 새 이터레이터를 반환하여 첫 번째 요소가 첫 번째 이터레이터에서 나오고 두 번째 요소가 두 번째 이터레이터에서 나온 튜플을 반환합니다.
    ///
    ///
    /// 즉, 두 개의 반복자를 하나의 반복자로 압축합니다.
    ///
    /// 반복자가 [`None`] 를 반환하면 압축 된 반복자의 [`next`] 가 [`None`] 를 반환합니다.
    /// 첫 번째 반복자가 [`None`] 를 반환하면 `zip` 가 단락되고 두 번째 반복자에서 `next` 가 호출되지 않습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` 에 대한 인수는 [`IntoIterator`] 를 사용하므로 [`Iterator`] 자체뿐만 아니라 [`Iterator`] 로 변환 할 수있는 모든 것을 전달할 수 있습니다.
    /// 예를 들어 슬라이스 (`&[T]`) 는 [`IntoIterator`] 를 구현하므로 `zip()` 에 직접 전달할 수 있습니다.
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` 무한 반복자를 유한 반복자로 압축하는 데 자주 사용됩니다.
    /// 유한 반복기가 결국 [`None`] 를 반환하고 지퍼를 끝내기 때문에 작동합니다.`(0..)` 를 사용한 압축은 [`enumerate`] 와 매우 유사합니다.
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// 원래 반복기의 인접한 항목 사이에 `separator` 의 복사본을 배치하는 새 반복기를 만듭니다.
    ///
    /// `separator` 가 [`Clone`] 를 구현하지 않거나 매번 계산해야하는 경우 [`intersperse_with`] 를 사용합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` 의 첫 번째 요소입니다.
    /// assert_eq!(a.next(), Some(&100)); // 구분 기호입니다.
    /// assert_eq!(a.next(), Some(&1));   // `a` 의 다음 요소입니다.
    /// assert_eq!(a.next(), Some(&100)); // 구분 기호입니다.
    /// assert_eq!(a.next(), Some(&2));   // `a` 의 마지막 요소입니다.
    /// assert_eq!(a.next(), None);       // 반복기가 완료되었습니다.
    /// ```
    ///
    /// `intersperse` 공통 요소를 사용하여 반복자의 항목을 결합하는 데 매우 유용 할 수 있습니다.
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// `separator` 에 의해 생성 된 항목을 원래 반복자의 인접한 항목 사이에 배치하는 새 반복기를 만듭니다.
    ///
    /// 클로저는 기본 반복기에서 인접한 두 항목 사이에 항목이 배치 될 때마다 정확히 한 번 호출됩니다.
    /// 특히, 기본 반복자가 두 개 미만의 항목을 산출하고 마지막 항목이 산출 된 후에 클로저가 호출되지 않습니다.
    ///
    ///
    /// 반복자의 항목이 [`Clone`] 를 구현하는 경우 [`intersperse`] 를 사용하는 것이 더 쉬울 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` 의 첫 번째 요소입니다.
    /// assert_eq!(it.next(), Some(NotClone(99))); // 구분 기호입니다.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` 의 다음 요소입니다.
    /// assert_eq!(it.next(), Some(NotClone(99))); // 구분 기호입니다.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` 의 마지막 요소입니다.
    /// assert_eq!(it.next(), None);               // 반복기가 완료되었습니다.
    /// ```
    ///
    /// `intersperse_with` 구분 기호를 계산해야하는 상황에서 사용할 수 있습니다.
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // 클로저는 항목을 생성하기 위해 컨텍스트를 가변적으로 차용합니다.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// 클로저를 가져와 각 요소에 대해 해당 클로저를 호출하는 반복자를 만듭니다.
    ///
    /// `map()` 인수를 사용하여 한 반복자를 다른 반복자로 변환합니다.
    /// [`FnMut`] 를 구현하는 것.원래 이터레이터의 각 요소에 대해이 클로저를 호출하는 새 이터레이터를 생성합니다.
    ///
    /// 유형을 잘 생각한다면 `map()` 를 다음과 같이 생각할 수 있습니다.
    /// `A` 유형의 요소를 제공하는 반복기가 있고 다른 유형 `B` 의 반복기를 원하는 경우 `map()` 를 사용하여 `A` 를 사용하고 `B` 를 반환하는 클로저를 전달할 수 있습니다.
    ///
    ///
    /// `map()` 개념적으로 [`for`] 루프와 유사합니다.그러나 `map()` 는 게으 르기 때문에 이미 다른 반복기로 작업하고있을 때 가장 잘 사용됩니다.
    /// 부작용에 대해 일종의 루핑을 수행하는 경우 `map()` 보다 [`for`] 를 사용하는 것이 더 관용적 인 것으로 간주됩니다.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 어떤 종류의 부작용을 겪고 있다면 `map()` 보다 [`for`] 를 선호하십시오.
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // 이러지 마세요 :
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // 게으 르기 때문에 실행조차되지 않습니다.Rust 가 이에 대해 경고합니다.
    ///
    /// // 대신 다음을 사용하십시오.
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// 반복기의 각 요소에 대해 클로저를 호출합니다.
    ///
    /// 이는 `break` 및 `continue` 가 클로저에서 가능하지 않지만 반복기에서 [`for`] 루프를 사용하는 것과 동일합니다.
    /// 일반적으로 `for` 루프를 사용하는 것이 더 관용적이지만 더 긴 반복기 체인의 끝에서 항목을 처리 할 때 `for_each` 가 더 읽기 쉬울 수 있습니다.
    ///
    /// 경우에 따라 `for_each` 는 `Chain` 와 같은 어댑터에서 내부 반복을 사용하기 때문에 루프보다 빠를 수도 있습니다.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// 이러한 작은 예의 경우 `for` 루프가 더 깔끔 할 수 있지만 반복기가 더 긴 기능적 스타일을 유지하는 데 `for_each` 가 더 나을 수 있습니다.
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// 요소가 생성되어야하는지 결정하기 위해 클로저를 사용하는 반복기를 생성합니다.
    ///
    /// 요소가 주어지면 클로저는 `true` 또는 `false` 를 반환해야합니다.반환 된 이터레이터는 클로저가 true를 반환하는 요소 만 생성합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()` 로 전달 된 클로저가 참조를 취하고 많은 반복자가 참조를 반복하기 때문에 클로저 유형이 이중 참조 인 혼란스러운 상황이 발생할 수 있습니다.
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // * 두 개가 필요합니다!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 대신 인수에 디스트 럭처링을 사용하여 하나를 제거하는 것이 일반적입니다.
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // 둘다 *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 아니면 둘다:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // 두 개의 &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 이 레이어의.
    ///
    /// `iter.filter(f).next()` 는 `iter.find(f)` 와 동일합니다.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// 필터링하고 매핑하는 반복기를 만듭니다.
    ///
    /// 반환 된 반복자는 제공된 클로저가 `Some(value)` 를 반환하는 '값'만 생성합니다.
    ///
    /// `filter_map` [`filter`] 및 [`map`] 의 체인을 더 간결하게 만드는 데 사용할 수 있습니다.
    /// 아래 예는 `map().filter().map()` 를 `filter_map` 에 대한 단일 호출로 단축하는 방법을 보여줍니다.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 다음은 동일한 예이지만 [`filter`] 및 [`map`] 를 사용하는 경우 :
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// 현재 반복 횟수와 다음 값을 제공하는 반복기를 만듭니다.
    ///
    /// 반환 된 반복기는 `(i, val)` 쌍을 생성합니다. 여기서 `i` 는 반복의 현재 인덱스이고 `val` 는 반복자가 반환 한 값입니다.
    ///
    ///
    /// `enumerate()` 카운트를 [`usize`] 로 유지합니다.
    /// 다른 크기의 정수로 계산하려는 경우 [`zip`] 함수는 유사한 기능을 제공합니다.
    ///
    /// # 오버플로 동작
    ///
    /// 이 메서드는 오버플로에 대해 보호하지 않으므로 [`usize::MAX`] 요소 이상을 열거하면 잘못된 결과 또는 panics 가 생성됩니다.
    /// 디버그 어설 션이 활성화 된 경우 panic 가 보장됩니다.
    ///
    /// # Panics
    ///
    /// 반환 될 인덱스가 [`usize`] 를 오버플로 할 경우 반환 된 반복자는 panic 가 될 수 있습니다.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// [`peek`] 를 사용하여 사용하지 않고 반복기의 다음 요소를 볼 수있는 반복기를 만듭니다.
    ///
    /// 반복기에 [`peek`] 메서드를 추가합니다.자세한 내용은 설명서를 참조하십시오.
    ///
    /// 기본 반복기는 [`peek`] 가 처음 호출 될 때 계속 진행됩니다. 다음 요소를 검색하기 위해 [`next`] 가 기본 반복기에서 호출되므로 모든 부작용 (예 :
    ///
    /// [`next`] 메소드의 다음 값을 가져 오는 것 이외의 모든 것이 발생합니다.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future 를 볼 수 있습니다.
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // 우리는 peek() 를 여러 번 할 수 있습니다. 반복기는 진행되지 않습니다.
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // 반복자가 완료된 후 peek() 도
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// 조건 자에 따라 요소를 [`건너 뛰는`] 반복자를 만듭니다.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` 종결을 인수로 취합니다.반복기의 각 요소에 대해이 클로저를 호출하고 `false` 를 반환 할 때까지 요소를 무시합니다.
    ///
    /// `false` 가 반환 된 후 `skip_while()`'s 작업이 종료되고 나머지 요소가 생성됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()` 에 전달 된 클로저는 참조를 취하고 많은 이터레이터가 참조를 반복하기 때문에 클로저 인수의 유형이 이중 참조 인 혼란스러운 상황이 발생할 수 있습니다.
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // * 두 개가 필요합니다!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 초기 `false` 후 중지 :
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // 이것은 거짓이었을 것입니다. 우리는 이미 거짓을 얻었으므로 skip_while() 는 더 이상 사용되지 않습니다.
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// 조건자를 기반으로 요소를 생성하는 반복기를 만듭니다.
    ///
    /// `take_while()` 종결을 인수로 취합니다.반복기의 각 요소에 대해이 클로저를 호출하고 `true` 를 반환하는 동안 요소를 생성합니다.
    ///
    /// `false` 가 반환 된 후 `take_while()`'s 작업은 종료되고 나머지 요소는 무시됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` 로 전달 된 클로저가 참조를 취하고 많은 반복자가 참조를 반복하기 때문에 클로저 유형이 이중 참조 인 혼란스러운 상황이 발생할 수 있습니다.
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // * 두 개가 필요합니다!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 초기 `false` 후 중지 :
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // 0보다 작은 요소가 더 많이 있지만 이미 거짓이 있으므로 take_while() 는 더 이상 사용되지 않습니다.
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` 는 값이 포함되어야하는지 여부를 확인하기 위해 값을 확인해야하므로 반복기를 사용하면 값이 제거 된 것을 볼 수 있습니다.
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` 는 더 이상 존재하지 않습니다. 반복을 중지해야하는지 확인하기 위해 소비되었지만 반복기에 다시 배치되지 않았기 때문입니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// 조건 자와 맵을 기반으로 요소를 모두 생성하는 반복기를 만듭니다.
    ///
    /// `map_while()` 종결을 인수로 취합니다.
    /// 반복기의 각 요소에 대해이 클로저를 호출하고 [`Some(_)`][`Some`] 를 반환하는 동안 요소를 생성합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 다음은 동일한 예이지만 [`take_while`] 및 [`map`] 를 사용하는 경우 :
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 초기 [`None`] 후 중지 :
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32 (4, 5)에 맞을 수있는 더 많은 요소가 있지만 `map_while` 는 `-3` 에 대해 `None` 를 반환했고 (`predicate` 가 `None` 를 반환 했으므로) `collect` 는 첫 번째 `None` 에서 멈 춥니 다.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` 는 값이 포함되어야하는지 여부를 확인하기 위해 값을 확인해야하므로 반복기를 사용하면 값이 제거 된 것을 볼 수 있습니다.
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` 는 더 이상 존재하지 않습니다. 반복을 중지해야하는지 확인하기 위해 소비되었지만 반복기에 다시 배치되지 않았기 때문입니다.
    ///
    /// [`take_while`] 와 달리이 반복자는 통합되지 **않습니다**.
    /// 첫 번째 [`None`] 가 반환 된 후이 반복기가 반환하는 내용도 지정되지 않습니다.
    /// 융합 된 반복자가 필요한 경우 [`fuse`] 를 사용하십시오.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// 첫 번째 `n` 요소를 건너 뛰는 반복기를 만듭니다.
    ///
    /// 소비 된 후 나머지 요소가 산출됩니다.
    /// 이 메서드를 직접 재정의하는 대신 `nth` 메서드를 재정의하십시오.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// 첫 번째 `n` 요소를 생성하는 반복기를 만듭니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` 유한하게 만들기 위해 종종 무한 반복기와 함께 사용됩니다.
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 사용 가능한 `n` 요소보다 작은 경우 `take` 는 기본 반복기의 크기로 자체를 제한합니다.
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// 내부 상태를 보유하고 새 반복기를 생성하는 [`fold`] 와 유사한 반복기 어댑터.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` 두 개의 인수를 취합니다: 내부 상태를 시드하는 초기 값과 두 개의 인수가있는 클로저, 첫 번째는 내부 상태에 대한 변경 가능한 참조이고 두 번째는 반복기 요소입니다.
    ///
    /// 클로저는 내부 상태에 할당하여 반복간에 상태를 공유 할 수 있습니다.
    ///
    /// 반복에서 클로저는 반복기의 각 요소에 적용되며 클로저의 반환 값인 [`Option`] 는 반복기에 의해 생성됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // 반복 할 때마다 상태에 요소를 곱합니다.
    ///     *state = *state * x;
    ///
    ///     // 그런 다음 우리는 국가의 부정을 산출 할 것입니다
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// 맵처럼 작동하지만 중첩 된 구조를 평평하게하는 반복기를 만듭니다.
    ///
    /// [`map`] 어댑터는 매우 유용하지만 클로저 인수가 값을 생성 할 때만 가능합니다.
    /// 대신 반복자를 생성하면 추가 간접 레이어가 있습니다.
    /// `flat_map()` 이 추가 레이어는 자체적으로 제거됩니다.
    ///
    /// `flat_map(f)` 를 [`map`] ping과 동일한 의미로 생각한 다음 `map(f).flatten()` 에서처럼 [`flatten`] ing 할 수 있습니다.
    ///
    /// `flat_map()` 에 대한 또 다른 생각: [`map`]의 클로저는 각 요소에 대해 하나의 항목을 반환하고 `flat_map()`'s 클로저는 각 요소에 대한 반복자를 반환합니다.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() 반복자를 반환
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// 중첩 된 구조를 평면화하는 반복기를 만듭니다.
    ///
    /// 이것은 반복기의 반복자 또는 반복기로 전환 될 수있는 사물의 반복자가 있고 한 수준의 간접 지정을 제거하려는 경우에 유용합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// 매핑 및 병합 :
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() 반복자를 반환
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// [`flat_map()`] 로 다시 작성할 수도 있습니다.이 경우 의도를 더 명확하게 전달하기 때문에이 경우 더 좋습니다.
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() 반복자를 반환
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// 병합은 한 번에 한 수준의 중첩 만 제거합니다.
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// 여기서 우리는 `flatten()` 가 "deep" 평면화를 수행하지 않음을 알 수 있습니다.
    /// 대신 한 수준의 중첩 만 제거됩니다.즉, 3 차원 배열을 `flatten()` 하면 결과는 1 차원이 아닌 2 차원이됩니다.
    /// 1 차원 구조를 얻으려면 `flatten()` 를 다시해야합니다.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// 첫 번째 [`None`] 이후에 끝나는 반복기를 만듭니다.
    ///
    /// 반복자가 [`None`] 를 반환 한 후 future 호출은 [`Some(T)`] 를 다시 생성하거나 생성하지 않을 수 있습니다.
    /// `fuse()` 반복자를 적용하여 [`None`] 가 제공된 후 항상 [`None`] 를 영원히 반환하도록합니다.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // Some과 None 사이를 번갈아가는 반복자
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // 짝수이면 Some(i32), 그렇지 않으면 없음
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // 반복자가 앞뒤로 이동하는 것을 볼 수 있습니다.
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // 하지만 일단 융합하면 ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // 처음 이후에는 항상 `None` 를 반환합니다.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// 반복기의 각 요소에 대해 값을 전달하는 작업을 수행합니다.
    ///
    /// 반복자를 사용할 때 종종 여러 개를 함께 연결합니다.
    /// 이러한 코드를 작업하는 동안 파이프 라인의 다양한 부분에서 무슨 일이 일어나고 있는지 확인하고 싶을 수 있습니다.이를 수행하려면 `inspect()` 에 대한 호출을 삽입하십시오.
    ///
    /// `inspect()` 가 최종 코드에 존재하는 것보다 디버깅 도구로 사용되는 것이 더 일반적이지만 응용 프로그램은 오류를 버리기 전에 기록해야하는 특정 상황에서 유용하다는 것을 알 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // 이 반복기 시퀀스는 복잡합니다.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // 무슨 일이 일어나고 있는지 조사하기 위해 몇 가지 inspect() 호출을 추가하겠습니다.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// 다음과 같이 인쇄됩니다.
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// 삭제하기 전에 오류 로깅 :
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// 다음과 같이 인쇄됩니다.
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// 반복자를 소비하는 대신 차용합니다.
    ///
    /// 이는 원래 반복자의 소유권을 유지하면서 반복기 어댑터를 적용 할 수 있도록하는 데 유용합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // iter를 다시 사용하려고하면 작동하지 않습니다.
    /// // 다음 줄은 "오류: 이동 된 값 사용 : `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // 다시 해보자
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // 대신 .by_ref() 를 추가합니다.
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // 이제 괜찮습니다.
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// 반복기를 컬렉션으로 변환합니다.
    ///
    /// `collect()` 반복 가능한 모든 것을 가져와 관련 컬렉션으로 바꿀 수 있습니다.
    /// 이것은 다양한 컨텍스트에서 사용되는 표준 라이브러리에서 더 강력한 방법 중 하나입니다.
    ///
    /// `collect()` 가 사용되는 가장 기본적인 패턴은 한 컬렉션을 다른 컬렉션으로 바꾸는 것입니다.
    /// 컬렉션을 가져 와서 [`iter`] 를 호출하고 여러 변형을 수행 한 다음 마지막에 `collect()` 를 수행합니다.
    ///
    /// `collect()` 일반적인 컬렉션이 아닌 유형의 인스턴스를 만들 수도 있습니다.
    /// 예를 들어, [`String`] 는 [`char`]에서 빌드 할 수 있으며 [`Result<T, E>`][`Result`] 항목의 반복자는 `Result<Collection<T>, E>` 로 수집 할 수 있습니다.
    ///
    /// 자세한 내용은 아래 예를 참조하십시오.
    ///
    /// `collect()` 는 매우 일반적이기 때문에 유형 추론에 문제가 발생할 수 있습니다.
    /// 따라서 `collect()` 는 'turbofish' 라는 애칭으로 알려진 구문을 볼 수있는 몇 안되는 경우 중 하나입니다. `::<>`.
    /// 이것은 추론 알고리즘이 수집하려는 컬렉션을 구체적으로 이해하는 데 도움이됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// 왼쪽에 `: Vec<i32>` 가 필요했습니다.예를 들어 [`VecDeque<T>`] 대신 수집 할 수 있기 때문입니다.
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` 주석 대신 'turbofish' 사용 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` 는 수집하는 항목에만 관심이 있으므로 터보 피시와 함께 부분 유형 힌트 `_` 를 사용할 수 있습니다.
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` 를 사용하여 [`String`] 만들기 :
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// [`결과<T, E>`][`Result`] s, `collect()` 를 사용하여 실패 여부를 확인할 수 있습니다.
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // 우리에게 첫 번째 오류를줍니다
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // 우리에게 답변 목록을 제공합니다
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// 반복기를 사용하여 두 개의 컬렉션을 만듭니다.
    ///
    /// `partition()` 에 전달 된 술어는 `true` 또는 `false` 를 리턴 할 수 있습니다.
    /// `partition()` 쌍, `true` 를 반환 한 모든 요소 및 `false` 를 반환 한 모든 요소를 반환합니다.
    ///
    ///
    /// [`is_partitioned()`] 및 [`partition_in_place()`] 를 참조하십시오.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// `true` 를 반환하는 모든 요소가 `false` 를 반환하는 모든 요소보다 우선하도록 지정된 조건 자에 따라이 반복기의 요소를 *in-place* 재정렬합니다.
    ///
    /// 발견 된 `true` 요소의 수를 반환합니다.
    ///
    /// 분할 된 항목의 상대적 순서는 유지되지 않습니다.
    ///
    /// [`is_partitioned()`] 및 [`partition()`] 를 참조하십시오.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // 짝수와 배당률 사이에서 제자리 분할
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: 넘쳐나는 카운트를 걱정해야할까요?더 많은 것을 가질 수있는 유일한 방법
        // `usize::MAX` 가변 참조는 ZST를 사용하므로 분할하는 데 유용하지 않습니다.

        // 이러한 클로저 "factory" 함수는 `Self` 의 일반성을 피하기 위해 존재합니다.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // 반복적으로 첫 번째 `false` 를 찾아 마지막 `true` 로 바꿉니다.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// `true` 를 반환하는 모든 요소가 `false` 를 반환하는 모든 요소보다 우선하도록이 반복기의 요소가 주어진 조건 자에 따라 분할되었는지 확인합니다.
    ///
    ///
    /// [`partition()`] 및 [`partition_in_place()`] 를 참조하십시오.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // 모든 항목이 `true` 를 테스트하거나 첫 번째 절이 `false` 에서 중지되고 그 이후에 더 이상 `true` 항목이 없는지 확인합니다.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// 성공적으로 반환되는 한 함수를 적용하여 단일 최종 값을 생성하는 반복기 메서드입니다.
    ///
    /// `try_fold()` 두 개의 인수, 즉 초기 값과 두 개의 인수 ('accumulator' 및 요소)가있는 클로저를 사용합니다.
    /// 클로저는 누산기가 다음 반복을 위해 가져야하는 값으로 성공적으로 반환되거나 오류 값이 즉시 (short-circuiting) 호출자에게 전파되는 오류를 반환합니다.
    ///
    ///
    /// 초기 값은 누산기가 첫 번째 호출에서 가질 값입니다.반복기의 모든 요소에 대해 클로저 적용이 성공하면 `try_fold()` 는 최종 누산기를 성공으로 반환합니다.
    ///
    /// 접기는 무언가의 컬렉션이 있고 그로부터 단일 값을 생성하고자 할 때 유용합니다.
    ///
    /// # 구현 자 참고 사항
    ///
    /// 다른 (forward) 메소드 중 일부는이 방법과 관련하여 기본 구현을 가지고 있으므로 기본 `for` 루프 구현보다 더 나은 작업을 수행 할 수있는 경우이를 명시 적으로 구현하십시오.
    ///
    /// 특히이 반복기가 구성되는 내부 부분에서이 호출 `try_fold()` 를 사용하십시오.
    /// 여러 번의 호출이 필요한 경우 `?` 연산자는 누산기 값을 연결하는 데 편리 할 수 있지만 이러한 초기 반환 전에 유지해야하는 불변성을주의하십시오.
    /// 이것은 `&mut self` 방법이므로 여기서 오류가 발생한 후 반복을 재개 할 수 있어야합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // 배열의 모든 요소의 체크 된 합계
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 이 합계는 100 요소를 추가 할 때 오버플로됩니다.
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // 단락 되었기 때문에 나머지 요소는 반복기를 통해 계속 사용할 수 있습니다.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// 반복기의 각 항목에 오류가있는 함수를 적용하여 첫 번째 오류에서 중지하고 해당 오류를 반환하는 반복기 메서드입니다.
    ///
    ///
    /// 이것은 [`for_each()`] 의 잘못된 형태 또는 [`try_fold()`] 의 상태 비 저장 버전으로 생각할 수도 있습니다.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // 단락되었으므로 나머지 항목은 여전히 반복기에 있습니다.
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// 연산을 적용하여 모든 요소를 누산기로 접고 최종 결과를 반환합니다.
    ///
    /// `fold()` 두 개의 인수, 즉 초기 값과 두 개의 인수 ('accumulator' 및 요소)가있는 클로저를 사용합니다.
    /// 클로저는 누산기가 다음 반복을 위해 가져야하는 값을 반환합니다.
    ///
    /// 초기 값은 누산기가 첫 번째 호출에서 가질 값입니다.
    ///
    /// 이 클로저를 반복기의 모든 요소에 적용한 후 `fold()` 는 누산기를 반환합니다.
    ///
    /// 이 작업을 'reduce' 또는 'inject' 라고도합니다.
    ///
    /// 접기는 무언가의 컬렉션이 있고 그로부터 단일 값을 생성하고자 할 때 유용합니다.
    ///
    /// Note: `fold()` 및 전체 반복기를 통과하는 유사한 메서드는 결과가 유한 시간 내에 결정 가능한 traits 에서도 무한 반복기에 대해 종료되지 않을 수 있습니다.
    ///
    /// Note: 누산기 유형과 항목 유형이 동일한 경우 [`reduce()`] 를 사용하여 첫 번째 요소를 초기 값으로 사용할 수 있습니다.
    ///
    /// # 구현 자 참고 사항
    ///
    /// 다른 (forward) 메소드 중 일부는이 방법과 관련하여 기본 구현을 가지고 있으므로 기본 `for` 루프 구현보다 더 나은 작업을 수행 할 수있는 경우이를 명시 적으로 구현하십시오.
    ///
    ///
    /// 특히이 반복기가 구성되는 내부 부분에서이 호출 `fold()` 를 사용하십시오.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // 배열의 모든 요소의 합
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// 여기에서 반복의 각 단계를 살펴 보겠습니다.
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// 그래서 최종 결과는 `6`.
    ///
    /// 반복기를 많이 사용하지 않은 사람들은 결과를 생성하기 위해 항목 목록과 함께 `for` 루프를 사용하는 것이 일반적입니다.그것들은 `fold()`s 로 바뀔 수 있습니다 :
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for 루프 :
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // 그들은 똑같다
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// 축소 작업을 반복적으로 적용하여 요소를 단일 요소로 줄입니다.
    ///
    /// 반복기가 비어 있으면 [`None`] 를 반환합니다.그렇지 않으면 감소 결과를 반환합니다.
    ///
    /// 하나 이상의 요소가있는 반복기의 경우 이는 반복기의 첫 번째 요소를 초기 값으로 사용하여 [`fold()`] 와 동일하며 모든 후속 요소를 그 안에 접습니다.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// 최대 값 찾기 :
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// 반복기의 모든 요소가 술어와 일치하는지 테스트합니다.
    ///
    /// `all()` `true` 또는 `false` 를 반환하는 클로저를 사용합니다.이 클로저를 반복기의 각 요소에 적용하고 모두 `true` 를 반환하면 `all()` 도 마찬가지입니다.
    /// 이들 중 하나가 `false` 를 반환하면 `false` 를 반환합니다.
    ///
    /// `all()` 단락 됨;즉, `false` 를 찾는 즉시 처리를 중지합니다. 다른 일이 발생하더라도 결과도 `false` 가됩니다.
    ///
    ///
    /// 빈 반복기는 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// 첫 번째 `false` 에서 중지 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // 더 많은 요소가 있으므로 여전히 `iter` 를 사용할 수 있습니다.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// 반복기의 요소가 술어와 일치하는지 테스트합니다.
    ///
    /// `any()` `true` 또는 `false` 를 반환하는 클로저를 사용합니다.이 클로저를 반복기의 각 요소에 적용하고 이들 중 하나가 `true` 를 반환하면 `any()` 도 마찬가지입니다.
    /// 모두 `false` 를 반환하면 `false` 를 반환합니다.
    ///
    /// `any()` 단락 됨;즉, `true` 를 찾는 즉시 처리를 중지합니다. 다른 일이 발생하더라도 결과도 `true` 가됩니다.
    ///
    ///
    /// 빈 반복기는 `false` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// 첫 번째 `true` 에서 중지 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // 더 많은 요소가 있으므로 여전히 `iter` 를 사용할 수 있습니다.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// 술어를 만족하는 반복기의 요소를 검색합니다.
    ///
    /// `find()` `true` 또는 `false` 를 반환하는 클로저를 사용합니다.
    /// 이 클로저를 반복기의 각 요소에 적용하고 이들 중 하나가 `true` 를 반환하면 `find()` 는 [`Some(element)`] 를 반환합니다.
    /// 모두 `false` 를 반환하면 [`None`] 를 반환합니다.
    ///
    /// `find()` 단락 됨;즉, 클로저가 `true` 를 반환하자마자 처리를 중지합니다.
    ///
    /// `find()` 는 참조를 취하고 많은 반복기가 참조를 반복하기 때문에 인수가 이중 참조 인 경우 혼란 스러울 수있는 상황이 발생합니다.
    ///
    /// 이 효과는 `&&x` 의 아래 예에서 볼 수 있습니다.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// 첫 번째 `true` 에서 중지 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // 더 많은 요소가 있으므로 여전히 `iter` 를 사용할 수 있습니다.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` 는 `iter.filter(f).next()` 와 동일합니다.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// 반복기의 요소에 함수를 적용하고 첫 번째가 아닌 결과를 반환합니다.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` 와 동일합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// 반복기의 요소에 함수를 적용하고 첫 번째 참 결과 또는 첫 번째 오류를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// 반복기에서 요소를 검색하여 색인을 반환합니다.
    ///
    /// `position()` `true` 또는 `false` 를 반환하는 클로저를 사용합니다.
    /// 이 클로저를 반복기의 각 요소에 적용하고 그중 하나가 `true` 를 반환하면 `position()` 는 [`Some(index)`] 를 반환합니다.
    /// 모두 `false` 를 반환하면 [`None`] 를 반환합니다.
    ///
    /// `position()` 단락 됨;즉, `true` 를 찾는 즉시 처리를 중지합니다.
    ///
    /// # 오버플로 동작
    ///
    /// 이 메서드는 오버플로에 대해 보호하지 않으므로 [`usize::MAX`] 일치하지 않는 요소가 더 많은 경우 잘못된 결과 또는 panics 를 생성합니다.
    ///
    /// 디버그 어설 션이 활성화 된 경우 panic 가 보장됩니다.
    ///
    /// # Panics
    ///
    /// 반복기에 `usize::MAX` 개 이상의 일치하지 않는 요소가있는 경우이 함수는 panic 일 수 있습니다.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// 첫 번째 `true` 에서 중지 :
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // 더 많은 요소가 있으므로 여전히 `iter` 를 사용할 수 있습니다.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // 반환 된 인덱스는 반복기 상태에 따라 다릅니다.
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// 오른쪽에서 반복기의 요소를 검색하여 색인을 반환합니다.
    ///
    /// `rposition()` `true` 또는 `false` 를 반환하는 클로저를 사용합니다.
    /// 이 클로저를 끝부터 시작하여 반복기의 각 요소에 적용하고 그중 하나가 `true` 를 반환하면 `rposition()` 는 [`Some(index)`] 를 반환합니다.
    ///
    /// 모두 `false` 를 반환하면 [`None`] 를 반환합니다.
    ///
    /// `rposition()` 단락 됨;즉, `true` 를 찾는 즉시 처리를 중지합니다.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// 첫 번째 `true` 에서 중지 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // 더 많은 요소가 있으므로 여전히 `iter` 를 사용할 수 있습니다.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // `ExactSizeIterator` 는 요소 수가 `usize` 에 맞는다는 것을 의미하므로 여기서 오버플로 검사가 필요하지 않습니다.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// 반복기의 최대 요소를 반환합니다.
    ///
    /// 여러 요소가 똑같이 최대이면 마지막 요소가 반환됩니다.
    /// 반복기가 비어 있으면 [`None`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// 반복기의 최소 요소를 반환합니다.
    ///
    /// 여러 요소가 똑같이 최소 인 경우 첫 번째 요소가 반환됩니다.
    /// 반복기가 비어 있으면 [`None`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// 지정된 함수에서 최대 값을 제공하는 요소를 반환합니다.
    ///
    ///
    /// 여러 요소가 똑같이 최대이면 마지막 요소가 반환됩니다.
    /// 반복기가 비어 있으면 [`None`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// 지정된 비교 함수에 대해 최대 값을 제공하는 요소를 반환합니다.
    ///
    ///
    /// 여러 요소가 똑같이 최대이면 마지막 요소가 반환됩니다.
    /// 반복기가 비어 있으면 [`None`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// 지정된 함수에서 최소값을 제공하는 요소를 반환합니다.
    ///
    ///
    /// 여러 요소가 똑같이 최소 인 경우 첫 번째 요소가 반환됩니다.
    /// 반복기가 비어 있으면 [`None`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// 지정된 비교 함수에 대해 최소값을 제공하는 요소를 반환합니다.
    ///
    ///
    /// 여러 요소가 똑같이 최소 인 경우 첫 번째 요소가 반환됩니다.
    /// 반복기가 비어 있으면 [`None`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// 반복자의 방향을 반전합니다.
    ///
    /// 일반적으로 반복기는 왼쪽에서 오른쪽으로 반복됩니다.
    /// `rev()` 를 사용한 후에는 반복기가 오른쪽에서 왼쪽으로 반복됩니다.
    ///
    /// 이터레이터에 끝이있는 경우에만 가능하므로 `rev()` 는 [`DoubleEndedIterator`]에서만 작동합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// 쌍의 반복자를 컨테이너 쌍으로 변환합니다.
    ///
    /// `unzip()` 쌍의 전체 반복자를 사용하여 두 개의 컬렉션을 생성합니다. 하나는 쌍의 왼쪽 요소에서 하나는 오른쪽 요소에서 하나는 생성합니다.
    ///
    ///
    /// 이 기능은 어떤 의미에서 [`zip`] 의 반대입니다.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// 모든 요소를 복사하는 반복기를 만듭니다.
    ///
    /// 이것은 `&T` 에 대한 반복기가 있지만 `T` 에 대한 반복기가 필요할 때 유용합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // 복사는 .map(|&x| x) 와 동일합니다.
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// 모든 요소를 [`clone`]하는 반복자를 만듭니다.
    ///
    /// 이것은 `&T` 에 대한 반복기가 있지만 `T` 에 대한 반복기가 필요할 때 유용합니다.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned는 정수의 경우 .map(|&x| x) 와 동일합니다.
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// 반복자를 끝없이 반복합니다.
    ///
    /// [`None`] 에서 중지하는 대신 반복기가 처음부터 다시 시작됩니다.다시 반복하면 처음부터 다시 시작됩니다.다시 한번.
    /// 다시 한번.
    /// Forever.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// 반복기의 요소를 더합니다.
    ///
    /// 각 요소를 가져 와서 함께 더한 다음 결과를 반환합니다.
    ///
    /// 빈 반복기는 유형의 0 값을 반환합니다.
    ///
    /// # Panics
    ///
    /// `sum()` 를 호출하고 원시 정수 유형이 반환 될 때 계산이 오버플로되고 디버그 어설 션이 활성화되면이 메서드는 panic 가됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// 전체 반복자를 반복하여 모든 요소를 곱합니다.
    ///
    /// 빈 반복기는 유형의 값 하나를 반환합니다.
    ///
    /// # Panics
    ///
    /// `product()` 를 호출하고 원시 정수 유형이 반환 될 때 계산이 오버플로되고 디버그 어설 션이 활성화되면 메서드는 panic 가됩니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 이 [`Iterator`] 의 요소를 다른 요소와 비교합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 지정된 비교 함수에 대해이 [`Iterator`] 의 요소를 다른 요소와 비교합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 이 [`Iterator`] 의 요소를 다른 요소와 비교합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 지정된 비교 함수에 대해이 [`Iterator`] 의 요소를 다른 요소와 비교합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// 이 [`Iterator`] 의 요소가 다른 요소와 같은지 확인합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// 이 [`Iterator`] 의 요소가 지정된 항등 함수와 관련하여 다른 요소와 같은지 여부를 판별합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// 이 [`Iterator`] 의 요소가 다른 요소와 같지 않은지 확인합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// 이 [`Iterator`] 의 요소가 다른 요소보다 [lexicographically](Ord#lexicographical-comparison) 작은 지 판별합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// 이 [`Iterator`] 의 요소가 다른 요소보다 [lexicographically](Ord#lexicographical-comparison) 작거나 같은지 여부를 판별합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// 이 [`Iterator`] 의 요소가 다른 요소보다 [lexicographically](Ord#lexicographical-comparison) 큰지 확인합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// 이 [`Iterator`] 의 요소가 [lexicographically](Ord#lexicographical-comparison) 가 다른 요소보다 크거나 같은지 확인합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// 이 반복기의 요소가 정렬되었는지 확인합니다.
    ///
    /// 즉, 각 요소 `a` 및 그 다음 요소 `b` 에 대해 `a <= b` 가 유지되어야합니다.반복기가 정확히 0 개 또는 1 개의 요소를 산출하면 `true` 가 반환됩니다.
    ///
    /// `Self::Item` 가 `PartialOrd` 만 있고 `Ord` 가 아닌 경우 위의 정의는 두 개의 연속 항목이 비교할 수없는 경우이 함수가 `false` 를 반환 함을 의미합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// 이 반복기의 요소가 지정된 비교기 함수를 사용하여 정렬되었는지 확인합니다.
    ///
    /// `PartialOrd::partial_cmp` 를 사용하는 대신이 함수는 주어진 `compare` 함수를 사용하여 두 요소의 순서를 결정합니다.
    /// 그 외에도 [`is_sorted`] 와 동일합니다.자세한 내용은 설명서를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// 이 반복기의 요소가 지정된 키 추출 함수를 사용하여 정렬되었는지 확인합니다.
    ///
    /// 반복기의 요소를 직접 비교하는 대신이 함수는 `f` 에 의해 결정된대로 요소의 키를 비교합니다.
    /// 그 외에도 [`is_sorted`] 와 동일합니다.자세한 내용은 설명서를 참조하십시오.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] 참조
    // 비정상적인 이름은 #76479 를 참조하여 메서드 확인에서 이름 충돌을 방지하는 것입니다.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}