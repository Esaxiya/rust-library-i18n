/// [`Iterator`] 에서 변환.
///
/// 유형에 대해 `FromIterator` 를 구현하여 반복기에서 생성되는 방법을 정의합니다.
/// 이것은 일종의 컬렉션을 설명하는 유형에 일반적입니다.
///
/// [`FromIterator::from_iter()`] 명시 적으로 호출되는 경우는 거의 없으며 대신 [`Iterator::collect()`] 메서드를 통해 사용됩니다.
///
/// 더 많은 예제는 [`Iterator::collect()`]'s 문서를 참조하십시오.
///
/// 또한보십시오: [`IntoIterator`].
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] 를 사용하여 암시 적으로 `FromIterator` 사용 :
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// 유형에 맞게 `FromIterator` 구현 :
///
/// ```
/// use std::iter::FromIterator;
///
/// // 샘플 컬렉션, Vec에 대한 래퍼입니다.<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 하나를 만들고 여기에 추가 할 수 있도록 몇 가지 방법을 제공하겠습니다.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // FromIterator를 구현합니다.
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // 이제 새로운 반복자를 만들 수 있습니다.
/// let iter = (0..5).into_iter();
///
/// // ... 그리고 그것으로 MyCollection을 만드십시오
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // 작품도 모 으세요!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// 반복기에서 값을 만듭니다.
    ///
    /// 자세한 내용은 [module-level documentation] 를 참조하십시오.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] 로 변환.
///
/// 형식에 대해 `IntoIterator` 를 구현하여 반복기로 변환되는 방법을 정의합니다.
/// 이것은 일종의 컬렉션을 설명하는 유형에 일반적입니다.
///
/// `IntoIterator` 구현의 한 가지 이점은 유형이 [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) 라는 것입니다.
///
///
/// 또한보십시오: [`FromIterator`].
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// 유형에 맞게 `IntoIterator` 구현 :
///
/// ```
/// // 샘플 컬렉션, Vec에 대한 래퍼입니다.<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 하나를 만들고 여기에 추가 할 수 있도록 몇 가지 방법을 제공하겠습니다.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // IntoIterator를 구현합니다.
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // 이제 새 컬렉션을 만들 수 있습니다 ...
/// let mut c = MyCollection::new();
///
/// // ... 그것에 몇 가지 물건을 추가 ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... 그런 다음 Iterator로 바꿉니다.
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` 를 trait bound 로 사용하는 것이 일반적입니다.이렇게하면 입력 컬렉션 유형이 여전히 반복자 인 한 변경할 수 있습니다.
/// 다음을 제한하여 추가 경계를 지정할 수 있습니다.
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// 반복되는 요소의 유형입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// 우리는 이것을 어떤 종류의 반복자로 바꾸고 있습니까?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// 값에서 반복기를 만듭니다.
    ///
    /// 자세한 내용은 [module-level documentation] 를 참조하십시오.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// 반복기의 내용으로 컬렉션을 확장합니다.
///
/// 반복기는 일련의 값을 생성하며 컬렉션은 일련의 값으로 간주 될 수도 있습니다.
/// `Extend` trait 는이 갭을 메우므로 해당 반복자의 콘텐츠를 포함하여 컬렉션을 확장 할 수 있습니다.
/// 이미 존재하는 키로 컬렉션을 확장하면 해당 항목이 업데이트되거나 동일한 키가있는 여러 항목을 허용하는 컬렉션의 경우 해당 항목이 삽입됩니다.
///
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// // 일부 문자로 문자열을 확장 할 수 있습니다.
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` 구현 :
///
/// ```
/// // 샘플 컬렉션, Vec에 대한 래퍼입니다.<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 하나를 만들고 여기에 추가 할 수 있도록 몇 가지 방법을 제공하겠습니다.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection에는 i32 목록이 있으므로 i32 용 Extend를 구현합니다.
/// impl Extend<i32> for MyCollection {
///
///     // 이것은 구체적인 타입 시그니처를 사용하면 조금 더 간단합니다. i32를 제공하는 Iterator로 변환 될 수있는 모든 것에 extend를 호출 할 수 있습니다.
///     // MyCollection에 넣을 i32가 필요하기 때문입니다.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // 구현은 매우 간단합니다. 반복자를 통해 루프를 수행하고 각 요소를 add() 자신에게 보냅니다.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // 세 개의 숫자를 더 추가하여 컬렉션을 확장하겠습니다.
/// c.extend(vec![1, 2, 3]);
///
/// // 이 요소를 끝에 추가했습니다.
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// 반복기의 내용으로 컬렉션을 확장합니다.
    ///
    /// 이것이이 trait 에 필요한 유일한 방법이므로 [trait-level] 문서에는 자세한 내용이 포함되어 있습니다.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // 일부 문자로 문자열을 확장 할 수 있습니다.
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// 정확히 하나의 요소로 컬렉션을 확장합니다.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// 지정된 수의 추가 요소에 대해 컬렉션의 용량을 예약합니다.
    ///
    /// 기본 구현은 아무것도하지 않습니다.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}