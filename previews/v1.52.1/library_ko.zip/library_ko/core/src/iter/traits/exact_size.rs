/// 정확한 길이를 알고있는 반복기입니다.
///
/// 많은 [`반복자`]는 반복 할 횟수를 모르지만 일부는 반복합니다.
/// 반복자가 반복 할 수있는 횟수를 알고있는 경우 해당 정보에 대한 액세스를 제공하는 것이 유용 할 수 있습니다.
/// 예를 들어, 거꾸로 반복하려면 끝이 어디인지 아는 것이 좋습니다.
///
/// `ExactSizeIterator` 를 구현할 때 [`Iterator`] 도 구현해야합니다.
/// 그렇게 할 때 [`Iterator::size_hint`] 구현은 반복자의 정확한 크기를 *반환해야합니다*.
///
/// [`len`] 메서드에는 기본 구현이 있으므로 일반적으로 구현하면 안됩니다.
/// 그러나 기본값보다 더 성능이 뛰어난 구현을 제공 할 수 있으므로이 경우 재정의하는 것이 좋습니다.
///
///
/// 이 trait 는 안전한 trait 이므로 반환 된 길이가 정확함을 보장하지 *않거나**할 수 없습니다*.
/// 이는 `unsafe` 코드가 [`Iterator::size_hint`] 의 정확성에 의존해서는 **안됩니다**.
/// 불안정하고 안전하지 않은 [`TrustedLen`](super::marker::TrustedLen) trait 는 이러한 추가 보증을 제공합니다.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// // 유한 범위는 반복 할 횟수를 정확히 알고 있습니다.
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] 에서는 [`Iterator`] 를 구현했습니다. `Counter`.
/// `ExactSizeIterator` 도 구현해 보겠습니다.
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // 남은 반복 횟수를 쉽게 계산할 수 있습니다.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // 이제 우리는 그것을 사용할 수 있습니다!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// 반복자의 정확한 길이를 반환합니다.
    ///
    /// 구현은 [`None`] 를 반환하기 전에 반복기가 [`Some(T)`] 값보다 정확히 `len()` 를 더 많이 반환하도록 보장합니다.
    ///
    /// 이 메서드에는 기본 구현이 있으므로 일반적으로 직접 구현하면 안됩니다.
    /// 그러나보다 효율적인 구현을 제공 할 수 있다면 그렇게 할 수 있습니다.
    /// 예제는 [trait-level] 문서를 참조하십시오.
    ///
    /// 이 기능은 [`Iterator::size_hint`] 기능과 동일한 안전성을 보장합니다.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // 유한 범위는 반복 할 횟수를 정확히 알고 있습니다.
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: 이 주장은 지나치게 방어 적이지만 불변성을 확인합니다.
        // trait 에 의해 보장됩니다.
        // 이 trait 가 rust-internal이면 debug_assert!를 사용할 수 있습니다.assert_eq!모든 Rust 사용자 구현도 확인합니다.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// 반복기가 비어 있으면 `true` 를 반환합니다.
    ///
    /// 이 메서드에는 [`ExactSizeIterator::len()`] 를 사용하는 기본 구현이 있으므로 직접 구현할 필요가 없습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}