use crate::{iter::FusedIterator, ops::Try};

/// 끝없이 반복되는 반복기.
///
/// 이 `struct` 는 [`Iterator`] 에서 [`cycle`] 방법으로 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // 순환 반복기가 비어 있거나 무한합니다.
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // 현재 반복자를 완전히 반복합니다.
        // 이것은 `self.orig` 가 아닌 경우에도 `self.iter` 가 비어있을 수 있기 때문에 필요합니다.
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // 순환 반복기가 비어 있는지 여부를 추적하면서 전체 순환을 완료합니다.
        // 무한 루프를 방지하기 위해 빈 반복자의 경우 일찍 반환해야합니다.
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` 오버라이드는 없습니다. `fold` 는 `Cycle` 에 대해 그다지 이해가되지 않고 기본값보다 더 나은 것을 할 수 없기 때문입니다.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}