use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// 이 trait 는 다음 조건에서 인터 레이터 어댑터 파이프 라인의 소스 단계에 대한 전 이적 액세스를 제공합니다.
/// * 반복기 소스 `S` 자체가 `SourceIter<Source = S>` 를 구현합니다.
/// * 소스와 파이프 라인 소비자 사이의 파이프 라인에있는 각 어댑터에 대해이 trait 의 위임 구현이 있습니다.
///
/// 소스가 소유하는 반복기 구조체 (일반적으로 `IntoIter` 라고 함) 인 경우 이는 [`FromIterator`] 구현을 전문화하거나 반복기가 부분적으로 소진 된 후 나머지 요소를 복구하는 데 유용 할 수 있습니다.
///
///
/// 구현시 반드시 파이프 라인의 가장 안쪽 소스에 대한 액세스를 제공 할 필요는 없습니다.상태 저장 중간 어댑터는 파이프 라인의 일부를 열심히 평가하고 내부 저장소를 소스로 노출 할 수 있습니다.
///
/// trait 는 구현자가 추가 안전 속성을 유지해야하기 때문에 안전하지 않습니다.
/// 자세한 내용은 [`as_inner`] 를 참조하십시오.
///
/// # Examples
///
/// 부분적으로 소비 된 소스 검색 :
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// 반복기 파이프 라인의 소스 단계.
    type Source: Iterator;

    /// 반복기 파이프 라인의 소스를 검색합니다.
    ///
    /// # Safety
    ///
    /// 의 구현은 호출자로 대체되지 않는 한 수명 동안 동일한 변경 가능한 참조를 반환해야합니다.
    /// 호출자는 반복을 중지 한 경우에만 참조를 교체하고 소스를 추출한 후 반복기 파이프 라인을 삭제할 수 있습니다.
    ///
    /// 즉, 반복기 어댑터는 반복 중에 변경되지 않는 소스에 의존 할 수 있지만 Drop 구현에서는이를 신뢰할 수 없습니다.
    ///
    /// 이 방법을 구현한다는 것은 어댑터가 소스에 대한 개인 전용 액세스를 포기하고 메소드 수신자 유형을 기반으로 한 보장에만 의존 할 수 있음을 의미합니다.
    /// 제한된 액세스가 없기 때문에 어댑터가 내부에 액세스 할 수있는 경우에도 소스의 공용 API를 유지해야합니다.
    ///
    /// 호출자는 소스와 소스 사이에있는 어댑터가 동일한 액세스 권한을 갖기 때문에 소스가 공개 API와 일치하는 모든 상태에있을 것으로 예상해야합니다.
    /// 특히 어댑터는 꼭 필요한 것보다 더 많은 요소를 소비했을 수 있습니다.
    ///
    /// 이러한 요구 사항의 전반적인 목표는 파이프 라인 소비자가
    /// * 반복이 중지 된 후 소스에 남아있는 항목
    /// * 소비하는 반복자를 진행하여 사용하지 않게 된 메모리
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// 기본 반복기가 `Result::Ok` 값을 생성하는 한 출력을 생성하는 반복기 어댑터입니다.
///
///
/// 오류가 발생하면 반복기가 중지되고 오류가 저장됩니다.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// 주어진 반복기를 `Result<T, _>` 대신 `T` 를 산출 한 것처럼 처리합니다.
/// 모든 오류는 내부 반복기를 중지하고 전체 결과는 오류가됩니다.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}