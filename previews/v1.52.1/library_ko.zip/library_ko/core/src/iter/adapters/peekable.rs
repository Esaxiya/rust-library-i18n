use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// 다음 요소에 대한 선택적 참조를 반환하는 `peek()` 가있는 반복기입니다.
///
///
/// 이 `struct` 는 [`Iterator`] 에서 [`peekable`] 방법으로 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// 없음 인 경우에도 미리보기 값을 기억하십시오.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable은 `.peek()` 메서드에서 None이 나타 났는지 기억해야합니다.
// `.peek();.peek();` 또는 `.peek();.next();` 는 기본 반복자를 최대 한 번만 진행합니다.
// 이것은 그 자체로 반복자를 융합하지 않습니다.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// 반복기를 진행하지 않고 next() 값에 대한 참조를 반환합니다.
    ///
    /// [`next`] 와 마찬가지로 값이 있으면 `Some(T)` 로 래핑됩니다.
    /// 그러나 반복이 끝나면 `None` 가 반환됩니다.
    ///
    /// [`next`]: Iterator::next
    ///
    /// `peek()` 는 참조를 반환하고 많은 반복기가 참조를 반복하므로 반환 값이 이중 참조 인 경우 혼동 될 수 있습니다.
    /// 아래 예제에서이 효과를 볼 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future 를 볼 수 있습니다.
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // 반복자는 여러 번 `peek` 해도 진행되지 않습니다.
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // 반복자가 완료된 후 `peek()` 도 완료됩니다.
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// 반복기를 진행하지 않고 next() 값에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// [`next`] 와 마찬가지로 값이 있으면 `Some(T)` 로 래핑됩니다.
    /// 그러나 반복이 끝나면 `None` 가 반환됩니다.
    ///
    /// `peek_mut()` 는 참조를 반환하고 많은 반복기가 참조를 반복하므로 반환 값이 이중 참조 인 경우 혼동 될 수 있습니다.
    /// 아래 예제에서이 효과를 볼 수 있습니다.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` 와 마찬가지로 반복기를 진행하지 않고도 future 를 볼 수 있습니다.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // 반복자를 들여다보고 가변 참조 뒤에 값을 설정합니다.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // 우리가 입력 한 값은 반복기가 계속됨에 따라 다시 나타납니다.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// 조건이 참이면이 반복자의 다음 값을 소비하고 반환합니다.
    /// `func` 가이 반복기의 다음 값에 대해 `true` 를 반환하면 소비하고 반환합니다.
    /// 그렇지 않으면 `None` 를 반환합니다.
    /// # Examples
    /// 0과 같으면 숫자를 사용합니다.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // 이터레이터의 첫 번째 항목은 0입니다.그것을 소비하십시오.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // 반환 된 다음 항목은 이제 1이므로 `consume` 는 `false` 를 반환합니다.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` `expected` 와 같지 않은 경우 다음 항목의 값을 저장합니다.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10보다 작은 숫자를 소비하십시오.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // 10 미만의 모든 숫자를 사용
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // 반환되는 다음 값은 10입니다.
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // `self.next()` 를 호출했기 때문에 `self.peeked` 를 소비했습니다.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// `expected` 와 같으면 다음 항목을 소비하고 반환합니다.
    /// # Example
    /// 0과 같으면 숫자를 사용합니다.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // 이터레이터의 첫 번째 항목은 0입니다.그것을 소비하십시오.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // 반환 된 다음 항목은 이제 1이므로 `consume` 는 `false` 를 반환합니다.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` `expected` 와 같지 않은 경우 다음 항목의 값을 저장합니다.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // 안전: 동일한 요구 사항을 가진 안전하지 않은 기능으로 안전하지 않은 기능 전달
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}