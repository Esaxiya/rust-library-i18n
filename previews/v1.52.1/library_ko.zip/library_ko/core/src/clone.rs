//! '암시 적으로 복사'할 수없는 유형에 대한 `Clone` trait 입니다.
//!
//! Rust 에서 일부 간단한 유형은 "implicitly copyable" 이며이를 할당하거나 인수로 전달할 때 수신자는 원래 값을 그대로두고 복사본을 얻습니다.
//! 이러한 유형은 복사 할 할당이 필요하지 않으며 종료자가 없으므로 (즉, 소유 된 상자를 포함하지 않거나 [`Drop`] 를 구현하지 않음) 컴파일러는 복사하기에 저렴하고 안전한 것으로 간주합니다.
//!
//! 다른 유형의 경우 [`Clone`] trait 를 구현하고 [`clone`] 메서드를 호출하는 규칙에 따라 명시 적으로 복사해야합니다.
//!
//! [`clone`]: Clone::clone
//!
//! 기본 사용 예 :
//!
//! ```
//! let s = String::new(); // 문자열 유형은 복제를 구현합니다.
//! let copy = s.clone(); // 복제 할 수 있도록
//! ```
//!
//! Clone trait 를 쉽게 구현하려면 `#[derive(Clone)]` 를 사용할 수도 있습니다.예:
//!
//! ```
//! #[derive(Clone)] // Morpheus 구조체에 Clone trait 를 추가합니다.
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // 이제 복제 할 수 있습니다!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// 객체를 명시 적으로 복제하는 기능을위한 공통 trait 입니다.
///
/// [`Copy`] 는 암시 적이며 매우 저렴하지만 `Clone` 는 항상 명시 적이며 비싸거나 비싸지 않을 수 있다는 점에서 [`Copy`] 와 다릅니다.
/// 이러한 특성을 적용하기 위해 Rust 에서는 [`Copy`] 를 다시 구현할 수 없지만 `Clone` 를 다시 구현하고 임의 코드를 실행할 수 있습니다.
///
/// `Clone` 는 [`Copy`] 보다 일반적이므로 [`Copy`] 를 `Clone` 로 자동으로 만들 수 있습니다.
///
/// ## Derivable
///
/// 이 trait 는 모든 필드가 `Clone` 인 경우 `#[derive]` 와 함께 사용할 수 있습니다.[`Clone`] 의 '파생'구현은 각 필드에서 [`clone`] 를 호출합니다.
///
/// [`clone`]: Clone::clone
///
/// 일반 구조체의 경우 `#[derive]` 는 일반 매개 변수에 바인딩 된 `Clone` 를 추가하여 `Clone` 를 조건부로 구현합니다.
///
/// ```
/// // `derive` 읽기 용 복제 구현<T>T가 클론 일 때.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` 를 어떻게 구현할 수 있습니까?
///
/// [`Copy`] 유형은 `Clone` 의 간단한 구현을 가져야합니다.보다 공식적으로 :
/// `T: Copy`, `x: T` 및 `y: &T` 인 경우 `let x = y.clone();` 는 `let x = *y;` 와 동일합니다.
/// 수동 구현은이 불변성을 유지하도록주의해야합니다.그러나 안전하지 않은 코드는 메모리 안전을 보장하기 위해이 코드에 의존해서는 안됩니다.
///
/// 예를 들어 함수 포인터를 보유하는 일반 구조체가 있습니다.이 경우 `Clone` 의 구현은 '파생'될 수 없지만 다음과 같이 구현 될 수 있습니다.
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## 추가 구현 자
///
/// [implementors listed below][impls] 외에 다음 유형도 `Clone` 를 구현합니다.
///
/// * 기능 항목 유형 (즉, 각 기능에 대해 정의 된 구별 유형)
/// * 함수 포인터 유형 (예 : `fn() -> i32`)
/// * 항목 유형이 `Clone` (예: `[i32; 123456]`)도 구현하는 경우 모든 크기에 대한 배열 유형
/// * 각 구성 요소가 `Clone` (예: `()`, `(i32, bool)`)를 구현하는 경우 튜플 유형
/// * 클로저 유형 (환경에서 값을 캡처하지 않거나 캡처 된 모든 값이 `Clone` 자체를 구현하는 경우)
///   공유 참조로 캡처 된 변수는 항상 `Clone` 를 구현하지만 (참조 항목이 그렇지 않더라도) 가변 참조로 캡처 된 변수는 `Clone` 를 구현하지 않습니다.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// 값의 복사본을 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Clone 구현
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` 에서 복사 할당을 수행합니다.
    ///
    /// `a.clone_from(&b)` 기능상 `a = b.clone()` 와 동일하지만 불필요한 할당을 피하기 위해 `a` 의 리소스를 재사용하도록 재정의 할 수 있습니다.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` 의 impl을 생성하는 매크로를 유도합니다.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): 이러한 구조체는 유형의 모든 구성 요소가 Clone 또는 Copy를 구현한다고 주장하기 위해#[derive]에 의해서만 사용됩니다.
//
//
// 이러한 구조체는 사용자 코드에 나타나지 않아야합니다.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// 기본 유형에 대한 `Clone` 구현.
///
/// Rust 에서 설명 할 수없는 구현은 `rustc_trait_selection` 의 `traits::SelectionContext::copy_clone_conditions()` 에서 구현됩니다.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// 공유 참조는 복제 할 수 있지만 변경 가능한 참조는 *할 수 없습니다*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// 공유 참조는 복제 할 수 있지만 변경 가능한 참조는 *할 수 없습니다*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}