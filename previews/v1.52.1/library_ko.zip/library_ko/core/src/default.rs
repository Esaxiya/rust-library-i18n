//! 의미있는 기본값을 가질 수있는 유형에 대한 `Default` trait 입니다.

#![stable(feature = "rust1", since = "1.0.0")]

/// 유형에 유용한 기본값을 제공하기위한 trait.
///
/// 때로는 어떤 종류의 기본값으로 돌아가고 싶고 그것이 무엇인지 특별히 신경 쓰지 않습니다.
/// 이것은 종종 옵션 세트를 정의하는`struct`와 함께 나타납니다.
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// 몇 가지 기본값을 어떻게 정의 할 수 있습니까?`Default` 를 사용할 수 있습니다.
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// 이제 모든 기본값을 얻습니다.Rust 는 다양한 기본 유형에 대해 `Default` 를 구현합니다.
///
/// 특정 옵션을 재정의하되 다른 기본값은 그대로 유지하려는 경우 :
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// 이 trait 는 유형의 모든 필드가 `Default` 를 구현하는 경우 `#[derive]` 와 함께 사용할 수 있습니다.
/// '파생'되면 각 필드의 유형에 대한 기본값을 사용합니다.
///
/// ## `Default` 를 어떻게 구현할 수 있습니까?
///
/// 기본값이어야하는 유형의 값을 리턴하는 `default()` 메소드에 대한 구현을 제공하십시오.
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// 유형에 대한 "default value" 를 반환합니다.
    ///
    /// 기본값은 종종 일종의 초기 값, ID 값 또는 기본값으로 이해할 수있는 다른 모든 것입니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 제공 기본값 사용 :
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// 나만의 만들기 :
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait 에 따라 유형의 기본값을 반환합니다.
///
/// 반환 할 유형은 컨텍스트에서 유추됩니다.이것은 `Default::default()` 와 동일하지만 형식이 짧습니다.
///
/// 예를 들면 :
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` 의 impl을 생성하는 매크로를 유도합니다.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }