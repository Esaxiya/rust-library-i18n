#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! 외부 기능 인터페이스 (FFI) 바인딩과 관련된 유틸리티입니다.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] 로 사용될 때 C의 `void` 유형과 동일합니다.
///
/// 본질적으로 `*const c_void` 는 C의 `const void*` 와 동일하고 `*mut c_void` 는 C의 `void*` 와 동일합니다.
/// 즉, 이것은 Rust 의 `()` 유형 인 C의 `void` 반환 유형과 동일하지 *않습니다*.
///
/// FFI에서 불투명 유형에 대한 포인터를 모델링하려면 `extern type` 가 안정화 될 때까지 빈 바이트 배열 주위에 newtype 래퍼를 사용하는 것이 좋습니다.
///
/// 자세한 내용은 [Nomicon] 를 참조하십시오.
///
/// 이전 Rust 컴파일러를 1.1.0 까지 지원하려는 경우 `std::os::raw::c_void` 를 사용할 수 있습니다.
/// Rust 1.30.0 이후이 정의에 의해 다시 내보내졌습니다.
/// 자세한 내용은 [RFC 2521] 를 참조하십시오.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// 참고로 LLVM이 void 포인터 유형을 인식하고 malloc() 와 같은 확장 기능을 사용하려면 LLVM 비트 코드에서 i8 *로 표시해야합니다.
// 여기에 사용 된 열거 형은이를 보장하고 전용 변형 만 가짐으로써 "raw" 유형의 오용을 방지합니다.
// 컴파일러가 repr 속성에 대해 불평하기 때문에 우리는 두 가지 변형이 필요합니다. 그렇지 않으면 열거 형이 무인 상태이고 적어도 그러한 포인터를 역 참조하는 것은 UB가되기 때문에 적어도 하나의 변형이 필요합니다.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` 의 기본 구현.
// 이름은 WIP이며 현재 `VaListImpl` 를 사용합니다.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` 에 대해 불변이므로 각 `VaListImpl<'f>` 개체는 정의 된 함수 영역에 연결됩니다.
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` 의 ABI 구현.
/// 자세한 내용은 [AArch64 Procedure Call Standard] 를 참조하십시오.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` 의 ABI 구현.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` 의 ABI 구현.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` 용 래퍼
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` 를 C의 `va_list` 와 바이너리 호환되는 `VaList` 로 변환합니다.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` 를 C의 `va_list` 와 바이너리 호환되는 `VaList` 로 변환합니다.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait 는 공용 인터페이스에서 사용해야하지만 trait 자체는이 모듈 외부에서 사용할 수 없습니다.
// 사용자가 새 유형에 대해 trait 를 구현하도록 허용하면 (이에 따라 va_arg 내장 함수를 새 유형에 사용할 수 있음) 정의되지 않은 동작이 발생할 수 있습니다.
//
// FIXME(dlrobertson): VaArgSafe trait 를 공용 인터페이스에서 사용하지만 다른 곳에서 사용할 수 없도록하려면 trait 가 개인 모듈 내에서 공용이어야합니다.
// RFC 2145가 구현되면이를 개선 할 수 있습니다.
//
//
//
//
mod sealed_trait {
    /// 허용 된 유형을 [super::VaListImpl::arg] 와 함께 사용할 수 있도록 허용하는 Trait.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// 다음 인수로 진행합니다.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // 안전: 발신자는 `va_arg` 에 대한 안전 계약을 유지해야합니다.
        unsafe { va_arg(self) }
    }

    /// 현재 위치에 `va_list` 를 복사합니다.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // 안전: 발신자는 `va_end` 에 대한 안전 계약을 유지해야합니다.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // 안전: 우리는 `MaybeUninit` 에 쓰기 때문에 초기화되고 `assume_init` 는 합법적입니다.
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: `va_end` 를 호출해야하지만 깨끗한 방법은 없습니다.
        // `drop` 는 항상 호출자에게 인라인되므로 `va_end` 는 해당 `va_copy` 와 동일한 함수에서 직접 호출됩니다.
        // `man va_end` C는 이것을 요구하고 LLVM은 기본적으로 C 의미를 따르므로 `va_end` 가 항상 `va_copy` 와 동일한 함수에서 호출되는지 확인해야합니다.
        //
        // 자세한 사항은, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // `va_end` 는 현재 모든 LLVM 대상에서 작동하지 않기 때문에 현재 작동합니다.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` 또는 `va_copy` 로 초기화 한 후 arglist `ap` 를 삭제하십시오.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// arglist `src` 의 현재 위치를 arglist `dst` 에 복사합니다.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` 에서 `T` 유형의 인수를로드하고 `ap` 가 가리키는 인수를 증가시킵니다.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}