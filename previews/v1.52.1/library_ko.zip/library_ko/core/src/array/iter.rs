//! 배열에 대한 `IntoIter` 소유 반복기를 정의합니다.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// 값별 [array] 반복자입니다.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// 이것이 우리가 반복하는 배열입니다.
    ///
    /// `alive.start <= i < alive.end` 가 아직 생성되지 않았고 유효한 배열 항목 인 인덱스 `i` 가있는 요소입니다.
    /// 인덱스가 `i < alive.start` 또는 `i >= alive.end` 인 요소는 이미 산출되었으며 더 이상 액세스 할 수 없습니다!이러한 죽은 요소는 완전히 초기화되지 않은 상태 일 수도 있습니다!
    ///
    ///
    /// 따라서 불변성은 다음과 같습니다.
    /// - `data[alive]` 살아 있음 (즉, 유효한 요소 포함)
    /// - `data[..alive.start]` 및 `data[alive.end..]` 가 죽었습니다 (즉, 요소가 이미 읽혀졌으므로 더 이상 건 드리면 안됩니다!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// 아직 산출되지 않은 `data` 의 요소.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// 지정된 `array` 에 대해 새 반복기를 만듭니다.
    ///
    /// *참고*:이 메서드는 [`IntoIterator` is implemented for arrays][array-into-iter] 이후 future 에서 더 이상 사용되지 않을 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // 여기서 `value` 의 유형은 `&i32` 대신 `i32` 입니다.
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // 안전: 여기서 변환은 실제로 안전합니다.`MaybeUninit` 의 문서
        // promise:
        //
        // > `MaybeUninit<T>` 동일한 크기와 정렬이 보장됩니다.
        // > `T` 로.
        //
        // 문서는 `MaybeUninit<T>` 배열에서 `T` 배열로의 변환을 보여줍니다.
        //
        //
        // 이를 통해이 초기화는 불변성을 충족합니다.

        // FIXME(LukasKalbertodt): 실제로 여기에서 `mem::transmute` 를 사용하면 const 제네릭과 함께 작동합니다.
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // 그때까지는 `mem::transmute_copy` 를 사용하여 비트 별 복사본을 다른 유형으로 만든 다음 `array` 를 잊어 버리지 않도록 할 수 있습니다.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// 아직 생성되지 않은 모든 요소의 불변 조각을 반환합니다.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // 안전: 우리는 `alive` 내의 모든 요소가 제대로 초기화되었음을 알고 있습니다.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// 아직 생성되지 않은 모든 요소의 가변 슬라이스를 반환합니다.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // 안전: 우리는 `alive` 내의 모든 요소가 제대로 초기화되었음을 알고 있습니다.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // 앞에서 다음 색인을 가져옵니다.
        //
        // `alive.start` 를 1 씩 늘리면 `alive` 에 대한 불변이 유지됩니다.
        // 그러나 이러한 변경으로 인해 잠시 동안 살아있는 존은 더 이상 `data[alive]` 가 아니라 `data[idx..alive.end]` 가됩니다.
        //
        self.alive.next().map(|idx| {
            // 배열에서 요소를 읽습니다.
            // 안전: `idx` 는 이전 "alive" 영역에 대한 색인입니다.
            // 정렬.이 요소를 읽는 것은 `data[idx]` 가 현재 죽은 것으로 간주된다는 것을 의미합니다 (즉, 만지지 마십시오).
            // `idx` 가 활성 영역의 시작 이었으므로 이제 활성 영역은 이제 다시 `data[alive]` 가되어 모든 불변을 복원합니다.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // 뒤에서 다음 색인을 가져옵니다.
        //
        // `alive.end` 를 1 씩 줄이면 `alive` 에 대한 불변이 유지됩니다.
        // 그러나 이러한 변경으로 인해 잠시 동안 살아있는 존은 더 이상 `data[alive]` 가 아니라 `data[alive.start..=idx]` 가됩니다.
        //
        self.alive.next_back().map(|idx| {
            // 배열에서 요소를 읽습니다.
            // 안전: `idx` 는 이전 "alive" 영역에 대한 색인입니다.
            // 정렬.이 요소를 읽는 것은 `data[idx]` 가 현재 죽은 것으로 간주된다는 것을 의미합니다 (즉, 만지지 마십시오).
            // `idx` 가 활성 영역의 끝 이었으므로 이제 활성 영역은 이제 다시 `data[alive]` 가되어 모든 불변을 복원합니다.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // 안전: 이것은 안전합니다: `as_mut_slice` 는 정확히 하위 슬라이스를 반환합니다.
        // 아직 이동하지 않았고 삭제해야하는 요소의 수입니다.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // 변하지 않는`alive.start <=로 인해 절대 언더 플로되지 않습니다.
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// 반복기는 실제로 올바른 길이를보고합니다.
// (여전히 산출 될) "alive" 요소의 수는 범위 `alive` 의 길이입니다.
// 이 범위는 `next` 또는 `next_back` 에서 길이가 감소합니다.
// 이러한 메서드에서는 항상 1 씩 감소하지만 `Some(_)` 가 반환되는 경우에만 해당됩니다.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // 실제로 똑같은 살아있는 범위를 일치시킬 필요는 없으므로 `self` 의 위치에 관계없이 오프셋 0으로 복제 할 수 있습니다.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // 모든 살아있는 요소를 복제합니다.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // 새 어레이에 클론을 작성한 다음 활성 범위를 업데이트합니다.
            // panics 를 복제하는 경우 이전 항목을 올바르게 삭제합니다.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // 아직 산출되지 않은 요소 만 인쇄합니다. 산출 된 요소에 더 이상 액세스 할 수 없습니다.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}