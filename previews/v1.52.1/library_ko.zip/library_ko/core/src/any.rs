//! 이 모듈은 런타임 리플렉션을 통해 모든 `'static` 유형의 동적 타이핑을 가능하게하는 `Any` trait 를 구현합니다.
//!
//! `Any` 자체는 `TypeId` 를 얻는 데 사용할 수 있으며 trait 객체로 사용할 때 더 많은 기능을 제공합니다.
//! `&dyn Any` (차용 된 trait 객체)로서 포함 된 값이 주어진 유형인지 테스트하고 내부 값에 대한 참조를 유형으로 가져 오는 `is` 및 `downcast_ref` 메서드가 있습니다.
//! `&mut dyn Any` 에는 내부 값에 대한 변경 가능한 참조를 가져 오는 `downcast_mut` 메서드도 있습니다.
//! `Box<dyn Any>` `Box<T>` 로 변환을 시도하는 `downcast` 메소드를 추가합니다.
//! 자세한 내용은 [`Box`] 설명서를 참조하십시오.
//!
//! `&dyn Any` 는 값이 지정된 구체적인 유형인지 여부를 테스트하는 것으로 제한되며 유형이 trait 를 구현하는지 여부를 테스트하는 데 사용할 수 없습니다.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # 스마트 포인터 및 `dyn Any`
//!
//! 특히 `Box<dyn Any>` 또는 `Arc<dyn Any>` 와 같은 유형에서 `Any` 를 trait 개체로 사용할 때 염두에 두어야 할 동작 중 하나는 값에 대해 `.type_id()` 를 호출하면 기본 trait 개체가 아닌 *container* 의 `TypeId` 가 생성된다는 것입니다.
//!
//! 대신 스마트 포인터를 `&dyn Any` 로 변환하면 개체의 `TypeId` 가 반환됩니다.
//! 예를 들면 :
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // 이것을 원할 가능성이 더 높습니다.
//! let actual_id = (&*boxed).type_id();
//! // ... 이것보다:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! 함수에 전달 된 값을 로그 아웃하려는 상황을 고려하십시오.
//! 우리가 작업중인 값은 Debug를 구현하지만 구체적인 유형은 모릅니다.우리는 특정 유형에 특별한 처리를하고 싶습니다.이 경우에는 해당 값 이전에 문자열 값의 길이를 인쇄합니다.
//! 컴파일 타임에 값의 구체적인 유형을 알지 못하므로 대신 런타임 리플렉션을 사용해야합니다.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Debug를 구현하는 모든 유형에 대한 로거 함수.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // 우리의 가치를 `String` 로 변환 해보십시오.
//!     // 성공하면 문자열의 길이와 값을 출력하려고합니다.
//!     // 그렇지 않은 경우 다른 유형입니다. 장식하지 않고 인쇄하십시오.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // 이 함수는 작업을 수행하기 전에 해당 매개 변수를 로그 아웃하려고합니다.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... 다른 일을
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// 모든 trait
///////////////////////////////////////////////////////////////////////////////

/// 동적 타이핑을 에뮬레이트하기위한 trait.
///
/// 대부분의 유형은 `Any` 를 구현합니다.그러나 '정적'이 아닌 참조를 포함하는 모든 유형은 그렇지 않습니다.
/// 자세한 내용은 [module-level documentation][mod] 를 참조하십시오.
///
/// [mod]: crate::any
// 이 trait 는 안전하지 않은 코드 (예: `downcast`)에서 유일한 impl의 `type_id` 함수에 의존하지만 안전하지 않습니다.일반적으로 그것은 문제가 될 수 있지만 `Any` 의 유일한 impl은 블랭킷 구현이기 때문에 다른 코드는 `Any` 를 구현할 수 없습니다.
//
// 우리는이 trait 를 안전하지 않게 만들 수 있습니다. 모든 구현을 제어하기 때문에 파손을 일으키지는 않습니다. `type_id` 는 여전히 호출해도 안전하지만 문서에서이를 표시하고 싶을 것입니다.)
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` 의 `TypeId` 를 가져옵니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// 모든 trait 개체에 대한 확장 메서드.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// 예를 들어 스레드 결합의 결과를 인쇄하여 `unwrap` 와 함께 사용할 수 있는지 확인하십시오.
// 디스패치가 업 캐스팅과 함께 작동하는 경우 결국 더 이상 필요하지 않을 수 있습니다.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// 박스형이 `T` 와 같으면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // 이 함수가 인스턴스화되는 유형의 `TypeId` 를 가져옵니다.
        let t = TypeId::of::<T>();

        // trait 개체 (`self`) 에서 유형의 `TypeId` 를 가져옵니다.
        let concrete = self.type_id();

        // 두`TypeId`가 같은지 비교하십시오.
        t == concrete
    }

    /// `T` 유형이면 boxed 값에 대한 참조를 반환하고 그렇지 않으면 `None` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // 안전: 올바른 유형을 가리키고 있는지 확인했으며
            // 모든 유형에 대해 Any를 구현했기 때문에 메모리 안전성을 확인합니다.우리의 impl과 충돌하기 때문에 다른 impl은 존재할 수 없습니다.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// `T` 유형 인 경우 boxed 값에 대한 변경 가능한 참조를 반환하고 그렇지 않은 경우 `None` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // 안전: 올바른 유형을 가리키고 있는지 확인했으며
            // 모든 유형에 대해 Any를 구현했기 때문에 메모리 안전성을 확인합니다.우리의 impl과 충돌하기 때문에 다른 impl은 존재할 수 없습니다.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` 유형에 정의 된 메소드로 전달합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` 유형에 정의 된 메소드로 전달합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` 유형에 정의 된 메소드로 전달합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` 유형에 정의 된 메소드로 전달합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` 유형에 정의 된 메소드로 전달합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` 유형에 정의 된 메소드로 전달합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID 및 방법
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` 는 유형에 대한 전역 적으로 고유 한 식별자를 나타냅니다.
///
/// 각 `TypeId` 는 내부 내용을 검사 할 수 없지만 복제, 비교, 인쇄 및 표시와 같은 기본 작업을 허용하는 불투명 한 개체입니다.
///
///
/// `TypeId` 는 현재 `'static` 에 속하는 유형에만 사용할 수 있지만이 제한은 future 에서 제거 될 수 있습니다.
///
/// `TypeId` 는 `Hash`, `PartialOrd` 및 `Ord` 를 구현하지만 해시 및 순서는 Rust 릴리스마다 다를 수 있습니다.
/// 코드 내에서 이들에 의존하지 않도록주의하십시오!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// 이 제네릭 함수를 인스턴스화 한 형식의 `TypeId` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// 유형의 이름을 문자열 조각으로 반환합니다.
///
/// # Note
///
/// 이것은 진단용입니다.
/// 반환 된 문자열의 정확한 내용과 형식은 형식에 대한 최선의 설명 외에는 지정되지 않습니다.
/// 예를 들어 `type_name::<Option<String>>()` 가 반환 할 수있는 문자열 중에는 `"Option<String>"` 와 `"std::option::Option<std::string::String>"` 가 있습니다.
///
///
/// 반환 된 문자열은 여러 유형이 동일한 유형 이름에 매핑 될 수 있으므로 유형의 고유 식별자로 간주되어서는 안됩니다.
/// 마찬가지로 형식의 모든 부분이 반환 된 문자열에 표시된다는 보장은 없습니다. 예를 들어 수명 지정자는 현재 포함되어 있지 않습니다.
/// 또한 출력은 컴파일러 버전간에 변경 될 수 있습니다.
///
/// 현재 구현은 컴파일러 진단 및 debuginfo와 동일한 인프라를 사용하지만 이것이 보장되지는 않습니다.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// 가리키는 값 유형의 이름을 문자열 조각으로 반환합니다.
/// `type_name::<T>()` 와 동일하지만 변수 유형을 쉽게 사용할 수없는 경우 사용할 수 있습니다.
///
/// # Note
///
/// 이것은 진단용입니다.문자열의 정확한 내용과 형식은 형식에 대한 최선의 설명 외에는 지정되지 않습니다.
/// 예를 들어 `type_name_of_val::<Option<String>>(None)` 는 `"Option<String>"` 또는 `"std::option::Option<std::string::String>"` 를 반환 할 수 있지만 `"foobar"` 는 반환하지 않습니다.
///
/// 또한 출력은 컴파일러 버전간에 변경 될 수 있습니다.
///
/// 이 함수는 trait 개체를 확인하지 않습니다. 즉, `type_name_of_val(&7u32 as &dyn Debug)` 는 `"dyn Debug"` 를 반환 할 수 있지만 `"u32"` 는 반환하지 않을 수 있습니다.
///
/// 유형 이름은 유형의 고유 식별자로 간주되어서는 안됩니다.
/// 여러 유형이 동일한 유형 이름을 공유 할 수 있습니다.
///
/// 현재 구현은 컴파일러 진단 및 debuginfo와 동일한 인프라를 사용하지만 이것이 보장되지는 않습니다.
///
/// # Examples
///
/// 기본 정수 및 부동 유형을 인쇄합니다.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}