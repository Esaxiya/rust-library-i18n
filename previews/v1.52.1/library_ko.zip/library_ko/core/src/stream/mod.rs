//! 구성 가능한 비동기 반복.
//!
//! futures 가 비동기 값이면 스트림은 비동기 반복기입니다.
//! 어떤 종류의 비동기 컬렉션이 있고 해당 컬렉션의 요소에 대한 작업을 수행해야하는 경우 'streams' 를 빠르게 실행할 수 있습니다.
//! 스트림은 관용적 비동기 Rust 코드에서 많이 사용되므로 익숙해 질 가치가 있습니다.
//!
//! 자세히 설명하기 전에이 모듈의 구조에 대해 이야기 해 보겠습니다.
//!
//! # Organization
//!
//! 이 모듈은 주로 유형별로 구성됩니다.
//!
//! * [Traits] 핵심 부분입니다. 이러한 traits 는 어떤 종류의 스트림이 존재하는지, 스트림으로 무엇을 할 수 있는지 정의합니다.이 traits 의 방법은 추가 학습 시간을 투자 할 가치가 있습니다.
//! * 함수는 몇 가지 기본 스트림을 만드는 데 유용한 방법을 제공합니다.
//! * 구조체는 종종이 모듈의 traits 에있는 다양한 메서드의 반환 유형입니다.일반적으로 `struct` 자체보다는 `struct` 를 생성하는 방법을보고 싶을 것입니다.
//! 이유에 대한 자세한 내용은 '[Implementing Stream](#implementing-stream)'을 참조하세요.
//!
//! [Traits]: #traits
//!
//! 그게 다야!개울을 파헤쳐 보자.
//!
//! # Stream
//!
//! 이 모듈의 핵심은 [`Stream`] trait 입니다.[`Stream`] 의 핵심은 다음과 같습니다.
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! `Iterator` 와 달리 `Stream` 는 `Stream` 구현시 사용하는 [`poll_next`] 방식과 스트림 소비시 사용하는 (to-be-implemented) `next` 방식을 구분합니다.
//!
//! `Stream` 의 소비자는 호출시 `Option<Stream::Item>` 를 산출하는 future 를 반환하는 `next` 만 고려하면됩니다.
//!
//! `next` 에 의해 반환 된 future 는 요소가있는 한 `Some(Item)` 를 산출하고, 요소가 모두 소진되면 `None` 를 산출하여 반복이 완료되었음을 나타냅니다.
//! 해결하기 위해 비동기식을 기다리고 있다면 future 는 스트림이 다시 양보 할 준비가 될 때까지 기다릴 것입니다.
//!
//! 개별 스트림은 반복을 재개하도록 선택할 수 있으므로 `next` 를 다시 호출하면 특정 시점에서 결국 `Some(Item)` 가 다시 생성 될 수도 있고 그렇지 않을 수도 있습니다.
//!
//! [`Stream`]의 전체 정의에는 다른 여러 메서드도 포함되어 있지만 [`poll_next`] 위에 빌드 된 기본 메서드이므로 무료로 얻을 수 있습니다.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # 스트림 구현
//!
//! 자신 만의 스트림을 생성하려면 스트림의 상태를 유지하기 위해 `struct` 를 생성 한 다음 해당 `struct` 에 대해 [`Stream`] 를 구현하는 두 단계가 필요합니다.
//!
//! `1` 에서 `5` 까지 세는 `Counter` 라는 스트림을 만들어 보겠습니다.
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // 첫째, 구조체 :
//!
//! /// 1에서 5까지 세는 스트림
//! struct Counter {
//!     count: usize,
//! }
//!
//! // 카운트가 1부터 시작되기를 원하므로 new() 메서드를 추가하여 도움을 드리겠습니다.
//! // 이것은 꼭 필요한 것은 아니지만 편리합니다.
//! // `count` 는 0에서 시작합니다. 아래 `poll_next()`'s 구현에서 그 이유를 알 수 있습니다.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // 그런 다음 `Counter` 에 대해 `Stream` 를 구현합니다.
//!
//! impl Stream for Counter {
//!     // 우리는 usize와 함께 셀 것입니다
//!     type Item = usize;
//!
//!     // poll_next() 유일한 필수 방법입니다.
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // 카운트를 늘립니다.이것이 우리가 0에서 시작한 이유입니다.
//!         self.count += 1;
//!
//!         // 계산이 끝났는지 확인하십시오.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! 스트림은 *지연* 입니다.즉, 스트림을 만드는 것만으로는 _do_ 가 많이 발생하지 않습니다.`next` 를 호출 할 때까지 아무 일도 일어나지 않습니다.
//! 이것은 부작용만을위한 스트림을 생성 할 때 때때로 혼란의 원인이됩니다.
//! 컴파일러는 이러한 종류의 동작에 대해 경고합니다.
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;