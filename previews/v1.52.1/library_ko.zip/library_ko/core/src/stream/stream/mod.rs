use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// 비동기 반복기를 처리하기위한 인터페이스입니다.
///
/// 이것이 메인 스트림 trait 입니다.
/// 일반적으로 스트림 개념에 대한 자세한 내용은 [module-level documentation] 를 참조하십시오.
/// 특히 [implement `Stream`][impl] 방법을 알고 싶을 수 있습니다.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// 스트림에서 산출 된 항목 유형입니다.
    type Item;

    /// 이 스트림의 다음 값을 가져 와서 값을 아직 사용할 수없는 경우 웨이크 업을 위해 현재 작업을 등록하고 스트림이 소진되면 `None` 를 반환합니다.
    ///
    /// # 반환 값
    ///
    /// 가능한 반환 값은 여러 가지가 있으며 각각 고유 한 스트림 상태를 나타냅니다.
    ///
    /// - `Poll::Pending` 이 스트림의 다음 값이 아직 준비되지 않았 음을 의미합니다.구현은 다음 값이 준비 될 때 현재 작업이 알림을 받도록 보장합니다.
    ///
    /// - `Poll::Ready(Some(val))` 스트림이 `val` 값을 성공적으로 생성했으며 후속 `poll_next` 호출에서 추가 값을 생성 할 수 있음을 의미합니다.
    ///
    /// - `Poll::Ready(None)` 스트림이 종료되었으며 `poll_next` 를 다시 호출하지 않아야 함을 의미합니다.
    ///
    /// # Panics
    ///
    /// 스트림이 완료되면 (`Ready(None)` from `poll_next`) 반환, `poll_next` 메서드를 다시 호출하면 panic, 영원히 차단되거나 다른 종류의 문제가 발생할 수 있습니다 .`Stream` trait 는 이러한 호출의 효과에 대한 요구 사항을 지정하지 않습니다.
    ///
    /// 그러나 `poll_next` 메서드가 `unsafe` 로 표시되지 않기 때문에 Rust 의 일반적인 규칙이 적용됩니다. 호출은 스트림 상태에 관계없이 정의되지 않은 동작 (메모리 손상, `unsafe` 함수의 잘못된 사용 등)을 유발해서는 안됩니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// 스트림의 나머지 길이에 대한 경계를 반환합니다.
    ///
    /// 특히 `size_hint()` 는 첫 번째 요소가 하한이고 두 번째 요소가 상한 인 튜플을 반환합니다.
    ///
    /// 반환되는 튜플의 나머지 절반은 [`Option`]`<`[`usize`]`>`입니다.
    /// 여기서 [`None`] 는 알려진 상한이 없거나 상한이 [`usize`] 보다 크다는 것을 의미합니다.
    ///
    /// # 구현 참고 사항
    ///
    /// 스트림 구현이 선언 된 요소 수를 산출하도록 강제되지 않습니다.버그가있는 스트림은 요소의 하한보다 적거나 상한보다 더 많이 산출 할 수 있습니다.
    ///
    /// `size_hint()` 주로 스트림의 요소를위한 공간을 예약하는 것과 같은 최적화에 사용하기위한 것이지만, 예를 들어 안전하지 않은 코드에서 경계 검사를 생략하도록 신뢰해서는 안됩니다.
    /// `size_hint()` 의 잘못된 구현은 메모리 안전 위반으로 이어지지 않아야합니다.
    ///
    /// 즉, 구현시 올바른 추정치를 제공해야합니다. 그렇지 않으면 trait 의 프로토콜을 위반하게됩니다.
    ///
    /// 기본 구현은 모든 스트림에 맞는`(0,`[`None`]`)`을 반환합니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}