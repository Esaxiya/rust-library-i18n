//! 주문 및 비교 기능.
//!
//! 이 모듈에는 값을 정렬하고 비교하기위한 다양한 도구가 포함되어 있습니다.요약해서 말하자면:
//!
//! * [`Eq`] [`PartialEq`] 는 traits 로 각각 값 간의 전체 및 부분 동등성을 정의 할 수 있습니다.
//! 이를 구현하면 `==` 및 `!=` 연산자가 오버로드됩니다.
//! * [`Ord`] [`PartialOrd`] 는 traits 로 값 사이의 전체 및 부분 순서를 각각 정의 할 수 있습니다.
//!
//! 이를 구현하면 `<`, `<=`, `>` 및 `>=` 연산자가 오버로드됩니다.
//! * [`Ordering`] [`Ord`] 및 [`PartialOrd`] 의 주요 기능에 의해 반환되는 열거 형이며 순서를 설명합니다.
//! * [`Reverse`] 순서를 쉽게 뒤집을 수있는 구조체입니다.
//! * [`max`] [`min`] 는 [`Ord`] 를 기반으로하는 함수이며 두 값의 최대 값 또는 최소값을 찾을 수 있습니다.
//!
//! 자세한 내용은 목록의 각 항목에 대한 각 설명서를 참조하십시오.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait 는 [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) 인 동등성 비교를위한 것입니다.
///
/// 이 trait 는 완전한 동등성 관계가없는 유형에 대해 부분 동등성을 허용합니다.
/// 예를 들어 부동 소수점 숫자 `NaN != NaN` 에서 부동 소수점 유형은 [`trait@Eq`] 가 아닌 `PartialEq` 를 구현합니다.
///
/// 공식적으로 같음은 다음과 같아야합니다 (`A`, `B`, `C` 유형의 모든 `a`, `b`, `c`).
///
/// - **대칭**: `A: PartialEq<B>` 및 `B: PartialEq<A>` 인 경우 **`a==b`는`b==a`** 를 의미합니다.과
///
/// - **전환**: `A: PartialEq<B>` 및 `B: PartialEq<C>` 및`A :
///   PartialEq<C>`,**`a==b`이고 `b == c` 는`a==c`** 를 의미합니다.
///
/// `B: PartialEq<A>` (symmetric) 및 `A: PartialEq<C>` (transitive) impls는 강제로 존재하지 않지만 이러한 요구 사항은 존재할 때마다 적용됩니다.
///
/// ## Derivable
///
/// 이 trait 는 `#[derive]` 와 함께 사용할 수 있습니다.구조체에서 '파생'될 때 모든 필드가 같으면 두 인스턴스가 같고 필드가 같지 않으면 같지 않습니다.열거 형에서 '파생'되면 각 변형은 자신과 동일하고 다른 변형과 동일하지 않습니다.
///
/// ## `PartialEq` 를 어떻게 구현할 수 있습니까?
///
/// `PartialEq` [`eq`] 메소드 만 구현하면됩니다.[`ne`] 는 기본적으로 정의됩니다.[`ne`] 의 모든 수동 구현은 [`eq`] 가 [`ne`] 의 엄격한 역수라는 규칙을 *반드시* 준수해야합니다.즉, `a != b` 인 경우에만 `!(a == b)` 입니다.
///
/// `PartialEq`, [`PartialOrd`] 및 [`Ord`] 의 구현은 *반드시* 서로 일치해야합니다.traits 중 일부를 파생하고 다른 일부를 수동으로 구현하여 실수로 동의하지 않게 만드는 것은 쉽습니다.
///
/// 형식이 다르더라도 ISBN이 일치하면 두 책이 동일한 책으로 간주되는 도메인 구현의 예 :
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## 두 가지 유형을 어떻게 비교할 수 있습니까?
///
/// 비교할 수있는 유형은`PartialEq`의 유형 매개 변수에 의해 제어됩니다.
/// 예를 들어, 이전 코드를 약간 수정 해 보겠습니다.
///
/// ```
/// // 파생 구현<BookFormat>==<BookFormat>비교
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // 도구<Book>==<BookFormat>비교
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // 도구<BookFormat>==<Book>비교
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` 를 `impl PartialEq<BookFormat> for Book` 로 변경하여`BookFormat`을`Book`과 비교할 수 있습니다.
///
/// 구조체의 일부 필드를 무시하는 위와 같은 비교는 위험 할 수 있습니다.부분적 동등성 관계에 대한 요구 사항의 의도하지 않은 위반으로 쉽게 이어질 수 있습니다.
/// 예를 들어, 위의 `BookFormat` 용 `PartialEq<Book>` 구현을 유지하고 `Book` 용 `PartialEq<Book>` 구현을 추가 한 경우 (`#[derive]` 를 통해 또는 첫 번째 예제의 수동 구현을 통해) 결과는 전이성을 위반합니다.
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// 이 메서드는 `self` 및 `other` 값이 같은지 테스트하고 `==` 에서 사용합니다.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// 이 방법은 `!=` 를 테스트합니다.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq` 의 impl을 생성하는 매크로를 유도합니다.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait 는 [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) 인 동등성 비교를위한 것입니다.
///
/// 즉, `a == b` 및 `a != b` 가 엄격한 역인 것 외에도 동등성은 다음과 같아야합니다 (모든 `a`, `b` 및 `c` 에 대해).
///
/// - reflexive: `a == a`;
/// - 대칭: `a == b` 는 `b == a` 를 의미합니다.과
/// - 전이: `a == b` 및 `b == c` 는 `a == c` 를 의미합니다.
///
/// 이 속성은 컴파일러에서 확인할 수 없으므로 `Eq` 는 [`PartialEq`] 를 의미하며 추가 메서드가 없습니다.
///
/// ## Derivable
///
/// 이 trait 는 `#[derive]` 와 함께 사용할 수 있습니다.
/// '파생'되면 `Eq` 에는 추가 메서드가 없기 때문에 컴파일러에게 이것이 부분 동등 관계가 아니라 동등 관계임을 알리는 것입니다.
///
/// `derive` 전략을 사용하려면 모든 필드가 `Eq` 여야하며 항상 바람직하지는 않습니다.
///
/// ## `Eq` 를 어떻게 구현할 수 있습니까?
///
/// `derive` 전략을 사용할 수없는 경우 유형이 메소드가없는 `Eq` 를 구현하도록 지정하십시오.
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // 이 메서드는 유형의 모든 구성 요소가#[deriving] 자체를 구현한다고 주장하기 위해#[deriving]에 의해서만 사용됩니다. 현재 파생 인프라는이 trait 에서 메서드를 사용하지 않고이 주장을 수행하는 것이 거의 불가능하다는 것을 의미합니다.
    //
    //
    // 이것은 손으로 구현해서는 안됩니다.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq` 의 impl을 생성하는 매크로를 유도합니다.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: 이 구조체는#[derive]에 의해서만 사용됩니다.
// 유형의 모든 구성 요소가 Eq를 구현한다고 주장합니다.
//
// 이 구조체는 사용자 코드에 나타나지 않아야합니다.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` 는 두 값을 비교 한 결과입니다.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// 비교 값이 다른 값보다 작은 순서입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// 비교 된 값이 다른 값과 동일한 순서입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// 비교 된 값이 다른 값보다 큰 순서입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// 주문이 `Equal` 변형 인 경우 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// 주문이 `Equal` 변형이 아닌 경우 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// 주문이 `Less` 변형 인 경우 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// 주문이 `Greater` 변형 인 경우 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// 주문이 `Less` 또는 `Equal` 변형 인 경우 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// 주문이 `Greater` 또는 `Equal` 변형 인 경우 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` 를 반전합니다.
    ///
    /// * `Less` `Greater` 가됩니다.
    /// * `Greater` `Less` 가됩니다.
    /// * `Equal` `Equal` 가됩니다.
    ///
    /// # Examples
    ///
    /// 기본 동작 :
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// 이 방법은 비교를 반대로하는 데 사용할 수 있습니다.
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // 가장 큰 것에서 가장 작은 것까지 배열을 정렬합니다.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// 두 가지 순서를 연결합니다.
    ///
    /// `Equal` 가 아닌 경우 `self` 를 반환합니다.그렇지 않으면 `other` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// 주어진 함수로 순서를 연결합니다.
    ///
    /// `Equal` 가 아닌 경우 `self` 를 반환합니다.
    /// 그렇지 않으면 `f` 를 호출하고 결과를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// 역순 정렬을위한 도우미 구조체입니다.
///
/// 이 구조체는 [`Vec::sort_by_key`] 와 같은 함수와 함께 사용되는 도우미이며 키의 일부를 역순으로 정렬하는 데 사용할 수 있습니다.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// [total order](https://en.wikipedia.org/wiki/Total_order) 를 형성하는 유형의 경우 Trait 입니다.
///
/// 다음과 같은 경우 주문은 총 주문입니다 (모든 `a`, `b` 및 `c`).
///
/// - 전체 및 비대칭: `a < b`, `a == b` 또는 `a > b` 중 정확히 하나가 참입니다.과
/// - 전이, `a < b` 및 `b < c` 는 `a < c` 를 의미합니다.`==` 와 `>` 모두 동일해야합니다.
///
/// ## Derivable
///
/// 이 trait 는 `#[derive]` 와 함께 사용할 수 있습니다.
/// 구조체에서 '파생'되면 구조체 멤버의 위에서 아래로 선언 된 순서를 기반으로 [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) 순서를 생성합니다.
///
/// 열거 형에서 '파생'될 때 변형은 위에서 아래로 판별되는 순서로 정렬됩니다.
///
/// ## 사전 비교
///
/// 사전 비교는 다음과 같은 속성을 가진 작업입니다.
///  - 두 시퀀스는 요소별로 비교됩니다.
///  - 첫 번째 불일치 요소는 사전 순으로 다른 시퀀스보다 작거나 큰 시퀀스를 정의합니다.
///  - 한 시퀀스가 다른 시퀀스의 접두사 인 경우 더 짧은 시퀀스는 사 전적으로 다른 시퀀스보다 작습니다.
///  - 두 시퀀스에 동일한 요소가 있고 길이가 같은 경우 시퀀스는 사 전적으로 동일합니다.
///  - 빈 시퀀스는 비어 있지 않은 시퀀스보다 사전 식적으로 작습니다.
///  - 두 개의 빈 시퀀스는 사 전적으로 동일합니다.
///
/// ## `Ord` 를 어떻게 구현할 수 있습니까?
///
/// `Ord` 유형도 [`PartialOrd`] 및 [`Eq`] ([`PartialEq`] 필요) 여야합니다.
///
/// 그런 다음 [`cmp`] 에 대한 구현을 정의해야합니다.유형의 필드에서 [`cmp`] 를 사용하는 것이 유용 할 수 있습니다.
///
/// [`PartialEq`], [`PartialOrd`] 및 `Ord` 의 구현은 *반드시* 서로 일치해야합니다.
/// 즉, 모든 `a` 및 `b` 에 대해 `a == b` 및 `Some(a.cmp(b)) == a.partial_cmp(b)` 인 경우에만 `a.cmp(b) == Ordering::Equal` 입니다.
/// traits 중 일부를 파생하고 다른 일부를 수동으로 구현하여 실수로 동의하지 않게 만드는 것은 쉽습니다.
///
/// 다음은 `id` 및 `name` 를 무시하고 키로 만 사람을 정렬하려는 예입니다.
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// 이 메서드는 `self` 와 `other` 사이의 [`Ordering`] 를 반환합니다.
    ///
    /// 규칙에 따라 `self.cmp(&other)` 는 true 인 경우 `self <operator> other` 표현식과 일치하는 순서를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// 최대 두 값을 비교하고 반환합니다.
    ///
    /// 비교 결과 두 번째 인수가 동일하다고 판단되면 두 번째 인수를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// 최소 두 값을 비교하고 반환합니다.
    ///
    /// 비교 결과 동일하다고 판단되면 첫 번째 인수를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// 값을 특정 간격으로 제한합니다.
    ///
    /// `self` 가 `max` 보다 크면 `max` 를 반환하고 `self` 가 `min` 보다 작 으면 `min` 를 반환합니다.
    /// 그렇지 않으면 `self` 를 반환합니다.
    ///
    /// # Panics
    ///
    /// `min > max` 인 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord` 의 impl을 생성하는 매크로를 유도합니다.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// 정렬 순서에 대해 비교할 수있는 값의 경우 Trait 입니다.
///
/// 비교는 모든 `a`, `b` 및 `c` 에 대해 다음을 충족해야합니다.
///
/// - 비대칭: `a < b` 이면 `!(a > b)`, `!(a < b)` 를 의미하는 `a > b`;과
/// - 전이성: `a < b` 및 `b < c` 는 `a < c` 를 의미합니다.`==` 와 `>` 모두 동일해야합니다.
///
/// 이러한 요구 사항은 trait 자체가 대칭적이고 전 이적으로 구현되어야 함을 의미합니다. `T: PartialOrd<U>` 및 `U: PartialOrd<V>` 인 경우 `U: PartialOrd<T>` 및`T :
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// 이 trait 는 `#[derive]` 와 함께 사용할 수 있습니다.구조체에서 '파생'되면 구조체 멤버의 맨 위에서 맨 아래로 선언 순서를 기반으로 사전 순서를 생성합니다.
/// 열거 형에서 '파생'될 때 변형은 위에서 아래로 판별되는 순서로 정렬됩니다.
///
/// ## `PartialOrd` 를 어떻게 구현할 수 있습니까?
///
/// `PartialOrd` [`partial_cmp`] 메서드의 구현 만 필요하며 나머지는 기본 구현에서 생성됩니다.
///
/// 그러나 총 주문이없는 유형에 대해 다른 것을 별도로 구현하는 것은 가능합니다.
/// 예를 들어 부동 소수점 숫자의 경우 `NaN < 0 == false` 및 `NaN >= 0 == false` (참조 :
/// IEEE 754-2008 섹션 5.11).
///
/// `PartialOrd` 유형이 [`PartialEq`] 여야합니다.
///
/// [`PartialEq`], `PartialOrd` 및 [`Ord`] 의 구현은 *반드시* 서로 일치해야합니다.
/// traits 중 일부를 파생하고 다른 일부를 수동으로 구현하여 실수로 동의하지 않게 만드는 것은 쉽습니다.
///
/// 유형이 [`Ord`] 인 경우 [`cmp`] 를 사용하여 [`partial_cmp`] 를 구현할 수 있습니다.
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// 유형의 필드에서 [`partial_cmp`] 를 사용하는 것이 유용 할 수도 있습니다.
/// 다음은 정렬에 사용되는 유일한 필드 인 부동 소수점 `height` 필드가있는 `Person` 유형의 예입니다.
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// 이 메소드는 존재하는 경우 `self` 와 `other` 값 사이의 순서를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// 비교가 불가능한 경우 :
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// 이 방법은 `self` 및 `other` 에 대해보다 작게 테스트하며 `<` 연산자에서 사용합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// 이 방법은 `self` 및 `other` 에 대해 작거나 같음을 테스트하며 `<=` 연산자에서 사용합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// 이 방법은보다 큼 (`self` 및 `other` 의 경우)을 테스트하며 `>` 연산자에서 사용합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// 이 방법은보다 크거나 같음 (`self` 및 `other` 의 경우)을 테스트하며 `>=` 연산자에서 사용됩니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd` 의 impl을 생성하는 매크로를 유도합니다.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// 최소 두 값을 비교하고 반환합니다.
///
/// 비교 결과 동일하다고 판단되면 첫 번째 인수를 반환합니다.
///
/// 내부적으로 [`Ord::min`] 에 대한 별칭을 사용합니다.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// 지정된 비교 함수와 관련하여 최소 두 값을 반환합니다.
///
/// 비교 결과 동일하다고 판단되면 첫 번째 인수를 반환합니다.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// 지정된 함수에서 최소값을 제공하는 요소를 반환합니다.
///
/// 비교 결과 동일하다고 판단되면 첫 번째 인수를 반환합니다.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// 최대 두 값을 비교하고 반환합니다.
///
/// 비교 결과 두 번째 인수가 동일하다고 판단되면 두 번째 인수를 반환합니다.
///
/// 내부적으로 [`Ord::max`] 에 대한 별칭을 사용합니다.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// 지정된 비교 함수와 관련하여 최대 두 값을 반환합니다.
///
/// 비교 결과 두 번째 인수가 동일하다고 판단되면 두 번째 인수를 반환합니다.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// 지정된 함수에서 최대 값을 제공하는 요소를 반환합니다.
///
/// 비교 결과 두 번째 인수가 동일하다고 판단되면 두 번째 인수를 반환합니다.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// 기본 유형에 대한 PartialEq, Eq, PartialOrd 및 Ord 구현
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // 여기서 순서는보다 최적의 어셈블리를 생성하는 데 중요합니다.
                    // 자세한 내용은 <https://github.com/rust-lang/rust/issues/63758> 를 참조하십시오.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // i8로 캐스팅하고 차이를 Ordering으로 변환하면보다 최적의 어셈블리가 생성됩니다.
            //
            // 자세한 내용은 <https://github.com/rust-lang/rust/issues/66780> 를 참조하십시오.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // 안전: bool 는 i8 가 0 또는 1을 반환하므로 차이는 다른 것이 될 수 없습니다.
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // 및 포인터

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}