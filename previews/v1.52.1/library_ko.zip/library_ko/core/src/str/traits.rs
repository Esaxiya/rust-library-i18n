//! `str` 에 대한 Trait 구현.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// 문자열의 순서를 구현합니다.
///
/// 문자열은 바이트 값에 따라 [lexicographically](Ord#lexicographical-comparison) 로 정렬됩니다.
/// 이것은 코드 차트에서의 위치에 따라 유니 코드 코드 포인트를 정렬합니다.
/// 이것은 언어 및 로케일에 따라 달라지는 "alphabetical" 순서와 반드시 동일하지는 않습니다.
/// 문화적으로 허용되는 표준에 따라 문자열을 정렬하려면 `str` 유형의 범위를 벗어나는 로케일 별 데이터가 필요합니다.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// 문자열에 대한 비교 작업을 구현합니다.
///
/// 문자열은 바이트 값으로 [lexicographically](Ord#lexicographical-comparison) 를 비교합니다.
/// 이것은 코드 차트에서의 위치에 따라 유니 코드 코드 포인트를 비교합니다.
/// 이것은 언어 및 로케일에 따라 달라지는 "alphabetical" 순서와 반드시 동일하지는 않습니다.
/// 문화적으로 허용되는 표준에 따라 문자열을 비교하려면 `str` 유형의 범위를 벗어나는 로케일 별 데이터가 필요합니다.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// 구문 `&self[..]` 또는 `&mut self[..]` 를 사용하여 부분 문자열 슬라이스를 구현합니다.
///
/// 전체 문자열의 조각을 반환합니다. 즉, `&self` 또는 `&mut self` 를 반환합니다.`&self [0 ..
/// len]`또는`&mut self [0 ..
/// len]`.
/// 다른 인덱싱 작업과 달리 이것은 panic 가 될 수 없습니다.
///
/// 이 작업은 *O*(1)입니다.
///
/// 1.20.0 이전에는 이러한 인덱싱 작업이 `Index` 및 `IndexMut` 를 직접 구현하여 계속 지원되었습니다.
///
/// `&self[0 .. len]` 또는 `&mut self[0 .. len]` 와 동일합니다.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// 구문 `&self[begin .. end]` 또는 `&mut self[begin .. end]` 를 사용하여 부분 문자열 슬라이스를 구현합니다.
///
/// 바이트 범위 [`begin`, `end`)에서 주어진 문자열의 조각을 반환합니다.
///
/// 이 작업은 *O*(1)입니다.
///
/// 1.20.0 이전에는 이러한 인덱싱 작업이 `Index` 및 `IndexMut` 를 직접 구현하여 계속 지원되었습니다.
///
/// # Panics
///
/// `begin` 또는 `end` 가 문자의 시작 바이트 오프셋 (`is_char_boundary` 에 정의 된대로)을 가리 키지 않는 경우 Panics, `begin > end` 또는 `end > len` 인 경우.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // 이들은 panic :
/// // 바이트 2는 `ö` 내에 있습니다.
/// // &s [2 ..3];
///
/// // 바이트 8은 `老`&s [1 ..
/// // 8];
///
/// // 바이트 100은 문자열&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // 안전: `start` 와 `end` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            // 문자 경계도 확인 했으므로 유효한 UTF-8 입니다.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // 안전: `start` 및 `end` 가 문자 경계에 있는지 확인했습니다.
            // 포인터가 `slice` 에서 가져 왔기 때문에 고유하다는 것을 알고 있습니다.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // 안전: 호출자는 `self` 가 `slice` 범위 내에 있음을 보장합니다.
        // `add` 의 모든 조건을 충족합니다.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // 안전: `get_unchecked` 에 대한 설명을 참조하십시오.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary는 인덱스가 [0에 있는지 확인하고, .len()] 는 NLL 문제로 인해 위와 같이 `get` 를 재사용 할 수 없습니다.
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // 안전: `start` 와 `end` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// 구문 `&self[.. end]` 또는 `&mut self[.. end]` 를 사용하여 부분 문자열 슬라이스를 구현합니다.
///
/// 바이트 범위 [`0`, `end`)에서 주어진 문자열의 조각을 반환합니다.
/// `&self[0 .. end]` 또는 `&mut self[0 .. end]` 와 동일합니다.
///
/// 이 작업은 *O*(1)입니다.
///
/// 1.20.0 이전에는 이러한 인덱싱 작업이 `Index` 및 `IndexMut` 를 직접 구현하여 계속 지원되었습니다.
///
/// # Panics
///
/// Panics `end` 가 문자의 시작 바이트 오프셋 (`is_char_boundary` 에 의해 정의 됨)을 가리 키지 않거나 `end > len` 인 경우.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // 안전: `end` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // 안전: `end` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // 안전: `end` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// 구문 `&self[begin ..]` 또는 `&mut self[begin ..]` 를 사용하여 부분 문자열 슬라이스를 구현합니다.
///
/// 바이트 범위 [`begin`, `len`)에서 주어진 문자열의 조각을 반환합니다.`&self [begin ..
/// len]`또는`&mut self [begin ..
/// len]`.
///
/// 이 작업은 *O*(1)입니다.
///
/// 1.20.0 이전에는 이러한 인덱싱 작업이 `Index` 및 `IndexMut` 를 직접 구현하여 계속 지원되었습니다.
///
/// # Panics
///
/// Panics `begin` 가 문자의 시작 바이트 오프셋 (`is_char_boundary` 에 의해 정의 됨)을 가리 키지 않거나 `begin > len` 인 경우.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // 안전: `start` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // 안전: `start` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // 안전: 호출자는 `self` 가 `slice` 범위 내에 있음을 보장합니다.
        // `add` 의 모든 조건을 충족합니다.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // 안전: `get_unchecked` 와 동일합니다.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // 안전: `start` 가 문자 경계에 있는지 확인했습니다.
            // 안전한 참조를 전달하므로 반환 값도 1이됩니다.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// 구문 `&self[begin ..= end]` 또는 `&mut self[begin ..= end]` 를 사용하여 부분 문자열 슬라이스를 구현합니다.
///
/// 바이트 범위 [`begin`, `end`] 에서 주어진 문자열의 조각을 반환합니다.`end` 에 `usize` 의 최대 값이있는 경우를 제외하고 `&self [begin .. end + 1]` 또는 `&mut self[begin .. end + 1]` 와 동일합니다.
///
/// 이 작업은 *O*(1)입니다.
///
/// # Panics
///
/// `begin` 가 문자의 시작 바이트 오프셋을 가리 키지 않는 경우 (`is_char_boundary` 에 정의 된대로), `end` 가 문자의 끝 바이트 오프셋을 가리 키지 않는 경우 (`end + 1` 는 시작 바이트 오프셋이거나 `len` 와 같음), `begin > end` 인 경우, 또는 `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // 안전: 발신자는 `get_unchecked` 에 대한 안전 계약을 유지해야합니다.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // 안전: 발신자는 `get_unchecked_mut` 에 대한 안전 계약을 유지해야합니다.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// 구문 `&self[..= end]` 또는 `&mut self[..= end]` 를 사용하여 부분 문자열 슬라이스를 구현합니다.
///
/// 바이트 범위 [0, `end`] 에서 주어진 문자열의 조각을 반환합니다.
/// `end` 에 `usize` 의 최대 값이있는 경우를 제외하고 `&self [0 .. end + 1]` 와 동일합니다.
///
/// 이 작업은 *O*(1)입니다.
///
/// # Panics
///
/// Panics `end` 가 문자의 끝 바이트 오프셋을 가리 키지 않는 경우 (`end + 1` 는 `is_char_boundary` 에 정의 된 시작 바이트 오프셋이거나 `len` 와 같음) 또는 `end >= len` 인 경우.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // 안전: 발신자는 `get_unchecked` 에 대한 안전 계약을 유지해야합니다.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // 안전: 발신자는 `get_unchecked_mut` 에 대한 안전 계약을 유지해야합니다.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// 문자열에서 값 구문 분석
///
/// `FromStr`의 [`from_str`] 방식은 [`str`]의 [`parse`] 방식을 통해 묵시적으로 사용되는 경우가 많습니다.
/// 예제는 [`parse`]의 문서를 참조하세요.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` 수명 매개 변수가 없으므로 수명 매개 변수 자체를 포함하지 않는 유형 만 구문 분석 할 수 있습니다.
///
/// 즉, `FromStr` 로 `i32` 를 구문 분석 할 수 있지만 `&i32` 는 구문 분석 할 수 없습니다.
/// `i32` 는 포함하지만 `&i32` 는 포함하지 않는 구조체를 구문 분석 할 수 있습니다.
///
/// # Examples
///
/// 예제 `Point` 유형에서 `FromStr` 의 기본 구현 :
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// 구문 분석에서 반환 될 수있는 관련 오류입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// 이 유형의 값을 리턴하기 위해 문자열 `s` 를 구문 분석합니다.
    ///
    /// 구문 분석이 성공하면 [`Ok`] 내부의 값을 반환하고, 그렇지 않으면 문자열 형식이 잘못된 경우 내부 [`Err`] 에 특정한 오류를 반환합니다.
    /// 오류 유형은 trait 의 구현에 따라 다릅니다.
    ///
    /// # Examples
    ///
    /// `FromStr` 를 구현하는 유형 인 [`i32`] 의 기본 사용법 :
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// 문자열에서 `bool` 를 구문 분석합니다.
    ///
    /// `s` 는 실제로 구문 분석 할 수 있거나 그렇지 않을 수 있으므로 `Result<bool, ParseBoolError>` 를 생성합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// 많은 경우 `str` 의 `.parse()` 방법이 더 적절합니다.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}