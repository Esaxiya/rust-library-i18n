//! utf8 오류 유형을 정의합니다.

use crate::fmt;

/// [`u8`] 시퀀스를 문자열로 해석하려고 할 때 발생할 수있는 오류입니다.
///
/// 따라서 예를 들어 [`String`]과 [`&str`] 모두에 대한 `from_utf8` 함수 및 메서드 제품군은이 오류를 사용합니다.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// 이 오류 유형의 메서드는 힙 메모리를 할당하지 않고 `String::from_utf8_lossy` 와 유사한 기능을 만드는 데 사용할 수 있습니다.
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// 유효한 UTF-8 가 확인 된 주어진 문자열의 인덱스를 반환합니다.
    ///
    /// `from_utf8(&input[..index])` 가 `Ok(_)` 를 반환하는 최대 인덱스입니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector 의 일부 잘못된 바이트
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error를 반환합니다.
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // 두 번째 바이트는 여기서 유효하지 않습니다.
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// 실패에 대한 자세한 정보를 제공합니다.
    ///
    /// * `None`: 입력의 끝에 예기치 않게 도달했습니다.
    ///   `self.valid_up_to()` 입력의 끝에서 1-3 바이트입니다.
    ///   바이트 스트림 (예: 파일 또는 네트워크 소켓)이 점진적으로 디코딩되는 경우 이는 UTF-8 바이트 시퀀스가 여러 청크에 걸쳐있는 유효한 `char` 일 수 있습니다.
    ///
    ///
    /// * `Some(len)`: 예기치 않은 바이트가 발견되었습니다.
    ///   제공된 길이는 `valid_up_to()` 가 제공 한 색인에서 시작하는 유효하지 않은 바이트 시퀀스의 길이입니다.
    ///   손실 디코딩의 경우 디코딩은 해당 시퀀스 이후 ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] 삽입 후) 다시 시작되어야합니다.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] 를 사용하여 `bool` 구문 분석이 실패 할 때 반환되는 오류
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}