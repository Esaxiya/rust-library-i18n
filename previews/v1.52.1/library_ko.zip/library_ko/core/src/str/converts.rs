//! 바이트 슬라이스에서 `str` 를 만드는 방법.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// 바이트 조각을 문자열 조각으로 변환합니다.
///
/// 문자열 슬라이스 ([`&str`]) 는 바이트 ([`u8`]) 로 구성되고 바이트 슬라이스 ([`&[u8]`][byteslice]) 는 바이트로 구성되므로이 함수는 둘 사이에서 변환됩니다.
/// 모든 바이트 조각이 유효한 문자열 조각은 아니지만 [`&str`] 는 유효한 UTF-8 여야합니다.
/// `from_utf8()` 바이트가 유효한 UTF-8 인지 확인한 다음 변환을 수행합니다.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// 바이트 슬라이스가 유효한 UTF-8 임을 확신하고 유효성 검사의 오버 헤드를 발생시키지 않으려면이 함수의 안전하지 않은 버전 인 [`from_utf8_unchecked`] 가 있습니다.이 함수는 동작이 동일하지만 검사를 건너 뜁니다.
///
///
/// `&str` 대신 `String` 가 필요한 경우 [`String::from_utf8`][string] 를 고려하십시오.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// `[u8; N]` 를 스택 할당 할 수 있고 [`&[u8]`][byteslice] 를 사용할 수 있기 때문에이 함수는 스택 할당 문자열을 갖는 한 가지 방법입니다.아래 예 섹션에 이에 대한 예가 있습니다.
///
/// [byteslice]: slice
///
/// # Errors
///
/// 슬라이스가 UTF-8 가 아닌 경우 제공된 슬라이스가 UTF-8 가 아닌 이유에 대한 설명과 함께 `Err` 를 반환합니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::str;
///
/// // vector 의 일부 바이트
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // 이 바이트가 유효하다는 것을 알고 있으므로 `unwrap()` 를 사용하십시오.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// 잘못된 바이트 :
///
/// ```
/// use std::str;
///
/// // vector 의 일부 잘못된 바이트
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// 반환 될 수있는 오류 종류에 대한 자세한 내용은 [`Utf8Error`] 문서를 참조하십시오.
///
/// "stack allocated string" :
///
/// ```
/// use std::str;
///
/// // 스택 할당 배열의 일부 바이트
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // 이 바이트가 유효하다는 것을 알고 있으므로 `unwrap()` 를 사용하십시오.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // 안전: 방금 유효성 검사를 실행했습니다.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// 가변 바이트 조각을 가변 문자열 조각으로 변환합니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" 변경 가능한 vector 로
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // 이 바이트가 유효하다는 것을 알고 있으므로 `unwrap()` 를 사용할 수 있습니다.
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// 잘못된 바이트 :
///
/// ```
/// use std::str;
///
/// // 변경 가능한 vector 의 일부 유효하지 않은 바이트
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// 반환 될 수있는 오류 종류에 대한 자세한 내용은 [`Utf8Error`] 문서를 참조하십시오.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // 안전: 방금 유효성 검사를 실행했습니다.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// 문자열에 유효한 UTF-8 가 포함되어 있는지 확인하지 않고 바이트 조각을 문자열 조각으로 변환합니다.
///
/// 자세한 내용은 안전한 버전 [`from_utf8`] 를 참조하십시오.
///
/// # Safety
///
/// 이 함수는 전달 된 바이트가 유효한 UTF-8 인지 확인하지 않기 때문에 안전하지 않습니다.
/// 이 제약 조건을 위반하면 Rust 의 나머지 부분이 [`&str`]이 유효한 UTF-8 라고 가정하므로 정의되지 않은 동작이 발생합니다.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::str;
///
/// // vector 의 일부 바이트
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // 안전: 호출자는 `v` 바이트가 유효한 UTF-8 임을 보장해야합니다.
    // 또한 동일한 레이아웃을 가진 `&str` 및 `&[u8]` 에 의존합니다.
    unsafe { mem::transmute(v) }
}

/// 문자열에 유효한 UTF-8 가 포함되어 있는지 확인하지 않고 바이트 조각을 문자열 조각으로 변환합니다.변경 가능한 버전.
///
///
/// 자세한 내용은 변경 불가능한 버전 [`from_utf8_unchecked()`] 를 참조하십시오.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // 안전: 호출자는 `v` 바이트를 보장해야합니다.
    // 유효한 UTF-8 이므로 `*mut str` 로의 캐스트는 안전합니다.
    // 또한 포인터 역 참조는 쓰기에 대해 유효하다고 보장되는 참조에서 온 포인터이므로 안전합니다.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}