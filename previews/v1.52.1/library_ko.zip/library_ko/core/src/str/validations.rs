//! UTF-8 유효성 검사와 관련된 작업입니다.

use crate::mem;

use super::Utf8Error;

/// 첫 번째 바이트에 대한 초기 코드 포인트 누산기를 반환합니다.
/// 첫 번째 바이트는 특별합니다. 너비 2의 경우 아래쪽 5 비트, 너비 3의 경우 4 비트, 너비 4의 경우 3 비트 만 필요합니다.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// 연속 바이트 `byte` 로 업데이트 된 `ch` 의 값을 반환합니다.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// 바이트가 UTF-8 연속 바이트 (즉, 비트 `10` 로 시작)인지 확인합니다.
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// 바이트 반복기 (UTF-8과 유사한 인코딩으로 가정)에서 다음 코드 포인트를 읽습니다.
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // UTF-8 디코딩
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // 멀티 바이트 케이스는 다음의 바이트 조합에서 디코딩을 따릅니다. [[[x y] z] w]
    //
    // NOTE: 성능은 여기서 정확한 공식에 민감합니다.
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] 케이스
        // 0xE0 의 5 번째 비트 .. 0xEF 는 항상 클리어되므로 `init` 는 여전히 유효합니다.
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] 케이스는 `init` 의 하위 3 비트 만 사용합니다.
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// 바이트 반복기에서 마지막 코드 포인트를 읽습니다 (UTF-8 유사 인코딩 가정).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // UTF-8 디코딩
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // 멀티 바이트 케이스는 다음 중 바이트 조합에서 디코딩을 따릅니다. [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// 잘림을 사용하여 u64 를 사용
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` 단어의 바이트가 nonascii (>=128)이면 `true` 를 반환합니다.
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` 를 통해 유효한 UTF-8 시퀀스인지 확인하고,이 경우 `Ok(())` 를 반환하거나, 유효하지 않은 경우 `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // 데이터가 필요했지만 오류가 없었습니다!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2 바이트 인코딩은 코드 포인트\u {0080}부터\u {07ff} 첫 C2 80 마지막 DF BF에 사용됩니다.
            // 3 바이트 인코딩은 서로 게이트 코드 포인트\u {d800}에서\u {dfff} ED A0 80에서 ED BF BF까지를 제외한 코드 포인트\u {0800}부터\u {ffff}까지 첫 E0 A0 80 마지막 EF BF BF 용입니다.
            // 4 바이트 인코딩은 코드 포인트\u {1000} 0 ~\u {10ff} ff 첫 F0 90 80 80 마지막 F4 8F BF BF
            //
            // RFC의 UTF-8 구문 사용
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8 꼬리 UTF8-3= %xE0 % xA0-BF UTF8 꼬리/% xE1-EC 2( UTF8-tail )/%xED % x80-9F UTF8 꼬리/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0 % x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4 % x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii의 경우 빨리 건너 뛰십시오.
            // 포인터가 정렬되면 ASCII가 아닌 바이트를 포함하는 단어를 찾을 때까지 반복 당 2 단어의 데이터를 읽습니다.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // 안전: `align - index` 및 `ascii_block_size` 는
                    // `usize_bytes` 의 배수, `block = ptr.add(index)` 는 항상 `usize` 와 정렬되므로 `block` 와 `block.offset(1)` 를 모두 역 참조하는 것이 안전합니다.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // nonascii 바이트가 있으면 중단
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // wordwise 루프가 멈춘 지점에서 한 걸음
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// 첫 번째 바이트가 주어지면이 UTF-8 문자에있는 바이트 수를 결정합니다.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// 연속 바이트의 값 비트 마스크.
const CONT_MASK: u8 = 0b0011_1111;
/// 연속 바이트의 태그 비트 (태그 마스크는 !CONT_MASK)의 값입니다.
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` 를 `max` 와 같은 길이로 자르면 잘린 경우 `true` 를 반환하고 새 str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}