//! 문자열 조작.
//!
//! 자세한 내용은 [`std::str`] 모듈을 참조하십시오.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. 출입 금지 구역의
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. 시작 <=끝
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. 문자 경계
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // 캐릭터 찾기
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` len 및 char 경계보다 작아야합니다.
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` 의 길이를 반환합니다.
    ///
    /// 이 길이는 [`char`] 또는 자소가 아닌 바이트 단위입니다.
    /// 즉, 인간이 현의 길이를 고려하는 것과 다를 수 있습니다.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // 멋진 f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `self` 의 길이가 0 바이트이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// '인덱스'번째 바이트가 UTF-8 코드 포인트 시퀀스의 첫 번째 바이트 또는 문자열의 끝인지 확인합니다.
    ///
    ///
    /// 문자열의 시작과 끝 (`index== self.len()`) 일 때 경계로 간주됩니다.
    ///
    /// `index` 가 `self.len()` 보다 크면 `false` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` 시작
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` 의 두 번째 바이트
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` 의 세 번째 바이트
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0과 len은 항상 괜찮습니다.
        // 검사를 쉽게 최적화하고 해당 경우에 대한 문자열 데이터 읽기를 건너 뛸 수 있도록 명시 적으로 0을 테스트합니다.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // 이것은 다음과 같은 비트 매직입니다. b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// 문자열 조각을 바이트 조각으로 변환합니다.
    /// 바이트 슬라이스를 다시 문자열 슬라이스로 변환하려면 [`from_utf8`] 함수를 사용하십시오.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // 안전: 동일한 레이아웃으로 두 가지 유형을 변환하기 때문에 const 사운드
        unsafe { mem::transmute(self) }
    }

    /// 변경 가능한 문자열 슬라이스를 변경 가능한 바이트 슬라이스로 변환합니다.
    ///
    /// # Safety
    ///
    /// 호출자는 차용이 끝나고 기본 `str` 가 사용되기 전에 슬라이스의 내용이 유효한 UTF-8 인지 확인해야합니다.
    ///
    ///
    /// 내용이 유효하지 않은 `str` 를 사용하는 것은 정의되지 않은 동작입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // 안전: `&str` 에서 `&[u8]` 로의 캐스트는 `str` 이후로 안전합니다.
        // `&[u8]` 와 레이아웃이 동일합니다 (libstd 만이 보장을 할 수 있습니다).
        // 포인터 역 참조는 쓰기에 대해 유효 함이 보장되는 가변 참조에서 오기 때문에 안전합니다.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// 문자열 조각을 원시 포인터로 변환합니다.
    ///
    /// 문자열 조각은 바이트 조각이므로 원시 포인터는 [`u8`] 를 가리 킵니다.
    /// 이 포인터는 문자열 슬라이스의 첫 번째 바이트를 가리 킵니다.
    ///
    /// 호출자는 반환 된 포인터가 기록되지 않도록해야합니다.
    /// 문자열 슬라이스의 내용을 변경해야하는 경우 [`as_mut_ptr`] 를 사용하십시오.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// 변경 가능한 문자열 조각을 원시 포인터로 변환합니다.
    ///
    /// 문자열 조각은 바이트 조각이므로 원시 포인터는 [`u8`] 를 가리 킵니다.
    /// 이 포인터는 문자열 슬라이스의 첫 번째 바이트를 가리 킵니다.
    ///
    /// 문자열 슬라이스가 유효한 UTF-8 로 유지되는 방식으로 만 수정되도록하는 것은 사용자의 책임입니다.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` 의 서브 슬라이스를 반환합니다.
    ///
    /// 이것은 `str` 인덱싱에 대한 당황하지 않는 대안입니다.
    /// 동등한 인덱싱 작업이 panic 가 될 때마다 [`None`] 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // UTF-8 시퀀스 경계에없는 인덱스
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // 출입 금지 구역의
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` 의 가변 서브 슬라이스를 반환합니다.
    ///
    /// 이것은 `str` 인덱싱에 대한 당황하지 않는 대안입니다.
    /// 동등한 인덱싱 작업이 panic 가 될 때마다 [`None`] 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // 정확한 길이
    /// assert!(v.get_mut(0..5).is_some());
    /// // 출입 금지 구역의
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` 의 선택되지 않은 부분을 반환합니다.
    ///
    /// 이것은 `str` 인덱싱에 대한 선택되지 않은 대안입니다.
    ///
    /// # Safety
    ///
    /// 이 함수의 호출자는 다음 전제 조건을 충족해야합니다.
    ///
    /// * 시작 색인은 종료 색인을 초과 할 수 없습니다.
    /// * 인덱스는 원래 조각의 경계 내에 있어야합니다.
    /// * 인덱스는 UTF-8 시퀀스 경계에 있어야합니다.
    ///
    /// 실패하면 반환 된 문자열 슬라이스가 잘못된 메모리를 참조하거나 `str` 유형이 전달하는 불변성을 위반할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // 안전: 발신자는 `get_unchecked` 에 대한 안전 계약을 유지해야합니다.
        // 슬라이스는 `self` 가 안전한 참조이므로 참조 할 수 없습니다.
        // 반환 된 포인터는 `SliceIndex` 의 impls가 보장해야하기 때문에 안전합니다.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` 의 변경 가능하고 확인되지 않은 서브 슬라이스를 반환합니다.
    ///
    /// 이것은 `str` 인덱싱에 대한 선택되지 않은 대안입니다.
    ///
    /// # Safety
    ///
    /// 이 함수의 호출자는 다음 전제 조건을 충족해야합니다.
    ///
    /// * 시작 색인은 종료 색인을 초과 할 수 없습니다.
    /// * 인덱스는 원래 조각의 경계 내에 있어야합니다.
    /// * 인덱스는 UTF-8 시퀀스 경계에 있어야합니다.
    ///
    /// 실패하면 반환 된 문자열 슬라이스가 잘못된 메모리를 참조하거나 `str` 유형이 전달하는 불변성을 위반할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // 안전: 발신자는 `get_unchecked_mut` 에 대한 안전 계약을 유지해야합니다.
        // 슬라이스는 `self` 가 안전한 참조이므로 참조 할 수 없습니다.
        // 반환 된 포인터는 `SliceIndex` 의 impls가 보장해야하기 때문에 안전합니다.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// 안전 검사를 우회하여 다른 문자열 조각에서 문자열 조각을 만듭니다.
    ///
    /// 이것은 일반적으로 권장되지 않으므로주의해서 사용하십시오!안전한 대안은 [`str`] 및 [`Index`] 를 참조하십시오.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// 이 새로운 슬라이스는 `begin` 를 포함하지만 `end` 를 제외한 `begin` 에서 `end` 로 이동합니다.
    ///
    /// 대신 변경 가능한 문자열 슬라이스를 얻으려면 [`slice_mut_unchecked`] 메서드를 참조하십시오.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// 이 함수의 호출자는 세 가지 전제 조건을 충족해야합니다.
    ///
    /// * `begin` `end` 를 초과하지 않아야합니다.
    /// * `begin` `end` 는 문자열 슬라이스 내의 바이트 위치 여야합니다.
    /// * `begin` `end` 는 UTF-8 시퀀스 경계에 있어야합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // 안전: 발신자는 `get_unchecked` 에 대한 안전 계약을 유지해야합니다.
        // 슬라이스는 `self` 가 안전한 참조이므로 참조 할 수 없습니다.
        // 반환 된 포인터는 `SliceIndex` 의 impls가 보장해야하기 때문에 안전합니다.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// 안전 검사를 우회하여 다른 문자열 조각에서 문자열 조각을 만듭니다.
    /// 이것은 일반적으로 권장되지 않으므로주의해서 사용하십시오!안전한 대안은 [`str`] 및 [`IndexMut`] 를 참조하십시오.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// 이 새로운 슬라이스는 `begin` 를 포함하지만 `end` 를 제외한 `begin` 에서 `end` 로 이동합니다.
    ///
    /// 대신 변경 불가능한 문자열 슬라이스를 얻으려면 [`slice_unchecked`] 메소드를 참조하십시오.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// 이 함수의 호출자는 세 가지 전제 조건을 충족해야합니다.
    ///
    /// * `begin` `end` 를 초과하지 않아야합니다.
    /// * `begin` `end` 는 문자열 슬라이스 내의 바이트 위치 여야합니다.
    /// * `begin` `end` 는 UTF-8 시퀀스 경계에 있어야합니다.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // 안전: 발신자는 `get_unchecked_mut` 에 대한 안전 계약을 유지해야합니다.
        // 슬라이스는 `self` 가 안전한 참조이므로 참조 할 수 없습니다.
        // 반환 된 포인터는 `SliceIndex` 의 impls가 보장해야하기 때문에 안전합니다.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// 인덱스에서 하나의 문자열 조각을 두 개로 나눕니다.
    ///
    /// 인수 `mid` 는 문자열 시작에서 바이트 오프셋이어야합니다.
    /// 또한 UTF-8 코드 포인트의 경계에 있어야합니다.
    ///
    /// 반환 된 두 조각은 문자열 조각의 시작에서 `mid` 로, 그리고 `mid` 에서 문자열 조각의 끝으로 이동합니다.
    ///
    /// 대신 변경 가능한 문자열 조각을 얻으려면 [`split_at_mut`] 메서드를 참조하십시오.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// `mid` 가 UTF-8 코드 포인트 경계에 있지 않거나 문자열 슬라이스의 마지막 코드 포인트의 끝을 지난 경우 Panics 입니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary는 인덱스가 [0, .len()]
        if self.is_char_boundary(mid) {
            // 안전: `mid` 가 문자 경계에 있는지 확인했습니다.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// 하나의 가변 문자열 슬라이스를 인덱스에서 두 개로 나눕니다.
    ///
    /// 인수 `mid` 는 문자열 시작에서 바이트 오프셋이어야합니다.
    /// 또한 UTF-8 코드 포인트의 경계에 있어야합니다.
    ///
    /// 반환 된 두 조각은 문자열 조각의 시작에서 `mid` 로, 그리고 `mid` 에서 문자열 조각의 끝으로 이동합니다.
    ///
    /// 대신 변경 불가능한 문자열 조각을 얻으려면 [`split_at`] 메서드를 참조하십시오.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// `mid` 가 UTF-8 코드 포인트 경계에 있지 않거나 문자열 슬라이스의 마지막 코드 포인트의 끝을 지난 경우 Panics 입니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary는 인덱스가 [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // 안전: `mid` 가 문자 경계에 있는지 확인했습니다.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// 문자열 조각의 [`char`]에 대한 반복자를 반환합니다.
    ///
    /// 문자열 슬라이스는 유효한 UTF-8 로 구성되므로 [`char`] 로 문자열 슬라이스를 반복 할 수 있습니다.
    /// 이 메서드는 이러한 반복자를 반환합니다.
    ///
    /// [`char`] 는 유니 코드 스칼라 값을 나타내며 'character' 가 무엇인지에 대한 귀하의 생각과 일치하지 않을 수 있음을 기억하는 것이 중요합니다.
    ///
    /// grapheme 클러스터에 대한 반복은 실제로 원하는 것일 수 있습니다.
    /// 이 기능은 Rust 의 표준 라이브러리에서 제공하지 않습니다. 대신 crates.io 를 확인하십시오.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// [`char`]는 문자에 대한 귀하의 직관과 일치하지 않을 수 있습니다.
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 'y̆' 아님
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// 문자열 조각의 [`char`]에 대한 반복기와 해당 위치를 반환합니다.
    ///
    /// 문자열 슬라이스는 유효한 UTF-8 로 구성되므로 [`char`] 로 문자열 슬라이스를 반복 할 수 있습니다.
    /// 이 메서드는 이러한 [`char`]의 반복자와 해당 바이트 위치를 모두 반환합니다.
    ///
    /// 반복기는 튜플을 생성합니다.위치가 첫 번째이고 [`char`] 가 두 번째입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// [`char`]는 문자에 대한 귀하의 직관과 일치하지 않을 수 있습니다.
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // 아님 (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // 여기에있는 3은 마지막 문자가 2 바이트를 차지했습니다.
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// 문자열 조각의 바이트에 대한 반복기입니다.
    ///
    /// 문자열 조각은 일련의 바이트로 구성되므로 문자열 조각을 바이트 단위로 반복 할 수 있습니다.
    /// 이 메서드는 이러한 반복자를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// 공백으로 문자열 조각을 분할합니다.
    ///
    /// 반환 된 반복자는 원래 문자열 조각의 하위 조각 인 문자열 조각을 임의의 양의 공백으로 구분하여 반환합니다.
    ///
    ///
    /// 'Whitespace' 유니 코드 파생 핵심 속성 `White_Space` 의 조건에 따라 정의됩니다.
    /// 대신 ASCII 공백으로 만 분할하려면 [`split_ascii_whitespace`] 를 사용하십시오.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// 모든 종류의 공백이 고려됩니다.
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ASCII 공백으로 문자열 슬라이스를 분할합니다.
    ///
    /// 반환 된 반복기는 원래 문자열 조각의 하위 조각 인 문자열 조각을 임의의 양의 ASCII 공백으로 구분하여 반환합니다.
    ///
    ///
    /// 대신 유니 코드 `Whitespace` 로 분할하려면 [`split_whitespace`] 를 사용하십시오.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// 모든 종류의 ASCII 공백이 고려됩니다.
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// 문자열 조각으로 문자열 행에 대한 반복기입니다.
    ///
    /// 줄은 줄 바꿈 (`\n`) 또는 줄 바꿈 (`\r\n`) 가있는 캐리지 리턴으로 끝납니다.
    ///
    /// 마지막 줄 끝은 선택 사항입니다.
    /// 마지막 줄 끝으로 끝나는 문자열은 마지막 줄 끝이없는 다른 동일한 문자열과 동일한 줄을 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// 마지막 줄 끝은 필요하지 않습니다.
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// 문자열 행에 대한 반복기입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 로 인코딩 된 문자열에 대해 `u16` 의 반복기를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// 주어진 패턴이이 문자열 조각의 하위 조각과 일치하면 `true` 를 반환합니다.
    ///
    /// 그렇지 않은 경우 `false` 를 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// 주어진 패턴이이 문자열 조각의 접두사와 일치하면 `true` 를 반환합니다.
    ///
    /// 그렇지 않은 경우 `false` 를 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// 주어진 패턴이이 문자열 조각의 접미사와 일치하면 `true` 를 반환합니다.
    ///
    /// 그렇지 않은 경우 `false` 를 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// 패턴과 일치하는이 문자열 슬라이스의 첫 번째 문자의 바이트 인덱스를 리턴합니다.
    ///
    /// 패턴이 일치하지 않으면 [`None`] 를 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// 점없는 스타일과 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// 패턴을 찾지 못함 :
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// 이 문자열 조각에서 패턴의 가장 오른쪽 일치 항목의 첫 번째 문자에 대한 바이트 인덱스를 반환합니다.
    ///
    /// 패턴이 일치하지 않으면 [`None`] 를 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// 클로저가있는 더 복잡한 패턴 :
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// 패턴을 찾지 못함 :
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// 패턴과 일치하는 문자로 구분 된이 문자열 조각의 하위 문자열에 대한 반복기입니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 패턴이 역방향 검색을 허용하고 forward/reverse 검색이 동일한 요소를 생성하는 경우 반환 된 반복자는 [`DoubleEndedIterator`] 가됩니다.
    /// 예를 들어 [`char`] 에는 해당되지만 `&str` 에는 해당되지 않습니다.
    ///
    /// 패턴이 역방향 검색을 허용하지만 그 결과가 정방향 검색과 다를 수있는 경우 [`rsplit`] 방법을 사용할 수 있습니다.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// 패턴이 문자 조각 인 경우 문자가 나타날 때마다 분할합니다.
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// 문자열에 연속 된 구분 기호가 여러 개 포함되어 있으면 출력에 빈 문자열이 표시됩니다.
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// 연속 구분 기호는 빈 문자열로 구분됩니다.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// 문자열의 시작 또는 끝에있는 구분 기호는 빈 문자열로 인접합니다.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// 빈 문자열이 구분 기호로 사용되면 문자열의 시작과 끝과 함께 문자열의 모든 문자를 구분합니다.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// 연속 구분 기호는 공백이 구분 기호로 사용될 때 예상치 못한 동작을 유발할 수 있습니다.이 코드는 정확합니다.
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ 는 다음을 제공합니다.
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// 이 동작에는 [`split_whitespace`] 를 사용하십시오.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// 패턴과 일치하는 문자로 구분 된이 문자열 조각의 하위 문자열에 대한 반복기입니다.
    /// `split_inclusive` 가 일치하는 부분을 부분 문자열의 종결 자로 남겨둔다는 점에서 `split` 에 의해 생성 된 반복자와 다릅니다.
    ///
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// 문자열의 마지막 요소가 일치하면 해당 요소는 이전 하위 문자열의 종결 자로 간주됩니다.
    /// 해당 하위 문자열은 반복자가 반환하는 마지막 항목이됩니다.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// 주어진 문자열 조각의 하위 문자열에 대한 반복기이며 패턴과 일치하는 문자로 구분되고 역순으로 산출됩니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 반환 된 반복자는 패턴이 역방향 검색을 지원해야하며 forward/reverse 검색이 동일한 요소를 생성하는 경우 [`DoubleEndedIterator`] 가됩니다.
    ///
    ///
    /// 앞에서 반복하는 경우 [`split`] 방법을 사용할 수 있습니다.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// 패턴과 일치하는 문자로 구분 된 지정된 문자열 조각의 하위 문자열에 대한 반복기입니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// 비어있는 경우 후행 하위 문자열을 건너 뛴다는 점을 제외하면 [`split`] 와 동일합니다.
    ///
    /// [`split`]: str::split
    ///
    /// 이 방법은 패턴 별 _separated_ 가 아닌 _terminated_ 인 문자열 데이터에 사용할 수 있습니다.
    ///
    /// # 반복기 동작
    ///
    /// 패턴이 역방향 검색을 허용하고 forward/reverse 검색이 동일한 요소를 생성하는 경우 반환 된 반복자는 [`DoubleEndedIterator`] 가됩니다.
    /// 예를 들어 [`char`] 에는 해당되지만 `&str` 에는 해당되지 않습니다.
    ///
    /// 패턴이 역방향 검색을 허용하지만 그 결과가 정방향 검색과 다를 수있는 경우 [`rsplit_terminator`] 방법을 사용할 수 있습니다.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` 의 하위 문자열에 대한 반복기이며 패턴과 일치하고 역순으로 생성되는 문자로 구분됩니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// 비어있는 경우 후행 하위 문자열을 건너 뛴다는 점을 제외하면 [`split`] 와 동일합니다.
    ///
    /// [`split`]: str::split
    ///
    /// 이 방법은 패턴 별 _separated_ 가 아닌 _terminated_ 인 문자열 데이터에 사용할 수 있습니다.
    ///
    /// # 반복기 동작
    ///
    /// 반환 된 반복자는 패턴이 역방향 검색을 지원해야하며 forward/reverse 검색이 동일한 요소를 생성하면 이중 종료됩니다.
    ///
    ///
    /// 앞에서 반복하는 경우 [`split_terminator`] 방법을 사용할 수 있습니다.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// 패턴으로 구분 된 지정된 문자열 조각의 하위 문자열에 대한 반복기이며 최대 `n` 항목을 반환하도록 제한됩니다.
    ///
    /// `n` 부분 문자열이 반환되면 마지막 부분 문자열 (`n '번째 부분 문자열)에 나머지 문자열이 포함됩니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 반환 된 반복자는 지원하기에 효율적이지 않기 때문에 이중 종료되지 않습니다.
    ///
    /// 패턴이 역방향 검색을 허용하는 경우 [`rsplitn`] 방법을 사용할 수 있습니다.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// 문자열 끝에서 시작하여 패턴으로 구분 된이 문자열 조각의 하위 문자열에 대한 반복기이며 최대 `n` 항목을 반환하도록 제한됩니다.
    ///
    ///
    /// `n` 부분 문자열이 반환되면 마지막 부분 문자열 (`n '번째 부분 문자열)에 나머지 문자열이 포함됩니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 반환 된 반복자는 지원하기에 효율적이지 않기 때문에 이중 종료되지 않습니다.
    ///
    /// 전면에서 분할하려면 [`splitn`] 방법을 사용할 수 있습니다.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// 지정된 구분 기호가 처음 나타날 때 문자열을 분할하고 구분 기호 앞에 접두사를 반환하고 구분 기호 뒤에 접미사를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// 지정된 구분 기호의 마지막 발생에서 문자열을 분할하고 구분 기호 앞에 접두사를 반환하고 구분 기호 뒤에 접미사를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// 주어진 문자열 조각 내에서 패턴의 비 연속 일치에 대한 반복기입니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 패턴이 역방향 검색을 허용하고 forward/reverse 검색이 동일한 요소를 생성하는 경우 반환 된 반복자는 [`DoubleEndedIterator`] 가됩니다.
    /// 예를 들어 [`char`] 에는 해당되지만 `&str` 에는 해당되지 않습니다.
    ///
    /// 패턴이 역방향 검색을 허용하지만 그 결과가 정방향 검색과 다를 수있는 경우 [`rmatches`] 방법을 사용할 수 있습니다.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// 역순으로 생성 된이 문자열 조각 내에서 패턴의 비 연속 일치에 대한 반복기입니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 반환 된 반복자는 패턴이 역방향 검색을 지원해야하며 forward/reverse 검색이 동일한 요소를 생성하는 경우 [`DoubleEndedIterator`] 가됩니다.
    ///
    ///
    /// 앞에서 반복하는 경우 [`matches`] 방법을 사용할 수 있습니다.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// 이 문자열 조각 내에서 패턴의 비 연속 일치에 대한 반복기 및 일치가 시작되는 인덱스입니다.
    ///
    /// `self` 내에서 겹치는 `pat` 일치 항목의 경우 첫 번째 일치 항목에 해당하는 색인 만 반환됩니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 패턴이 역방향 검색을 허용하고 forward/reverse 검색이 동일한 요소를 생성하는 경우 반환 된 반복자는 [`DoubleEndedIterator`] 가됩니다.
    /// 예를 들어 [`char`] 에는 해당되지만 `&str` 에는 해당되지 않습니다.
    ///
    /// 패턴이 역방향 검색을 허용하지만 그 결과가 정방향 검색과 다를 수있는 경우 [`rmatch_indices`] 방법을 사용할 수 있습니다.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // 첫 번째 `aba` 만
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` 내에서 패턴의 비 연속 일치에 대한 반복기이며 일치 색인과 함께 역순으로 산출됩니다.
    ///
    /// `self` 내에서 겹치는 `pat` 일치 항목의 경우 마지막 일치 항목에 해당하는 인덱스 만 반환됩니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 반복기 동작
    ///
    /// 반환 된 반복자는 패턴이 역방향 검색을 지원해야하며 forward/reverse 검색이 동일한 요소를 생성하는 경우 [`DoubleEndedIterator`] 가됩니다.
    ///
    ///
    /// 앞에서 반복하는 경우 [`match_indices`] 방법을 사용할 수 있습니다.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // 마지막 `aba` 만
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// 선행 및 후행 공백이 제거 된 문자열 조각을 반환합니다.
    ///
    /// 'Whitespace' 유니 코드 파생 핵심 속성 `White_Space` 의 조건에 따라 정의됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// 선행 공백이 제거 된 문자열 조각을 반환합니다.
    ///
    /// 'Whitespace' 유니 코드 파생 핵심 속성 `White_Space` 의 조건에 따라 정의됩니다.
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// `start` 이 문맥에서 해당 바이트 문자열의 첫 번째 위치를 의미합니다.영어 또는 러시아어와 같은 왼쪽에서 오른쪽으로 쓰는 언어의 경우 왼쪽이되고 아랍어 나 히브리어와 같은 오른쪽에서 왼쪽으로 쓰는 언어의 경우 오른쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// 후행 공백이 제거 된 문자열 조각을 반환합니다.
    ///
    /// 'Whitespace' 유니 코드 파생 핵심 속성 `White_Space` 의 조건에 따라 정의됩니다.
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// `end` 이 문맥에서 해당 바이트 문자열의 마지막 위치를 의미합니다.영어 또는 러시아어와 같은 왼쪽에서 오른쪽으로 쓰는 언어의 경우 오른쪽이되고 아랍어 나 히브리어와 같은 오른쪽에서 왼쪽으로 쓰는 언어의 경우 왼쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// 선행 공백이 제거 된 문자열 조각을 반환합니다.
    ///
    /// 'Whitespace' 유니 코드 파생 핵심 속성 `White_Space` 의 조건에 따라 정의됩니다.
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// 'Left' 이 문맥에서 해당 바이트 문자열의 첫 번째 위치를 의미합니다.아랍어 나 히브리어와 같이 '왼쪽에서 오른쪽으로'가 아닌 '오른쪽에서 왼쪽으로'언어의 경우 왼쪽이 아닌 _right_ 쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// 후행 공백이 제거 된 문자열 조각을 반환합니다.
    ///
    /// 'Whitespace' 유니 코드 파생 핵심 속성 `White_Space` 의 조건에 따라 정의됩니다.
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// 'Right' 이 문맥에서 해당 바이트 문자열의 마지막 위치를 의미합니다.아랍어 나 히브리어와 같이 '왼쪽에서 오른쪽으로'가 아닌 '오른쪽에서 왼쪽으로'언어의 경우 오른쪽이 아닌 _left_ 쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// 패턴과 일치하는 모든 접두사와 접미사가 반복적으로 제거 된 문자열 조각을 반환합니다.
    ///
    /// [pattern] 는 [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // 가장 먼저 알려진 일치를 기억하십시오. 아래에서 수정하십시오.
            // 마지막 경기가 다릅니다
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // 안전: `Searcher` 는 유효한 인덱스를 반환하는 것으로 알려져 있습니다.
        unsafe { self.get_unchecked(i..j) }
    }

    /// 패턴과 일치하는 모든 접두사가 반복적으로 제거 된 문자열 조각을 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// `start` 이 문맥에서 해당 바이트 문자열의 첫 번째 위치를 의미합니다.영어 또는 러시아어와 같은 왼쪽에서 오른쪽으로 쓰는 언어의 경우 왼쪽이되고 아랍어 나 히브리어와 같은 오른쪽에서 왼쪽으로 쓰는 언어의 경우 오른쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // 안전: `Searcher` 는 유효한 인덱스를 반환하는 것으로 알려져 있습니다.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// 접두사가 제거 된 문자열 조각을 반환합니다.
    ///
    /// 문자열이 `prefix` 패턴으로 시작하면 `Some` 로 래핑 된 접두사 뒤의 하위 문자열을 반환합니다.
    /// `trim_start_matches` 와 달리이 방법은 접두사를 정확히 한 번 제거합니다.
    ///
    /// 문자열이 `prefix` 로 시작하지 않으면 `None` 를 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// 접미사가 제거 된 문자열 조각을 반환합니다.
    ///
    /// 문자열이 `suffix` 패턴으로 끝나는 경우 `Some` 로 래핑 된 접미사 앞의 하위 문자열을 반환합니다.
    /// `trim_end_matches` 와 달리이 방법은 접미사를 정확히 한 번 제거합니다.
    ///
    /// 문자열이 `suffix` 로 끝나지 않으면 `None` 를 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// 패턴과 일치하는 모든 접미사가 반복적으로 제거 된 문자열 조각을 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// `end` 이 문맥에서 해당 바이트 문자열의 마지막 위치를 의미합니다.영어 또는 러시아어와 같은 왼쪽에서 오른쪽으로 쓰는 언어의 경우 오른쪽이되고 아랍어 나 히브리어와 같은 오른쪽에서 왼쪽으로 쓰는 언어의 경우 왼쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // 안전: `Searcher` 는 유효한 인덱스를 반환하는 것으로 알려져 있습니다.
        unsafe { self.get_unchecked(0..j) }
    }

    /// 패턴과 일치하는 모든 접두사가 반복적으로 제거 된 문자열 조각을 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// 'Left' 이 문맥에서 해당 바이트 문자열의 첫 번째 위치를 의미합니다.아랍어 나 히브리어와 같이 '왼쪽에서 오른쪽으로'가 아닌 '오른쪽에서 왼쪽으로'언어의 경우 왼쪽이 아닌 _right_ 쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// 패턴과 일치하는 모든 접미사가 반복적으로 제거 된 문자열 조각을 반환합니다.
    ///
    /// [pattern] 는 `&str`, [`char`], [`char`]의 조각 또는 문자가 일치하는지 여부를 결정하는 함수 또는 클로저 일 수 있습니다.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 텍스트 방향
    ///
    /// 문자열은 일련의 바이트입니다.
    /// 'Right' 이 문맥에서 해당 바이트 문자열의 마지막 위치를 의미합니다.아랍어 나 히브리어와 같이 '왼쪽에서 오른쪽으로'가 아닌 '오른쪽에서 왼쪽으로'언어의 경우 오른쪽이 아닌 _left_ 쪽이됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 간단한 패턴 :
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// 클로저를 사용하는 더 복잡한 패턴 :
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// 이 문자열 조각을 다른 유형으로 구문 분석합니다.
    ///
    /// `parse` 는 매우 일반적이기 때문에 유형 추론에 문제가 발생할 수 있습니다.
    /// 따라서 `parse` 는 'turbofish' 라는 애칭으로 알려진 구문을 볼 수있는 몇 안되는 경우 중 하나입니다. `::<>`.
    ///
    /// 이는 추론 알고리즘이 파싱하려는 유형을 구체적으로 이해하는 데 도움이됩니다.
    ///
    /// `parse` [`FromStr`] trait 를 구현하는 모든 유형으로 구문 분석 할 수 있습니다.
    ///

    /// # Errors
    ///
    /// 이 문자열 조각을 원하는 유형으로 구문 분석 할 수없는 경우 [`Err`] 를 반환합니다.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// 기본 사용법
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// `four` 주석 대신 'turbofish' 사용 :
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// 파싱 실패 :
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// 이 문자열의 모든 문자가 ASCII 범위 내에 있는지 확인합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // 여기서 각 바이트를 문자로 취급 할 수 있습니다. 모든 멀티 바이트 문자는 ASCII 범위에 속하지 않는 바이트로 시작하므로 이미 여기서 중지합니다.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// 두 문자열이 ASCII 대소 문자를 구분하지 않는 일치인지 확인합니다.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 와 동일하지만 임시를 할당하고 복사하지 않습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// 이 문자열을 해당 위치에 해당하는 ASCII 대문자로 변환합니다.
    ///
    /// ASCII 문자 'a'-'z' 는 'A'-'Z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 기존 값을 수정하지 않고 새 대문자 값을 반환하려면 [`to_ascii_uppercase()`] 를 사용합니다.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // 안전: 동일한 레이아웃으로 두 가지 유형을 변환하므로 안전합니다.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// 이 문자열을 해당 위치에있는 ASCII 소문자로 변환합니다.
    ///
    /// ASCII 문자 'A'-'Z' 는 'a'-'z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 기존 값을 수정하지 않고 새 소문자 값을 반환하려면 [`to_ascii_lowercase()`] 를 사용합니다.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // 안전: 동일한 레이아웃으로 두 가지 유형을 변환하므로 안전합니다.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// [`char::escape_debug`] 로 `self` 의 각 문자를 이스케이프하는 반복기를 반환합니다.
    ///
    ///
    /// Note: 문자열을 시작하는 확장 된 자소 코드 점 만 이스케이프됩니다.
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// [`char::escape_default`] 로 `self` 의 각 문자를 이스케이프하는 반복기를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// [`char::escape_unicode`] 로 `self` 의 각 문자를 이스케이프하는 반복기를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 반복자로서 :
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` 직접 사용 :
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// 둘 다 다음과 같습니다.
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` 사용 :
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// 빈 str을 만듭니다.
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// 비어있는 가변 str을 만듭니다.
    #[inline]
    fn default() -> Self {
        // 안전: 빈 문자열은 유효한 UTF-8 입니다.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// 이름과 복제가 가능한 fn 유형
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // 안전: 안전하지 않음
        unsafe { from_utf8_unchecked(bytes) }
    };
}