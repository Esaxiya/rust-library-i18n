//! 16 비트 부호없는 정수 유형에 대한 상수입니다.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! 새 코드는 원시 유형에서 직접 연관된 상수를 사용해야합니다.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }