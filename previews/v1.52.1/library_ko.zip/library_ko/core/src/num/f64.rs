//! `f64` 배정 밀도 부동 소수점 유형에 특정한 상수입니다.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! `consts` 하위 모듈에는 수학적으로 의미있는 숫자가 제공됩니다.
//!
//! 이 모듈에 직접 정의 된 상수 (`consts` 하위 모듈에 정의 된 것과는 다름)의 경우 새 코드는 대신 `f64` 유형에 직접 정의 된 관련 상수를 사용해야합니다.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64` 내부 표현의 기수 또는 밑입니다.
/// 대신 [`f64::RADIX`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // 의도 된 방법
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// 2 진법의 유효 자릿수입니다.
/// 대신 [`f64::MANTISSA_DIGITS`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // 의도 된 방법
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// 10 진수의 대략적인 유효 자릿수입니다.
/// 대신 [`f64::DIGITS`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // 의도 된 방법
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] `f64` 의 값입니다.
/// 대신 [`f64::EPSILON`] 를 사용하십시오.
///
/// 이것은 `1.0` 와 다음으로 큰 표현 가능한 숫자의 차이입니다.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // 의도 된 방법
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// 최소 유한 `f64` 값.
/// 대신 [`f64::MIN`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // 의도 된 방법
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// 가장 작은 양의 정상 `f64` 값.
/// 대신 [`f64::MIN_POSITIVE`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // 의도 된 방법
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// 최대 유한 `f64` 값입니다.
/// 대신 [`f64::MAX`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // 의도 된 방법
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// 2 지수의 가능한 최소 정규 거듭 제곱보다 큰 값입니다.
/// 대신 [`f64::MIN_EXP`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // 의도 된 방법
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// 2 지수의 최대 가능한 거듭 제곱입니다.
/// 대신 [`f64::MAX_EXP`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // 의도 된 방법
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// 10 지수의 가능한 최소 정규 거듭 제곱입니다.
/// 대신 [`f64::MIN_10_EXP`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // 의도 된 방법
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// 10 지수의 최대 가능한 거듭 제곱입니다.
/// 대신 [`f64::MAX_10_EXP`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // 의도 된 방법
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// 숫자 (NaN) 가 아닙니다.
/// 대신 [`f64::NAN`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // 의도 된 방법
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// 대신 [`f64::INFINITY`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // 의도 된 방법
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// 음의 무한대 (−∞).
/// 대신 [`f64::NEG_INFINITY`] 를 사용하십시오.
///
/// # Examples
///
/// ```rust
/// // 사용되지 않는 방법
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // 의도 된 방법
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// 기본 수학 상수.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath의 수학 상수로 대체하십시오.

    /// 아르키메데스 상수 (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// 전체 원 상수 (τ)
    ///
    /// 2π와 같습니다.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// 오일러 번호 (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64` 내부 표현의 기수 또는 밑입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// 2 진법의 유효 자릿수입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// 10 진수의 대략적인 유효 자릿수입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] `f64` 의 값입니다.
    ///
    /// 이것은 `1.0` 와 다음으로 큰 표현 가능한 숫자의 차이입니다.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// 최소 유한 `f64` 값.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// 가장 작은 양의 정상 `f64` 값.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// 최대 유한 `f64` 값입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// 2 지수의 가능한 최소 정규 거듭 제곱보다 큰 값입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// 2 지수의 최대 가능한 거듭 제곱입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// 10 지수의 가능한 최소 정규 거듭 제곱입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// 10 지수의 최대 가능한 거듭 제곱입니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// 숫자 (NaN) 가 아닙니다.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// 음의 무한대 (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// 이 값이 `NaN` 이면 `true` 를 반환합니다.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` 는 이식성에 대한 우려로 인해 libcore에서 공개적으로 사용할 수 없으므로이 구현은 내부적으로 사적으로 사용됩니다.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// 이 값이 양의 무한대 또는 음의 무한대이면 `true` 를 반환하고 그렇지 않으면 `false` 를 반환합니다.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// 이 숫자가 무한도 아니고 `NaN` 도 아닌 경우 `true` 를 반환합니다.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN을 별도로 처리 할 필요가 없습니다. self가 NaN이면 비교는 원하는대로 정확히 사실이 아닙니다.
        //
        self.abs_private() < Self::INFINITY
    }

    /// 숫자가 [subnormal] 이면 `true` 를 반환합니다.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // `0` 와 `min` 사이의 값은 비정상입니다.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// 숫자가 0, 무한, [subnormal] 또는 `NaN` 가 아닌 경우 `true` 를 반환합니다.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // `0` 와 `min` 사이의 값은 비정상입니다.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// 숫자의 부동 소수점 범주를 반환합니다.
    /// 하나의 속성 만 테스트 할 경우 일반적으로 특정 조건자를 대신 사용하는 것이 더 빠릅니다.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `self` 에 `+0.0`, 양의 부호 비트 및 양의 무한대가있는`NaN`을 포함하여 양의 부호가있는 경우 `true` 를 반환합니다.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// `self` 에 `-0.0`, 음수 부호 비트 및 음의 무한대가있는`NaN`을 포함하여 음수 부호가 있으면 `true` 를 반환합니다.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// 숫자의 역수 (inverse) 를 취합니다. `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// 라디안을 각도로 변환합니다.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // 여기서 나누기는 180/π의 실제 값에 대해 올바르게 반올림됩니다.
        // (이것은 올바르게 반올림 된 결과를 보장하기 위해 상수를 사용해야하는 f32 와 다릅니다.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// 각도를 라디안으로 변환합니다.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// 두 숫자 중 최대 값을 반환합니다.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// 인수 중 하나가 NaN이면 다른 인수가 반환됩니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// 두 숫자 중 최소값을 반환합니다.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// 인수 중 하나가 NaN이면 다른 인수가 반환됩니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// 값이 유한하고 해당 유형에 적합하다고 가정하여 0으로 반올림하고 모든 기본 정수 유형으로 변환합니다.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// 값은 다음과 같아야합니다.
    ///
    /// * `NaN` 가 아님
    /// * 무한하지 않음
    /// * 소수 부분을 자른 후 반환 유형 `Int` 로 표현 가능해야합니다.
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // 안전: 발신자는 `FloatToInt::to_int_unchecked` 에 대한 안전 계약을 유지해야합니다.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u64` 로의 원시 변환.
    ///
    /// 이것은 현재 모든 플랫폼에서 `transmute::<f64, u64>(self)` 와 동일합니다.
    ///
    /// 이 작업의 이식성에 대한 논의는 `from_bits` 를 참조하십시오 (거의 문제 없음).
    ///
    /// 이 함수는 비트 값이 아닌 *숫자* 값을 보존하려고하는 `as` 캐스팅과는 다릅니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() 캐스팅이 아닙니다!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // 안전: `u64` 는 평범한 오래된 데이터 유형이므로 항상 변환 할 수 있습니다.
        unsafe { mem::transmute(self) }
    }

    /// `u64` 에서 원시 변환.
    ///
    /// 이것은 현재 모든 플랫폼에서 `transmute::<u64, f64>(v)` 와 동일합니다.
    /// 이것은 두 가지 이유로 믿을 수 없을 정도로 이식성이있는 것으로 밝혀졌습니다.
    ///
    /// * Floats와 Ints는 지원되는 모든 플랫폼에서 동일한 엔디안을 갖습니다.
    /// * IEEE-754는 float의 비트 레이아웃을 매우 정확하게 지정합니다.
    ///
    /// 그러나 한 가지주의 사항이 있습니다. 2008 년 버전의 IEEE-754 이전에는 NaN 신호 비트를 해석하는 방법이 실제로 지정되지 않았습니다.
    /// 대부분의 플랫폼 (특히 x86 및 ARM)은 2008 년에 최종적으로 표준화 된 해석을 선택했지만 일부는 그렇지 않았습니다 (특히 MIPS).
    /// 결과적으로 MIPS 의 모든 신호 NaN은 x86 의 조용한 NaN이며 그 반대의 경우도 마찬가지입니다.
    ///
    /// 이 구현은 신호 성을 교차 플랫폼에 보존하려고하기보다는 정확한 비트를 보존하는 것을 선호합니다.
    /// 즉,이 방법의 결과가 네트워크를 통해 x86 시스템에서 MIPS 시스템으로 전송 되더라도 NaN으로 인코딩 된 모든 페이로드가 보존됩니다.
    ///
    ///
    /// 이 방법의 결과가이를 생성 한 동일한 아키텍처에 의해서만 조작되는 경우 이식성 문제가 없습니다.
    ///
    /// 입력이 NaN이 아니면 이식성 문제가 없습니다.
    ///
    /// 시그널링에 관심이 없다면 (가능성이 매우 높음) 이식성 문제가 없습니다.
    ///
    /// 이 함수는 비트 값이 아닌 *숫자* 값을 보존하려고하는 `as` 캐스팅과는 다릅니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // 안전: `u64` 는 평범한 오래된 데이터 유형이므로 항상 변환 할 수 있습니다.
        // sNaN의 안전 문제가 과장된 것으로 밝혀졌습니다!만세!
        unsafe { mem::transmute(v) }
    }

    /// 이 부동 소수점 숫자의 메모리 표현을 빅 엔디안 (network) 바이트 순서의 바이트 배열로 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// 이 부동 소수점 숫자의 메모리 표현을 리틀 엔디안 바이트 순서의 바이트 배열로 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// 이 부동 소수점 숫자의 메모리 표현을 기본 바이트 순서의 바이트 배열로 반환합니다.
    ///
    /// 대상 플랫폼의 네이티브 엔디안이 사용되므로 이식 가능한 코드는 [`to_be_bytes`] 또는 [`to_le_bytes`] 를 대신 사용해야합니다.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// 이 부동 소수점 숫자의 메모리 표현을 기본 바이트 순서의 바이트 배열로 반환합니다.
    ///
    ///
    /// [`to_ne_bytes`] 가능할 때마다 이것보다 선호되어야합니다.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // 안전: `f64` 는 평범한 오래된 데이터 유형이므로 항상 변환 할 수 있습니다.
        unsafe { &*(self as *const Self as *const _) }
    }

    /// 빅 엔디안의 바이트 배열로 표현에서 부동 소수점 값을 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// 리틀 엔디안의 바이트 배열로 표현에서 부동 소수점 값을 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// 네이티브 엔디안의 바이트 배열로 표현에서 부동 소수점 값을 만듭니다.
    ///
    /// 대상 플랫폼의 네이티브 엔디안이 사용됨에 따라 이식 가능한 코드는 적절하게 [`from_be_bytes`] 또는 [`from_le_bytes`] 를 대신 사용하려고합니다.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// self 값과 다른 값 사이의 순서를 반환합니다.
    /// 부동 소수점 숫자 간의 표준 부분 비교와 달리이 비교는 항상 IEEE 754 (2008 개정) 부동 소수점 표준에 정의 된 totalOrder 술어에 따라 순서를 생성합니다.
    /// 값은 다음 순서로 정렬됩니다.
    /// - 네거티브 조용한 NaN
    /// - 음성 신호 NaN
    /// - 음의 무한대
    /// - 음수
    /// - 음의 비정규 숫자
    /// - 음의 제로
    /// - 양의 제로
    /// - 양의 비정규 숫자
    /// - 양수
    /// - 양의 무한대
    /// - 양성 신호 NaN
    /// - 긍정적 인 조용한 NaN
    ///
    /// 이 함수는 `f64` 의 [`PartialOrd`] 및 [`PartialEq`] 구현과 항상 일치하지는 않습니다.특히, 그들은 음수와 양수 0을 같은 것으로 간주하지만 `total_cmp` 는 그렇지 않습니다.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // 음수의 경우 부호를 제외한 모든 비트를 뒤집어 2의 보수 정수와 유사한 레이아웃을 얻습니다.
        //
        // 왜 이것이 작동합니까?IEEE 754 부동 소수점은 세 가지 필드로 구성됩니다.
        // 부호 비트, 지수 및 가수.지수 및 가수 필드 세트는 전체적으로 비트 순서가 크기가 정의 된 숫자 크기와 같다는 속성을 갖습니다.
        // 크기는 일반적으로 NaN 값에 정의되지 않지만 IEEE 754 totalOrder는 비트 순서를 따르도록 NaN 값도 정의합니다.이것은 문서 주석에 설명 된 순서로 이어집니다.
        // 그러나 크기 표현은 음수와 양수에 대해 동일하며 부호 비트 만 다릅니다.
        // 부동 소수점을 부호있는 정수로 쉽게 비교하려면 음수의 경우 지수 및 가수 비트를 뒤집어 야합니다.
        // 숫자를 "two's complement" 형식으로 효과적으로 변환합니다.
        //
        // 뒤집기를 수행하기 위해 마스크를 구성하고 이에 대해 XOR합니다.
        // 음의 부호가있는 값에서 분기없이 "all-ones except for the sign bit" 마스크를 계산합니다. 오른쪽 시프트는 정수를 부호 확장하므로 부호 비트로 마스크를 "fill" 한 다음 부호없는 것으로 변환하여 0 비트를 하나 더 푸시합니다.
        //
        // 양수 값에서 마스크는 모두 0이므로 작동하지 않습니다.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// NaN이 아닌 경우 값을 특정 간격으로 제한합니다.
    ///
    /// `self` 가 `max` 보다 크면 `max` 를 반환하고 `self` 가 `min` 보다 작 으면 `min` 를 반환합니다.
    /// 그렇지 않으면 `self` 를 반환합니다.
    ///
    /// 이 함수는 초기 값이 NaN 인 경우에도 NaN을 반환합니다.
    ///
    /// # Panics
    ///
    /// `min > max`, `min` 가 NaN 또는 `max` 가 NaN 인 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}