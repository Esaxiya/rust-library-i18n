//! "부동 소수점 숫자를 빠르고 정확하게 인쇄"[^ 1]의 그림 3에 대한 거의 직접적이지만 약간 최적화 된 Rust 변환입니다.
//!
//!
//! [^1]: Burger, RG 및 Dybvig, RK 1996. 부동 소수점 숫자 인쇄
//!   빠르고 정확하게.SIGPLAN 아닙니다.31, 5 (1996 년 5 월), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n)에 대해 미리 계산 된`Digit` 배열
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// `x < 16 * scale` 일 때만 사용할 수 있습니다.`scaleN` 는 `scale.mul_small(N)` 여야합니다.
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Dragon의 최단 모드 구현입니다.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // 형식화 할 숫자 `v` 는 다음과 같이 알려져 있습니다.
    // - `mant * 2^exp` 와 같음;
    // - 원래 유형에서 `(mant - 2 *minus)* 2^exp` 가 앞에옵니다.과
    // - 원래 유형의 `(mant + 2 *plus)* 2^exp` 가 뒤 따릅니다.
    //
    // 당연히 `minus` 와 `plus` 는 0이 될 수 없습니다.(무한의 경우 범위를 벗어난 값을 사용합니다.) 또한 하나 이상의 숫자가 생성된다고 가정합니다. 즉, `mant` 도 0이 될 수 없습니다.
    //
    // 이것은 또한 `low = (mant - minus)*2^exp` 와 `high = (mant + plus)* 2^exp` 사이의 숫자가 원래 가수가 짝수 일 때 포함 된 경계 (즉, `!mant_was_odd`)와 함께 정확한 부동 소수점 숫자로 매핑된다는 것을 의미합니다.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` 입니다.
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` 를 만족하는 원래 입력에서 `k_0` 를 추정합니다.
    // `10^(k-1) < high <= 10^k` 를 만족하는 타이트 바운드 `k` 는 나중에 계산됩니다.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` 를 분수 형식으로 변환하여 다음을 수행합니다.
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` 를 `10^k` 로 나눕니다.이제 `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (또는 `>=`) 일 때 수정.
    // 대신 초기 곱셈을 건너 뛸 수 있으므로 실제로 `scale` 를 수정하지 않습니다.
    // 이제 `scale < mant + plus <= scale * 10` 이고 숫자를 생성 할 준비가되었습니다.
    //
    // `scale - plus < mant < scale` 일 때 `d[0]` 는 0이 될 수 있습니다.
    // 이 경우 반올림 조건 (아래 `up`)이 즉시 트리거됩니다.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` 를 10으로 조정하는 것과 동일
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // 숫자 생성을위한 캐시 `(2, 4, 8) * scale`.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` 는 지금까지 생성 된 숫자입니다.
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (따라서 `mant / scale < 10`) 여기서 `d[i..j]` 는`d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // 한 자리 생성 : `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // 이것은 수정 된 Dragon 알고리즘에 대한 간략한 설명입니다.
        // 편의를 위해 많은 중간 파생 및 완전성 인수가 생략되었습니다.
        //
        // `n` 를 업데이트 했으므로 수정 된 불변으로 시작합니다.
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` 가 `low` 와 `high` 사이의 가장 짧은 표현이라고 가정합니다. 즉, `d[0..n-1]` 는 다음 두 가지를 모두 충족하지만 `d[0..n-2]` 는 그렇지 않습니다.
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: `v` 로 반올림 된 숫자);과
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (마지막 숫자가 정확합니다).
        //
        // 두 번째 조건은 `2 * mant <= scale` 로 단순화됩니다.
        // `mant`, `low` 및 `high` 의 관점에서 불변을 해결하면 첫 번째 조건의 더 간단한 버전이 생성됩니다. `-plus < mant < minus`.
        // `-plus < 0 <= mant` 이후 `mant < minus` 및 `2 * mant <= scale` 일 때 가장 짧은 표현이 정확합니다.
        // (원래 가수가 짝수이면 전자는 `mant <= minus` 가됩니다.)
        //
        // 두 번째 값이 유지되지 않으면 (`2 * mant> scale`) 마지막 숫자를 늘려야합니다.
        // 이것은 그 조건을 복원하기에 충분합니다. 우리는 이미 숫자 생성이 `0 <= v / 10^(k-n) - d[0..n-1] < 1` 를 보장한다는 것을 알고 있습니다.
        // 이 경우 첫 번째 조건은 `-plus < mant - scale < minus` 가됩니다.
        // `mant < scale` 이후 `scale < mant + plus` 가 있습니다.
        // (다시 말하지만, 이것은 원래 가수가 짝수 일 때 `scale <= mant + plus` 가됩니다.)
        //
        // 요컨대 :
        // - `mant < minus` (또는 `<=`) 일 때 `down` (숫자 그대로 유지)를 중지하고 반올림합니다.
        // - `scale < mant + plus` (또는 `<=`) 일 때 `up` (마지막 숫자 증가)를 중지하고 반올림합니다.
        // - 그렇지 않으면 계속 생성하십시오.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // 우리는 가장 짧은 표현을 가지고 있습니다.

        // 불변성을 복원하십시오.
        // 이렇게하면 알고리즘이 항상 종료됩니다. `minus` 및 `plus` 는 항상 증가하지만 `mant` 는 `scale` 모듈로 잘리고 `scale` 는 고정됩니다.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // 반올림은 i) 반올림 조건 만 트리거되거나 ii) 두 조건이 모두 트리거되고 타이 브레이킹이 반올림을 선호 할 때 발생합니다.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // 반올림으로 길이가 변경되면 지수도 변경되어야합니다.
        // 이 조건은 만족하기가 매우 어려운 것처럼 보이지만 (불가능할 수도 있음) 여기서는 안전하고 일관성이 있습니다.
        //
        // 안전: 위의 메모리를 초기화했습니다.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // 안전: 위의 메모리를 초기화했습니다.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Dragon에 대한 정확하고 고정 된 모드 구현.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` 를 만족하는 원래 입력에서 `k_0` 를 추정합니다.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` 를 `10^k` 로 나눕니다.이제 `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` 일 때 수정, 여기서 `plus / scale = 10^-buf.len() / 2`.
    // 고정 된 크기의 큰 숫자를 유지하기 위해 실제로 `mant + floor(plus) >= scale` 를 사용합니다.
    // 대신 초기 곱셈을 건너 뛸 수 있으므로 실제로 `scale` 를 수정하지 않습니다.
    // 다시 가장 짧은 알고리즘을 사용하면 `d[0]` 는 0이 될 수 있지만 결국 반올림됩니다.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` 를 10으로 조정하는 것과 동일
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // 마지막 자릿수 제한으로 작업하는 경우 이중 반올림을 방지하기 위해 실제 렌더링 전에 버퍼를 줄여야합니다.
    //
    // 반올림이 발생할 때 버퍼를 다시 확대해야합니다.
    let mut len = if k < limit {
        // 죄송합니다.*한* 숫자를 생성 할 수도 없습니다.
        // 이것은 우리가 9.5 와 같은 것을 가지고 있고 10으로 반올림 될 때 가능합니다.
        // `k == limit` 에서 발생하고 정확히 한 자리를 생성해야하는 나중에 반올림하는 경우를 제외하고는 빈 버퍼를 반환합니다.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // 숫자 생성을위한 캐시 `(2, 4, 8) * scale`.
        // (비용이 많이들 수 있으므로 버퍼가 비어있을 때는 계산하지 마십시오.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // 다음 숫자는 모두 0입니다. 여기서 멈 춥니 다. 반올림을 수행하지 않습니다.오히려 나머지 숫자를 채우십시오.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // 안전: 위의 메모리를 초기화했습니다.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // 다음 자릿수가 정확히 5000이면 자릿수 중간에서 멈출 경우 반올림 ..., 이전 자릿수를 확인하고 짝수로 반올림합니다 (즉, 이전 자릿수가 짝수 일 때 반올림하지 않음).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // 안전: `buf[len-1]` 가 초기화됩니다.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // 반올림으로 길이가 변경되면 지수도 변경되어야합니다.
        // 그러나 고정 된 자릿수를 요청 받았으므로 버퍼를 변경하지 마십시오.
        // 안전: 위의 메모리를 초기화했습니다.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... 대신 고정 정밀도를 요청하지 않는 한.
            // 또한 원래 버퍼가 비어있는 경우 `k == limit` (edge 케이스)에서만 추가 숫자를 추가 할 수 있는지 확인해야합니다.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // 안전: 위의 메모리를 초기화했습니다.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}