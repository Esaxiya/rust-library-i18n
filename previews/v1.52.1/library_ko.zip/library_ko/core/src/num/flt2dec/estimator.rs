//! 지수 추정량입니다.

/// `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)` 와 같은 `k_0` 를 찾습니다.
///
/// `k = ceil(log_10 (mant * 2^exp))` 를 근사화하는 데 사용됩니다.
/// 진정한 `k` 는 `k_0` 또는 `k_0+1` 입니다.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits if mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) 따라서 이것은 항상 과소 평가 (또는 정확)하지만 많지는 않습니다.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}