//! 부동 소수점 값을 개별 부분 및 오류 범위로 디코딩합니다.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// 다음과 같이 디코딩 된 부호없는 유한 값 :
///
/// - 원래 값은 `mant * 2^exp` 와 같습니다.
///
/// - `(mant - minus)*2^exp` 에서 `(mant + plus)* 2^exp` 까지의 숫자는 원래 값으로 반올림됩니다.
/// 범위는 `inclusive` 가 `true` 인 경우에만 포함됩니다.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// 축척 된 가수입니다.
    pub mant: u64,
    /// 더 낮은 오류 범위.
    pub minus: u64,
    /// 상한 오류 범위입니다.
    pub plus: u64,
    /// 밑이 2 인 공유 지수입니다.
    pub exp: i16,
    /// 오류 범위가 포함되면 True입니다.
    ///
    /// IEEE 754에서는 원래 가수가 짝수 인 경우에도 마찬가지입니다.
    pub inclusive: bool,
}

/// 디코딩 된 부호없는 값입니다.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// 무한대, 양수 또는 음수.
    Infinite,
    /// 0, 양수 또는 음수.
    Zero,
    /// 추가 디코딩 된 필드가있는 유한 숫자.
    Finite(Decoded),
}

/// '디코딩'할 수있는 부동 소수점 유형입니다.
pub trait DecodableFloat: RawFloat + Copy {
    /// 정규화 된 최소 양수 값입니다.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// 주어진 부동 소수점 숫자에서 부호 (음수이면 참)와 `FullDecoded` 값을 반환합니다.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // 이웃: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode 항상 지수를 유지하므로 가수는 비정규로 조정됩니다.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // 이웃: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // 여기서 maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // 이웃: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}