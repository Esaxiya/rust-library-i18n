/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// 이것은 광범위하게 문서화되어 있지만 원칙적으로 테스트 용으로 만 공개되는 비공개입니다.
// 우리를 폭로하지 마십시오.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// 숫자 생성 알고리즘.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// 최단 모드에 필요한 최소 버퍼 크기입니다.
///
/// 파생하는 것은 사소하지 않지만 이것은 가장 짧은 결과를 갖는 형식화 알고리즘에서 최대 유효 십진수 수를 더한 것입니다.
///
/// 정확한 공식은 `ceil(# bits in mantissa * log_10 2 + 1)` 입니다.
pub const MAX_SIG_DIGITS: usize = 17;

/// `d` 에 십진수가 포함 된 경우 마지막 자릿수를 늘리고 캐리를 전파하십시오.
/// 길이가 변경되면 다음 숫자를 반환합니다.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n]은 모두 9입니다.
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 증가 된 지수를 사용하여 1000..000으로 반올림합니다.
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // 빈 버퍼가 반올림됩니다 (조금 이상하지만 합리적인)
            Some(b'1')
        }
    }
}

/// 포맷 된 부품.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// 주어진 숫자가 0입니다.
    Zero(usize),
    /// 최대 5 자리의 리터럴 숫자입니다.
    Num(u16),
    /// 주어진 바이트의 축 어적 사본.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// 주어진 부분의 정확한 바이트 길이를 반환합니다.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// 제공된 버퍼에 부분을 씁니다.
    /// 쓴 바이트 수를 반환하거나 버퍼가 충분하지 않은 경우 `None` 를 반환합니다.
    /// (여전히 부분적으로 쓰여진 바이트를 버퍼에 남길 수 있습니다. 의존하지 마십시오.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// 하나 이상의 부품을 포함하는 형식화 된 결과입니다.
/// 이것은 바이트 버퍼에 기록되거나 할당 된 문자열로 변환 될 수 있습니다.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// 부호 (`""`, `"-"` 또는 `"+"`)를 나타내는 바이트 슬라이스.
    pub sign: &'static str,
    /// 부호 및 선택적 제로 패딩 뒤에 렌더링 할 형식화 된 부분입니다.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// 결합 된 형식화 된 결과의 정확한 바이트 길이를 반환합니다.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// 서식이 지정된 모든 부분을 제공된 버퍼에 씁니다.
    /// 쓴 바이트 수를 반환하거나 버퍼가 충분하지 않은 경우 `None` 를 반환합니다.
    /// (여전히 부분적으로 쓰여진 바이트를 버퍼에 남길 수 있습니다. 의존하지 마십시오.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// 주어진 소수 자릿수 `0.<...buf...> * 10^exp` 를 최소한 주어진 소수 자릿수를 사용하여 소수 형식으로 형식화합니다.
///
/// 결과는 제공된 부품 배열에 저장되고 작성된 부품 조각이 반환됩니다.
///
/// `frac_digits` `buf` 의 실제 소수 자릿수보다 작을 수 있습니다.
/// 무시되고 전체 숫자가 인쇄됩니다.렌더링 된 숫자 이후에 추가 0을 인쇄하는 데만 사용됩니다.
/// 따라서 0의 `frac_digits` 는 주어진 숫자 만 인쇄하고 다른 것은 인쇄하지 않음을 의미합니다.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // 마지막 자리 위치에 제한이있는 경우 `buf` 는 가상 0으로 왼쪽이 채워지는 것으로 간주됩니다.
    // 가상 0의 수 `nzeroes` 는 `max(0, exp + frac_digits - buf.len())` 와 같으므로 마지막 숫자 `exp - buf.len() - nzeroes` 의 위치는 `-frac_digits` 보다 크지 않습니다.
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |0 |특급
    //    0. 12 34 5678 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` 오버플로를 방지하기 위해 각 경우에 대해 개별적으로 계산됩니다.
    //

    if exp <= 0 {
        // 소수점은 렌더링 된 숫자 앞에 있습니다. [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // 안전: 방금 `..4` 요소를 초기화했습니다.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // 안전: 방금 `..3` 요소를 초기화했습니다.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // 소수점은 렌더링 된 숫자 안에 있습니다. [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // 안전: 방금 `..4` 요소를 초기화했습니다.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // 안전: 방금 `..3` 요소를 초기화했습니다.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // 소수점은 렌더링 된 숫자 ([1234][____0000] 또는 [1234][__][.][__]) 뒤에 있습니다.
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // 안전: 방금 `..4` 요소를 초기화했습니다.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // 안전: 방금 `..2` 요소를 초기화했습니다.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// 주어진 십진수 `0.<...buf...> * 10^exp` 를 최소한 주어진 유효 자릿수를 사용하여 지수 형식으로 형식화합니다.
///
/// `upper` 가 `true` 이면 지수 앞에 `E` 가 붙습니다.그렇지 않으면 `e` 입니다.
/// 결과는 제공된 부품 배열에 저장되고 작성된 부품 조각이 반환됩니다.
///
/// `min_digits` `buf` 의 실제 유효 자릿수보다 작을 수 있습니다.
/// 무시되고 전체 숫자가 인쇄됩니다.렌더링 된 숫자 이후에 추가 0을 인쇄하는 데만 사용됩니다.
/// 따라서 `min_digits == 0` 는 주어진 숫자 만 인쇄하고 다른 것은 인쇄하지 않음을 의미합니다.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // exp가 i16::MIN 일 때 언더 플로 방지
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // 안전: 방금 `..n + 2` 요소를 초기화했습니다.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// 서식 옵션에 서명합니다.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// 0이 아닌 음수 값에 대해서만 `-` 를 인쇄합니다.
    Minus, // -inf -1 000 1 inf nan
    /// 음수 값 (음수 0 포함)에 대해서만 `-` 를 인쇄합니다.
    MinusRaw, // -inf -1 -0 01 inf nan
    /// 0이 아닌 음수 값에 대해서는 `-` 를 인쇄하고 그렇지 않으면 `+` 를 인쇄합니다.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// 음수 값 (음수 0 포함)에 대해 `-` 를 인쇄하거나 그렇지 않으면 `+` 를 인쇄합니다.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// 서식을 지정할 부호에 해당하는 정적 바이트 문자열을 반환합니다.
/// `""`, `"+"` 또는 `"-"` 일 수 있습니다.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// 주어진 부동 소수점 숫자를 최소한 주어진 소수 자릿수를 사용하여 10 진수 형식으로 포맷합니다.
/// 결과는 제공된 바이트 버퍼를 스크래치로 사용하는 동안 제공된 부품 배열에 저장됩니다.
/// `upper` 은 현재 사용되지 않지만 future 결정을 위해 비유 한 값 (예: `inf` 및 `nan`)의 대소 문자를 변경해야합니다.
///
/// 렌더링 할 첫 번째 부분은 항상 `Part::Sign` 입니다 (표시가 렌더링되지 않은 경우 빈 문자열 일 수 있음).
///
/// `format_shortest` 기본 숫자 생성 함수 여야합니다.
/// 초기화 한 버퍼 부분을 반환해야합니다.
/// 아마도 `strategy::grisu::format_shortest` 를 원할 것입니다.
///
/// `frac_digits` `v` 의 실제 소수 자릿수보다 작을 수 있습니다.
/// 무시되고 전체 숫자가 인쇄됩니다.렌더링 된 숫자 이후에 추가 0을 인쇄하는 데만 사용됩니다.
/// 따라서 0의 `frac_digits` 는 주어진 숫자 만 인쇄하고 다른 것은 인쇄하지 않음을 의미합니다.
///
/// 바이트 버퍼의 길이는 최소한 `MAX_SIG_DIGITS` 바이트 여야합니다.
/// `frac_digits = 10` 가있는 `[+][0.][0000][2][0000]` 와 같은 최악의 경우로 인해 최소 4 개의 부품을 사용할 수 있어야합니다.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // 안전: 방금 `..2` 요소를 초기화했습니다.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // 안전: 방금 `..1` 요소를 초기화했습니다.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// 결과 지수에 따라 주어진 부동 소수점 숫자를 10 진수 형식 또는 지수 형식으로 형식화합니다.
/// 결과는 제공된 바이트 버퍼를 스크래치로 사용하는 동안 제공된 부품 배열에 저장됩니다.
/// `upper` 비유 한 값 (`inf` 및 `nan`) 또는 지수 접두어 (`e` 또는 `E`)의 대소 문자를 판별하는 데 사용됩니다.
/// 렌더링 할 첫 번째 부분은 항상 `Part::Sign` 입니다 (표시가 렌더링되지 않은 경우 빈 문자열 일 수 있음).
///
/// `format_shortest` 기본 숫자 생성 함수 여야합니다.
/// 초기화 한 버퍼 부분을 반환해야합니다.
/// 아마도 `strategy::grisu::format_shortest` 를 원할 것입니다.
///
/// `dec_bounds` 는 `10^lo <= V < 10^hi` 일 때만 숫자가 십진수로 형식화되는 튜플 `(lo, hi)` 입니다.
/// 이것은 실제 `v` 가 아닌 *명백한*`V` 입니다!따라서 지수 형식으로 인쇄 된 지수는이 범위에있을 수 없으므로 혼동을 피할 수 있습니다.
///
///
/// 바이트 버퍼의 길이는 최소한 `MAX_SIG_DIGITS` 바이트 여야합니다.
/// `[+][1][.][2345][e][-][6]` 와 같은 최악의 경우로 인해 최소 6 개의 부품을 사용할 수 있어야합니다.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// 주어진 디코딩 된 지수에서 계산 된 최대 버퍼 크기에 대해 다소 조잡한 근사값 (상한)을 반환합니다.
///
/// 정확한 제한은 다음과 같습니다.
///
/// - `exp < 0` 일 때 최대 길이는 `ceil(log_10 (5^-exp * (2^64 - 1)))` 입니다.
/// - `exp >= 0` 일 때 최대 길이는 `ceil(log_10 (2^exp * (2^64 - 1)))` 입니다.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` 보다 작으며 차례로 `20 + (1 + exp* log_10 x)` 보다 작습니다.
/// 우리는 `log_10 2 < 5/16` 와 `log_10 5 < 12/16` 라는 사실을 사용하는데, 이는 우리의 목적에 충분합니다.
///
/// 왜 이것이 필요한가요?`format_exact` 함수는 마지막 숫자 제한에 의해 제한되지 않는 한 전체 버퍼를 채 웁니다. 그러나 요청 된 숫자 수가 엄청나게 클 수 있습니다 (예: 30,000 자리).
///
/// 대부분의 버퍼는 0으로 채워 지므로 모든 버퍼를 미리 할당하고 싶지 않습니다.
/// 따라서 주어진 인수에 대해
/// `f64` 에는 826 바이트의 버퍼면 충분합니다.최악의 경우 실제 숫자 인 770 바이트 (`exp = -1074` 일 때)와 비교하십시오.
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// 주어진 부동 소수점 숫자를 정확히 주어진 유효 자릿수로 지수 형식으로 형식화합니다.
/// 결과는 제공된 바이트 버퍼를 스크래치로 사용하는 동안 제공된 부품 배열에 저장됩니다.
/// `upper` 지수 접두어 (`e` 또는 `E`)의 대소 문자를 결정하는 데 사용됩니다.
/// 렌더링 할 첫 번째 부분은 항상 `Part::Sign` 입니다 (표시가 렌더링되지 않은 경우 빈 문자열 일 수 있음).
///
/// `format_exact` 기본 숫자 생성 함수 여야합니다.
/// 초기화 한 버퍼 부분을 반환해야합니다.
/// 아마도 `strategy::grisu::format_exact` 를 원할 것입니다.
///
/// 바이트 버퍼는 `ndigits` 가 너무 커서 고정 된 자릿수 만 기록되지 않는 한 `ndigits` 바이트 이상이어야합니다.
/// (`f64` 의 티핑 포인트는 약 800이므로 1000 바이트이면 충분합니다.) `[+][1][.][2345][e][-][6]` 와 같은 최악의 경우로 인해 최소 6 개의 부품을 사용할 수 있어야합니다.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // 안전: 방금 `..3` 요소를 초기화했습니다.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // 안전: 방금 `..1` 요소를 초기화했습니다.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// 주어진 부동 소수점 숫자를 정확히 주어진 소수 자릿수를 사용하여 10 진수 형식으로 형식화합니다.
/// 결과는 제공된 바이트 버퍼를 스크래치로 사용하는 동안 제공된 부품 배열에 저장됩니다.
/// `upper` 은 현재 사용되지 않지만 future 결정을 위해 비유 한 값 (예: `inf` 및 `nan`)의 대소 문자를 변경해야합니다.
/// 렌더링 할 첫 번째 부분은 항상 `Part::Sign` 입니다 (표시가 렌더링되지 않은 경우 빈 문자열 일 수 있음).
///
/// `format_exact` 기본 숫자 생성 함수 여야합니다.
/// 초기화 한 버퍼 부분을 반환해야합니다.
/// 아마도 `strategy::grisu::format_exact` 를 원할 것입니다.
///
/// 바이트 버퍼는 `frac_digits` 가 너무 커서 고정 된 자릿수 만 기록되지 않는 한 출력에 충분해야합니다.
/// (`f64` 의 티핑 포인트는 약 800이고 1000 바이트이면 충분합니다.) `frac_digits = 10` 를 사용하는 `[+][0.][0000][2][0000]` 와 같은 최악의 경우로 인해 최소 4 개의 부품을 사용할 수 있어야합니다.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 안전: 방금 `..1` 요소를 초기화했습니다.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // 안전: 방금 `..2` 요소를 초기화했습니다.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // 안전: 방금 `..1` 요소를 초기화했습니다.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // `frac_digits` 가 엄청나게 클 수도 있습니다.
            // `format_exact` `maxlen` 에 의해 엄격하게 제한되기 때문에이 경우 훨씬 더 일찍 숫자 렌더링을 종료합니다.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // 제한이 충족되지 않았으므로 `exp` 와 상관없이 0처럼 렌더링되어야합니다.
                // 여기에는 최종 반올림 후에 만 제한이 충족 된 경우는 포함되지 않습니다.`exp = limit + 1` 의 일반적인 경우입니다.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // 안전: 방금 `..2` 요소를 초기화했습니다.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // 안전: 방금 `..1` 요소를 초기화했습니다.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}