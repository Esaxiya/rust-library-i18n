//! "정수를 사용하여 빠르고 정확하게 부동 소수점 숫자 인쇄"[^ 1]에 설명 된 Grisu3 알고리즘의 Rust 적용.
//! 약 1KB의 미리 계산 된 테이블을 사용하며 대부분의 입력에 대해 매우 빠릅니다.
//!
//! [^1]: Florian Loitsch.2010. 부동 소수점 숫자를 빠르게 인쇄하고
//!   정수로 정확하게.SIGPLAN 아닙니다.45, 6 (2010 년 6 월), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// 근거는 `format_shortest_opt` 의 주석을 참조하십시오.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` 가 주어지면 `10^k <= x < 10^(k+1)` 와 같은 `(k, 10^k)` 를 반환합니다.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Grisu의 최단 모드 구현입니다.
///
/// 그렇지 않으면 정확하지 않은 표현을 반환 할 때 `None` 를 반환합니다.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // 최소한 3 비트의 추가 정밀도가 필요합니다.

    // 공유 지수로 정규화 된 값으로 시작
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // `ALPHA <= minusk + plus.e + 64 <= GAMMA` 와 같은 `cached = 10^minusk` 를 찾으십시오.
    // `plus` 가 정규화되었으므로 이것은 `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` 를 의미합니다.
    // `ALPHA` 및 `GAMMA` 를 선택하면 `plus * cached` 가 `[4, 2^32)` 에 포함됩니다.
    //
    // `GAMMA - ALPHA` 를 최대화하는 것이 분명히 바람직하므로 10의 캐시 된 거듭 제곱이 많이 필요하지 않지만 몇 가지 고려 사항이 있습니다.
    //
    //
    // 1. 비용이 많이 드는 분할이 필요하므로 `floor(plus * cached)` 를 `u32` 내에 유지하려고합니다.
    //    (이것은 실제로 피할 수 없으며 정확도 추정을 위해 나머지가 필요합니다.)
    // 2.
    // `floor(plus * cached)` 의 나머지 부분은 반복적으로 10 배가되고 오버플로되지 않아야합니다.
    //
    // 첫 번째는 `64 + GAMMA <= 32` 를 제공하고 두 번째는 `10 * 2^-ALPHA <= 2^64` 를 제공합니다.
    // -60 -32 는이 제약 조건의 최대 범위이며 V8 도이를 사용합니다.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // 스케일 fps.이것은 1ulp의 최대 오차를 제공합니다 (Theorem 5.1 에서 입증).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-실제 마이너스 범위
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1ulp | 1ulp || 1ulp | 1ulp || 1ulp | 1ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus` 이상, `v` 및 `plus` 는 *양자화* 근사치입니다 (오류 <1 ulp).
    // 오차가 양수인지 음수인지 알 수 없기 때문에 동일한 간격으로 두 개의 근사치를 사용하고 최대 오차는 2ulps입니다.
    //
    // "unsafe region" 는 우리가 처음에 생성하는 자유 간격입니다.
    // "safe region" 는 우리가 받아 들일 수있는 보수적 인 간격입니다.
    // 안전하지 않은 영역 내에서 올바른 재현으로 시작하고 안전 영역 내에있는 `v` 에 가장 가까운 재현을 찾으려고합니다.
    // 할 수 없으면 포기합니다.
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f, 1;//설명을 위해서만 let minus0 = minus.f + 1;//설명 용
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // 공유 지수

    // `plus1` 를 정수 부분과 분수 부분으로 나눕니다.
    // 캐시 된 전력은 `plus < 2^32` 를 보장하고 정규화 된 `plus.f` 는 정밀도 요구 사항으로 인해 항상 `2^64 - 2^4` 보다 작기 때문에 필수 부품은 u32 에 적합하도록 보장됩니다.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // `plus1` (따라서 `plus1 < 10^(max_kappa+1)`) 이하의 가장 큰 `10^max_kappa` 를 계산합니다.
    // 이것은 아래 `kappa` 의 상한입니다.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 정리 6.2: `k` 가 가장 큰 정수인 경우 st
    // `0 <= y mod 10^k <= y - x`,              `V = floor(y / 10^k) * 10^k` 는 `[x, y]` 에 있으며 해당 범위에서 가장 짧은 표현 (유효 자릿수의 최소 포함) 중 하나입니다.
    //
    //
    // Theorem 6.2 에 따라 `(minus1, plus1)` 사이의 숫자 길이 `kappa` 를 찾으십시오.
    // 정리 6.2 는 대신 `y mod 10^k < y - x` 를 요구하여 `x` 를 제외하도록 채택 할 수 있습니다.
    // (예: `x` =32000, `y` =32777; `kappa` =2 이후`y mod 10 ^ 3=777 <y, x=777`.) 알고리즘은 `y` 를 제외하기 위해 이후 검증 단계에 의존합니다.
    //
    let delta1 = plus1 - minus1;
    // delta1int=(delta1>> e) as usize;//설명 용
    let delta1frac = delta1 & ((1 << e) - 1);

    // 각 단계에서 정확성을 확인하면서 필수 부품을 렌더링합니다.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // 아직 렌더링되지 않은 숫자
    loop {
        // `plus1 >= 10^kappa` 불변으로 항상 렌더링 할 숫자가 하나 이상 있습니다.
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (그 `remainder = plus1int % 10^(kappa+1)` 를 따릅니다)
        //
        //

        // `remainder` 를 `10^kappa` 로 나눕니다.둘 다 `2^-e` 로 확장됩니다.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1 % 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; 올바른 `kappa` 를 찾았습니다.
            let ten_kappa = (ten_kappa as u64) << e; // 10 ^ kappa를 공유 지수로 다시 조정
            return round_and_weed(
                // 안전: 위의 메모리를 초기화했습니다.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // 모든 정수를 렌더링하면 루프를 끊습니다.
        // 정확한 자릿수는 `max_kappa + 1` 와 `plus1 < 10^(max_kappa+1)` 입니다.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // 불변 복원
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // 각 단계에서 정확성을 확인하면서 분수 부분을 렌더링합니다.
    // 이번에는 나누기가 정밀도를 잃기 때문에 반복되는 곱셈에 의존합니다.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // 불변을 분석하기 전에 테스트 한 것처럼 다음 숫자는 중요해야합니다. 여기서 `m = max_kappa + 1` (정수 부분의 숫자 수) :
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // 넘치지 않을 것입니다. `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` 를 `10^kappa` 로 나눕니다.
        // 둘 다 `2^e / 10^kappa` 에 의해 크기가 조정되므로 후자는 여기서 암시 적입니다.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // 암시 적 제수
            return round_and_weed(
                // 안전: 위의 메모리를 초기화했습니다.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // 불변 복원
        kappa -= 1;
        remainder = r;
    }

    // `plus1` 의 모든 유효 자릿수를 생성했지만 이것이 최적인지 확실하지 않습니다.
    // 예를 들어 `minus1` 가 3.14153 ...이고 `plus1` 가 3.14158 ... 인 경우 3.14154 에서 3.14158 까지 5 개의 가장 짧은 표현이 있지만 가장 큰 표현 만 있습니다.
    // 마지막 숫자를 연속적으로 줄이고 이것이 최적의 반복인지 확인해야합니다.
    // 최대 9 개의 후보 (..1 ~ ..9)가 있으므로 상당히 빠릅니다.("rounding" 단계)
    //
    // 이 함수는이 "optimal" repr이 실제로 ulp 범위 내에 있는지 확인하며 반올림 오류로 인해 "second-to-optimal" repr이 실제로 최적 일 수 있습니다.
    // 두 경우 모두 `None` 를 반환합니다.
    // ("weeding" 단계)
    //
    // 여기에있는 모든 인수는 공통 (하지만 암시 적) 값 `k` 에 의해 스케일링되므로 다음과 같습니다.
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (또한 `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (또한 이전 불변의 `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 ulps 내에서 `v` (실제로 `plus1 - v`)에 대한 두 가지 근사값을 생성합니다.
        // 결과 표현은 둘 다에 가장 가까운 표현이어야합니다.
        //
        // 여기서 `plus1 - v` 는 overflow/underflow (따라서 겉보기에 바뀐 이름)를 피하기 위해 `plus1` 에 대한 계산이 수행되기 때문에 사용됩니다.
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // 마지막 숫자를 줄이고 `v + 1 ulp` 에 가장 가까운 표현에서 멈 춥니 다.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // 우리는 초기에 `plus1 - plus1 % 10^kappa` 와 같은 대략적인 숫자 `w(n)` 로 작업합니다.루프 바디를 `n` 번 실행 한 후 `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // 우리는 `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` 를 설정합니다 (따라서`remainder= plus1w(0)`) 는 검사를 단순화합니다.
            // `plus1w(n)` 는 항상 증가하고 있습니다.
            //
            // 종료 할 세 가지 조건이 있습니다.그들 중 어느 것도 루프를 진행할 수 없게 만들지 만 어쨌든 `v + 1 ulp` 에 가장 가까운 것으로 알려진 유효한 표현이 하나 이상 있습니다.
            // 간결성을 위해 TC1 부터 TC3 까지 표시합니다.
            //
            // TC1: `w(n) <= v + 1 ulp`, 즉 이것은 가장 가까운 것이 될 수있는 마지막 반복입니다.
            // 이것은 `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` 와 동일합니다.
            // TC2 와 결합 (`w(n+1)` is valid) 여부를 확인하여 `plus1w(n)` 계산시 오버플로 가능성을 방지합니다.
            //
            // TC2: `w(n+1) < minus1`, 즉 다음 반복은 확실히 `v` 로 반올림되지 않습니다.
            // 이것은 `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` 와 동일합니다.
            // 왼쪽은 오버플로 될 수 있지만 `threshold > plus1v` 를 알고 있으므로 TC1 가 거짓이면 `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` 이고 대신 `threshold - plus1w(n) < 10^kappa` 인지 안전하게 테스트 할 수 있습니다.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, 즉, 다음 반복은
            // 현재 재현보다 `v + 1 ulp` 에 더 가깝지 않습니다.
            // `z(n) = plus1v_up - plus1w(n)` 가 주어지면 이것은 `abs(z(n)) <= abs(z(n+1))` 가됩니다.다시 TC1 가 거짓이라고 가정하면 `z(n) > 0` 가 있습니다.고려해야 할 두 가지 경우가 있습니다.
            //
            // - `z(n+1) >= 0`: TC3 가 `z(n) <= z(n+1)` 가됩니다.
            // `plus1w(n)` 가 증가함에 따라 `z(n)` 는 감소해야하며 이것은 분명히 거짓입니다.
            // - `z(n+1) < 0` :
            //   - TC3a: 전제 조건은 `plus1v_up < plus1w(n) + 10^kappa` 입니다.TC2 가 거짓이라고 가정하면 `threshold >= plus1w(n) + 10^kappa` 는 오버플로 할 수 없습니다.
            //   - TC3b: TC3 는 `z(n) <= -z(n+1)` 가됩니다. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   부정 된 TC1 는 `plus1v_up > plus1w(n)` 를 제공하므로 TC3a와 결합하면 오버플로 또는 언더 플로 할 수 없습니다.
            //
            // 결과적으로 `TC1 || TC2 || (TC3a && TC3b)` 가되면 중지해야합니다.다음은 그 역과 같습니다. `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // 가장 짧은 반복은 `0` 로 끝날 수 없습니다.
                plus1w += ten_kappa;
            }
        }

        // 이 표현이 `v - 1 ulp` 에 가장 가까운 표현인지 확인하십시오.
        //
        // 이것은 `v + 1 ulp` 의 종료 조건과 동일하며 모든 `plus1v_up` 가 대신 `plus1v_down` 로 대체됩니다.
        // 오버플로 분석은 동일하게 유지됩니다.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // 이제 우리는 `plus1` 와 `minus1` 사이에서 `v` 에 가장 가까운 표현을 가지고 있습니다.
        // 그러나 이것은 너무 자유롭기 때문에 우리는 `plus0` 와 `minus0` 사이에 있지 않은 `w(n)`, 즉 `plus1 - plus1w(n) <= minus0` 또는 `plus1 - plus1w(n) >= plus0` 를 거부합니다.
        // 우리는 `threshold = plus1 - minus1` 와 `plus1 - plus0 = minus0 - minus1 = 2 ulp` 의 사실을 활용합니다.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Grisu with Dragon fallback의 최단 모드 구현입니다.
///
/// 대부분의 경우에 사용해야합니다.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // 안전: 차용 검사기는 `buf` 를 사용할 수있을만큼 똑똑하지 않습니다.
    // 두 번째 branch 에서 우리는 여기서 평생을 세탁합니다.
    // 하지만 `format_shortest_opt` 가 `None` 를 반환 한 경우에만 `buf` 를 재사용하므로 괜찮습니다.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Grisu를위한 정확한 고정 모드 구현.
///
/// 그렇지 않으면 정확하지 않은 표현을 반환 할 때 `None` 를 반환합니다.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // 최소한 3 비트의 추가 정밀도가 필요합니다.
    assert!(!buf.is_empty());

    // `v` 를 정규화하고 확장합니다.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` 를 정수 부분과 분수 부분으로 나눕니다.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // 이전 `v` 와 새 `v` (`10^-k` 에 의해 스케일링 됨) 모두 <1ulp (Theorem 5.1)의 오류가 있습니다.
    // 오류가 양수인지 음수인지 알 수 없기 때문에 동일한 간격으로 두 개의 근사치를 사용하고 최대 오류는 2ulps입니다 (가장 짧은 경우와 동일).
    //
    //
    // 목표는 `v - 1 ulp` 와 `v + 1 ulp` 모두에 공통되는 정확히 반올림 된 일련의 숫자를 찾는 것이므로 최대한 확신 할 수 있습니다.
    // 이것이 가능하지 않으면 어떤 것이 `v` 에 대한 올바른 출력인지 알 수 없으므로 포기하고 폴백합니다.
    //
    // `err` 여기서는 `1 ulp * 2^e` 로 정의됩니다 (`vfrac` 의 ulp와 동일). `v` 의 크기가 조정될 때마다 크기를 조정합니다.
    //
    //
    //
    let mut err = 1;

    // `v` (따라서 `v < 10^(max_kappa+1)`) 이하의 가장 큰 `10^max_kappa` 를 계산합니다.
    // 이것은 아래 `kappa` 의 상한입니다.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 마지막 자릿수 제한으로 작업하는 경우 이중 반올림을 방지하기 위해 실제 렌더링 전에 버퍼를 줄여야합니다.
    //
    // 반올림이 발생할 때 버퍼를 다시 확대해야합니다.
    let len = if exp <= limit {
        // 죄송합니다.*한* 숫자를 생성 할 수도 없습니다.
        // 이것은 우리가 9.5 와 같은 것을 가지고 있고 10으로 반올림 될 때 가능합니다.
        //
        // 원칙적으로 빈 버퍼로 `possibly_round` 를 즉시 호출 할 수 있지만 `max_ten_kappa << e` 를 10으로 확장하면 오버플로가 발생할 수 있습니다.
        //
        // 따라서 우리는 여기서 엉성하고 오류 범위를 10 배로 넓 힙니다.
        // 이것은 위 음성률을 증가시킬 것이지만, 매우 *아주* 약간만 증가 할 것입니다.
        // 가수가 60 비트보다 클 때만 눈에 띄게 중요 할 수 있습니다.
        //
        // 안전: `len=0` 이므로이 메모리를 초기화해야하는 의무는 사소합니다.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // 필수 부분을 렌더링합니다.
    // 오류는 완전히 부분적이므로이 부분에서 확인할 필요가 없습니다.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // 아직 렌더링되지 않은 숫자
    loop {
        // 불변을 렌더링하기 위해 항상 최소한 하나의 숫자가 있습니다.
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (그 `remainder = vint % 10^(kappa+1)` 를 따릅니다)
        //
        //

        // `remainder` 를 `10^kappa` 로 나눕니다.둘 다 `2^-e` 로 확장됩니다.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // 버퍼가 꽉 찼습니까?나머지로 반올림 패스를 실행하십시오.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v % 10 ^ kappa) * 2 ^ e
            // 안전: 우리는 `len` 많은 바이트를 초기화했습니다.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // 모든 정수를 렌더링하면 루프를 끊습니다.
        // 정확한 자릿수는 `max_kappa + 1` 와 `plus1 < 10^(max_kappa+1)` 입니다.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // 불변 복원
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // 분수 부분을 렌더링합니다.
    //
    // 원칙적으로 사용 가능한 마지막 숫자까지 계속해서 정확성을 확인할 수 있습니다.
    // 불행히도 우리는 유한 크기의 정수로 작업하고 있으므로 오버플로를 감지하려면 몇 가지 기준이 필요합니다.
    // V8 `remainder > err` 를 사용합니다. `v - 1 ulp` 와 `v` 의 첫 번째 `i` 유효 숫자가 다를 때 거짓이됩니다.
    // 그러나 이것은 다른 유효한 입력을 너무 많이 거부합니다.
    //
    // 이후 단계에는 올바른 오버플로 감지가 있으므로 대신 더 엄격한 기준을 사용합니다.
    // 우리는 `err` 가 `10^kappa / 2` 를 초과 할 때까지 계속해서 `v - 1 ulp` 와 `v + 1 ulp` 사이의 범위는 확실히 두 개 이상의 둥근 표현을 포함합니다.
    //
    // 이것은 참조를 위해 `possibly_round` 의 처음 두 비교와 동일합니다.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // 불변, 여기서 `m = max_kappa + 1` (정수 부분의 자릿수) :
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // 넘치지 않을 것입니다. `2^e * 10 < 2^64`
        err *= 10; // 넘치지 않을 것입니다. `err * 10 < 2^e * 5 < 2^64`

        // `remainder` 를 `10^kappa` 로 나눕니다.
        // 둘 다 `2^e / 10^kappa` 에 의해 크기가 조정되므로 후자는 여기서 암시 적입니다.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // 버퍼가 꽉 찼습니까?나머지로 반올림 패스를 실행하십시오.
        if i == len {
            // 안전: 우리는 `len` 많은 바이트를 초기화했습니다.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // 불변 복원
        remainder = r;
    }

    // 추가 계산은 쓸모가 없으므로 (`possibly_round` 는 확실히 실패 함) 포기합니다.
    return None;

    // `v` 의 요청 된 모든 숫자를 생성했습니다. `v - 1 ulp` 의 해당 숫자와 동일해야합니다.
    // 이제 `v - 1 ulp` 와 `v + 1 ulp` 가 공유하는 고유 한 표현이 있는지 확인합니다.이는 생성 된 숫자와 동일하거나 해당 숫자의 반올림 버전과 동일 할 수 있습니다.
    //
    // 범위에 동일한 길이의 여러 표현이 포함되어 있으면 확신 할 수 없으며 대신 `None` 를 반환해야합니다.
    //
    // 여기에있는 모든 인수는 공통 (하지만 암시 적) 값 `k` 에 의해 스케일링되므로 다음과 같습니다.
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // 안전: `buf` 의 첫 번째 `len` 바이트는 초기화되어야합니다.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (참고로 점선은 주어진 자릿수로 표현 가능한 정확한 값을 나타냅니다.)
        //
        //
        // 오류가 너무 커서 `v - 1 ulp` 와 `v + 1 ulp` 사이에 가능한 표현이 세 개 이상 있습니다.
        // 어느 것이 옳은지 판단 할 수 없습니다.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1ulp | 1ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // 실제로 1/2 ulp는 두 가지 가능한 표현을 도입하기에 충분합니다.
        // (`v - 1 ulp` 와`v + 1 ulp` 모두에 대해 고유 한 표현이 필요하다는 것을 기억하십시오.) 이것은 첫 번째 검사의 `ulp < ten_kappa` 처럼 오버플로되지 않습니다.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- --------> :
        //     | :   |                           :
        //     | 1ulp | 1ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // `v + 1 ulp` 가 반올림 된 표현 (이미 `buf` 에 있음)에 더 가깝다면 안전하게 반환 할 수 있습니다.
        // `v - 1 ulp`*는 현재 표현보다 작을 수 있지만*`1 ulp < 10^kappa / 2` 이므로이 조건이면 충분합니다.
        // `v - 1 ulp` 와 현재 표현 사이의 거리는 `10^kappa / 2` 를 초과 할 수 없습니다.
        //
        // 조건은 `remainder + ulp < 10^kappa / 2` 와 같습니다.
        // 쉽게 넘칠 수 있으므로 먼저 `remainder < 10^kappa / 2` 인지 확인하십시오.
        // 우리는 이미 `ulp < 10^kappa / 2` 를 확인 했으므로 `10^kappa` 가 결국 오버플로되지 않는 한 두 번째 검사는 괜찮습니다.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // 안전: 호출자가 해당 메모리를 초기화했습니다.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------나머지------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- -------> :
        //   :                    |     |   : |
        //   : | 1ulp | 1ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // 반면에 `v - 1 ulp` 가 반올림 표현에 더 가깝다면 반올림하고 반환해야합니다.
        // 같은 이유로 `v + 1 ulp` 를 확인할 필요가 없습니다.
        //
        // 조건은 `remainder - ulp >= 10^kappa / 2` 와 같습니다.
        // 다시 우리는 먼저 `remainder > ulp` 를 확인합니다 (`10^kappa` 는 0이 아니므로 `remainder >= ulp` 가 아닙니다).
        //
        // 또한 `remainder - ulp <= 10^kappa` 이므로 두 번째 검사가 오버플로되지 않습니다.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // 안전: 호출자는 해당 메모리를 초기화해야합니다.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // 고정 정밀도를 요청한 경우에만 추가 숫자를 추가하십시오.
                // 또한 원래 버퍼가 비어있는 경우 `exp == limit` (edge 케이스)에서만 추가 숫자를 추가 할 수 있는지 확인해야합니다.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // 안전: 우리와 호출자는 해당 메모리를 초기화했습니다.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // 그렇지 않으면 우리는 파멸 (즉, `v - 1 ulp` 와 `v + 1 ulp` 사이의 일부 값은 반올림되고 다른 값은 반올림 됨)하고 포기합니다.
        //
        None
    }
}

/// Grisu with Dragon fallback을위한 정확하고 고정 된 모드 구현.
///
/// 대부분의 경우에 사용해야합니다.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // 안전: 차용 검사기는 `buf` 를 사용할 수있을만큼 똑똑하지 않습니다.
    // 두 번째 branch 에서 우리는 여기서 평생을 세탁합니다.
    // 하지만 `format_exact_opt` 가 `None` 를 반환 한 경우에만 `buf` 를 재사용하므로 괜찮습니다.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}