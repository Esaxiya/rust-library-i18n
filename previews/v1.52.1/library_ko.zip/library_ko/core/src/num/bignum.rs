//! 사용자 정의 임의 정밀도 숫자 (bignum) 구현.
//!
//! 이는 스택 메모리를 희생하여 힙 할당을 방지하도록 설계되었습니다.
//! 가장 많이 사용되는 bignum 유형 인 `Big32x40` 는 32 × 40=1,280 비트로 제한되며 최대 160 바이트의 스택 메모리를 사용합니다.
//! 이것은 가능한 모든 유한 `f64` 값을 왕복하기에 충분합니다.
//!
//! 원칙적으로 다른 입력에 대해 여러 bignum 유형을 가질 수 있지만 코드 부풀림을 피하기 위해 그렇게하지 않습니다.
//!
//! 각 bignum은 여전히 실제 사용량에 대해 추적되므로 일반적으로 중요하지 않습니다.
//!

// 이 모듈은 dec2flt 및 flt2dec 전용이며 coretest로 인해 공개됩니다.
// 안정화를위한 것이 아닙니다.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// bignums에 필요한 산술 연산.
pub trait FullOps: Sized {
    /// `carry' * 2^W + v' = self + other + carry` 와 같은 `(carry', v')` 를 반환합니다. 여기서 `W` 는 `Self` 의 비트 수입니다.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `carry'*2^W + v' = self* other + carry` 와 같은 `(carry', v')` 를 반환합니다. 여기서 `W` 는 `Self` 의 비트 수입니다.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `carry'*2^W + v' = self* other + other2 + carry` 와 같은 `(carry', v')` 를 반환합니다. 여기서 `W` 는 `Self` 의 비트 수입니다.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `borrow *2^W + self = quo* other + rem` 및 `0 <= rem < other` 와 같은 `(quo, rem)` 를 반환합니다. 여기서 `W` 는 `Self` 의 비트 수입니다.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // 이것은 넘칠 수 없습니다.출력은 `0` 와 `2 * 2^nbits - 1` 사이입니다.
                    // FIXME: LLVM은 이것을 ADC 또는 유사하게 최적화합니까?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // 이것은 넘칠 수 없습니다.
                    // 출력은 `0` 와 `2^nbits * (2^nbits - 1)` 사이입니다.
                    // FIXME: LLVM은 이것을 ADC 또는 유사하게 최적화합니까?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // 이것은 넘칠 수 없습니다.
                    // 출력은 `0` 와 `2^nbits * (2^nbits - 1)` 사이입니다.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // 이것은 넘칠 수 없습니다.출력은 `0` 와 `other * (2^nbits - 1)` 사이입니다.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // 이를 활성화하려면 RFC #521 를 참조하십시오.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// 숫자로 표현할 수있는 5의 거듭 제곱 표.특히, 5의 거듭 제곱에 해당 지수를 더한 가장 큰 {u8, u16, u32} 값입니다.
/// `mul_pow5` 에서 사용됩니다.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// 스택 할당 임의 정밀도 (특정 제한까지) 정수입니다.
        ///
        /// 이것은 주어진 ("digit") 유형의 고정 크기 배열로 뒷받침됩니다.
        /// 어레이가 그다지 크지는 않지만 (보통 수백 바이트) 무분별하게 복사하면 성능이 저하 될 수 있습니다.
        ///
        /// 따라서 이것은 의도적으로 `Copy` 가 아닙니다.
        ///
        /// 오버플로의 경우 bignums panic 에 사용할 수있는 모든 작업입니다.
        /// 호출자는 충분히 큰 bignum 유형을 사용해야합니다.
        pub struct $name {
            /// 하나에 사용중인 최대 "digit" 에 대한 오프셋을 더합니다.
            /// 이것은 감소하지 않으므로 계산 순서에 유의하십시오.
            /// `base[size..]` 0이어야합니다.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` 를 나타냅니다. 여기서 `W` 는 숫자 유형의 비트 수입니다.
            base: [$ty; $n],
        }

        impl $name {
            /// 한 자리에서 큰 숫자를 만듭니다.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` 값에서 큰 숫자를 만듭니다.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// 내부 자릿수를 슬라이스 `[a, b, c, ...]` 로 반환하여 숫자 값이 `a + b *2^W + c* 2^(2W) + ...` 이고 여기서 `W` 는 자릿수 유형의 비트 수입니다.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// 비트 0이 최하위 비트 인 'i'번째 비트를 반환합니다.
            /// 즉, 가중치가 `2^i` 인 비트입니다.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// bignum이 0이면 `true` 를 반환합니다.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// 이 값을 나타내는 데 필요한 비트 수를 반환합니다.
            /// 0은 0 비트가 필요한 것으로 간주됩니다.
            pub fn bit_length(&self) -> usize {
                // 0 인 최상위 유효 숫자를 건너 뜁니다.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // 0이 아닌 숫자가 없습니다. 즉, 숫자가 0입니다.
                    return 0;
                }
                // 이것은 leading_zeros() 및 비트 시프트로 최적화 될 수 있지만 번거로울 가치가 없을 것입니다.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` 를 자체에 추가하고 자체 변경 가능한 참조를 반환합니다.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// 자체에서 `other` 를 빼고 자체 변경 가능한 참조를 반환합니다.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// 숫자 크기의 `other` 로 자신을 곱하고 자체 변경 가능한 참조를 반환합니다.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// 자신을 `2^bits` 로 곱하고 자체 변경 가능한 참조를 반환합니다.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` 비트 단위로 이동
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` 비트 단위로 이동
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. digits]는 0이며 이동할 필요가 없습니다.
                }

                self.size = sz;
                self
            }

            /// 자신을 `5^e` 로 곱하고 자체 변경 가능한 참조를 반환합니다.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 ^ n에는 정확히 n 개의 후행 0이 있으며, 관련 숫자 크기는 연속 2의 거듭 제곱이므로 테이블에 적합한 인덱스입니다.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // 가능한 한 가장 큰 한 자리 수로 곱하십시오 ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... 나머지는 끝냅니다.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (여기서 `W` 는 숫자 유형의 비트 수)에서 설명하는 숫자로 자신을 곱하고 자체 변경 가능한 참조를 반환합니다.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // 내부 루틴.aa.len() <= bb.len() 일 때 가장 잘 작동합니다.
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// 자신을 숫자 크기의 `other` 로 나누고 자체 가변 참조 *및* 나머지를 반환합니다.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// self를 다른 bignum으로 나누어 `q` 를 몫으로, `r` 를 나머지로 덮어 씁니다.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // 어리석은 느린 base-2 긴 분할
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME는 긴 분할을 위해 더 큰 기본 ($ty) 를 사용합니다.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // q의 비트 `i` 를 1로 설정합니다.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` 의 숫자 유형입니다.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// 이것은 테스트 용으로 만 사용됩니다.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}