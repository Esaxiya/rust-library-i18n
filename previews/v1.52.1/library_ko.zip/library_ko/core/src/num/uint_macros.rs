macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// 이 정수 유형으로 나타낼 수있는 가장 작은 값입니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// 이 정수 유형으로 표시 할 수있는 가장 큰 값입니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// 이 정수 유형의 크기 (비트)입니다.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// 주어진 밑수에있는 문자열 조각을 정수로 변환합니다.
        ///
        /// 문자열은 선택적인 `+` 부호와 숫자로 예상됩니다.
        ///
        /// 선행 및 후행 공백은 오류를 나타냅니다.
        /// 숫자는 `radix` 에 따라 다음 문자의 하위 집합입니다.
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// 이 기능은 `radix` 가 2에서 36 사이의 범위에 있지 않은 경우 panics 입니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` 의 이진 표현에서 1의 수를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` 의 이진 표현에서 0의 수를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` 의 이진 표현에서 선행 0의 수를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` 의 이진 표현에서 후행 0의 수를 반환합니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` 의 이진 표현에서 선행 숫자의 수를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` 의 이진 표현에서 후행 수를 반환합니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// 잘린 비트를 결과 정수의 끝으로 래핑하여 지정된 양 `n` 만큼 비트를 왼쪽으로 이동합니다.
        ///
        ///
        /// 이것은 `<<` 시프 팅 연산자와 같은 작업이 아닙니다!
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// 비트를 지정된 양 (`n`)만큼 오른쪽으로 이동하여 잘린 비트를 결과 정수의 시작 부분으로 래핑합니다.
        ///
        ///
        /// 이것은 `>>` 시프 팅 연산자와 같은 작업이 아닙니다!
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// 정수의 바이트 순서를 반대로합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// 정수에서 비트 순서를 반대로합니다.
        /// 최하위 비트는 최상위 비트가되고, 두 번째 최하위 비트는 두 번째 최상위 비트가됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() 로하자;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// 정수를 빅 엔디안에서 대상의 엔디안으로 변환합니다.
        ///
        /// 빅 엔디안에서 이것은 작동하지 않습니다.
        /// 리틀 엔디안에서는 바이트가 스왑됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// 정수를 리틀 엔디안에서 대상의 엔디안으로 변환합니다.
        ///
        /// 리틀 엔디안에서 이것은 작동하지 않습니다.
        /// 빅 엔디안에서는 바이트가 스왑됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// 타겟의 엔디안에서 `self` 를 빅 엔디안으로 변환합니다.
        ///
        /// 빅 엔디안에서 이것은 작동하지 않습니다.
        /// 리틀 엔디안에서는 바이트가 스왑됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } 그렇지 않으면 { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // 아니면 안 될까요?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` 를 대상의 엔디안에서 리틀 엔디안으로 변환합니다.
        ///
        /// 리틀 엔디안에서 이것은 작동하지 않습니다.
        /// 빅 엔디안에서는 바이트가 스왑됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } 그렇지 않으면 { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// 정수 더하기를 확인했습니다.
        /// `self + rhs` 를 계산하고 오버플로가 발생하면 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 확인되지 않은 정수 더하기.오버플로가 발생할 수 없다고 가정하고 `self + rhs` 를 계산합니다.
        /// 이로 인해 다음과 같은 경우 정의되지 않은 동작이 발생합니다.
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // 안전: 발신자는 `unchecked_add` 에 대한 안전 계약을 유지해야합니다.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// 정수 빼기를 확인했습니다.
        /// `self - rhs` 를 계산하고 오버플로가 발생하면 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 확인되지 않은 정수 빼기.오버플로가 발생할 수 없다고 가정하고 `self - rhs` 를 계산합니다.
        /// 이로 인해 다음과 같은 경우 정의되지 않은 동작이 발생합니다.
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // 안전: 발신자는 `unchecked_sub` 에 대한 안전 계약을 유지해야합니다.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// 정수 곱셈을 확인했습니다.
        /// `self * rhs` 를 계산하고 오버플로가 발생하면 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 확인되지 않은 정수 곱셈.오버플로가 발생할 수 없다고 가정하고 `self * rhs` 를 계산합니다.
        /// 이로 인해 다음과 같은 경우 정의되지 않은 동작이 발생합니다.
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // 안전: 발신자는 `unchecked_mul` 에 대한 안전 계약을 유지해야합니다.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// 정수 나누기를 확인했습니다.
        /// `self / rhs` 를 계산하고 `rhs == 0` 인 경우 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // 안전: div by zero는 위에서 확인되었으며 서명되지 않은 유형에는 다른 것이 없습니다.
                // 분할 실패 모드
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// 유클리드 부서를 확인했습니다.
        /// `self.div_euclid(rhs)` 를 계산하고 `rhs == 0` 인 경우 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// 정수 나머지를 확인했습니다.
        /// `self % rhs` 를 계산하고 `rhs == 0` 인 경우 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // 안전: div by zero는 위에서 확인되었으며 서명되지 않은 유형에는 다른 것이 없습니다.
                // 분할 실패 모드
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// 유클리드 모듈로를 확인했습니다.
        /// `self.rem_euclid(rhs)` 를 계산하고 `rhs == 0` 인 경우 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// 부정을 확인했습니다.`-self` 를 계산하고`self==가 아니면 `None` 를 반환합니다.
        /// 0`.
        ///
        /// 양의 정수를 부정하면 오버플로됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 왼쪽으로 시프트를 확인했습니다.
        /// `self << rhs` 를 계산하고 `rhs` 가 `self` 의 비트 수보다 크거나 같으면 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 오른쪽으로 시프트를 확인했습니다.
        /// `self >> rhs` 를 계산하고 `rhs` 가 `self` 의 비트 수보다 크거나 같으면 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 지수를 확인했습니다.
        /// `self.pow(exp)` 를 계산하고 오버플로가 발생하면 `None` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 이후, 마지막으로 exp는 1이어야합니다.
            // 나중에 밑을 제곱 할 필요가없고 불필요한 오버플로가 발생할 수 있으므로 지수의 마지막 비트를 별도로 처리합니다.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// 포화 정수 더하기.
        /// 오버플로 대신 숫자 경계에서 포화 상태 인 `self + rhs` 를 계산합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// 포화 정수 빼기.
        /// 오버플로 대신 숫자 경계에서 포화 상태 인 `self - rhs` 를 계산합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// 포화 정수 곱셈.
        /// 오버플로 대신 숫자 경계에서 포화 상태 인 `self * rhs` 를 계산합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// 포화 정수 지수.
        /// 오버플로 대신 숫자 경계에서 포화 상태 인 `self.pow(exp)` 를 계산합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) 추가 래핑.
        /// `self + rhs` 를 계산하여 형식의 경계를 감싸줍니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) 빼기를 래핑합니다.
        /// `self - rhs` 를 계산하여 형식의 경계를 감싸줍니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) 곱셈을 래핑합니다.
        /// `self * rhs` 를 계산하여 형식의 경계를 감싸줍니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// 이 예제는 정수 유형간에 공유됩니다.
        /// 여기서 `u8` 가 사용되는 이유를 설명합니다.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) 분할을 래핑합니다.`self / rhs` 를 계산합니다.
        /// 부호없는 유형의 래핑 된 분할은 일반 분할입니다.
        /// 포장이 일어날 수있는 방법은 없습니다.
        /// 이 기능이 존재하므로 모든 작업이 래핑 작업에 포함됩니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// 유클리드 분할 포장.`self.div_euclid(rhs)` 를 계산합니다.
        /// 부호없는 유형의 래핑 된 분할은 일반 분할입니다.
        /// 포장이 일어날 수있는 방법은 없습니다.
        /// 이 기능이 존재하므로 모든 작업이 래핑 작업에 포함됩니다.
        /// 양의 정수의 경우 모든 일반적인 나누기 정의가 동일하므로 `self.wrapping_div(rhs)` 와 정확히 동일합니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) 나머지를 래핑합니다.`self % rhs` 를 계산합니다.
        /// 부호없는 형식에 대한 래핑 된 나머지 계산은 일반 나머지 계산 일뿐입니다.
        ///
        /// 포장이 일어날 수있는 방법은 없습니다.
        /// 이 기능이 존재하므로 모든 작업이 래핑 작업에 포함됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// 유클리드 모듈로 감싸기.`self.rem_euclid(rhs)` 를 계산합니다.
        /// 부호없는 유형에 대한 래핑 된 모듈로 계산은 일반 나머지 계산 일뿐입니다.
        /// 포장이 일어날 수있는 방법은 없습니다.
        /// 이 기능이 존재하므로 모든 작업이 래핑 작업에 포함됩니다.
        /// 양의 정수의 경우 모든 일반적인 나누기 정의가 동일하므로 `self.wrapping_rem(rhs)` 와 정확히 동일합니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) 부정을 래핑합니다.
        /// `-self` 를 계산하여 형식의 경계를 감싸줍니다.
        ///
        /// unsigned 타입은 음수 등가물을 갖지 않기 때문에이 함수의 모든 응용 프로그램은 랩핑됩니다 (`-0` 제외).
        /// 해당 부호있는 유형의 최대 값보다 작은 값의 경우 결과는 해당 부호있는 값을 캐스팅하는 것과 동일합니다.
        ///
        /// 더 큰 값은 `MAX + 1 - (val - MAX - 1)` 와 동일하며 여기서 `MAX` 는 해당 부호있는 유형의 최대 값입니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// 이 예제는 정수 유형간에 공유됩니다.
        /// 여기서 `i8` 가 사용되는 이유를 설명합니다.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;
        /// `self << mask(rhs)` 를 생성합니다. 여기서 `mask` 는 이동이 유형의 비트 폭을 초과하도록하는 `rhs` 의 상위 비트를 제거합니다.
        ///
        /// 이것은 왼쪽 회전과 동일하지 *않습니다*.래핑 왼쪽 시프트의 RHS는 LHS에서 시프트 된 비트가 다른 쪽 끝으로 반환되는 것이 아니라 유형의 범위로 제한됩니다.
        /// 프리미티브 정수 유형은 모두 [`rotate_left`](Self::rotate_left) 함수를 구현하며 대신 원하는 것일 수 있습니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // 안전: 유형의 비트 크기에 의한 마스킹은 우리가 이동하지 않도록 보장합니다.
            // 출입 금지 구역의
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-free bitwise shift-right;
        /// `self >> mask(rhs)` 를 생성합니다. 여기서 `mask` 는 이동이 유형의 비트 폭을 초과하도록하는 `rhs` 의 상위 비트를 제거합니다.
        ///
        /// 이것은 오른쪽 회전과 동일하지 *않습니다*.래핑 오른쪽 시프트의 RHS는 LHS에서 시프트 된 비트가 다른 쪽 끝으로 반환되는 것이 아니라 유형의 범위로 제한됩니다.
        /// 프리미티브 정수 유형은 모두 [`rotate_right`](Self::rotate_right) 함수를 구현하며 대신 원하는 것일 수 있습니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // 안전: 유형의 비트 크기에 의한 마스킹은 우리가 이동하지 않도록 보장합니다.
            // 출입 금지 구역의
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) 지수를 래핑합니다.
        /// `self.pow(exp)` 를 계산하여 형식의 경계를 감싸줍니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 이후, 마지막으로 exp는 1이어야합니다.
            // 나중에 밑을 제곱 할 필요가없고 불필요한 오버플로가 발생할 수 있으므로 지수의 마지막 비트를 별도로 처리합니다.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` 를 계산합니다.
        ///
        /// 산술 오버플로가 발생하는지 여부를 나타내는 부울과 함께 더하기의 튜플을 반환합니다.
        /// 오버플로가 발생하면 래핑 된 값이 반환됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` 를 계산합니다.
        ///
        /// 산술 오버플로가 발생하는지 여부를 나타내는 부울과 함께 빼기의 튜플을 반환합니다.
        /// 오버플로가 발생하면 래핑 된 값이 반환됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` 와 `rhs` 의 곱셈을 계산합니다.
        ///
        /// 산술 오버플로가 발생하는지 여부를 나타내는 부울과 함께 곱셈의 튜플을 반환합니다.
        /// 오버플로가 발생하면 래핑 된 값이 반환됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// 이 예제는 정수 유형간에 공유됩니다.
        /// 여기서 `u32` 가 사용되는 이유를 설명합니다.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` 를 `rhs` 로 나눌 때 제수를 계산합니다.
        ///
        /// 산술 오버플로가 발생하는지 여부를 나타내는 부울과 함께 제수 튜플을 반환합니다.
        /// 부호없는 정수의 경우 오버플로가 발생하지 않으므로 두 번째 값은 항상 `false` 입니다.
        ///
        /// # Panics
        ///
        /// 이 기능은 `rhs` 가 0이면 panic 가됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// 유클리드 나눗셈 `self.div_euclid(rhs)` 의 몫을 계산합니다.
        ///
        /// 산술 오버플로가 발생하는지 여부를 나타내는 부울과 함께 제수 튜플을 반환합니다.
        /// 부호없는 정수의 경우 오버플로가 발생하지 않으므로 두 번째 값은 항상 `false` 입니다.
        /// 양의 정수의 경우 모든 일반적인 나누기 정의가 동일하므로 `self.overflowing_div(rhs)` 와 정확히 동일합니다.
        ///
        ///
        /// # Panics
        ///
        /// 이 기능은 `rhs` 가 0이면 panic 가됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` 를 `rhs` 로 나눌 때 나머지를 계산합니다.
        ///
        /// 산술 오버플로가 발생할지 여부를 나타내는 부울과 함께 나눈 후 나머지 튜플을 반환합니다.
        /// 부호없는 정수의 경우 오버플로가 발생하지 않으므로 두 번째 값은 항상 `false` 입니다.
        ///
        /// # Panics
        ///
        /// 이 기능은 `rhs` 가 0이면 panic 가됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// 유클리드 나눗셈처럼 나머지 `self.rem_euclid(rhs)` 를 계산합니다.
        ///
        /// 산술 오버플로가 발생할지 여부를 나타내는 부울과 함께 나눈 후 모듈로의 튜플을 반환합니다.
        /// 부호없는 정수의 경우 오버플로가 발생하지 않으므로 두 번째 값은 항상 `false` 입니다.
        /// 양의 정수의 경우 모든 일반적인 나누기 정의가 동일하므로이 연산은 정확히 `self.overflowing_rem(rhs)` 와 같습니다.
        ///
        ///
        /// # Panics
        ///
        /// 이 기능은 `rhs` 가 0이면 panic 가됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// 넘쳐나는 방식으로 자신을 부정한다.
        ///
        /// 이 부호없는 값의 부정을 나타내는 값을 반환하는 래핑 작업을 사용하여 `!self + 1` 를 반환합니다.
        /// 양의 부호없는 값의 경우 오버플로가 항상 발생하지만 0을 부정하면 오버플로되지 않습니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` 비트만큼 왼쪽으로 이동합니다.
        ///
        /// 시프트 값이 비트 수보다 크거나 같은지 여부를 나타내는 부울과 함께 시프트 된 self 버전의 튜플을 반환합니다.
        /// 시프트 값이 너무 크면 값은 (N-1) 로 마스킹됩니다. 여기서 N은 비트 수이며이 값은 시프트를 수행하는 데 사용됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` 비트만큼 오른쪽으로 이동합니다.
        ///
        /// 시프트 값이 비트 수보다 크거나 같은지 여부를 나타내는 부울과 함께 시프트 된 self 버전의 튜플을 반환합니다.
        /// 시프트 값이 너무 크면 값은 (N-1) 로 마스킹됩니다. 여기서 N은 비트 수이며이 값은 시프트를 수행하는 데 사용됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// 제곱에 의한 지수를 사용하여 자아를 `exp` 의 거듭 제곱으로 올립니다.
        ///
        /// 오버플로 발생 여부를 나타내는 bool 와 함께 지수화의 튜플을 반환합니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, 참));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // overflowing_mul 결과를 저장하기위한 스크래치 공간.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 이후, 마지막으로 exp는 1이어야합니다.
            // 나중에 밑을 제곱 할 필요가없고 불필요한 오버플로가 발생할 수 있으므로 지수의 마지막 비트를 별도로 처리합니다.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// 제곱에 의한 지수를 사용하여 자아를 `exp` 의 거듭 제곱으로 올립니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 이후, 마지막으로 exp는 1이어야합니다.
            // 나중에 밑을 제곱 할 필요가없고 불필요한 오버플로가 발생할 수 있으므로 지수의 마지막 비트를 별도로 처리합니다.
            //
            //
            acc * base
        }

        /// 유클리드 분할을 수행합니다.
        ///
        /// 양의 정수의 경우 모든 일반적인 나누기 정의가 동일하므로 `self / rhs` 와 정확히 동일합니다.
        ///
        ///
        /// # Panics
        ///
        /// 이 기능은 `rhs` 가 0이면 panic 가됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` 의 최소 나머지를 계산합니다.
        ///
        /// 양의 정수의 경우 모든 일반적인 나누기 정의가 동일하므로 `self % rhs` 와 정확히 동일합니다.
        ///
        ///
        /// # Panics
        ///
        /// 이 기능은 `rhs` 가 0이면 panic 가됩니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// 일부 `k` 에 대해 `self == 2^k` 인 경우에만 `true` 를 반환합니다.
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // 다음 2의 거듭 제곱보다 1을 적게 반환합니다.
        // (8u8의 경우 2의 제곱은 8u8이고 6u8의 경우 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // 이 메서드는 `next_power_of_two` 오버플로 경우에서 대신 형식의 최대 값을 반환하고 0에 대해 0을 반환 할 수 있으므로 오버플로 할 수 없습니다.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // 안전: `p > 0` 이므로 선행 0으로 만 구성 될 수 없습니다.
            // 즉, 시프트는 항상 인바운드이며 일부 프로세서 (예: intel pre-haswell)는 인수가 0이 아닐 때 더 효율적인 ctlz 내장 함수를 사용합니다.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` 보다 크거나 같은 2의 최소 거듭 제곱을 반환합니다.
        ///
        /// 반환 값이 오버플로되면 (즉, `uN` 유형의 `self > (1 << (N-1))`) 디버그 모드에서는 panics 이고 릴리스 모드에서는 반환 값이 0으로 래핑됩니다 (메서드가 0을 반환 할 수있는 유일한 상황).
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` 보다 크거나 같은 2의 최소 거듭 제곱을 반환합니다.
        /// 다음 2의 거듭 제곱이 유형의 최대 값보다 크면 `None` 가 반환되고, 그렇지 않으면 2의 거듭 제곱이 `Some` 에 래핑됩니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` 보다 크거나 같은 2의 최소 거듭 제곱을 반환합니다.
        /// 다음 2의 거듭 제곱이 유형의 최대 값보다 크면 반환 값이 `0` 로 래핑됩니다.
        ///
        ///
        /// # Examples
        ///
        /// 기본 사용법 :
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// 이 정수의 메모리 표현을 빅 엔디안 (network) 바이트 순서의 바이트 배열로 반환합니다.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// 이 정수의 메모리 표현을 little-endian 바이트 순서의 바이트 배열로 반환합니다.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// 이 정수의 메모리 표현을 기본 바이트 순서의 바이트 배열로 반환합니다.
        ///
        /// 대상 플랫폼의 네이티브 엔디안이 사용되므로 이식 가능한 코드는 [`to_be_bytes`] 또는 [`to_le_bytes`] 를 대신 사용해야합니다.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     바이트, if cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // 안전: 정수는 평범한 오래된 데이터 유형이기 때문에 상수 소리가납니다.
        // 그것들을 바이트 배열로 변환
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // 안전: 정수는 평범한 오래된 데이터 유형이므로 항상 다음으로 변환 할 수 있습니다.
            // 바이트 배열
            unsafe { mem::transmute(self) }
        }

        /// 이 정수의 메모리 표현을 기본 바이트 순서의 바이트 배열로 반환합니다.
        ///
        ///
        /// [`to_ne_bytes`] 가능할 때마다 이것보다 선호되어야합니다.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     바이트, if cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // 안전: 정수는 평범한 오래된 데이터 유형이므로 항상 다음으로 변환 할 수 있습니다.
            // 바이트 배열
            unsafe { &*(self as *const Self as *const _) }
        }

        /// 빅 엔디안의 바이트 배열로 표현에서 네이티브 엔디안 정수 값을 만듭니다.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto 를 사용하십시오.
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * 입력=휴식;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// 리틀 엔디안의 바이트 배열로 표현에서 네이티브 엔디안 정수 값을 만듭니다.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto 를 사용하십시오.
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * 입력=휴식;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// 네이티브 엔디안의 바이트 배열로 메모리 표현에서 네이티브 엔디안 정수 값을 만듭니다.
        ///
        /// 대상 플랫폼의 네이티브 엔디안이 사용됨에 따라 이식 가능한 코드는 적절하게 [`from_be_bytes`] 또는 [`from_le_bytes`] 를 대신 사용하려고합니다.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto 를 사용하십시오.
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * 입력=휴식;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // 안전: 정수는 평범한 오래된 데이터 유형이기 때문에 상수 소리가납니다.
        // 그들에게 변환
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // 안전: 정수는 평범한 오래된 데이터 유형이므로 항상 변환 할 수 있습니다.
            unsafe { mem::transmute(bytes) }
        }

        /// 새 코드는 사용을 선호해야합니다
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// 이 정수형으로 나타낼 수있는 최소값을 리턴합니다.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// 새 코드는 사용을 선호해야합니다
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// 이 정수형으로 나타낼 수있는 가장 큰 값을 반환합니다.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}