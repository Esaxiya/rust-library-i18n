//! 정수 유형으로 변환하기위한 오류 유형.

use crate::convert::Infallible;
use crate::fmt;

/// 확인 된 정수 유형 변환이 실패 할 때 반환되는 오류 유형입니다.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` 가 `!` 의 별칭이 될 때 위의 `From<Infallible> for TryFromIntError` 와 같은 코드가 계속 작동하는지 확인하기 위해 강제보다는 일치시킵니다.
        //
        //
        match never {}
    }
}

/// 정수를 구문 분석 할 때 반환 될 수있는 오류입니다.
///
/// 이 오류는 [`i8::from_str_radix`] 와 같은 기본 정수 유형의 `from_str_radix()` 함수에 대한 오류 유형으로 사용됩니다.
///
/// # 잠재적 원인
///
/// 다른 원인 중에서 `ParseIntError` 는 문자열의 선행 또는 후행 공백으로 인해 발생할 수 있습니다 (예: 표준 입력에서 얻은 경우).
///
/// [`str::trim()`] 방법을 사용하면 구문 분석 전에 공백이 남지 않습니다.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// 정수 구문 분석 실패를 유발할 수있는 다양한 유형의 오류를 저장하는 열거 형입니다.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// 구문 분석중인 값이 비어 있습니다.
    ///
    /// 다른 원인 중에서도이 변형은 빈 문자열을 구문 분석 할 때 생성됩니다.
    Empty,
    /// 컨텍스트에 잘못된 숫자가 포함되어 있습니다.
    ///
    /// 다른 원인 중에서도이 변형은 ASCII가 아닌 문자가 포함 된 문자열을 구문 분석 할 때 생성됩니다.
    ///
    /// 이 변형은 `+` 또는 `-` 가 자체적으로 또는 숫자 중간에 문자열 내에서 잘못 배치 된 경우에도 생성됩니다.
    ///
    ///
    InvalidDigit,
    /// 정수가 너무 커서 대상 정수 유형에 저장할 수 없습니다.
    PosOverflow,
    /// 정수가 너무 작아 대상 정수 유형에 저장할 수 없습니다.
    NegOverflow,
    /// 값이 0이었습니다.
    ///
    /// 이 변형은 구문 분석 문자열의 값이 0 일 때 생성되며, 이는 0이 아닌 유형에 대해 불법입니다.
    ///
    Zero,
}

impl ParseIntError {
    /// 정수 구문 분석 실패의 자세한 원인을 출력합니다.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}