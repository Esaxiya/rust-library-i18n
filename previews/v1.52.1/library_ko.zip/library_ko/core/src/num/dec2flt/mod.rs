//! 10 진수 문자열을 IEEE 754 이진 부동 소수점 숫자로 변환합니다.
//!
//! # 문제 설명
//!
//! `12.34e56` 와 같은 10 진수 문자열이 제공됩니다.
//! 이 문자열은 정수 (`12`), 소수 (`34`) 및 지수 (`56`) 부분으로 구성됩니다.모든 부분은 선택 사항이며 누락 된 경우 0으로 해석됩니다.
//!
//! 10 진수 문자열의 정확한 값에 가장 가까운 IEEE 754 부동 소수점 숫자를 찾습니다.
//! 많은 십진 문자열이 2 진법으로 끝나는 표현이 없다는 것은 잘 알려져 있습니다. 그래서 우리는 마지막 자리에서 0.5 단위로 반올림합니다 (즉, 가능한 한).
//! 두 개의 연속 된 부동 소수점 사이의 정확히 중간에있는 소수 값인 동점은 은행원 반올림이라고도하는 반-짝수 전략으로 해결됩니다.
//!
//! 말할 필요도없이 이것은 구현 복잡성과 CPU주기 측면에서 매우 어렵습니다.
//!
//! # Implementation
//!
//! 첫째, 우리는 신호를 무시합니다.또는 변환 프로세스의 맨 처음에 제거하고 맨 끝에 다시 적용합니다.
//! 이것은 IEEE 플로트가 0을 중심으로 대칭이기 때문에 모든 edge 경우에 맞습니다. 1을 부정하면 단순히 첫 번째 비트를 뒤집습니다.
//!
//! 그런 다음 지수를 조정하여 소수점을 제거합니다. 개념적으로 `12.34e56` 는 `1234e54` 로 바뀌며 양의 정수 `f = 1234` 와 정수 `e = 54` 로 설명합니다.
//! `(f, e)` 표현은 구문 분석 단계를 지난 거의 모든 코드에서 사용됩니다.
//!
//! 그런 다음 기계 크기 정수와 작은 고정 크기 부동 소수점 숫자를 사용하여 점진적으로 더 일반적이고 값 비싼 특수 사례의 긴 체인을 시도합니다 (처음 `f32`/`f64`, 그다음 64 비트 유효 유형, `Fp`).
//!
//! 이 모든 것이 실패하면 우리는 총알을 깨물고 `f * 10^e` 를 완전히 계산하고 최상의 근사치를 반복적으로 검색하는 단순하지만 매우 느린 알고리즘에 의존합니다.
//!
//! 주로이 모듈과 하위 모듈은 다음에 설명 된 알고리즘을 구현합니다.
//! "How to Read Floating Point Numbers Accurately" 작성자: William D.
//! Clinger, 온라인 사용 가능 : <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! 또한 논문에서는 사용되지만 Rust (또는 적어도 코어에서는)에서 사용할 수없는 수많은 도우미 함수가 있습니다.
//! 우리의 버전은 오버플로와 언더 플로를 처리 할 필요성과 비정규 숫자를 처리하려는 욕구로 인해 추가로 복잡합니다.
//! Bellerophon 및 Algorithm R은 오버플로, 비정규 및 언더 플로 문제가 있습니다.
//! 입력이 임계 영역에 들어가기 훨씬 전에 보수적으로 알고리즘 M (논문의 섹션 8에 설명 된 수정 사항 포함)으로 전환합니다.
//!
//! 주의가 필요한 또 다른 측면은 거의 모든 기능이 매개 변수화되는``RawFloat ''trait 입니다.`f64` 로 구문 분석하고 결과를 `f32` 로 캐스팅하는 것으로 충분하다고 생각할 수 있습니다.
//! 불행히도 이것은 우리가 살고있는 세상이 아니며, 2 진법 또는 반올림을 사용하는 것과는 아무 관련이 없습니다.
//!
//! 예를 들어 두 개의 십진수와 네 개의 십진수가있는 십진수 유형을 나타내는 두 가지 유형 `d2` 및 `d4` 를 고려하고 "0.01499" 를 입력으로 취하십시오.반올림을 사용하겠습니다.
//! 십진수 두 자리로 직접 이동하면 `0.01` 가 제공되지만 먼저 네 자리로 반올림하면 `0.0150` 가되고 `0.02` 로 반올림됩니다.
//! 동일한 원칙이 다른 작업에도 적용됩니다. 0.5 ULP 정확도를 원하는 경우 *모든 작업* 을 전체 정밀도로 수행하고 한 번에 잘린 모든 비트를 고려하여 *정확히 한 번, 끝* 에서 반올림해야합니다.
//!
//! FIXME: 일부 코드 복제가 필요하지만 코드의 일부를 섞어서 더 적은 코드가 복제 될 수 있습니다.
//! 알고리즘의 대부분은 출력 할 부동 소수점 유형과 무관하거나 매개 변수로 전달할 수있는 몇 가지 상수에 대한 액세스 만 필요합니다.
//!
//! # Other
//!
//! 변환은 *절대* panic 이어야합니다.
//! 코드에 어설 션과 명시 적 panics 가 있지만 트리거되지 않아야하며 내부 온 전성 검사로만 사용됩니다.모든 panics 는 버그로 간주되어야합니다.
//!
//! 단위 테스트가 있지만 정확성을 보장하는 데 매우 부적절하며 가능한 오류의 작은 비율 만 다룹니다.
//! 훨씬 더 광범위한 테스트는 Python 스크립트로 `src/etc/test-float-parse` 디렉토리에 있습니다.
//!
//! 정수 오버플로에 대한 참고 사항: 이 파일의 많은 부분은 십진 지수 `e` 로 산술을 수행합니다.
//! 주로 소수점을 첫 번째 소수점 앞, 마지막 소수점 뒤 등으로 이동합니다.부주의하게하면 넘칠 수 있습니다.
//! 우리는 충분히 작은 지수만을 전달하기 위해 구문 분석 서브 모듈에 의존합니다. 여기서 "sufficient" 는 "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" 를 의미합니다.
//! 더 큰 지수가 허용되지만, 우리는 그것들로 산술을하지 않고 즉시 {positive,negative} {zero,infinity} 로 바뀝니다.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// 이 두 가지는 자체 테스트가 있습니다.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// 밑이 10 인 문자열을 부동 소수점으로 변환합니다.
            /// 선택적 십진수 지수를 허용합니다.
            ///
            /// 이 함수는 다음과 같은 문자열을받습니다.
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', 또는 동등하게 '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', 또는 동등하게 '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// 선행 및 후행 공백은 오류를 나타냅니다.
            ///
            /// # Grammar
            ///
            /// 다음 [EBNF] 문법을 준수하는 모든 문자열은 [`Ok`] 가 반환됩니다.
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # 알려진 버그
            ///
            /// 경우에 따라 유효한 부동 소수점을 만들어야하는 일부 문자열은 대신 오류를 반환합니다.
            /// 자세한 내용은 [issue #31407] 를 참조하십시오.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, 문자열
            ///
            /// # 반환 값
            ///
            /// `Err(ParseFloatError)` 문자열이 유효한 숫자를 나타내지 않은 경우.
            /// 그렇지 않으면 `Ok(n)` 입니다. 여기서 `n` 는 `src` 가 나타내는 부동 소수점 숫자입니다.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// float를 구문 분석 할 때 반환 될 수있는 오류입니다.
///
/// 이 오류는 [`f32`] 및 [`f64`] 에 대한 [`FromStr`] 구현의 오류 유형으로 사용됩니다.
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// 나머지를 검사하거나 유효성을 검사하지 않고 십진수 문자열을 부호와 나머지로 분할합니다.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // 문자열이 유효하지 않으면 부호를 사용하지 않으므로 여기서 유효성을 검사 할 필요가 없습니다.
        _ => (Sign::Positive, s),
    }
}

/// 10 진수 문자열을 부동 소수점 숫자로 변환합니다.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// 10 진수에서 부동 소수점으로의 변환을위한 주요 도구: 모든 전처리를 조정하고 어떤 알고리즘이 실제 변환을 수행해야하는지 파악합니다.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift 소수점.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40은 1280 비트로 제한되며 약 385 개의 십진수로 변환됩니다.
    // 이 값을 초과하면 충돌이 발생하므로 너무 가까워지기 전에 오류가 발생합니다 (10 ^ 10 이내).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // 이제 지수는 기본 알고리즘 전체에서 사용되는 16 비트에 확실히 맞습니다.
    let e = e as i16;
    // FIXME 이러한 경계는 다소 보수적입니다.
    // Bellerophon의 고장 모드를보다 신중하게 분석하면 더 많은 경우에이를 사용하여 엄청난 속도를 높일 수 있습니다.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// 쓰여진대로 이것은 잘못 최적화됩니다 (#27130 참조, 코드의 이전 버전을 참조 함).
// `inline(always)` 그에 대한 해결 방법입니다.
// 전체적으로 두 개의 호출 사이트 만 있으며 코드 크기를 악화시키지 않습니다.

/// 지수를 변경해야하는 경우에도 가능한 경우 0을 제거합니다.
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // 이 0을 트리밍해도 아무것도 변경되지 않지만 빠른 경로 (<15 자리)를 사용할 수 있습니다.
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // 0.0 ... x 및 x ... 0.0 형식의 숫자를 단순화하고 그에 따라 지수를 조정합니다.
    // 이것은 항상이기는 것은 아니지만 (일부 숫자를 빠른 경로에서 밀어 낼 수 있음) 다른 부분을 크게 단순화합니다 (특히 값의 크기와 비슷 함).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// 알고리즘 R과 알고리즘 M이 주어진 십진수에서 작업하는 동안 계산할 가장 큰 값의 (log10) 크기에 대한 빠른 상한값을 반환합니다.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // trivial_cases() 와 가장 극단적 인 입력을 필터링하는 파서 덕분에 여기서 오버플로에 대해 너무 걱정할 필요가 없습니다.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // e>=0 인 경우 두 알고리즘 모두 약 `f * 10^e` 를 계산합니다.
        // 알고리즘 R은이를 사용하여 복잡한 계산을 진행하지만 상한선에 대해서는이를 무시할 수 있습니다. 그 이유는 사전에 분수를 줄여주기 때문에 거기에 충분한 버퍼가 있습니다.
        //
        f_len + (e as u64)
    } else {
        // e <0이면 알고리즘 R은 거의 동일한 작업을 수행하지만 알고리즘 M은 다릅니다.
        // `f << k / 10^e` 가 범위 내 유효 값이되도록 양수 k를 찾으려고합니다.
        // 이것은 약 `2^53 *f* 10^e` <`10^17 *f* 10^e` 가됩니다.
        // 이를 트리거하는 하나의 입력은 0.33 ... 33 (375 x 3)입니다.
        f_len + e.unsigned_abs() + 17
    }
}

/// 소수점 이하 자릿수를 보지 않고도 명백한 오버플로 및 언더 플로를 감지합니다.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // 0이 있지만 simplify() 에 의해 제거되었습니다.
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // 이것은 ceil(log10(the real value)) 의 대략적인 근사치입니다.
    // 입력 길이가 (적어도 2 ^ 64에 비해) 작고 파서가 이미 절대 값이 10 ^ 18 (여전히 10 ^ 19 짧음)보다 큰 지수를 처리하기 때문에 여기서 오버플로에 대해 너무 걱정할 필요가 없습니다. 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}