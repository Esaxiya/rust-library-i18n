//! 메소드로 전환하기에는 너무 의미가없는 거물을위한 유틸리티 함수.

// FIXME 다른 모듈도 `core::num` 를 가져 오기 때문에이 모듈의 이름은 약간 아쉽습니다.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` 보다 중요하지 않은 모든 비트를 자르면 0.5 ULP보다 작거나 같거나 큰 상대 오류가 발생하는지 테스트합니다.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // 나머지 비트가 모두 0이면= 0.5 ULP, 그렇지 않으면> 0.5 비트가 더 이상 없으면 (half_bit==0) 아래에서도 Equal을 올바르게 반환합니다.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// 10 진수 만 포함 된 ASCII 문자열을 `u64` 로 변환합니다.
///
/// 오버플로 또는 유효하지 않은 문자에 대한 검사를 수행하지 않으므로 호출자가주의하지 않으면 결과는 가짜이며 panic 가 될 수 있습니다 (`unsafe` 는 아니지만).
/// 또한 빈 문자열은 0으로 처리됩니다.
/// 이 기능은
///
/// 1. `&[u8]` 에서 `FromStr` 를 사용하려면 `from_utf8_unchecked` 가 필요합니다.
/// 2. `integral.parse()` 와 `fractional.parse()` 의 결과를 함께 연결하는 것은이 전체 기능보다 더 복잡합니다.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII 숫자 문자열을 bignum으로 변환합니다.
///
/// `from_str_unchecked` 와 마찬가지로이 함수는 파서에 의존하여 숫자가 아닌 것을 걸러냅니다.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// bignum을 64 비트 정수로 풉니 다.숫자가 너무 큰 경우 Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// 비트 범위를 추출합니다.

/// 인덱스 0은 최하위 비트이며 범위는 평소와 같이 반쯤 열려 있습니다.
/// 반환 유형에 맞는 것보다 더 많은 비트를 추출하도록 요청받은 경우 Panics.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}