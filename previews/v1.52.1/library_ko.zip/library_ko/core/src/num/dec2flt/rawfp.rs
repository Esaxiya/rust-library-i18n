//! 양의 IEEE 754 부동 소수점에 대한 비트 조작.음수는 처리되지 않으며 처리 할 필요도 없습니다.
//! 일반 부동 소수점 수는 값이 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), 여기서 N은 비트 수)가되도록 (frac, exp)와 같은 표준 표현을 갖습니다.
//!
//! Subnormals은 약간 다르고 이상하지만 동일한 원칙이 적용됩니다.
//!
//! 그러나 여기서는 값이 f *가되도록 f가 양수인 (sig, k)로 표시합니다.
//! 2 <sup>e</sup> ."hidden bit" 를 명시 적으로 만드는 것 외에도 이것은 이른바 가수 이동에 의해 지수를 변경합니다.
//!
//! 달리 말하면 일반적으로 float는 (1) 로 작성되지만 여기서는 (2) 로 작성됩니다.
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1) 를 **분수 표현** 이라고하고 (2) 를 **적분 표현** 이라고합니다.
//!
//! 이 모듈의 많은 함수는 일반 숫자 만 처리합니다.dec2flt 루틴은 보수적으로 매우 작은 숫자와 매우 큰 숫자에 대해 보편적으로 정확한 느린 경로 (알고리즘 M)를 사용합니다.
//! 이 알고리즘은 비정규와 0을 처리하는 next_float() 만 필요합니다.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// 기본적으로 `f32` 및 `f64` 에 대한 모든 변환 코드를 복제하는 것을 방지하는 도우미 trait.
///
/// 이것이 필요한 이유는 상위 모듈의 문서 주석을 참조하십시오.
///
/// **절대** 다른 유형에 대해 구현하거나 dec2flt 모듈 외부에서 사용해서는 안됩니다.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` 및 `from_bits` 에서 사용하는 유형입니다.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// 정수로 원시 변환을 수행합니다.
    fn to_bits(self) -> Self::Bits;

    /// 정수에서 원시 변환을 수행합니다.
    fn from_bits(v: Self::Bits) -> Self;

    /// 이 숫자가 속하는 범주를 반환합니다.
    fn classify(self) -> FpCategory;

    /// 가수, 지수 및 부호를 정수로 반환합니다.
    fn integer_decode(self) -> (u64, i16, i8);

    /// 플로트를 디코딩합니다.
    fn unpack(self) -> Unpacked;

    /// 정확하게 표현할 수있는 작은 정수에서 캐스트합니다.
    /// Panic 정수를 표현할 수없는 경우이 모듈의 다른 코드는 이러한 일이 발생하지 않도록합니다.
    fn from_int(x: u64) -> Self;

    /// 미리 계산 된 테이블에서 값 10 <sup>e</sup> 를 가져옵니다.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` 의 경우 Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// 이름이 말하는 것.
    /// 내장 함수를 저글링하고 LLVM 상수가이를 접기를 바라는 것보다 하드 코딩하는 것이 더 쉽습니다.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // 오버플로 또는 0을 생성 할 수없는 입력의 소수 자릿수에 대한 보수적 경계
    /// 비정규.아마도 최대 정상 값의 십진수 지수이므로 이름입니다.
    const MAX_NORMAL_DIGITS: usize;

    /// 최상위 십진수가 이보다 큰 자릿값을 가질 때, 숫자는 확실히 무한대로 반올림됩니다.
    ///
    const INF_CUTOFF: i64;

    /// 최상위 십진수의 자리 값이 이보다 작 으면 숫자는 확실히 0으로 반올림됩니다.
    ///
    const ZERO_CUTOFF: i64;

    /// 지수의 비트 수입니다.
    const EXP_BITS: u8;

    /// 숨겨진 비트를 *포함* 하는 유효 숫자의 비트 수입니다.
    const SIG_BITS: u8;

    /// 숨겨진 비트를 *제외* 하는 유효 숫자의 비트 수입니다.
    const EXPLICIT_SIG_BITS: u8;

    /// 분수 표현의 최대 법적 지수입니다.
    const MAX_EXP: i16;

    /// 비정규를 제외한 분수 표현의 최소 법적 지수입니다.
    const MIN_EXP: i16;

    /// `MAX_EXP` 적분 표현, 즉 시프트가 적용된 경우.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` 인코딩 됨 (예: 오프셋 바이어스 사용)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` 적분 표현, 즉 시프트가 적용된 경우.
    const MIN_EXP_INT: i16;

    /// 적분 표현의 최대 정규화 된 유효 값입니다.
    const MAX_SIG: u64;

    /// 적분 표현의 최소 정규화 유의.
    const MIN_SIG: u64;
}

// 대부분 #34344 에 대한 해결 방법입니다.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// 가수, 지수 및 부호를 정수로 반환합니다.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // 지수 편향 + 가수 이동
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe는 `as` 가 모든 플랫폼에서 올바르게 반올림되는지 여부를 불확실합니다.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// 가수, 지수 및 부호를 정수로 반환합니다.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // 지수 편향 + 가수 이동
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe는 `as` 가 모든 플랫폼에서 올바르게 반올림되는지 여부를 불확실합니다.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` 를 가장 가까운 기계 부동 유형으로 변환합니다.
/// 비정상 결과를 처리하지 않습니다.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 비트이므로 xe는 63의 가수 시프트를가집니다.
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64 비트 유효 숫자를 반 짝수로 T::SIG_BITS 비트로 반올림합니다.
/// 지수 오버플로를 처리하지 않습니다.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // 가수 이동 조정
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// 정규화 된 숫자에 대한 `RawFloat::unpack()` 의 역.
/// Panics (유효 지수 또는 지수가 정규화 된 숫자에 유효하지 않은 경우)
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // 숨겨진 비트 제거
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // 지수 편향 및 가수 이동에 대한 지수 조정
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 부호 비트를 0 ("+") 로 남겨두면 숫자는 모두 양수
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// 비정규를 구성하십시오.가수 0이 허용되며 0을 구성합니다.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // 인코딩 된 지수는 0이고 부호 비트는 0이므로 비트를 재 해석하면됩니다.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp로 큰 숫자를 근사합니다.반-짝수로 0.5 ULP 내에서 반올림합니다.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // 인덱스 `start` 이전의 모든 비트를 잘라냅니다. 즉, `start` 만큼 효과적으로 오른쪽으로 이동하므로 이것이 필요한 지수이기도합니다.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // 잘린 비트에 따라 (half-to-even) 를 반올림합니다.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// 인수보다 엄격하게 작은 가장 큰 부동 소수점 수를 찾습니다.
/// 비정규, 0 또는 지수 언더 플로를 처리하지 않습니다.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// 인수보다 엄격하게 큰 가장 작은 부동 소수점 수를 찾습니다.
// 이 연산은 포화 상태입니다. 즉, next_float(inf) ==inf입니다.
// 이 모듈의 대부분의 코드와 달리이 함수는 0, 비정규 및 무한을 처리합니다.
// 그러나 여기에있는 다른 모든 코드와 마찬가지로 NaN 및 음수를 처리하지 않습니다.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // 사실이라고하기에는 너무 좋아 보이지만 작동합니다.
        // 0.0 모두 0 단어로 인코딩됩니다.Subnormals는 0x000m ... m입니다. 여기서 m은 가수입니다.
        // 특히, 가장 작은 비정규는 0x0 ... 01이고 가장 큰 것은 0x000F ... F입니다.
        // 가장 작은 일반 숫자는 0x0010 ... 0이므로이 코너 케이스도 작동합니다.
        // 증가가 가수를 넘치면 캐리 비트는 우리가 원하는대로 지수를 증가시키고 가수 비트는 0이됩니다.
        // 숨겨진 비트 규칙 때문에 이것도 우리가 원하는 것입니다!
        // 마지막으로 f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY 입니다.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}