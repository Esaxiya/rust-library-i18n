//! 다음 형식의 10 진수 문자열 유효성 검사 및 분해 :
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! 즉, 부호 없음, "inf" 및 "NaN" 처리 없음의 두 가지 예외가있는 표준 부동 소수점 구문입니다.이들은 드라이버 기능 (super::dec2flt) 에 의해 처리됩니다.
//!
//! 유효한 입력을 인식하는 것은 비교적 쉽지만이 모듈은 또한 panic 가 아닌 수많은 잘못된 변형을 거부하고 다른 모듈이 panic (또는 오버플로)가 아닌 것에 의존하는 수많은 검사를 수행해야합니다.
//!
//! 설상가상으로 입력에 대한 단일 패스에서 모든 일이 발생합니다.
//! 따라서 수정시주의하고 다른 모듈을 다시 확인하십시오.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// 10 진수 문자열의 흥미로운 부분.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// 십진수 지수로, 십진수 18 개 미만이 보장됩니다.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// 입력 문자열이 유효한 부동 소수점 숫자인지 확인하고 그렇다면 정수 부분, 소수 부분 및 지수를 찾습니다.
/// 표지판을 다루지 않습니다.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' 앞에 숫자가 없습니다.
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // 포인트 전후에 최소 한 자리 숫자가 필요합니다.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // 분수 부분 후 후행 정크
            }
        }
        _ => Invalid, // 첫 번째 숫자 문자열 뒤의 정크
    }
}

/// 숫자가 아닌 첫 번째 문자까지 십진수를 자릅니다.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// 지수 추출 및 오류 검사.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // 지수 후 후행 정크
    }
    if number.is_empty() {
        return Invalid; // 빈 지수
    }
    // 이 시점에서 우리는 확실히 유효한 숫자 문자열을 가지고 있습니다.`i64` 에 넣기에는 너무 길 수 있지만, 그렇게 크면 입력은 확실히 0 또는 무한대입니다.
    // 10 진수 숫자의 각 0은 지수를 +/-1만큼만 조정하므로 exp=10 ^ 18에서 입력은 0의 17 엑사 바이트 (!) 이어야 원격으로 유한에 가까워집니다.
    //
    // 이것은 우리가 수용해야하는 사용 사례가 아닙니다.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}