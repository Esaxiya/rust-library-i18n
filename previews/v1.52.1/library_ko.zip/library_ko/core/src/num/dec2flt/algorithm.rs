//! 논문의 다양한 알고리즘.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp의 유효 비트 수
const P: u32 = 64;

// *모든* 지수에 대한 최상의 근사값을 저장하기 만하면 변수 "h" 및 관련 조건을 생략 할 수 있습니다.
// 이것은 몇 킬로바이트의 공간에 대한 성능을 교환합니다.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// 대부분의 아키텍처에서 부동 소수점 연산에는 명시적인 비트 크기가 있으므로 계산의 정밀도는 연산별로 결정됩니다.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 에서 SSE/SSE2 확장을 사용할 수없는 경우 x87 FPU가 부동 작업에 사용됩니다.
// x87 FPU는 기본적으로 80 비트의 정밀도로 작동합니다. 즉, 작업이 80 비트로 반올림되어 값이 결국 다음과 같이 표현 될 때 이중 반올림이 발생합니다.
//
// 32/64 비트 부동 값.이를 극복하기 위해 계산이 원하는 정밀도로 수행되도록 FPU 제어 워드를 설정할 수 있습니다.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU 제어 단어의 원래 값을 보존하는 데 사용되는 구조로, 구조가 삭제 될 때 복원 될 수 있습니다.
    ///
    ///
    /// x87 FPU는 필드가 다음과 같은 16 비트 레지스터입니다.
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// 모든 필드에 대한 문서는 IA-32 Architectures Software Developer'sManual (Volume 1)에 있습니다.
    ///
    /// 다음 코드와 관련된 유일한 필드는 PC, Precision Control입니다.
    /// 이 필드는 FPU가 수행하는 작업의 정밀도를 결정합니다.
    /// 다음과 같이 설정할 수 있습니다.
    ///  - 0b00, 단 정밀도 즉, 32 비트
    ///  - 0b10, 배정 밀도 즉, 64 비트
    ///  - 0b11, 배정 밀도 즉, 80 비트 (기본 상태) 0b01 값은 예약되어 있으므로 사용해서는 안됩니다.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // 안전: `fldcw` 명령은 올바르게 작동 할 수 있도록 감사되었습니다.
        // 모든 `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM 8 및 LLVM 9를 지원하기 위해 ATT 구문을 사용하고 있습니다.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU의 정밀도 필드를 `T` 로 설정하고 `FPUControlWord` 를 반환합니다.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` 에 적합한 정밀 제어 필드의 값을 계산하십시오.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 비트
            8 => 0x0200, // 64 비트
            _ => 0x0300, // 기본값, 80 비트
        };

        // 제어 단어의 원래 값을 가져와 나중에 복원 할 수 있습니다. `FPUControlWord` 구조가 삭제되었을 때 안전: `fnstcw` 명령이 모든 `u16` 에서 올바르게 작동 할 수 있도록 감사되었습니다.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM 8 및 LLVM 9를 지원하기 위해 ATT 구문을 사용하고 있습니다.
                options(att_syntax, nostack),
            )
        }

        // 제어 단어를 원하는 정밀도로 설정하십시오.
        // 이는 이전 정밀도 (비트 8 및 9, 0x300)를 마스킹하고 위에서 계산 된 정밀도 플래그로 대체하여 수행됩니다.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// 기계 크기의 정수와 부동 소수점을 사용하는 Bellerophon의 빠른 경로.
///
/// 이것은 bignum을 구성하기 전에 시도 할 수 있도록 별도의 함수로 추출됩니다.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // 마지막에 가까운 MAX_SIG와 정확한 값을 비교합니다. 이것은 빠르고 저렴한 거부입니다 (또한 나머지 코드가 언더 플로에 대해 걱정하지 않아도됩니다).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // 빠른 경로는 중간 반올림없이 올바른 비트 수로 반올림되는 산술에 결정적으로 의존합니다.
    // x86 (SSE 또는 SSE2 제외)에서는 x87 FPU 스택의 정밀도를 변경하여 64/32 비트로 직접 반올림해야합니다.
    // `set_precision` 기능은 전역 상태 (x87 FPU의 제어 단어와 같은)를 변경하여 설정해야하는 아키텍처의 정밀도 설정을 처리합니다.
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // e <0 케이스는 다른 branch 로 접을 수 없습니다.
    // 음의 거듭 제곱은 반올림 된 이진 부분에서 반복되는 분수 부분을 생성하여 최종 결과에서 실제 (때로는 상당히 심각한!) 오류를 발생시킵니다.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon은 사소하지 않은 숫자 분석으로 정당화되는 사소한 코드입니다.
///
/// ``f ''를 64 비트 유효 값을 가진 부동 소수점으로 반올림하고 `10^e` 의 최적 근사값 (동일한 부동 소수점 형식)을 곱합니다.이것은 종종 정확한 결과를 얻기에 충분합니다.
/// 그러나 결과가 인접한 두 (ordinary) 부동 소수점 사이의 중간에 가까워지면 두 근사값을 곱한 복합 반올림 오류는 결과가 몇 비트 차이가 날 수 있음을 의미합니다.
/// 이런 일이 발생하면 반복 알고리즘 R이 문제를 해결합니다.
///
/// 손으로 물결 치는 "close to halfway" 는 종이의 수치 분석으로 정밀하게 만들어졌습니다.
/// Clinger의 말 :
///
/// > 최하위 비트 단위로 표현되는 슬롭은 오류에 대한 포괄적 인 경계입니다.
/// > f * 10 ^ e 근사값의 부동 소수점 계산 중에 누적됩니다.(슬롭은
/// > 실제 오류에 대한 경계는 아니지만 근사 z와
/// > p 비트의 유효 값을 사용하는 가장 좋은 근사값입니다.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) 케이스는 fast_path() 에 있습니다.
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // n 비트로 반올림 할 때 차이를 만들 수있을만큼 슬롭이 큽니까?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// `f * 10^e` 의 부동 소수점 근사치를 향상시키는 반복 알고리즘입니다.
///
/// 각 반복은 마지막 위치에서 하나의 단위를 더 가깝게 가져옵니다. 물론 `z0` 가 약간 꺼져 있으면 수렴하는 데 시간이 많이 걸립니다.
/// 운 좋게도 Bellerophon의 폴백으로 사용하면 시작 근사값이 최대 하나의 ULP만큼 떨어져 있습니다.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x / y` 가 정확히 `(f *10^e) / (m* 2^k)` 가되도록 양의 정수 `x`, `y` 를 찾습니다.
        // 이것은 `e` 와 `k` 의 부호를 다루는 것을 피할뿐만 아니라 `10^e` 와 `2^k` 에 공통된 두 제곱을 제거하여 숫자를 더 작게 만듭니다.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // 우리의 bignum은 음수를 지원하지 않기 때문에 약간 어색하게 작성되었으므로 절대 값 + 부호 정보를 사용합니다.
        // m_digits를 사용한 곱셈은 오버플로 할 수 없습니다.
        // `x` 또는 `y` 가 오버플로에 대해 걱정할 필요가있을만큼 충분히 크면 `make_ratio` 가 2 ^ 64 이상의 비율로 분수를 줄일만큼 충분히 큽니다.
        //
        //
        let (d2, d_negative) = if x >= y {
            // 더 이상 x가 필요하지 않고 clone() 를 저장하십시오.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // 여전히 y가 필요합니다. 사본을 만드십시오.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` 와 `y = m` 에서 `f` 는 평소와 같이 입력 십진 자릿수를 나타내고 `m` 는 부동 소수점 근사값의 유효 값을 나타내므로 비율 `x / y` 를 `(f *10^e) / (m* 2^k)` 와 같게 만드십시오. 둘 다 공통되는 2의 거듭 제곱만큼 감소 할 수 있습니다.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, 단 2의 제곱으로 분수를 줄이는 것을 제외하고는.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m 이것은 양의 `e` 와 음의 `k` 가 필요하기 때문에 오버플로 할 수 없습니다. 이는 1에 매우 가까운 값에서만 발생할 수 있습니다. 즉, `e` 와 `k` 는 비교적 작다는 것을 의미합니다.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k 이것도 오버플로 할 수 없습니다. 위를 참조하세요.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), 다시 2의 공통 거듭 제곱만큼 감소합니다.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// 개념적으로 알고리즘 M은 소수를 실수로 변환하는 가장 간단한 방법입니다.
///
/// 우리는 `f * 10^e` 와 동일한 비율을 형성 한 다음 유효한 float 유효 값을 제공 할 때까지 2의 거듭 제곱을 던집니다.
/// 이진 지수 `k` 는 분자 또는 분모에 2를 곱한 횟수입니다. 즉, 항상 `f *10^e` 가 `(u / v)* 2^k` 와 같습니다.
/// significand를 발견하면 나머지 부분을 검사하여 반올림하기 만하면됩니다.이 작업은 아래의 도우미 함수에서 수행됩니다.
///
///
/// 이 알고리즘은 `quick_start()` 에 설명 된 최적화를 사용하더라도 매우 느립니다.
/// 그러나 오버플로, 언더 플로 및 비정상 결과에 적응하는 것은 가장 간단한 알고리즘입니다.
/// 이 구현은 Bellerophon과 Algorithm R이 압도 될 때 이어집니다.
/// 언더 플로 및 오버플로를 감지하는 것은 쉽습니다. 비율은 여전히 범위 내에서 중요하지 않지만 minimum/maximum 지수에 도달했습니다.
/// 오버플로의 경우 단순히 무한대를 반환합니다.
///
/// 언더 플로와 비정규를 처리하는 것은 더 까다 롭습니다.
/// 한 가지 큰 문제는 최소 지수를 사용하는 경우 비율이 여전히 너무 클 수 있다는 것입니다.
/// 자세한 내용은 underflow() 를 참조하십시오.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME 가능한 최적화: 이중 반올림없이 만 여기서 fp_to_float(big_to_fp(u)) 와 동일한 작업을 수행 할 수 있도록 big_to_fp를 일반화합니다.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // 최소 지수에서 멈춰야합니다. `k < T::MIN_EXP_INT` 가 될 때까지 기다리면 2 배 차이가 날 것입니다.
            // 불행히도 이것은 우리가 최소 지수를 가진 특별한 경우의 일반 숫자를 의미합니다.
            // FIXME는 더 우아한 공식을 찾았지만 `tiny-pow10` 테스트를 실행하여 실제로 올바른지 확인하십시오!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// 비트 길이를 확인하여 대부분의 Algorithm M 반복을 건너 뜁니다.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // 비트 길이는 밑이 2 인 로그의 추정치이며 log(u / v) = log(u), log(v) 입니다.
    // 추정치는 최대 1만큼 떨어져 있지만 항상 과소 추정되므로 log(u) 및 log(v) 의 오류는 동일한 부호이고 취소됩니다 (둘 다 큰 경우).
    // 따라서 log(u / v) 의 오류도 최대 1입니다.
    // 목표 비율은 u/v 가 범위 내 유효 값에있는 비율입니다.따라서 종료 조건은 log2(u / v) 가 유효 비트, plus/minus 1입니다.
    // FIXME 두 번째 비트를 보면 추정치를 향상시키고 더 많은 분할을 피할 수 있습니다.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // 언더 플로 또는 비정상.주 기능에 맡기십시오.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // 과다.주 기능에 맡기십시오.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // 비율은 최소 지수가있는 범위 내 유효하지 않으므로 초과 비트를 반올림하고 그에 따라 지수를 조정해야합니다.
    // 이제 실제 값은 다음과 같습니다.
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q 잘림.(rem으로 표시)
    //
    // 따라서 반올림 된 비트가!= 0.5 ULP이면 자체적으로 반올림을 결정합니다.
    // 동일하고 나머지가 0이 아닌 경우에도 값을 반올림해야합니다.
    // 반올림 된 비트가 1/2 이고 나머지가 0 인 경우에만 반-짝수 상황이됩니다.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// 일반 반올림, 나머지 부분을 기준으로 반올림해야하므로 난독 화됩니다.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}