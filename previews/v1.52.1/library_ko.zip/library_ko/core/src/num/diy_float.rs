//! 확장 정밀도 "soft float", 내부 전용입니다.

// 이 모듈은 dec2flt 및 flt2dec 전용이며 coretest로 인해 공개됩니다.
// 안정화를위한 것이 아닙니다.
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// `f * 2^e` 를 나타내는 사용자 정의 64 비트 부동 소수점 유형입니다.
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// 정수 가수입니다.
    pub f: u64,
    /// 밑이 2 인 지수입니다.
    pub e: i16,
}

impl Fp {
    /// 자신과 `other` 의 올바로 반올림 된 곱을 반환합니다.
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// 결과 가수가 `2^63` 이상이되도록 자체 정규화합니다.
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// 공유 지수를 갖도록 자체적으로 정규화합니다.
    /// 지수를 감소시킬 수만있어 가수를 증가시킬 수 있습니다.
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}