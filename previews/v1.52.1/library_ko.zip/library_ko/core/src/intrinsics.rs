//! 컴파일러 내장 함수.
//!
//! 해당 정의는 `compiler/rustc_codegen_llvm/src/intrinsic.rs` 에 있습니다.
//! 해당 const 구현은 `compiler/rustc_mir/src/interpret/intrinsics.rs` 에 있습니다.
//!
//! # 상수 내장 함수
//!
//! Note: 내장 함수의 일관성에 대한 변경 사항은 언어 팀과 논의해야합니다.
//! 여기에는 constness의 안정성 변경이 포함됩니다.
//!
//! 컴파일 타임에 내장 함수를 사용하려면 <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> 에서 `compiler/rustc_mir/src/interpret/intrinsics.rs` 로 구현을 복사하고 내장 함수에 `#[rustc_const_unstable(feature = "foo", issue = "01234")]` 를 추가해야합니다.
//!
//!
//! 내장 함수가 `rustc_const_stable` 속성이있는 `const fn` 에서 사용되어야하는 경우 내장 속성도 `rustc_const_stable` 여야합니다.
//! 이러한 변경은 컴파일러 지원 없이는 사용자 코드에서 복제 할 수없는 언어로 기능을 베이크하므로 T-lang 협의없이 수행해서는 안됩니다.
//!
//! # Volatiles
//!
//! 휘발성 내장 함수는 I/O 메모리에서 작동하도록 의도 된 작업을 제공하며, 이는 다른 휘발성 내장 함수에서 컴파일러에 의해 재정렬되지 않도록 보장됩니다.[[volatile]] 에 대한 LLVM 문서를 참조하십시오.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! 원자 내장 함수는 가능한 여러 메모리 순서와 함께 기계어에 대한 공통 원자 연산을 제공합니다.그들은 C++ 11과 동일한 의미를 따릅니다.[[atomics]] 에 대한 LLVM 문서를 참조하십시오.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! 메모리 주문에 대한 간단한 복습 :
//!
//! * 획득, 자물쇠 획득을위한 장벽.후속 읽기 및 쓰기는 장벽 이후에 발생합니다.
//! * 잠금 해제를위한 장벽 인 해제.선행 읽기 및 쓰기는 장벽보다 먼저 발생합니다.
//! * 순차적으로 일관되고 순차적으로 일관된 작업이 순서대로 발생하도록 보장됩니다.이것은 원자 유형 작업을위한 표준 모드이며 Java 의 `volatile` 와 동일합니다.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// 이러한 가져 오기는 문서 내 링크를 단순화하는 데 사용됩니다.
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // 안전: `ptr::drop_in_place` 참조
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, 이러한 내장 함수는 `&` 또는 `&mut` 에 유효하지 않은 별칭 메모리를 변경하기 때문에 원시 포인터를 사용합니다.
    //

    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `success` 및 `failure` 매개 변수로 [`Ordering::SeqCst`] 를 전달하여 `compare_exchange` 메소드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    ///
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `success` 및 `failure` 매개 변수로 [`Ordering::Acquire`] 를 전달하여 `compare_exchange` 메소드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    ///
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `success` 로 전달하고 [`Ordering::Acquire`] 를 `failure` 매개 변수로 전달하여 `compare_exchange` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `success` 및 `failure` 매개 변수로 [`Ordering::Relaxed`] 를 전달하여 `compare_exchange` 메소드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    ///
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `success` 로 전달하고 [`Ordering::Acquire`] 를 `failure` 매개 변수로 전달하여 `compare_exchange` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `success` 및 `failure` 매개 변수로 [`Ordering::SeqCst`] 를 전달하여 `compare_exchange_weak` 메소드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    ///
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `success` 및 `failure` 매개 변수로 [`Ordering::Acquire`] 를 전달하여 `compare_exchange_weak` 메소드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    ///
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange_weak` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `success` 로 전달하고 [`Ordering::Acquire`] 를 `failure` 매개 변수로 전달하여 `compare_exchange_weak` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `success` 및 `failure` 매개 변수로 [`Ordering::Relaxed`] 를 전달하여 `compare_exchange_weak` 메소드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    ///
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange_weak` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `success` 로 전달하고 [`Ordering::Acquire`] 를 `failure` 매개 변수로 전달하여 `compare_exchange_weak` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange_weak` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 현재 값이 `old` 값과 동일한 경우 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `success` 로 전달하고 [`Ordering::Relaxed`] 를 `failure` 매개 변수로 전달하여 `compare_exchange_weak` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// 포인터의 현재 값을로드합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `load` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// 포인터의 현재 값을로드합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `load` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// 포인터의 현재 값을로드합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `load` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// 지정된 메모리 위치에 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `store` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// 지정된 메모리 위치에 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `store` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// 지정된 메모리 위치에 값을 저장합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `store` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// 지정된 메모리 위치에 값을 저장하고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `swap` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// 지정된 메모리 위치에 값을 저장하고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `swap` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 지정된 메모리 위치에 값을 저장하고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `swap` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 지정된 메모리 위치에 값을 저장하고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `swap` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 지정된 메모리 위치에 값을 저장하고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `swap` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 현재 값에 더하여 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_add` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에 더하여 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_add` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에 더하여 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_add` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에 더하여 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_add` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에 더하여 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_add` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 현재 값에서 빼고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_sub` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에서 빼고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_sub` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에서 빼고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_sub` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에서 빼고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_sub` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값에서 빼고 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_sub` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 비트 단위 및 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_and` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 및 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_and` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 및 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_and` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 및 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_and` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 및 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_and` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 현재 값이있는 비트 단위 nand, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_nand` 메서드를 통해 [`AtomicBool`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값이있는 비트 단위 nand, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_nand` 메서드를 통해 [`AtomicBool`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값이있는 비트 단위 nand, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_nand` 메서드를 통해 [`AtomicBool`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값이있는 비트 단위 nand, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_nand` 메서드를 통해 [`AtomicBool`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값이있는 비트 단위 nand, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_nand` 메서드를 통해 [`AtomicBool`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 비트 단위 또는 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_or` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 또는 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_or` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 또는 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_or` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 또는 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_or` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 비트 단위 또는 현재 값으로 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_or` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 현재 값으로 비트 xor, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_xor` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값으로 비트 xor, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_xor` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값으로 비트 xor, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_xor` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값으로 비트 xor, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_xor` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값으로 비트 xor, 이전 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_xor` 메서드를 통해 [`atomic`] 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 부호있는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호있는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호있는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호있는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 현재 값으로 최대.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 부호있는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호있는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호있는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호있는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호있는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호있는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 부호없는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최소값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_min` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 부호없는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 부호없는 비교를 사용하는 현재 값의 최대 값입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Relaxed`] 를 `order` 로 전달하여 `fetch_max` 메서드를 통해 [`atomic`] 부호없는 정수 유형에서 사용할 수 있습니다.
    /// 예를 들면 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` 내장 함수는 지원되는 경우 프리 페치 명령어를 삽입하기위한 코드 생성기에 대한 힌트입니다.그렇지 않으면 작동하지 않습니다.
    /// 프리 페치는 프로그램의 동작에 영향을주지 않지만 성능 특성을 변경할 수 있습니다.
    ///
    /// `locality` 인수는 상수 정수 여야하며 (0) (지역 없음)에서 (3) (캐시의 극히 로컬 유지)까지의 시간적 지역 지정자입니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` 내장 함수는 지원되는 경우 프리 페치 명령어를 삽입하기위한 코드 생성기에 대한 힌트입니다.그렇지 않으면 작동하지 않습니다.
    /// 프리 페치는 프로그램의 동작에 영향을주지 않지만 성능 특성을 변경할 수 있습니다.
    ///
    /// `locality` 인수는 상수 정수 여야하며 (0) (지역 없음)에서 (3) (캐시의 극히 로컬 유지)까지의 시간적 지역 지정자입니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` 내장 함수는 지원되는 경우 프리 페치 명령어를 삽입하기위한 코드 생성기에 대한 힌트입니다.그렇지 않으면 작동하지 않습니다.
    /// 프리 페치는 프로그램의 동작에 영향을주지 않지만 성능 특성을 변경할 수 있습니다.
    ///
    /// `locality` 인수는 상수 정수 여야하며 (0) (지역 없음)에서 (3) (캐시의 극히 로컬 유지)까지의 시간적 지역 지정자입니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` 내장 함수는 지원되는 경우 프리 페치 명령어를 삽입하기위한 코드 생성기에 대한 힌트입니다.그렇지 않으면 작동하지 않습니다.
    /// 프리 페치는 프로그램의 동작에 영향을주지 않지만 성능 특성을 변경할 수 있습니다.
    ///
    /// `locality` 인수는 상수 정수 여야하며 (0) (지역 없음)에서 (3) (캐시의 극히 로컬 유지)까지의 시간적 지역 지정자입니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// 원자 울타리.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 [`atomic::fence`] 에서 사용할 수 있습니다.
    ///
    ///
    pub fn atomic_fence();
    /// 원자 울타리.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 [`atomic::fence`] 에서 사용할 수 있습니다.
    ///
    ///
    pub fn atomic_fence_acq();
    /// 원자 울타리.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 [`atomic::fence`] 에서 사용할 수 있습니다.
    ///
    ///
    pub fn atomic_fence_rel();
    /// 원자 울타리.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 [`atomic::fence`] 에서 사용할 수 있습니다.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// 컴파일러 전용 메모리 장벽.
    ///
    /// 메모리 액세스는 컴파일러에 의해이 장벽을 넘어서 다시 정렬되지 않지만 이에 대한 명령은 생성되지 않습니다.
    /// 이는 신호 처리기와 상호 작용할 때와 같이 선점 될 수있는 동일한 스레드에서의 작업에 적합합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::SeqCst`] 를 `order` 로 전달하여 [`atomic::compiler_fence`] 에서 사용할 수 있습니다.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// 컴파일러 전용 메모리 장벽.
    ///
    /// 메모리 액세스는 컴파일러에 의해이 장벽을 넘어서 다시 정렬되지 않지만 이에 대한 명령은 생성되지 않습니다.
    /// 이는 신호 처리기와 상호 작용할 때와 같이 선점 될 수있는 동일한 스레드에서의 작업에 적합합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Acquire`] 를 `order` 로 전달하여 [`atomic::compiler_fence`] 에서 사용할 수 있습니다.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// 컴파일러 전용 메모리 장벽.
    ///
    /// 메모리 액세스는 컴파일러에 의해이 장벽을 넘어서 다시 정렬되지 않지만 이에 대한 명령은 생성되지 않습니다.
    /// 이는 신호 처리기와 상호 작용할 때와 같이 선점 될 수있는 동일한 스레드에서의 작업에 적합합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::Release`] 를 `order` 로 전달하여 [`atomic::compiler_fence`] 에서 사용할 수 있습니다.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// 컴파일러 전용 메모리 장벽.
    ///
    /// 메모리 액세스는 컴파일러에 의해이 장벽을 넘어서 다시 정렬되지 않지만 이에 대한 명령은 생성되지 않습니다.
    /// 이는 신호 처리기와 상호 작용할 때와 같이 선점 될 수있는 동일한 스레드에서의 작업에 적합합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`Ordering::AcqRel`] 를 `order` 로 전달하여 [`atomic::compiler_fence`] 에서 사용할 수 있습니다.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// 함수에 연결된 속성에서 의미를 파생하는 매직 내장.
    ///
    /// 예를 들어, 데이터 흐름은이를 사용하여 정적 어설 션을 삽입하므로 `rustc_peek(potentially_uninitialized)` 는 실제로 데이터 흐름이 제어 흐름의 해당 지점에서 초기화되지 않은 것으로 계산했는지 실제로 다시 확인합니다.
    ///
    ///
    /// 이 내장 함수는 컴파일러 외부에서 사용해서는 안됩니다.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// 프로세스 실행을 중단합니다.
    ///
    /// 이 작업의보다 사용자 친화적이고 안정적인 버전은 [`std::process::abort`](../../std/process/fn.abort.html) 입니다.
    ///
    pub fn abort() -> !;

    /// 코드의이 지점에 도달 할 수 없음을 옵티 마이저에 알려 추가 최적화를 가능하게합니다.
    ///
    /// NB, 이것은 `unreachable!()` 매크로와 매우 다릅니다. 매크로가 실행될 때 panics 가 실행되는 매크로와 달리이 함수가 표시된 코드에 도달하는 것은 *정의되지 않은 동작* 입니다.
    ///
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) 입니다.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// 조건이 항상 참임을 최적화 프로그램에 알립니다.
    /// 조건이 거짓이면 동작이 정의되지 않습니다.
    ///
    /// 이 내장 함수에 대한 코드는 생성되지 않지만 최적화 프로그램은 패스 사이에 코드 (및 조건)를 보존하려고 시도하므로 주변 코드의 최적화를 방해하고 성능이 저하 될 수 있습니다.
    /// 옵티마이 저가 자체적으로 불변을 발견 할 수 있거나 중요한 최적화를 활성화하지 않는 경우에는 사용하지 않아야합니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch 조건이 참일 가능성이 있다는 컴파일러에 대한 힌트입니다.
    /// 전달 된 값을 반환합니다.
    ///
    /// `if` 문 이외의 사용은 아마도 효과가 없을 것입니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch 조건이 거짓 일 가능성이 있다는 컴파일러에 대한 힌트입니다.
    /// 전달 된 값을 반환합니다.
    ///
    /// `if` 문 이외의 사용은 아마도 효과가 없을 것입니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// 디버거에서 검사하기 위해 중단 점 트랩을 실행합니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn breakpoint();

    /// 유형의 크기 (바이트)입니다.
    ///
    /// 보다 구체적으로 이것은 정렬 패딩을 포함하여 동일한 유형의 연속 항목 사이의 바이트 단위 오프셋입니다.
    ///
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::mem::size_of`](crate::mem::size_of) 입니다.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// 유형의 최소 정렬입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::mem::align_of`](crate::mem::align_of) 입니다.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// 유형의 기본 정렬입니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// 참조 된 값의 크기 (바이트)입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`mem::size_of_val`] 입니다.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// 참조 된 값의 필수 정렬입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::mem::align_of_val`](crate::mem::align_of_val) 입니다.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// 형식 이름이 포함 된 정적 문자열 조각을 가져옵니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::any::type_name`](crate::any::type_name) 입니다.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// 지정된 유형에 대해 전역 적으로 고유 한 식별자를 가져옵니다.
    /// 이 함수는 호출 된 crate 에 관계없이 유형에 대해 동일한 값을 반환합니다.
    ///
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::any::TypeId::of`](crate::any::TypeId::of) 입니다.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` 가 사람이 거주하지 않는 경우 실행할 수없는 안전하지 않은 기능에 대한 보호 :
    /// 이것은 정적으로 panic 이거나 아무것도하지 않을 것입니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` 가 제로 초기화를 허용하지 않는 경우 실행될 수없는 안전하지 않은 기능에 대한 가드: 이것은 panic 를 정적으로 수행하거나 아무것도 수행하지 않습니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn assert_zero_valid<T>();

    /// `T` 에 유효하지 않은 비트 패턴이있는 경우 실행할 수없는 안전하지 않은 기능에 대한 가드: panic 또는 아무 작업도하지 않습니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn assert_uninit_valid<T>();

    /// 호출 된 위치를 나타내는 정적 `Location` 에 대한 참조를 가져옵니다.
    ///
    /// 대신 [`core::panic::Location::caller`](crate::panic::Location::caller) 를 사용해보십시오.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// 드롭 글루를 실행하지 않고 값을 범위 밖으로 이동합니다.
    ///
    /// 이것은 [`mem::forget_unsized`] 에만 존재합니다.일반 `forget` 는 대신 `ManuallyDrop` 를 사용합니다.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// 한 유형의 값 비트를 다른 유형으로 재 해석합니다.
    ///
    /// 두 유형 모두 크기가 같아야합니다.
    /// 원본도 결과도 [invalid value](../../nomicon/what-unsafe-does.html) 가 아닐 수 있습니다.
    ///
    /// `transmute` 의미 적으로는 한 유형을 다른 유형으로 비트 단위로 이동하는 것과 같습니다.소스 값의 비트를 대상 값으로 복사 한 다음 원본을 잊습니다.
    /// `transmute_copy` 와 마찬가지로 C의 `memcpy` 와 동일합니다.
    ///
    /// `transmute` 는 값별 연산이므로 *변환 된 값 자체* 의 정렬은 문제가되지 않습니다.
    /// 다른 함수와 마찬가지로 컴파일러는 `T` 와 `U` 가 모두 올바르게 정렬되었는지 이미 확인합니다.
    /// 그러나 *다른 곳*(예: 포인터, 참조, 상자 등)을 가리키는 값을 변환 할 때 호출자는 가리키는 값의 적절한 정렬을 확인해야합니다.
    ///
    /// `transmute` **놀랍게도** 안전하지 않습니다.이 기능을 사용하여 [undefined behavior][ub] 를 발생시키는 방법에는 여러 가지가 있습니다.`transmute` 는 절대적인 최후의 수단이어야합니다.
    ///
    /// [nomicon](../../nomicon/transmutes.html) 에는 추가 문서가 있습니다.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` 가 정말 유용한 몇 가지가 있습니다.
    ///
    /// 포인터를 함수 포인터로 바꾸기.이것은 함수 포인터와 데이터 포인터의 크기가 다른 기계에 이식 할 수 *없습니다*.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// 수명 연장 또는 불변 수명 단축.이것은 매우 안전하지 않은 고급 Rust 입니다!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// 절망하지 마십시오. `transmute` 의 많은 용도는 다른 수단을 통해 달성 할 수 있습니다.
    /// 다음은보다 안전한 구조로 대체 할 수있는 `transmute` 의 일반적인 응용 프로그램입니다.
    ///
    /// 원시 bytes(`&[u8]`) 를 `u32`, `f64` 등으로 전환 :
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // 대신 `u32::from_ne_bytes` 사용
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // 또는 `u32::from_le_bytes` 또는 `u32::from_be_bytes` 를 사용하여 엔디안을 지정하십시오.
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// 포인터를 `usize` 로 바꾸기 :
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // 대신 `as` 캐스트 사용
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` 를 `&mut T` 로 전환 :
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // 대신 재 차입 사용
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` 를 `&mut U` 로 전환 :
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // 이제 `as` 를 합치고 재 차입합니다. `as` `as` 의 체인은 전이되지 않습니다.
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` 를 `&[u8]` 로 전환 :
    ///
    /// ```
    /// // 이것은 좋은 방법이 아닙니다.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // `str::as_bytes` 를 사용할 수 있습니다.
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // 또는 문자열 리터럴을 제어 할 수있는 경우 바이트 문자열을 사용하십시오.
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` 를 `Vec<Option<&T>>` 로 전환.
    ///
    /// 컨테이너 내용물의 내부 유형을 변환하려면 컨테이너의 불변성을 위반하지 않도록해야합니다.
    /// `Vec` 의 경우 이것은 내부 유형의 크기 *와 정렬* 이 모두 일치해야 함을 의미합니다.
    /// 다른 컨테이너는 유형, 정렬 또는 `TypeId` 의 크기에 의존 할 수 있습니다.이 경우 컨테이너 불변성을 위반하지 않고는 변환이 전혀 불가능합니다.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // 나중에 재사용 할 것이므로 vector 를 복제합니다.
    /// let v_clone = v_orig.clone();
    ///
    /// // transmute 사용: 이것은 `Vec` 의 지정되지 않은 데이터 레이아웃에 의존하며 이는 나쁜 생각이며 정의되지 않은 동작을 유발할 수 있습니다.
    /////
    /// // 그러나 사본이 아닙니다.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // 이것이 제안되고 안전한 방법입니다.
    /// // 그러나 전체 vector 를 새 배열로 복사합니다.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // 이것은 데이터 레이아웃에 의존하지 않고 "transmuting" a `Vec` 의 적절한 복사 금지, 안전하지 않은 방법입니다.
    /// // 문자 그대로 `transmute` 를 호출하는 대신 포인터 캐스트를 수행하지만 원래 내부 유형 (`&i32`) 를 새로운 (`Option<&i32>`) 로 변환하는 측면에서 모두 동일한 경고가 있습니다.
    /////
    /// // 위에 제공된 정보 외에도 [`from_raw_parts`] 문서를 참조하십시오.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts가 안정화되면 업데이트합니다.
    ///     // 원래 vector 가 삭제되지 않았는지 확인하십시오.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` 구현 :
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // 이를 수행하는 방법에는 여러 가지가 있으며 다음 (transmute) 방식에는 여러 가지 문제가 있습니다.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // 첫째: transmute는 형식에 안전하지 않습니다.그것이 확인하는 것은 T와
    ///         // U는 같은 크기입니다.
    ///         // 둘째, 바로 여기에 동일한 메모리를 가리키는 두 개의 가변 참조가 있습니다.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // 이것은 유형 안전 문제를 제거합니다.`&mut *` 는 `&mut T` 또는 `* mut T` 의 `&mut T` 를 *만* 제공합니다.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // 그러나 여전히 동일한 메모리를 가리키는 두 개의 변경 가능한 참조가 있습니다.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // 이것이 표준 라이브러리가하는 방법입니다.
    /// // 이런 식으로해야하는 경우 이것이 가장 좋은 방법입니다.
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // 이제 동일한 메모리를 가리키는 3 개의 가변 참조가 있습니다.`slice`, rvalue ret.0 및 rvalue ret.1.
    ///         // `slice` `let ptr = ...` 이후에는 사용되지 않으므로 "dead" 로 취급 할 수 있으므로 실제 변경 가능한 슬라이스는 두 개뿐입니다.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: 이것은 내장 const를 안정적으로 만들지 만 const fn에 몇 가지 사용자 정의 코드가 있습니다.
    // `const fn` 내에서 사용을 방지하는 검사.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` 로 지정된 실제 유형에 드롭 글루가 필요한 경우 `true` 를 반환합니다.`T` 에 제공된 실제 유형이 `Copy` 를 구현하는 경우 `false` 를 반환합니다.
    ///
    ///
    /// 실제 유형이 드롭 글루를 필요로하지 않거나 `Copy` 를 구현하지 않는 경우이 함수의 반환 값은 지정되지 않습니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`mem::needs_drop`](crate::mem::needs_drop) 입니다.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// 포인터에서 오프셋을 계산합니다.
    ///
    /// 변환은 앨리어싱 정보를 버리기 때문에 정수와의 변환을 피하기 위해 내장 함수로 구현됩니다.
    ///
    /// # Safety
    ///
    /// 시작 포인터와 결과 포인터는 모두 할당 된 개체의 끝을지나 1 바이트 또는 경계 내에 있어야합니다.
    /// 포인터가 범위를 벗어 났거나 산술 오버플로가 발생하면 반환 된 값을 더 사용하면 정의되지 않은 동작이 발생합니다.
    ///
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`pointer::offset`] 입니다.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// 포인터에서 오프셋을 계산하여 잠재적으로 래핑합니다.
    ///
    /// 이것은 변환이 특정 최적화를 금지하기 때문에 정수와의 변환을 피하기 위해 내장 함수로 구현됩니다.
    ///
    /// # Safety
    ///
    /// `offset` 내장 함수와 달리이 내장 함수는 결과 포인터가 할당 된 객체의 끝을 가리 키거나 1 바이트를지나도록 제한하지 않으며 2의 보수 산술로 래핑됩니다.
    /// 결과 값이 실제로 메모리에 액세스하는 데 사용할 수있는 것은 아닙니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`pointer::wrapping_offset`] 입니다.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` 크기와 정렬을 갖는 적절한 `llvm.memcpy.p0i8.0i8.*` 내장 함수와 동일합니다.
    ///
    /// `min_align_of::<T>()`
    ///
    /// 휘발성 매개 변수는 `true` 로 설정되어 있으므로 크기가 0이 아니면 최적화되지 않습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 적절한 `llvm.memmove.p0i8.0i8.*` 내장 함수와 동일하며 크기는 `count* size_of::<T>()` 이고 정렬은
    ///
    /// `min_align_of::<T>()`
    ///
    /// 휘발성 매개 변수는 `true` 로 설정되어 있으므로 크기가 0이 아니면 최적화되지 않습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 적절한 `llvm.memset.p0i8.*` 내장 함수와 동일하며 크기는 `count* size_of::<T>()` 이고 정렬은 `min_align_of::<T>()` 입니다.
    ///
    ///
    /// 휘발성 매개 변수는 `true` 로 설정되어 있으므로 크기가 0이 아니면 최적화되지 않습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` 포인터에서 휘발성로드를 수행합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::ptr::read_volatile`](crate::ptr::read_volatile) 입니다.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` 포인터에 휘발성 저장을 수행합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::ptr::write_volatile`](crate::ptr::write_volatile) 입니다.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` 포인터에서 휘발성로드를 수행합니다. 포인터를 정렬 할 필요가 없습니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` 포인터에 휘발성 저장을 수행합니다.
    /// 포인터를 정렬 할 필요는 없습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` 의 제곱근을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` 의 제곱근을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` 를 정수 거듭 제곱으로 올립니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` 를 정수 거듭 제곱으로 올립니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` 의 사인을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` 의 사인을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` 의 코사인을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` 의 코사인을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` 를 `f32` 거듭 제곱으로 올립니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` 를 `f64` 거듭 제곱으로 올립니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` 의 지수를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` 의 지수를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 2를 `f32` 의 거듭 제곱으로 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 2를 `f64` 의 거듭 제곱으로 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` 의 자연 로그를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` 의 자연 로그를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` 의 밑이 10 인 로그를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` 의 밑이 10 인 로그를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` 의 밑이 2 인 로그를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` 의 밑이 2 인 로그를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` 값에 대해 `a * b + c` 를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` 값에 대해 `a * b + c` 를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` 의 절대 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` 의 절대 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// 최소 2 개의 `f32` 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// 최소 2 개의 `f64` 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// 최대 2 개의 `f32` 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// 최대 2 개의 `f64` 값을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` 값에 대해 `y` 에서 `x` 로 부호를 복사합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` 값에 대해 `y` 에서 `x` 로 부호를 복사합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` 보다 작거나 같은 가장 큰 정수를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` 보다 작거나 같은 가장 큰 정수를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` 보다 크거나 같은 가장 작은 정수를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` 보다 크거나 같은 가장 작은 정수를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` 의 정수 부분을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` 의 정수 부분을 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// `f32` 에 가장 가까운 정수를 반환합니다.
    /// 인수가 정수가 아닌 경우 부정확 한 부동 소수점 예외가 발생할 수 있습니다.
    pub fn rintf32(x: f32) -> f32;
    /// `f64` 에 가장 가까운 정수를 반환합니다.
    /// 인수가 정수가 아닌 경우 부정확 한 부동 소수점 예외가 발생할 수 있습니다.
    pub fn rintf64(x: f64) -> f64;

    /// `f32` 에 가장 가까운 정수를 반환합니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn nearbyintf32(x: f32) -> f32;
    /// `f64` 에 가장 가까운 정수를 반환합니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn nearbyintf64(x: f64) -> f64;

    /// `f32` 에 가장 가까운 정수를 반환합니다.0에서 반올림합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// `f64` 에 가장 가까운 정수를 반환합니다.0에서 반올림합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// 대수 규칙을 기반으로 최적화를 허용하는 부동 추가.
    /// 입력이 유한하다고 가정 할 수 있습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// 대수 규칙을 기반으로 최적화를 허용하는 부동 빼기.
    /// 입력이 유한하다고 가정 할 수 있습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// 대수 규칙을 기반으로 최적화를 허용하는 부동 곱셈.
    /// 입력이 유한하다고 가정 할 수 있습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// 대수 규칙을 기반으로 최적화를 허용하는 부동 분할.
    /// 입력이 유한하다고 가정 할 수 있습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// 대수 규칙을 기반으로 최적화를 허용하는 부동 나머지.
    /// 입력이 유한하다고 가정 할 수 있습니다.
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// 범위를 벗어난 값에 대해 undef를 반환 할 수있는 LLVM의 fptoui/fptosi 로 변환합니다.
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] 및 [`f64::to_int_unchecked`] 로 안정화되었습니다.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// 정수형 `T` 에 설정된 비트 수를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `count_ones` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// 정수 유형 `T` 에서 선행 설정되지 않은 비트 (zeroes) 의 수를 리턴합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `leading_zeros` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// 값이 `0` 인 `x` 는 `T` 의 비트 폭을 반환합니다.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` 와 비슷하지만 값이 `0` 인 `x` 가 주어지면 `undef` 를 반환하므로 매우 안전하지 않습니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// 정수 유형 `T` 에서 후행 설정되지 않은 비트 (zeroes) 의 수를 리턴합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `trailing_zeros` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// 값이 `0` 인 `x` 는 `T` 의 비트 너비를 반환합니다.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` 와 비슷하지만 값이 `0` 인 `x` 가 주어지면 `undef` 를 반환하므로 매우 안전하지 않습니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// 정수 유형 `T` 의 바이트를 반전합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `swap_bytes` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// 정수 유형 `T` 의 비트를 반전합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `reverse_bits` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// 확인 된 정수 더하기를 수행합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `overflowing_add` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 확인 된 정수 빼기를 수행합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `overflowing_sub` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 확인 된 정수 곱셈을 수행합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `overflowing_mul` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 정확한 분할을 수행하여 `x % y != 0` 또는 `y == 0` 또는 `x == T::MIN && y == -1` 에서 정의되지 않은 동작이 발생합니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// 확인되지 않은 분할을 수행하여 `y == 0` 또는 `x == T::MIN && y == -1` 에서 정의되지 않은 동작이 발생합니다.
    ///
    ///
    /// 이 내장 함수에 대한 안전한 래퍼는 `checked_div` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// 확인되지 않은 분할의 나머지를 반환하여 `y == 0` 또는 `x == T::MIN && y == -1` 일 때 정의되지 않은 동작이 발생합니다.
    ///
    ///
    /// 이 내장 함수에 대한 안전한 래퍼는 `checked_rem` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// 확인되지 않은 왼쪽 시프트를 수행하여 `y < 0` 또는 `y >= N` 일 때 정의되지 않은 동작이 발생합니다. 여기서 N은 T의 너비 (비트)입니다.
    ///
    ///
    /// 이 내장 함수에 대한 안전한 래퍼는 `checked_shl` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// 확인되지 않은 오른쪽 시프트를 수행하여 `y < 0` 또는 `y >= N` 일 때 정의되지 않은 동작이 발생합니다. 여기서 N은 T의 너비 (비트)입니다.
    ///
    ///
    /// 이 내장 함수에 대한 안전한 래퍼는 `checked_shr` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// 확인되지 않은 추가의 결과를 반환하여 `x + y > T::MAX` 또는 `x + y < T::MIN` 일 때 정의되지 않은 동작이 발생합니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// 확인되지 않은 빼기의 결과를 반환하여 `x - y > T::MAX` 또는 `x - y < T::MIN` 일 때 정의되지 않은 동작이 발생합니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// 확인되지 않은 곱셈의 결과를 반환하여 `x *y > T::MAX` 또는 `x* y < T::MIN` 일 때 정의되지 않은 동작이 발생합니다.
    ///
    ///
    /// 이 내장 함수에는 안정적인 대응 항목이 없습니다.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// 왼쪽으로 회전을 수행합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `rotate_left` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// 오른쪽으로 회전을 수행합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `rotate_right` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (a + b) mod 2 <sup>N을</sup> 반환합니다. 여기서 N은 T의 너비 (비트)입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `wrapping_add` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (a, b) mod 2 <sup>N을</sup> 반환합니다. 여기서 N은 T의 너비 (비트)입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `wrapping_sub` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (a * b) mod 2 <sup>N을</sup> 반환합니다. 여기서 N은 T의 너비 (비트)입니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `wrapping_mul` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// 숫자 경계에서 포화 상태 인 `a + b` 를 계산합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `saturating_add` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// 숫자 경계에서 포화 상태 인 `a - b` 를 계산합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 `saturating_sub` 메서드를 통해 정수 프리미티브에서 사용할 수 있습니다.
    /// 예를 들면
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' 의 변형에 대한 판별 값을 반환합니다.
    /// `T` 에 판별자가 없으면 `0` 를 반환합니다.
    ///
    /// 이 내장 함수의 안정화 된 버전은 [`core::mem::discriminant`](crate::mem::discriminant) 입니다.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `usize` 로 캐스팅 된 `T` 유형의 변형 수를 반환합니다.
    /// `T` 에 변형이 없으면 `0` 를 반환합니다.무인 변종이 계산됩니다.
    ///
    /// 이 내장 함수의 안정화 될 버전은 [`mem::variant_count`] 입니다.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// 데이터 포인터 `data` 로 함수 포인터 `try_fn` 를 호출하는 Rust 의 "try catch" 구조.
    ///
    /// 세 번째 인수는 panic 가 발생하면 호출되는 함수입니다.
    /// 이 함수는 데이터 포인터와 포착 된 대상 특정 예외 개체에 대한 포인터를 사용합니다.
    ///
    /// 자세한 내용은 컴파일러의 소스와 std 의 catch 구현을 참조하세요.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM에 따라 `!nontemporal` 저장소를 내 보냅니다 (문서 참조).
    /// 아마도 안정되지 않을 것입니다.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// 자세한 내용은 `<*const T>::offset_from` 설명서를 참조하십시오.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// 자세한 내용은 `<*const T>::guaranteed_eq` 설명서를 참조하십시오.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// 자세한 내용은 `<*const T>::guaranteed_ne` 설명서를 참조하십시오.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// 컴파일 타임에 할당하십시오.런타임에 호출하면 안됩니다.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// 일부 함수는이 모듈에서 실수로 stable에서 사용할 수있게 되었기 때문에 여기에서 정의됩니다.
// <https://github.com/rust-lang/rust/issues/15702> 를 참조하십시오.
// (`transmute` 도이 범주에 속하지만 `T` 와 `U` 의 크기가 같은지 확인하기 때문에 포장 할 수 없습니다.)
//

/// `ptr` 가 `align_of::<T>()` 에 대해 제대로 정렬되었는지 확인합니다.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `src` 에서 `dst` 로 `count *size_of::<T>()` 바이트를 복사합니다.소스와 대상이 겹치지* 않아야 *합니다.
///
/// 겹칠 수있는 메모리 영역의 경우 대신 [`copy`] 를 사용하십시오.
///
/// `copy_nonoverlapping` 의미 적으로 C의 [`memcpy`] 와 동일하지만 인수 순서가 바뀝니다.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `src` `count * size_of::<T>()` 바이트 읽기의 경우 [valid] 여야합니다.
///
/// * `dst` `count * size_of::<T>()` 바이트 쓰기의 경우 [valid] 여야합니다.
///
/// * `src` 와 `dst` 는 모두 올바르게 정렬되어야합니다.
///
/// * 'count'크기로 `src` 에서 시작하는 메모리 영역 *
///   size_of: :<T>()`바이트는 같은 크기의 `dst` 에서 시작하는 메모리 영역과 겹치지 *않아야* 합니다.
///
/// [`read`] 와 마찬가지로 `copy_nonoverlapping` 는 `T` 가 [`Copy`] 인지 여부에 관계없이 `T` 의 비트 단위 복사본을 만듭니다.
/// `T` 가 [`Copy`] 가 아닌 경우 `*src` 에서 시작하는 영역과 `* dst` 에서 시작하는 영역의 값을 *둘 다* 사용하면 [violate memory safety][read-ownership] 가 가능합니다.
///
///
/// 효과적으로 복사 된 크기 (`count * size_of: :<T>()`)는 `0` 이고 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] 를 수동으로 구현합니다.
///
/// ```
/// use std::ptr;
///
/// /// `src` 의 모든 요소를 `dst` 로 이동하고 `src` 는 비워 둡니다.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` 에 모든 `src` 를 수용 할 수있는 충분한 용량이 있는지 확인하십시오.
///     dst.reserve(src_len);
///
///     unsafe {
///         // offset에 대한 호출은 `Vec` 가 `isize::MAX` 바이트 이상을 할당하지 않기 때문에 항상 안전합니다.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // 내용을 삭제하지 않고 `src` 를 자릅니다.
///         // panics 아래로 내려가는 경우 문제를 방지하기 위해 먼저이 작업을 수행합니다.
///         src.set_len(0);
///
///         // 변경 가능한 참조는 별칭을 사용하지 않기 때문에 두 영역은 겹칠 수 없으며 두 개의 다른 vectors 는 동일한 메모리를 소유 할 수 없습니다.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // 이제 `src` 의 내용을 보유하고 있음을 `dst` 에 알립니다.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: 런타임에만 이러한 검사를 수행하십시오.
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // codegen 영향을 작게 유지하기 위해 당황하지 않습니다.
        abort();
    }*/

    // 안전: `copy_nonoverlapping` 에 대한 안전 계약은
    // 발신자가지지합니다.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `src` 에서 `dst` 로 `count * size_of::<T>()` 바이트를 복사합니다.소스와 대상이 겹칠 수 있습니다.
///
/// 소스와 대상이 겹치지 *않는* 경우 [`copy_nonoverlapping`] 를 대신 사용할 수 있습니다.
///
/// `copy` 의미 적으로 C의 [`memmove`] 와 동일하지만 인수 순서가 바뀝니다.
/// 복사는 바이트가 `src` 에서 임시 배열로 복사 된 다음 배열에서 `dst` 로 복사 된 것처럼 발생합니다.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `src` `count * size_of::<T>()` 바이트 읽기의 경우 [valid] 여야합니다.
///
/// * `dst` `count * size_of::<T>()` 바이트 쓰기의 경우 [valid] 여야합니다.
///
/// * `src` 와 `dst` 는 모두 올바르게 정렬되어야합니다.
///
/// [`read`] 와 마찬가지로 `copy` 는 `T` 가 [`Copy`] 인지 여부에 관계없이 `T` 의 비트 단위 복사본을 만듭니다.
/// `T` 가 [`Copy`] 가 아닌 경우 `*src` 에서 시작하는 영역과 `* dst` 에서 시작하는 영역의 값을 모두 사용하여 [violate memory safety][read-ownership] 를 수행 할 수 있습니다.
///
///
/// 효과적으로 복사 된 크기 (`count * size_of: :<T>()`)는 `0` 이고 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 안전하지 않은 버퍼에서 Rust vector 를 효율적으로 만듭니다.
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` 0이 아닌 유형에 대해 올바르게 정렬되어야합니다.
/// /// * `ptr` `T` 유형의 `elts` 연속 요소 읽기에 유효해야합니다.
/// /// * 이러한 요소는 `T: Copy` 가 아니면이 함수를 호출 한 후에 사용해서는 안됩니다.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // 안전: 우리의 전제 조건은 소스가 정렬되고 유효한지 확인합니다.
///     // `Vec::with_capacity` 는 그것들을 쓸 수있는 사용 가능한 공간을 확보합니다.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // 안전: 우리는 이전에 이렇게 많은 용량으로 만들었습니다.
///     // 이전 `copy` 는 이러한 요소를 초기화했습니다.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: 런타임에만 이러한 검사를 수행하십시오.
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // codegen 영향을 작게 유지하기 위해 당황하지 않습니다.
        abort();
    }*/

    // 안전: `copy` 에 대한 안전 계약은 발신자가 지켜야합니다.
    unsafe { copy(src, dst, count) }
}

/// `dst` 에서 시작하는 `count * size_of::<T>()` 바이트의 메모리를 `val` 로 설정합니다.
///
/// `write_bytes` C의 [`memset`] 와 유사하지만 `count * size_of::<T>()` 바이트를 `val` 로 설정합니다.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `dst` `count * size_of::<T>()` 바이트 쓰기의 경우 [valid] 여야합니다.
///
/// * `dst` 제대로 정렬되어야합니다.
///
/// 또한 호출자는 지정된 메모리 영역에 `count * size_of::<T>()` 바이트를 쓰는 결과 `T` 의 유효한 값이 생성되는지 확인해야합니다.
/// 유효하지 않은 `T` 값을 포함하는 `T` 로 입력 된 메모리 영역을 사용하는 것은 정의되지 않은 동작입니다.
///
/// 효과적으로 복사 된 크기 (`count * size_of: :<T>()`)은 `0` 이고 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// 잘못된 값 생성 :
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // 널 포인터로 `Box<T>` 를 덮어 써 이전에 보유한 값을 누출합니다.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // 이 시점에서 `v` 를 사용하거나 삭제하면 정의되지 않은 동작이 발생합니다.
/// // drop(v); // ERROR
///
/// // `v` "uses" 유출조차도 정의되지 않은 동작입니다.
/// // mem::forget(v); // ERROR
///
/// // 사실 `v` 는 기본 유형 레이아웃 불변에 따라 유효하지 않으므로 *모든* 조작이 정의되지 않은 동작입니다.
/////
/// // 하자 v2 =v;//오류
///
/// unsafe {
///     // 대신 유효한 값을 입력하겠습니다.
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // 이제 상자는 괜찮아
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // 안전: `write_bytes` 에 대한 안전 계약은 발신자가 지켜야합니다.
    unsafe { write_bytes(dst, val, count) }
}