//! SipHash의 구현.

#![allow(deprecated)] // 이 모듈의 유형은 더 이상 사용되지 않습니다.

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash 1-3의 구현.
///
/// 이것은 현재 표준 라이브러리에서 사용하는 기본 해싱 함수입니다 (예: `collections::HashMap` 에서 기본적으로 사용).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash 2-4의 구현.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash 2-4의 구현.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash는 범용 해싱 기능으로, 좋은 속도로 실행되고 (Spooky 및 City와 경쟁적) 강력한 _keyed_ 해싱을 허용합니다.
///
/// 이를 통해 [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) 와 같은 강력한 RNG에서 해시 테이블에 키를 지정할 수 있습니다.
///
/// SipHash 알고리즘은 일반적으로 강력한 것으로 간주되지만 암호화 목적을위한 것은 아닙니다.
/// 따라서이 구현의 모든 암호화 용도는 _strongly discouraged_ 입니다.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // 처리 한 바이트 수
    state: State,  // 해시 상태
    tail: u64,     // 처리되지 않은 바이트 파일
    ntail: usize,  // tail의 유효한 바이트 수
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 및 v1, v3 는 알고리즘에서 쌍으로 표시되며 SipHash의 simd 구현은 v02 및 v13 의 vectors 를 사용합니다.
    //
    // 구조체에이 순서로 배치하면 컴파일러는 몇 가지 simd 최적화 만 선택할 수 있습니다.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE 순서로 바이트 스트림에서 원하는 유형의 정수를로드합니다.
/// `copy_nonoverlapping` 를 사용하여 컴파일러가 정렬되지 않은 주소에서로드하는 가장 효율적인 방법을 생성하도록합니다.
///
///
/// 안전하지 않은 이유: i..i+size_of(int_ty) 에서 확인되지 않은 인덱싱
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// 최대 7 바이트의 바이트 슬라이스를 사용하여 u64 를로드합니다.
/// 서투른 것처럼 보이지만 `load_int_le!` 를 통해 발생하는 `copy_nonoverlapping` 호출은 모두 크기가 고정되어 있으며 속도에 좋은 `memcpy` 호출을 피합니다.
///
///
/// 안전하지 않은 이유: 시작시 확인되지 않은 인덱싱 ..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // 출력 u64 의 현재 바이트 인덱스 (LSB에서)
    let mut out = 0;
    if i + 3 < len {
        // 안전: `i` 는 `len` 보다 클 수 없으며 발신자가 보증해야합니다.
        // 인덱스 start..start + len이 범위 내에 있음을 확인합니다.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // 안전: 위와 동일합니다.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // 안전: 위와 동일합니다.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 두 개의 초기 키가 0으로 설정된 새 `SipHasher` 를 만듭니다.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// 제공된 키에서 키가 지정된 `SipHasher` 를 만듭니다.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 두 개의 초기 키가 0으로 설정된 새 `SipHasher13` 를 만듭니다.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// 제공된 키에서 키가 지정된 `SipHasher13` 를 만듭니다.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: 정수 해싱 방법 (`write_u *`, `write_i*`)이 정의되지 않았습니다.
    // 이 유형을 위해.
    // 이를 추가하고 librustc_data_structures/sip128.rs 에서 `short_write` 구현을 복사 한 다음 `write_u *`/`write_i*` 메서드를 `SipHasher`, `SipHasher13` 및 `DefaultHasher` 에 추가 할 수 있습니다.
    //
    // 이렇게하면 일부 벤치 마크에서 컴파일 속도가 약간 느려지는 대신 해당 해시에 의한 정수 해싱 속도가 크게 향상됩니다.
    // 자세한 내용은 #69152 를 참조하십시오.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // 안전: `cmp::min(length, needed)` 는 `length` 를 초과하지 않음을 보장합니다.
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // 버퍼링 된 꼬리는 이제 플러시되고 새 입력을 처리합니다.
        let len = length - needed;
        let left = len & 0x7; // len % 8

        let mut i = needed;
        while i < len - left {
            // 안전: `len - left` 는 아래에있는 8의 가장 큰 배수이기 때문에
            // `len`, `i` 는 `needed` 에서 시작하고 `len` 는 `length - needed` 이므로 `i + 8` 는 `length` 보다 작거나 같음을 보장합니다.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // 안전: `i` 는 이제 `needed + len.div_euclid(8) * 8` 입니다.
        // 따라서 `i + left` = `needed + len` = `length`, 정의상 `msg.len()` 와 같습니다.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 두 개의 초기 키가 0으로 설정된 `Hasher<S>` 를 만듭니다.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}