use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` 의 초기화되지 않은 인스턴스를 생성하는 래퍼 유형입니다.
///
/// # 초기화 불변
///
/// 일반적으로 컴파일러는 변수 유형의 요구 사항에 따라 변수가 적절하게 초기화되었다고 가정합니다.예를 들어 참조 유형의 변수는 정렬되고 NULL이 아니어야합니다.
/// 이것은 안전하지 않은 코드에서도 *항상* 유지되어야하는 불변성입니다.
/// 결과적으로 참조 유형의 변수를 0으로 초기화하면 해당 참조가 메모리에 액세스하는 데 사용되는지 여부에 관계없이 즉시 [undefined behavior][ub] 가 발생합니다.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // 정의되지 않은 동작!⚠️
/// // `MaybeUninit<&i32>` 와 동등한 코드 :
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // 정의되지 않은 동작!⚠️
/// ```
///
/// 이는 런타임 검사 제거 및 `enum` 레이아웃 최적화와 같은 다양한 최적화를 위해 컴파일러에서 악용됩니다.
///
/// 마찬가지로, 완전히 초기화되지 않은 메모리에는 모든 콘텐츠가있을 수 있지만 `bool` 는 항상 `true` 또는 `false` 여야합니다.따라서 초기화되지 않은 `bool` 를 만드는 것은 정의되지 않은 동작입니다.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // 정의되지 않은 동작!⚠️
/// // `MaybeUninit<bool>` 와 동등한 코드 :
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // 정의되지 않은 동작!⚠️
/// ```
///
/// 또한 초기화되지 않은 메모리는 고정 된 값이 없다는 점에서 특별합니다 ("fixed" 는 "it won't change without being written to" 를 의미 함).초기화되지 않은 동일한 바이트를 여러 번 읽으면 다른 결과를 얻을 수 있습니다.
/// 따라서 변수에 정수 유형이 있더라도 변수에 초기화되지 않은 데이터가있는 정의되지 않은 동작이 있습니다. 그렇지 않으면 *고정* 비트 패턴을 보유 할 수 있습니다.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // 정의되지 않은 동작!⚠️
/// // `MaybeUninit<i32>` 와 동등한 코드 :
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // 정의되지 않은 동작!⚠️
/// ```
/// (초기화되지 않은 정수에 대한 규칙은 아직 완성되지 않았지만 완성되기 전까지는 피하는 것이 좋습니다.)
///
/// 또한 대부분의 유형에는 단순히 유형 수준에서 초기화 된 것으로 간주되는 것 이상의 추가 불변성이 있음을 기억하십시오.
/// 예를 들어 '1'로 초기화 된 [`Vec<T>`] 는 초기화 된 것으로 간주됩니다 (현재 구현에서 이것은 안정적인 보장을 구성하지 않음). 컴파일러가 이에 대해 알고있는 유일한 요구 사항은 데이터 포인터가 null이 아니어야한다는 것입니다.
/// 이러한 `Vec<T>` 를 생성한다고해서 *즉시* 정의되지 않은 동작이 발생하지는 않지만 가장 안전한 작업 (삭제 포함)으로 정의되지 않은 동작이 발생합니다.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` 안전하지 않은 코드가 초기화되지 않은 데이터를 처리 할 수 있도록합니다.
/// 여기에있는 데이터가 초기화되지 *않을* 수도 있음을 나타내는 컴파일러에 대한 신호입니다.
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // 명시 적으로 초기화되지 않은 참조를 만듭니다.
/// // 컴파일러는 `MaybeUninit<T>` 내부의 데이터가 유효하지 않을 수 있음을 알고 있으므로 이것은 UB가 아닙니다.
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // 유효한 값으로 설정하십시오.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // 초기화 된 데이터 추출-`x` 를 적절하게 초기화 한 *후* 에만 허용됩니다!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// 그러면 컴파일러는이 코드에 대해 잘못된 가정이나 최적화를하지 않는 것을 알고 있습니다.
///
/// `MaybeUninit<T>` 는 `Option<T>` 와 비슷하지만 런타임 추적 및 안전 검사가없는 것으로 생각할 수 있습니다.
///
/// ## out-pointers
///
/// `MaybeUninit<T>` 를 사용하여 "out-pointers" 를 구현할 수 있습니다. 함수에서 데이터를 반환하는 대신 결과를 저장할 일부 (uninitialized) 메모리에 대한 포인터를 전달합니다.
/// 이는 호출자가 결과가 저장되는 메모리가 할당되는 방식을 제어하는 것이 중요하고 불필요한 이동을 피하려는 경우 유용 할 수 있습니다.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` 중요한 것은 오래된 내용을 삭제하지 않습니다.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // 이제 `v` 가 초기화되었음을 알았습니다!이것은 또한 vector 가 제대로 삭제되었는지 확인합니다.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## 요소별로 배열 초기화
///
/// `MaybeUninit<T>` 요소별로 큰 배열을 초기화하는 데 사용할 수 있습니다.
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // 초기화되지 않은 `MaybeUninit` 배열을 만듭니다.
///     // `assume_init` 는 여기서 초기화했다고 주장하는 유형이 초기화가 필요없는`MaybeUninit`의 무리이기 때문에 안전합니다.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` 를 삭제해도 아무 효과가 없습니다.
///     // 따라서 `ptr::write` 대신 원시 포인터 할당을 사용하면 이전의 초기화되지 않은 값이 삭제되지 않습니다.
/////
///     // 또한이 루프 중에 panic 가 있으면 메모리 누수가 있지만 메모리 안전 문제는 없습니다.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // 모든 것이 초기화됩니다.
///     // 배열을 초기화 된 유형으로 변환합니다.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// 하위 수준 데이터 구조에서 찾을 수있는 부분적으로 초기화 된 배열로 작업 할 수도 있습니다.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // 초기화되지 않은 `MaybeUninit` 배열을 만듭니다.
/// // `assume_init` 는 여기서 초기화했다고 주장하는 유형이 초기화가 필요없는`MaybeUninit`의 무리이기 때문에 안전합니다.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // 우리가 할당 한 요소의 수를 세십시오.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // 배열의 각 항목에 대해 할당 한 경우 삭제합니다.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## 필드별로 구조체 초기화
///
/// `MaybeUninit<T>` 및 [`std::ptr::addr_of_mut`] 매크로를 사용하여 필드별로 구조체를 초기화 할 수 있습니다.
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` 필드 초기화
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` 필드 초기화 여기에 panic 가 있으면 `name` 필드의 `String` 가 누출됩니다.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // 모든 필드가 초기화되었으므로 `assume_init` 를 호출하여 초기화 된 Foo를 얻습니다.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` 와 동일한 크기, 정렬 및 ABI를 갖도록 보장됩니다.
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// 그러나 `MaybeUninit<T>` 를 *포함* 하는 유형이 반드시 동일한 레이아웃은 아닙니다.Rust 는 일반적으로 `T` 및 `U` 의 크기와 정렬이 동일하더라도 `Foo<T>` 의 필드가 `Foo<U>` 와 동일한 순서를 갖는다 고 보장하지 않습니다.
///
/// 또한 `MaybeUninit<T>` 에 대해 모든 비트 값이 유효하기 때문에 컴파일러는 non-zero/niche-filling 최적화를 적용 할 수 없으므로 잠재적으로 크기가 더 커집니다.
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` 가 FFI에 안전하면 `MaybeUninit<T>` 도 안전합니다.
///
/// `MaybeUninit` 는 `#[repr(transparent)]` (`T` 와 동일한 크기, 정렬 및 ABI를 보장 함을 나타냄)이지만 이전 경고를 변경하지 *않습니다*.
/// `Option<T>` `Option<MaybeUninit<T>>` 는 여전히 다른 크기를 가질 수 있으며 `T` 유형의 필드를 포함하는 유형은 해당 필드가 `MaybeUninit<T>` 인 경우와 다르게 레이아웃 (및 크기) 될 수 있습니다.
/// `MaybeUninit` 공용체 유형이고 공용체의 `#[repr(transparent)]` 는 불안정합니다 ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// 시간이 지남에 따라 조합에 대한 `#[repr(transparent)]` 의 정확한 보증은 발전 할 수 있으며 `MaybeUninit` 는 `#[repr(transparent)]` 로 유지되거나 유지되지 않을 수 있습니다.
/// 즉, `MaybeUninit<T>` 는 `T` 와 동일한 크기, 정렬 및 ABI를 *항상* 보장합니다.`MaybeUninit` 가 보증을 구현하는 방식이 발전 할 수 있다는 것입니다.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// 다른 유형을 포장 할 수 있도록 Lang 항목입니다.이것은 생성기에 유용합니다.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` 를 호출하지 않으면 충분히 초기화되었는지 알 수 없습니다.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// 주어진 값으로 초기화 된 새로운 `MaybeUninit<T>` 를 생성합니다.
    /// 이 함수의 반환 값에 대해 [`assume_init`] 를 호출하는 것이 안전합니다.
    ///
    /// `MaybeUninit<T>` 를 드롭하면`T`의 드롭 코드가 호출되지 않습니다.
    /// `T` 가 초기화 된 경우 삭제되었는지 확인하는 것은 귀하의 책임입니다.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// 초기화되지 않은 상태에서 새 `MaybeUninit<T>` 를 만듭니다.
    ///
    /// `MaybeUninit<T>` 를 드롭하면`T`의 드롭 코드가 호출되지 않습니다.
    /// `T` 가 초기화 된 경우 삭제되었는지 확인하는 것은 귀하의 책임입니다.
    ///
    /// 몇 가지 예는 [type-level documentation][MaybeUninit] 를 참조하십시오.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// 초기화되지 않은 상태에서 `MaybeUninit<T>` 항목의 새 배열을 만듭니다.
    ///
    /// Note: future Rust 버전에서는 배열 리터럴 구문이 [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) 를 허용 할 때이 메서드가 필요하지 않을 수 있습니다.
    ///
    /// 그러면 아래 예제에서 `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` 를 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// 실제로 읽은 데이터의 (아마도 더 작은) 조각을 반환합니다.
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // 안전: 초기화되지 않은 `[MaybeUninit<_>; LEN]` 가 유효합니다.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// 메모리가 `0` 바이트로 채워져 초기화되지 않은 상태에서 새 `MaybeUninit<T>` 를 만듭니다.이미 적절한 초기화를 수행하는지 여부는 `T` 에 따라 다릅니다.
    ///
    /// 예를 들어 `MaybeUninit<usize>::zeroed()` 는 초기화되지만 참조가 null이 아니어야하기 때문에 `MaybeUninit<&'static i32>::zeroed()` 는 초기화되지 않습니다.
    ///
    /// `MaybeUninit<T>` 를 드롭하면`T`의 드롭 코드가 호출되지 않습니다.
    /// `T` 가 초기화 된 경우 삭제되었는지 확인하는 것은 귀하의 책임입니다.
    ///
    /// # Example
    ///
    /// 이 함수의 올바른 사용법: 0으로 구조체 초기화. 여기서 구조체의 모든 필드는 비트 패턴 0을 유효한 값으로 유지할 수 있습니다.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// 이 함수의 *잘못된* 사용법: `0` 가 유형에 대해 유효한 비트 패턴이 아닐 때 `x.zeroed().assume_init()` 호출 :
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // 쌍 내에서 유효한 판별자가없는 `NotZero` 를 만듭니다.
    /// // 이것은 정의되지 않은 동작입니다.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // 안전: `u.as_mut_ptr()` 는 할당 된 메모리를 가리 킵니다.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` 의 값을 설정합니다.
    /// 이렇게하면 이전 값을 삭제하지 않고 덮어 쓰므로 소멸자 실행을 건너 뛰지 않으려면이 값을 두 번 사용하지 않도록주의하십시오.
    ///
    /// 편의를 위해 `self` 의 (안전하게 초기화 된) 내용에 대한 변경 가능한 참조도 반환합니다.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // 안전: 방금이 값을 초기화했습니다.
        unsafe { self.assume_init_mut() }
    }

    /// 포함 된 값에 대한 포인터를 가져옵니다.
    /// 이 포인터에서 읽거나 참조로 바꾸는 것은 `MaybeUninit<T>` 가 초기화되지 않는 한 정의되지 않은 동작입니다.
    /// 이 포인터 (non-transitively) 가 가리키는 메모리에 쓰는 것은 정의되지 않은 동작입니다 (`UnsafeCell<T>` 내부 제외).
    ///
    /// # Examples
    ///
    /// 이 방법의 올바른 사용법 :
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` 에 대한 참조를 만듭니다.초기화했기 때문에 괜찮습니다.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// 이 방법의 *잘못된* 사용법 :
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // 초기화되지 않은 vector 에 대한 참조를 만들었습니다!이것은 정의되지 않은 동작입니다.⚠️
    /// ```
    ///
    /// (초기화되지 않은 데이터에 대한 참조에 대한 규칙은 아직 확정되지 않았지만 완료되기 전까지는이를 피하는 것이 좋습니다.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` `ManuallyDrop` 는 모두 `repr(transparent)` 이므로 포인터를 캐스팅 할 수 있습니다.
        self as *const _ as *const T
    }

    /// 포함 된 값에 대한 변경 가능한 포인터를 가져옵니다.
    /// 이 포인터에서 읽거나 참조로 바꾸는 것은 `MaybeUninit<T>` 가 초기화되지 않는 한 정의되지 않은 동작입니다.
    ///
    /// # Examples
    ///
    /// 이 방법의 올바른 사용법 :
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` 에 대한 참조를 만듭니다.
    /// // 초기화했기 때문에 괜찮습니다.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// 이 방법의 *잘못된* 사용법 :
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // 초기화되지 않은 vector 에 대한 참조를 만들었습니다!이것은 정의되지 않은 동작입니다.⚠️
    /// ```
    ///
    /// (초기화되지 않은 데이터에 대한 참조에 대한 규칙은 아직 확정되지 않았지만 완료되기 전까지는이를 피하는 것이 좋습니다.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` `ManuallyDrop` 는 모두 `repr(transparent)` 이므로 포인터를 캐스팅 할 수 있습니다.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` 컨테이너에서 값을 추출합니다.결과 `T` 가 일반적인 드롭 처리를 따르기 때문에 이는 데이터가 삭제되도록하는 좋은 방법입니다.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` 가 실제로 초기화 된 상태에 있는지 확인하는 것은 호출자에게 달려 있습니다.콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 즉시 정의되지 않은 동작이 발생합니다.
    /// [type-level documentation][inv] 에는이 초기화 불변에 대한 자세한 정보가 포함되어 있습니다.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// 또한 대부분의 유형에는 단순히 유형 수준에서 초기화 된 것으로 간주되는 것 이상의 추가 불변성이 있음을 기억하십시오.
    /// 예를 들어 '1'로 초기화 된 [`Vec<T>`] 는 초기화 된 것으로 간주됩니다 (현재 구현에서 이것은 안정적인 보장을 구성하지 않음). 컴파일러가 이에 대해 알고있는 유일한 요구 사항은 데이터 포인터가 null이 아니어야한다는 것입니다.
    ///
    /// 이러한 `Vec<T>` 를 생성한다고해서 *즉시* 정의되지 않은 동작이 발생하지는 않지만 가장 안전한 작업 (삭제 포함)으로 정의되지 않은 동작이 발생합니다.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// 이 방법의 올바른 사용법 :
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// 이 방법의 *잘못된* 사용법 :
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` 아직 초기화되지 않았으므로이 마지막 줄은 정의되지 않은 동작을 유발했습니다.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // 안전: 호출자는 `self` 가 초기화되었는지 확인해야합니다.
        // 이것은 또한 `self` 가 `value` 변형이어야 함을 의미합니다.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` 컨테이너에서 값을 읽습니다.결과 `T` 는 일반적인 낙하 처리를 따릅니다.
    ///
    /// 가능하면 `MaybeUninit<T>` 의 내용이 복제되지 않도록 [`assume_init`] 를 대신 사용하는 것이 좋습니다.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` 가 실제로 초기화 된 상태에 있는지 확인하는 것은 호출자에게 달려 있습니다.콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 정의되지 않은 동작이 발생합니다.
    /// [type-level documentation][inv] 에는이 초기화 불변에 대한 자세한 정보가 포함되어 있습니다.
    ///
    /// 또한 `MaybeUninit<T>` 에 동일한 데이터의 복사본이 남습니다.
    /// 데이터의 여러 복사본을 사용하는 경우 (`assume_init_read` 를 여러 번 호출하거나 먼저 `assume_init_read` 를 호출 한 다음 [`assume_init`] 를 호출하여) 데이터가 실제로 복제 될 수 있는지 확인하는 것은 사용자의 책임입니다.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// 이 방법의 올바른 사용법 :
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` 이므로 여러 번 읽을 수 있습니다.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` 값을 복제하는 것은 괜찮으므로 여러 번 읽을 수 있습니다.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// 이 방법의 *잘못된* 사용법 :
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // 우리는 이제 동일한 vector 의 두 개의 복사본을 만들었고, 둘 다 떨어졌을 때 더블 프리 ⚠️로 이어졌습니다!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // 안전: 호출자는 `self` 가 초기화되었는지 확인해야합니다.
        // `self` 를 초기화해야하므로 `self.as_ptr()` 에서 읽는 것이 안전합니다.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// 포함 된 값을 제자리에 삭제합니다.
    ///
    /// `MaybeUninit` 의 소유권이있는 경우 대신 [`assume_init`] 를 사용할 수 있습니다.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` 가 실제로 초기화 된 상태에 있는지 확인하는 것은 호출자에게 달려 있습니다.콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 정의되지 않은 동작이 발생합니다.
    ///
    /// 또한 `T` (또는 그 멤버)의 `Drop` 구현이 이에 의존 할 수 있으므로 `T` 유형의 모든 추가 불변이 충족되어야합니다.
    /// 예를 들어 '1'로 초기화 된 [`Vec<T>`] 는 초기화 된 것으로 간주됩니다 (현재 구현에서 이것은 안정적인 보장을 구성하지 않음). 컴파일러가 이에 대해 알고있는 유일한 요구 사항은 데이터 포인터가 null이 아니어야한다는 것입니다.
    ///
    /// 그러나 이러한 `Vec<T>` 를 삭제하면 정의되지 않은 동작이 발생합니다.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // 안전: 호출자는 `self` 가 초기화되고
        // `T` 의 모든 불변을 충족합니다.
        // 이 경우 값을 제자리에 놓는 것이 안전합니다.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// 포함 된 값에 대한 공유 참조를 가져옵니다.
    ///
    /// 이것은 초기화되었지만 `MaybeUninit` 의 소유권이없는 `MaybeUninit` 에 액세스하려고 할 때 유용 할 수 있습니다 (`.assume_init()`) 의 사용 방지).
    ///
    /// # Safety
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 정의되지 않은 동작이 발생합니다. `MaybeUninit<T>` 가 실제로 초기화 된 상태에 있는지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ### 이 방법의 올바른 사용법 :
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` 초기화 :
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // 이제 `MaybeUninit<_>` 가 초기화 된 것으로 알려 졌으므로 이에 대한 공유 참조를 생성해도됩니다.
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // 안전: `x` 가 초기화되었습니다.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### 이 방법의 *잘못된* 사용법 :
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // 초기화되지 않은 vector 에 대한 참조를 만들었습니다!이것은 정의되지 않은 동작입니다.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` 를 사용하여 `MaybeUninit` 를 초기화합니다.
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // 초기화되지 않은 `Cell<bool>` 에 대한 참조: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // 안전: 호출자는 `self` 가 초기화되었는지 확인해야합니다.
        // 이것은 또한 `self` 가 `value` 변형이어야 함을 의미합니다.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// 포함 된 값에 대한 변경 가능한 (unique) 참조를 가져옵니다.
    ///
    /// 이것은 초기화되었지만 `MaybeUninit` 의 소유권이없는 `MaybeUninit` 에 액세스하려고 할 때 유용 할 수 있습니다 (`.assume_init()`) 의 사용 방지).
    ///
    /// # Safety
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 정의되지 않은 동작이 발생합니다. `MaybeUninit<T>` 가 실제로 초기화 된 상태에 있는지 확인하는 것은 호출자에게 달려 있습니다.
    /// 예를 들어, `.assume_init_mut()` 는 `MaybeUninit` 를 초기화하는 데 사용할 수 없습니다.
    ///
    /// # Examples
    ///
    /// ### 이 방법의 올바른 사용법 :
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// 입력 버퍼의 *모든* 바이트를 초기화합니다.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` 초기화 :
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // 이제 `buf` 가 초기화되었으므로 `.assume_init()` 를 수행 할 수 있습니다.
    /// // 그러나 `.assume_init()` 를 사용하면 2048 바이트의 `memcpy` 가 트리거 될 수 있습니다.
    /// // 버퍼를 복사하지 않고 초기화했음을 확인하기 위해 `&mut MaybeUninit<[u8; 2048]>` 를 `&mut [u8; 2048]` 로 업그레이드합니다.
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // 안전: `buf` 가 초기화되었습니다.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // 이제 `buf` 를 일반 슬라이스로 사용할 수 있습니다.
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### 이 방법의 *잘못된* 사용법 :
    ///
    /// `.assume_init_mut()` 를 사용하여 값을 초기화 할 수 없습니다.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // 초기화되지 않은 `bool` 에 대한 (mutable) 참조를 만들었습니다!
    ///     // 이것은 정의되지 않은 동작입니다.⚠️
    /// }
    /// ```
    ///
    /// 예를 들어, 초기화되지 않은 버퍼로 [`Read`] 를 실행할 수 없습니다.
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) 초기화되지 않은 메모리에 대한 참조!
    ///                             // 이것은 정의되지 않은 동작입니다.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// 직접 필드 액세스를 사용하여 필드 별 점진적 초기화를 수행 할 수도 없습니다.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) 초기화되지 않은 메모리에 대한 참조!
    ///                  // 이것은 정의되지 않은 동작입니다.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) 초기화되지 않은 메모리에 대한 참조!
    ///                  // 이것은 정의되지 않은 동작입니다.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): 우리는 현재 위의 내용이 부정확하다는 것에 의존합니다. 즉, 초기화되지 않은 데이터에 대한 참조가 있습니다 (예: `libcore/fmt/float.rs`).
    // 안정화 전에 규칙에 대한 최종 결정을 내려야합니다.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // 안전: 호출자는 `self` 가 초기화되었는지 확인해야합니다.
        // 이것은 또한 `self` 가 `value` 변형이어야 함을 의미합니다.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` 컨테이너 배열에서 값을 추출합니다.
    ///
    /// # Safety
    ///
    /// 배열의 모든 요소가 초기화 된 상태인지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // 안전: 이제 모든 요소를 초기화 했으므로 안전합니다.
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * 호출자는 배열의 모든 요소가 초기화되도록 보장합니다.
        // * `MaybeUninit<T>` T는 동일한 레이아웃을 갖도록 보장됩니다.
        // * MaybeUnint는 떨어지지 않기 때문에 double-free가 없으므로 변환이 안전합니다.
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// 모든 요소가 초기화되었다고 가정하고 슬라이스를 가져옵니다.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` 요소가 실제로 초기화 된 상태에 있는지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 정의되지 않은 동작이 발생합니다.
    ///
    /// 자세한 내용과 예는 [`assume_init_ref`] 를 참조하십시오.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // 안전: 슬라이스를 `*const [T]` 로 캐스팅하는 것은 호출자가
        // `slice` 초기화되고`MaybeUninit`는 `T` 와 동일한 레이아웃을 갖도록 보장됩니다.
        // 획득 한 포인터는 참조 인 `slice` 가 소유 한 메모리를 참조하므로 유효하므로 읽기에 유효합니다.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// 모든 요소가 초기화되었다고 가정하면 가변 슬라이스를 가져옵니다.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` 요소가 실제로 초기화 된 상태에 있는지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 정의되지 않은 동작이 발생합니다.
    ///
    /// 자세한 내용과 예는 [`assume_init_mut`] 를 참조하십시오.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // 안전: `slice_get_ref` 에 대한 안전 참고 사항과 유사하지만
        // 쓰기에도 유효 함이 보장되는 가변 참조.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// 배열의 첫 번째 요소에 대한 포인터를 가져옵니다.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// 배열의 첫 번째 요소에 대한 변경 가능한 포인터를 가져옵니다.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` 에서 `this` 로 요소를 복사하여 `this` 의 현재 초기화 된 내용에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// `T` 가 `Copy` 를 구현하지 않는 경우 [`write_slice_cloned`] 를 사용하십시오.
    ///
    /// 이것은 [`slice::copy_from_slice`] 와 유사합니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 두 슬라이스의 길이가 다른 경우 panic 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // 안전: 우리는 len의 모든 요소를 예비 용량에 복사했습니다.
    /// // vec의 첫 번째 src.len() 요소는 이제 유효합니다.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // 안전: &[T] 및&[MaybeUninit<T>] 레이아웃이 동일합니다.
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // 안전: 유효한 요소가 방금 `this` 에 복사되었으므로 초기화됩니다.
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` 에서 `this` 로 요소를 복제하여 `this` 의 현재 초기화 된 내용에 대한 변경 가능한 참조를 반환합니다.
    /// 이미 초기화 된 요소는 삭제되지 않습니다.
    ///
    /// `T` 가 `Copy` 를 구현하는 경우 [`write_slice`] 를 사용합니다.
    ///
    /// 이것은 [`slice::clone_from_slice`] 와 유사하지만 기존 요소를 삭제하지 않습니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 두 슬라이스의 길이가 다르거 나 `Clone` panics 의 구현 인 경우 panic 가됩니다.
    ///
    /// panic 가있는 경우 이미 복제 된 요소가 삭제됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // 안전: 우리는 len의 모든 요소를 예비 용량에 복제했습니다.
    /// // vec의 첫 번째 src.len() 요소는 이제 유효합니다.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice와 달리 이것은 슬라이스에서 clone_from_slice를 호출하지 않습니다. 이것은 `MaybeUninit<T: Clone>` 가 Clone을 구현하지 않기 때문입니다.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // 안전: 이 원시 슬라이스에는 초기화 된 객체 만 포함됩니다.
                // 그래서 그것을 떨어 뜨릴 수 있습니다.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: 우리는 그것들을 같은 길이로 명시 적으로 슬라이스해야합니다
        // 경계 검사가 제거되고 옵티마이 저는 간단한 경우에 대해 memcpy를 생성합니다 (예: T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // 보호가 필요함 b/c panic 는 복제 중에 발생할 수 있습니다.
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // 안전: 유효한 요소가 `this` 에 방금 작성되었으므로 초기화됩니다.
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}