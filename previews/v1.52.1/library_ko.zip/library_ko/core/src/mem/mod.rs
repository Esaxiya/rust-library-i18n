//! 메모리를 다루는 기본 기능.
//!
//! 이 모듈에는 유형의 크기 및 정렬을 쿼리하고 메모리를 초기화하고 조작하는 함수가 포함되어 있습니다.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **소멸자를 실행하지 않고** 가치에 대한 소유권과 "forgets" 를받습니다.
///
/// 힙 메모리 또는 파일 핸들과 같이 값이 관리하는 모든 리소스는 도달 할 수없는 상태로 영원히 남아 있습니다.그러나이 메모리에 대한 포인터가 유효한 상태로 유지된다는 보장은 없습니다.
///
/// * 메모리 누수를 원하면 [`Box::leak`] 를 참조하십시오.
/// * 메모리에 대한 원시 포인터를 얻으려면 [`Box::into_raw`] 를 참조하십시오.
/// * 값을 적절하게 처리하고 소멸자를 실행하려면 [`mem::drop`] 를 참조하십시오.
///
/// # Safety
///
/// `forget` Rust 의 안전 보장은 소멸자가 항상 실행된다는 보장을 포함하지 않기 때문에 `unsafe` 로 표시되지 않습니다.
/// 예를 들어, 프로그램은 [`Rc`][rc] 를 사용하여 참조주기를 만들거나 [`process::exit`][exit] 를 호출하여 소멸자를 실행하지 않고 종료 할 수 있습니다.
/// 따라서 안전 코드에서 `mem::forget` 를 허용한다고해서 Rust 의 안전 보장이 근본적으로 변경되지는 않습니다.
///
/// 즉, 메모리 또는 I/O 개체와 같은 리소스 누출은 일반적으로 바람직하지 않습니다.
/// FFI 또는 안전하지 않은 코드에 대한 일부 특수 사용 사례에 대한 필요성이 제기되지만, 그럼에도 불구하고 일반적으로 [`ManuallyDrop`] 가 선호됩니다.
///
/// 값을 잊어 버릴 수 있기 때문에 작성하는 모든 `unsafe` 코드는 이러한 가능성을 허용해야합니다.값을 반환 할 수 없으며 호출자가 반드시 값의 소멸자를 실행할 것이라고 기대할 수 없습니다.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` 의 표준 안전한 사용은 `Drop` trait 에 의해 구현 된 값의 소멸자를 우회하는 것입니다.예를 들어, 이것은 `File` 를 누출합니다.
/// 변수가 차지하는 공간을 회수하지만 기본 시스템 리소스를 닫지 마십시오.
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// 이것은 예를 들어 원시 파일 설명자를 C 코드로 전송하여 기본 리소스의 소유권이 이전에 Rust 외부의 코드로 전송 된 경우에 유용합니다.
///
/// # `ManuallyDrop` 와의 관계
///
/// `mem::forget` 를 사용하여 *메모리* 소유권을 전송할 수도 있지만 그렇게하면 오류가 발생하기 쉽습니다.
/// [`ManuallyDrop`] 대신 사용해야합니다.예를 들어 다음 코드를 고려하십시오.
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` 의 콘텐츠를 사용하여 `String` 빌드
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // 이제 메모리가 `s` 에 의해 관리되기 때문에 `v` 가 누출됩니다.
/// mem::forget(v);  // 오류, v는 유효하지 않으며 함수에 전달하면 안됩니다.
/// assert_eq!(s, "Az");
/// // `s` 암시 적으로 삭제되고 해당 메모리가 할당 해제됩니다.
/// ```
///
/// 위의 예에는 두 가지 문제가 있습니다.
///
/// * `String` 의 구성과 `mem::forget()` 의 호출 사이에 더 많은 코드가 추가되면 동일한 메모리가 `v` 와 `s` 에 의해 처리되기 때문에 그 안에있는 panic 는 이중 해제를 발생시킵니다.
/// * `v.as_mut_ptr()` 를 호출하고 데이터 소유권을 `s` 로 전송 한 후 `v` 값이 유효하지 않습니다.
/// 값이 `mem::forget` 로 이동하더라도 (검사하지 않음) 일부 유형에는 매달 리거나 더 이상 소유하지 않을 때 유효하지 않게 만드는 값에 대한 엄격한 요구 사항이 있습니다.
/// 잘못된 값을 함수로 전달하거나 함수에서 반환하는 것을 포함하여 어떤 방식 으로든 잘못된 값을 사용하면 정의되지 않은 동작이 구성되고 컴파일러의 가정이 깨질 수 있습니다.
///
/// `ManuallyDrop` 로 전환하면 두 가지 문제가 모두 방지됩니다.
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v` 를 원시 부품으로 분해하기 전에 떨어지지 않도록주의하십시오!
/////
/// let mut v = ManuallyDrop::new(v);
/// // 이제 `v` 를 분해합니다.이러한 작업은 panic 할 수 없으므로 누출이있을 수 없습니다.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // 마지막으로 `String` 를 빌드하십시오.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` 암시 적으로 삭제되고 해당 메모리가 할당 해제됩니다.
/// ```
///
/// `ManuallyDrop` 다른 작업을 수행하기 전에`v`의 소멸자를 비활성화하므로 double-free를 강력하게 방지합니다.
/// `mem::forget()` 인수를 소비하므로 `v` 에서 필요한 항목을 추출한 후에 만 호출하도록 강제하기 때문에이를 허용하지 않습니다.
/// panic 가 `ManuallyDrop` 의 생성과 문자열 구축 사이에 도입 되었더라도 (표시된 코드에서는 발생할 수 없음) 이중 자유가 아닌 누수가 발생합니다.
/// 즉, `ManuallyDrop` 는 (이중) 드롭 측면에서 오류가 발생하는 대신 누출 측면에서 오류가 발생합니다.
///
/// 또한 `ManuallyDrop` 는 소유권을 `s` 로 이전 한 후 "touch" `v` 가 필요하지 않도록합니다. `v` 와 상호 작용하여 소멸자를 실행하지 않고이를 처리하는 마지막 단계는 완전히 피할 수 있습니다.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] 와 비슷하지만 크기가 지정되지 않은 값도 허용합니다.
///
/// 이 기능은 `unsized_locals` 기능이 안정화되면 제거하기위한 심입니다.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// 유형의 크기를 바이트 단위로 반환합니다.
///
/// 보다 구체적으로 이것은 정렬 패딩을 포함하여 해당 항목 유형이있는 배열의 연속 요소 사이의 바이트 단위 오프셋입니다.
///
/// 따라서 모든 유형 `T` 및 길이 `n` 에 대해 `[T; n]` 의 크기는 `n * size_of::<T>()` 입니다.
///
/// 일반적으로 유형의 크기는 컴파일간에 안정적이지 않지만 프리미티브와 같은 특정 유형은 안정적입니다.
///
/// 다음 표는 기본 요소의 크기를 제공합니다.
///
/// 유형 |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 자 |4
///
/// 또한 `usize` 와 `isize` 의 크기는 동일합니다.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` 및 `Option<Box<T>>` 유형은 모두 같은 크기입니다.
/// `T` 가 Sized이면 이러한 모든 유형의 크기는 `usize` 와 같습니다.
///
/// 포인터의 가변성은 크기를 변경하지 않습니다.따라서 `&T` 와 `&mut T` 의 크기는 동일합니다.
/// `*const T` 및 `* mut T` 도 마찬가지입니다.
///
/// # `#[repr(C)]` 항목의 크기
///
/// 항목에 대한 `C` 표현에는 정의 된 레이아웃이 있습니다.
/// 이 레이아웃을 사용하면 모든 필드의 크기가 안정적인 한 항목의 크기도 안정적입니다.
///
/// ## 구조체의 크기
///
/// `structs` 의 경우 크기는 다음 알고리즘에 의해 결정됩니다.
///
/// 선언 순서에 따라 정렬 된 구조체의 각 필드에 대해 :
///
/// 1. 필드의 크기를 추가하십시오.
/// 2. 현재 크기를 다음 필드의 [alignment] 의 가장 가까운 배수로 반올림합니다.
///
/// 마지막으로 구조체의 크기를 [alignment] 의 가장 가까운 배수로 반올림합니다.
/// 구조체의 정렬은 일반적으로 모든 필드의 가장 큰 정렬입니다.이것은 `repr(align(N))` 를 사용하여 변경할 수 있습니다.
///
/// `C` 와 달리 크기가 0 인 구조체는 크기가 1 바이트로 반올림되지 않습니다.
///
/// ## 열거 형 크기
///
/// 판별 자 이외의 데이터를 전달하지 않는 열거 형은 컴파일 대상 플랫폼의 C 열거 형과 크기가 같습니다.
///
/// ## 조합의 크기
///
/// 유니온의 크기는 가장 큰 필드의 크기입니다.
///
/// `C` 와 달리 크기가 0 인 공용체는 크기가 1 바이트로 반올림되지 않습니다.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // 일부 프리미티브
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // 일부 어레이
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // 포인터 크기 동일
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` 사용.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // 첫 번째 필드의 크기는 1이므로 크기에 1을 더합니다.크기는 1입니다.
/// // 두 번째 필드의 정렬은 2이므로 패딩 크기에 1을 더합니다.크기는 2입니다.
/// // 두 번째 필드의 크기는 2이므로 크기에 2를 더합니다.크기는 4입니다.
/// // 세 번째 필드의 정렬은 1이므로 패딩 크기에 0을 추가합니다.크기는 4입니다.
/// // 세 번째 필드의 크기는 1이므로 크기에 1을 더합니다.크기는 5입니다.
/// // 마지막으로 구조체의 정렬은 2 (필드 중 가장 큰 정렬이 2이기 때문에)이므로 패딩 크기에 1을 더합니다.
/// // 크기는 6입니다.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // 튜플 구조체는 동일한 규칙을 따릅니다.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // 필드 순서를 변경하면 크기가 줄어들 수 있습니다.
/// // `second` 앞에 `third` 를 넣어 두 패딩 바이트를 모두 제거 할 수 있습니다.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // 유니온 크기는 가장 큰 필드의 크기입니다.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// 가리키는 값의 크기를 바이트 단위로 반환합니다.
///
/// 일반적으로 `size_of::<T>()` 와 동일합니다.
/// 그러나 `T` *에 정적으로 알려진 크기가없는 경우 (예: 슬라이스 [`[T]`][slice] 또는 [trait object]), `size_of_val` 를 사용하여 동적으로 알려진 크기를 얻을 수 있습니다.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // 안전: `val` 는 참조이므로 유효한 원시 포인터입니다.
    unsafe { intrinsics::size_of_val(val) }
}

/// 가리키는 값의 크기를 바이트 단위로 반환합니다.
///
/// 일반적으로 `size_of::<T>()` 와 동일합니다.그러나 `T` *에 정적으로 알려진 크기가없는 경우 (예: 슬라이스 [`[T]`][slice] 또는 [trait object]), `size_of_val_raw` 를 사용하여 동적으로 알려진 크기를 얻을 수 있습니다.
///
/// # Safety
///
/// 이 함수는 다음 조건이 충족되는 경우에만 호출해도 안전합니다.
///
/// - `T` 가 `Sized` 이면이 함수는 항상 안전하게 호출 할 수 있습니다.
/// - `T` 의 크기가 지정되지 않은 꼬리가 다음과 같은 경우 :
///     - [slice] 인 경우 슬라이스 꼬리의 길이는 초기화 된 정수 여야하며 *전체 값*(동적 꼬리 길이 + 정적으로 크기가 지정된 접두사)의 크기는 `isize` 에 맞아야합니다.
///     - [trait object] 인 경우 포인터의 vtable 부분은 unsizing coercion으로 얻은 유효한 vtable을 가리켜 야하며 *전체 값*(동적 꼬리 길이 + 정적으로 크기가 지정된 접두사)의 크기는 `isize` 에 맞아야합니다.
///
///     - (unstable) [extern type] 인 경우이 함수는 항상 호출하기에 안전하지만, panic 또는 extern 유형의 레이아웃을 알 수 없기 때문에 잘못된 값을 반환 할 수 있습니다.
///     이것은 extern 유형 꼬리가있는 유형에 대한 참조에서 [`size_of_val`] 와 동일한 동작입니다.
///     - 그렇지 않으면 보수적으로이 함수를 호출 할 수 없습니다.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // 안전: 호출자는 유효한 원시 포인터를 제공해야합니다.
    unsafe { intrinsics::size_of_val(val) }
}

/// 형식의 [ABI] 필수 최소 정렬을 반환합니다.
///
/// `T` 유형의 값에 대한 모든 참조는이 숫자의 배수 여야합니다.
///
/// 이것은 구조체 필드에 사용되는 정렬입니다.선호하는 정렬보다 작을 수 있습니다.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` 가 가리키는 값 유형의 [ABI] 필수 최소 정렬을 반환합니다.
///
/// `T` 유형의 값에 대한 모든 참조는이 숫자의 배수 여야합니다.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // 안전: val은 참조이므로 유효한 원시 포인터입니다.
    unsafe { intrinsics::min_align_of_val(val) }
}

/// 형식의 [ABI] 필수 최소 정렬을 반환합니다.
///
/// `T` 유형의 값에 대한 모든 참조는이 숫자의 배수 여야합니다.
///
/// 이것은 구조체 필드에 사용되는 정렬입니다.선호하는 정렬보다 작을 수 있습니다.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` 가 가리키는 값 유형의 [ABI] 필수 최소 정렬을 반환합니다.
///
/// `T` 유형의 값에 대한 모든 참조는이 숫자의 배수 여야합니다.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // 안전: val은 참조이므로 유효한 원시 포인터입니다.
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` 가 가리키는 값 유형의 [ABI] 필수 최소 정렬을 반환합니다.
///
/// `T` 유형의 값에 대한 모든 참조는이 숫자의 배수 여야합니다.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// 이 함수는 다음 조건이 충족되는 경우에만 호출해도 안전합니다.
///
/// - `T` 가 `Sized` 이면이 함수는 항상 안전하게 호출 할 수 있습니다.
/// - `T` 의 크기가 지정되지 않은 꼬리가 다음과 같은 경우 :
///     - [slice] 인 경우 슬라이스 꼬리의 길이는 초기화 된 정수 여야하며 *전체 값*(동적 꼬리 길이 + 정적으로 크기가 지정된 접두사)의 크기는 `isize` 에 맞아야합니다.
///     - [trait object] 인 경우 포인터의 vtable 부분은 unsizing coercion으로 얻은 유효한 vtable을 가리켜 야하며 *전체 값*(동적 꼬리 길이 + 정적으로 크기가 지정된 접두사)의 크기는 `isize` 에 맞아야합니다.
///
///     - (unstable) [extern type] 인 경우이 함수는 항상 호출하기에 안전하지만, panic 또는 extern 유형의 레이아웃을 알 수 없기 때문에 잘못된 값을 반환 할 수 있습니다.
///     이것은 extern 유형 꼬리가있는 유형에 대한 참조에서 [`align_of_val`] 와 동일한 동작입니다.
///     - 그렇지 않으면 보수적으로이 함수를 호출 할 수 없습니다.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // 안전: 호출자는 유효한 원시 포인터를 제공해야합니다.
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `T` 유형의 값을 삭제하는 것이 중요하면 `true` 를 반환합니다.
///
/// 이것은 순전히 최적화 힌트이며 보수적으로 구현할 수 있습니다.
/// 실제로 삭제할 필요가없는 유형에 대해서는 `true` 를 반환 할 수 있습니다.
/// 따라서 항상 `true` 를 반환하는 것은이 함수의 유효한 구현입니다.그러나이 함수가 실제로 `false` 를 반환하면 `T` 를 삭제해도 부작용이 없음을 확신 할 수 있습니다.
///
/// 데이터를 수동으로 삭제해야하는 컬렉션과 같은 저수준 구현에서는이 기능을 사용하여 모든 콘텐츠가 파괴 될 때 불필요하게 삭제하지 않도록해야합니다.
///
/// 이는 릴리스 빌드 (부작용이없는 루프가 쉽게 감지되고 제거되는 경우)에서 차이를 만들지 않을 수 있지만 종종 디버그 빌드에서 큰 승리입니다.
///
/// [`drop_in_place`] 는 이미이 검사를 수행하므로 워크로드를 적은 수의 [`drop_in_place`] 호출로 줄일 수있는 경우이를 사용할 필요가 없습니다.
/// 특히 슬라이스를 [`drop_in_place`] 할 수 있으며 모든 값에 대해 단일 needs_drop 검사를 수행합니다.
///
/// 따라서 Vec과 같은 유형은 `needs_drop` 를 명시 적으로 사용하지 않고 `drop_in_place(&mut self[..])` 만 사용합니다.
/// 반면 [`HashMap`] 와 같은 유형은 한 번에 하나씩 값을 삭제해야하며이 API를 사용해야합니다.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// 다음은 컬렉션에서 `needs_drop` 를 사용하는 방법의 예입니다.
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // 데이터를 버리다
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// 모두 0 바이트 패턴으로 표시되는 `T` 유형의 값을 리턴합니다.
///
/// 이는 예를 들어 `(u8, u16)` 의 패딩 바이트가 반드시 0이되는 것은 아님을 의미합니다.
///
/// 모두 0 바이트 패턴이 `T` 유형의 유효한 값을 나타낸다는 보장은 없습니다.
/// 예를 들어 모두 0 인 바이트 패턴은 참조 유형 (`&T`, `&mut T`) 및 함수 포인터에 유효한 값이 아닙니다.
/// 이러한 유형에서 `zeroed` 를 사용하면 초기화 된 것으로 간주되는 변수에 항상 유효한 값이있는 [the Rust compiler assumes][inv] 가 즉시 [undefined behavior][ub] 가됩니다.
///
///
/// 이것은 [`MaybeUninit::zeroed().assume_init()`][zeroed] 와 동일한 효과가 있습니다.
/// 가끔 FFI에 유용하지만 일반적으로 피해야합니다.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// 이 함수의 올바른 사용법: 0으로 정수 초기화.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// 이 함수의 *잘못된* 사용법: 0으로 참조 초기화.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // 정의되지 않은 동작!
/// let _y: fn() = unsafe { mem::zeroed() }; // 다시 한번!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // 안전: 호출자는 모두 0 값이 `T` 에 대해 유효 함을 보장해야합니다.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// `T` 유형의 값을 생성하는 척하면서 Rust 의 정상적인 메모리 초기화 검사를 무시하고 아무것도하지 않습니다.
///
/// **이 기능은 더 이상 사용되지 않습니다.** 대신 [`MaybeUninit<T>`] 를 사용하세요.
///
/// 지원 중단의 이유는 기본적으로 함수를 올바르게 사용할 수 없기 때문입니다. [`MaybeUninit::uninit().assume_init()`][uninit] 와 동일한 효과가 있습니다.
///
/// [`assume_init` documentation][assume_init] 가 설명 하듯이 [the Rust compiler assumes][inv] 는 값이 적절하게 초기화됩니다.
/// 결과적으로 예를 들어
/// `mem::uninitialized::<bool>()` `true` 또는 `false` 가 아닌 `bool` 를 반환하는 즉시 정의되지 않은 동작이 발생합니다.
/// 더 나쁜 것은 여기에 반환되는 것과 같이 실제로 초기화되지 않은 메모리는 컴파일러가 고정 된 값이 없다는 것을 알고 있다는 점에서 특별합니다.
/// 따라서 해당 변수에 정수 유형이 있더라도 변수에 초기화되지 않은 데이터가있는 정의되지 않은 동작이 있습니다.
/// (초기화되지 않은 정수에 대한 규칙은 아직 완성되지 않았지만 완성되기 전까지는 피하는 것이 좋습니다.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // 안전: 호출자는 단위 화 된 값이 `T` 에 대해 유효한지 확인해야합니다.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// 둘 중 하나를 초기화하지 않고 변경 가능한 두 위치의 값을 바꿉니다.
///
/// * 기본값 또는 더미 값으로 교체하려면 [`take`] 를 참조하십시오.
/// * 전달 된 값으로 바꾸고 이전 값을 반환하려면 [`replace`] 를 참조하십시오.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // 안전: 원시 포인터는 모든
    // `ptr::swap_nonoverlapping_one` 에 대한 제약
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` 를 기본값 `T` 로 바꾸고 이전 `dest` 값을 반환합니다.
///
/// * 두 변수의 값을 바꾸려면 [`swap`] 를 참조하십시오.
/// * 기본값 대신 전달 된 값으로 바꾸려면 [`replace`] 를 참조하십시오.
///
/// # Examples
///
/// 간단한 예 :
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` 구조체 필드를 "empty" 값으로 대체하여 소유권을 가져올 수 있습니다.
/// `take` 가 없으면 다음과 같은 문제가 발생할 수 있습니다.
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` 가 반드시 [`Clone`] 를 구현하는 것은 아니므로 `self.buf` 를 복제하고 재설정 할 수도 없습니다.
/// 그러나 `take` 를 사용하여 `self` 에서 `self.buf` 의 원래 값을 분리하여 반환 할 수 있습니다.
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` 를 참조 된 `dest` 로 이동하여 이전 `dest` 값을 반환합니다.
///
/// 두 값 모두 삭제되지 않습니다.
///
/// * 두 변수의 값을 바꾸려면 [`swap`] 를 참조하십시오.
/// * 기본값으로 바꾸려면 [`take`] 를 참조하십시오.
///
/// # Examples
///
/// 간단한 예 :
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` 구조체 필드를 다른 값으로 대체하여 사용할 수 있습니다.
/// `replace` 가 없으면 다음과 같은 문제가 발생할 수 있습니다.
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` 가 반드시 [`Clone`] 를 구현하는 것은 아니므로 이동을 피하기 위해 `self.buf[i]` 를 복제 할 수도 없습니다.
/// 그러나 `replace` 를 사용하여 `self` 에서 해당 인덱스의 원래 값을 연결 해제하여 반환 할 수 있습니다.
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // 안전: 우리는 `dest` 에서 읽었지만 나중에 `src` 를 직접 씁니다.
    // 이전 값이 중복되지 않도록합니다.
    // 아무것도 드롭되지 않으며 여기에서 아무것도 panic 할 수 없습니다.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// 값을 폐기합니다.
///
/// 이것은 인수의 [`Drop`][drop] 구현을 호출함으로써 가능합니다.
///
/// 이것은 `Copy` 를 구현하는 유형에 대해 효과적으로 수행하지 않습니다.
/// integers.
/// 이러한 값은 복사되고 _then_ 가 함수로 이동하므로이 함수 호출 후에도 값이 유지됩니다.
///
///
/// 이 기능은 마술이 아닙니다.말 그대로 다음과 같이 정의됩니다.
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` 는 함수로 이동하기 때문에 함수가 반환되기 전에 자동으로 삭제됩니다.
///
/// [drop]: Drop
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector 를 명시 적으로 삭제
/// ```
///
/// [`RefCell`] 는 런타임에 차용 규칙을 적용하므로 `drop` 는 [`RefCell`] 차용을 해제 할 수 있습니다.
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // 이 슬롯에서 변경 가능한 차용을 포기
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] 를 구현하는 정수 및 기타 유형은 `drop` 의 영향을받지 않습니다.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` 사본이 이동 및 삭제됩니다.
/// drop(y); // `y` 사본이 이동 및 삭제됩니다.
///
/// println!("x: {}, y: {}", x, y.0); // 여전히 사용 가능
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` 를 `&U` 유형으로 해석 한 다음 포함 된 값을 이동하지 않고 `src` 를 읽습니다.
///
/// 이 함수는 `&T` 를 `&U` 로 변환 한 다음 `&U` 를 읽음으로써 `src` 포인터가 [`size_of::<U>`][size_of] 바이트에 대해 유효하다고 안전하지 않게 가정합니다 (`&U` 가 `&T` 보다 더 엄격한 정렬 요구 사항을 생성하는 경우에도 올바른 방식으로 수행되는 경우 제외).
/// 또한 `src` 밖으로 이동하는 대신 포함 된 값의 복사본을 안전하지 않게 만듭니다.
///
/// `T` 와 `U` 의 크기가 다른 경우 컴파일 타임 오류가 아니지만 `T` 와 `U` 의 크기가 같은 경우에만이 함수를 호출하는 것이 좋습니다.이 함수는 `U` 가 `T` 보다 큰 경우 [undefined behavior][ub] 를 트리거합니다.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' 에서 데이터를 복사하여 'Foo' 로 취급
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // 복사 된 데이터 수정
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' 의 내용은 변경되지 않아야합니다.
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U에 더 높은 정렬 요구 사항이 있으면 src 가 적절하게 정렬되지 않을 수 있습니다.
    if align_of::<U>() > align_of::<T>() {
        // 안전: `src` 는 읽기에 유효 함이 보장되는 참조입니다.
        // 호출자는 실제 변환이 안전한지 확인해야합니다.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // 안전: `src` 는 읽기에 유효 함이 보장되는 참조입니다.
        // 방금 `src as *const U` 가 제대로 정렬되었는지 확인했습니다.
        // 호출자는 실제 변환이 안전한지 확인해야합니다.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// 열거 형의 판별자를 나타내는 불투명 한 유형입니다.
///
/// 자세한 내용은이 모듈의 [`discriminant`] 기능을 참조하십시오.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. 이러한 trait 구현은 T에 대한 경계를 원하지 않기 때문에 파생 될 수 없습니다.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` 에서 열거 형 변형을 고유하게 식별하는 값을 반환합니다.
///
/// `T` 가 열거 형이 아닌 경우이 함수를 호출하면 정의되지 않은 동작이 발생하지 않지만 반환 값은 지정되지 않습니다.
///
///
/// # Stability
///
/// 열거 형 정의가 변경되면 열거 형 변형의 판별이 변경 될 수 있습니다.
/// 일부 변형의 판별은 동일한 컴파일러를 사용하는 컴파일간에 변경되지 않습니다.
///
/// # Examples
///
/// 실제 데이터는 무시하고 데이터를 전달하는 열거 형을 비교하는 데 사용할 수 있습니다.
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// 열거 형 `T` 의 변형 수를 반환합니다.
///
/// `T` 가 열거 형이 아닌 경우이 함수를 호출하면 정의되지 않은 동작이 발생하지 않지만 반환 값은 지정되지 않습니다.
/// 마찬가지로 `T` 가 `usize::MAX` 보다 변형이 더 많은 열거 형이면 반환 값이 지정되지 않습니다.
/// 무인 변종이 계산됩니다.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}