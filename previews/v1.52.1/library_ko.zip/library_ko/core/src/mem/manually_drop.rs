use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// 컴파일러가`T`의 소멸자를 자동으로 호출하지 못하도록하는 래퍼입니다.
/// 이 래퍼는 비용이 0입니다.
///
/// `ManuallyDrop<T>` `T` 와 동일한 레이아웃 최적화가 적용됩니다.
/// 결과적으로 컴파일러가 내용에 대해 만드는 가정에 *효과가 없습니다*.
/// 예를 들어 [`mem::zeroed`] 로 `ManuallyDrop<&mut T>` 를 초기화하는 것은 정의되지 않은 동작입니다.
/// 초기화되지 않은 데이터를 처리해야하는 경우 대신 [`MaybeUninit<T>`] 를 사용하십시오.
///
/// `ManuallyDrop<T>` 내부의 값에 액세스하는 것은 안전합니다.
/// 즉, 콘텐츠가 삭제 된 `ManuallyDrop<T>` 는 공용 안전 API를 통해 노출되지 않아야합니다.
/// 따라서 `ManuallyDrop::drop` 는 안전하지 않습니다.
///
/// # `ManuallyDrop` 및 드롭 오더.
///
/// Rust 에는 잘 정의 된 [drop order] 값이 있습니다.
/// 필드 또는 로컬이 특정 순서로 삭제되었는지 확인하려면 암시 적 삭제 순서가 올바른 순서가되도록 선언을 재정렬하십시오.
///
/// `ManuallyDrop` 를 사용하여 드롭 순서를 제어 할 수 있지만이 경우 안전하지 않은 코드가 필요하며 해제가있을 때 올바르게 수행하기가 어렵습니다.
///
///
/// 예를 들어 특정 필드가 다른 필드 뒤에 삭제되도록하려면 해당 필드를 구조체의 마지막 필드로 만듭니다.
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` 이후에 삭제됩니다.
///     // Rust 는 선언 순서대로 필드가 삭제되도록 보장합니다.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// 수동으로 삭제할 값을 래핑합니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // 여전히 가치에 대해 안전하게 작업 할 수 있습니다.
    /// assert_eq!(*x, "Hello");
    /// // 그러나 `Drop` 는 여기서 실행되지 않습니다.
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` 컨테이너에서 값을 추출합니다.
    ///
    /// 이렇게하면 값을 다시 삭제할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // 이것은 `Box` 를 삭제합니다.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` 컨테이너에서 값을 가져옵니다.
    ///
    /// 이 방법은 주로 값을 떨어 뜨리는 데 사용됩니다.
    /// [`ManuallyDrop::drop`] 를 사용하여 값을 수동으로 삭제하는 대신이 방법을 사용하여 값을 가져와 원하는대로 사용할 수 있습니다.
    ///
    /// 가능하면 `ManuallyDrop<T>` 의 내용이 복제되지 않도록 [`into_inner`][`ManuallyDrop::into_inner`] 를 대신 사용하는 것이 좋습니다.
    ///
    ///
    /// # Safety
    ///
    /// 이 함수는 추가 사용을 방지하지 않고 포함 된 값을 의미 적으로 이동하여이 컨테이너의 상태를 변경하지 않습니다.
    /// 이 `ManuallyDrop` 가 다시 사용되지 않도록하는 것은 귀하의 책임입니다.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // 안전: 우리는 참조에서 읽고 있습니다.
        // 읽기에 유효합니다.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// 포함 된 값을 수동으로 삭제합니다.이것은 포함 된 값에 대한 포인터로 [`ptr::drop_in_place`] 를 호출하는 것과 정확히 동일합니다.
    /// 따라서 포함 된 값이 패킹 된 구조체가 아니면 소멸자는 값을 이동하지 않고 제자리에서 호출되므로 [pinned] 데이터를 안전하게 삭제하는 데 사용할 수 있습니다.
    ///
    /// 값에 대한 소유권이있는 경우 대신 [`ManuallyDrop::into_inner`] 를 사용할 수 있습니다.
    ///
    /// # Safety
    ///
    /// 이 함수는 포함 된 값의 소멸자를 실행합니다.
    /// 소멸자 자체에 의해 변경된 것 외에 메모리는 변경되지 않은 채로 남아 있으며 컴파일러에 관한 한 여전히 `T` 유형에 유효한 비트 패턴을 보유합니다.
    ///
    ///
    /// 그러나이 "zombie" 값은 안전한 코드에 노출되어서는 안되며이 함수는 두 번 이상 호출되지 않아야합니다.
    /// 값을 삭제 한 후 사용하거나 값을 여러 번 삭제하면 정의되지 않은 동작이 발생할 수 있습니다 (`drop` 의 기능에 따라 다름).
    /// 이것은 일반적으로 유형 시스템에 의해 방지되지만 `ManuallyDrop` 사용자는 컴파일러의 도움없이 이러한 보증을 유지해야합니다.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // 안전: 가변 참조가 가리키는 값을 삭제합니다.
        // 쓰기에 유효 함이 보장됩니다.
        // `slot` 가 다시 끊어지지 않도록하는 것은 호출자에게 달려 있습니다.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}