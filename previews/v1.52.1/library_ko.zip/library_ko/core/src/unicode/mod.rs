#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` 및 `str` 메서드의 유니 코드 부분이 기반으로하는 [Unicode](http://www.unicode.org/) 버전입니다.
///
/// 새 버전의 유니 코드가 정기적으로 릴리스되고 이후 유니 코드에 따라 표준 라이브러리의 모든 메서드가 업데이트됩니다.
/// 따라서 일부 `char` 및 `str` 메서드의 동작과이 상수 값은 시간이 지남에 따라 변경됩니다.
/// 이는 주요 변경 사항으로 간주되지 *않습니다*.
///
/// 버전 번호 지정 체계는 [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) 에 설명되어 있습니다.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// liballoc에서 사용하기 위해 libstd에서 다시 내 보내지 않습니다.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;