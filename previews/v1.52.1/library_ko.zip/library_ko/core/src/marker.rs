//! 기본 traits 및 유형의 기본 속성을 나타내는 유형.
//!
//! Rust 유형은 고유 속성에 따라 다양한 유용한 방법으로 분류 할 수 있습니다.
//! 이러한 분류는 traits 로 표시됩니다.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// 스레드 경계를 넘어 전송할 수있는 유형입니다.
///
/// 이 trait 는 컴파일러가 적절하다고 판단하면 자동으로 구현됩니다.
///
/// 비`보내기`유형의 예는 참조 계수 포인터 [`rc::Rc`][`Rc`] 입니다.
/// 두 스레드가 동일한 참조 횟수 값을 가리키는 [`Rc`]를 복제하려고 시도하면 동시에 참조 횟수 업데이트를 시도 할 수 있습니다. [`Rc`] 는 원자 적 연산을 사용하지 않기 때문에 [undefined behavior][ub] 입니다.
///
/// 사촌 [`sync::Arc`][arc] 는 원자 연산 (일부 오버 헤드 발생)을 사용하므로 `Send` 입니다.
///
/// 자세한 내용은 [the Nomicon](../../nomicon/send-and-sync.html) 를 참조하십시오.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// 컴파일 타임에 알려진 일정한 크기를 가진 유형.
///
/// 모든 유형 매개 변수에는 `Sized` 의 내재적 경계가 있습니다.적절하지 않은 경우 특수 구문 `?Sized` 를 사용하여이 경계를 제거 할 수 있습니다.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // 구조체 FooUse(Foo<[i32]>);//오류: [i32] 에 대해 Sized가 구현되지 않았습니다.
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// 한 가지 예외는 trait 의 암시 적 `Self` 유형입니다.
/// trait 는 정의에 따라 trait 가 가능한 모든 구현 자와 함께 작동해야하는 [trait object]와 호환되지 않으므로 암시 적 `Sized` 바인딩이 없습니다.
///
///
/// Rust 를 사용하면 `Sized` 를 trait 에 바인딩 할 수 있지만 나중에 trait 개체를 형성하는 데 사용할 수 없습니다.
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn Bar= &Impl;//오류: trait `Bar` 는 객체로 만들 수 없습니다.
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // 예를 들어, `[T]: !Default` 를 평가할 수 있어야하는 기본
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// "unsized" 가 될 수있는 유형은 동적 크기 유형입니다.
///
/// 예를 들어, 크기가 지정된 배열 유형 `[i8; 2]` 는 `Unsize<[i8]>` 및 `Unsize<dyn fmt::Debug>` 를 구현합니다.
///
/// `Unsize` 의 모든 구현은 컴파일러에 의해 자동으로 제공됩니다.
///
/// `Unsize` 다음을 위해 구현됩니다.
///
/// - `[T; N]` `Unsize<[T]>` 입니다.
/// - `T` `T: Trait` 일 때 `Unsize<dyn Trait>`
/// - `Foo<..., T, ...>` 다음과 같은 경우 `Unsize<Foo<..., U, ...>>` 입니다.
///   - `T: Unsize<U>`
///   - Foo는 구조체입니다.
///   - `Foo` 의 마지막 필드에만 `T` 와 관련된 유형이 있습니다.
///   - `T` 다른 필드 유형의 일부가 아닙니다.
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` 의 마지막 필드에 `Bar<T>` 유형이있는 경우
///
/// `Unsize` [`ops::CoerceUnsized`] 와 함께 사용되어 [`Rc`] 와 같은 "user-defined" 컨테이너가 동적 크기의 유형을 포함 할 수 있습니다.
/// 자세한 내용은 [DST coercion RFC][RFC982] 및 [the nomicon entry on coercion][nomicon-coerce] 를 참조하십시오.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// 패턴 일치에 사용되는 상수에 trait 가 필요합니다.
///
/// `PartialEq` 를 파생하는 모든 유형은 유형 매개 변수가 `Eq` 를 구현하는지 여부에 관계없이 *이 trait 를 자동으로 구현합니다.
///
/// `const` 항목에이 trait 를 구현하지 않는 일부 유형이 포함 된 경우 해당 유형은 (1.) 가 `PartialEq` 를 구현하지 않거나 (즉, 코드 생성이 사용 가능하다고 가정하는 상수가 해당 비교 방법을 제공하지 않음을 의미합니다) 또는 (2.) 가 자체적으로 구현합니다. * `PartialEq` 버전 (구조적 평등 비교를 따르지 않는다고 가정).
///
///
/// 위의 두 시나리오 중 하나에서 패턴 일치에서 이러한 상수 사용을 거부합니다.
///
/// 속성 기반 설계에서이 trait 로 마이그레이션하는 동기를 부여한 [structural match RFC][RFC1445] 및 [issue 63438] 도 참조하십시오.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// 패턴 일치에 사용되는 상수에 trait 가 필요합니다.
///
/// `Eq` 를 파생하는 모든 유형은 유형 매개 변수가 `Eq` 를 구현하는지 여부에 관계없이 *이 trait 를 자동으로 구현합니다.
///
/// 이것은 우리 유형 시스템의 제한을 해결하기위한 해킹입니다.
///
/// # Background
///
/// 패턴 일치에 사용되는 const 유형에 `#[derive(PartialEq, Eq)]` 속성이 있어야합니다.
///
/// 더 이상적인 세계에서는 주어진 유형이 `StructuralPartialEq` trait *및*`Eq` trait 를 모두 구현하는지 확인하여 해당 요구 사항을 확인할 수 있습니다.
/// 그러나 `derive(PartialEq, Eq)` 를 *do* 하는 ADT를 가질 수 있으며 컴파일러가 받아들이기를 원하지만 상수의 유형이 `Eq` 를 구현하지 못하는 경우가 될 수 있습니다.
///
/// 즉, 다음과 같은 경우입니다.
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (위 코드에서 문제는 `Wrap<fn(&())>` 가 `PartialEq` 나 `Eq` 를 구현하지 않는다는 것입니다. 왜냐하면`for < 'a> fn(&'a _)` does not implement those traits.)
///
/// 따라서 우리는 `StructuralPartialEq` 및 단순한 `Eq` 에 대한 순진한 검사에 의존 할 수 없습니다.
///
/// 이 문제를 해결하기위한 해킹으로 (`#[derive(PartialEq)]` 및 `#[derive(Eq)]`) 파생물 각각에 의해 주입 된 두 개의 개별 traits 를 사용하고 둘 다 구조적 일치 검사의 일부로 존재하는지 확인합니다.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// 단순히 비트를 복사하여 값을 복제 할 수있는 유형입니다.
///
/// 기본적으로 변수 바인딩에는 '이동 의미 체계'가 있습니다.다시 말해:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` 로 이동하여 사용할 수 없습니다.
///
/// // println! ("{: ?}", x);//오류: 이동 된 값 사용
/// ```
///
/// 그러나 유형이 `Copy` 를 구현하는 경우 대신 '복사 의미론'이 있습니다.
///
/// ```
/// // `Copy` 구현을 유도 할 수 있습니다.
/// // `Clone` `Copy` 의 초 특성이므로 필요합니다.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` 의 복사본입니다.
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// 이 두 예에서 유일한 차이점은 할당 후 `x` 에 액세스 할 수 있는지 여부입니다.
/// 내부적으로는 복사와 이동 모두 메모리에서 비트가 복사 될 수 있지만 때로는 최적화되어 있습니다.
///
/// ## `Copy` 를 어떻게 구현할 수 있습니까?
///
/// 유형에 `Copy` 를 구현하는 방법에는 두 가지가 있습니다.가장 간단한 방법은 `derive` 를 사용하는 것입니다.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` 및 `Clone` 를 수동으로 구현할 수도 있습니다.
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// 둘 사이에는 약간의 차이가 있습니다. `derive` 전략은 또한 유형 매개 변수에 `Copy` 바운드를 배치하지만 항상 바람직하지는 않습니다.
///
/// ## `Copy` 와 `Clone` 의 차이점은 무엇입니까?
///
/// 복사는 예를 들어 할당 `y = x` 의 일부로 암시 적으로 발생합니다.`Copy` 의 동작은 과부하되지 않습니다.항상 단순한 비트 복사입니다.
///
/// 복제는 명시 적 작업 인 `x.clone()` 입니다.[`Clone`] 의 구현은 값을 안전하게 복제하는 데 필요한 모든 유형별 동작을 제공 할 수 있습니다.
/// 예를 들어, [`String`] 용 [`Clone`] 구현은 힙에서 가리키는 문자열 버퍼를 복사해야합니다.
/// [`String`] 값의 간단한 비트 복사는 단순히 포인터를 복사하여 라인 아래에 이중 여유 공간을 만듭니다.
/// 따라서 [`String`] 는 [`Clone`] 이지만 `Copy` 는 아닙니다.
///
/// [`Clone`] `Copy` 의 초 특성이므로 `Copy` 인 모든 것은 [`Clone`] 도 구현해야합니다.
/// 유형이 `Copy` 이면 해당 [`Clone`] 구현은 `*self` 만 반환하면됩니다 (위의 예 참조).
///
/// ## 내 유형은 언제 `Copy` 가 될 수 있습니까?
///
/// 모든 구성 요소가 `Copy` 를 구현하는 경우 유형은 `Copy` 를 구현할 수 있습니다.예를 들어이 구조체는 `Copy` 일 수 있습니다.
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// 구조체는 `Copy` 일 수 있고 [`i32`] 는 `Copy` 이므로 `Point` 는 `Copy` 가 될 수 있습니다.
/// 대조적으로
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// [`Vec<T>`] 가 `Copy` 가 아니기 때문에 `PointList` 구조체는 `Copy` 를 구현할 수 없습니다.`Copy` 구현을 유도하려고하면 오류가 발생합니다.
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// 공유 참조 (`&T`) 도 `Copy` 이므로 `Copy` 가 *아닌* 유형 `T` 의 공유 참조를 보유하는 경우에도 유형은 `Copy` 가 될 수 있습니다.
/// `Copy` 를 구현할 수있는 다음 구조체를 고려하십시오. 위의 비`Copy` 유형 `PointList` 에 대한 *공유 참조* 만 보유하기 때문입니다.
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## 내 유형이 `Copy` 가 될 수 *없습니다*?
///
/// 일부 유형은 안전하게 복사 할 수 없습니다.예를 들어 `&mut T` 를 복사하면 별칭이있는 가변 참조가 생성됩니다.
/// [`String`] 를 복사하면 [`String`]의 버퍼 관리에 대한 책임이 중복되어 이중 해제가 발생합니다.
///
/// 후자의 경우를 일반화하면 [`Drop`] 를 구현하는 모든 유형은 `Copy` 가 될 수 없습니다. 자체 [`size_of::<T>`] 바이트 외에 일부 리소스를 관리하기 때문입니다.
///
/// 비`Copy` 데이터를 포함하는 구조체 또는 열거 형에서 `Copy` 를 구현하려고하면 [E0204] 오류가 발생합니다.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## 내 유형이 `Copy` 여야하는 경우는 언제입니까?
///
/// 일반적으로 말해서, _can_ 유형이 `Copy` 를 구현한다면 그렇게해야합니다.
/// 하지만 `Copy` 를 구현하는 것은 사용자 유형의 공용 API의 일부입니다.
/// future 에서 유형이 'Copy'가 아닌 경우 API 변경을 방지하기 위해 지금 `Copy` 구현을 생략하는 것이 현명 할 수 있습니다.
///
/// ## 추가 구현 자
///
/// [implementors listed below][impls] 외에 다음 유형도 `Copy` 를 구현합니다.
///
/// * 기능 항목 유형 (즉, 각 기능에 대해 정의 된 구별 유형)
/// * 함수 포인터 유형 (예 : `fn() -> i32`)
/// * 항목 유형이 `Copy` (예: `[i32; 123456]`)도 구현하는 경우 모든 크기에 대한 배열 유형
/// * 각 구성 요소가 `Copy` (예: `()`, `(i32, bool)`)를 구현하는 경우 튜플 유형
/// * 클로저 유형 (환경에서 값을 캡처하지 않거나 캡처 된 모든 값이 `Copy` 자체를 구현하는 경우)
///   공유 참조로 캡처 된 변수는 항상 `Copy` 를 구현하지만 (참조 항목이 그렇지 않더라도) 가변 참조로 캡처 된 변수는 `Copy` 를 구현하지 않습니다.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) 이를 통해 수명 제한이 충족되지 않아 `Copy` 를 구현하지 않는 유형을 복사 할 수 있습니다 (`A<'static>: Copy` 및 `A<'_>: Clone` 만있는 경우 `A<'_>` 복사).
// 표준 라이브러리에 이미 존재하는 `Copy` 에 대한 기존 전문화가 상당히 많고 지금 당장 안전하게이 동작을 수행 할 방법이 없기 때문에 여기에이 속성이 있습니다.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` 의 impl을 생성하는 매크로를 유도합니다.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// 스레드간에 참조를 공유하는 것이 안전한 유형입니다.
///
/// 이 trait 는 컴파일러가 적절하다고 판단하면 자동으로 구현됩니다.
///
/// 정확한 정의는 다음과 같습니다. `T` 유형은 `&T` 가 [`Send`] 인 경우에만 [`Sync`] 입니다.
/// 즉, 스레드간에 `&T` 참조를 전달할 때 [undefined behavior][ub] (데이터 경합 포함) 가능성이없는 경우입니다.
///
/// 예상대로 [`u8`] 및 [`f64`] 와 같은 기본 유형은 모두 [`Sync`] 이며 튜플, 구조체 및 열거 형과 같이이를 포함하는 간단한 집계 유형도 마찬가지입니다.
/// 기본 [`Sync`] 유형의 더 많은 예에는 `&T` 와 같은 "immutable" 유형과 [`Box<T>`][box], [`Vec<T>`][vec] 및 대부분의 다른 컬렉션 유형과 같은 단순 상속 된 변경 가능성이있는 유형이 포함됩니다.
///
/// (컨테이너가 [`Sync`]가 되려면 일반 매개 변수가 [`Sync`] 여야합니다.)
///
/// 정의의 다소 놀라운 결과는 동기화되지 않은 돌연변이를 제공 할 수있는 것처럼 보이지만 `&mut T` 가 `Sync` (`T` 가 `Sync` 인 경우)라는 것입니다.
/// 트릭은 공유 참조 (즉, `& &mut T`) 뒤에있는 변경 가능한 참조가 마치 `& &T` 인 것처럼 읽기 전용이되는 것입니다.
/// 따라서 데이터 경쟁의 위험이 없습니다.
///
/// `Sync` 가 아닌 유형은 [`Cell`][cell] 및 [`RefCell`][refcell] 와 같이 스레드로부터 안전하지 않은 형식의 "interior mutability" 가있는 유형입니다.
/// 이러한 유형은 변경 불가능한 공유 참조를 통해서도 내용의 변경을 허용합니다.
/// 예를 들어 [`Cell<T>`][cell] 의 `set` 메서드는 `&self` 를 사용하므로 공유 참조 [`&Cell<T>`][cell] 만 필요합니다.
/// 이 메서드는 동기화를 수행하지 않으므로 [`Cell`][cell] 는 `Sync` 가 될 수 없습니다.
///
/// non-`Sync` 유형의 또 다른 예는 참조 계수 포인터 [`Rc`][rc] 입니다.
/// 참조 [`&Rc<T>`][rc] 가 주어지면 새 [`Rc<T>`][rc] 를 복제하여 비원 자적 방식으로 참조 횟수를 수정할 수 있습니다.
///
/// 스레드로부터 안전한 내부 변경 성이 필요한 경우 Rust 는 [atomic data types] 와 [`sync::Mutex`][mutex] 및 [`sync::RwLock`][rwlock] 를 통한 명시 적 잠금을 제공합니다.
/// 이러한 유형은 변형이 데이터 경합을 유발할 수 없도록 보장하므로 유형은 `Sync` 입니다.
/// 마찬가지로 [`sync::Arc`][arc] 는 [`Rc`][rc] 의 스레드 안전 아날로그를 제공합니다.
///
/// 내부 변경 가능성이있는 모든 유형은 공유 참조를 통해 변경 될 수있는 value(s) 주위에 [`cell::UnsafeCell`][unsafecell] 래퍼를 사용해야합니다.
/// 이 작업에 실패하면 [undefined behavior][ub] 입니다.
/// 예를 들어, `&T` 에서 `&mut T` 로의 [`transmute`][transmute]-ing은 유효하지 않습니다.
///
/// `Sync` 에 대한 자세한 내용은 [the Nomicon][nomicon-send-and-sync] 를 참조하십시오.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): `rustc_on_unimplemented` 에 메모를 추가하는 지원이 베타 버전으로 출시되고 클로저가 요구 사항 체인의 어느 위치에 있는지 확인하도록 확장 되었으면 다음과 같이 (#48534) 로 확장합니다.
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" 가 `T` 를 소유 한 것을 표시하는 데 사용되는 크기가 0 인 유형입니다.
///
/// 유형에 `PhantomData<T>` 필드를 추가하면 실제로는 그렇지 않더라도 유형이 `T` 유형의 값을 저장하는 것처럼 작동한다는 것을 컴파일러에 알립니다.
/// 이 정보는 특정 안전 속성을 계산할 때 사용됩니다.
///
/// `PhantomData<T>` 사용 방법에 대한 자세한 설명은 [the Nomicon](../../nomicon/phantom-data.html) 를 참조하십시오.
///
/// # 무시 무시한 메모 👻👻👻
///
/// 둘 다 무서운 이름을 가지고 있지만 `PhantomData` 와 '팬텀 유형'은 관련이 있지만 동일하지는 않습니다.가상 유형 매개 변수는 결코 사용되지 않는 유형 매개 변수입니다.
/// Rust 에서 이로 인해 종종 컴파일러가 불평하고 해결책은 `PhantomData` 를 통해 "dummy" 사용을 추가하는 것입니다.
///
/// # Examples
///
/// ## 사용되지 않은 수명 매개 변수
///
/// `PhantomData` 의 가장 일반적인 사용 사례는 일반적으로 안전하지 않은 코드의 일부로 사용되지 않는 수명 매개 변수가있는 구조체 일 것입니다.
/// 예를 들어, 다음은 `*const T` 유형의 두 포인터가있는 구조체 `Slice` 입니다. 아마도 어딘가에 배열을 가리킬 것입니다.
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// 의도는 기본 데이터가 `'a` 수명 동안 만 유효하므로 `Slice` 는 `'a` 보다 오래 지속되지 않아야합니다.
/// 그러나이 의도는 `'a` 수명을 사용하지 않고 적용되는 데이터가 명확하지 않기 때문에 코드에 표현되어 있지 않습니다.
/// `Slice` 구조체에 참조 `&'a T` 가 포함 된 것처럼 *동작* 하도록 컴파일러에 지시하여이를 수정할 수 있습니다.
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// 또한 `T: 'a` 주석이 필요합니다. 이는 `T` 의 모든 참조가 `'a` 수명 동안 유효 함을 나타냅니다.
///
/// `Slice` 를 초기화 할 때 `phantom` 필드에 `PhantomData` 값을 제공하면됩니다.
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## 사용하지 않는 유형 매개 변수
///
/// 데이터가 실제로 구조체 자체에서 발견되지 않더라도 구조체가 "tied" 인 데이터 유형을 나타내는 사용되지 않은 형식 매개 변수가있는 경우가 있습니다.
/// 다음은 [FFI] 에서 발생하는 예입니다.
/// 외부 인터페이스는 `*mut ()` 유형의 핸들을 사용하여 다른 유형의 Rust 값을 참조합니다.
/// 핸들을 감싸는 구조체 `ExternalResource` 의 팬텀 유형 매개 변수를 사용하여 Rust 유형을 추적합니다.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## 소유권 및 낙차 확인
///
/// `PhantomData<T>` 유형의 필드를 추가하면 유형이 `T` 유형의 데이터를 소유 함을 나타냅니다.이는 유형이 삭제 될 때 `T` 유형의 인스턴스를 하나 이상 삭제할 수 있음을 의미합니다.
/// 이것은 Rust 컴파일러의 [drop check] 분석과 관련이 있습니다.
///
/// 구조체가 `T` 유형의 데이터를 실제로 *소유* 하지 않는 경우 소유권을 나타내지 않도록 `PhantomData<&'a T>` (ideally) 또는 `PhantomData<*const T>` (수명이 적용되지 않는 경우)와 같은 참조 유형을 사용하는 것이 좋습니다.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// 열거 형 판별 유형을 나타내는 데 사용되는 컴파일러 내부 trait 입니다.
///
/// 이 trait 는 모든 유형에 대해 자동으로 구현되며 [`mem::Discriminant`] 에 어떠한 보증도 추가하지 않습니다.
/// `DiscriminantKind::Discriminant` 와 `mem::Discriminant` 간에 변환하는 것은 **정의되지 않은 동작** 입니다.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` 에 필요한 trait bounds 를 충족해야하는 판별 자의 유형입니다.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// 컴파일러 내부 trait 는 형식에 `UnsafeCell` 가 내부적으로 포함되어 있는지 여부를 확인하는 데 사용되지만 간접을 통하지는 않습니다.
///
/// 예를 들어, 해당 유형의 `static` 가 읽기 전용 정적 메모리에 배치되는지 쓰기 가능한 정적 메모리에 배치되는지에 영향을줍니다.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// 고정 후 안전하게 이동할 수있는 유형입니다.
///
/// Rust 자체에는 고정 유형에 대한 개념이 없으며 이동 (예: 할당 또는 [`mem::replace`] 를 통한)이 항상 안전한 것으로 간주합니다.
///
/// [`Pin`][Pin] 유형은 유형 시스템을 통한 이동을 방지하기 위해 대신 사용됩니다.[`Pin<P<T>>`][Pin] 래퍼에 래핑 된 포인터 `P<T>` 는 밖으로 이동할 수 없습니다.
/// 고정에 대한 자세한 내용은 [`pin` module] 설명서를 참조하십시오.
///
/// `T` 용 `Unpin` trait 를 구현하면 유형을 고정하는 제한이 해제되어 [`mem::replace`] 와 같은 기능을 사용하여 `T` 를 [`Pin<P<T>>`][Pin] 밖으로 이동할 수 있습니다.
///
///
/// `Unpin` 고정되지 않은 데이터에는 전혀 영향을 미치지 않습니다.
/// 특히 [`mem::replace`] 는 `!Unpin` 데이터를 즐겁게 이동합니다 (`T: Unpin` 일 때뿐만 아니라 모든 `&mut T` 에서 작동 함).
/// 그러나 [`Pin<P<T>>`][Pin] 내부에 래핑 된 데이터에는 [`mem::replace`] 를 사용할 수 없습니다. 필요한 `&mut T` 를 얻을 수없고 *그게* 이 시스템을 작동하게 만드는 것입니다.
///
/// 예를 들어 이것은 `Unpin` 를 구현하는 유형에서만 수행 할 수 있습니다.
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` 를 호출하려면 가변 참조가 필요합니다.
/// // `Pin::deref_mut` 를 호출하는 (implicitly) 에 의해 이러한 참조를 얻을 수 있지만 이는 `String` 가 `Unpin` 를 구현하기 때문에 가능합니다.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// 이 trait 는 거의 모든 유형에 대해 자동으로 구현됩니다.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` 를 구현하지 않는 마커 유형입니다.
///
/// 유형에 `PhantomPinned` 가 포함 된 경우 기본적으로 `Unpin` 를 구현하지 않습니다.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// 기본 유형에 대한 `Copy` 구현.
///
/// Rust 에서 설명 할 수없는 구현은 `rustc_trait_selection` 의 `traits::SelectionContext::copy_clone_conditions()` 에서 구현됩니다.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// 공유 참조는 복사 할 수 있지만 변경 가능한 참조는 *할 수 없습니다*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}