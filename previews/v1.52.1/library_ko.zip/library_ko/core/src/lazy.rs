//! 지연 값 및 정적 데이터의 일회성 초기화.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// 한 번만 쓸 수있는 셀입니다.
///
/// `RefCell` 와 달리 `OnceCell` 는 해당 값에 대한 공유 `&T` 참조 만 제공합니다.
/// `Cell` 와 달리 `OnceCell` 는 액세스하기 위해 값을 복사하거나 바꿀 필요가 없습니다.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // 불변: 최대 한 번만 작성됩니다.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// 빈 셀을 새로 만듭니다.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// 기본 값에 대한 참조를 가져옵니다.
    ///
    /// 셀이 비어 있으면 `None` 를 반환합니다.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // 안전성: '내부'의 불변성으로 인한 안전
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// 기본 값에 대한 변경 가능한 참조를 가져옵니다.
    ///
    /// 셀이 비어 있으면 `None` 를 반환합니다.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // 안전: 고유 한 액세스 권한이 있으므로 안전합니다.
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// 셀의 내용을 `value` 로 설정합니다.
    ///
    /// # Errors
    ///
    /// 이 메서드는 셀이 비어 있으면 `Ok(())` 를, 가득 차면 `Err(value)` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // 안전: 중복되는 가변 차입을 가질 수 없기 때문에 안전합니다.
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // 안전: 이것은 우리가 슬롯을 설정하는 유일한 장소입니다.
        // reentrancy/concurrency 로 인해 가능하며 슬롯이 현재 `None` 인지 확인 했으므로이 쓰기는`inner`의 불변을 유지합니다.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// 셀의 내용을 가져 와서 셀이 비어있는 경우 `f` 로 초기화합니다.
    ///
    /// # Panics
    ///
    /// `f` panics 이면 panic 가 호출자에게 전파되고 셀은 초기화되지 않은 상태로 유지됩니다.
    ///
    ///
    /// `f` 에서 셀을 재진입하여 초기화하는 것은 오류입니다.이렇게하면 panic 가 발생합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// 셀의 내용을 가져 와서 셀이 비어있는 경우 `f` 로 초기화합니다.
    /// 셀이 비어 있고 `f` 가 실패하면 오류가 리턴됩니다.
    ///
    /// # Panics
    ///
    /// `f` panics 이면 panic 가 호출자에게 전파되고 셀은 초기화되지 않은 상태로 유지됩니다.
    ///
    ///
    /// `f` 에서 셀을 재진입하여 초기화하는 것은 오류입니다.이렇게하면 panic 가 발생합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // *일부* 형태의 재진입 초기화는 UB로 이어질 수 있습니다 (`reentrant_init` 테스트 참조).
        // `set/get` 를 유지하면서이 `assert` 를 제거하는 것만으로도 괜찮을 것이라고 생각하지만, 이전 값을 조용히 사용하는 것보다 panic 가 더 나은 것 같습니다.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// 셀을 소비하고 래핑 된 값을 반환합니다.
    ///
    /// 셀이 비어 있으면 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` 는 `self` 를 값으로 사용하므로 컴파일러는 현재 차용되지 않았는지 정적으로 확인합니다.
        // 따라서 `Option<T>` 를 이동하는 것이 안전합니다.
        self.inner.into_inner()
    }

    /// 이 `OnceCell` 에서 값을 가져와 초기화되지 않은 상태로 되돌립니다.
    ///
    /// 효과가 없으며 `OnceCell` 가 초기화되지 않은 경우 `None` 를 반환합니다.
    ///
    /// 가변 참조를 요구함으로써 안전성이 보장됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// 첫 번째 액세스에서 초기화되는 값입니다.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   초기화 준비
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// 주어진 초기화 함수로 새로운 lazy 값을 생성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// 이 지연 값을 강제로 평가하고 결과에 대한 참조를 반환합니다.
    ///
    ///
    /// 이것은 `Deref` impl과 동일하지만 명시 적입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// `Default` 를 초기화 함수로 사용하여 새로운 지연 값을 만듭니다.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}