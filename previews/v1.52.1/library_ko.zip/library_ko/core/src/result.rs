//! `Result` 유형을 사용한 오류 처리.
//!
//! [`Result<T, E>`][`Result`] 오류 반환 및 전파에 사용되는 유형입니다.
//! 성공을 나타내고 값을 포함하는 [`Ok(T)`] 변형과 오류를 나타내고 오류 값을 포함하는 [`Err(E)`] 가있는 열거 형입니다.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! 오류가 예상되고 복구 가능할 때마다 함수는 [`Result`] 를 반환합니다.`std` crate 에서 [`Result`] 는 [I/O](../../std/io/index.html) 에 가장 많이 사용됩니다.
//!
//! [`Result`] 를 반환하는 간단한 함수는 다음과 같이 정의하고 사용할 수 있습니다.
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`결과`]에 대한 패턴 일치는 간단한 경우에 명확하고 간단하지만 [`Result`] 에는보다 간결하게 작업 할 수있는 몇 가지 편리한 방법이 있습니다.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` 및 `is_err` 방법은 그들이 말하는 것을 수행합니다.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` 를 소비하고 다른 것을 생산합니다.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // 계산을 계속하려면 `and_then` 를 사용하십시오.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // `or_else` 를 사용하여 오류를 처리하십시오.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // 결과를 소비하고 `unwrap` 로 내용을 반환합니다.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # 결과를 사용해야합니다.
//!
//! 반환 값을 사용하여 오류를 표시하는 일반적인 문제는 반환 값을 무시하기 쉬워서 오류를 처리하지 못한다는 것입니다.
//! [`Result`] `#[must_use]` 속성으로 주석이 추가되어 결과 값이 무시 될 때 컴파일러가 경고를 발행합니다.
//! 따라서 [`Result`] 는 오류가 발생할 수 있지만 유용한 값을 반환하지 않는 함수에 특히 유용합니다.
//!
//! [`Write`] trait 에 의해 I/O 유형에 대해 정의 된 [`write_all`] 방법을 고려하십시오.
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] 의 실제 정의는 [`Result`]`의 동의어 인 [`io::Result`] 를 사용합니다.<T,`[`io: :Error`]`>`.*
//!
//! 이 메서드는 값을 생성하지 않지만 쓰기가 실패 할 수 있습니다.오류 케이스를 처리하는 것이 중요하며 다음과 같이 작성하지 *않습니다*.
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // `write_all` 오류가 발생하면 반환 값이 무시되므로 알 수 없습니다.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Rust 에 작성 *하면 컴파일러는 경고를 제공합니다 (기본적으로 `unused_must_use` lint 에 의해 제어 됨).
//!
//! 대신 오류를 처리하지 않으려면 [`expect`] 로 성공을 주장 할 수 있습니다.
//! 쓰기가 실패하면 panic 가 발생하여 이유를 나타내는 약간 유용한 메시지를 제공합니다.
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! 단순히 성공을 주장 할 수도 있습니다.
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! 또는 [`?`] 를 사용하여 오류를 호출 스택 위로 전파하십시오.
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # 물음표 연산자, `?`
//!
//! [`Result`] 유형을 반환하는 많은 함수를 호출하는 코드를 작성할 때 오류 처리가 지루할 수 있습니다.
//! 물음표 연산자 [`?`] 는 호출 스택에 오류를 전파하는 상용구를 숨 깁니다.
//!
//! 다음을 대체합니다.
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // 오류에 대한 조기 반품
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! 이것으로 :
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // 오류에 대한 조기 반품
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *훨씬 좋습니다!*
//!
//! [`?`] 로 표현식을 끝내면 결과가 [`Err`] 가 아닌 한 래핑되지 않은 성공 ([`Ok`]) 값이됩니다.이 경우 [`Err`] 는 둘러싸는 함수에서 일찍 반환됩니다.
//!
//!
//! [`?`] [`Result`] 가 제공하는 [`Err`] 의 조기 반환으로 인해 [`Result`] 를 반환하는 함수에서만 사용할 수 있습니다.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` 성공 ([`Ok`]) 또는 실패 ([`Err`]) 를 나타내는 유형입니다.
///
/// 자세한 내용은 [module documentation](self) 를 참조하십시오.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// 성공 값을 포함합니다.
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// 오류 값을 포함합니다.
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// 유형 구현
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // 포함 된 값 쿼리
    /////////////////////////////////////////////////////////////////////////

    /// 결과가 [`Ok`] 이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// 결과가 [`Err`] 이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// 결과가 주어진 값을 포함하는 [`Ok`] 값이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// 결과가 주어진 값을 포함하는 [`Err`] 값이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 각 변형에 대한 어댑터
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` 에서 [`Option<T>`] 로 변환합니다.
    ///
    /// `self` 를 [`Option<T>`] 로 변환하여 `self` 를 사용하고 오류가있는 경우 버립니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` 에서 [`Option<E>`] 로 변환합니다.
    ///
    /// `self` 를 [`Option<E>`] 로 변환하여 `self` 를 사용하고 성공 값이있는 경우 버립니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 참조 작업을위한 어댑터
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` 에서 `Result<&T, &E>` 로 변환합니다.
    ///
    /// 원본을 그대로두고 원본에 대한 참조를 포함하는 새 `Result` 를 생성합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` 에서 `Result<&mut T, &mut E>` 로 변환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 포함 된 값 변환
    /////////////////////////////////////////////////////////////////////////

    /// 포함 된 [`Ok`] 값에 함수를 적용하여 `Result<T, E>` 를 `Result<U, E>` 에 매핑하고 [`Err`] 값은 그대로 둡니다.
    ///
    ///
    /// 이 함수는 두 함수의 결과를 구성하는 데 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// 2를 곱한 문자열의 각 줄에 숫자를 인쇄하십시오.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// 포함 된 값 ([`Ok`] 인 경우)에 함수를 적용하거나 제공된 기본값 ([`Err`] 인 경우)을 반환합니다.
    ///
    /// `map_or` 에 전달 된 인수는 열심히 평가됩니다.함수 호출 결과를 전달하는 경우 느리게 평가되는 [`map_or_else`] 를 사용하는 것이 좋습니다.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// 함수를 포함 된 [`Ok`] 값에 적용하거나 대체 함수를 포함 된 [`Err`] 값에 적용하여 `Result<T, E>` 를 `U` 에 매핑합니다.
    ///
    ///
    /// 이 함수는 오류를 처리하는 동안 성공적인 결과를 압축 해제하는 데 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// 포함 된 [`Err`] 값에 함수를 적용하여 `Result<T, E>` 를 `Result<T, F>` 에 매핑하고 [`Ok`] 값은 그대로 둡니다.
    ///
    ///
    /// 이 함수는 오류를 처리하는 동안 성공적인 결과를 전달하는 데 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // 반복자 생성자
    /////////////////////////////////////////////////////////////////////////

    /// 포함 된 값에 대한 반복기를 반환합니다.
    ///
    /// 반복기는 결과가 [`Result::Ok`] 이면 하나의 값을 생성하고 그렇지 않으면 아무 것도 생성하지 않습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// 포함 된 값에 대해 변경 가능한 반복기를 반환합니다.
    ///
    /// 반복기는 결과가 [`Result::Ok`] 이면 하나의 값을 생성하고 그렇지 않으면 아무 것도 생성하지 않습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // 값에 대한 부울 연산, eager 및 lazy
    /////////////////////////////////////////////////////////////////////////

    /// 결과가 [`Ok`] 이면 `res` 를 반환하고, 그렇지 않으면 `self` 의 [`Err`] 값을 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// 결과가 [`Ok`] 이면 `op` 를 호출하고, 그렇지 않으면 `self` 의 [`Err`] 값을 반환합니다.
    ///
    ///
    /// 이 기능은 `Result` 값을 기반으로하는 제어 흐름에 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// 결과가 [`Err`] 이면 `res` 를 반환하고, 그렇지 않으면 `self` 의 [`Ok`] 값을 반환합니다.
    ///
    /// `or` 에 전달 된 인수는 열심히 평가됩니다.함수 호출 결과를 전달하는 경우 느리게 평가되는 [`or_else`] 를 사용하는 것이 좋습니다.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// 결과가 [`Err`] 이면 `op` 를 호출하고, 그렇지 않으면 `self` 의 [`Ok`] 값을 반환합니다.
    ///
    ///
    /// 이 기능은 결과 값에 따라 제어 흐름에 사용할 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// 포함 된 [`Ok`] 값 또는 제공된 기본값을 반환합니다.
    ///
    /// `unwrap_or` 에 전달 된 인수는 열심히 평가됩니다.함수 호출 결과를 전달하는 경우 느리게 평가되는 [`unwrap_or_else`] 를 사용하는 것이 좋습니다.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// 포함 된 [`Ok`] 값을 반환하거나 클로저에서 계산합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// 포함 된 [`Ok`] 값을 반환하고 값이 [`Err`] 가 아닌지 확인하지 않고 `self` 값을 사용합니다.
    ///
    ///
    /// # Safety
    ///
    /// [`Err`] 에서이 메서드를 호출하는 것은 *[정의되지 않은 동작]* 입니다.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // 정의되지 않은 동작!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // 안전: 발신자가 안전 계약을 유지해야합니다.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// 포함 된 [`Err`] 값을 반환하고 값이 [`Ok`] 가 아닌지 확인하지 않고 `self` 값을 사용합니다.
    ///
    ///
    /// # Safety
    ///
    /// [`Ok`] 에서이 메서드를 호출하는 것은 *[정의되지 않은 동작]* 입니다.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // 정의되지 않은 동작!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // 안전: 발신자가 안전 계약을 유지해야합니다.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` 부분의 내용을 복사하여 `Result<&T, E>` 를 `Result<T, E>` 에 매핑합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` 부분의 내용을 복사하여 `Result<&mut T, E>` 를 `Result<T, E>` 에 매핑합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` 부분의 내용을 복제하여 `Result<&T, E>` 를 `Result<T, E>` 에 매핑합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` 부분의 내용을 복제하여 `Result<&mut T, E>` 를 `Result<T, E>` 에 매핑합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// 포함 된 [`Ok`] 값을 반환하고 `self` 값을 사용합니다.
    ///
    /// # Panics
    ///
    /// 값이 [`Err`] 인 경우 Panics, 전달 된 메시지가 포함 된 panic 메시지 및 [`Err`] 의 내용.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// 포함 된 [`Ok`] 값을 반환하고 `self` 값을 사용합니다.
    ///
    /// 이 함수는 panic 일 수 있으므로 일반적으로 사용하지 않는 것이 좋습니다.
    /// 대신 패턴 일치를 사용하고 [`Err`] 케이스를 명시 적으로 처리하거나 [`unwrap_or`], [`unwrap_or_else`] 또는 [`unwrap_or_default`] 를 호출하십시오.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// 값이 [`Err`] 인 경우 Panics 이며 [`Err`]의 값에 의해 panic 메시지가 제공됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// 포함 된 [`Err`] 값을 반환하고 `self` 값을 사용합니다.
    ///
    /// # Panics
    ///
    /// 값이 [`Ok`] 인 경우 Panics, 전달 된 메시지가 포함 된 panic 메시지 및 [`Ok`] 의 내용.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// 포함 된 [`Err`] 값을 반환하고 `self` 값을 사용합니다.
    ///
    /// # Panics
    ///
    /// 값이 [`Ok`] 인 경우 Panics 이며 [`Ok`] 값에 의해 제공된 사용자 지정 panic 메시지가 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// 포함 된 [`Ok`] 값 또는 기본값을 반환합니다.
    ///
    /// `self` 인수를 사용하고 [`Ok`] 이면 포함 된 값을 반환하고, 그렇지 않으면 [`Err`] 이면 해당 유형의 기본값을 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 문자열을 정수로 변환하여 형식이 잘못된 문자열을 0 (정수 기본값)으로 바꿉니다.
    /// [`parse`] 문자열을 [`FromStr`] 를 구현하는 다른 유형으로 변환하여 오류시 [`Err`] 를 반환합니다.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// 포함 된 [`Ok`] 값을 반환하지만 panics 는 반환하지 않습니다.
    ///
    /// [`unwrap`] 와 달리이 메서드는 구현 된 결과 유형에 대해 panic 를 적용하지 않는 것으로 알려져 있습니다.
    /// 따라서 `Result` 의 오류 유형이 나중에 실제로 발생할 수있는 오류로 변경되면 컴파일에 실패하는 유지 보수성 보호 수단으로 `unwrap` 대신 사용할 수 있습니다.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (또는 `&Result<T, E>`)에서 `Result<&<T as Deref>::Target, &E>` 로 변환합니다.
    ///
    /// [`Deref`](crate::ops::Deref) 를 통해 원래 [`Result`] 의 [`Ok`] 변형을 강제 변환하고 새 [`Result`] 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (또는 `&mut Result<T, E>`)에서 `Result<&mut <T as DerefMut>::Target, &mut E>` 로 변환합니다.
    ///
    /// [`DerefMut`](crate::ops::DerefMut) 를 통해 원래 [`Result`] 의 [`Ok`] 변형을 강제 변환하고 새 [`Result`] 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// `Option` 의 `Result` 를 `Result` 의 `Option` 로 바꿉니다.
    ///
    /// `Ok(None)` `None` 에 매핑됩니다.
    /// `Ok(Some(_))` `Err(_)` 는 `Some(Ok(_))` 및 `Some(Err(_))` 에 매핑됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` 에서 `Result<T, E>` 로 변환
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// 병합은 한 번에 한 수준의 중첩 만 제거합니다.
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` 가 `Ok` 이면 [`Ok`] 값을 반환하고 `self` 가 `Err` 이면 [`Err`] 값을 반환합니다.
    ///
    /// 즉,이 함수는 결과가 `Ok` 인지 `Err` 인지 여부에 관계없이 `Result<T, T>` 의 값 (`T`)을 반환합니다.
    ///
    /// 이는 [`Atomic*::compare_exchange`] 또는 [`slice::binary_search`] 와 같은 API와 함께 사용할 때 유용 할 수 있지만 결과가 `Ok` 인지 여부는 신경 쓰지 않는 경우에만 유용합니다.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// 메서드의 코드 크기를 줄이기위한 별도의 함수입니다.
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait 구현
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// 포함 된 값에 대한 소비 반복자를 반환합니다.
    ///
    /// 반복기는 결과가 [`Result::Ok`] 이면 하나의 값을 생성하고 그렇지 않으면 아무 것도 생성하지 않습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// 결과 반복자
/////////////////////////////////////////////////////////////////////////////

/// [`Result`] 의 [`Ok`] 변형에 대한 참조에 대한 반복기입니다.
///
/// 반복기는 결과가 [`Ok`] 이면 하나의 값을 생성하고 그렇지 않으면 아무 것도 생성하지 않습니다.
///
/// [`Result::iter`] 에 의해 생성되었습니다.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// [`Result`] 의 [`Ok`] 변형에 대한 변경 가능한 참조에 대한 반복기입니다.
///
/// [`Result::iter_mut`] 에 의해 생성되었습니다.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Result`] 의 [`Ok`] 변형 값에 대한 반복기입니다.
///
/// 반복기는 결과가 [`Ok`] 이면 하나의 값을 생성하고 그렇지 않으면 아무 것도 생성하지 않습니다.
///
/// 이 구조체는 [`Result`] ([`IntoIterator`] trait 에서 제공)의 [`into_iter`] 메서드에 의해 생성됩니다.
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` 의 각 요소를 가져옵니다. `Err` 이면 더 이상 요소를 가져 오지 않고 `Err` 가 반환됩니다.
    /// `Err` 가 발생하지 않으면 각 `Result` 의 값이있는 컨테이너가 반환됩니다.
    ///
    /// 다음은 오버플로를 확인하면서 vector 의 모든 정수를 증가시키는 예입니다.
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// 다음은 다른 정수 목록에서 하나를 빼려고 시도하는 또 다른 예입니다. 이번에는 언더 플로를 확인합니다.
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// 다음은 첫 번째 `Err` 이후 `iter` 에서 더 이상 요소를 가져 오지 않음을 보여주는 이전 예제의 변형입니다.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// 세 번째 요소로 인해 언더 플로가 발생했기 때문에 추가 요소가 사용되지 않았으므로 `shared` 의 최종 값은 16이 아니라 6 (= `3 + 2 + 1`)입니다.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): 이 성능 버그가 닫히면 Iterator::scan 로 대체 될 수 있습니다.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}