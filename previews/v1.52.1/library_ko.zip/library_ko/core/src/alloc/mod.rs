//! 메모리 할당 API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` 오류는 지정된 입력 인수를이 할당 자와 결합 할 때 리소스 고갈 또는 잘못된 문제로 인한 할당 실패를 나타냅니다.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (trait 오류의 다운 스트림 impl에 필요합니다)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` 의 구현은 [`Layout`][] 를 통해 설명 된 임의의 데이터 블록을 할당, 확장, 축소 및 할당 해제 할 수 있습니다.
///
/// `Allocator` 할당 된 메모리에 대한 포인터를 업데이트하지 않고는 `MyAlloc([u8; N])` 와 같은 할당자를 이동할 수 없기 때문에 ZST, 참조 또는 스마트 포인터에서 구현되도록 설계되었습니다.
///
/// [`GlobalAlloc`][] 와 달리 `Allocator` 에서는 크기가 0 인 할당이 허용됩니다.
/// 기본 할당자가이를 지원하지 않거나 (예: jemalloc) 널 포인터 (예: `libc::malloc`)를 반환하면 구현에서이를 포착해야합니다.
///
/// ### 현재 할당 된 메모리
///
/// 일부 메서드는 할당자를 통해 메모리 블록이 *현재 할당* 되어야합니다.이는 다음을 의미합니다.
///
/// * 해당 메모리 블록의 시작 주소는 이전에 [`allocate`], [`grow`] 또는 [`shrink`] 에 의해 반환되었습니다.
///
/// * 메모리 블록은 이후에 할당 해제되지 않았습니다. 여기서 블록은 [`deallocate`] 에 전달되어 직접 할당 해제되거나 `Ok` 를 반환하는 [`grow`] 또는 [`shrink`] 에 전달되어 변경되었습니다.
///
/// `grow` 또는 `shrink` 가 `Err` 를 반환 한 경우 전달 된 포인터는 계속 유효합니다.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### 메모리 피팅
///
/// 일부 방법에서는 레이아웃이 메모리 블록에 *맞아야* 합니다.
/// "fit" 에 대한 레이아웃에 대해 메모리 블록이 의미하는 것은 (또는 이와 동등하게 "fit" 에 대한 메모리 블록에 대해 레이아웃) 다음 조건이 유지되어야한다는 것입니다.
///
/// * 블록은 [`layout.align()`] 와 동일한 정렬로 할당되어야합니다.
///
/// * 제공된 [`layout.size()`] 는 `min ..= max` 범위에 있어야합니다. 여기서 :
///   - `min` 블록을 할당하는 데 가장 최근에 사용 된 레이아웃의 크기입니다.
///   - `max` [`allocate`], [`grow`] 또는 [`shrink`] 에서 반환 된 최신 실제 크기입니다.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * 할당 자에서 반환 된 메모리 블록은 유효한 메모리를 가리키고 인스턴스와 모든 복제본이 삭제 될 때까지 유효성을 유지해야합니다.
///
/// * 할당자를 복제하거나 이동하면이 할당 자에서 반환 된 메모리 블록이 무효화되지 않아야합니다.복제 된 할당자는 동일한 할당 자처럼 동작해야합니다.
///
/// * [*currently allocated*] 인 메모리 블록에 대한 포인터는 할당 자의 다른 방법으로 전달 될 수 있습니다.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// 메모리 블록 할당을 시도합니다.
    ///
    /// 성공하면 `layout` 의 크기 및 정렬 보장을 충족하는 [`NonNull<[u8]>`][NonNull] 를 반환합니다.
    ///
    /// 반환 된 블록은 `layout.size()` 에서 지정한 것보다 더 큰 크기를 가질 수 있으며 내용이 초기화되거나 초기화되지 않을 수 있습니다.
    ///
    /// # Errors
    ///
    /// `Err` 를 반환하면 메모리가 모두 소모되었거나 `layout` 가 할당 자의 크기 또는 정렬 제약 조건을 충족하지 않음을 나타냅니다.
    ///
    /// 구현은 당황하거나 중단하는 대신 메모리 고갈시 `Err` 를 반환하도록 권장되지만 엄격한 요구 사항은 아닙니다.
    /// (구체적으로: 메모리 고갈시 중단되는 기본 기본 할당 라이브러리 위에이 trait 를 구현하는 것은 *합법적* 입니다.)
    ///
    /// 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` 처럼 작동하지만 반환 된 메모리가 0으로 초기화되도록합니다.
    ///
    /// # Errors
    ///
    /// `Err` 를 반환하면 메모리가 모두 소모되었거나 `layout` 가 할당 자의 크기 또는 정렬 제약 조건을 충족하지 않음을 나타냅니다.
    ///
    /// 구현은 당황하거나 중단하는 대신 메모리 고갈시 `Err` 를 반환하도록 권장되지만 엄격한 요구 사항은 아닙니다.
    /// (구체적으로: 메모리 고갈시 중단되는 기본 기본 할당 라이브러리 위에이 trait 를 구현하는 것은 *합법적* 입니다.)
    ///
    /// 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // 안전: `alloc` 는 유효한 메모리 블록을 반환합니다.
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` 에서 참조하는 메모리를 할당 해제합니다.
    ///
    /// # Safety
    ///
    /// * `ptr` 이 할당자를 통해 [*currently allocated*] 메모리 블록을 나타내야합니다.
    /// * `layout` 해당 메모리 블록을 [*fit*] 해야합니다.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// 메모리 블록 확장을 시도합니다.
    ///
    /// 포인터와 할당 된 메모리의 실제 크기를 포함하는 새로운 [`NonNull<[u8]>`][NonNull] 를 반환합니다.포인터는 `new_layout` 에서 설명하는 데이터를 보유하는 데 적합합니다.
    /// 이를 수행하기 위해 할당자는 `ptr` 가 참조하는 할당을 새 레이아웃에 맞게 확장 할 수 있습니다.
    ///
    /// 이것이 `Ok` 를 반환하면 `ptr` 가 참조하는 메모리 블록의 소유권이이 할당 자로 전송 된 것입니다.
    /// 메모리는 해제되거나 해제되지 않았을 수 있으며,이 메서드의 반환 값을 통해 호출자에게 다시 전송되지 않는 한 사용할 수없는 것으로 간주되어야합니다.
    ///
    /// 이 메서드가 `Err` 를 반환하면 메모리 블록의 소유권이이 할당 자로 전송되지 않았고 메모리 블록의 내용이 변경되지 않은 것입니다.
    ///
    /// # Safety
    ///
    /// * `ptr` 이 할당자를 통해 메모리 [*currently allocated*] 블록을 표시해야합니다.
    /// * `old_layout` 메모리 블록을 [*fit*] 해야합니다 (`new_layout` 인수는 맞출 필요가 없습니다.).
    /// * `new_layout.size()` `old_layout.size()` 보다 크거나 같아야합니다.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 새 레이아웃이 할당 자의 크기 및 할당 자의 정렬 제약 조건을 충족하지 않거나 확장이 실패하면 `Err` 를 반환합니다.
    ///
    /// 구현은 당황하거나 중단하는 대신 메모리 고갈시 `Err` 를 반환하도록 권장되지만 엄격한 요구 사항은 아닙니다.
    /// (구체적으로: 메모리 고갈시 중단되는 기본 기본 할당 라이브러리 위에이 trait 를 구현하는 것은 *합법적* 입니다.)
    ///
    /// 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // 안전: `new_layout.size()` 는 다음보다 크거나 같아야하기 때문입니다.
        // `old_layout.size()`, 이전 및 새 메모리 할당은 모두 `old_layout.size()` 바이트의 읽기 및 쓰기에 유효합니다.
        // 또한 이전 할당이 아직 할당 해제되지 않았기 때문에 `new_ptr` 와 겹칠 수 없습니다.
        // 따라서 `copy_nonoverlapping` 에 대한 호출은 안전합니다.
        // `dealloc` 에 대한 안전 계약은 발신자가 유지해야합니다.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` 처럼 작동하지만 반환되기 전에 새 내용이 0으로 설정되도록합니다.
    ///
    /// 메모리 블록은 성공적인 호출 후 다음 내용을 포함합니다.
    /// `grow_zeroed`:
    ///   * `0..old_layout.size()` 바이트는 원래 할당에서 보존됩니다.
    ///   * `old_layout.size()..old_size` 바이트는 할당 자 구현에 따라 유지되거나 0이됩니다.
    ///   `old_size` `grow_zeroed` 호출 이전의 메모리 블록 크기를 나타내며, 할당 될 때 원래 요청 된 크기보다 클 수 있습니다.
    ///   * `old_size..new_size` 바이트는 0이됩니다.`new_size` 는 `grow_zeroed` 호출에서 반환 된 메모리 블록의 크기를 나타냅니다.
    ///
    /// # Safety
    ///
    /// * `ptr` 이 할당자를 통해 메모리 [*currently allocated*] 블록을 표시해야합니다.
    /// * `old_layout` 메모리 블록을 [*fit*] 해야합니다 (`new_layout` 인수는 맞출 필요가 없습니다.).
    /// * `new_layout.size()` `old_layout.size()` 보다 크거나 같아야합니다.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 새 레이아웃이 할당 자의 크기 및 할당 자의 정렬 제약 조건을 충족하지 않거나 확장이 실패하면 `Err` 를 반환합니다.
    ///
    /// 구현은 당황하거나 중단하는 대신 메모리 고갈시 `Err` 를 반환하도록 권장되지만 엄격한 요구 사항은 아닙니다.
    /// (구체적으로: 메모리 고갈시 중단되는 기본 기본 할당 라이브러리 위에이 trait 를 구현하는 것은 *합법적* 입니다.)
    ///
    /// 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // 안전: `new_layout.size()` 는 다음보다 크거나 같아야하기 때문입니다.
        // `old_layout.size()`, 이전 및 새 메모리 할당은 모두 `old_layout.size()` 바이트의 읽기 및 쓰기에 유효합니다.
        // 또한 이전 할당이 아직 할당 해제되지 않았기 때문에 `new_ptr` 와 겹칠 수 없습니다.
        // 따라서 `copy_nonoverlapping` 에 대한 호출은 안전합니다.
        // `dealloc` 에 대한 안전 계약은 발신자가 유지해야합니다.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// 메모리 블록 축소를 시도합니다.
    ///
    /// 포인터와 할당 된 메모리의 실제 크기를 포함하는 새로운 [`NonNull<[u8]>`][NonNull] 를 반환합니다.포인터는 `new_layout` 에서 설명하는 데이터를 보유하는 데 적합합니다.
    /// 이를 수행하기 위해 할당자는 `ptr` 가 참조하는 할당을 새 레이아웃에 맞게 축소 할 수 있습니다.
    ///
    /// 이것이 `Ok` 를 반환하면 `ptr` 가 참조하는 메모리 블록의 소유권이이 할당 자로 전송 된 것입니다.
    /// 메모리는 해제되거나 해제되지 않았을 수 있으며,이 메서드의 반환 값을 통해 호출자에게 다시 전송되지 않는 한 사용할 수없는 것으로 간주되어야합니다.
    ///
    /// 이 메서드가 `Err` 를 반환하면 메모리 블록의 소유권이이 할당 자로 전송되지 않았고 메모리 블록의 내용이 변경되지 않은 것입니다.
    ///
    /// # Safety
    ///
    /// * `ptr` 이 할당자를 통해 메모리 [*currently allocated*] 블록을 표시해야합니다.
    /// * `old_layout` 메모리 블록을 [*fit*] 해야합니다 (`new_layout` 인수는 맞출 필요가 없습니다.).
    /// * `new_layout.size()` `old_layout.size()` 보다 작거나 같아야합니다.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 새 레이아웃이 할당 자의 크기 및 할당 자의 정렬 제약 조건을 충족하지 않거나 축소가 실패하면 `Err` 를 반환합니다.
    ///
    /// 구현은 당황하거나 중단하는 대신 메모리 고갈시 `Err` 를 반환하도록 권장되지만 엄격한 요구 사항은 아닙니다.
    /// (구체적으로: 메모리 고갈시 중단되는 기본 기본 할당 라이브러리 위에이 trait 를 구현하는 것은 *합법적* 입니다.)
    ///
    /// 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // 안전: `new_layout.size()` 는 다음보다 작거나 같아야하기 때문입니다.
        // `old_layout.size()`, 이전 및 새 메모리 할당은 모두 `new_layout.size()` 바이트의 읽기 및 쓰기에 유효합니다.
        // 또한 이전 할당이 아직 할당 해제되지 않았기 때문에 `new_ptr` 와 겹칠 수 없습니다.
        // 따라서 `copy_nonoverlapping` 에 대한 호출은 안전합니다.
        // `dealloc` 에 대한 안전 계약은 발신자가 유지해야합니다.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// 이 `Allocator` 인스턴스에 대한 "by reference" 어댑터를 만듭니다.
    ///
    /// 반환 된 어댑터는 `Allocator` 도 구현하며 간단히 빌릴 것입니다.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // 안전: 발신자가 안전 계약을 유지해야합니다.
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 안전: 발신자가 안전 계약을 유지해야합니다.
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 안전: 발신자가 안전 계약을 유지해야합니다.
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 안전: 발신자가 안전 계약을 유지해야합니다.
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}