use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// `#[global_allocator]` 속성을 통해 표준 라이브러리의 기본값으로 등록 할 수있는 메모리 할당 자입니다.
///
/// 일부 메서드는 할당자를 통해 메모리 블록이 *현재 할당* 되어야합니다.이는 다음을 의미합니다.
///
/// * 해당 메모리 블록의 시작 주소는 이전에 `alloc` 와 같은 할당 방법에 대한 호출에 의해 반환되었습니다.
///
/// * 메모리 블록은 이후에 할당 해제되지 않았습니다. 여기서 블록은 `dealloc` 와 같은 할당 해제 메서드에 전달되거나 널이 아닌 포인터를 반환하는 재 할당 메서드에 전달되어 할당 해제됩니다.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait 는 여러 가지 이유로 `unsafe` trait 이며 구현자는 다음 계약을 준수하는지 확인해야합니다.
///
/// * 전역 할당자가 해제되면 정의되지 않은 동작입니다.이 제한은 future 에서 해제 될 수 있지만 현재 이러한 함수 중 하나에서 panic 가 있으면 메모리가 안전하지 않을 수 있습니다.
///
/// * `Layout` 일반적으로 쿼리 및 계산이 정확해야합니다.이 trait 의 호출자는 각 메서드에 정의 된 계약에 의존 할 수 있으며 구현자는 그러한 계약이 사실로 유지되도록해야합니다.
///
/// * 소스에 명시적인 힙 할당이 있더라도 실제로 발생하는 할당에 의존하지 않을 수 있습니다.
/// 옵티마이 저는 완전히 제거하거나 스택으로 이동하여 할당자를 호출하지 않을 수있는 사용되지 않은 할당을 감지 할 수 있습니다.
/// 옵티마이 저는 할당이 오류가 없다고 가정 할 수 있으므로 할당 자 오류로 인해 실패했던 코드가 이제 갑자기 작동 할 수 있습니다. 이는 옵티마이 저가 할당 필요성을 해결했기 때문입니다.
/// 보다 구체적으로, 다음 코드 예제는 사용자 지정 할당자가 할당 된 횟수를 계산할 수 있는지 여부에 관계없이 건전하지 않습니다.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   위에서 언급 한 최적화는 적용 할 수있는 유일한 최적화가 아닙니다.프로그램 동작을 변경하지 않고 제거 할 수있는 경우 일반적으로 발생하는 힙 할당에 의존하지 않을 수 있습니다.
///   할당이 발생했는지 여부는 인쇄 또는 기타 부작용이있는 할당을 추적하는 할당자를 통해 감지 될 수 있더라도 프로그램 동작의 일부가 아닙니다.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// 주어진 `layout` 에 설명 된대로 메모리를 할당하십시오.
    ///
    /// 새로 할당 된 메모리에 대한 포인터를 반환하거나 할당 실패를 나타내는 null을 반환합니다.
    ///
    /// # Safety
    ///
    /// 호출자가 `layout` 의 크기가 0이 아닌지 확인하지 않으면 정의되지 않은 동작이 발생할 수 있으므로이 함수는 안전하지 않습니다.
    ///
    /// (확장 하위 특성은 동작에 대해보다 구체적인 경계를 제공 할 수 있습니다. 예를 들어, 크기가 0 인 할당 요청에 대한 응답으로 센티넬 주소 또는 널 포인터를 보장합니다.)
    ///
    /// 할당 된 메모리 블록은 초기화되거나 초기화되지 않을 수 있습니다.
    ///
    /// # Errors
    ///
    /// null 포인터를 반환하면 메모리가 모두 소모되었거나 `layout` 가이 할당 자의 크기 또는 정렬 제약 조건을 충족하지 않음을 나타냅니다.
    ///
    /// 구현은 중단하지 않고 메모리 고갈시 null을 반환하도록 권장되지만 엄격한 요구 사항은 아닙니다.
    /// (구체적으로: 메모리 고갈시 중단되는 기본 기본 할당 라이브러리 위에이 trait 를 구현하는 것은 *합법적* 입니다.)
    ///
    /// 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// 주어진 `layout` 를 사용하여 주어진 `ptr` 포인터에서 메모리 블록을 할당 해제합니다.
    ///
    /// # Safety
    ///
    /// 호출자가 다음 사항을 모두 확인하지 않으면 정의되지 않은 동작이 발생할 수 있으므로이 함수는 안전하지 않습니다.
    ///
    ///
    /// * `ptr` 이 할당자를 통해 현재 할당 된 메모리 블록을 나타내야합니다.
    ///
    /// * `layout` 해당 메모리 블록을 할당하는 데 사용 된 것과 동일한 레이아웃이어야합니다.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// `alloc` 처럼 동작하지만 반환되기 전에 내용이 0으로 설정되었는지 확인합니다.
    ///
    /// # Safety
    ///
    /// 이 기능은 `alloc` 와 같은 이유로 안전하지 않습니다.
    /// 그러나 할당 된 메모리 블록은 초기화됩니다.
    ///
    /// # Errors
    ///
    /// null 포인터를 반환하면 메모리가 모두 소모되었거나 `layout` 가 `alloc` 에서와 같이 할당 자의 크기 또는 정렬 제약 조건을 충족하지 않음을 나타냅니다.
    ///
    /// 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // 안전: `alloc` 에 대한 안전 계약은 발신자가 지켜야합니다.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // 안전: 할당이 성공하면 `ptr` 의 영역
            // `size` 크기는 쓰기에 유효합니다.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// 주어진 `new_size` 로 메모리 블록을 줄이거 나 늘립니다.
    /// 블록은 주어진 `ptr` 포인터와 `layout` 로 설명됩니다.
    ///
    /// 이것이 널이 아닌 포인터를 리턴하면 `ptr` 가 참조하는 메모리 블록의 소유권이이 할당 자로 전송 된 것입니다.
    /// 메모리는 할당 해제되거나 해제되지 않았을 수 있으며 사용할 수없는 것으로 간주되어야합니다 (물론이 메서드의 반환 값을 통해 호출자에게 다시 전송되지 않는 한).
    /// 새 메모리 블록은 `layout` 로 할당되지만 `size` 는 `new_size` 로 업데이트됩니다.
    /// 이 새로운 레이아웃은 `dealloc` 로 새 메모리 블록을 할당 해제 할 때 사용해야합니다.
    /// 새 메모리 블록의 범위 `0..min(layout.size(), new_size)`는 원래 블록과 동일한 값을 갖도록 보장됩니다.
    ///
    /// 이 메서드가 null을 반환하면 메모리 블록의 소유권이이 할당 자로 전송되지 않았고 메모리 블록의 내용이 변경되지 않은 것입니다.
    ///
    /// # Safety
    ///
    /// 호출자가 다음 사항을 모두 확인하지 않으면 정의되지 않은 동작이 발생할 수 있으므로이 함수는 안전하지 않습니다.
    ///
    /// * `ptr` 현재이 할당자를 통해 할당되어야합니다.
    ///
    /// * `layout` 해당 메모리 블록을 할당하는 데 사용 된 것과 동일한 레이아웃이어야합니다.
    ///
    /// * `new_size` 0보다 커야합니다.
    ///
    /// * `new_size`, `layout.align()` 의 가장 가까운 배수로 반올림 할 때 오버플로되지 않아야합니다 (즉, 반올림 된 값은 `usize::MAX` 보다 작아야 함).
    ///
    /// (확장 하위 특성은 동작에 대해보다 구체적인 경계를 제공 할 수 있습니다. 예를 들어, 크기가 0 인 할당 요청에 대한 응답으로 센티넬 주소 또는 널 포인터를 보장합니다.)
    ///
    /// # Errors
    ///
    /// 새 레이아웃이 할당 자의 크기 및 정렬 제약 조건을 충족하지 않거나 재 할당이 실패하면 null을 반환합니다.
    ///
    /// 구현은 당황하거나 중단하는 대신 메모리 고갈시 null을 반환하도록 권장되지만 엄격한 요구 사항은 아닙니다.
    /// (구체적으로: 메모리 고갈시 중단되는 기본 기본 할당 라이브러리 위에이 trait 를 구현하는 것은 *합법적* 입니다.)
    ///
    /// 재 할당 오류에 대한 응답으로 계산을 중단하려는 클라이언트는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신 [`handle_alloc_error`] 함수를 호출하는 것이 좋습니다.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // 안전: 호출자는 `new_size` 가 오버플로되지 않도록해야합니다.
        // `layout.align()` `Layout` 에서 제공되므로 유효 함이 보장됩니다.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // 안전: 호출자는 `new_layout` 가 0보다 큰지 확인해야합니다.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // 안전: 이전에 할당 된 블록은 새로 할당 된 블록과 겹칠 수 없습니다.
            // `dealloc` 에 대한 안전 계약은 발신자가 유지해야합니다.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}