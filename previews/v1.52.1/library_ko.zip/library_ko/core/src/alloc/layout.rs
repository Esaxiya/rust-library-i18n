use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// 이 함수는 한 곳에서 사용되고 그 구현이 인라인 될 수 있지만 이전 시도에서는 rustc 가 느려졌습니다.
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// 메모리 블록의 레이아웃.
///
/// `Layout` 의 인스턴스는 특정 메모리 레이아웃을 설명합니다.
/// 할당 자에게 제공 할 입력으로 `Layout` 를 빌드합니다.
///
/// 모든 레이아웃에는 연관된 크기와 2의 거듭 제곱 정렬이 있습니다.
///
/// (`GlobalAlloc` 에서는 모든 메모리 요청의 크기가 0이 아니어야하지만 레이아웃이 0이 아닌 크기를 가질 필요는 *아닙니다*.
/// 호출자는 이와 같은 조건이 충족되는지 확인하고, 요구 사항이 더 느슨한 특정 할당자를 사용하거나, 더 관대 한 `Allocator` 인터페이스를 사용해야합니다.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // 요청 된 메모리 블록의 크기 (바이트 단위).
    size_: usize,

    // 요청 된 메모리 블록의 정렬 (바이트 단위)입니다.
    // `posix_memalign` 와 같은 API가이를 필요로하고 레이아웃 생성자에 부과하는 합리적인 제약이기 때문에 이것이 항상 2의 거듭 제곱임을 보장합니다.
    //
    //
    // (그러나 유사하게`align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// 주어진 `size` 및 `align` 에서 `Layout` 를 생성하거나 다음 조건 중 하나라도 충족되지 않으면 `LayoutError` 를 반환합니다.
    ///
    /// * `align` 0이 아니어야합니다.
    ///
    /// * `align` 2의 거듭 제곱이어야합니다.
    ///
    /// * `size`, `align` 의 가장 가까운 배수로 반올림 할 때 오버플로되지 않아야합니다 (즉, 반올림 된 값은 `usize::MAX` 보다 작거나 같아야 함).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (2의 거듭 제곱은 정렬!=0을 의미합니다.)

        // 반올림 된 크기는 다음과 같습니다.
        //   size_rounded_up=(크기 + 정렬, 1)&! (정렬, 1);
        //
        // 우리는 위에서 정렬!=0을 알고 있습니다.
        // 추가 (정렬, 1)가 오버플로되지 않으면 반올림해도됩니다.
        //
        // 반대로! (align, 1)로&-마스킹하면 하위 비트 만 제거됩니다.
        // 따라서 합계와 함께 오버플로가 발생하면&-mask가 해당 오버플로를 취소 할만큼 충분히 빼지 못합니다.
        //
        //
        // 위는 합계 오버플로를 확인하는 것이 필요하고 충분하다는 것을 의미합니다.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // 안전: `from_size_align_unchecked` 의 조건은
        // 위에서 확인했습니다.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// 모든 검사를 무시하고 레이아웃을 만듭니다.
    ///
    /// # Safety
    ///
    /// 이 함수는 [`Layout::from_size_align`] 의 사전 조건을 확인하지 않으므로 안전하지 않습니다.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // 안전: 호출자는 `align` 가 0보다 큰지 확인해야합니다.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// 이 레이아웃의 메모리 블록에 대한 최소 크기 (바이트)입니다.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// 이 레이아웃의 메모리 블록에 대한 최소 바이트 정렬입니다.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `T` 유형의 값을 보유하는 데 적합한 `Layout` 를 구성합니다.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // 안전: 정렬은 Rust 에 의해 2의 거듭 제곱이고
        // 크기 + 정렬 콤보는 주소 공간에 맞도록 보장됩니다.
        // 결과적으로 충분히 최적화되지 않은 경우 panics 코드를 삽입하지 않으려면 여기에서 확인되지 않은 생성자를 사용하십시오.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` 에 대한 백업 구조를 할당하는 데 사용할 수있는 레코드를 설명하는 레이아웃을 생성합니다 (trait 또는 슬라이스와 같은 다른 크기가 지정되지 않은 유형일 수 있음).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // 안전: 이것이 안전하지 않은 변형을 사용하는 이유는 `new` 의 근거를 참조하십시오.
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` 에 대한 백업 구조를 할당하는 데 사용할 수있는 레코드를 설명하는 레이아웃을 생성합니다 (trait 또는 슬라이스와 같은 다른 크기가 지정되지 않은 유형일 수 있음).
    ///
    /// # Safety
    ///
    /// 이 함수는 다음 조건이 충족되는 경우에만 호출해도 안전합니다.
    ///
    /// - `T` 가 `Sized` 이면이 함수는 항상 안전하게 호출 할 수 있습니다.
    /// - `T` 의 크기가 지정되지 않은 꼬리가 다음과 같은 경우 :
    ///     - [slice] 인 경우 슬라이스 꼬리의 길이는 초기화 된 정수 여야하며 *전체 값*(동적 꼬리 길이 + 정적으로 크기가 지정된 접두사)의 크기는 `isize` 에 맞아야합니다.
    ///     - [trait object] 인 경우 포인터의 vtable 부분은 unsizing coersion으로 획득 한 `T` 유형에 대해 유효한 vtable을 가리켜 야하며 *전체 값*(동적 꼬리 길이 + 정적으로 크기가 지정된 접두사)의 크기는 `isize` 에 맞아야합니다.
    ///
    ///     - (unstable) [extern type] 인 경우이 함수는 항상 호출하기에 안전하지만, panic 또는 extern 유형의 레이아웃을 알 수 없기 때문에 잘못된 값을 반환 할 수 있습니다.
    ///     이것은 extern 유형 tail에 대한 참조에서 [`Layout::for_value`] 와 동일한 동작입니다.
    ///     - 그렇지 않으면 보수적으로이 함수를 호출 할 수 없습니다.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // 안전: 이러한 함수의 전제 조건을 호출자에게 전달합니다.
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // 안전: 이것이 안전하지 않은 변형을 사용하는 이유는 `new` 의 근거를 참조하십시오.
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// 매달려 있지만이 레이아웃에 대해 잘 정렬 된 `NonNull` 를 만듭니다.
    ///
    /// 포인터 값은 잠재적으로 유효한 포인터를 나타낼 수 있으며 이는 "not yet initialized" 센티넬 값으로 사용해서는 안된다는 것을 의미합니다.
    /// 느리게 할당되는 유형은 다른 방법으로 초기화를 추적해야합니다.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // 안전: 정렬은 0이 아님을 보장합니다.
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` 와 동일한 레이아웃의 값을 보유 할 수 있지만 `align` 정렬 (바이트 단위로 측정)에 맞춰진 레코드를 설명하는 레이아웃을 만듭니다.
    ///
    ///
    /// `self` 가 이미 규정 된 정렬을 충족하면 `self` 를 반환합니다.
    ///
    /// 이 메서드는 반환 된 레이아웃에 다른 정렬이 있는지 여부에 관계없이 전체 크기에 패딩을 추가하지 않습니다.
    /// 즉, `K` 의 크기가 16이면 `K.align_to(32)` 는 *여전히* 크기가 16입니다.
    ///
    /// `self.size()` 와 주어진 `align` 의 조합이 [`Layout::from_size_align`] 에 나열된 조건을 위반하면 오류를 반환합니다.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// 다음 주소가 `align` (바이트 단위로 측정 됨)를 충족하는지 확인하기 위해 `self` 뒤에 삽입해야하는 패딩의 양을 반환합니다.
    ///
    /// 예를 들어 `self.size()` 가 9이면 `self.padding_needed_for(4)` 는 4로 정렬 된 주소를 가져 오는 데 필요한 패딩의 최소 바이트 수이기 때문에 3을 반환합니다 (해당 메모리 블록이 4로 정렬 된 주소에서 시작한다고 가정).
    ///
    ///
    /// `align` 가 2의 거듭 제곱이 아니면이 함수의 반환 값은 의미가 없습니다.
    ///
    /// 반환 된 값의 유틸리티를 사용하려면 `align` 가 할당 된 전체 메모리 블록에 대한 시작 주소의 정렬보다 작거나 같아야합니다.이 제약 조건을 충족하는 한 가지 방법은 `align <= self.align()` 를 확인하는 것입니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // 반올림 된 값은 다음과 같습니다.
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // 그리고 패딩 차이를 반환합니다. `len_rounded_up - len`.
        //
        // 우리는 전체적으로 모듈 식 산술을 사용합니다.
        //
        // 1. align은> 0이 보장되므로 align, 1은 항상 유효합니다.
        //
        // 2.
        // `len + align - 1` 최대 `align - 1` 에 의해 오버플로 될 수 있으므로 `!(align - 1)` 가있는&-mask는 오버플로의 경우 `len_rounded_up` 자체가 0이되도록합니다.
        //
        //    따라서 반환 된 패딩은 `len` 에 추가 될 때 0을 산출하며 이는 `align` 정렬을 사소하게 만족시킵니다.
        //
        // (물론, 위의 방식으로 크기와 패딩이 오버플로되는 메모리 블록을 할당하려고하면 할당자가 어쨌든 오류를 생성해야합니다.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// 이 레이아웃의 크기를 레이아웃 정렬의 배수로 반올림하여 레이아웃을 만듭니다.
    ///
    ///
    /// 이것은 `padding_needed_for` 의 결과를 레이아웃의 현재 크기에 추가하는 것과 같습니다.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // 이것은 넘칠 수 없습니다.레이아웃 불변에서 인용 :
        // > `size`, `align` 의 가장 가까운 배수로 반올림하면
        // > 넘치지 않아야합니다 (즉, 반올림 된 값은
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` 의 `n` 인스턴스에 대한 레코드를 설명하는 레이아웃을 만듭니다. 각 인스턴스에 요청 된 크기와 정렬이 제공되도록 각 인스턴스 사이에 적절한 양의 패딩이 있습니다.
    /// 성공하면 `(k, offs)` 를 반환합니다. 여기서 `k` 는 배열의 레이아웃이고 `offs` 는 배열의 각 요소 시작 사이의 거리입니다.
    ///
    /// 산술 오버플로시 `LayoutError` 를 반환합니다.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // 이것은 넘칠 수 없습니다.레이아웃 불변에서 인용 :
        // > `size`, `align` 의 가장 가까운 배수로 반올림하면
        // > 넘치지 않아야합니다 (즉, 반올림 된 값은
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // 안전: self.align 는 이미 유효한 것으로 알려져 있으며 alloc_size는
        // 이미 패딩되었습니다.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `next` 가 제대로 정렬되도록하기 위해 필요한 패딩을 포함하여 `self` 뒤에 `next` 에 대한 레코드를 설명하는 레이아웃을 생성하지만 *후행 패딩은 없습니다*.
    ///
    /// C 표현 레이아웃 `repr(C)` 를 일치 시키려면 레이아웃을 모든 필드로 확장 한 후 `pad_to_align` 를 호출해야합니다.
    /// (기본 Rust 표현 레이아웃 `repr(Rust)`, as it is unspecified.) 와 일치하는 방법은 없습니다.
    ///
    /// 결과 레이아웃의 정렬은 두 부분의 정렬을 보장하기 위해 `self` 및 `next` 의 최대 정렬이됩니다.
    ///
    /// `Ok((k, offset))` 를 리턴합니다. 여기서 `k` 는 연결된 레코드의 레이아웃이고 `offset` 는 연결된 레코드 내에 포함 된 `next` 시작의 상대 위치 (바이트)입니다 (레코드 자체가 오프셋 0에서 시작한다고 가정).
    ///
    ///
    /// 산술 오버플로시 `LayoutError` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` 구조의 레이아웃과 해당 필드의 레이아웃에서 필드의 오프셋을 계산하려면 :
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` 로 마무리하는 것을 잊지 마십시오!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // 작동하는지 테스트
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// 각 인스턴스 사이에 패딩없이 `self` 의 `n` 인스턴스에 대한 레코드를 설명하는 레이아웃을 만듭니다.
    ///
    /// `repeat` 와 달리 `repeat_packed` 는 `self` 의 주어진 인스턴스가 올바르게 정렬되어 있더라도 반복되는 `self` 인스턴스가 올바르게 정렬된다는 것을 보장하지 않습니다.
    /// 즉, `repeat_packed` 에서 반환 한 레이아웃을 사용하여 배열을 할당하는 경우 배열의 모든 요소가 올바르게 정렬된다는 보장이 없습니다.
    ///
    /// 산술 오버플로시 `LayoutError` 를 반환합니다.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// 둘 사이에 추가 패딩없이 `self` 뒤에 `next` 에 대한 레코드를 설명하는 레이아웃을 만듭니다.
    /// 패딩이 삽입되지 않았기 때문에 `next` 의 정렬은 관련이 없으며 결과 레이아웃에 *전혀* 통합되지 않습니다.
    ///
    ///
    /// 산술 오버플로시 `LayoutError` 를 반환합니다.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` 에 대한 레코드를 설명하는 레이아웃을 만듭니다.
    ///
    /// 산술 오버플로시 `LayoutError` 를 반환합니다.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` 또는 일부 다른 `Layout` 생성자에 제공된 매개 변수가 문서화 된 제약 조건을 충족하지 않습니다.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait 오류의 다운 스트림 impl에 필요합니다)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}