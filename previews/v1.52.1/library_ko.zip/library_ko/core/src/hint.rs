#![stable(feature = "core_hint", since = "1.27.0")]

//! 코드를 내보내거나 최적화하는 방법에 영향을주는 컴파일러에 대한 힌트입니다.
//! 힌트는 컴파일 시간 또는 런타임 일 수 있습니다.

use crate::intrinsics;

/// 코드의이 지점에 도달 할 수 없음을 컴파일러에 알려 추가 최적화를 가능하게합니다.
///
/// # Safety
///
/// 이 기능에 도달하는 것은 완전히 *정의되지 않은 동작*(UB) 입니다.특히 컴파일러는 모든 UB가 발생하지 않아야한다고 가정하므로 `unreachable_unchecked()` 호출에 도달하는 모든 분기를 제거합니다.
///
/// UB의 모든 인스턴스와 마찬가지로이 가정이 잘못된 것으로 판명되면, 즉 `unreachable_unchecked()` 호출이 모든 가능한 제어 흐름에서 실제로 도달 할 수있는 경우 컴파일러는 잘못된 최적화 전략을 적용하고 때로는 겉보기에 관련되지 않은 코드를 손상시켜 문제를 일으킬 수 있습니다. 디버그 문제.
///
///
/// 이 함수는 코드가 절대 호출하지 않는다는 것을 증명할 수있을 때만 사용하십시오.
/// 그렇지 않으면 최적화를 허용하지 않지만 실행시 panic 가되는 [`unreachable!`] 매크로를 사용하는 것이 좋습니다.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` 항상 양수 (0이 아님)이므로 `checked_div` 는 `None` 를 반환하지 않습니다.
/////
///     // 따라서 else branch 에 도달 할 수 없습니다.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // 안전: `intrinsics::unreachable` 에 대한 안전 계약은
    // 발신자의지지를받습니다.
    unsafe { intrinsics::unreachable() }
}

/// 프로세서가 busy-wait 스핀 루프 ("스핀 잠금")에서 실행 중임을 알리는 기계 명령을 내 보냅니다.
///
/// 스핀 루프 신호를 수신하면 프로세서는 예를 들어 전력을 절약하거나 hyper 스레드를 전환하여 동작을 최적화 할 수 있습니다.
///
/// 이 기능은 시스템의 스케줄러에 직접 양보하는 [`thread::yield_now`] 와 다른 반면 `spin_loop` 는 운영 체제와 상호 작용하지 않습니다.
///
/// `spin_loop` 의 일반적인 사용 사례는 동기화 프리미티브의 CAS 루프에서 제한된 낙관적 회전을 구현하는 것입니다.
/// 우선 순위 반전과 같은 문제를 방지하려면 한정된 양의 반복과 적절한 차단 시스템 호출이 이루어진 후에 스핀 루프를 종료하는 것이 좋습니다.
///
///
/// **참고**: 스핀 루프 힌트 수신을 지원하지 않는 플랫폼에서는이 기능이 아무 작업도 수행하지 않습니다.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // 스레드가 조정하는 데 사용할 공유 원자 값
/// let live = Arc::new(AtomicBool::new(false));
///
/// // 백그라운드 스레드에서 결국 값을 설정합니다.
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // 작업을 수행 한 다음 가치를 실현하십시오.
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // 현재 스레드로 돌아가서 값이 설정 될 때까지 기다립니다.
/// while !live.load(Ordering::Acquire) {
///     // 스핀 루프는 우리가 기다리고있는 CPU에 대한 힌트이지만 아마도 그리 오래 가지 않을 것입니다.
/////
///     hint::spin_loop();
/// }
///
/// // 이제 값이 설정되었습니다.
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // 안전: `cfg` 속성은 x86 타겟에서만 이것을 실행하도록합니다.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // 안전: `cfg` 속성은 x86_64 타겟에서만 이것을 실행하도록합니다.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // 안전: `cfg` 속성은 aarch64 타겟에서만 이것을 실행하도록합니다.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // 안전: `cfg` 속성은 우리가 팔 타겟에서만 이것을 실행하도록합니다.
            // v6 기능을 지원합니다.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// `black_box` 가 무엇을 할 수 있는지에 대해 최대한 비관적으로 컴파일러에 *__ 힌트 __* 하는 식별 함수.
///
/// [`std::convert::identity`] 와 달리 Rust 컴파일러는 `black_box` 가 호출 코드에 정의되지 않은 동작을 도입하지 않고 Rust 코드가 허용되는 가능한 모든 유효한 방식으로 `dummy` 를 사용할 수 있다고 가정하는 것이 좋습니다.
///
/// 이 속성은 `black_box` 가 벤치 마크와 같이 특정 최적화가 바람직하지 않은 코드를 작성하는 데 유용하게 만듭니다.
///
/// 그러나 `black_box` 는 "best-effort" 기준으로 만 제공되며 제공 될 수 있습니다.최적화를 차단할 수있는 정도는 사용되는 플랫폼 및 코드 생성 백엔드에 따라 다를 수 있습니다.
/// 프로그램은 어떤 식 으로든 *정확성* 을 위해 `black_box` 에 의존 할 수 없습니다.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // 우리는 LLVM이 어떤 방식 으로든 인수를 "use" 해야하며이를 지원하는 대상에서는 일반적으로 인라인 어셈블리를 활용하여이를 수행 할 수 있습니다.
    // 인라인 어셈블리에 대한 LLVM의 해석은 이것이 블랙 박스라는 것입니다.
    // 이것은 아마도 우리가 원하는 것보다 더 많이 최적화를 해제하기 때문에 가장 좋은 구현은 아니지만 충분히 훌륭합니다.
    //
    //

    #[cfg(not(miri))] // 이것은 힌트 일 뿐이므로 Miri에서 건너 뛰는 것이 좋습니다.
    // 안전: 인라인 어셈블리는 작동하지 않습니다.
    unsafe {
        // FIXME: MIPS 및 기타 아키텍처를 지원하지 않으므로 `asm!` 를 사용할 수 없습니다.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}