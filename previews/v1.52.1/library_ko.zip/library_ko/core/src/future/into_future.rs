use crate::future::Future;

/// `Future` 로 변환.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// future 가 완료시 생성 할 출력입니다.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// 우리는 이것을 어떤 종류의 future 로 바꾸고 있습니까?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// 값에서 future 를 만듭니다.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}