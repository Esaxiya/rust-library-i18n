#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future 는 비동기 계산을 나타냅니다.
///
/// future 는 아직 계산이 완료되지 않은 값입니다.
/// 이러한 종류의 "asynchronous value" 를 사용하면 스레드가 값을 사용할 수있을 때까지 기다리는 동안 유용한 작업을 계속할 수 있습니다.
///
///
/// # `poll` 방법
///
/// future, `poll`,*시도* 의 핵심 방법은 future 를 최종 값으로 확인합니다.
/// 이 메서드는 값이 준비되지 않은 경우 차단되지 않습니다.
/// 대신 현재 작업은 다시 '폴링'하여 추가 진행이 가능할 때 깨어나도록 예약됩니다.
/// `poll` 메서드에 전달 된 `context` 는 현재 작업을 깨우기위한 핸들 인 [`Waker`] 를 제공 할 수 있습니다.
///
/// future 를 사용할 때 일반적으로 `poll` 를 직접 호출하지 않고 대신 `.await` 값을 호출합니다.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// 완료시 생성되는 가치 유형입니다.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future 를 최종 값으로 확인하고 값을 아직 사용할 수없는 경우 깨우기를 위해 현재 작업을 등록합니다.
    ///
    /// # 반환 값
    ///
    /// 이 함수는 다음을 반환합니다.
    ///
    /// - [`Poll::Pending`] future 가 아직 준비되지 않은 경우
    /// - [`Poll::Ready(val)`] 성공적으로 완료된 경우이 future 의 결과 `val` 와 함께.
    ///
    /// future 가 완료되면 클라이언트는이를 다시 `poll` 하지 않아야합니다.
    ///
    /// future 가 아직 준비되지 않은 경우 `poll` 는 `Poll::Pending` 를 반환하고 현재 [`Context`] 에서 복사 된 [`Waker`] 의 복제본을 저장합니다.
    /// 이 [`Waker`] 는 future 가 진행될 수있게되면 깨어납니다.
    /// 예를 들어, 소켓을 읽을 수있게되기를 기다리는 future 는 [`Waker`] 에서 `.clone()` 를 호출하여 저장합니다.
    /// 소켓을 읽을 수 있음을 나타내는 신호가 다른 곳에 도착하면 [`Waker::wake`] 가 호출되고 소켓 future 의 작업이 깨어납니다.
    /// 작업이 깨어 나면 future 를 `poll` 로 다시 시도해야하며, 이는 최종 값을 생성하거나 생성하지 않을 수 있습니다.
    ///
    /// `poll` 에 대한 여러 호출에서 가장 최근 호출에 전달 된 [`Context`] 의 [`Waker`] 만 웨이크 업을 받도록 예약해야합니다.
    ///
    /// # 런타임 특성
    ///
    /// Futures 만 *불활성* 입니다.진행을 위해서는 *적극적으로*'폴링'되어야합니다. 즉, 현재 작업이 깨어날 때마다 여전히 관심이있는 futures 를 보류하는 동안 적극적으로 다시 폴링해야합니다.
    ///
    /// `poll` 함수는 타이트한 루프에서 반복적으로 호출되지 않습니다. 대신 future 가 진행할 준비가되었음을 나타낼 때만 호출해야합니다 (`wake()`).
    /// Unix 의 `poll(2)` 또는 `select(2)` 시스템 호출에 익숙하다면 futures 는 일반적으로 "all wakeups must poll all events" 와 동일한 문제를 겪지 *않습니다*.그들은 `epoll(4)` 와 더 비슷합니다.
    ///
    /// `poll` 의 구현은 빠르게 반환되도록 노력해야하며 차단해서는 안됩니다.신속하게 복귀하면 스레드 또는 이벤트 루프가 불필요하게 막히는 것을 방지 할 수 있습니다.
    /// `poll` 에 대한 호출이 시간이 오래 걸릴 수 있다는 것을 미리 알고있는 경우 작업을 스레드 풀 (또는 이와 유사한 것)로 오프로드하여 `poll` 가 빠르게 반환 될 수 있도록해야합니다.
    ///
    /// # Panics
    ///
    /// future 가 완료되면 (`poll` 에서 `Ready` 가 반환 됨) `poll` 메서드를 다시 호출하면 panic 가 영원히 차단되거나 다른 종류의 문제가 발생할 수 있습니다.`Future` trait 는 그러한 호출의 효과에 대한 요구 사항을 두지 않습니다.
    /// 그러나 `poll` 메서드가 `unsafe` 로 표시되지 않으므로 Rust 의 일반적인 규칙이 적용됩니다. 호출은 future 의 상태에 관계없이 정의되지 않은 동작 (메모리 손상, `unsafe` 함수의 잘못된 사용 등)을 유발해서는 안됩니다.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}