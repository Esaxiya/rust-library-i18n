#![stable(feature = "futures_api", since = "1.36.0")]

//! 비동기 값.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// 이 유형은 다음과 같은 이유로 필요합니다.
///
/// a) 생성기는 `for<'a, 'b> Generator<&'a mut Context<'b>>` 를 구현할 수 없으므로 원시 포인터를 전달해야합니다 (<https://github.com/rust-lang/rust/issues/68923> 참조).
///
/// b) 원시 포인터와 `NonNull` 는 `Send` 또는 `Sync` 가 아니므로 모든 future non-Send/Sync 도 만들 수 있으며 우리는 그것을 원하지 않습니다.
///
/// 또한 `.await` 의 HIR 저하를 단순화합니다.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// future 에 발전기를 감 쌉니다.
///
/// 이 함수는 아래에 `GenFuture` 를 반환하지만 더 나은 오류 메시지를 제공하기 위해 `impl Trait` 에서 숨 깁니다 (`GenFuture<[closure.....]>` 가 아닌 `impl Future`).
///
// `const async fn` 에서 복구 한 후 추가 오류를 방지하기위한 `const` 입니다.
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // 우리는 async/await futures 가 기본 생성기에서 자체 참조 차용을 생성하기 위해 움직일 수 없다는 사실에 의존합니다.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // 안전: 우리는 !Unpin + !Drop 이기 때문에 안전합니다. 이것은 단지 현장 투사 일뿐입니다.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // 생성기를 다시 시작하여 `&mut Context` 를 `NonNull` 원시 포인터로 바꿉니다.
            // `.await` 하강은 안전하게 `&mut Context` 로 다시 캐스팅합니다.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // 안전: 호출자는 `cx.0` 가 유효한 포인터인지 확인해야합니다.
    // 가변 참조에 대한 모든 요구 사항을 충족합니다.
    unsafe { &mut *cx.0.as_ptr().cast() }
}