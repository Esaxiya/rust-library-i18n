use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// 값으로 즉시 준비되는 future 를 만듭니다.
///
/// 이 `struct` 는 [`ready()`] 에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// 값으로 즉시 준비되는 future 를 만듭니다.
///
/// 이 함수를 통해 생성 된 Futures 는 `async {}` 를 통해 생성 된 것과 기능적으로 유사합니다.
/// 가장 큰 차이점은이 함수를 통해 생성 된 futures 가 명명되고 `Unpin` 를 구현한다는 것입니다.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}