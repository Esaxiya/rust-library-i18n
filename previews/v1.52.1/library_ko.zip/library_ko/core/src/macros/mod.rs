#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // 발신자의 에디션에 따라 `$crate::panic::panic_2015` 또는 `$crate::panic::panic_2021` 로 확장됩니다.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// 두 표현식이 서로 같음을 확인합니다 ([`PartialEq`] 사용).
///
/// panic 에서이 매크로는 디버그 표현과 함께 표현식의 값을 인쇄합니다.
///
///
/// [`assert!`] 와 마찬가지로이 매크로에는 사용자 지정 panic 메시지를 제공 할 수있는 두 번째 형식이 있습니다.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 아래의 재차 입은 의도적입니다.
                    // 그것들이 없으면 값을 비교하기 전에도 차용을위한 스택 슬롯이 초기화되어 눈에 띄게 느려지 게됩니다.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 아래의 재차 입은 의도적입니다.
                    // 그것들이 없으면 값을 비교하기 전에도 차용을위한 스택 슬롯이 초기화되어 눈에 띄게 느려지 게됩니다.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 두 표현식이 서로 같지 않음을 지정합니다 ([`PartialEq`] 사용).
///
/// panic 에서이 매크로는 디버그 표현과 함께 표현식의 값을 인쇄합니다.
///
///
/// [`assert!`] 와 마찬가지로이 매크로에는 사용자 지정 panic 메시지를 제공 할 수있는 두 번째 형식이 있습니다.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 아래의 재차 입은 의도적입니다.
                    // 그것들이 없으면 값을 비교하기 전에도 차용을위한 스택 슬롯이 초기화되어 눈에 띄게 느려지 게됩니다.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 아래의 재차 입은 의도적입니다.
                    // 그것들이 없으면 값을 비교하기 전에도 차용을위한 스택 슬롯이 초기화되어 눈에 띄게 느려지 게됩니다.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 런타임시 부울 표현식이 `true` 임을 확인합니다.
///
/// 런타임에 제공된 표현식을 `true` 로 평가할 수없는 경우 [`panic!`] 매크로를 호출합니다.
///
/// [`assert!`] 와 마찬가지로이 매크로에는 사용자 지정 panic 메시지를 제공 할 수있는 두 번째 버전도 있습니다.
///
/// # Uses
///
/// [`assert!`] 와 달리 `debug_assert!` 문은 기본적으로 최적화되지 않은 빌드에서만 활성화됩니다.
/// 최적화 된 빌드는 `-C debug-assertions` 가 컴파일러에 전달되지 않는 한 `debug_assert!` 문을 실행하지 않습니다.
/// 따라서 `debug_assert!` 는 릴리스 빌드에 표시하기에는 너무 비싸지 만 개발 중에 도움이 될 수있는 검사에 유용합니다.
/// `debug_assert!` 확장의 결과는 항상 유형 검사입니다.
///
/// 확인되지 않은 어설 션은 일관성없는 상태의 프로그램이 계속 실행되도록하여 예기치 않은 결과를 초래할 수 있지만 안전한 코드에서만 발생하는 한 안전하지 않습니다.
///
/// 그러나 어설 션의 성능 비용은 일반적으로 측정 할 수 없습니다.
/// 따라서 [`assert!`] 를 `debug_assert!` 로 대체하는 것은 철저한 프로파일 링 후에 만 권장되며 더 중요한 것은 안전한 코드에서만 가능합니다!
///
/// # Examples
///
/// ```
/// // 이러한 주장에 대한 panic 메시지는 주어진 표현식의 문자열 값입니다.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // 아주 간단한 기능
/// debug_assert!(some_expensive_computation());
///
/// // 사용자 지정 메시지로 주장
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// 두식이 서로 같다고 주장합니다.
///
/// panic 에서이 매크로는 디버그 표현과 함께 표현식의 값을 인쇄합니다.
///
/// [`assert_eq!`] 와 달리 `debug_assert_eq!` 문은 기본적으로 최적화되지 않은 빌드에서만 활성화됩니다.
/// 최적화 된 빌드는 `-C debug-assertions` 가 컴파일러에 전달되지 않는 한 `debug_assert_eq!` 문을 실행하지 않습니다.
/// 따라서 `debug_assert_eq!` 는 릴리스 빌드에 표시하기에는 너무 비싸지 만 개발 중에 도움이 될 수있는 검사에 유용합니다.
///
/// `debug_assert_eq!` 확장의 결과는 항상 유형 검사입니다.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// 두식이 서로 같지 않다고 주장합니다.
///
/// panic 에서이 매크로는 디버그 표현과 함께 표현식의 값을 인쇄합니다.
///
/// [`assert_ne!`] 와 달리 `debug_assert_ne!` 문은 기본적으로 최적화되지 않은 빌드에서만 활성화됩니다.
/// 최적화 된 빌드는 `-C debug-assertions` 가 컴파일러에 전달되지 않는 한 `debug_assert_ne!` 문을 실행하지 않습니다.
/// 따라서 `debug_assert_ne!` 는 릴리스 빌드에 표시하기에는 너무 비싸지 만 개발 중에 도움이 될 수있는 검사에 유용합니다.
///
/// `debug_assert_ne!` 확장의 결과는 항상 유형 검사입니다.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// 주어진 표현식이 주어진 패턴과 일치하는지 여부를 반환합니다.
///
/// `match` 표현식에서와 같이 패턴 뒤에 선택적으로 `if` 및 패턴으로 바인딩 된 이름에 액세스 할 수있는 보호 표현식이 올 수 있습니다.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// 결과를 풀거나 오류를 전파합니다.
///
/// `?` 연산자는 `try!` 를 대체하기 위해 추가되었으며 대신 사용해야합니다.
/// 또한 `try` 는 Rust 2018에서 예약어이므로 사용해야하는 경우 [raw-identifier syntax][ris] 를 사용해야합니다. `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` 주어진 [`Result`] 와 일치합니다.`Ok` 변형의 경우 표현식에는 래핑 된 값의 값이 있습니다.
///
/// `Err` 변형의 경우 내부 오류를 검색합니다.`try!` 는 `From` 를 사용하여 변환을 수행합니다.
/// 이것은 특수 오류와보다 일반적인 오류 사이의 자동 변환을 제공합니다.
/// 그러면 결과 오류가 즉시 반환됩니다.
///
/// 조기 반환 때문에 `try!` 는 [`Result`] 를 반환하는 함수에서만 사용할 수 있습니다.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // 빠른 반환 오류의 선호 방법
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // 오류를 빠르게 반환하는 이전 방법
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // 이것은 다음과 동일합니다.
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// 형식화 된 데이터를 버퍼에 씁니다.
///
/// 이 매크로는 'writer', 형식 문자열 및 인수 목록을 허용합니다.
/// 인수는 지정된 형식 문자열에 따라 형식이 지정되고 결과는 작성기에 전달됩니다.
/// 작성자는 `write_fmt` 메소드를 사용하는 모든 값이 될 수 있습니다.일반적으로 이것은 [`fmt::Write`] 또는 [`io::Write`] trait 의 구현에서 비롯됩니다.
/// 매크로는 `write_fmt` 메서드가 반환하는 모든 것을 반환합니다.일반적으로 [`fmt::Result`] 또는 [`io::Result`] 입니다.
///
/// 형식 문자열 구문에 대한 자세한 내용은 [`std::fmt`] 를 참조하십시오.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// 일반적으로 객체는 둘 다 구현하지 않으므로 모듈은 `std::fmt::Write` 및 `std::io::Write` 를 모두 가져오고 둘 중 하나를 구현하는 객체에 대해 `write!` 를 호출 할 수 있습니다.
///
/// 그러나 모듈은 이름이 충돌하지 않도록 정규화 된 traits 를 가져와야합니다.
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt 사용
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt 사용
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: 이 매크로는 `no_std` 설정에서도 사용할 수 있습니다.
/// `no_std` 설정에서 구성 요소의 구현 세부 정보를 담당합니다.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// 줄 바꿈을 추가하여 형식화 된 데이터를 버퍼에 씁니다.
///
/// 모든 플랫폼에서 개행 문자는 LINE FEED 문자 (`\n`/`U+000A`) 만입니다 (추가 CARRIAGE RETURN (`\r`/`U+000D`).
///
/// 자세한 내용은 [`write!`] 를 참조하십시오.형식 문자열 구문에 대한 정보는 [`std::fmt`] 를 참조하십시오.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// 일반적으로 객체는 둘 다 구현하지 않으므로 모듈은 `std::fmt::Write` 및 `std::io::Write` 를 모두 가져오고 둘 중 하나를 구현하는 객체에 대해 `write!` 를 호출 할 수 있습니다.
/// 그러나 모듈은 이름이 충돌하지 않도록 정규화 된 traits 를 가져와야합니다.
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt 사용
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt 사용
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// 연결할 수없는 코드를 나타냅니다.
///
/// 이는 컴파일러가 일부 코드에 도달 할 수 없다고 판단 할 수없는 경우에 유용합니다.예를 들면 :
///
/// * 가드 조건에 팔을 맞 춥니 다.
/// * 동적으로 종료되는 루프.
/// * 동적으로 종료되는 반복기.
///
/// 코드에 도달 할 수 없다는 결정이 잘못된 것으로 판명되면 프로그램은 즉시 [`panic!`] 로 종료됩니다.
///
/// 이 매크로의 안전하지 않은 대응 요소는 [`unreachable_unchecked`] 함수로, 코드에 도달하면 정의되지 않은 동작이 발생합니다.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// 이것은 항상 [`panic!`] 입니다.
///
/// # Examples
///
/// 팔 경기 :
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // 주석 처리 된 경우 컴파일 오류
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 의 가장 열악한 구현 중 하나
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" 메시지로 당황하여 구현되지 않은 코드를 나타냅니다.
///
/// 이를 통해 코드의 유형 검사를 수행 할 수 있으며, 이는 모두 사용할 계획이없는 여러 메서드가 필요한 trait 를 프로토 타이핑하거나 구현하는 경우 유용합니다.
///
/// `unimplemented!` 와 [`todo!`] 의 차이점은 `todo!` 는 나중에 기능을 구현하려는 의도를 전달하고 메시지는 "not yet implemented" 이지만 `unimplemented!` 는 그러한 주장을하지 않는다는 것입니다.
/// 메시지는 "not implemented" 입니다.
/// 또한 일부 IDE는`todo!`를 표시합니다.
///
/// # Panics
///
/// `unimplemented!` 는 고정 된 특정 메시지가있는 `panic!` 의 약어이기 때문에 항상 [`panic!`] 입니다.
///
/// `panic!` 와 마찬가지로이 매크로에는 사용자 지정 값을 표시하는 두 번째 형식이 있습니다.
///
/// # Examples
///
/// trait `Foo` 가 있다고 가정합니다.
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 'MyStruct' 용 `Foo` 를 구현하고 싶지만 어떤 이유로 `bar()` 기능을 구현하는 것이 합리적입니다.
/// `baz()` `qux()` 는 여전히 `Foo` 구현에서 정의해야하지만 정의에서 `unimplemented!` 를 사용하여 코드를 컴파일 할 수 있습니다.
///
/// 구현되지 않은 메서드에 도달하면 프로그램 실행을 중지하고 싶습니다.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` 가 `MyStruct` 인 것은 이치에 맞지 않으므로 여기에 논리가 전혀 없습니다.
/////
///         // "thread 'main' panicked at 'not implemented'" 가 표시됩니다.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // 여기에 몇 가지 논리가 있습니다. 구현되지 않은 메시지를 추가 할 수 있습니다!우리의 누락을 표시합니다.
///         // 다음이 표시됩니다. "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// 미완성 코드를 나타냅니다.
///
/// 프로토 타이핑 중이고 코드 유형 검사를 원하는 경우 유용 할 수 있습니다.
///
/// [`unimplemented!`] 와 `todo!` 의 차이점은 `todo!` 는 나중에 기능을 구현하려는 의도를 전달하고 메시지는 "not yet implemented" 이지만 `unimplemented!` 는 그러한 주장을하지 않는다는 것입니다.
/// 메시지는 "not implemented" 입니다.
/// 또한 일부 IDE는`todo!`를 표시합니다.
///
/// # Panics
///
/// 이것은 항상 [`panic!`] 입니다.
///
/// # Examples
///
/// 다음은 진행중인 코드의 예입니다.trait `Foo` 가 있습니다.
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// 유형 중 하나에 `Foo` 를 구현하고 싶지만 먼저 `bar()` 만 작업하고 싶습니다.코드를 컴파일하려면 `baz()` 를 구현해야하므로 `todo!` 를 사용할 수 있습니다.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // 여기에 구현
///     }
///
///     fn baz(&self) {
///         // 지금은 baz() 구현에 대해 걱정하지 마십시오.
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // 우리는 baz() 도 사용하지 않기 때문에 괜찮습니다.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// 내장 매크로의 정의.
///
/// 매크로 입력을 출력으로 변환하는 확장 함수를 제외하고 대부분의 매크로 속성 (안정성, 가시성 등)은 여기의 소스 코드에서 가져옵니다. 이러한 함수는 컴파일러에서 제공합니다.
///
///
pub(crate) mod builtin {

    /// 발생하면 주어진 오류 메시지와 함께 컴파일이 실패합니다.
    ///
    /// 이 매크로는 crate 가 잘못된 조건에 대해 더 나은 오류 메시지를 제공하기 위해 조건부 컴파일 전략을 사용할 때 사용해야합니다.
    ///
    /// [`panic!`] 의 컴파일러 수준 형식이지만 *런타임* 이 아닌 *컴파일* 중에 오류가 발생합니다.
    ///
    /// # Examples
    ///
    /// 이러한 두 가지 예는 매크로와 `#[cfg]` 환경입니다.
    ///
    /// 매크로에 잘못된 값이 전달되면 더 나은 컴파일러 오류를 내 보냅니다.
    /// 최종 branch 가 없으면 컴파일러는 여전히 오류를 내고 있지만 오류 메시지에는 두 개의 유효한 값이 언급되지 않습니다.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// 여러 기능 중 하나를 사용할 수없는 경우 컴파일러 오류를 내 보냅니다.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 다른 문자열 형식화 매크로에 대한 매개 변수를 구성합니다.
    ///
    /// 이 매크로는 전달 된 각 추가 인수에 대해 `{}` 를 포함하는 형식화 문자열 리터럴을 사용하여 작동합니다.
    /// `format_args!` 출력이 문자열로 해석 될 수 있도록 추가 매개 변수를 준비하고 인수를 단일 유형으로 정규화합니다.
    /// [`Display`] trait 를 구현하는 모든 값은 `format_args!` 로 전달 될 수 있으며, 모든 [`Debug`] 구현은 형식화 문자열 내에서 `{:?}` 로 전달 될 수 있습니다.
    ///
    ///
    /// 이 매크로는 [`fmt::Arguments`] 유형의 값을 생성합니다.이 값은 유용한 리디렉션을 수행하기 위해 [`std::fmt`] 내의 매크로에 전달 될 수 있습니다.
    /// 다른 모든 서식 매크로 ([`format!`], [`write!`], [`println!`] 등)는이 매크로를 통해 프록시됩니다.
    /// `format_args!`, 파생 된 매크로와 달리 힙 할당을 피합니다.
    ///
    /// 아래와 같이 `format_args!` 가 `Debug` 및 `Display` 컨텍스트에서 반환하는 [`fmt::Arguments`] 값을 사용할 수 있습니다.
    /// 이 예에서는 `Debug` 및 `Display` 형식이 동일한 것으로 표시됩니다. `format_args!` 의 보간 형식 문자열입니다.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// 자세한 내용은 [`std::fmt`] 의 설명서를 참조하십시오.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` 와 동일하지만 끝에 개행을 추가합니다.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// 컴파일 타임에 환경 변수를 검사합니다.
    ///
    /// 이 매크로는 컴파일 타임에 명명 된 환경 변수의 값으로 확장되어 `&'static str` 유형의 표현식을 생성합니다.
    ///
    ///
    /// 환경 변수가 정의되어 있지 않으면 컴파일 오류가 발생합니다.
    /// 컴파일 오류를 발생시키지 않으려면 대신 [`option_env!`] 매크로를 사용하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// 두 번째 매개 변수로 문자열을 전달하여 오류 메시지를 사용자 정의 할 수 있습니다.
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` 환경 변수가 정의되어 있지 않으면 다음 오류가 발생합니다.
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 선택적으로 컴파일 타임에 환경 변수를 검사합니다.
    ///
    /// 명명 된 환경 변수가 컴파일 타임에 존재하는 경우, 이는 값이 환경 변수 값의 `Some` 인 `Option<&'static str>` 유형의 표현식으로 확장됩니다.
    /// 환경 변수가 없으면 `None` 로 확장됩니다.
    /// 이 유형에 대한 자세한 내용은 [`Option<T>`][Option] 를 참조하십시오.
    ///
    /// 환경 변수가 있는지 여부에 관계없이이 매크로를 사용할 때 컴파일 시간 오류가 발생하지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 식별자를 하나의 식별자로 연결합니다.
    ///
    /// 이 매크로는 쉼표로 구분 된 여러 식별자를 가져 와서 모두 하나로 연결하여 새 식별자 인 식을 생성합니다.
    /// 위생은이 매크로가 지역 변수를 캡처 할 수 없도록 만듭니다.
    /// 또한 일반적으로 매크로는 항목, 문 또는 표현식 위치에서만 허용됩니다.
    /// 즉, 기존 변수, 함수 또는 모듈 등을 참조하는 데이 매크로를 사용할 수 있지만 새 매크로를 정의 할 수는 없습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//이런 식으로 사용할 수 없습니다!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 리터럴을 정적 문자열 조각으로 연결합니다.
    ///
    /// 이 매크로는 여러 쉼표로 구분 된 리터럴을 사용하여 왼쪽에서 오른쪽으로 연결된 모든 리터럴을 나타내는 `&'static str` 유형의 표현식을 생성합니다.
    ///
    ///
    /// 정수 및 부동 소수점 리터럴은 연결하기 위해 문자열 화됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 호출 된 행 번호로 확장됩니다.
    ///
    /// [`column!`] 및 [`file!`] 에서 이러한 매크로는 개발자에게 소스 내의 위치에 대한 디버깅 정보를 제공합니다.
    ///
    /// 확장 된 표현식의 유형은 `u32` 이고 1부터 시작하므로 각 파일의 첫 번째 줄은 1로, 두 번째 줄은 2로 평가됩니다.
    /// 이는 일반적인 컴파일러 또는 인기있는 편집기의 오류 메시지와 일치합니다.
    /// 리턴 된 행은 *반드시*`line!` 호출 자체의 행이 아니라 `line!` 매크로 호출로 이어지는 첫 번째 매크로 호출입니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// 호출 된 열 번호로 확장됩니다.
    ///
    /// [`line!`] 및 [`file!`] 에서 이러한 매크로는 개발자에게 소스 내의 위치에 대한 디버깅 정보를 제공합니다.
    ///
    /// 확장 된 표현식의 유형은 `u32` 이고 1부터 시작하므로 각 행의 첫 번째 열은 1로 평가되고 두 번째는 2로 평가됩니다.
    /// 이는 일반적인 컴파일러 또는 인기있는 편집기의 오류 메시지와 일치합니다.
    /// 리턴 된 열은 *반드시*`column!` 호출 자체의 행이 아니라 `column!` 매크로 호출로 이어지는 첫 번째 매크로 호출입니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// 호출 된 파일 이름으로 확장됩니다.
    ///
    /// [`line!`] 및 [`column!`] 에서 이러한 매크로는 소스 내의 위치에 대한 디버깅 정보를 개발자에게 제공합니다.
    ///
    /// 확장 된 표현식의 유형은 `&'static str` 이고 리턴 된 파일은 `file!` 매크로 자체의 호출이 아니라 `file!` 매크로 호출로 이어지는 첫 번째 매크로 호출입니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// 인수를 문자열 화합니다.
    ///
    /// 이 매크로는 매크로에 전달 된 모든 tokens 의 문자열 화인 `&'static str` 유형의 표현식을 생성합니다.
    /// 매크로 호출 자체의 구문에는 제한이 없습니다.
    ///
    /// 입력 tokens 의 확장 결과는 future 에서 변경 될 수 있습니다.출력에 의존하는 경우주의해야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 인코딩 파일을 문자열로 포함합니다.
    ///
    /// 파일은 현재 파일을 기준으로 위치합니다 (모듈을 찾는 방법과 유사).
    /// 제공된 경로는 컴파일 타임에 플랫폼 별 방식으로 해석됩니다.
    /// 따라서 예를 들어 백 슬래시 `\` 를 포함하는 Windows 경로를 사용한 호출은 Unix 에서 올바르게 컴파일되지 않습니다.
    ///
    ///
    /// 이 매크로는 파일의 내용 인 `&'static str` 유형의 표현식을 생성합니다.
    ///
    /// # Examples
    ///
    /// 동일한 디렉토리에 다음 내용을 가진 두 개의 파일이 있다고 가정합니다.
    ///
    /// 파일 'spanish.in' :
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 파일 'main.rs' :
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' 를 컴파일하고 결과 바이너리를 실행하면 "adiós" 가 인쇄됩니다.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 바이트 배열에 대한 참조로 파일을 포함합니다.
    ///
    /// 파일은 현재 파일을 기준으로 위치합니다 (모듈을 찾는 방법과 유사).
    /// 제공된 경로는 컴파일 타임에 플랫폼 별 방식으로 해석됩니다.
    /// 따라서 예를 들어 백 슬래시 `\` 를 포함하는 Windows 경로를 사용한 호출은 Unix 에서 올바르게 컴파일되지 않습니다.
    ///
    ///
    /// 이 매크로는 파일의 내용 인 `&'static [u8; N]` 유형의 표현식을 생성합니다.
    ///
    /// # Examples
    ///
    /// 동일한 디렉토리에 다음 내용을 가진 두 개의 파일이 있다고 가정합니다.
    ///
    /// 파일 'spanish.in' :
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 파일 'main.rs' :
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' 를 컴파일하고 결과 바이너리를 실행하면 "adiós" 가 인쇄됩니다.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 현재 모듈 경로를 나타내는 문자열로 확장됩니다.
    ///
    /// 현재 모듈 경로는 crate root 로 백업되는 모듈의 계층 구조로 생각할 수 있습니다.
    /// 반환 된 경로의 첫 번째 구성 요소는 현재 컴파일중인 crate 의 이름입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// 컴파일 타임에 구성 플래그의 부울 조합을 평가합니다.
    ///
    /// `#[cfg]` 속성 외에도이 매크로는 구성 플래그의 부울 표현식 평가를 허용하기 위해 제공됩니다.
    /// 이로 인해 중복 코드가 자주 발생하지 않습니다.
    ///
    /// 이 매크로에 주어진 구문은 [`cfg`] 속성과 동일한 구문입니다.
    ///
    /// `cfg!`, `#[cfg]` 와 달리 코드를 제거하지 않고 참 또는 거짓으로 만 평가됩니다.
    /// 예를 들어, `cfg!` 가 평가하는 항목에 관계없이 `cfg!` 가 조건에 사용될 때 if/else 표현식의 모든 블록이 유효해야합니다.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 컨텍스트에 따라 파일을 표현식 또는 항목으로 구문 분석합니다.
    ///
    /// 파일은 현재 파일을 기준으로 위치합니다 (모듈을 찾는 방법과 유사).제공된 경로는 컴파일 타임에 플랫폼 별 방식으로 해석됩니다.
    /// 따라서 예를 들어 백 슬래시 `\` 를 포함하는 Windows 경로를 사용한 호출은 Unix 에서 올바르게 컴파일되지 않습니다.
    ///
    /// 이 매크로를 사용하는 것은 종종 나쁜 생각입니다. 파일이 표현식으로 구문 분석되면 비위생적으로 주변 코드에 배치되기 때문입니다.
    /// 이로 인해 현재 파일에 동일한 이름을 가진 변수 또는 함수가있는 경우 변수 또는 함수가 파일이 예상 한 것과 다를 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// 동일한 디렉토리에 다음 내용을 가진 두 개의 파일이 있다고 가정합니다.
    ///
    /// 파일 'monkeys.in' :
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 파일 'main.rs' :
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' 를 컴파일하고 결과 바이너리를 실행하면 "🙈🙊🙉🙈🙊🙉" 가 인쇄됩니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 런타임시 부울 표현식이 `true` 임을 확인합니다.
    ///
    /// 런타임에 제공된 표현식을 `true` 로 평가할 수없는 경우 [`panic!`] 매크로를 호출합니다.
    ///
    /// # Uses
    ///
    /// 어설 션은 항상 디버그 및 릴리스 빌드 모두에서 확인되며 비활성화 할 수 없습니다.
    /// 기본적으로 릴리스 빌드에서 활성화되지 않은 어설 션은 [`debug_assert!`] 를 참조하십시오.
    ///
    /// 안전하지 않은 코드는 `assert!` 를 사용하여 위반할 경우 안전하지 않을 수있는 런타임 불변성을 적용 할 수 있습니다.
    ///
    /// `assert!` 의 다른 사용 사례에는 안전 코드에서 런타임 불변을 테스트하고 적용하는 것이 포함됩니다 (위반으로 인해 안전하지 않음).
    ///
    ///
    /// # 맞춤 메시지
    ///
    /// 이 매크로에는 두 번째 형식이 있습니다. 여기서 사용자 지정 panic 메시지는 형식 지정 인수를 포함하거나 포함하지 않고 제공 될 수 있습니다.
    /// 이 양식의 구문은 [`std::fmt`] 를 참조하십시오.
    /// 형식 인수로 사용되는 식은 어설 션이 실패한 경우에만 평가됩니다.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // 이러한 주장에 대한 panic 메시지는 주어진 표현식의 문자열 값입니다.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // 아주 간단한 기능
    ///
    /// assert!(some_computation());
    ///
    /// // 사용자 지정 메시지로 주장
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// 인라인 어셈블리.
    ///
    /// 사용법은 [unstable book] 를 읽으십시오.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM 스타일 인라인 어셈블리.
    ///
    /// 사용법은 [unstable book] 를 읽으십시오.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// 모듈 수준 인라인 어셈블리.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// 전달 된 tokens 를 표준 출력으로 인쇄합니다.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 다른 매크로를 디버깅하는 데 사용되는 추적 기능을 활성화하거나 비활성화합니다.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// 파생 매크로를 적용하는 데 사용되는 속성 매크로입니다.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// 단위 테스트로 전환하기 위해 함수에 적용된 속성 매크로입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// 벤치 마크 테스트로 전환하기 위해 함수에 적용된 속성 매크로입니다.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` 및 `#[bench]` 매크로의 구현 세부 정보입니다.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// 전역 할당 자로 등록하기 위해 정적에 적용된 속성 매크로입니다.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) 도 참조하십시오.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// 전달 된 경로에 액세스 할 수있는 경우 적용되는 항목을 유지하고 그렇지 않은 경우 제거합니다.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// 적용된 코드 조각에서 모든 `#[cfg]` 및 `#[cfg_attr]` 속성을 확장합니다.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` 컴파일러의 불안정한 구현 세부 사항은 사용하지 마십시오.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` 컴파일러의 불안정한 구현 세부 사항은 사용하지 마십시오.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}