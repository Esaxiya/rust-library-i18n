Panics 현재 스레드입니다.

이를 통해 프로그램이 즉시 종료되고 프로그램 호출자에게 피드백을 제공 할 수 있습니다.
`panic!` 프로그램이 복구 불가능한 상태에 도달 할 때 사용해야합니다.

이 매크로는 예제 코드와 테스트에서 조건을 주장하는 완벽한 방법입니다.
`panic!` [`Option`][ounwrap] 및 [`Result`][runwrap] 열거 형의 `unwrap` 방법과 밀접하게 연결되어 있습니다.
두 구현 모두 [`None`] 또는 [`Err`] 변형으로 설정된 경우 `panic!` 를 호출합니다.

`panic!()` 를 사용할 때 [`format!`] 구문을 사용하여 빌드 된 문자열 페이로드를 지정할 수 있습니다.
이 페이로드는 panic 를 호출하는 Rust 스레드에 삽입 할 때 사용되어 스레드를 panic 로 완전히 만듭니다.

기본 `std` hook 의 동작, 즉
panic 가 호출 된 직후에 실행되는 코드는 `panic!()` 호출의 file/line/column 정보와 함께 메시지 페이로드를 `stderr` 에 인쇄하는 것입니다.

[`std::panic::set_hook()`] 를 사용하여 panic hook 를 재정의 할 수 있습니다.
hook 내에서 panic 는 `&dyn Any + Send` 로 액세스 할 수 있으며, 여기에는 일반 `panic!()` 호출을위한 `&str` 또는 `String` 가 포함됩니다.
다른 유형의 값을 가진 panic 에는 [`panic_any`] 를 사용할 수 있습니다.

[`Result`] enum은 종종 `panic!` 매크로를 사용하는 것보다 오류를 복구하는 데 더 나은 솔루션입니다.
이 매크로는 외부 소스에서와 같이 잘못된 값을 사용하는 것을 방지하기 위해 사용해야합니다.
오류 처리에 대한 자세한 정보는 [book] 에서 찾을 수 있습니다.

컴파일 중 오류 발생에 대해서는 매크로 [`compile_error!`] 를 참조하십시오.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# 현재 구현

주 스레드 panics 이면 모든 스레드를 종료하고 코드 `101` 로 프로그램을 종료합니다.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





