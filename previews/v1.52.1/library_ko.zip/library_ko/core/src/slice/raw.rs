//! `&[T]` 및 `&mut [T]` 를 만드는 무료 기능.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// 포인터와 길이에서 슬라이스를 형성합니다.
///
/// `len` 인수는 바이트 수가 아니라 **요소** 의 수입니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `data` `len * mem::size_of::<T>()` 많은 바이트에 대한 읽기의 경우 [valid] 여야하며 적절하게 정렬되어야합니다.이것은 특히 다음을 의미합니다.
///
///     * 이 슬라이스의 전체 메모리 범위는 할당 된 단일 객체 내에 포함되어야합니다!
///       슬라이스는 할당 된 여러 개체에 걸쳐있을 수 없습니다.이를 고려하지 않은 예는 [below](#incorrect-usage) 를 참조하십시오.
///     * `data` 길이가 0 인 슬라이스의 경우에도 널이 아니고 정렬되어야합니다.
///     한 가지 이유는 열거 형 레이아웃 최적화가 다른 데이터와 구별하기 위해 정렬되고 널이 아닌 참조 (모든 길이의 슬라이스 포함)에 의존 할 수 있기 때문입니다.
///     [`NonNull::dangling()`] 를 사용하여 길이가 0 인 슬라이스에 대해 `data` 로 사용할 수있는 포인터를 얻을 수 있습니다.
///
/// * `data` `T` 유형의 `len` 연속 적절하게 초기화 된 값을 가리켜 야합니다.
///
/// * 반환 된 슬라이스가 참조하는 메모리는 `UnsafeCell` 내부를 제외하고 `'a` 수명 기간 동안 변경되어서는 안됩니다.
///
/// * 슬라이스의 총 크기 `len * mem::size_of::<T>()` 는 `isize::MAX` 보다 크지 않아야합니다.
///   [`pointer::offset`] 의 안전 문서를 참조하십시오.
///
/// # Caveat
///
/// 반환 된 슬라이스의 수명은 사용량에서 유추됩니다.
/// 실수로 인한 오용을 방지하기 위해 슬라이스에 대한 호스트 값의 수명을 취하는 도우미 함수를 제공하거나 명시 적 주석을 사용하여 수명을 컨텍스트에서 안전한 소스 수명과 연결하는 것이 좋습니다.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // 단일 요소에 대한 슬라이스 표시
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### 잘못된 사용법
///
/// 다음 `join_slices` 기능은 **불건전합니다** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // 위의 주장은 `fst` 와 `snd` 가 연속적임을 보장하지만 _different allocated objects_ 내에 여전히 포함되어있을 수 있으며이 경우이 슬라이스를 만드는 것은 정의되지 않은 동작입니다.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` `b` 는 다른 할당 된 객체입니다 ...
///     let a = 42;
///     let b = 27;
///     // ... 그럼에도 불구하고 메모리에 연속적으로 배치 될 수 있습니다. |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // 안전: 발신자는 `from_raw_parts` 에 대한 안전 계약을 유지해야합니다.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// 변경 가능한 슬라이스가 반환된다는 점을 제외하고 [`from_raw_parts`] 와 동일한 기능을 수행합니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `data` `len * mem::size_of::<T>()` 많은 바이트에 대한 읽기 및 쓰기 모두에 대해 [valid] 여야하며 제대로 정렬되어야합니다.이것은 특히 다음을 의미합니다.
///
///     * 이 슬라이스의 전체 메모리 범위는 할당 된 단일 객체 내에 포함되어야합니다!
///       슬라이스는 할당 된 여러 개체에 걸쳐있을 수 없습니다.
///     * `data` 길이가 0 인 슬라이스의 경우에도 널이 아니고 정렬되어야합니다.
///     한 가지 이유는 열거 형 레이아웃 최적화가 다른 데이터와 구별하기 위해 정렬되고 널이 아닌 참조 (모든 길이의 슬라이스 포함)에 의존 할 수 있기 때문입니다.
///
///     [`NonNull::dangling()`] 를 사용하여 길이가 0 인 슬라이스에 대해 `data` 로 사용할 수있는 포인터를 얻을 수 있습니다.
///
/// * `data` `T` 유형의 `len` 연속 적절하게 초기화 된 값을 가리켜 야합니다.
///
/// * 반환 된 슬라이스가 참조하는 메모리는 `'a` 수명 기간 동안 다른 포인터 (반환 값에서 파생되지 않음)를 통해 액세스해서는 안됩니다.
///   읽기 및 쓰기 액세스가 모두 금지됩니다.
///
/// * 슬라이스의 총 크기 `len * mem::size_of::<T>()` 는 `isize::MAX` 보다 크지 않아야합니다.
///   [`pointer::offset`] 의 안전 문서를 참조하십시오.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // 안전: 발신자는 `from_raw_parts_mut` 에 대한 안전 계약을 유지해야합니다.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T에 대한 참조를 길이 1의 조각으로 변환합니다 (복사하지 않음).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T에 대한 참조를 길이 1의 조각으로 변환합니다 (복사하지 않음).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}