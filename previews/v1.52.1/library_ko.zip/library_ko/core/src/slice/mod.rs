// ignore-tidy-filelength

//! 슬라이스 관리 및 조작.
//!
//! 자세한 내용은 [`std::slice`] 를 참조하십시오.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// rust-memchr에서 가져온 순수한 rust memchr 구현
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// 이 함수는 단위 테스트 힙 정렬에 대한 다른 방법이 없기 때문에 공용입니다.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// 슬라이스의 요소 수를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // 안전성: 길이 필드를 usize로 변환하기 때문에 const 사운드입니다.
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // 안전: `&[T]` 와 `FatPtr<T>` 의 레이아웃이 동일하기 때문에 안전합니다.
            // `std` 만이이를 보장 할 수 있습니다.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: 그것이 const-stable이면 `crate::ptr::metadata(self)` 로 교체하십시오.
            // 이 글을 쓰는 시점에서 "Const-stable functions can only call other const-stable functions" 오류가 발생합니다.
            //

            // 안전: `PtrRepr` 공용체의 값에 액세스하는 것은 * const T이므로 안전합니다.
            // 및 PtrComponents<T>메모리 레이아웃이 동일합니다.
            // std 만이이를 보장 할 수 있습니다.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// 슬라이스의 길이가 0이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 슬라이스의 첫 번째 요소 또는 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// 슬라이스의 첫 번째 요소에 대한 가변 포인터를 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// 슬라이스의 첫 번째 요소와 나머지 요소를 모두 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// 슬라이스의 첫 번째 요소와 나머지 요소를 모두 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// 슬라이스의 마지막 요소와 나머지 요소를 모두 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// 슬라이스의 마지막 요소와 나머지 요소를 모두 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// 슬라이스의 마지막 요소를 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// 슬라이스의 마지막 항목에 대한 변경 가능한 포인터를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// 인덱스 유형에 따라 요소 또는 하위 슬라이스에 대한 참조를 반환합니다.
    ///
    /// - 위치가 주어지면 해당 위치의 요소에 대한 참조를 반환하고 범위를 벗어난 경우 `None` 를 반환합니다.
    ///
    /// - 범위가 주어지면 해당 범위에 해당하는 부분 조각을 반환하고 범위를 벗어난 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// 인덱스 유형 ([`get`] 참조) 또는 인덱스가 범위를 벗어난 경우 `None` 에 따라 요소 또는 서브 슬라이스에 대한 가변 참조를 반환합니다.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// 경계 검사를 수행하지 않고 요소 또는 하위 조각에 대한 참조를 반환합니다.
    ///
    /// 안전한 대안은 [`get`] 를 참조하십시오.
    ///
    /// # Safety
    ///
    /// 경계를 벗어난 인덱스로이 메서드를 호출하면 결과 참조가 사용되지 않더라도 *[정의되지 않은 동작]* 이됩니다.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // 안전: 발신자는 `get_unchecked` 에 대한 대부분의 안전 요구 사항을 준수해야합니다.
        // 슬라이스는 `self` 가 안전한 참조이므로 참조 할 수 없습니다.
        // 반환 된 포인터는 `SliceIndex` 의 impls가 보장해야하기 때문에 안전합니다.
        unsafe { &*index.get_unchecked(self) }
    }

    /// 경계 검사를 수행하지 않고 요소 또는 하위 슬라이스에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// 안전한 대안은 [`get_mut`] 를 참조하십시오.
    ///
    /// # Safety
    ///
    /// 경계를 벗어난 인덱스로이 메서드를 호출하면 결과 참조가 사용되지 않더라도 *[정의되지 않은 동작]* 이됩니다.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // 안전: 발신자는 `get_unchecked_mut` 에 대한 안전 요구 사항을 준수해야합니다.
        // 슬라이스는 `self` 가 안전한 참조이므로 참조 할 수 없습니다.
        // 반환 된 포인터는 `SliceIndex` 의 impls가 보장해야하기 때문에 안전합니다.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// 슬라이스의 버퍼에 대한 원시 포인터를 반환합니다.
    ///
    /// 호출자는 슬라이스가이 함수가 반환하는 포인터보다 오래 지속되는지 확인해야합니다. 그렇지 않으면 결국 쓰레기를 가리킬 것입니다.
    ///
    /// 호출자는 또한 포인터 (non-transitively) 가 가리키는 메모리가이 포인터 또는 포인터에서 파생 된 포인터를 사용하여 기록되지 않도록해야합니다 (`UnsafeCell` 내부 제외).
    /// 슬라이스의 내용을 변경해야하는 경우 [`as_mut_ptr`] 를 사용하십시오.
    ///
    /// 이 슬라이스에서 참조하는 컨테이너를 수정하면 해당 버퍼가 재 할당 될 수 있으며, 이로 인해 포인터도 유효하지 않게됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// 슬라이스의 버퍼에 대한 안전하지 않은 가변 포인터를 반환합니다.
    ///
    /// 호출자는 슬라이스가이 함수가 반환하는 포인터보다 오래 지속되는지 확인해야합니다. 그렇지 않으면 결국 쓰레기를 가리킬 것입니다.
    ///
    /// 이 슬라이스에서 참조하는 컨테이너를 수정하면 해당 버퍼가 재 할당 될 수 있으며, 이로 인해 포인터도 유효하지 않게됩니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// 슬라이스에 걸쳐있는 두 개의 원시 포인터를 반환합니다.
    ///
    /// 반환 된 범위는 반쯤 열려 있습니다. 즉, 끝 포인터가 슬라이스의 마지막 요소를 *하나지나* 가리 킵니다.
    /// 이런 식으로 빈 슬라이스는 두 개의 동일한 포인터로 표시되고 두 포인터의 차이는 슬라이스의 크기를 나타냅니다.
    ///
    /// 이러한 포인터 사용에 대한 경고는 [`as_ptr`] 를 참조하십시오.끝 포인터는 슬라이스의 유효한 요소를 가리 키지 않으므로 특별히주의해야합니다.
    ///
    /// 이 함수는 C++ 에서 일반적으로 사용되는 것처럼 메모리의 요소 범위를 참조하기 위해 두 개의 포인터를 사용하는 외부 인터페이스와 상호 작용하는 데 유용합니다.
    ///
    ///
    /// 요소에 대한 포인터가이 슬라이스의 요소를 참조하는지 확인하는 것도 유용 할 수 있습니다.
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // 안전: `add` 는 다음과 같은 이유로 안전합니다.
        //
        //   - 두 포인터는 동일한 개체의 일부이며 개체를 직접 지나가는 것도 중요합니다.
        //
        //   - 슬라이스의 크기는 다음과 같이 isize::MAX 바이트보다 크지 않습니다.
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - 슬라이스가 주소 공간의 끝을 지나서 래핑되지 않기 때문에 관련된 래핑이 없습니다.
        //
        // pointer::add 의 문서를 참조하십시오.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// 슬라이스에 걸쳐있는 두 개의 안전하지 않은 가변 포인터를 반환합니다.
    ///
    /// 반환 된 범위는 반쯤 열려 있습니다. 즉, 끝 포인터가 슬라이스의 마지막 요소를 *하나지나* 가리 킵니다.
    /// 이런 식으로 빈 슬라이스는 두 개의 동일한 포인터로 표시되고 두 포인터의 차이는 슬라이스의 크기를 나타냅니다.
    ///
    /// 이러한 포인터 사용에 대한 경고는 [`as_mut_ptr`] 를 참조하십시오.
    /// 끝 포인터는 슬라이스의 유효한 요소를 가리 키지 않으므로 특별히주의해야합니다.
    ///
    /// 이 함수는 C++ 에서 일반적으로 사용되는 것처럼 메모리의 요소 범위를 참조하기 위해 두 개의 포인터를 사용하는 외부 인터페이스와 상호 작용하는 데 유용합니다.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // 안전: `add` 가 안전한 이유는 위의 as_ptr_range() 를 참조하십시오.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// 슬라이스의 두 요소를 바꿉니다.
    ///
    /// # Arguments
    ///
    /// * a, 첫 번째 요소의 색인
    /// * b, 두 번째 요소의 인덱스
    ///
    /// # Panics
    ///
    /// `a` 또는 `b` 가 범위를 벗어난 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // 하나의 vector 에서 두 개의 가변 대출을받을 수 없으므로 대신 원시 포인터를 사용하십시오.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // 안전: `pa` 및 `pb` 는 안전한 변경 가능한 참조에서 생성되었으며
        // 슬라이스의 요소에 연결되므로 유효하고 정렬됩니다.
        // `a` 및 `b` 뒤에있는 요소에 액세스하는 것이 확인되고 범위를 벗어난 경우 panic 가됩니다.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// 슬라이스에있는 요소의 순서를 제자리에서 바꿉니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // 매우 작은 유형의 경우 일반 경로의 모든 개별 읽기가 제대로 수행되지 않습니다.
        // 더 큰 청크를로드하고 레지스터를 반전하여 효율적으로 정렬되지 않은 load/store 가 주어지면 더 잘할 수 있습니다.
        //

        // 이상적으로 LLVM은 정렬되지 않은 읽기가 효율적인지 (예를 들어 서로 다른 ARM 버전간에 변경되기 때문에) 그리고 최상의 청크 크기가 무엇인지 우리가하는 것보다 더 잘 알고 있기 때문에이를 수행합니다.
        // 안타깝게도 LLVM 4.0 (2017-05) 부터는 루프 만 풀기 때문에이 작업을 직접 수행해야합니다.
        // (가설: 반대 방향은 측면이 다르게 정렬 될 수 있기 때문에 번거 롭습니다. 길이가 홀수 일 때 그럴 것입니다. 따라서 중간에 완전히 정렬 된 SIMD를 사용하기 위해 사전 및 후주를 방출 할 방법이 없습니다.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // llvm.bswap 내장 함수를 사용하여 usize에서 u8s 반전
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // 안전: 여기에서 확인해야 할 몇 가지 사항이 있습니다.
                //
                // - `chunk` 는 위의 cfg 검사로 인해 4 또는 8입니다.그래서 `chunk - 1` 는 긍정적입니다.
                // - 루프 검사가 보장하므로 인덱스 `i` 로 인덱싱하는 것이 좋습니다.
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - 인덱스 `ln - i - chunk = ln - (i + chunk)` 로 인덱싱하는 것이 좋습니다.
                //   - `i + chunk > 0` 사소한 사실입니다.
                //   - 루프 검사는 다음을 보장합니다.
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln` 이므로 빼기가 언더 플로되지 않습니다.
                // - `read_unaligned` 및 `write_unaligned` 호출은 정상입니다.
                //   - `pa` `i` 인덱스를 가리키고 `i < ln / 2 - (chunk - 1)` (위 참조)와 `pb` 는 `ln - i - chunk` 인덱스를 가리 키므로 둘 다 `self` 끝에서 적어도 `chunk` 많은 바이트 떨어져 있습니다.
                //
                //   - 초기화 된 모든 메모리는 유효한 `usize` 입니다.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32 에서 16 씩 회전을 사용하여 u16을 반전
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // 안전: `i + 1 < ln` 의 경우 `i` 에서 정렬되지 않은 u32 를 읽을 수 있습니다.
                // (그리고 분명히 `i < ln`), 각 요소는 2 바이트이고 우리는 4를 읽습니다.
                //
                // `i + chunk - 1 < ln / 2` # 동안 조건
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // 길이를 2로 나눈 것보다 작기 때문에 경계 내에 있어야합니다.
                //
                // 이것은 또한 `0 < i + chunk <= ln` 조건이 항상 존중되어 `pb` 포인터를 안전하게 사용할 수 있음을 의미합니다.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // 안전: `i` 는 슬라이스 길이의 절반보다 열등하므로
            // `i` 및 `ln - i - 1` 에 액세스하는 것은 안전합니다 (`i` 는 0에서 시작하고 `ln / 2 - 1` 이상으로 이동하지 않음).
            // 따라서 결과 포인터 `pa` 및 `pb` 는 유효하고 정렬되어 있으며 읽고 쓸 수 있습니다.
            //
            //
            unsafe {
                // 안전 스왑에서 경계 체크인을 피하기위한 안전하지 않은 스왑.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// 슬라이스에 대한 반복기를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// 각 값을 수정할 수있는 반복기를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// 길이가 `size` 인 모든 연속 windows 에 대한 반복기를 반환합니다.
    /// windows 가 겹칩니다.
    /// 슬라이스가 `size` 보다 짧은 경우 반복기는 값을 반환하지 않습니다.
    ///
    /// # Panics
    ///
    /// `size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 슬라이스가 `size` 보다 짧은 경우 :
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// 슬라이스의 시작 부분에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 슬라이스이며 겹치지 않습니다.`chunk_size` 가 슬라이스의 길이를 나누지 않으면 마지막 청크의 길이는 `chunk_size` 가 아닙니다.
    ///
    /// 항상 정확히 `chunk_size` 요소의 청크를 반환하는이 반복기의 변형에 대해서는 [`chunks_exact`] 를 참조하고, 슬라이스 끝에서 시작하는 동일한 반복기에 대해서는 [`rchunks`] 를 참조하십시오.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// 슬라이스의 시작 부분에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 변경 가능한 슬라이스이며 겹치지 않습니다.`chunk_size` 가 슬라이스의 길이를 나누지 않으면 마지막 청크의 길이는 `chunk_size` 가 아닙니다.
    ///
    /// 항상 정확히 `chunk_size` 요소의 청크를 반환하는이 반복기의 변형에 대해서는 [`chunks_exact_mut`] 를 참조하고, 슬라이스 끝에서 시작하는 동일한 반복기에 대해서는 [`rchunks_mut`] 를 참조하십시오.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// 슬라이스의 시작 부분에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 슬라이스이며 겹치지 않습니다.
    /// `chunk_size` 가 슬라이스의 길이를 나누지 않으면 마지막 `chunk_size-1` 요소가 생략되고 반복기의 `remainder` 함수에서 검색 할 수 있습니다.
    ///
    ///
    /// 각 청크에 정확히 `chunk_size` 요소가 있기 때문에 컴파일러는 종종 [`chunks`] 의 경우보다 결과 코드를 더 잘 최적화 할 수 있습니다.
    ///
    /// 나머지도 더 작은 청크로 반환하는이 반복기의 변형에 대해서는 [`chunks`] 를 참조하고 슬라이스 끝에서 시작하는 동일한 반복기에 대해서는 [`rchunks_exact`] 를 참조하십시오.
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// 슬라이스의 시작 부분에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 변경 가능한 슬라이스이며 겹치지 않습니다.
    /// `chunk_size` 가 슬라이스 길이를 나누지 않으면 마지막 최대 `chunk_size-1` 요소가 생략되고 반복기의 `into_remainder` 함수에서 검색 할 수 있습니다.
    ///
    ///
    /// 각 청크에 정확히 `chunk_size` 요소가 있기 때문에 컴파일러는 종종 [`chunks_mut`] 의 경우보다 결과 코드를 더 잘 최적화 할 수 있습니다.
    ///
    /// 나머지도 더 작은 청크로 반환하는이 반복기의 변형에 대해서는 [`chunks_mut`] 를 참조하고 슬라이스 끝에서 시작하는 동일한 반복기에 대해서는 [`rchunks_exact_mut`] 를 참조하십시오.
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// 나머지가 없다고 가정하고 슬라이스를`N` 요소 배열의 슬라이스로 분할합니다.
    ///
    ///
    /// # Safety
    ///
    /// 다음 경우에만 호출 할 수 있습니다.
    /// - 슬라이스는 정확히 'N'요소 청크로 분할됩니다 (일명 `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // 안전: 1 요소 청크에는 나머지가 없습니다.
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // 안전: 슬라이스 길이 (6) 는 3의 배수입니다.
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // 이것은 불건전 할 것입니다.
    /// // 청크: &[[_;5]]= slice.as_chunks_unchecked()//슬라이스 길이는 5 let 청크의 배수가 아닙니다.&[[_;0]]= slice.as_chunks_unchecked()//길이가 0 인 청크는 허용되지 않습니다.
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // 안전: 우리의 전제 조건은 정확히 이것을 호출하는 데 필요한 것입니다.
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // 안전: `new_len * N` 요소 조각을
        // `new_len` 많은 `N` 요소 청크 조각.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// 슬라이스를 슬라이스의 시작 부분에서 시작하여`N` 요소 배열의 슬라이스와 길이가 `N` 보다 작은 나머지 슬라이스로 분할합니다.
    ///
    ///
    /// # Panics
    ///
    /// `N` 가 0이면 Panics.이 검사는이 메서드가 안정화되기 전에 컴파일 시간 오류로 변경 될 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // 안전: 우리는 이미 제로에 당황했고 건설을 통해
        // 서브 슬라이스의 길이는 N의 배수입니다.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// 슬라이스를 슬라이스의 끝에서 시작하여`N` 요소 배열의 슬라이스와 길이가 `N` 보다 작은 나머지 슬라이스로 분할합니다.
    ///
    ///
    /// # Panics
    ///
    /// `N` 가 0이면 Panics.이 검사는이 메서드가 안정화되기 전에 컴파일 시간 오류로 변경 될 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // 안전: 우리는 이미 제로에 당황했고 건설을 통해
        // 서브 슬라이스의 길이는 N의 배수입니다.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// 슬라이스의 시작 부분에서 시작하여 한 번에 슬라이스의 `N` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 배열 참조이며 겹치지 않습니다.
    /// `N` 가 슬라이스의 길이를 나누지 않으면 마지막 `N-1` 요소가 생략되고 반복기의 `remainder` 함수에서 검색 할 수 있습니다.
    ///
    ///
    /// 이 메서드는 [`chunks_exact`] 와 동등한 const 일반 메서드입니다.
    ///
    /// # Panics
    ///
    /// `N` 가 0이면 Panics.이 검사는이 메서드가 안정화되기 전에 컴파일 시간 오류로 변경 될 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// 나머지가 없다고 가정하고 슬라이스를`N` 요소 배열의 슬라이스로 분할합니다.
    ///
    ///
    /// # Safety
    ///
    /// 다음 경우에만 호출 할 수 있습니다.
    /// - 슬라이스는 정확히 'N'요소 청크로 분할됩니다 (일명 `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // 안전: 1 요소 청크에는 나머지가 없습니다.
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // 안전: 슬라이스 길이 (6) 는 3의 배수입니다.
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // 이것은 불건전 할 것입니다.
    /// // 청크: &[[_;5]]= slice.as_chunks_unchecked_mut()//슬라이스 길이는 5 let 청크의 배수가 아닙니다.&[[_;0]]= slice.as_chunks_unchecked_mut()//길이가 0 인 청크는 허용되지 않습니다.
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // 안전: 우리의 전제 조건은 정확히 이것을 호출하는 데 필요한 것입니다.
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // 안전: `new_len * N` 요소 조각을
        // `new_len` 많은 `N` 요소 청크 조각.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// 슬라이스를 슬라이스의 시작 부분에서 시작하여`N` 요소 배열의 슬라이스와 길이가 `N` 보다 작은 나머지 슬라이스로 분할합니다.
    ///
    ///
    /// # Panics
    ///
    /// `N` 가 0이면 Panics.이 검사는이 메서드가 안정화되기 전에 컴파일 시간 오류로 변경 될 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // 안전: 우리는 이미 제로에 당황했고 건설을 통해
        // 서브 슬라이스의 길이는 N의 배수입니다.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// 슬라이스를 슬라이스의 끝에서 시작하여`N` 요소 배열의 슬라이스와 길이가 `N` 보다 작은 나머지 슬라이스로 분할합니다.
    ///
    ///
    /// # Panics
    ///
    /// `N` 가 0이면 Panics.이 검사는이 메서드가 안정화되기 전에 컴파일 시간 오류로 변경 될 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // 안전: 우리는 이미 제로에 당황했고 건설을 통해
        // 서브 슬라이스의 길이는 N의 배수입니다.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// 슬라이스의 시작 부분에서 시작하여 한 번에 슬라이스의 `N` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 가변 배열 참조이며 겹치지 않습니다.
    /// `N` 가 슬라이스의 길이를 나누지 않으면 마지막 `N-1` 요소가 생략되고 반복기의 `into_remainder` 함수에서 검색 할 수 있습니다.
    ///
    ///
    /// 이 메서드는 [`chunks_exact_mut`] 와 동등한 const 일반 메서드입니다.
    ///
    /// # Panics
    ///
    /// `N` 가 0이면 Panics.이 검사는이 메서드가 안정화되기 전에 컴파일 시간 오류로 변경 될 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// 슬라이스의 시작 부분에서 시작하여 슬라이스의 `N` 요소 중 windows 겹치는 반복기를 반환합니다.
    ///
    ///
    /// 이것은 [`windows`] 와 동등한 const 일반입니다.
    ///
    /// `N` 가 슬라이스 크기보다 크면 windows 를 반환하지 않습니다.
    ///
    /// # Panics
    ///
    /// `N` 가 0이면 Panics 입니다.
    /// 이 검사는이 메서드가 안정화되기 전에 컴파일 시간 오류로 변경 될 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// 슬라이스의 끝에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 슬라이스이며 겹치지 않습니다.`chunk_size` 가 슬라이스의 길이를 나누지 않으면 마지막 청크의 길이는 `chunk_size` 가 아닙니다.
    ///
    /// 항상 정확히 `chunk_size` 요소의 청크를 반환하는이 반복기의 변형에 대해서는 [`rchunks_exact`] 를 참조하고 슬라이스의 시작에서 시작하는 동일한 반복기에 대해서는 [`chunks`] 를 참조하십시오.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// 슬라이스의 끝에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 변경 가능한 슬라이스이며 겹치지 않습니다.`chunk_size` 가 슬라이스의 길이를 나누지 않으면 마지막 청크의 길이는 `chunk_size` 가 아닙니다.
    ///
    /// 항상 정확히 `chunk_size` 요소의 청크를 반환하는이 반복기의 변형에 대해서는 [`rchunks_exact_mut`] 를 참조하고 슬라이스의 시작에서 시작하는 동일한 반복기에 대해서는 [`chunks_mut`] 를 참조하십시오.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// 슬라이스의 끝에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 슬라이스이며 겹치지 않습니다.
    /// `chunk_size` 가 슬라이스의 길이를 나누지 않으면 마지막 `chunk_size-1` 요소가 생략되고 반복기의 `remainder` 함수에서 검색 할 수 있습니다.
    ///
    /// 각 청크에 정확히 `chunk_size` 요소가 있기 때문에 컴파일러는 종종 [`chunks`] 의 경우보다 결과 코드를 더 잘 최적화 할 수 있습니다.
    ///
    /// 나머지도 더 작은 청크로 반환하는이 반복자의 변형에 대해서는 [`rchunks`] 를 참조하고 슬라이스의 시작 부분에서 시작하는 동일한 반복기에 대해서는 [`chunks_exact`] 를 참조하십시오.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// 슬라이스의 끝에서 시작하여 한 번에 슬라이스의 `chunk_size` 요소에 대한 반복기를 반환합니다.
    ///
    /// 청크는 변경 가능한 슬라이스이며 겹치지 않습니다.
    /// `chunk_size` 가 슬라이스 길이를 나누지 않으면 마지막 최대 `chunk_size-1` 요소가 생략되고 반복기의 `into_remainder` 함수에서 검색 할 수 있습니다.
    ///
    /// 각 청크에 정확히 `chunk_size` 요소가 있기 때문에 컴파일러는 종종 [`chunks_mut`] 의 경우보다 결과 코드를 더 잘 최적화 할 수 있습니다.
    ///
    /// 나머지도 더 작은 청크로 반환하는이 반복자의 변형에 대해서는 [`rchunks_mut`] 를 참조하고 슬라이스의 시작 부분에서 시작하는 동일한 반복기에 대해서는 [`chunks_exact_mut`] 를 참조하십시오.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 가 0이면 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// 조건자를 사용하여 요소를 구분하는 겹치지 않는 실행을 생성하는 슬라이스에 대한 반복기를 반환합니다.
    ///
    /// 술어는 그 뒤의 두 요소에서 호출됩니다. 이는 술어가 `slice[0]` 및 `slice[1]` 에서 호출 된 다음 `slice[1]` 및 `slice[2]` 등에서 호출됨을 의미합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 이 메서드는 정렬 된 하위 조각을 추출하는 데 사용할 수 있습니다.
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// 조건자를 사용하여 요소를 구분하는 겹치지 않는 가변 실행을 생성하는 슬라이스에 대한 반복기를 반환합니다.
    ///
    /// 술어는 그 뒤의 두 요소에서 호출됩니다. 이는 술어가 `slice[0]` 및 `slice[1]` 에서 호출 된 다음 `slice[1]` 및 `slice[2]` 등에서 호출됨을 의미합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 이 메서드는 정렬 된 하위 조각을 추출하는 데 사용할 수 있습니다.
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// 인덱스에서 하나의 슬라이스를 두 개로 나눕니다.
    ///
    /// 첫 번째는 `[0, mid)` 의 모든 색인 (`mid` 자체 제외)을 포함하고 두 번째는 `[mid, len)` (`len` 색인 자체 제외)의 모든 색인을 포함합니다.
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` 인 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // 안전: `[ptr; mid]` 및 `[mid; len]` 는 `self` 내부에 있습니다.
        // `from_raw_parts_mut` 의 요구 사항을 충족합니다.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// 인덱스에서 하나의 가변 슬라이스를 두 개로 나눕니다.
    ///
    /// 첫 번째는 `[0, mid)` 의 모든 색인 (`mid` 자체 제외)을 포함하고 두 번째는 `[mid, len)` (`len` 색인 자체 제외)의 모든 색인을 포함합니다.
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` 인 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // 안전: `[ptr; mid]` 및 `[mid; len]` 는 `self` 내부에 있습니다.
        // `from_raw_parts_mut` 의 요구 사항을 충족합니다.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// 경계 검사를 수행하지 않고 인덱스에서 하나의 슬라이스를 두 개로 나눕니다.
    ///
    /// 첫 번째는 `[0, mid)` 의 모든 색인 (`mid` 자체 제외)을 포함하고 두 번째는 `[mid, len)` (`len` 색인 자체 제외)의 모든 색인을 포함합니다.
    ///
    ///
    /// 안전한 대안은 [`split_at`] 를 참조하십시오.
    ///
    /// # Safety
    ///
    /// 경계를 벗어난 인덱스로이 메서드를 호출하면 결과 참조가 사용되지 않더라도 *[정의되지 않은 동작]* 이됩니다.발신자는 `0 <= mid <= self.len()` 를 확인해야합니다.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // 안전: 발신자는 `0 <= mid <= self.len()` 가
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// 경계 검사를 수행하지 않고 인덱스에서 하나의 가변 슬라이스를 두 개로 나눕니다.
    ///
    /// 첫 번째는 `[0, mid)` 의 모든 색인 (`mid` 자체 제외)을 포함하고 두 번째는 `[mid, len)` (`len` 색인 자체 제외)의 모든 색인을 포함합니다.
    ///
    ///
    /// 안전한 대안은 [`split_at_mut`] 를 참조하십시오.
    ///
    /// # Safety
    ///
    /// 경계를 벗어난 인덱스로이 메서드를 호출하면 결과 참조가 사용되지 않더라도 *[정의되지 않은 동작]* 이됩니다.발신자는 `0 <= mid <= self.len()` 를 확인해야합니다.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // 안전: 발신자는 `0 <= mid <= self.len()` 를 확인해야합니다.
        //
        // `[ptr; mid]` `[mid; len]` 는 겹치지 않으므로 가변 참조를 반환하는 것이 좋습니다.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred` 와 일치하는 요소로 구분 된 하위 슬라이스에 대한 반복기를 반환합니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 첫 번째 요소가 일치하면 빈 조각이 반복기에 의해 반환되는 첫 번째 항목이됩니다.
    /// 마찬가지로 조각의 마지막 요소가 일치하면 빈 조각이 반복기가 반환하는 마지막 항목이됩니다.
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 일치하는 두 요소가 바로 인접 해 있으면 그 사이에 빈 슬라이스가 표시됩니다.
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred` 와 일치하는 요소로 구분 된 변경 가능한 하위 슬라이스에 대한 반복기를 반환합니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred` 와 일치하는 요소로 구분 된 하위 슬라이스에 대한 반복기를 반환합니다.
    /// 일치하는 요소는 종결 자로 이전 서브 슬라이스의 끝에 포함됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 슬라이스의 마지막 요소가 일치하면 해당 요소는 이전 슬라이스의 종결 자로 간주됩니다.
    ///
    /// 해당 슬라이스는 반복자가 반환하는 마지막 항목이됩니다.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred` 와 일치하는 요소로 구분 된 변경 가능한 하위 슬라이스에 대한 반복기를 반환합니다.
    /// 일치하는 요소는 종결 자로 이전 서브 슬라이스에 포함됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred` 와 일치하는 요소로 구분 된 하위 슬라이스에 대한 반복기를 슬라이스의 끝에서 시작하여 역방향으로 반환합니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` 와 마찬가지로 첫 번째 또는 마지막 요소가 일치하면 빈 슬라이스가 반복기에 의해 반환되는 첫 번째 (또는 마지막) 항목이됩니다.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred` 와 일치하는 요소로 구분 된 변경 가능한 하위 슬라이스에 대한 반복기를 슬라이스의 끝에서 시작하여 역방향으로 반환합니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred` 와 일치하는 요소로 구분 된 하위 슬라이스에 대한 반복기를 반환하며 최대 `n` 항목 만 반환하도록 제한됩니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// 반환 된 마지막 요소 (있는 경우)는 나머지 조각을 포함합니다.
    ///
    /// # Examples
    ///
    /// 3으로 나눌 수있는 숫자 (예: `[10, 40]`, `[20, 60, 50]`)로 한 번 분할 된 슬라이스를 인쇄합니다.
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred` 와 일치하는 요소로 구분 된 하위 슬라이스에 대한 반복기를 반환하며 최대 `n` 항목 만 반환하도록 제한됩니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// 반환 된 마지막 요소 (있는 경우)는 나머지 조각을 포함합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// 최대 `n` 항목을 반환하도록 제한되는 `pred` 와 일치하는 요소로 구분 된 하위 슬라이스에 대한 반복기를 반환합니다.
    /// 이것은 슬라이스의 끝에서 시작하여 거꾸로 작동합니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// 반환 된 마지막 요소 (있는 경우)는 나머지 조각을 포함합니다.
    ///
    /// # Examples
    ///
    /// 3으로 나눌 수있는 숫자 (예: `[50]`, `[10, 40, 30, 20]`)로 끝부터 시작하여 슬라이스 분할을 한 번 인쇄합니다.
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// 최대 `n` 항목을 반환하도록 제한되는 `pred` 와 일치하는 요소로 구분 된 하위 슬라이스에 대한 반복기를 반환합니다.
    /// 이것은 슬라이스의 끝에서 시작하여 거꾸로 작동합니다.
    /// 일치하는 요소가 서브 슬라이스에 포함되어 있지 않습니다.
    ///
    /// 반환 된 마지막 요소 (있는 경우)는 나머지 조각을 포함합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// 슬라이스에 주어진 값을 가진 요소가 포함 된 경우 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// `&T` 는 없지만 `T: Borrow<U>` 와 같은 `&U` (예 :
    /// `문자열: 차용<str>`), `iter().any` 를 사용할 수 있습니다.
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` 슬라이스
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` 로 검색
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` 가 슬라이스의 접두사이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` 가 빈 슬라이스이면 항상 `true` 를 반환합니다.
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` 가 슬라이스의 접미사이면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` 가 빈 슬라이스이면 항상 `true` 를 반환합니다.
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// 접두사가 제거 된 서브 슬라이스를 반환합니다.
    ///
    /// 슬라이스가 `prefix` 로 시작하는 경우 `Some` 로 래핑 된 접두사 뒤의 하위 슬라이스를 반환합니다.
    /// `prefix` 가 비어 있으면 원래 슬라이스를 반환합니다.
    ///
    /// 슬라이스가 `prefix` 로 시작하지 않으면 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // 이 함수는 SlicePattern이 더 정교 해지면 다시 작성해야합니다.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// 접미사가 제거 된 서브 슬라이스를 반환합니다.
    ///
    /// 슬라이스가 `suffix` 로 끝나는 경우 `Some` 로 래핑 된 접미사 앞의 하위 슬라이스를 반환합니다.
    /// `suffix` 가 비어 있으면 원래 슬라이스를 반환합니다.
    ///
    /// 슬라이스가 `suffix` 로 끝나지 않으면 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // 이 함수는 SlicePattern이 더 정교 해지면 다시 작성해야합니다.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// 바이너리는이 정렬 된 슬라이스에서 주어진 요소를 검색합니다.
    ///
    /// 값이 발견되면 일치하는 요소의 색인을 포함하는 [`Result::Ok`] 가 리턴됩니다.
    /// 일치하는 항목이 여러 개인 경우 일치 항목 중 하나가 반환 될 수 있습니다.
    /// 값이 없으면 정렬 된 순서를 유지하면서 일치하는 요소를 삽입 할 수있는 인덱스를 포함하는 [`Result::Err`] 가 반환됩니다.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`] 및 [`partition_point`] 도 참조하십시오.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 일련의 네 가지 요소를 찾습니다.
    /// 첫 번째는 고유하게 결정된 위치로 발견됩니다.두 번째와 세 번째는 찾을 수 없습니다.네 번째는 `[1, 4]` 의 모든 위치와 일치 할 수 있습니다.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// 정렬 순서를 유지하면서 정렬 된 vector 에 항목을 삽입하려는 경우 :
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary는 비교기 함수를 사용하여이 정렬 된 슬라이스를 검색합니다.
    ///
    /// 비교기 함수는 기본 슬라이스의 정렬 순서와 일치하는 순서를 구현하여 인수가 원하는 대상인 `Less`, `Equal` 또는 `Greater` 인지 여부를 나타내는 순서 코드를 반환해야합니다.
    ///
    ///
    /// 값이 발견되면 일치하는 요소의 색인을 포함하는 [`Result::Ok`] 가 리턴됩니다.일치하는 항목이 여러 개인 경우 일치 항목 중 하나가 반환 될 수 있습니다.
    /// 값이 없으면 정렬 된 순서를 유지하면서 일치하는 요소를 삽입 할 수있는 인덱스를 포함하는 [`Result::Err`] 가 반환됩니다.
    ///
    /// [`binary_search`], [`binary_search_by_key`] 및 [`partition_point`] 도 참조하십시오.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 일련의 네 가지 요소를 찾습니다.첫 번째는 고유하게 결정된 위치로 발견됩니다.두 번째와 세 번째는 찾을 수 없습니다.네 번째는 `[1, 4]` 의 모든 위치와 일치 할 수 있습니다.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // 안전: 호출은 다음과 같은 불변성에 의해 안전하게 이루어집니다.
            // - `mid >= 0`
            // - `mid < size`: `mid` 는 `[left; right)` 바인딩에 의해 제한됩니다.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // 일치가 아닌 if/else 제어 흐름을 사용하는 이유는 일치가 성능에 민감한 비교 작업을 재정렬하기 때문입니다.
            //
            // u8 용 x86 asm입니다. https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// 바이너리는 키 추출 기능을 사용하여이 정렬 된 슬라이스를 검색합니다.
    ///
    /// 예를 들어 동일한 키 추출 기능을 사용하는 [`sort_by_key`] 와 같이 슬라이스가 키별로 정렬되었다고 가정합니다.
    ///
    /// 값이 발견되면 일치하는 요소의 색인을 포함하는 [`Result::Ok`] 가 리턴됩니다.
    /// 일치하는 항목이 여러 개인 경우 일치 항목 중 하나가 반환 될 수 있습니다.
    /// 값이 없으면 정렬 된 순서를 유지하면서 일치하는 요소를 삽입 할 수있는 인덱스를 포함하는 [`Result::Err`] 가 반환됩니다.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`] 및 [`partition_point`] 도 참조하십시오.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 두 번째 요소로 정렬 된 쌍 조각에서 일련의 네 요소를 찾습니다.
    /// 첫 번째는 고유하게 결정된 위치로 발견됩니다.두 번째와 세 번째는 찾을 수 없습니다.네 번째는 `[1, 4]` 의 모든 위치와 일치 할 수 있습니다.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links 는 `slice::sort_by_key` 가 crate `alloc` 에 있으므로 허용되며 `core` 를 빌드 할 때 아직 존재하지 않습니다.
    //
    // 다운 스트림 crate: #74481 에 대한 링크.프리미티브는 libstd (#73423) 에만 문서화되어 있으므로 실제로는 링크가 끊어지지 않습니다.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// 슬라이스를 정렬하지만 동일한 요소의 순서를 유지하지 못할 수 있습니다.
    ///
    /// 이 정렬은 불안정하고 (즉, 동일한 요소를 재정렬 할 수 있음), 제자리 (즉, 할당하지 않음) 및 *O*(*n*\*log(* n*)) 최악의 경우)입니다.
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 Orson Peters의 [pattern-defeating quicksort][pdqsort] 를 기반으로합니다.이 알고리즘은 임의의 퀵 정렬의 빠른 평균 사례와 힙 정렬의 빠른 최악의 경우를 결합하는 동시에 특정 패턴의 슬라이스에서 선형 시간을 달성합니다.
    /// 일부 무작위 화를 사용하여 퇴화 사례를 방지하지만 고정 된 seed 를 사용하여 항상 결정적 동작을 제공합니다.
    ///
    /// 예를 들어 슬라이스가 여러 개의 연결된 정렬 시퀀스로 구성된 경우와 같은 몇 가지 특수한 경우를 제외하고는 일반적으로 안정적인 정렬보다 빠릅니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// 비교 함수를 사용하여 슬라이스를 정렬하지만 동일한 요소의 순서를 유지하지 못할 수 있습니다.
    ///
    /// 이 정렬은 불안정하고 (즉, 동일한 요소를 재정렬 할 수 있음), 제자리 (즉, 할당하지 않음) 및 *O*(*n*\*log(* n*)) 최악의 경우)입니다.
    ///
    /// 비교기 함수는 슬라이스의 요소에 대한 전체 순서를 정의해야합니다.순서가 전체가 아닌 경우 요소의 순서가 지정되지 않습니다.다음과 같은 경우 주문은 총 주문입니다 (모든 `a`, `b` 및 `c`).
    ///
    /// * 전체 및 비대칭: `a < b`, `a == b` 또는 `a > b` 중 정확히 하나가 참이고
    /// * 전이, `a < b` 및 `b < c` 는 `a < c` 를 의미합니다.`==` 와 `>` 모두 동일해야합니다.
    ///
    /// 예를 들어, [`f64`] 는 `NaN != NaN` 때문에 [`Ord`] 를 구현하지 않지만 슬라이스에 `NaN` 가 포함되어 있지 않다는 것을 알면 `partial_cmp` 를 정렬 함수로 사용할 수 있습니다.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 Orson Peters의 [pattern-defeating quicksort][pdqsort] 를 기반으로합니다.이 알고리즘은 임의의 퀵 정렬의 빠른 평균 사례와 힙 정렬의 빠른 최악의 경우를 결합하는 동시에 특정 패턴의 슬라이스에서 선형 시간을 달성합니다.
    /// 일부 무작위 화를 사용하여 퇴화 사례를 방지하지만 고정 된 seed 를 사용하여 항상 결정적 동작을 제공합니다.
    ///
    /// 예를 들어 슬라이스가 여러 개의 연결된 정렬 시퀀스로 구성된 경우와 같은 몇 가지 특수한 경우를 제외하고는 일반적으로 안정적인 정렬보다 빠릅니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // 역 정렬
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// 키 추출 기능을 사용하여 슬라이스를 정렬하지만 동일한 요소의 순서를 유지하지 못할 수 있습니다.
    ///
    /// 이 정렬은 불안정하고 (즉, 동일한 요소를 재정렬 할 수 있음) 제자리 (즉, 할당하지 않음) 및 *O*(m\* * n *\* log(*n*)) 최악의 경우, 여기서 핵심 기능은 *O* 입니다. (*미디엄*).
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 Orson Peters의 [pattern-defeating quicksort][pdqsort] 를 기반으로합니다.이 알고리즘은 임의의 퀵 정렬의 빠른 평균 사례와 힙 정렬의 빠른 최악의 경우를 결합하는 동시에 특정 패턴의 슬라이스에서 선형 시간을 달성합니다.
    /// 일부 무작위 화를 사용하여 퇴화 사례를 방지하지만 고정 된 seed 를 사용하여 항상 결정적 동작을 제공합니다.
    ///
    /// 키 호출 전략으로 인해 [`sort_unstable_by_key`](#method.sort_unstable_by_key) 는 키 기능이 비싼 경우 [`sort_by_cached_key`](#method.sort_by_cached_key) 보다 느릴 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// `index` 의 요소가 최종 정렬 위치에 있도록 슬라이스를 다시 정렬합니다.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// `index` 의 요소가 최종 정렬 위치에 있도록 비교 함수를 사용하여 슬라이스를 재정렬합니다.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// `index` 의 요소가 최종 정렬 위치에 있도록 키 추출 기능을 사용하여 슬라이스를 재정렬합니다.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// `index` 의 요소가 최종 정렬 위치에 있도록 슬라이스를 다시 정렬합니다.
    ///
    /// 이 재정렬에는 위치 `i < index` 의 값이 위치 `j > index` 의 값보다 작거나 같다는 추가 속성이 있습니다.
    /// 또한이 재정렬은 불안정합니다 (예 :
    /// 임의의 수의 동일한 요소가 위치 `index` 에서 끝날 수 있음), 제자리 (예 :
    /// 할당하지 않음) 및 *O*(*n*) 최악의 경우.
    /// 이 기능은 다른 라이브러리에서 "kth element" 라고도합니다.
    /// 주어진 인덱스에있는 것보다 작은 모든 요소, 주어진 인덱스에있는 값, 주어진 인덱스에있는 것보다 큰 모든 요소의 삼중 항 값을 반환합니다.
    ///
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 [`sort_unstable`] 에 사용되는 동일한 빠른 정렬 알고리즘의 빠른 선택 부분을 기반으로합니다.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 일 때 Panics, 즉 빈 슬라이스에서 항상 panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 중앙값 찾기
    /// v.select_nth_unstable(2);
    ///
    /// // 지정된 인덱스에 대해 정렬하는 방식에 따라 슬라이스가 다음 중 하나가 될 것임을 보장합니다.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` 의 요소가 최종 정렬 위치에 있도록 비교 함수를 사용하여 슬라이스를 재정렬합니다.
    ///
    /// 이 재정렬에는 `i < index` 위치의 값이 비교 기능을 사용하는 위치 `j > index` 의 값보다 작거나 같을 것이라는 추가 속성이 있습니다.
    /// 또한이 재정렬은 불안정하고 (즉, 동일한 요소가 `index` 위치에서 끝날 수 있음), 제자리 (즉, 할당하지 않음) 및 *O*(*n*) 최악의 경우입니다.
    /// 이 함수는 다른 라이브러리에서 "kth element" 라고도합니다.
    /// 제공된 비교기 함수를 사용하여 주어진 인덱스의 값보다 작은 모든 요소, 지정된 인덱스의 값, 지정된 인덱스의 값보다 큰 모든 요소의 세 가지 값을 반환합니다.
    ///
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 [`sort_unstable`] 에 사용되는 동일한 빠른 정렬 알고리즘의 빠른 선택 부분을 기반으로합니다.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 일 때 Panics, 즉 빈 슬라이스에서 항상 panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 슬라이스가 내림차순으로 정렬 된 것처럼 중앙값을 찾습니다.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // 지정된 인덱스에 대해 정렬하는 방식에 따라 슬라이스가 다음 중 하나가 될 것임을 보장합니다.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// `index` 의 요소가 최종 정렬 위치에 있도록 키 추출 기능을 사용하여 슬라이스를 재정렬합니다.
    ///
    /// 이 재정렬에는 키 추출 기능을 사용하여 위치 `i < index` 의 값이 위치 `j > index` 의 값보다 작거나 같다는 추가 속성이 있습니다.
    /// 또한이 재정렬은 불안정하고 (즉, 동일한 요소가 `index` 위치에서 끝날 수 있음), 제자리 (즉, 할당하지 않음) 및 *O*(*n*) 최악의 경우입니다.
    /// 이 함수는 다른 라이브러리에서 "kth element" 라고도합니다.
    /// 제공된 키 추출 함수를 사용하여 주어진 인덱스의 값보다 작은 모든 요소, 지정된 인덱스의 값, 지정된 인덱스의 값보다 큰 모든 요소의 3 중항 값을 반환합니다.
    ///
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 [`sort_unstable`] 에 사용되는 동일한 빠른 정렬 알고리즘의 빠른 선택 부분을 기반으로합니다.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 일 때 Panics, 즉 빈 슬라이스에서 항상 panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 배열이 절대 값에 따라 정렬 된 것처럼 중앙값을 반환합니다.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // 지정된 인덱스에 대해 정렬하는 방식에 따라 슬라이스가 다음 중 하나가 될 것임을 보장합니다.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait 구현에 따라 모든 연속 반복 요소를 슬라이스의 끝으로 이동합니다.
    ///
    ///
    /// 두 조각을 반환합니다.첫 번째에는 연속적으로 반복되는 요소가 없습니다.
    /// 두 번째는 지정된 순서없이 모든 중복을 포함합니다.
    ///
    /// 슬라이스가 정렬 된 경우 첫 번째 반환 된 슬라이스에는 중복 항목이 포함되지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// 연속 된 요소 중 첫 번째 요소를 제외한 모든 요소를 주어진 동등 관계를 만족하는 슬라이스의 끝으로 이동합니다.
    ///
    /// 두 조각을 반환합니다.첫 번째에는 연속적으로 반복되는 요소가 없습니다.
    /// 두 번째는 지정된 순서없이 모든 중복을 포함합니다.
    ///
    /// `same_bucket` 함수는 슬라이스의 두 요소에 대한 참조를 전달하며 요소가 동일한 지 확인해야합니다.
    /// 요소는 슬라이스의 순서와 반대 순서로 전달되므로 `same_bucket(a, b)` 가 `true` 를 반환하면 `a` 가 슬라이스의 끝에서 이동합니다.
    ///
    ///
    /// 슬라이스가 정렬 된 경우 첫 번째 반환 된 슬라이스에는 중복 항목이 포함되지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // `self` 에 대한 변경 가능한 참조가 있지만 *임의* 변경은 할 수 없습니다.`same_bucket` 호출은 panic 가 될 수 있으므로 슬라이스가 항상 유효한 상태인지 확인해야합니다.
        //
        // 이를 처리하는 방법은 스왑을 사용하는 것입니다.우리는 모든 요소를 반복하면서 끝에서 유지하려는 요소가 앞쪽에 있고 거부하려는 요소가 뒤쪽에 있도록 진행하면서 교체합니다.
        // 그런 다음 슬라이스를 분할 할 수 있습니다.
        // 이 작업은 여전히 `O(n)` 입니다.
        //
        // 예: 이 상태에서 시작합니다. 여기서 `r` 는 "다음
        // read "와 `w` 는"next_write "를 나타냅니다.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] 를 self [w-1]과 비교하면 이것은 중복이 아니므로 self[r] 와 self[w] (r==w로 효과 없음)를 바꾼 다음 r과 w를 모두 증가시켜 다음과 같이 남겨 둡니다.
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] 와 self [w-1]을 비교하면이 값은 중복되므로 `r` 를 증가시키고 나머지는 변경하지 않습니다.
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] 를 self [w-1]과 비교하면 이것은 중복이 아니므로 self[r] 와 self[w] 를 바꾸고 r과 w를 진행합니다.
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // 중복이 아닌 반복 :
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // 복제, advance r. End 슬라이스.w에서 분할.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // 안전: `while` 조건은 `next_read` 및 `next_write` 를 보장합니다.
        // `len` 보다 작으므로 `self` 안에 있습니다.
        // `prev_ptr_write` `ptr_write` 이전의 한 요소를 가리 키지 만 `next_write` 는 1에서 시작하므로 `prev_ptr_write` 는 0보다 작지 않으며 슬라이스 내부에 있습니다.
        // 이는 `ptr_read`, `prev_ptr_write` 및 `ptr_write` 를 역 참조하고 `ptr.add(next_read)`, `ptr.add(next_write - 1)` 및 `prev_ptr_write.offset(1)` 를 사용하기위한 요구 사항을 충족합니다.
        //
        //
        // `next_write` 또한 루프 당 최대 한 번 증가하므로 교체해야 할 때 요소를 건너 뛰지 않습니다.
        //
        // `ptr_read` `prev_ptr_write` 는 동일한 요소를 가리 키지 않습니다.이것은 `&mut *ptr_read`, `&mut* prev_ptr_write` 가 안전하기 위해 필요합니다.
        // 설명은 단순히 `next_read >= next_write` 가 항상 사실이므로 `next_read > next_write - 1` 도 마찬가지입니다.
        //
        //
        //
        //
        //
        unsafe {
            // 원시 포인터를 사용하여 경계 검사를 피하십시오.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// 연속 요소 중 첫 번째 요소를 제외한 모든 요소를 동일한 키로 확인되는 슬라이스 끝으로 이동합니다.
    ///
    ///
    /// 두 조각을 반환합니다.첫 번째에는 연속적으로 반복되는 요소가 없습니다.
    /// 두 번째는 지정된 순서없이 모든 중복을 포함합니다.
    ///
    /// 슬라이스가 정렬 된 경우 첫 번째 반환 된 슬라이스에는 중복 항목이 포함되지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// 슬라이스의 첫 번째 `mid` 요소가 끝으로 이동하고 마지막 `self.len() - mid` 요소가 앞으로 이동하도록 슬라이스를 제자리에서 회전합니다.
    /// `rotate_left` 를 호출하면 이전에 인덱스 `mid` 에 있던 요소가 슬라이스의 첫 번째 요소가됩니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 `mid` 가 슬라이스 길이보다 큰 경우 panic 입니다.`mid == self.len()` 는 _not_ panic 를 수행하며 작동하지 않는 회전입니다.
    ///
    /// # Complexity
    ///
    /// 선형을 취합니다 (`self.len()`) 시간에서.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// 서브 슬라이스 회전 :
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // 안전: `[p.add(mid) - mid, p.add(mid) + k)` 범위는 간단합니다.
        // `ptr_rotate` 에서 요구하는대로 읽기 및 쓰기에 유효합니다.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// 슬라이스의 첫 번째 `self.len() - k` 요소가 끝으로 이동하고 마지막 `k` 요소가 앞으로 이동하도록 슬라이스를 제자리에서 회전합니다.
    /// `rotate_right` 를 호출하면 이전에 인덱스 `self.len() - k` 에 있던 요소가 슬라이스의 첫 번째 요소가됩니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 `k` 가 슬라이스 길이보다 큰 경우 panic 입니다.`k == self.len()` 는 _not_ panic 를 수행하며 작동하지 않는 회전입니다.
    ///
    /// # Complexity
    ///
    /// 선형을 취합니다 (`self.len()`) 시간에서.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// 서브 슬라이스 회전 :
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // 안전: `[p.add(mid) - mid, p.add(mid) + k)` 범위는 간단합니다.
        // `ptr_rotate` 에서 요구하는대로 읽기 및 쓰기에 유효합니다.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` 를 복제하여 `self` 를 요소로 채 웁니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// 클로저를 반복적으로 호출하여 반환 된 요소로 `self` 를 채 웁니다.
    ///
    /// 이 메서드는 클로저를 사용하여 새 값을 만듭니다.주어진 값을 [`Clone`] 로 지정하려면 [`fill`] 를 사용하십시오.
    /// [`Default`] trait 를 사용하여 값을 생성하려면 [`Default::default`] 를 인수로 전달할 수 있습니다.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` 의 요소를 `self` 로 복사합니다.
    ///
    /// `src` 의 길이는 `self` 와 같아야합니다.
    ///
    /// `T` 가 `Copy` 를 구현하는 경우 [`copy_from_slice`] 를 사용하는 것이 더 성능이 좋습니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 두 슬라이스의 길이가 다른 경우 panic 입니다.
    ///
    /// # Examples
    ///
    /// 슬라이스에서 다른 슬라이스로 두 요소 복제 :
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // 슬라이스의 길이가 같아야하므로 소스 슬라이스를 4 개 요소에서 2 개로 슬라이스합니다.
    /// // 이렇게하지 않으면 panic 가됩니다.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust 는 특정 범위의 특정 데이터 조각에 대한 변경 불가능한 참조없이 하나의 변경 가능한 참조 만있을 수 있도록 강제합니다.
    /// 이 때문에 단일 슬라이스에서 `clone_from_slice` 를 사용하려고하면 컴파일 실패가 발생합니다.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// 이 문제를 해결하기 위해 [`split_at_mut`] 를 사용하여 슬라이스에서 두 개의 개별 하위 슬라이스를 만들 수 있습니다.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// memcpy를 사용하여 `src` 의 모든 요소를 `self` 로 복사합니다.
    ///
    /// `src` 의 길이는 `self` 와 같아야합니다.
    ///
    /// `T` 가 `Copy` 를 구현하지 않는 경우 [`clone_from_slice`] 를 사용하십시오.
    ///
    /// # Panics
    ///
    /// 이 함수는 두 슬라이스의 길이가 다른 경우 panic 입니다.
    ///
    /// # Examples
    ///
    /// 슬라이스에서 다른 슬라이스로 두 요소 복사 :
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // 슬라이스의 길이가 같아야하므로 소스 슬라이스를 4 개 요소에서 2 개로 슬라이스합니다.
    /// // 이렇게하지 않으면 panic 가됩니다.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust 는 특정 범위의 특정 데이터 조각에 대한 변경 불가능한 참조없이 하나의 변경 가능한 참조 만있을 수 있도록 강제합니다.
    /// 이 때문에 단일 슬라이스에서 `copy_from_slice` 를 사용하려고하면 컴파일 실패가 발생합니다.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// 이 문제를 해결하기 위해 [`split_at_mut`] 를 사용하여 슬라이스에서 두 개의 개별 하위 슬라이스를 만들 수 있습니다.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic 코드 경로는 콜 사이트를 부 풀리지 않도록 콜드 함수에 넣었습니다.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // 안전: `self` 는 정의에 따라 `self.len()` 요소에 유효하며 `src` 는
        // 길이가 같은지 확인했습니다.
        // 가변 참조는 배타적이므로 슬라이스는 겹칠 수 없습니다.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// memmove를 사용하여 슬라이스의 한 부분에서 다른 부분으로 요소를 복사합니다.
    ///
    /// `src` 복사 할 `self` 내의 범위입니다.
    /// `dest` 복사 할 `self` 내 범위의 시작 인덱스이며 `src` 와 길이가 같습니다.
    /// 두 범위가 겹칠 수 있습니다.
    /// 두 범위의 끝은 `self.len()` 보다 작거나 같아야합니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 범위 중 하나가 슬라이스의 끝을 초과하거나 `src` 의 끝이 시작 이전 인 경우 panic 입니다.
    ///
    ///
    /// # Examples
    ///
    /// 슬라이스 내에서 4 바이트 복사 :
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // 안전: `ptr::copy` 의 조건은 모두 위에서 확인되었습니다.
        // `ptr::add` 의 경우와 같습니다.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` 의 모든 요소를 `other` 의 요소로 바꿉니다.
    ///
    /// `other` 의 길이는 `self` 와 같아야합니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 두 슬라이스의 길이가 다른 경우 panic 입니다.
    ///
    /// # Example
    ///
    /// 슬라이스에서 두 요소 교체 :
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust 는 특정 범위의 특정 데이터에 대해 하나의 가변 참조 만있을 수 있도록 강제합니다.
    ///
    /// 이 때문에 단일 슬라이스에서 `swap_with_slice` 를 사용하려고하면 컴파일 실패가 발생합니다.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// 이 문제를 해결하기 위해 [`split_at_mut`] 를 사용하여 슬라이스에서 두 개의 별개의 가변 하위 슬라이스를 만들 수 있습니다.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // 안전: `self` 는 정의에 따라 `self.len()` 요소에 유효하며 `src` 는
        // 길이가 같은지 확인했습니다.
        // 가변 참조는 배타적이므로 슬라이스는 겹칠 수 없습니다.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` 의 중간 및 후행 슬라이스 길이를 계산하는 함수입니다.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest` 에 대해 우리가 할 일은 가장 낮은 수의`T`에 넣을 수있는`U`의 배수를 알아내는 것입니다.
        //
        // 그리고 각각의 "multiple" 에 필요한 'T'수.
        //
        // 예를 들어 T=u8 U=u16을 고려하십시오.그런 다음 2T에 1U를 넣을 수 있습니다.단순한.
        // 이제 예를 들어 size_of: :<T>=16, size_of::<U>=24.</u>
        // `rest` 슬라이스에서 3 개의 T 대신 2 Us를 배치 할 수 있습니다.
        // 좀 더 복잡합니다.
        //
        // 이를 계산하는 공식은 다음과 같습니다.
        //
        // 우리= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // 확장 및 단순화 :
        //
        // 우리=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // 다행스럽게도이 모든 것이 지속적으로 평가되기 때문에 ... 여기서 성능은 중요하지 않습니다!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein'salgorithm 우리는 여전히이 `const fn` 를 만들어야합니다 (그렇다면 재귀 알고리즘으로 되돌려 야합니다). llvm에 의존하여이 모든 것을 구성하는 것이 ... 글쎄요, 그것은 나를 불편하게 만듭니다.
            //
            //

            // 안전: `a` 및 `b` 는 0이 아닌 값으로 확인됩니다.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // b에서 2의 모든 인수 제거
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // 안전: `b` 가 0이 아닌지 확인합니다.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // 이 지식으로 무장하면 우리는 얼마나 많은 'U'를 맞출 수 있는지 알 수 있습니다!
        let us_len = self.len() / ts * us;
        // 그리고 후행 슬라이스에는 몇 개의 'T'가있을 것입니다!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// 슬라이스를 다른 유형의 슬라이스로 변환하여 유형의 정렬이 유지되도록합니다.
    ///
    /// 이 메서드는 슬라이스를 접두사, 새 유형의 올바르게 정렬 된 중간 슬라이스 및 접미사 슬라이스의 세 가지 개별 슬라이스로 분할합니다.
    /// 이 방법은 중간 슬라이스를 주어진 유형 및 입력 슬라이스에 대해 가능한 최대 길이로 만들 수 있지만 알고리즘의 성능 만이 정확성이 아니라 그것에 의존해야합니다.
    ///
    /// 모든 입력 데이터가 접두사 또는 접미사 슬라이스로 반환되는 것은 허용됩니다.
    ///
    /// 이 메서드는 입력 요소 `T` 또는 출력 요소 `U` 의 크기가 0 일 때 아무런 용도가 없으며 아무것도 분할하지 않고 원래 슬라이스를 반환합니다.
    ///
    /// # Safety
    ///
    /// 이 메서드는 반환 된 중간 슬라이스의 요소와 관련하여 본질적으로 `transmute` 이므로 `transmute::<T, U>` 와 관련된 모든 일반적인 경고도 여기에 적용됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // 이 함수의 대부분은 지속적으로 평가됩니다.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST를 특별히 처리합니다. 즉, 전혀 처리하지 마십시오.
            return (self, &[], &[]);
        }

        // 먼저 첫 번째 조각과 두 번째 조각 사이에서 분할 할 지점을 찾습니다.
        // ptr.align_offset 로 쉽게.
        let ptr = self.as_ptr();
        // 안전: 자세한 안전 설명은 `align_to_mut` 방법을 참조하십시오.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // 안전: 이제 `rest` 는 확실히 정렬되어 있으므로 아래의 `from_raw_parts` 는 괜찮습니다.
            // 호출자가 `T` 를 `U` 로 안전하게 변환 할 수 있음을 보장하기 때문입니다.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// 슬라이스를 다른 유형의 슬라이스로 변환하여 유형의 정렬이 유지되도록합니다.
    ///
    /// 이 메서드는 슬라이스를 접두사, 새 유형의 올바르게 정렬 된 중간 슬라이스 및 접미사 슬라이스의 세 가지 개별 슬라이스로 분할합니다.
    /// 이 방법은 중간 슬라이스를 주어진 유형 및 입력 슬라이스에 대해 가능한 최대 길이로 만들 수 있지만 알고리즘의 성능 만이 정확성이 아니라 그것에 의존해야합니다.
    ///
    /// 모든 입력 데이터가 접두사 또는 접미사 슬라이스로 반환되는 것은 허용됩니다.
    ///
    /// 이 메서드는 입력 요소 `T` 또는 출력 요소 `U` 의 크기가 0 일 때 아무런 용도가 없으며 아무것도 분할하지 않고 원래 슬라이스를 반환합니다.
    ///
    /// # Safety
    ///
    /// 이 메서드는 반환 된 중간 슬라이스의 요소와 관련하여 본질적으로 `transmute` 이므로 `transmute::<T, U>` 와 관련된 모든 일반적인 경고도 여기에 적용됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // 이 함수의 대부분은 지속적으로 평가됩니다.
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST를 특별히 처리합니다. 즉, 전혀 처리하지 마십시오.
            return (self, &mut [], &mut []);
        }

        // 먼저 첫 번째 조각과 두 번째 조각 사이에서 분할 할 지점을 찾습니다.
        // ptr.align_offset 로 쉽게.
        let ptr = self.as_ptr();
        // 안전: 여기서 우리는 U에 대해 정렬 된 포인터를 사용할 것입니다.
        // 나머지 방법.U를 대상으로하는 정렬과 함께&[T]에 대한 포인터를 전달하면됩니다.
        // `crate::ptr::align_offset` 올바르게 정렬되고 유효한 포인터 `ptr` (`self` 에 대한 참조에서 제공됨)와 2의 제곱 크기 (U에 대한 정렬에서 제공되므로)로 호출되어 안전 제약 조건을 충족합니다.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // 이 후에는 `rest` 를 다시 사용할 수 없습니다. 그러면 별칭 `mut_ptr` 가 무효화됩니다!안전: `align_to` 에 대한 설명을 참조하십시오.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// 이 슬라이스의 요소가 정렬되었는지 확인합니다.
    ///
    /// 즉, 각 요소 `a` 및 그 다음 요소 `b` 에 대해 `a <= b` 가 유지되어야합니다.슬라이스가 정확히 0 개 또는 1 개의 요소를 산출하면 `true` 가 반환됩니다.
    ///
    /// `Self::Item` 가 `PartialOrd` 만 있고 `Ord` 가 아닌 경우 위의 정의는 두 개의 연속 항목이 비교할 수없는 경우이 함수가 `false` 를 반환 함을 의미합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// 이 슬라이스의 요소가 주어진 비교 함수를 사용하여 정렬되었는지 확인합니다.
    ///
    /// `PartialOrd::partial_cmp` 를 사용하는 대신이 함수는 주어진 `compare` 함수를 사용하여 두 요소의 순서를 결정합니다.
    /// 그 외에도 [`is_sorted`] 와 동일합니다.자세한 내용은 설명서를 참조하십시오.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// 이 슬라이스의 요소가 지정된 키 추출 기능을 사용하여 정렬되었는지 확인합니다.
    ///
    /// 슬라이스의 요소를 직접 비교하는 대신이 함수는 `f` 에 의해 결정된대로 요소의 키를 비교합니다.
    /// 그 외에도 [`is_sorted`] 와 동일합니다.자세한 내용은 설명서를 참조하십시오.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// 주어진 조건 자 (두 번째 파티션의 첫 번째 요소 인덱스)에 따라 파티션 지점의 인덱스를 반환합니다.
    ///
    /// 슬라이스는 주어진 술어에 따라 분할 된 것으로 간주됩니다.
    /// 이는 술어가 true를 리턴하는 모든 요소가 슬라이스의 시작에 있고 술어가 false를 리턴하는 모든 요소가 끝에 있음을 의미합니다.
    ///
    /// 예를 들어, [7, 15, 3, 5, 4, 12, 6] 는 술어 x % 2!=0으로 분할됩니다 (모든 홀수는 시작에 있고 모두 끝에서 짝수 임).
    ///
    /// 이 슬라이스가 분할되지 않은 경우이 메서드는 일종의 이진 검색을 수행하므로 반환 된 결과는 지정되지 않고 의미가 없습니다.
    ///
    /// [`binary_search`], [`binary_search_by`] 및 [`binary_search_by_key`] 도 참조하십시오.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // 안전: `left < right`, `left <= mid < right`.
            // 따라서 `left` 는 항상 증가하고 `right` 는 항상 감소하며 둘 중 하나가 선택됩니다.두 경우 모두 `left <= right` 가 충족됩니다.따라서 단계에서 `left < right` 가 있으면 다음 단계에서 `left <= right` 가 충족됩니다.
            //
            // 따라서 `left != right` 이면 `0 <= left < right <= len` 를 만족하고이 경우 `0 <= mid < len` 도 만족합니다.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: 우리는 그것들을 같은 길이로 명시 적으로 슬라이스해야합니다
        // 옵티마이 저가 경계 검사를 쉽게 제거 할 수 있도록합니다.
        // 하지만 신뢰할 수 없기 때문에 T: Copy에 대한 명시적인 전문화도 있습니다.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// 빈 조각을 만듭니다.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// 변경 가능한 빈 슬라이스를 만듭니다.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// 현재 슬라이스의 패턴은 `strip_prefix` 및 `strip_suffix` 에서만 사용됩니다.
/// future 지점에서 `core::str::Pattern` (작성 당시 `str` 로 제한됨)를 슬라이스로 일반화하고이 trait 가 대체되거나 폐지되기를 바랍니다.
///
pub trait SlicePattern {
    /// 일치하는 슬라이스의 요소 유형입니다.
    type Item;

    /// 현재 `SlicePattern` 소비자는 슬라이스가 필요합니다.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}