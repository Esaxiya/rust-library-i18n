// rust-memchr에서 가져온 원래 구현입니다.
// 저작권 2015 Andrew Gallant, bluss 및 Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// 잘림을 사용하십시오.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` 에 0 바이트가 포함되어 있으면 `true` 를 반환합니다.
///
/// *Matters Computational* 에서 J. Arndt :
///
/// "아이디어는 각 바이트에서 하나를 뺀 다음 가장 중요한 부분까지 전파 된 바이트를 찾는 것입니다.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` 의 `x` 바이트와 일치하는 첫 번째 인덱스를 반환합니다.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // 작은 조각을위한 빠른 경로
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // 한 번에 두 개의 `usize` 단어를 읽어 단일 바이트 값을 검색합니다.
    //
    // `text` 를 세 부분으로 분할
    // - 정렬되지 않은 초기 부분, 텍스트의 첫 번째 단어 정렬 주소 앞
    // - 본문, 한 번에 두 단어 씩 스캔
    // - 마지막 남은 부분, <2 단어 크기

    // 정렬 된 경계까지 검색
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // 본문 검색
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // 안전: while의 술어는 최소 2 * usize_bytes의 거리를 보장합니다.
        // 오프셋과 슬라이스 끝 사이.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // 일치하는 바이트가 있으면 중단
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // 본문 루프가 중지 된 지점 뒤의 바이트를 찾습니다.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` 의 `x` 바이트와 일치하는 마지막 인덱스를 반환합니다.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // 한 번에 두 개의 `usize` 단어를 읽어 단일 바이트 값을 검색합니다.
    //
    // `text` 를 세 부분으로 나눕니다.
    // - 정렬되지 않은 꼬리, 텍스트에서 마지막 단어 정렬 주소 뒤,
    // - 한 번에 두 단어 씩 스캔하는 본문,
    // - 첫 번째 남은 바이트, <2 워드 크기.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // 접두사와 접미사의 길이를 얻기 위해 이것을 호출합니다.
        // 중간에 우리는 항상 한 번에 두 개의 청크를 처리합니다.
        // 안전: `[u8]` 를 `[usize]` 로 변환하는 것은 `align_to` 에서 처리하는 크기 차이를 제외하고는 안전합니다.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // 텍스트 본문을 검색하고 min_aligned_offset을 교차하지 않는지 확인하십시오.
    // 오프셋은 항상 정렬되므로 `>` 테스트만으로 충분하며 가능한 오버플로를 방지합니다.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // 안전: 오프셋은 len, suffix.len() 에서 시작합니다.
        // min_aligned_offset (prefix.len()) 남은 거리는 최소 2 * chunk_bytes입니다.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // 일치하는 바이트가 있으면 중단합니다.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // 본문 루프가 중지 된 지점 이전의 바이트를 찾습니다.
    text[..offset].iter().rposition(|elt| *elt == x)
}