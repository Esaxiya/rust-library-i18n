//! 슬라이스 정렬
//!
//! 이 모듈에는 Orson Peters의 패턴 파괴 퀵 정렬 기반 정렬 알고리즘이 포함되어 있습니다. <https://github.com/orlp/pdqsort>
//!
//!
//! 불안정한 정렬은 안정적인 정렬 구현과 달리 메모리를 할당하지 않기 때문에 libcore와 호환됩니다.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// 드롭하면 `src` 에서 `dest` 로 복사됩니다.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // 안전: 이것은 도우미 클래스입니다.
        //          정확성을 위해 사용법을 참조하십시오.
        //          즉, `ptr::copy_nonoverlapping` 에서 요구하는대로 `src` 와 `dst` 가 겹치지 않도록해야합니다.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// 더 크거나 같은 요소를 만날 때까지 첫 번째 요소를 오른쪽으로 이동합니다.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // 안전: 아래의 안전하지 않은 작업에는 바운드 검사 (`get_unchecked` 및 `get_unchecked_mut`)없이 인덱싱이 포함됩니다.
    // 및 메모리 (`ptr::copy_nonoverlapping`) 복사.
    //
    // ㅏ.인덱싱 :
    //  1. 배열의 크기를>=2로 확인했습니다.
    //  2. 우리가 할 모든 인덱싱은 항상 기껏해야 {0 <= index < len} 사이입니다.
    //
    // 비.메모리 복사
    //  1. 우리는 유효하다고 보장되는 참조에 대한 포인터를 얻고 있습니다.
    //  2. 슬라이스의 차이 인덱스에 대한 포인터를 얻으므로 중첩 될 수 없습니다.
    //     즉, `i` 및 `i-1` 입니다.
    //  3. 슬라이스가 제대로 정렬되면 요소가 올바르게 정렬됩니다.
    //     슬라이스가 제대로 정렬되었는지 확인하는 것은 호출자의 책임입니다.
    //
    // 자세한 내용은 아래 설명을 참조하십시오.
    unsafe {
        // 처음 두 요소가 순서가 맞지 않으면 ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // 첫 번째 요소를 스택 할당 변수로 읽습니다.
            // 다음 비교 작업 panics 이면 `hole` 가 삭제되고 자동으로 요소를 슬라이스에 다시 씁니다.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // 'i'번째 요소를 왼쪽으로 한 단계 이동하여 구멍을 오른쪽으로 이동합니다.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` 삭제되어 `tmp` 를 `v` 의 나머지 구멍에 복사합니다.
        }
    }
}

/// 더 작거나 같은 요소를 만날 때까지 마지막 요소를 왼쪽으로 이동합니다.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // 안전: 아래의 안전하지 않은 작업에는 바운드 검사 (`get_unchecked` 및 `get_unchecked_mut`)없이 인덱싱이 포함됩니다.
    // 및 메모리 (`ptr::copy_nonoverlapping`) 복사.
    //
    // ㅏ.인덱싱 :
    //  1. 배열의 크기를>=2로 확인했습니다.
    //  2. 우리가 할 모든 인덱싱은 항상 기껏해야 `0 <= index < len-1` 사이입니다.
    //
    // 비.메모리 복사
    //  1. 우리는 유효하다고 보장되는 참조에 대한 포인터를 얻고 있습니다.
    //  2. 슬라이스의 차이 인덱스에 대한 포인터를 얻으므로 중첩 될 수 없습니다.
    //     즉, `i` 및 `i+1` 입니다.
    //  3. 슬라이스가 제대로 정렬되면 요소가 올바르게 정렬됩니다.
    //     슬라이스가 제대로 정렬되었는지 확인하는 것은 호출자의 책임입니다.
    //
    // 자세한 내용은 아래 설명을 참조하십시오.
    unsafe {
        // 마지막 두 요소가 순서가 맞지 않으면 ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // 마지막 요소를 스택 할당 변수로 읽습니다.
            // 다음 비교 작업 panics 이면 `hole` 가 삭제되고 자동으로 요소를 슬라이스에 다시 씁니다.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // 'i'번째 요소를 오른쪽으로 한 단계 이동하여 구멍을 왼쪽으로 이동합니다.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` 삭제되어 `tmp` 를 `v` 의 나머지 구멍에 복사합니다.
        }
    }
}

/// 순서가 맞지 않는 여러 요소를 주변으로 이동하여 슬라이스를 부분적으로 정렬합니다.
///
/// 슬라이스가 끝에 정렬되면 `true` 를 반환합니다.이 함수는 *O*(*n*) 최악의 경우입니다.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // 이동 될 인접 비 순차 쌍의 최대 수입니다.
    const MAX_STEPS: usize = 5;
    // 슬라이스가 이보다 짧으면 요소를 이동하지 마십시오.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // 안전: 우리는 이미 `i < len` 로 바운드 검사를 명시 적으로 수행했습니다.
        // 이후의 모든 인덱싱은 `0 <= index < len` 범위에만 있습니다.
        unsafe {
            // 인접한 비 순차 요소의 다음 쌍을 찾습니다.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // 끝났어?
        if i == len {
            return true;
        }

        // 성능 비용이있는 짧은 배열에서 요소를 이동하지 마십시오.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // 찾은 요소 쌍을 바꿉니다.이렇게하면 올바른 순서로 배치됩니다.
        v.swap(i - 1, i);

        // 작은 요소를 왼쪽으로 이동합니다.
        shift_tail(&mut v[..i], is_less);
        // 큰 요소를 오른쪽으로 이동합니다.
        shift_head(&mut v[i..], is_less);
    }

    // 제한된 수의 단계에서 슬라이스를 정렬하지 못했습니다.
    false
}

/// 삽입 정렬 (*O*(*n*^ 2) 최악의 경우)을 사용하여 슬라이스를 정렬합니다.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// *O*(*n*\*log(* n*)) 최악의 경우를 보장하는 힙 정렬을 사용하여 `v` 를 정렬합니다.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // 이 바이너리 힙은 불변 `parent >= child` 를 따릅니다.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` 의 하위 :
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // 더 큰 아이를 선택하십시오.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // 불변이 `node` 에서 유지되면 중지하십시오.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` 를 더 큰 아이와 바꾸고 한 단계 아래로 이동 한 다음 계속 체로 치십시오.
            v.swap(node, greater);
            node = greater;
        }
    };

    // 선형 시간에 힙을 빌드하십시오.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // 힙에서 최대 요소를 팝합니다.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` 를 `pivot` 보다 작은 요소와 `pivot` 보다 크거나 같은 요소로 분할합니다.
///
///
/// `pivot` 보다 작은 요소 수를 반환합니다.
///
/// 분할 작업은 분기 작업 비용을 최소화하기 위해 블록 단위로 수행됩니다.
/// 이 아이디어는 [BlockQuicksort][pdf] 문서에 나와 있습니다.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // 일반적인 블록의 요소 수.
    const BLOCK: usize = 128;

    // 파티셔닝 알고리즘은 완료 될 때까지 다음 단계를 반복합니다.
    //
    // 1. 왼쪽에서 블록을 추적하여 피벗보다 크거나 같은 요소를 식별합니다.
    // 2. 오른쪽에서 블록을 추적하여 피벗보다 작은 요소를 식별합니다.
    // 3. 식별 된 요소를 왼쪽과 오른쪽 사이에서 교환하십시오.
    //
    // 요소 블록에 대해 다음 변수를 유지합니다.
    //
    // 1. `block` - 블록의 요소 수.
    // 2. `start` - `offsets` 배열에 대한 포인터를 시작합니다.
    // 3. `end` - `offsets` 배열에 대한 끝 포인터.
    // 4. `오프셋, 블록 내 비 순차적 요소의 인덱스.

    // 왼쪽의 현재 블록 (`l` 에서 `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // 오른쪽의 현재 블록 (`r.sub(block_r)` to `r`).
    // 안전: .add() 설명서에는 `vec.as_ptr().add(vec.len())` 가 항상 안전하다고 명시되어 있습니다.
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: VLA를 얻을 때 길이가 `min(v.len(), 2 * BLOCK)`인 하나의 배열을 만들어보십시오.
    // 길이가 `BLOCK` 인 두 개의 고정 크기 배열보다.VLA는 캐시 효율성이 더 높을 수 있습니다.

    // 포인터 `l` (inclusive) 와 `r` (exclusive) 사이의 요소 수를 반환합니다.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` 와 `r` 가 매우 가까워지면 블록 단위로 파티션을 나눕니다.
        // 그런 다음 나머지 요소를 그 사이에 분할하기 위해 패치 업 작업을 수행합니다.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // 나머지 요소의 수 (여전히 피벗과 비교되지 않음)
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // 왼쪽과 오른쪽 블록이 겹치지 않도록 블록 크기를 조정하고 나머지 간격 전체를 덮도록 완벽하게 정렬합니다.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // 왼쪽에서 `block_l` 요소를 추적합니다.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // 안전: 아래의 안전하지 않은 작업에는 `offset` 사용이 포함됩니다.
                //         함수에 필요한 조건에 따라 다음과 같은 이유로 만족합니다.
                //         1. `offsets_l` 스택 할당되므로 별도의 할당 된 개체로 간주됩니다.
                //         2. `is_less` 함수는 `bool` 를 반환합니다.
                //            `bool` 를 캐스팅하면 `isize` 가 오버플로되지 않습니다.
                //         3. 우리는 `block_l` 가 `<= BLOCK` 가 될 것이라고 보장했습니다.
                //            또한 `end_l` 는 처음에 스택에 선언 된 `offsets_` 의 시작 포인터로 설정되었습니다.
                //            따라서 최악의 경우 (`is_less` 의 모든 호출이 false를 반환 함)에서도 끝까지 최대 1 바이트 만 전달된다는 것을 알고 있습니다.
                //        여기서 또 다른 안전하지 않은 작업은 `elem` 를 참조 해제하는 것입니다.
                //        그러나 `elem` 는 처음에는 항상 유효한 슬라이스에 대한 시작 포인터였습니다.
                unsafe {
                    // 분기없는 비교.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // 오른쪽에서 `block_r` 요소를 추적합니다.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // 안전: 아래의 안전하지 않은 작업에는 `offset` 사용이 포함됩니다.
                //         함수에 필요한 조건에 따라 다음과 같은 이유로 만족합니다.
                //         1. `offsets_r` 스택 할당되므로 별도의 할당 된 개체로 간주됩니다.
                //         2. `is_less` 함수는 `bool` 를 반환합니다.
                //            `bool` 를 캐스팅하면 `isize` 가 오버플로되지 않습니다.
                //         3. 우리는 `block_r` 가 `<= BLOCK` 가 될 것이라고 보장했습니다.
                //            또한 `end_r` 는 처음에 스택에 선언 된 `offsets_` 의 시작 포인터로 설정되었습니다.
                //            따라서 최악의 경우 (`is_less` 의 모든 호출이 true를 반환 함)에서도 끝까지 최대 1 바이트 만 전달된다는 것을 알고 있습니다.
                //        여기서 또 다른 안전하지 않은 작업은 `elem` 를 참조 해제하는 것입니다.
                //        그러나 `elem` 는 처음에는 `1 *sizeof(T)` 끝을 지나서 액세스하기 전에 `1* sizeof(T)` 만큼 감소시킵니다.
                //        또한 `block_r` 는 `BLOCK` 보다 작다고 주장되었으므로 `elem` 는 기껏해야 슬라이스의 시작 부분을 가리 킵니다.
                unsafe {
                    // 분기없는 비교.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // 왼쪽과 오른쪽 사이에서 교체 할 순서가 잘못된 요소의 수입니다.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // 한 번에 한 쌍을 바꾸는 대신 순환 순열을 수행하는 것이 더 효율적입니다.
            // 이것은 스와핑과 완전히 동일하지는 않지만 더 적은 메모리 작업을 사용하여 유사한 결과를 생성합니다.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // 왼쪽 블록의 모든 비 순차 요소가 이동되었습니다.다음 블록으로 이동합니다.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // 오른쪽 블록의 모든 비 순차 요소가 이동되었습니다.이전 블록으로 이동합니다.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // 이제 남은 것은 이동해야하는 순서가 잘못된 요소가있는 최대 하나의 블록 (왼쪽 또는 오른쪽)입니다.
    // 이러한 나머지 요소는 단순히 블록 내에서 끝으로 이동할 수 있습니다.
    //

    if start_l < end_l {
        // 왼쪽 블록이 남아 있습니다.
        // 순서가 맞지 않는 나머지 요소를 맨 오른쪽으로 이동합니다.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // 오른쪽 블록이 남아 있습니다.
        // 나머지 비 순차 요소를 맨 왼쪽으로 이동합니다.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // 다른 할 일이 없습니다.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` 를 `v[pivot]` 보다 작은 요소와 `v[pivot]` 보다 크거나 같은 요소로 분할합니다.
///
///
/// 다음의 튜플을 반환합니다.
///
/// 1. `v[pivot]` 보다 작은 요소 수.
/// 2. `v` 가 이미 분할 된 경우 참입니다.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // 슬라이스 시작 부분에 피벗을 놓습니다.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // 효율성을 위해 피벗을 스택 할당 변수로 읽습니다.
        // 다음 비교 작업 panics 이면 피벗이 자동으로 슬라이스에 다시 기록됩니다.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // 순서가 잘못된 요소의 첫 번째 쌍을 찾습니다.
        let mut l = 0;
        let mut r = v.len();

        // 안전: 아래의 안전하지 않은 점은 배열 인덱싱과 관련이 있습니다.
        // 첫 번째: 우리는 이미 `l < r` 로 경계 검사를 수행합니다.
        // 두 번째: 처음에는 `l == 0` 및 `r == v.len()` 가 있고 모든 인덱싱 작업에서 `l < r` 를 확인했습니다.
        //                     여기서 우리는 `r` 가 첫 번째부터 유효한 것으로 표시된 `r == l` 이상이어야 함을 알고 있습니다.
        unsafe {
            // 피벗보다 크거나 같은 첫 번째 요소를 찾습니다.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // 피벗보다 작은 마지막 요소를 찾으십시오.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` 범위를 벗어나 원래 있던 슬라이스에 피벗 (스택 할당 변수)을 다시 씁니다.
        // 이 단계는 안전을 보장하는 데 매우 중요합니다!
        //
    };

    // 두 파티션 사이에 피벗을 배치합니다.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` 를 `v[pivot]` 와 동일한 요소와 `v[pivot]` 보다 큰 요소로 분할합니다.
///
/// 피벗과 같은 요소 수를 반환합니다.
/// `v` 에는 피벗보다 작은 요소가 포함되어 있지 않다고 가정합니다.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // 슬라이스 시작 부분에 피벗을 놓습니다.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // 효율성을 위해 피벗을 스택 할당 변수로 읽습니다.
    // 다음 비교 작업 panics 이면 피벗이 자동으로 슬라이스에 다시 기록됩니다.
    // 안전: 여기서 포인터는 슬라이스에 대한 참조에서 가져 오기 때문에 유효합니다.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // 이제 슬라이스를 분할합니다.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // 안전: 아래의 안전하지 않은 점은 배열 인덱싱과 관련이 있습니다.
        // 첫 번째: 우리는 이미 `l < r` 로 경계 검사를 수행합니다.
        // 두 번째: 처음에는 `l == 0` 및 `r == v.len()` 가 있고 모든 인덱싱 작업에서 `l < r` 를 확인했습니다.
        //                     여기서 우리는 `r` 가 첫 번째부터 유효한 것으로 표시된 `r == l` 이상이어야 함을 알고 있습니다.
        unsafe {
            // 피벗보다 큰 첫 번째 요소를 찾으십시오.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // 피벗과 같은 마지막 요소를 찾으십시오.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // 끝났어?
            if l >= r {
                break;
            }

            // 발견 된 순서가 잘못된 요소 쌍을 바꿉니다.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // 우리는 `l` 요소가 피벗과 같은 것을 발견했습니다.피벗 자체에 대해 1을 더합니다.
    l + 1

    // `_pivot_guard` 범위를 벗어나 원래 있던 슬라이스에 피벗 (스택 할당 변수)을 다시 씁니다.
    // 이 단계는 안전을 보장하는 데 매우 중요합니다!
}

/// Quicksort에서 불균형 파티션을 유발할 수있는 패턴을 깨기 위해 일부 요소를 분산시킵니다.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George Marsaglia가 작성한 "Xorshift RNGs" 논문의 의사 난수 생성기.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // 이 숫자를 모듈로 난수를 취하십시오.
        // `len` 가 `isize::MAX` 보다 크지 않기 때문에 숫자는 `usize` 에 맞습니다.
        let modulus = len.next_power_of_two();

        // 일부 피벗 후보는이 색인 근처에 있습니다.무작위로 봅시다.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // `len` 모듈로 난수를 생성합니다.
            // 그러나 비용이 많이 드는 작업을 피하기 위해 먼저 모듈로 2의 제곱을 취한 다음 `[0, len - 1]` 범위에 맞을 때까지 `len` 만큼 감소시킵니다.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` 미만이어야합니다.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` 에서 피벗을 선택하고 슬라이스가 이미 정렬되었을 가능성이있는 경우 인덱스 및 `true` 를 반환합니다.
///
/// `v` 의 요소는 프로세스에서 재정렬 될 수 있습니다.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // 중앙값 방법을 선택할 수있는 최소 길이입니다.
    // 더 짧은 슬라이스는 간단한 3 중위수 방법을 사용합니다.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // 이 기능에서 수행 할 수있는 최대 스왑 수입니다.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // 피벗을 선택할 세 가지 인덱스입니다.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // 인덱스를 정렬하는 동안 수행하려는 총 스왑 수를 계산합니다.
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` 가되도록 인덱스를 스왑합니다.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` 가되도록 인덱스를 스왑합니다.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` 의 중앙값을 찾고 인덱스를 `a` 에 저장합니다.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` 및 `c` 주변에서 중앙값을 찾습니다.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` 및 `c` 중 중앙값을 찾으십시오.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // 최대 스왑 횟수가 수행되었습니다.
        // 슬라이스가 내림차순이거나 대부분 내림차순이므로 반전하면 더 빨리 정렬하는 데 도움이 될 수 있습니다.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` 를 재귀 적으로 정렬합니다.
///
/// 슬라이스에 원래 배열의 선행 작업이있는 경우 `pred` 로 지정됩니다.
///
/// `limit` `heapsort` 로 전환하기 전에 허용 된 불균형 파티션의 수입니다.
/// 0이면이 함수는 즉시 힙 정렬로 전환됩니다.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // 이 길이까지의 조각은 삽입 정렬을 사용하여 정렬됩니다.
    const MAX_INSERTION: usize = 20;

    // 마지막 파티셔닝이 적절하게 균형 잡힌 경우 참입니다.
    let mut was_balanced = true;
    // 마지막 분할이 요소를 섞지 않은 경우 (슬라이스가 이미 분할 된 경우) 참입니다.
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // 매우 짧은 슬라이스는 삽입 정렬을 사용하여 정렬됩니다.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // 잘못된 피벗 선택이 너무 많으면 `O(n * log(n))` 최악의 경우를 보장하기 위해 힙 정렬로 돌아가십시오.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // 마지막 파티셔닝이 불균형 한 경우 일부 요소를 섞어 슬라이스의 패턴을 분리 해보십시오.
        // 이번에는 더 나은 피벗을 선택하기를 바랍니다.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // 피벗을 선택하고 슬라이스가 이미 정렬되었는지 추측 해보십시오.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // 마지막 분할이 적절하게 균형을 이루고 요소를 섞지 않았고 피벗 선택에서 슬라이스가 이미 정렬되었을 가능성이 있다고 예측하면 ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // 순서가 맞지 않는 여러 요소를 식별하고 올바른 위치로 이동해보십시오.
            // 슬라이스가 완전히 정렬되면 완료된 것입니다.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // 선택한 피벗이 전임자와 같으면 슬라이스에서 가장 작은 요소입니다.
        // 슬라이스를 피벗보다 큰 요소와 같은 요소로 분할합니다.
        // 이 경우는 일반적으로 슬라이스에 중복 요소가 많이 포함되어있을 때 발생합니다.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // 피벗보다 큰 요소를 계속 정렬합니다.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // 슬라이스를 분할합니다.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // 슬라이스를 `left`, `pivot` 및 `right` 로 분할합니다.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // 총 재귀 호출 수를 최소화하고 스택 공간을 더 적게 소비하기 위해 더 짧은면으로 만 재귀합니다.
        // 그런 다음 더 긴 쪽을 계속하십시오 (이것은 꼬리 재귀와 유사합니다).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*)) 최악의 경우) 패턴을 무시하는 빠른 정렬을 사용하여 `v` 를 정렬합니다.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // 정렬은 크기가 0 인 유형에서 의미있는 동작이 없습니다.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // 불균형 파티션 수를 `floor(log2(len)) + 1` 로 제한하십시오.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // 이 길이까지의 조각은 단순히 정렬하는 것이 더 빠를 것입니다.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // 피벗 선택
        let (pivot, _) = choose_pivot(v, is_less);

        // 선택한 피벗이 전임자와 같으면 슬라이스에서 가장 작은 요소입니다.
        // 슬라이스를 피벗보다 큰 요소와 같은 요소로 분할합니다.
        // 이 경우는 일반적으로 슬라이스에 중복 요소가 많이 포함되어있을 때 발생합니다.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // 우리가 우리의 지수를 통과했다면 우리는 좋은 것입니다.
                if mid > index {
                    return;
                }

                // 그렇지 않으면 피벗보다 큰 요소를 계속 정렬합니다.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // 슬라이스를 `left`, `pivot` 및 `right` 로 분할합니다.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // mid==index이면 partition() 가 mid 이후의 모든 요소가 mid 이상임을 보장하므로 완료된 것입니다.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // 정렬은 크기가 0 인 유형에서 의미있는 동작이 없습니다.아무것도하지 마세요.
    } else if index == v.len() - 1 {
        // 최대 요소를 찾아 배열의 마지막 위치에 배치합니다.
        // v가 비어 있으면 안된다는 것을 알고 있기 때문에 여기서 `unwrap()` 를 자유롭게 사용할 수 있습니다.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // 최소 요소를 찾아 배열의 첫 번째 위치에 배치합니다.
        // v가 비어 있으면 안된다는 것을 알고 있기 때문에 여기서 `unwrap()` 를 자유롭게 사용할 수 있습니다.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}