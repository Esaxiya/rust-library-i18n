//! 슬라이스 반복기에서 사용하는 매크로입니다.

// is_empty와 len을 인라인하면 성능이 크게 달라집니다.
macro_rules! is_empty {
    // ZST 반복기의 길이를 인코딩하는 방식은 ZST 및 비 ZST 모두에서 작동합니다.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// 일부 경계 검사 (`position` 참조)를 제거하기 위해 다소 예상치 못한 방식으로 길이를 계산합니다.
// (`codegen/slice-position-bounds-check`에 의해 테스트되었습니다.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // 우리는 때때로 안전하지 않은 블록 내에서 사용됩니다.

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // 이 _cannot_ 는 긴 ZST 슬라이스 반복자의 길이를 나타 내기 위해 래핑에 의존하기 때문에 `unchecked_sub` 를 사용합니다.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // 우리는 `start <= end` 가 서명이 필요한 `offset_from` 보다 더 잘할 수 있다는 것을 알고 있습니다.
            // 여기에 적절한 플래그를 설정하여 LLVM에이를 알려 경계 검사를 제거 할 수 있습니다.
            // 안전: 불변 유형에 따라 `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // 또한 LLVM에 포인터가 유형 크기의 정확한 배수만큼 떨어져 있음을 알려줌으로써 `len() == 0` 를 `(end - start) < size` 대신 `start == end` 로 최적화 할 수 있습니다.
            //
            // 안전: 불변 유형에 따라 포인터가 정렬되어
            //         그들 사이의 거리는 뾰족한 크기의 배수 여야합니다.
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` 및 `IterMut` 반복자의 공유 정의
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // 첫 번째 요소를 반환하고 반복기의 시작을 1 앞으로 이동합니다.
        // 인라인 함수에 비해 성능이 크게 향상됩니다.
        // 반복자는 비워 둘 수 없습니다.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // 마지막 요소를 반환하고 반복기의 끝을 1만큼 뒤로 이동합니다.
        // 인라인 함수에 비해 성능이 크게 향상됩니다.
        // 반복자는 비워 둘 수 없습니다.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // 반복기의 끝을 `n` 뒤로 이동하여 T가 ZST 일 때 반복기를 축소합니다.
        // `n` `self.len()` 를 초과하지 않아야합니다.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // 반복기에서 슬라이스를 만들기위한 도우미 함수입니다.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // 안전: 포인터가있는 슬라이스에서 반복기가 생성되었습니다.
                // `self.ptr` 길이 `len!(self)`.
                // 이를 통해 `from_raw_parts` 의 모든 전제 조건이 충족됩니다.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // 반복자의 시작을 `offset` 요소에 의해 앞으로 이동하여 이전 시작을 반환하는 도우미 함수입니다.
            //
            // 오프셋이 `self.len()` 를 초과하지 않아야하므로 안전하지 않습니다.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // 안전: 발신자는 `offset` 가 `self.len()` 를 초과하지 않도록 보장합니다.
                    // 따라서이 새 포인터는 `self` 내부에 있으므로 null이 아닙니다.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // 반복기의 끝을 `offset` 요소로 뒤로 이동하여 새 끝을 반환하는 도우미 함수입니다.
            //
            // 오프셋이 `self.len()` 를 초과하지 않아야하므로 안전하지 않습니다.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // 안전: 발신자는 `offset` 가 `self.len()` 를 초과하지 않도록 보장합니다.
                    // `isize` 를 오버플로하지 않는 것이 보장됩니다.
                    // 또한 결과 포인터는 `offset` 에 대한 다른 요구 사항을 충족하는 `slice` 범위 내에 있습니다.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // 슬라이스로 구현할 수 있지만 이것은 경계 검사를 피합니다.

                // 안전: 슬라이스의 시작 포인터이므로 `assume` 호출은 안전합니다.
                // Null이 아니어야하며 ZST가 아닌 슬라이스에도 Null이 아닌 끝 포인터가 있어야합니다.
                // `next_unchecked!` 에 대한 호출은 이터레이터가 먼저 비어 있는지 확인하기 때문에 안전합니다.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // 이 반복기는 이제 비어 있습니다.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` 는 절대 0이 될 수 없지만 `end` 는 (래핑으로 인해) 될 수 있기 때문에 이렇게해야합니다.
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // 안전: ptr이 0이 아니고 end>=ptr이기 때문에 T가 ZST가 아니면 end는 0이 될 수 없습니다.
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // 안전: 우리는 경계에 있습니다.`post_inc_start` 는 ZST에서도 올바른 일을합니다.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // 이 간단한 구현은 LLVM IR을 적게 생성하고 컴파일 속도가 더 빠르기 때문에 `try_fold` 를 사용하는 기본 구현을 재정의합니다.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // 이 간단한 구현은 LLVM IR을 적게 생성하고 컴파일 속도가 더 빠르기 때문에 `try_fold` 를 사용하는 기본 구현을 재정의합니다.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // 이 간단한 구현은 LLVM IR을 적게 생성하고 컴파일 속도가 더 빠르기 때문에 `try_fold` 를 사용하는 기본 구현을 재정의합니다.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // 이 간단한 구현은 LLVM IR을 적게 생성하고 컴파일 속도가 더 빠르기 때문에 `try_fold` 를 사용하는 기본 구현을 재정의합니다.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // 이 간단한 구현은 LLVM IR을 적게 생성하고 컴파일 속도가 더 빠르기 때문에 `try_fold` 를 사용하는 기본 구현을 재정의합니다.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // 이 간단한 구현은 LLVM IR을 적게 생성하고 컴파일 속도가 더 빠르기 때문에 `try_fold` 를 사용하는 기본 구현을 재정의합니다.
            // 또한 `assume` 는 경계 검사를 피합니다.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // 안전: 루프 불변에 의해 경계에 있음이 보장됩니다.
                        // `i >= n`, `self.next()` 는 `None` 를 반환하고 루프가 중단됩니다.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // 이 간단한 구현은 LLVM IR을 적게 생성하고 컴파일 속도가 더 빠르기 때문에 `try_fold` 를 사용하는 기본 구현을 재정의합니다.
            // 또한 `assume` 는 경계 검사를 피합니다.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // 안전: `i` 는 `n` 에서 시작하므로 `n` 보다 낮아야합니다.
                        // 그리고 단지 감소하고 있습니다.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // 안전: 호출자는 `i` 가
                // 따라서 `i` 는 `isize` 를 오버플로 할 수 없으며 반환 된 참조는 슬라이스의 요소를 참조하므로 유효하다는 것이 보장됩니다.
                //
                // 또한 호출자는 동일한 인덱스로 다시 호출되지 않으며이 서브 슬라이스에 액세스 할 다른 메서드가 호출되지 않도록 보장하므로 반환 된 참조가 다음과 같은 경우에 변경 가능하도록 유효합니다.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // 슬라이스로 구현할 수 있지만 이것은 경계 검사를 피합니다.

                // 안전: 슬라이스의 시작 포인터가 널이 아니어야하므로 `assume` 호출은 안전합니다.
                // 그리고 ZST가 아닌 슬라이스에도 널이 아닌 끝 포인터가 있어야합니다.
                // `next_back_unchecked!` 에 대한 호출은 이터레이터가 먼저 비어 있는지 확인하기 때문에 안전합니다.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // 이 반복기는 이제 비어 있습니다.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // 안전: 우리는 경계에 있습니다.`pre_dec_end` 는 ZST에서도 올바른 일을합니다.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}