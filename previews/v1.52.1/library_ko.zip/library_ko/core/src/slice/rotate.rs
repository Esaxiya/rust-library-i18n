// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `mid` 의 요소가 첫 번째 요소가되도록 범위 `[mid-left, mid+right)` 를 회전합니다.마찬가지로 범위 `left` 요소를 왼쪽으로 또는 `right` 요소를 오른쪽으로 회전합니다.
///
/// # Safety
///
/// 지정된 범위는 읽기 및 쓰기에 유효해야합니다.
///
/// # Algorithm
///
/// 알고리즘 1은 `left + right` 의 작은 값 또는 큰 `T` 에 사용됩니다.
/// 요소는 `mid - left` 에서 시작하여 `left + right` 모듈로 `right` 단계로 진행하여 한 번에 하나씩 최종 위치로 이동하므로 임시 하나만 필요합니다.
/// 결국 우리는 `mid - left` 에 다시 도착합니다.
/// 그러나 `gcd(left + right, right)` 가 1이 아닌 경우 위 단계는 요소를 건너 뜁니다.
/// 예를 들면 :
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// 다행히도, 완성 된 요소 사이에서 건너 뛴 요소의 수는 항상 동일하므로 시작 위치를 오프셋하고 더 많은 라운드를 수행 할 수 있습니다 (총 라운드 수는 `gcd(left + right, right)` value) 입니다.
///
/// 최종 결과는 모든 요소가 한 번만 마무리된다는 것입니다.
///
/// 알고리즘 2는 `left + right` 가 크지 만 `min(left, right)` 가 스택 버퍼에 맞을만큼 충분히 작은 경우에 사용됩니다.
/// `min(left, right)` 요소는 버퍼에 복사되고 `memmove` 는 다른 요소에 적용되며 버퍼의 요소는 원래 위치의 반대편에있는 구멍으로 다시 이동됩니다.
///
/// 벡터화 할 수있는 알고리즘은 `left + right` 가 충분히 커지면 위의 성능을 능가합니다.
/// 알고리즘 1은 한 번에 여러 라운드를 청킹하고 수행하여 벡터화 할 수 있지만 `left + right` 가 거대해질 때까지 평균적으로 너무 적은 라운드가 있고 단일 라운드의 최악의 경우가 항상 존재합니다.
/// 대신 알고리즘 3은 더 작은 회전 문제가 남을 때까지 `min(left, right)` 요소를 반복적으로 교체합니다.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` 일 때 스와핑은 대신 왼쪽에서 발생합니다.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. 이러한 경우를 확인하지 않으면 아래 알고리즘이 실패 할 수 있습니다.
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks는 랜덤 시프트에 대한 평균 성능이 약 `left + right == 32` 까지 더 낫다는 것을 보여 주지만 최악의 경우 성능은 약 16까지 떨어집니다.
            // 24 명은 중간 지대로 선정되었습니다.
            // `T` 의 크기가 4 개의 'usize'보다 크면이 알고리즘은 다른 알고리즘보다 성능이 뛰어납니다.
            //
            //
            let x = unsafe { mid.sub(left) };
            // 1 라운드 시작
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` 를 계산하여 미리 찾을 수 있지만 gcd를 부작용으로 계산하는 하나의 루프를 수행 한 다음 나머지 청크를 수행하는 것이 더 빠릅니다.
            //
            //
            let mut gcd = right;
            // 벤치 마크에 따르면 임시 파일을 한 번 읽고 거꾸로 복사 한 다음 마지막에 임시로 쓰는 것보다 임시 파일을 완전히 교체하는 것이 더 빠릅니다.
            // 이는 임시 메모리를 교체하거나 교체하는 것이 두 개를 관리 할 필요없이 루프에서 하나의 메모리 주소 만 사용하기 때문일 수 있습니다.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` 를 증분 한 다음 경계를 벗어 났는지 확인하는 대신 `i` 가 다음 증분에서 경계를 벗어날 것인지 확인합니다.
                // 이것은 포인터 또는 `usize` 의 래핑을 방지합니다.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // 1 라운드 종료
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // 이 조건은 `left + right >= 15` 인 경우 여기에 있어야합니다.
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // 더 많은 라운드로 덩어리를 마무리
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` 크기가 0이 아니므로 크기로 나누어도됩니다.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // 알고리즘 2 여기서 `[T; 0]` 는 이것이 T에 대해 적절하게 정렬되도록하는 것입니다.
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // 알고리즘 3이 알고리즘의 마지막 스왑 위치를 찾고이 알고리즘처럼 인접한 청크를 스와핑하는 대신 마지막 청크를 사용하여 스와핑하는 다른 스왑 방법이 있지만이 방법은 여전히 더 빠릅니다.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // 알고리즘 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}