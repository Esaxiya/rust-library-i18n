//! ASCII `[u8]` 에서 작업.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// 이 슬라이스의 모든 바이트가 ASCII 범위 내에 있는지 확인합니다.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// 두 슬라이스가 ASCII 대소 문자를 구분하지 않는 일치인지 확인합니다.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 와 동일하지만 임시를 할당하고 복사하지 않습니다.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// 이 슬라이스를 해당 위치에 해당하는 ASCII 대문자로 변환합니다.
    ///
    /// ASCII 문자 'a'-'z' 는 'A'-'Z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 기존 값을 수정하지 않고 새 대문자 값을 반환하려면 [`to_ascii_uppercase`] 를 사용합니다.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// 이 슬라이스를 해당 위치에 해당하는 ASCII 소문자로 변환합니다.
    ///
    /// ASCII 문자 'A'-'Z' 는 'a'-'z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 기존 값을 수정하지 않고 새 소문자 값을 반환하려면 [`to_ascii_lowercase`] 를 사용합니다.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` 단어의 바이트가 nonascii (>=128)이면 `true` 를 반환합니다.
/// utf8 유효성 검사와 유사한 작업을 수행하는 `../str/mod.rs` 에서 Snarfed.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// 가능한 경우 한 번에 바이트 작업 대신 한 번에 사용 작업을 사용하는 최적화 된 ASCII 테스트.
///
/// 여기서 사용하는 알고리즘은 매우 간단합니다.`s` 가 너무 짧으면 각 바이트를 확인하고 처리합니다.그렇지 않으면:
///
/// - 정렬되지 않은 하중으로 첫 번째 단어를 읽으십시오.
/// - 포인터를 정렬하고 정렬 된로드로 끝날 때까지 후속 단어를 읽으십시오.
/// - 정렬되지 않은로드로 `s` 에서 마지막 `usize` 를 읽습니다.
///
/// 이러한 부하 중 하나가 `contains_nonascii` (above) 가 true를 반환하는 무언가를 생성하면 답이 거짓임을 압니다.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // 한 번에 한 단어 씩 구현에서 아무것도 얻지 못하면 스칼라 루프로 돌아가십시오.
    //
    // 우리는 또한 이상한 edge 케이스이기 때문에 `size_of::<usize>()` 가 `usize` 에 대해 충분하지 않은 아키텍처에 대해서도이 작업을 수행합니다.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // 우리는 항상 정렬되지 않은 첫 번째 단어를 읽습니다. 즉, `align_offset` 가
    // 0이면 정렬 된 읽기에 대해 동일한 값을 다시 읽습니다.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // 안전: 위의 `len < USIZE_SIZE` 를 확인합니다.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // 우리는 이것을 약간 암시 적으로 확인했습니다.
    // `offset_to_aligned` 는 `align_offset` 또는 `USIZE_SIZE` 이며 둘 다 위에서 명시 적으로 확인합니다.
    //
    debug_assert!(offset_to_aligned <= len);

    // 안전: word_ptr은 (적절하게 정렬 된) usize ptr입니다.
    // 슬라이스의 중간 덩어리.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` 루프 종료 검사에 사용되는 `word_ptr` 의 바이트 인덱스입니다.
    let mut byte_pos = offset_to_aligned;

    // 편집증은 정렬되지 않은로드를 수행하려고하기 때문에 정렬에 대해 확인합니다.
    // 실제로 이것은 `align_offset` 의 버그를 제외하고는 불가능합니다.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // 꼬리가 항상 하나의 `usize` 에서 여분의 branch `byte_pos == len` 까지 항상 하나의 `usize` 인지 확인하기 위해 나중에 꼬리 검사에서 수행 할 마지막 정렬 된 단어를 제외하고 마지막으로 정렬 된 단어까지 후속 단어를 읽습니다.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // 읽기가 범위 내에 있는지 확인
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // 그리고 `byte_pos` 에 대한 우리의 가정이 유지됩니다.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // 안전: 우리는 `word_ptr` 가 제대로 정렬되어 있다는 것을 알고 있습니다.
        // `align_offset`), 우리는 `word_ptr` 와 끝 사이에 충분한 바이트가 있다는 것을 알고 있습니다.
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // 안전: 우리는 `byte_pos <= len - USIZE_SIZE` 를 알고 있습니다.
        // 이 `add` 이후, `word_ptr` 는 기껏해야 한 번만 종료됩니다.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // `usize` 가 실제로 하나만 남아 있는지 확인하기위한 온 전성 검사.
    // 이것은 루프 조건에 의해 보장되어야합니다.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // 안전: 이것은 우리가 처음에 확인하는 `len >= USIZE_SIZE` 에 의존합니다.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}