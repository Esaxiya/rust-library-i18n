//! `[T]` 에 대한 비교 traits.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// memcmp를 제공하는 구현을 호출합니다.
    ///
    /// 데이터를 u8 로 해석합니다.
    ///
    /// 같으면 0,보다 작 으면 <0,보다 크면> 0을 반환합니다.
    ///
    // FIXME(#32610): 반환 유형은 c_int 여야합니다.
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) 의 비교를 구현합니다.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) 의 비교를 구현합니다.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// 슬라이스의 PartialEq 전문화를위한 중간 trait
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// 일반 슬라이스 동등성
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// 유형이 허용하는 경우 memcmp를 사용하여 바이트 단위 평등
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // 안전: `self` 및 `other` 는 참조이므로 유효 함을 보장합니다.
        // 위의 두 조각이 동일한 크기로 확인되었습니다.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// 슬라이스의 PartialOrd 전문화를위한 중간 trait
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // 루프 반복 범위로 슬라이스하여 컴파일러에서 바운드 검사 제거를 활성화합니다.
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// 이것이 우리가 갖고 싶은 impl입니다.불행히도 소리가 나지 않습니다.
// `partial_ord_slice.rs` 를 참조하십시오.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// 슬라이스의 Ord 전문화를위한 중간 trait
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // 루프 반복 범위로 슬라이스하여 컴파일러에서 바운드 검사 제거를 활성화합니다.
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp는 부호없는 바이트 시퀀스를 사전 식으로 비교합니다.
// 이것은 우리가 [u8] 에 대해 원하는 순서와 일치하지만 다른 것은 없습니다 ([i8] 조차도).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // 안전: `left` 및 `right` 는 참조이므로 유효 함을 보장합니다.
            // 두 영역이 해당 간격의 읽기에 유효 함을 보장하는 두 길이의 최소값을 사용합니다.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// `Eq` 에 메서드가 있어도 `Eq` 에 특화 할 수 있도록 해킹합니다.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// 바이트 단위 표현을 사용하여 동등성을 비교할 수있는 유형에 대해 구현 된 Trait
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // 안전: `i8` 및 `u8` 는 동일한 메모리 레이아웃을 가지므로 `x.as_ptr()` 를 캐스팅합니다.
        // `*const u8` 는 안전합니다.
        // `x.as_ptr()` 는 참조에서 제공되므로 `isize::MAX` 보다 클 수없는 슬라이스 `x.len()` 의 길이에 대한 읽기에 유효합니다.
        // 반환 된 슬라이스는 변경되지 않습니다.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}