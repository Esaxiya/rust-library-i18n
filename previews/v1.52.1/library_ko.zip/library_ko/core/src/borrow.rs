//! 빌린 데이터 작업을위한 모듈입니다.

#![stable(feature = "rust1", since = "1.0.0")]

/// 데이터 차용을위한 trait.
///
/// Rust 에서는 다양한 사용 사례에 대해 서로 다른 유형의 표현을 제공하는 것이 일반적입니다.
/// 예를 들어, 값에 대한 저장 위치 및 관리는 [`Box<T>`] 또는 [`Rc<T>`] 와 같은 포인터 유형을 통해 특정 용도에 맞게 특별히 선택할 수 있습니다.
/// 모든 유형과 함께 사용할 수있는 이러한 일반 래퍼 외에도 일부 유형은 잠재적으로 비용이 많이 드는 기능을 제공하는 선택적 패싯을 제공합니다.
/// 이러한 유형의 예는 기본 [`str`] 에 문자열을 확장하는 기능을 추가하는 [`String`] 입니다.
/// 이를 위해서는 단순하고 변경 불가능한 문자열에 대해 불필요한 추가 정보를 유지해야합니다.
///
/// 이러한 유형은 해당 데이터 유형에 대한 참조를 통해 기본 데이터에 대한 액세스를 제공합니다.그들은 그 유형으로 '빌려졌다'고합니다.
/// 예를 들어 [`Box<T>`] 는 `T` 로 빌릴 수 있고 [`String`] 는 `str` 로 빌릴 수 있습니다.
///
/// 유형은 `Borrow<T>` 를 구현하여 trait 의 [`borrow`] 메서드에서 `T` 에 대한 참조를 제공하여 일부 유형 `T` 로 빌릴 수 있음을 나타냅니다.한 유형은 여러 유형으로 무료로 빌릴 수 있습니다.
/// 유형으로 변경 가능하게 빌려서 기본 데이터를 수정할 수 있도록하려면 [`BorrowMut<T>`] 를 추가로 구현할 수 있습니다.
///
/// 또한 추가 traits 에 대한 구현을 제공 할 때 해당 기본 유형의 표현으로 작동하는 결과로 기본 유형의 구현과 동일하게 작동해야하는지 여부를 고려해야합니다.
/// 일반 코드는 이러한 추가 trait 구현의 동일한 동작에 의존 할 때 일반적으로 `Borrow<T>` 를 사용합니다.
/// 이러한 traits 는 추가 trait bounds 로 나타날 가능성이 높습니다.
///
/// 특히 `Eq`, `Ord` 및 `Hash` 는 차용 및 소유 값에 대해 동일해야합니다. `x.borrow() == y.borrow()` 는 `x == y` 와 동일한 결과를 제공해야합니다.
///
/// 제네릭 코드가 관련 유형 `T` 에 대한 참조를 제공 할 수있는 모든 유형에 대해 작동해야하는 경우 더 많은 유형이 안전하게 구현할 수 있으므로 [`AsRef<T>`] 를 사용하는 것이 더 좋습니다.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// 데이터 수집으로서 [`HashMap<K, V>`] 는 키와 값을 모두 소유합니다.키의 실제 데이터가 일종의 관리 유형으로 래핑 된 경우 키의 데이터에 대한 참조를 사용하여 값을 검색 할 수 있어야합니다.
/// 예를 들어 키가 문자열 인 경우 해시 맵과 함께 [`String`] 로 저장 될 가능성이 높지만 [`&str`][`str`] 를 사용하여 검색 할 수 있어야합니다.
/// 따라서 `insert` 는 `String` 에서 작동해야하고 `get` 는 `&str` 를 사용할 수 있어야합니다.
///
/// 약간 단순화 된 `HashMap<K, V>` 의 관련 부분은 다음과 같습니다.
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // 필드 생략
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// 전체 해시 맵은 키 유형 `K` 에 대해 일반적입니다.이러한 키는 해시 맵과 함께 저장되므로이 유형은 키의 데이터를 소유해야합니다.
/// 키-값 쌍을 삽입 할 때 맵에 이러한 `K` 가 제공되며 올바른 해시 버킷을 찾고 해당 `K` 를 기반으로 키가 이미 존재하는지 확인해야합니다.따라서 `K: Hash + Eq` 가 필요합니다.
///
/// 그러나 맵에서 값을 검색 할 때 검색 할 키로 `K` 에 대한 참조를 제공하려면 항상 이러한 소유 값을 생성해야합니다.
/// 문자열 키의 경우 `str` 만 사용할 수있는 경우 검색을 위해 `String` 값을 만들어야 함을 의미합니다.
///
/// 대신 `get` 메서드는 위의 메서드 서명에서 `Q` 라고하는 기본 키 데이터 유형에 대해 일반적입니다.`K` 는 `K: Borrow<Q>` 를 요구하여 `Q` 로 차용한다고 말합니다.
/// `Q: Hash + Eq` 를 추가로 요구함으로써 `K` 및 `Q` 가 동일한 결과를 생성하는 `Hash` 및 `Eq` traits 를 구현해야한다는 요구 사항을 나타냅니다.
///
/// `get` 구현은 특히 `K` 값에서 계산 된 해시 값을 기반으로 키를 삽입 했음에도 불구하고 `Q` 값에 대해 `Hash::hash` 를 호출하여 키의 해시 버킷을 결정하여 `Hash` 의 동일한 구현에 의존합니다.
///
///
/// 결과적으로 `Q` 값을 래핑하는 `K` 가 `Q` 와 다른 해시를 생성하면 해시 맵이 손상됩니다.예를 들어 문자열을 감싸지 만 대소 문자를 무시하고 ASCII 문자를 비교하는 유형이 있다고 가정 해보십시오.
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// 두 개의 동일한 값이 동일한 해시 값을 생성해야하기 때문에 `Hash` 구현은 ASCII 대소 문자도 무시해야합니다.
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` 는 `Borrow<str>` 를 구현할 수 있습니까?포함 된 소유 문자열을 통해 문자열 슬라이스에 대한 참조를 확실히 제공 할 수 있습니다.
/// 그러나 `Hash` 구현이 다르기 때문에 `str` 와 다르게 작동하므로 실제로 `Borrow<str>` 를 구현해서는 안됩니다.
/// 다른 사람이 기본 `str` 에 액세스 할 수 있도록 허용하려면 추가 요구 사항이없는 `AsRef<str>` 를 통해이를 수행 할 수 있습니다.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// 소유 한 가치에서 불변 적으로 차입합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// 데이터를 변경하기위한 trait.
///
/// [`Borrow<T>`] 의 동반자로서이 trait 는 가변 참조를 제공하여 유형이 기본 유형으로 차용 할 수 있도록합니다.
/// 다른 유형으로 빌리는 것에 대한 자세한 정보는 [`Borrow<T>`] 를 참조하십시오.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// 소유 한 가치에서 상호 차용합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}