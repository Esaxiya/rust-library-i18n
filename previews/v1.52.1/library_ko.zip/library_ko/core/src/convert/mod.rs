//! 유형 간 변환을위한 Traits.
//!
//! 이 모듈의 traits 는 한 유형에서 다른 유형으로 변환하는 방법을 제공합니다.
//! 각 trait 는 다른 용도로 사용됩니다.
//!
//! - 저렴한 참조-참조 변환을 위해 [`AsRef`] trait 구현
//! - 저렴한 변경 가능-변경 가능 변환을 위해 [`AsMut`] trait 구현
//! - 가치 대 가치 전환을 위해 [`From`] trait 구현
//! - 현재 crate 외부의 유형으로 가치 대 가치 변환을 사용하기 위해 [`Into`] trait 를 구현합니다.
//! - [`TryFrom`] 및 [`TryInto`] traits 는 [`From`] 및 [`Into`] 처럼 작동하지만 변환이 실패 할 수있는 경우 구현해야합니다.
//!
//! 이 모듈의 traits 는 여러 유형의 인수가 지원되는 일반 함수에 대해 trait bounds 로 자주 사용됩니다.예제는 각 trait 의 문서를 참조하십시오.
//!
//! 라이브러리 작성자는 항상 [`Into<U>`][`Into`] 또는 [`TryInto<U>`][`TryInto`] 보다 [`From<T>`][`From`] 또는 [`TryFrom<T>`][`TryFrom`] 를 구현하는 것을 선호해야합니다. [`From`] 및 [`TryFrom`] 는 표준 라이브러리의 포괄적 구현 덕분에 더 큰 유연성을 제공하고 동등한 [`Into`] 또는 [`TryInto`] 구현을 무료로 제공하기 때문입니다.
//! Rust 1.41 이전 버전을 대상으로하는 경우 현재 crate 외부의 유형으로 변환 할 때 [`Into`] 또는 [`TryInto`] 를 직접 구현해야 할 수 있습니다.
//!
//! # 일반 구현
//!
//! - [`AsRef`] 내부 유형이 참조 인 경우 [`AsMut`] 자동 역 참조
//! - T`의 [`From`]` <U>은</u> [`Into`]`<U>를 의미합니다.</u><T><U>U` 용</u>
//! - T`의 [`TryFrom`]` <U>은</u> [`TryInto`]`<U>를 의미합니다.</u><T><U>U` 용</u>
//! - [`From`] [`Into`] 는 반사적이므로 모든 유형이 `into` 자체 및 `from` 자체를
//!
//! 사용 예는 각 trait 를 참조하십시오.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// 정체성 기능.
///
/// 이 기능에 대해 유의해야 할 두 가지 사항이 있습니다.
///
/// - 클로저가 `x` 를 다른 유형으로 강제 할 수 있기 때문에 항상 `|x| x` 와 같은 클로저와 동일하지는 않습니다.
///
/// - 함수에 전달 된 입력 `x` 를 이동합니다.
///
/// 입력을 반환하는 함수가있는 것이 이상하게 보일 수 있지만 몇 가지 흥미로운 용도가 있습니다.
///
///
/// # Examples
///
/// `identity` 를 사용하여 다른 흥미로운 기능 시퀀스에서 아무것도하지 않습니다.
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // 하나를 추가하는 것이 흥미로운 기능이라고 가정 해 봅시다.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// 조건부에서 `identity` 를 "do nothing" 기본 케이스로 사용 :
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // 더 흥미로운 일을하세요 ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` 를 사용하여 `Option<T>` 반복기의 `Some` 변형 유지 :
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// 저렴한 참조-참조 변환을 수행하는 데 사용됩니다.
///
/// 이 trait 는 가변 참조 간 변환에 사용되는 [`AsMut`] 와 유사합니다.
/// 비용이 많이 드는 변환을 수행해야하는 경우 `&T` 유형으로 [`From`] 를 구현하거나 사용자 정의 함수를 작성하는 것이 좋습니다.
///
/// `AsRef` [`Borrow`] 와 동일한 서명을 갖지만 [`Borrow`] 는 몇 가지 측면에서 다릅니다.
///
/// - `AsRef` 와 달리 [`Borrow`] 에는 `T` 에 대한 블랭킷 impl이 있으며 참조 또는 값을 수락하는 데 사용할 수 있습니다.
/// - [`Borrow`] 또한 차용 가치에 대한 [`Hash`], [`Eq`] 및 [`Ord`] 가 소유 가치와 동일해야합니다.
/// 이러한 이유로 구조체의 단일 필드 만 빌리려면 [`Borrow`] 가 아닌 `AsRef` 를 구현할 수 있습니다.
///
/// **Note: 이 trait 는 실패하지 않아야합니다 **.변환이 실패 할 경우 [`Option<T>`] 또는 [`Result<T, E>`] 를 반환하는 전용 메서드를 사용하십시오.
///
/// # 일반 구현
///
/// - `AsRef` 내부 유형이 참조 또는 변경 가능한 참조 인 경우 자동 역 참조 (예 : `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds 를 사용하여 지정된 유형 `T` 로 변환 할 수있는 한 다른 유형의 인수를 허용 할 수 있습니다.
///
/// 예: `AsRef<str>` 를받는 일반 함수를 생성함으로써 우리는 [`&str`] 로 변환 될 수있는 모든 참조를 인수로 받아들이기를 원한다고 표현합니다.
/// [`String`] 와 [`&str`] 는 모두 `AsRef<str>` 를 구현하므로 둘 다 입력 인수로 받아 들일 수 있습니다.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// 변환을 수행합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// 저렴한 변경 가능에서 변경 가능한 참조 변환을 수행하는 데 사용됩니다.
///
/// 이 trait 는 [`AsRef`] 와 유사하지만 변경 가능한 참조 간의 변환에 사용됩니다.
/// 비용이 많이 드는 변환을 수행해야하는 경우 `&mut T` 유형으로 [`From`] 를 구현하거나 사용자 정의 함수를 작성하는 것이 좋습니다.
///
/// **Note: 이 trait 는 실패하지 않아야합니다 **.변환이 실패 할 경우 [`Option<T>`] 또는 [`Result<T, E>`] 를 반환하는 전용 메서드를 사용하십시오.
///
/// # 일반 구현
///
/// - `AsMut` 내부 유형이 변경 가능한 참조 인 경우 자동 역 참조 (예 : `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// 일반 함수에 대해 `AsMut` 를 trait bound 로 사용하면 `&mut T` 유형으로 변환 할 수있는 모든 변경 가능한 참조를 받아 들일 수 있습니다.
/// [`Box<T>`] 는 `AsMut<T>` 를 구현하기 때문에 `&mut u64` 로 변환 할 수있는 모든 인수를 취하는 함수 `add_one` 를 작성할 수 있습니다.
/// [`Box<T>`] 는 `AsMut<T>` 를 구현하므로 `add_one` 는 `&mut Box<u64>` 유형의 인수도 허용합니다.
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// 변환을 수행합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// 입력 값을 사용하는 가치 대 가치 변환입니다.[`From`] 의 반대입니다.
///
/// [`Into`] 구현을 피하고 대신 [`From`] 를 구현해야합니다.
/// [`From`] 를 구현하면 표준 라이브러리의 블랭킷 구현 덕분에 [`Into`] 구현이 자동으로 제공됩니다.
///
/// 일반 함수에 trait bounds 를 지정할 때 [`From`] 보다 [`Into`] 를 사용하여 [`Into`] 만 구현하는 유형도 사용할 수 있도록합니다.
///
/// **Note: 이 trait 는 실패하지 않아야합니다 **.변환이 실패하면 [`TryInto`] 를 사용하십시오.
///
/// # 일반 구현
///
/// - [`From`]`<T>U`는 `Into<U> for T` 를 의미합니다.
/// - [`Into`] 반사적이므로 `Into<T> for T` 가 구현됨을 의미합니다.
///
/// # 이전 버전의 Rust 에서 외부 유형으로 변환하기 위해 [`Into`] 구현
///
/// Rust 1.41 이전에는 대상 유형이 현재 crate 의 일부가 아니면 [`From`] 를 직접 구현할 수 없었습니다.
/// 예를 들어 다음 코드를 사용하십시오.
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Rust 의 고아 규칙이 조금 더 엄격했기 때문에 이전 버전의 언어에서는 컴파일되지 않습니다.
/// 이를 우회하기 위해 [`Into`] 를 직접 구현할 수 있습니다.
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] 는 [`From`] 구현을 제공하지 않는다는 것을 이해하는 것이 중요합니다 ([`From`] 가 [`Into`] 에서 제공하는 것처럼).
/// 따라서 항상 [`From`] 를 구현하고 [`From`] 를 구현할 수없는 경우 [`Into`] 로 대체해야합니다.
///
/// # Examples
///
/// [`String`] [`Into`]`<`[`Vec`]`<`[`u8`]`>>`을 구현합니다.
///
/// 일반 함수가 지정된 유형 `T` 로 변환 할 수있는 모든 인수를 취하기를 원한다는 것을 표현하기 위해 [`Into`]`의 trait bound 를 사용할 수 있습니다.<T>`.
///
/// 예: `is_hello` 함수는 [`Vec`]`<`[`u8`]`>`로 변환 할 수있는 모든 인수를 사용합니다.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// 변환을 수행합니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// 입력 값을 소비하면서 가치 대 가치 변환을 수행하는 데 사용됩니다.[`Into`] 의 역수입니다.
///
/// `From` 를 구현하면 표준 라이브러리의 블랭킷 구현 덕분에 [`Into`] 구현이 자동으로 제공되기 때문에 항상 [`Into`] 보다 `From` 구현을 선호해야합니다.
///
///
/// Rust 1.41 이전 버전을 대상으로하고 현재 crate 외부의 유형으로 변환 할 때만 [`Into`] 를 구현하십시오.
/// `From` Rust 의 고아 규칙으로 인해 이전 버전에서는 이러한 유형의 변환을 수행 할 수 없습니다.
/// 자세한 내용은 [`Into`] 를 참조하십시오.
///
/// 일반 함수에서 trait bounds 를 지정할 때 `From` 를 사용하는 것보다 [`Into`] 를 사용하는 것이 좋습니다.
/// 이렇게하면 [`Into`] 를 직접 구현하는 형식도 인수로 사용할 수 있습니다.
///
/// `From` 는 오류 처리를 수행 할 때도 매우 유용합니다.실패 할 수있는 함수를 구성 할 때 반환 유형은 일반적으로 `Result<T, E>` 형식입니다.
/// `From` trait 는 함수가 여러 오류 유형을 캡슐화하는 단일 오류 유형을 반환하도록 허용하여 오류 처리를 단순화합니다.자세한 내용은 "Examples" 섹션 및 [the book][book] 를 참조하십시오.
///
/// **Note: 이 trait 는 실패하지 않아야합니다 **.변환이 실패하면 [`TryFrom`] 를 사용하십시오.
///
/// # 일반 구현
///
/// - `From<T> for U` T`에 <U>대해</u> [`Into`]` <U>를 의미합니다.</u>
/// - `From` 반사적이므로 `From<T> for T` 가 구현됨을 의미합니다.
///
/// # Examples
///
/// [`String`] `From<&str>` 를 구현합니다.
///
/// `&str` 에서 문자열로의 명시 적 변환은 다음과 같이 수행됩니다.
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// 오류 처리를 수행하는 동안 고유 한 오류 유형에 대해 `From` 를 구현하는 것이 유용한 경우가 많습니다.
/// 기본 오류 유형을 기본 오류 유형을 캡슐화하는 자체 사용자 정의 오류 유형으로 변환하여 기본 원인에 대한 정보를 잃지 않고 단일 오류 유형을 반환 할 수 있습니다.
/// '?' 연산자는 `From` 를 구현할 때 자동으로 제공되는 `Into<CliError>::into` 를 호출하여 기본 오류 유형을 사용자 정의 오류 유형으로 자동 변환합니다.
/// 그런 다음 컴파일러는 어떤 `Into` 구현을 사용해야하는지 추론합니다.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// 변환을 수행합니다.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` 를 소비하는 시도 된 변환으로 비용이 많이들 수도 있고 그렇지 않을 수도 있습니다.
///
/// 라이브러리 작성자는 일반적으로이 trait 를 직접 구현해서는 안되지만 표준 라이브러리의 포괄적 구현 덕분에 더 큰 유연성을 제공하고 동등한 `TryInto` 구현을 무료로 제공하는 [`TryFrom`] trait 를 구현하는 것을 선호해야합니다.
/// 이에 대한 자세한 내용은 [`Into`] 설명서를 참조하십시오.
///
/// # `TryInto` 구현
///
/// 이것은 [`Into`] 를 구현하는 것과 동일한 제한 및 추론을 겪습니다. 자세한 내용은 여기를 참조하십시오.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// 변환 오류가 발생한 경우 반환되는 유형입니다.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// 변환을 수행합니다.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// 일부 상황에서 통제 된 방식으로 실패 할 수있는 간단하고 안전한 유형 변환.[`TryInto`] 의 역수입니다.
///
/// 이것은 사소하게 성공할 수 있지만 특별한 처리가 필요할 수도있는 유형 변환을 수행 할 때 유용합니다.
/// 예를 들어 [`From`] trait 를 사용하여 [`i64`] 를 [`i32`] 로 변환 할 수있는 방법이 없습니다. [`i64`] 에는 [`i32`] 가 나타낼 수없는 값이 포함되어있어 변환시 데이터가 손실 될 수 있기 때문입니다.
///
/// 이것은 [`i64`] 를 [`i32`] 로 자르거나 (본질적으로 [`i64`]의 값 모듈로 [`i32::MAX`] 제공) 또는 단순히 [`i32::MAX`] 를 반환하거나 다른 방법으로 처리 할 수 있습니다.
/// [`From`] trait 는 완벽한 변환을위한 것이므로 `TryFrom` trait 는 프로그래머에게 유형 변환이 잘못 될 수 있음을 알리고 처리 방법을 결정할 수 있도록합니다.
///
/// # 일반 구현
///
/// - `TryFrom<T> for U` T`의 경우 [`TryInto`]` <U>를 의미합니다.</u>
/// - [`try_from`] 즉, `TryFrom<T> for T` 가 구현되고 실패 할 수 없음을 의미합니다. `T` 유형의 값에서 `T::try_from()` 를 호출하기위한 관련 `Error` 유형은 [`Infallible`] 입니다.
/// [`!`] 유형이 안정화되면 [`Infallible`] 와 [`!`] 는 동일합니다.
///
/// `TryFrom<T>` 다음과 같이 구현할 수 있습니다.
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// 설명한대로 [`i32`] 는`TryFrom <`[`i64`]`>`을 구현합니다.
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number` 를 자동으로 자르고 사실 이후에 잘림을 감지하고 처리해야합니다.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` 가 너무 커서 `i32` 에 맞지 않기 때문에 오류를 반환합니다.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` 를 반환합니다.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// 변환 오류가 발생한 경우 반환되는 유형입니다.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// 변환을 수행합니다.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// 일반 임플란트
////////////////////////////////////////////////////////////////////////////////

// 리프트 오버&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut 이상의 리프트
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut에 대한 위의 impls를 다음의 더 일반적인 것으로 대체하십시오.
// // Deref를 통해 리프트로
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U :? 크기> <U>D에 대한</u> AsRef <U>{fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut은 &mut 이상으로 들어 올립니다.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut 에 대한 위의 impl을 다음과 같은보다 일반적인 것으로 대체하십시오.
// // AsMut는 DerefMut 위로 들어 올립니다.
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U :? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// From은 Into를 의미합니다.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (따라서 Into)은 반사적입니다.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **안정성 참고 사항:** 이 impl은 아직 존재하지 않지만 future 에 추가 할 "reserving space" 입니다.
/// 자세한 내용은 [rust-lang/rust#64715][#64715] 를 참조하십시오.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): 대신 원칙적으로 수정하십시오.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom은 TryInto를 의미합니다.
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// 무오류 변환은 의미 상 무인 오류 유형의 오류 변환과 동일합니다.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// 콘크리트 임플
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// 오류 없음 오류 유형
////////////////////////////////////////////////////////////////////////////////

/// 발생할 수없는 오류에 대한 오류 유형입니다.
///
/// 이 열거 형에는 변형이 없으므로이 유형의 값은 실제로 존재할 수 없습니다.
/// 이는 [`Result`] 를 사용하고 오류 유형을 매개 변수화하여 결과가 항상 [`Ok`] 임을 나타내는 일반 API에 유용 할 수 있습니다.
///
/// 예를 들어 [`TryFrom`] trait ([`Result`] 를 반환하는 변환)에는 역 [`Into`] 구현이 존재하는 모든 유형에 대한 블랭킷 구현이 있습니다.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future 호환성
///
/// 이 열거 형은이 버전의 Rust 에서 불안정한 [the `!`“never”type][never] 와 동일한 역할을합니다.
/// `!` 가 안정화되면 `Infallible` 를 유형 별칭으로 만들 계획입니다.
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …그리고 결국 `Infallible` 를 더 이상 사용하지 않습니다.
///
/// 그러나 `!` 가 본격적인 유형으로 안정화되기 전에 `!` 구문을 사용할 수있는 경우가 있습니다. 함수의 반환 유형 위치에 있습니다.
/// 특히 두 가지 다른 함수 포인터 유형에 대한 구현이 가능합니다.
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` 가 열거 형이면이 코드가 유효합니다.
/// 그러나 `Infallible` 가 never type 의 별칭이되면 두`impl`이 겹치기 시작하므로 언어의 trait 일관성 규칙에 의해 허용되지 않습니다.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}