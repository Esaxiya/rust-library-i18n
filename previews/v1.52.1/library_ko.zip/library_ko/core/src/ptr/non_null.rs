use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` 그러나 0이 아닌 공변.
///
/// 이것은 종종 원시 포인터를 사용하여 데이터 구조를 빌드 할 때 사용하는 올바른 방법이지만 추가 속성으로 인해 궁극적으로 사용하는 것이 더 위험합니다.`NonNull<T>` 를 사용해야하는지 확실하지 않으면 `*mut T` 를 사용하십시오!
///
/// `*mut T` 와 달리 포인터가 역 참조되지 않더라도 포인터는 항상 널이 아니어야합니다.이는 열거 형이이 금지 된 값을 판별 자로 사용할 수 있도록하기위한 것입니다. `Option<NonNull<T>>` 는 `* mut T` 와 크기가 같습니다.
/// 그러나 포인터가 역 참조되지 않으면 포인터가 계속 매달려있을 수 있습니다.
///
/// `*mut T` 와 달리 `NonNull<T>` 는 `T` 에 대해 공변하도록 선택되었습니다.이렇게하면 공변 유형을 빌드 할 때 `NonNull<T>` 를 사용할 수 있지만 실제로 공변이어서는 안되는 유형에 사용하면 불건전 할 위험이 있습니다.
/// (기술적으로 불건전 함은 안전하지 않은 함수를 호출 할 때만 발생할 수 있음에도 불구하고 `*mut T` 에 대해 반대 선택을했습니다.)
///
/// 공분산은 `Box`, `Rc`, `Arc`, `Vec` 및 `LinkedList` 와 같은 대부분의 안전한 추상화에 적합합니다.이는 Rust 의 일반 공유 XOR 변경 가능 규칙을 따르는 공용 API를 제공하기 때문입니다.
///
/// 유형이 안전하게 공변이 될 수없는 경우 불변성을 제공하기 위해 추가 필드가 포함되어 있는지 확인해야합니다.종종이 필드는 `PhantomData<Cell<T>>` 또는 `PhantomData<&'a mut T>` 와 같은 [`PhantomData`] 유형입니다.
///
/// `NonNull<T>` 에는 `&T` 에 대한 `From` 인스턴스가 있습니다.그러나 이것은 [`UnsafeCell<T>`] 내부에서 돌연변이가 발생하지 않는 한 공유 참조 (a에서 파생 된 포인터)를 통한 돌연변이가 정의되지 않은 동작이라는 사실을 변경하지 않습니다.공유 참조에서 변경 가능한 참조를 만드는 경우에도 마찬가지입니다.
///
/// `UnsafeCell<T>` 없이이 `From` 인스턴스를 사용할 때 `as_mut` 가 호출되지 않고 `as_ptr` 가 변이에 사용되지 않도록하는 것은 사용자의 책임입니다.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` 포인터가 참조하는 데이터가 별칭이 될 수 있으므로 포인터는 `Send` 가 아닙니다.
// NB,이 impl은 불필요하지만 더 나은 오류 메시지를 제공해야합니다.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` 포인터가 참조하는 데이터가 별칭이 될 수 있으므로 포인터는 `Sync` 가 아닙니다.
// NB,이 impl은 불필요하지만 더 나은 오류 메시지를 제공해야합니다.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// 매달려 있지만 잘 정렬 된 새 `NonNull` 를 만듭니다.
    ///
    /// 이것은 `Vec::new` 처럼 느리게 할당되는 유형을 초기화하는 데 유용합니다.
    ///
    /// 포인터 값은 잠재적으로 `T` 에 대한 유효한 포인터를 나타낼 수 있습니다. 이는 "not yet initialized" 센티넬 값으로 사용해서는 안된다는 것을 의미합니다.
    /// 느리게 할당되는 유형은 다른 방법으로 초기화를 추적해야합니다.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // 안전: mem::align_of() 는 0이 아닌 usize를 반환 한 다음 캐스팅됩니다.
        // * mut T에.
        // 따라서 `ptr` 는 null이 아니고 new_unchecked() 를 호출하기위한 조건이 준수됩니다.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// 값에 대한 공유 참조를 반환합니다.[`as_ref`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 변경 가능한 대응 물은 [`as_uninit_mut`] 를 참조하십시오.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 변경되지 않아야합니다 (`UnsafeCell` 내부 제외).
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // 안전: 발신자는 `self` 가 모든
        // 참조를위한 요구 사항.
        unsafe { &*self.cast().as_ptr() }
    }

    /// 값에 대한 고유 한 참조를 반환합니다.[`as_mut`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 공유 상대에 대해서는 [`as_uninit_ref`] 를 참조하십시오.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 다른 포인터를 통해 액세스 (읽기 또는 쓰기)되어서는 안됩니다.
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // 안전: 발신자는 `self` 가 모든
        // 참조를위한 요구 사항.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// 새 `NonNull` 를 만듭니다.
    ///
    /// # Safety
    ///
    /// `ptr` 널이 아니어야합니다.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // 안전: 호출자는 `ptr` 가 널이 아님을 보장해야합니다.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` 가 널이 아닌 경우 새 `NonNull` 를 작성합니다.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // 안전: 포인터가 이미 확인되었으며 null이 아닙니다.
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// 원시 `*const` 포인터와 반대로 `NonNull` 포인터가 반환된다는 점을 제외하면 [`std::ptr::from_raw_parts`] 와 동일한 기능을 수행합니다.
    ///
    ///
    /// 자세한 내용은 [`std::ptr::from_raw_parts`] 문서를 참조하십시오.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // 안전: `data_address` 가 있기 때문에 `ptr::from::raw_parts_mut` 의 결과는 널이 아닙니다.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// (넓은) 포인터를 주소 및 메타 데이터 구성 요소로 분해합니다.
    ///
    /// 포인터는 나중에 [`NonNull::from_raw_parts`] 로 재구성 할 수 있습니다.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// 기본 `*mut` 포인터를 획득합니다.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// 값에 대한 공유 참조를 반환합니다.값이 초기화되지 않은 경우 [`as_uninit_ref`] 를 대신 사용해야합니다.
    ///
    /// 변경 가능한 대응 물은 [`as_mut`] 를 참조하십시오.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 포인터는 초기화 된 `T` 인스턴스를 가리켜 야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 변경되지 않아야합니다 (`UnsafeCell` 내부 제외).
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    /// (초기화에 대한 부분은 아직 완전히 결정되지 않았지만, 그것이 될 때까지 유일하게 안전한 방법은 초기화되었는지 확인하는 것입니다.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // 안전: 발신자는 `self` 가 모든
        // 참조를위한 요구 사항.
        unsafe { &*self.as_ptr() }
    }

    /// 값에 대한 고유 한 참조를 반환합니다.값이 초기화되지 않은 경우 [`as_uninit_mut`] 를 대신 사용해야합니다.
    ///
    /// 공유 상대에 대해서는 [`as_ref`] 를 참조하십시오.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 포인터는 초기화 된 `T` 인스턴스를 가리켜 야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 다른 포인터를 통해 액세스 (읽기 또는 쓰기)되어서는 안됩니다.
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    /// (초기화에 대한 부분은 아직 완전히 결정되지 않았지만, 그것이 될 때까지 유일하게 안전한 방법은 초기화되었는지 확인하는 것입니다.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // 안전: 발신자는 `self` 가 모든
        // 가변 참조에 대한 요구 사항.
        unsafe { &mut *self.as_ptr() }
    }

    /// 다른 유형의 포인터로 캐스트합니다.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // 안전: `self` 는 반드시 null이 아닌 `NonNull` 포인터입니다.
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// 가는 포인터와 길이에서 null이 아닌 원시 슬라이스를 만듭니다.
    ///
    /// `len` 인수는 바이트 수가 아니라 **요소** 의 수입니다.
    ///
    /// 이 함수는 안전하지만 반환 값을 역 참조하는 것은 안전하지 않습니다.
    /// 슬라이스 안전 요구 사항은 [`slice::from_raw_parts`] 설명서를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // 첫 번째 요소에 대한 포인터로 시작할 때 슬라이스 포인터를 만듭니다.
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (이 예제는이 방법의 사용을 인위적으로 보여 주지만`let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // 안전: `data` 는 반드시 null이 아닌 `NonNull` 포인터입니다.
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// null이 아닌 원시 조각의 길이를 반환합니다.
    ///
    /// 반환 된 값은 바이트 수가 아니라 **요소** 의 수입니다.
    ///
    /// 이 함수는 포인터에 유효한 주소가 없기 때문에 널이 아닌 원시 슬라이스를 슬라이스로 역 참조 할 수없는 경우에도 안전합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// 슬라이스의 버퍼에 대한 널이 아닌 포인터를 리턴합니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // 안전: 우리는 `self` 가 null이 아니라는 것을 알고 있습니다.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// 슬라이스의 버퍼에 대한 원시 포인터를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// 초기화되지 않은 값의 조각에 대한 공유 참조를 반환합니다.[`as_ref`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 변경 가능한 대응 물은 [`as_uninit_slice_mut`] 를 참조하십시오.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터는 `ptr.len() * mem::size_of::<T>()` 많은 바이트에 대한 읽기의 경우 [valid] 여야하며 올바르게 정렬되어야합니다.이것은 특히 다음을 의미합니다.
    ///
    ///     * 이 슬라이스의 전체 메모리 범위는 할당 된 단일 객체 내에 포함되어야합니다!
    ///       슬라이스는 할당 된 여러 개체에 걸쳐있을 수 없습니다.
    ///
    ///     * 길이가 0 인 슬라이스의 경우에도 포인터를 정렬해야합니다.
    ///     한 가지 이유는 열거 형 레이아웃 최적화가 다른 데이터와 구별하기 위해 정렬되고 널이 아닌 참조 (모든 길이의 슬라이스 포함)에 의존 할 수 있기 때문입니다.
    ///
    ///     [`NonNull::dangling()`] 를 사용하여 길이가 0 인 슬라이스에 대해 `data` 로 사용할 수있는 포인터를 얻을 수 있습니다.
    ///
    /// * 슬라이스의 총 크기 `ptr.len() * mem::size_of::<T>()` 는 `isize::MAX` 보다 크지 않아야합니다.
    ///   [`pointer::offset`] 의 안전 문서를 참조하십시오.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 변경되지 않아야합니다 (`UnsafeCell` 내부 제외).
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [`slice::from_raw_parts`] 도 참조하십시오.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // 안전: 발신자는 `as_uninit_slice` 에 대한 안전 계약을 유지해야합니다.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// 초기화되지 않은 값의 조각에 대한 고유 참조를 반환합니다.[`as_mut`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 공유 상대에 대해서는 [`as_uninit_slice`] 를 참조하십시오.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터는 `ptr.len() * mem::size_of::<T>()` 많은 바이트에 대한 읽기 및 쓰기의 경우 [valid] 여야하며 적절하게 정렬되어야합니다.이것은 특히 다음을 의미합니다.
    ///
    ///     * 이 슬라이스의 전체 메모리 범위는 할당 된 단일 객체 내에 포함되어야합니다!
    ///       슬라이스는 할당 된 여러 개체에 걸쳐있을 수 없습니다.
    ///
    ///     * 길이가 0 인 슬라이스의 경우에도 포인터를 정렬해야합니다.
    ///     한 가지 이유는 열거 형 레이아웃 최적화가 다른 데이터와 구별하기 위해 정렬되고 널이 아닌 참조 (모든 길이의 슬라이스 포함)에 의존 할 수 있기 때문입니다.
    ///
    ///     [`NonNull::dangling()`] 를 사용하여 길이가 0 인 슬라이스에 대해 `data` 로 사용할 수있는 포인터를 얻을 수 있습니다.
    ///
    /// * 슬라이스의 총 크기 `ptr.len() * mem::size_of::<T>()` 는 `isize::MAX` 보다 크지 않아야합니다.
    ///   [`pointer::offset`] 의 안전 문서를 참조하십시오.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 다른 포인터를 통해 액세스 (읽기 또는 쓰기)되어서는 안됩니다.
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [`slice::from_raw_parts_mut`] 도 참조하십시오.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // 이것은 `memory` 가 `memory.len()` 많은 바이트에 대한 읽기 및 쓰기에 유효하기 때문에 안전합니다.
    /// // 콘텐츠가 초기화되지 않을 수 있으므로 여기서 `memory.as_mut()` 를 호출하는 것은 허용되지 않습니다.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // 안전: 발신자는 `as_uninit_slice_mut` 에 대한 안전 계약을 유지해야합니다.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// 경계 검사를 수행하지 않고 요소 또는 하위 조각에 대한 원시 포인터를 반환합니다.
    ///
    /// 범위를 벗어난 인덱스를 사용하여이 메서드를 호출하거나 `self` 가 역 참조 할 수없는 경우 결과 포인터가 사용되지 않더라도 *[정의되지 않은 동작]* 입니다.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // 안전: 발신자는 `self` 가 역 참조 가능하고 `index` 인바운드인지 확인합니다.
        // 결과적으로 결과 포인터는 NULL이 될 수 없습니다.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // 안전: 고유 포인터는 null 일 수 없으므로
        // new_unchecked() 존경받습니다.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // 안전: 변경 가능한 참조는 null 일 수 없습니다.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // 안전: 참조는 null 일 수 없으므로
        // new_unchecked() 존경받습니다.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}