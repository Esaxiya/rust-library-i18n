use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// 이 래퍼의 소유자가 참조 대상을 소유 함을 나타내는 null이 아닌 원시 `*mut T` 를 둘러싼 래퍼입니다.
/// `Box<T>`, `Vec<T>`, `String` 및 `HashMap<K, V>` 와 같은 추상화를 구축하는 데 유용합니다.
///
/// `*mut T` 와 달리 `Unique<T>` 는 `T` 의 인스턴스였던 "as if" 로 동작합니다.
/// `T` 가 `Send`/`Sync` 이면 `Send`/`Sync` 를 구현합니다.
/// 또한 `T` 의 인스턴스가 기대할 수있는 강력한 앨리어싱의 종류를 의미합니다.
/// 포인터의 참조는 고유 한 고유 경로없이 수정되어서는 안됩니다.
///
/// 목적에 `Unique` 를 사용하는 것이 올바른지 확실하지 않은 경우 의미가 약한 `NonNull` 를 사용하는 것이 좋습니다.
///
///
/// `*mut T` 와 달리 포인터가 역 참조되지 않더라도 포인터는 항상 널이 아니어야합니다.
/// 이는 열거 형이이 금지 된 값을 판별 자로 사용할 수 있도록하기위한 것입니다. `Option<Unique<T>>` 는 `Unique<T>` 와 크기가 같습니다.
/// 그러나 포인터가 역 참조되지 않으면 포인터가 계속 매달려있을 수 있습니다.
///
/// `*mut T` 와 달리 `Unique<T>` 는 `T` 에 대해 공변합니다.
/// Unique의 앨리어싱 요구 사항을 유지하는 모든 유형에 대해 항상 정확해야합니다.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: 이 마커는 분산에 영향을 미치지 않지만 필요합니다.
    // dropck가 우리가 논리적으로 `T` 를 소유하고 있음을 이해하도록합니다.
    //
    // 자세한 내용은 다음을 참조하십시오.
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` 가 `Send` 이면 포인터가 참조하는 데이터가 별칭이 지정되지 않았으므로 포인터는 `Send` 입니다.
/// 이 앨리어싱 불변은 유형 시스템에 의해 적용되지 않습니다.`Unique` 를 사용하는 추상화는이를 강제해야합니다.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` 가 `Sync` 이면 포인터가 참조하는 데이터가 별칭이 지정되지 않았으므로 포인터는 `Sync` 입니다.
/// 이 앨리어싱 불변은 유형 시스템에 의해 적용되지 않습니다.`Unique` 를 사용하는 추상화는이를 강제해야합니다.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// 매달려 있지만 잘 정렬 된 새 `Unique` 를 만듭니다.
    ///
    /// 이것은 `Vec::new` 처럼 느리게 할당되는 유형을 초기화하는 데 유용합니다.
    ///
    /// 포인터 값은 잠재적으로 `T` 에 대한 유효한 포인터를 나타낼 수 있습니다. 이는 "not yet initialized" 센티넬 값으로 사용해서는 안된다는 것을 의미합니다.
    /// 느리게 할당되는 유형은 다른 방법으로 초기화를 추적해야합니다.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // 안전: mem::align_of() 는 널이 아닌 유효한 포인터를 리턴합니다.그만큼
        // 따라서 new_unchecked() 를 호출하는 조건이 존중됩니다.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// 새 `Unique` 를 만듭니다.
    ///
    /// # Safety
    ///
    /// `ptr` 널이 아니어야합니다.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // 안전: 호출자는 `ptr` 가 널이 아님을 보장해야합니다.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` 가 널이 아닌 경우 새 `Unique` 를 작성합니다.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // 안전: 포인터가 이미 확인되었으며 null이 아닙니다.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// 기본 `*mut` 포인터를 획득합니다.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// 콘텐츠를 역 참조합니다.
    ///
    /// 결과 수명은 자기 자신에게 묶여 있으므로 "as if" 로 동작하며 실제로 차용되는 T의 인스턴스였습니다.
    /// 더 긴 (unbound) 수명이 필요한 경우 `&*my_ptr.as_ptr()` 를 사용하십시오.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // 안전: 발신자는 `self` 가 모든
        // 참조를위한 요구 사항.
        unsafe { &*self.as_ptr() }
    }

    /// 콘텐츠를 상호 참조 해제합니다.
    ///
    /// 결과 수명은 자기 자신에게 묶여 있으므로 "as if" 로 동작하며 실제로 차용되는 T의 인스턴스였습니다.
    /// 더 긴 (unbound) 수명이 필요한 경우 `&mut *my_ptr.as_ptr()` 를 사용하십시오.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // 안전: 발신자는 `self` 가 모든
        // 가변 참조에 대한 요구 사항.
        unsafe { &mut *self.as_ptr() }
    }

    /// 다른 유형의 포인터로 캐스트합니다.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // 안전: Unique::new_unchecked() 는 새로운 독특하고 요구 사항을 만듭니다.
        // null이 아닌 지정된 포인터
        // self를 포인터로 전달하므로 null이 될 수 없습니다.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // 안전: 변경 가능한 참조는 null 일 수 없습니다.
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}