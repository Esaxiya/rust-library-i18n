//! 원시 포인터를 통해 메모리를 수동으로 관리합니다.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! 이 모듈의 많은 함수는 원시 포인터를 인수로 사용하여 읽거나 씁니다.이것이 안전하려면이 포인터가 *유효* 여야합니다.
//! 포인터가 유효한지 여부는 사용되는 작업 (읽기 또는 쓰기)과 액세스되는 메모리의 범위 (예: read/written 바이트 수)에 따라 다릅니다.
//! 대부분의 함수는 `*mut T` 및 `* const T` 를 사용하여 단일 값에만 액세스합니다.이 경우 문서에서는 크기를 생략하고이를 `size_of::<T>()` 바이트로 암시 적으로 가정합니다.
//!
//! 유효성에 대한 정확한 규칙은 아직 결정되지 않았습니다.이 시점에서 제공되는 보증은 매우 미미합니다.
//!
//! * [null] 포인터는 [size zero][zst] 의 액세스에도 유효하지 않습니다.
//! * 포인터가 유효하려면 포인터가 *역 참조 가능* 이어야하지만 항상 충분하지는 않습니다. 포인터에서 시작하는 주어진 크기의 메모리 범위는 모두 할당 된 단일 객체의 범위 내에 있어야합니다.
//!
//! Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
//! * [size zero][zst] 의 연산에서도 포인터가 할당 해제 된 메모리를 가리키면 안됩니다. 즉 할당 해제는 크기가 0 인 연산에서도 포인터를 무효화합니다.
//! 그러나 0이 아닌 정수 *리터럴* 을 포인터로 캐스팅하는 것은 해당 주소에 일부 메모리가 존재하고 할당 해제되는 경우에도 크기가 0 인 액세스에 유효합니다.
//! 이것은 자신의 할당 자 작성에 해당합니다. 크기가 0 인 개체를 할당하는 것은 그리 어렵지 않습니다.
//! 크기가 0 인 액세스에 유효한 포인터를 얻는 표준 방법은 [`NonNull::dangling`] 입니다.
//! * 이 모듈의 함수에 의해 수행되는 모든 액세스는 스레드 간 동기화에 사용되는 [atomic operations] 의 의미에서 *비원 자적* 입니다.
//! 즉, 두 액세스가 모두 메모리에서 읽기만하지 않는 한 서로 다른 스레드에서 동일한 위치에 두 개의 동시 액세스를 수행하는 것은 정의되지 않은 동작입니다.
//! 여기에는 [`read_volatile`] 및 [`write_volatile`] 가 명시 적으로 포함됩니다. 휘발성 액세스는 스레드 간 동기화에 사용할 수 없습니다.
//! * 포인터에 대한 참조를 캐스팅 한 결과는 기본 개체가 활성 상태이고 동일한 메모리에 액세스하는 데 참조 (원시 포인터 만)가 사용되지 않는 한 유효합니다.
//!
//! 포인터 산술을 위해 [`offset`] 를주의 깊게 사용하는 것과 함께 이러한 공리는 안전하지 않은 코드에서 많은 유용한 것들을 올바르게 구현하기에 충분합니다.
//! [aliasing] 규칙이 결정됨에 따라 결국 더 강력한 보증이 제공 될 것입니다.
//! 자세한 내용은 [book] 및 [undefined behavior][ub] 관련 참조 섹션을 참조하십시오.
//!
//! ## Alignment
//!
//! 위에 정의 된 유효한 원시 포인터는 반드시 제대로 정렬되지는 않습니다 (여기서 "proper" 정렬은 pointee 유형에 의해 정의됩니다. 즉, `*const T` 는 `mem::align_of::<T>()` 에 정렬되어야 함).
//! 그러나 대부분의 함수는 인수가 올바르게 정렬되어야하며이 요구 사항을 설명서에 명시 적으로 명시합니다.
//! 이에 대한 주목할만한 예외는 [`read_unaligned`] 및 [`write_unaligned`] 입니다.
//!
//! 함수에 적절한 정렬이 필요한 경우 액세스 크기가 0 인 경우, 즉 메모리가 실제로 터치되지 않은 경우에도 그렇게합니다.이러한 경우 [`NonNull::dangling`] 사용을 고려하십시오.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// 가리키는 값의 소멸자 (있는 경우)를 실행합니다.
///
/// 이것은 [`ptr::read`] 를 호출하고 결과를 버리는 것과 의미 상 동일하지만 다음과 같은 이점이 있습니다.
///
/// * `drop_in_place` 를 사용하여 trait 객체와 같은 크기가 지정되지 않은 유형을 드롭하는 것은 *필수* 입니다. 왜냐하면 이들은 스택으로 읽을 수없고 정상적으로 드롭 될 수 없기 때문입니다.
///
/// * 컴파일러가 복사본을 제거하는 것이 소리인지 증명할 필요가 없기 때문에 (예: `Box`/`Rc`/`Vec` 구현에서) 수동으로 할당 된 메모리를 삭제할 때 [`ptr::read`] 보다이 작업을 수행하는 것이 최적화기에 더 친숙합니다.
///
///
/// * `T` 가 `repr(packed)` 가 아닌 경우 [pinned] 데이터를 삭제하는 데 사용할 수 있습니다 (고정 된 데이터는 삭제되기 전에 이동해서는 안 됨).
///
/// 정렬되지 않은 값은 제자리에 놓을 수 없으며 먼저 [`ptr::read_unaligned`] 를 사용하여 정렬 된 위치에 복사해야합니다.패킹 된 구조체의 경우이 이동은 컴파일러에 의해 자동으로 수행됩니다.
/// 이는 패킹 된 구조체의 필드가 제자리에 삭제되지 않음을 의미합니다.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `to_drop` 읽기 및 쓰기 모두에 대해 [valid] 여야합니다.
///
/// * `to_drop` 제대로 정렬되어야합니다.
///
/// * `to_drop` 가 가리키는 값은 삭제에 유효해야합니다. 이는 추가 불변을 유지해야 함을 의미 할 수 있으며 이는 유형에 따라 다릅니다.
///
/// 또한 `T` 가 [`Copy`] 가 아닌 경우 `drop_in_place` 를 호출 한 후 지정 값을 사용하면 정의되지 않은 동작이 발생할 수 있습니다.`*to_drop = foo` 는 값이 다시 삭제되기 때문에 사용으로 간주됩니다.
/// [`write()`] 데이터를 삭제하지 않고 덮어 쓰는 데 사용할 수 있습니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [valid]: self#safety
///
/// # Examples
///
/// vector 에서 마지막 항목을 수동으로 제거합니다.
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // `v` 의 마지막 요소에 대한 원시 포인터를 가져옵니다.
///     let ptr = &mut v[1] as *mut _;
///     // 마지막 항목이 삭제되지 않도록 `v` 를 줄이십시오.
///     // `drop_in_place` 가 panics 미만인 경우 문제를 방지하기 위해 먼저 그렇게합니다.
///     v.set_len(1);
///     // `drop_in_place` 를 호출하지 않으면 마지막 항목이 삭제되지 않고 관리하는 메모리가 누출됩니다.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // 마지막 항목이 삭제되었는지 확인하십시오.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// 컴파일러는 패킹 된 구조체를 삭제할 때이 복사를 자동으로 수행합니다. 즉, `drop_in_place` 를 수동으로 호출하지 않는 한 일반적으로 이러한 문제에 대해 걱정할 필요가 없습니다.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // 여기의 코드는 중요하지 않습니다. 이것은 컴파일러에 의해 실제 드롭 글루로 대체됩니다.
    //

    // 안전: 위의 주석 참조
    unsafe { drop_in_place(to_drop) }
}

/// null 원시 포인터를 만듭니다.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// null 가변 원시 포인터를 만듭니다.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// `T: Clone` 바인딩을 피하기 위해 수동 impl이 필요했습니다.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// `T: Copy` 바인딩을 피하기 위해 수동 impl이 필요했습니다.
impl<T> Copy for FatPtr<T> {}

/// 포인터와 길이에서 원시 슬라이스를 형성합니다.
///
/// `len` 인수는 바이트 수가 아니라 **요소** 의 수입니다.
///
/// 이 함수는 안전하지만 실제로 반환 값을 사용하는 것은 안전하지 않습니다.
/// 슬라이스 안전 요구 사항은 [`slice::from_raw_parts`] 설명서를 참조하십시오.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // 첫 번째 요소에 대한 포인터로 시작할 때 슬라이스 포인터를 만듭니다.
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // 안전: * const [T] 이후 `Repr` 공용체의 값에 액세스하는 것이 안전합니다.
        //
        // FatPtr은 동일한 메모리 레이아웃을 가지고 있습니다.std 만이이를 보장 할 수 있습니다.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// 원시 불변 슬라이스와 반대로 원시 변경 가능 슬라이스가 반환된다는 점을 제외하면 [`slice_from_raw_parts`] 와 동일한 기능을 수행합니다.
///
///
/// 자세한 내용은 [`slice_from_raw_parts`] 문서를 참조하십시오.
///
/// 이 함수는 안전하지만 실제로 반환 값을 사용하는 것은 안전하지 않습니다.
/// 슬라이스 안전 요구 사항은 [`slice::from_raw_parts_mut`] 설명서를 참조하십시오.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // 슬라이스의 인덱스에 값 할당
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // 안전: `Repr` 공용체의 값에 액세스하는 것은 * mut [T] 이므로 안전합니다.
        // FatPtr은 같은 메모리 레이아웃을 가지고 있습니다.
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// 초기화를 해제하지 않고 동일한 유형의 변경 가능한 두 위치에서 값을 바꿉니다.
///
/// 그러나 다음 두 가지 예외의 경우이 함수는 의미 상 [`mem::swap`] 와 동일합니다.
///
///
/// * 참조 대신 원시 포인터에서 작동합니다.
/// 참조를 사용할 수있는 경우 [`mem::swap`] 를 선호해야합니다.
///
/// * 두 포인트 값이 겹칠 수 있습니다.
/// 값이 겹치면 `x` 의 겹치는 메모리 영역이 사용됩니다.
/// 이것은 아래의 두 번째 예에서 설명됩니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `x` 및 `y` 는 읽기 및 쓰기 모두에 대해 [valid] 여야합니다.
///
/// * `x` 와 `y` 는 모두 올바르게 정렬되어야합니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [valid]: self#safety
///
/// # Examples
///
/// 겹치지 않는 두 영역 바꾸기 :
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // 이것은 `array[0..2]` 입니다
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // 이것은 `array[2..4]` 입니다
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// 두 개의 겹치는 영역 교체 :
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // 이것은 `array[0..3]` 입니다
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // 이것은 `array[1..4]` 입니다
///
/// unsafe {
///     ptr::swap(x, y);
///     // 슬라이스의 인덱스 `1..3` 는 `x` 와 `y` 사이에서 겹칩니다.
///     // 합리적인 결과는 `[2, 3]` 이므로 인덱스 `0..3` 는 `[1, 2, 3]` 입니다 (`swap` 이전의 `y` 와 일치).또는 인덱스 `1..4` 가 `[0, 1, 2]` (`swap` 이전의 `x` 와 일치)가되도록 `[0, 1]` 가되도록합니다.
/////
///     // 이 구현은 후자의 선택을 위해 정의됩니다.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // 작업 할 스크래치 공간을 확보하십시오.
    // 드롭에 대해 걱정할 필요가 없습니다. `MaybeUninit` 는 떨어 뜨렸을 때 아무것도하지 않습니다.
    let mut tmp = MaybeUninit::<T>::uninit();

    // 스왑 안전 수행: 호출자는 `x` 및 `y` 가 쓰기에 유효하고 올바르게 정렬되었는지 확인해야합니다.
    // `tmp` `tmp` 가 별도의 할당 된 개체로 스택에 할당되었으므로 `x` 또는 `y` 와 겹칠 수 없습니다.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` `y` 는 겹칠 수 있습니다.
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// `x` 와 `y` 에서 시작하는 두 메모리 영역 사이에서 `count * size_of::<T>()` 바이트를 스왑합니다.
/// 두 영역은 겹치지 *않아야* 합니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `count의 읽기 및 쓰기 모두에 대해 `x` 및 `y` 는 모두 [valid] 여야합니다. *
///   size_of: :<T>()`바이트.
///
/// * `x` 와 `y` 는 모두 올바르게 정렬되어야합니다.
///
/// * 'count'크기로 `x` 에서 시작하는 메모리 영역 *
///   size_of: :<T>()`바이트는 같은 크기의 `y` 에서 시작하는 메모리 영역과 겹치지 *않아야* 합니다.
///
/// 효과적으로 복사 된 크기 (`count * size_of: :<T>()`)는 `0` 이고 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // 안전: 발신자는 `x` 및 `y` 가
    // 쓰기에 유효하고 올바르게 정렬됩니다.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // 아래 블록 최적화보다 작은 유형의 경우 코드 생성을 비관적으로 피하려면 직접 교체하십시오.
    //
    if mem::size_of::<T>() < 32 {
        // 안전: 호출자는 `x` 및 `y` 가 유효한지 확인해야합니다.
        // 쓰기, 적절하게 정렬되고 겹치지 않습니다.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // 안전: 발신자는 `swap_nonoverlapping` 에 대한 안전 계약을 유지해야합니다.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // 여기서 접근 방식은 simd를 사용하여 x와 y를 효율적으로 스왑하는 것입니다.
    // 테스트 결과 한 번에 32 바이트 또는 64 바이트를 스와핑하는 것이 Intel Haswell E 프로세서에 가장 효율적이라는 사실이 밝혀졌습니다.
    // LLVM은 실제로이 구조체를 직접 사용하지 않더라도 구조체에 #[repr(simd)] 를 제공하면 더 최적화 할 수 있습니다.
    //
    //
    // emscripten 및 redox에서 FIXME repr(simd) 가 손상됨
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // x&y를 통해 반복, 한 번에 `Block` 복사 최적화 프로그램은 대부분의 유형 NB에 대해 루프를 완전히 풀어야합니다.
    // `range` impl이 `mem::swap` 를 재귀 적으로 호출하므로 for 루프를 사용할 수 없습니다.
    //
    let mut i = 0;
    while i + block_size <= len {
        // 초기화되지 않은 메모리를 스크래치 공간으로 생성 여기에서 `t` 를 선언하면이 루프가 사용되지 않을 때 스택이 정렬되지 않습니다.
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // 안전: `i < len` 및 호출자는 `x` 및 `y` 가 유효한지 확인해야합니다.
        // `len` 바이트의 경우 `x + i` 및 `y + i` 는 `add` 에 대한 안전 계약을 충족하는 유효한 주소 여야합니다.
        //
        // 또한 호출자는 `x` 및 `y` 가 쓰기에 유효하고 적절하게 정렬되고 겹치지 않음을 보장하여 `copy_nonoverlapping` 에 대한 안전 계약을 충족해야합니다.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // t를 임시 버퍼로 사용하여 x 및 y 바이트 블록을 스왑합니다. 가능한 경우 효율적인 SIMD 작업으로 최적화되어야합니다.
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // 나머지 바이트 교체
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // 안전: 이전 안전 설명을 참조하십시오.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// `src` 를 뾰족한 `dst` 로 이동하여 이전 `dst` 값을 반환합니다.
///
/// 두 값 모두 삭제되지 않습니다.
///
/// 이 함수는 참조 대신 원시 포인터에서 작동한다는 점을 제외하면 [`mem::replace`] 와 의미 상 동일합니다.
/// 참조를 사용할 수있는 경우 [`mem::replace`] 를 선호해야합니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `dst` 읽기 및 쓰기 모두에 대해 [valid] 여야합니다.
///
/// * `dst` 제대로 정렬되어야합니다.
///
/// * `dst` `T` 유형의 적절하게 초기화 된 값을 가리켜 야합니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` 안전하지 않은 블록 없이도 동일한 효과를 얻을 수 있습니다.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // 안전: 호출자는 `dst` 가 유효한지 확인해야합니다.
    // 변경 가능한 참조 (쓰기에 유효, 정렬, 초기화 됨)로 캐스트되고 `dst` 가 별개의 할당 된 객체를 가리켜 야하기 때문에 `src` 와 겹칠 수 없습니다.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // 겹칠 수 없습니다
    }
    src
}

/// 이동하지 않고 `src` 에서 값을 읽습니다.이렇게하면 `src` 의 메모리가 변경되지 않습니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `src` 읽기를 위해서는 [valid] 여야합니다.
///
/// * `src` 제대로 정렬되어야합니다.그렇지 않은 경우 [`read_unaligned`] 를 사용하십시오.
///
/// * `src` `T` 유형의 적절하게 초기화 된 값을 가리켜 야합니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] 를 수동으로 구현합니다.
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp` 의 `a` 에있는 값의 비트 단위 복사본을 만듭니다.
///         let tmp = ptr::read(a);
///
///         // 이 시점에서 종료하면 (명시 적으로 반환하거나 panics 함수를 호출하여) 동일한 값이 여전히 `a` 에 의해 참조되는 동안 `tmp` 의 값이 삭제됩니다.
///         // `T` 가 `Copy` 가 아닌 경우 정의되지 않은 동작을 트리거 할 수 있습니다.
/////
/////
///
///         // `a` 의 `b` 에있는 값의 비트 단위 복사본을 만듭니다.
///         // 변경 가능한 참조는 별칭을 사용할 수 없기 때문에 안전합니다.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 위와 같이 `a` 및 `b` 에서 동일한 값을 참조하기 때문에 여기서 종료하면 정의되지 않은 동작이 트리거 될 수 있습니다.
/////
///
///         // `tmp` 를 `b` 로 이동합니다.
///         ptr::write(b, tmp);
///
///         // `tmp` 이동되었으므로 (`write` 는 두 번째 인수의 소유권을 갖습니다) 여기에 암시 적으로 삭제되는 것은 없습니다.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## 반환 된 가치의 소유권
///
/// `read` `T` 가 [`Copy`] 인지 여부에 관계없이 `T` 의 비트 복사본을 만듭니다.
/// `T` 가 [`Copy`] 가 아닌 경우 반환 된 값과 `*src` 의 값을 모두 사용하면 메모리 안전을 위반할 수 있습니다.
/// `*src` 에 할당하면 `* src` 에서 값을 삭제하려고 시도하기 때문에 사용으로 간주됩니다.
///
/// [`write()`] 데이터를 삭제하지 않고 덮어 쓰는 데 사용할 수 있습니다.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` 이제 `s` 와 동일한 기본 메모리를 가리 킵니다.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // `s2` 에 할당하면 원래 값이 삭제됩니다.
///     // 이 시점 이후에는 기본 메모리가 해제되었으므로 `s` 를 더 이상 사용하지 않아야합니다.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // `s` 에 할당하면 이전 값이 다시 삭제되어 정의되지 않은 동작이 발생합니다.
/////
///     // s= String::from("bar");//오류
///
///     // `ptr::write` 값을 삭제하지 않고 덮어 쓰는 데 사용할 수 있습니다.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // 안전: 호출자는 `src` 가 읽기에 유효 함을 보장해야합니다.
    // `src` `tmp` 가 별도의 할당 된 개체로 스택에 할당되었으므로 `tmp` 와 겹칠 수 없습니다.
    //
    //
    // 또한 `tmp` 에 유효한 값을 방금 썼으므로 제대로 초기화되는 것이 보장됩니다.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// 이동하지 않고 `src` 에서 값을 읽습니다.이렇게하면 `src` 의 메모리가 변경되지 않습니다.
///
/// [`read`] 와 달리 `read_unaligned` 는 정렬되지 않은 포인터로 작동합니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `src` 읽기를 위해서는 [valid] 여야합니다.
///
/// * `src` `T` 유형의 적절하게 초기화 된 값을 가리켜 야합니다.
///
/// [`read`] 와 마찬가지로 `read_unaligned` 는 `T` 가 [`Copy`] 인지 여부에 관계없이 `T` 의 비트 단위 복사본을 만듭니다.
/// `T` 가 [`Copy`] 가 아닌 경우 반환 된 값과 `*src` 의 값을 모두 사용하여 [violate memory safety][read-ownership] 를 수행 할 수 있습니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니어야합니다.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## `packed` 구조체에서
///
/// 현재 패킹 된 구조체의 정렬되지 않은 필드에 대한 원시 포인터를 만드는 것은 불가능합니다.
///
/// `&packed.unaligned as *const FieldType` 와 같은 표현식을 사용하여 `unaligned` 구조체 필드에 대한 원시 포인터를 만들려고 시도하면 정렬되지 않은 중간 참조가 생성되어 원시 포인터로 변환됩니다.
///
/// 이 참조는 임시적이고 즉시 캐스트된다는 것은 컴파일러가 항상 참조가 적절하게 정렬되기를 기대하기 때문에 중요하지 않습니다.
/// 결과적으로 `&packed.unaligned as *const FieldType` 를 사용하면 프로그램에서 즉시* 정의되지 않은 동작 *이 발생합니다.
///
/// 하지 말아야 할 것과 이것이 `read_unaligned` 와의 관계에 대한 예는 다음과 같습니다.
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // 여기서는 정렬되지 않은 32 비트 정수의 주소를 가져 오려고합니다.
///     let unaligned =
///         // 여기에 정렬되지 않은 임시 참조가 생성되어 참조 사용 여부에 관계없이 정의되지 않은 동작이 발생합니다.
/////
///         &packed.unaligned
///         // 원시 포인터로 캐스트하는 것은 도움이되지 않습니다.실수는 이미 일어났습니다.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// 그러나 예를 들어 `packed.unaligned` 를 사용하여 정렬되지 않은 필드에 직접 액세스하는 것은 안전합니다.
///
///
///
///
///
///
// FIXME: RFC #2582 및 친구의 결과에 따라 문서를 업데이트합니다.
/// # Examples
///
/// 바이트 버퍼에서 사용 값을 읽습니다.
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // 안전: 호출자는 `src` 가 읽기에 유효 함을 보장해야합니다.
    // `src` `tmp` 가 별도의 할당 된 개체로 스택에 할당되었으므로 `tmp` 와 겹칠 수 없습니다.
    //
    //
    // 또한 `tmp` 에 유효한 값을 방금 썼으므로 제대로 초기화되는 것이 보장됩니다.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// 이전 값을 읽거나 삭제하지 않고 주어진 값으로 메모리 위치를 덮어 씁니다.
///
/// `write` `dst` 의 내용을 삭제하지 않습니다.
/// 이것은 안전하지만 할당이나 리소스가 누수 될 수 있으므로 삭제해야하는 개체를 덮어 쓰지 않도록주의해야합니다.
///
///
/// 또한 `src` 를 드롭하지 않습니다.의미 상 `src` 는 `dst` 가 가리키는 위치로 이동합니다.
///
/// 이것은 초기화되지 않은 메모리를 초기화하거나 이전에 [`read`] 를 사용했던 메모리를 덮어 쓰는 데 적합합니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `dst` 쓰기를 위해서는 [valid] 여야합니다.
///
/// * `dst` 제대로 정렬되어야합니다.그렇지 않은 경우 [`write_unaligned`] 를 사용하십시오.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [valid]: self#safety
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// [`mem::swap`] 를 수동으로 구현합니다.
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // `tmp` 의 `a` 에있는 값의 비트 단위 복사본을 만듭니다.
///         let tmp = ptr::read(a);
///
///         // 이 시점에서 종료하면 (명시 적으로 반환하거나 panics 함수를 호출하여) 동일한 값이 여전히 `a` 에 의해 참조되는 동안 `tmp` 의 값이 삭제됩니다.
///         // `T` 가 `Copy` 가 아닌 경우 정의되지 않은 동작을 트리거 할 수 있습니다.
/////
/////
///
///         // `a` 의 `b` 에있는 값의 비트 단위 복사본을 만듭니다.
///         // 변경 가능한 참조는 별칭을 사용할 수 없기 때문에 안전합니다.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 위와 같이 `a` 및 `b` 에서 동일한 값을 참조하기 때문에 여기서 종료하면 정의되지 않은 동작이 트리거 될 수 있습니다.
/////
///
///         // `tmp` 를 `b` 로 이동합니다.
///         ptr::write(b, tmp);
///
///         // `tmp` 이동되었으므로 (`write` 는 두 번째 인수의 소유권을 갖습니다) 여기에 암시 적으로 삭제되는 것은 없습니다.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // `intrinsics::copy_nonoverlapping` 는 래퍼 함수이므로 생성 된 코드에서 함수 호출을 피하기 위해 내장 함수를 직접 호출합니다.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // 안전: 호출자는 `dst` 가 쓰기에 유효 함을 보장해야합니다.
    // `dst` 호출자는 `dst` 에 대해 변경 가능한 액세스 권한을 가지고 있고 `src` 는이 함수에 의해 소유되므로 `src` 와 겹칠 수 없습니다.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// 이전 값을 읽거나 삭제하지 않고 주어진 값으로 메모리 위치를 덮어 씁니다.
///
/// [`write()`] 와 달리 포인터가 정렬되지 않을 수 있습니다.
///
/// `write_unaligned` `dst` 의 내용을 삭제하지 않습니다.이것은 안전하지만 할당이나 리소스가 누수 될 수 있으므로 삭제해야하는 개체를 덮어 쓰지 않도록주의해야합니다.
///
/// 또한 `src` 를 드롭하지 않습니다.의미 상 `src` 는 `dst` 가 가리키는 위치로 이동합니다.
///
/// 이는 초기화되지 않은 메모리를 초기화하거나 이전에 [`read_unaligned`] 로 읽은 메모리를 덮어 쓰는 데 적합합니다.
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `dst` 쓰기를 위해서는 [valid] 여야합니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니어야합니다.
///
/// [valid]: self#safety
///
/// ## `packed` 구조체에서
///
/// 현재 패킹 된 구조체의 정렬되지 않은 필드에 대한 원시 포인터를 만드는 것은 불가능합니다.
///
/// `&packed.unaligned as *const FieldType` 와 같은 표현식을 사용하여 `unaligned` 구조체 필드에 대한 원시 포인터를 만들려고 시도하면 정렬되지 않은 중간 참조가 생성되어 원시 포인터로 변환됩니다.
///
/// 이 참조는 임시적이고 즉시 캐스트된다는 것은 컴파일러가 항상 참조가 적절하게 정렬되기를 기대하기 때문에 중요하지 않습니다.
/// 결과적으로 `&packed.unaligned as *const FieldType` 를 사용하면 프로그램에서 즉시* 정의되지 않은 동작 *이 발생합니다.
///
/// 하지 말아야 할 것과 이것이 `write_unaligned` 와의 관계에 대한 예는 다음과 같습니다.
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // 여기서는 정렬되지 않은 32 비트 정수의 주소를 가져 오려고합니다.
///     let unaligned =
///         // 여기에 정렬되지 않은 임시 참조가 생성되어 참조 사용 여부에 관계없이 정의되지 않은 동작이 발생합니다.
/////
///         &mut packed.unaligned
///         // 원시 포인터로 캐스트하는 것은 도움이되지 않습니다.실수는 이미 일어났습니다.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// 그러나 예를 들어 `packed.unaligned` 를 사용하여 정렬되지 않은 필드에 직접 액세스하는 것은 안전합니다.
///
///
///
///
///
///
///
///
///
// FIXME: RFC #2582 및 친구의 결과에 따라 문서를 업데이트합니다.
/// # Examples
///
/// 사용 값을 바이트 버퍼에 씁니다.
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // 안전: 호출자는 `dst` 가 쓰기에 유효 함을 보장해야합니다.
    // `dst` 호출자는 `dst` 에 대해 변경 가능한 액세스 권한을 가지고 있고 `src` 는이 함수에 의해 소유되므로 `src` 와 겹칠 수 없습니다.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // 생성 된 코드에서 함수 호출을 피하기 위해 내장 함수를 직접 호출합니다.
        intrinsics::forget(src);
    }
}

/// `src` 에서 값을 이동하지 않고 휘발성 읽기를 수행합니다.이렇게하면 `src` 의 메모리가 변경되지 않습니다.
///
/// 휘발성 작업은 I/O 메모리에서 작동하도록 의도되었으며 다른 휘발성 작업에서 컴파일러에 의해 제거되거나 순서가 변경되지 않습니다.
///
/// # Notes
///
/// Rust 에는 현재 엄격하고 공식적으로 정의 된 메모리 모델이 없으므로 "volatile" 가 의미하는 정확한 의미는 시간이 지남에 따라 변경 될 수 있습니다.
/// 즉, 의미론은 거의 항상 [C11's definition of volatile][c11] 와 매우 유사합니다.
///
/// 컴파일러는 휘발성 메모리 작업의 상대적 순서 나 수를 변경해서는 안됩니다.
/// 그러나 크기가 0 인 유형에 대한 휘발성 메모리 작업 (예: 크기가 0 인 유형이 `read_volatile` 에 전달되는 경우)은 noops이며 무시 될 수 있습니다.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `src` 읽기를 위해서는 [valid] 여야합니다.
///
/// * `src` 제대로 정렬되어야합니다.
///
/// * `src` `T` 유형의 적절하게 초기화 된 값을 가리켜 야합니다.
///
/// [`read`] 와 마찬가지로 `read_volatile` 는 `T` 가 [`Copy`] 인지 여부에 관계없이 `T` 의 비트 단위 복사본을 만듭니다.
/// `T` 가 [`Copy`] 가 아닌 경우 반환 된 값과 `*src` 의 값을 모두 사용하여 [violate memory safety][read-ownership] 를 수행 할 수 있습니다.
/// 그러나 비 [`Copy`] 유형을 휘발성 메모리에 저장하는 것은 거의 확실하지 않습니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// C에서와 마찬가지로, 작업이 휘발성인지 여부는 여러 스레드의 동시 액세스와 관련된 질문과 관련이 없습니다.휘발성 액세스는 이와 관련하여 비원 자적 액세스와 똑같이 작동합니다.
///
/// 특히, `read_volatile` 와 동일한 위치에 대한 쓰기 작업 간의 경쟁은 정의되지 않은 동작입니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // codegen 영향을 작게 유지하기 위해 당황하지 않습니다.
        abort();
    }
    // 안전: 발신자는 `volatile_load` 에 대한 안전 계약을 유지해야합니다.
    unsafe { intrinsics::volatile_load(src) }
}

/// 이전 값을 읽거나 삭제하지 않고 주어진 값으로 메모리 위치의 휘발성 쓰기를 수행합니다.
///
/// 휘발성 작업은 I/O 메모리에서 작동하도록 의도되었으며 다른 휘발성 작업에서 컴파일러에 의해 제거되거나 순서가 변경되지 않습니다.
///
/// `write_volatile` `dst` 의 내용을 삭제하지 않습니다.이것은 안전하지만 할당이나 리소스가 누수 될 수 있으므로 삭제해야하는 개체를 덮어 쓰지 않도록주의해야합니다.
///
/// 또한 `src` 를 드롭하지 않습니다.의미 상 `src` 는 `dst` 가 가리키는 위치로 이동합니다.
///
/// # Notes
///
/// Rust 에는 현재 엄격하고 공식적으로 정의 된 메모리 모델이 없으므로 "volatile" 가 의미하는 정확한 의미는 시간이 지남에 따라 변경 될 수 있습니다.
/// 즉, 의미론은 거의 항상 [C11's definition of volatile][c11] 와 매우 유사합니다.
///
/// 컴파일러는 휘발성 메모리 작업의 상대적 순서 나 수를 변경해서는 안됩니다.
/// 그러나 크기가 0 인 유형에 대한 휘발성 메모리 작업 (예: 크기가 0 인 유형이 `write_volatile` 에 전달되는 경우)은 noops이며 무시 될 수 있습니다.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 다음 조건 중 하나라도 위반하면 동작이 정의되지 않습니다.
///
/// * `dst` 쓰기를 위해서는 [valid] 여야합니다.
///
/// * `dst` 제대로 정렬되어야합니다.
///
/// `T` 의 크기가 `0` 인 경우에도 포인터는 NULL이 아니고 올바르게 정렬되어야합니다.
///
/// [valid]: self#safety
///
/// C에서와 마찬가지로, 작업이 휘발성인지 여부는 여러 스레드의 동시 액세스와 관련된 질문과 관련이 없습니다.휘발성 액세스는 이와 관련하여 비원 자적 액세스와 똑같이 작동합니다.
///
/// 특히, `write_volatile` 와 같은 위치에서 다른 작업 (읽기 또는 쓰기) 간의 경쟁은 정의되지 않은 동작입니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // codegen 영향을 작게 유지하기 위해 당황하지 않습니다.
        abort();
    }
    // 안전: 발신자는 `volatile_store` 에 대한 안전 계약을 유지해야합니다.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// 포인터 `p` 를 정렬합니다.
///
/// 포인터 `p` 가 `a` 에 정렬되도록 포인터 `p` 에 적용해야하는 오프셋 (`stride` 스트라이드의 요소 측면에서)을 계산합니다.
///
/// Note: 이 구현은 panic 가 아닌 세 심하게 조정되었습니다.이것을 panic 에 UB입니다.
/// 여기서 할 수있는 유일한 실제 변경은 `INV_TABLE_MOD_16` 및 관련 상수의 변경입니다.
///
/// 2의 거듭 제곱이 아닌 `a` 를 사용하여 내장 함수를 호출 할 수 있도록 결정한 경우 변경 사항을 수용하기 위해이를 조정하는 것보다 순진한 구현으로 변경하는 것이 더 현명 할 것입니다.
///
///
/// 질문이 있으면@nagisa로 이동하십시오.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): 이러한 내장 함수를 직접 사용하면 opt-level <=에서 codegen이 크게 향상됩니다.
    // 이러한 작업의 메서드 버전은 인라인되지 않습니다.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// `x` 모듈로 `m` 의 곱셈 모듈러 역을 계산합니다.
    ///
    /// 이 구현은 `align_offset` 에 맞게 조정되었으며 다음과 같은 전제 조건이 있습니다.
    ///
    /// * `m` 2의 거듭 제곱입니다.
    /// * `x < m`; (`x ≥ m` 인 경우 대신 `x % m` 로 전달)
    ///
    /// 이 기능의 구현은 panic 가 아닙니다.이제까지.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// 곱셈 모듈 식 역 테이블 모듈로 2⁴=16.
        ///
        /// 이 테이블에는 역이 존재하지 않는 값이 포함되어 있지 않습니다 (예: `0⁻¹ mod 16`, `2⁻¹ mod 16` 등).
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` 가 의도하는 모듈로.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // 안전: `m` 는 2의 거듭 제곱이어야하므로 0이 아닙니다.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // 다음 공식을 사용하여 "up" 를 반복합니다.
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // 2²ⁿ ≥ m까지.그런 다음 결과 `mod m` 를 가져 와서 원하는 `m` 로 줄일 수 있습니다.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // 여기서는 의도적으로 래핑 작업을 사용합니다. 원래 공식은 예를 들어 빼기 `mod n` 를 사용합니다.
                // 어쨌든 `mod n` 결과를 가져 오기 때문에 대신 `mod usize::MAX` 를 수행하는 것이 좋습니다.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // 안전: `a` 는 2의 거듭 제곱이므로 0이 아닙니다.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case는 `-p (mod a)` 를 통해 더 간단하게 계산할 수 있지만 그렇게하면 LLVM이 `lea` 와 같은 명령을 선택하는 기능이 제한됩니다.대신 우리는
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // 로드 베어링 주위에 작업을 분산 시키지만 LLVM이 알고있는 다양한 최적화를 활용할 수 있도록 `and` 를 충분히 비관적입니다.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // 이미 정렬되었습니다.예이!
        return 0;
    } else if stride == 0 {
        // 포인터가 정렬되어 있지 않고 요소의 크기가 0이면 어떤 양의 요소도 포인터를 정렬하지 않습니다.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // 안전: a는 2의 거듭 제곱이므로 0이 아닙니다.stride==0 케이스는 위에서 처리됩니다.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // 안전: gcdpow는 usize의 최대 비트 수인 상한선을 가지고 있습니다.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // 안전: gcd는 항상 1보다 크거나 같습니다.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // 이 branch 는 다음 선형 합동 방정식을 해결합니다.
        //
        // ` p + so = 0 mod a `
        //
        // `p` 여기 포인터 값 `s`, `T` 의 보폭,`T`의 `o` 오프셋, 요청 된 정렬 인 `a` 가 있습니다.
        //
        // `g = gcd(a, s)` 와 `p` 도 `g` 로 나눌 수 있다고 주장하는 위의 조건을 사용하면 `a' = a/g`, `s' = s/g`, `p' = p/g` 를 나타낼 수 있습니다. 그러면 다음과 같습니다.
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // 첫 번째 항은 "the relative alignment of `p` to `a`" (`g` 로 나눔)이고 두 번째 항은 "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (다시 `g` 로 나눔)입니다.
        //
        // `a` 와 `s` 가 코 프라임이 아닌 경우 역을 잘 형성하려면 `g` 로 나누기가 필요합니다.
        //
        // 또한이 솔루션으로 생성 된 결과는 "minimal" 가 아니므로 결과 `o mod lcm(s, a)` 를 가져와야합니다.`lcm(s, a)` 를 `a'` 로 대체 할 수 있습니다.
        //
        //
        //
        //
        //

        // 안전: `gcdpow` 에는 `a` 의 후행 0 비트 수보다 크지 않은 상한이 있습니다.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // 안전: `a2` 는 0이 아닙니다.`gcdpow` 로 `a` 를 이동하면 설정된 비트를 이동할 수 없습니다.
        // `a` (정확히 하나만 있음).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // 안전: `gcdpow` 에는 `a` 의 후행 0 비트 수보다 크지 않은 상한이 있습니다.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // 안전: `gcdpow` 에는 후행 0 비트 수보다 크지 않은 상한이 있습니다.
        // `a`.
        // 또한 `a2 = a >> gcdpow` 는 항상 `(p % a) >> gcdpow` 보다 엄격하게 크기 때문에 빼기가 오버플로 될 수 없습니다.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // 안전: `a2` 는 위에서 입증 된 것처럼 2의 거듭 제곱입니다.`s2` 는 `a2` 보다 작습니다.
        // `(s % a) >> gcdpow` 는 `a >> gcdpow` 보다 엄격히 작기 때문입니다.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // 전혀 정렬 할 수 없습니다.
    usize::MAX
}

/// 원시 포인터가 같은지 비교합니다.
///
/// 이것은 `==` 연산자를 사용하는 것과 동일하지만 덜 일반적입니다.
/// 인수는 `PartialEq` 를 구현하는 것이 아니라 `*const T` 원시 포인터 여야합니다.
///
/// 이것은 `&T` 참조 (암시 적으로 `*const T` 로 강제 변환)를 가리키는 값을 비교하는 대신 주소별로 비교하는 데 사용할 수 있습니다 (`PartialEq for &T` 구현이 수행하는 작업).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// 슬라이스는 길이 (팻 포인터)로도 비교됩니다.
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits 는 또한 구현에 따라 비교됩니다.
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // 포인터는 동일한 주소를 갖습니다.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // 객체의 주소는 동일하지만 `Trait` 는 구현이 다릅니다.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // 참조를 `*const u8` 로 변환하면 주소별로 비교됩니다.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// 원시 포인터를 해시하십시오.
///
/// 이것은 가리키는 값 (`Hash for &T` 구현이 수행하는 작업)이 아닌 주소로 `&T` 참조 (암시 적으로 `*const T` 로 강제 변환)를 해시하는 데 사용할 수 있습니다.
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// 함수 포인터에 대한 Impls
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR을 사용하려면 중간 캐스트가 필요합니다.
                // 소스 함수 포인터의 주소 공간이 최종 함수 포인터에 보존되도록합니다.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR을 사용하려면 중간 캐스트가 필요합니다.
                // 소스 함수 포인터의 주소 공간이 최종 함수 포인터에 보존되도록합니다.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 매개 변수가 0 인 가변 함수 없음
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// 중간 참조를 만들지 않고 장소에 대한 `const` 원시 포인터를 만듭니다.
///
/// `&`/`&mut` 로 참조를 만드는 것은 포인터가 제대로 정렬되고 초기화 된 데이터를 가리키는 경우에만 허용됩니다.
/// 이러한 요구 사항이 충족되지 않는 경우에는 대신 원시 포인터를 사용해야합니다.
/// 그러나 `&expr as *const _` 는 참조를 원시 포인터로 캐스트하기 전에 참조를 작성하며 해당 참조에는 다른 모든 참조와 동일한 규칙이 적용됩니다.
///
/// 이 매크로는 참조를 먼저 생성하지 않고 * 원시 포인터를 생성 할 수 있습니다.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` 정렬되지 않은 참조를 생성하므로 Undefined Behavior!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// 중간 참조를 만들지 않고 장소에 대한 `mut` 원시 포인터를 만듭니다.
///
/// `&`/`&mut` 로 참조를 만드는 것은 포인터가 제대로 정렬되고 초기화 된 데이터를 가리키는 경우에만 허용됩니다.
/// 이러한 요구 사항이 충족되지 않는 경우에는 대신 원시 포인터를 사용해야합니다.
/// 그러나 `&mut expr as *mut _` 는 참조를 원시 포인터로 캐스트하기 전에 참조를 작성하며 해당 참조에는 다른 모든 참조와 동일한 규칙이 적용됩니다.
///
/// 이 매크로는 참조를 먼저 생성하지 않고 * 원시 포인터를 생성 할 수 있습니다.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` 정렬되지 않은 참조를 생성하므로 Undefined Behavior!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` 참조를 만드는 대신 필드를 강제로 복사합니다.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}