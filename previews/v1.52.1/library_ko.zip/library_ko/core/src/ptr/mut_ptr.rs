use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// 포인터가 null이면 `true` 를 반환합니다.
    ///
    /// 크기가 지정되지 않은 유형에는 길이, vtable 등이 아닌 원시 데이터 포인터 만 고려되므로 가능한 많은 널 포인터가 있습니다.
    /// 따라서 null 인 두 포인터는 여전히 서로 같지 않을 수 있습니다.
    ///
    /// ## const 평가 중 동작
    ///
    /// 이 함수가 const 평가 중에 사용되면 런타임에 null로 판명 된 포인터에 대해 `false` 를 반환 할 수 있습니다.
    /// 특히, 일부 메모리에 대한 포인터가 결과 포인터가 널이되는 방식으로 경계를 넘어 오프셋 될 때 함수는 여전히 `false` 를 리턴합니다.
    ///
    /// CTFE가 해당 메모리의 절대 위치를 알 수있는 방법이 없으므로 포인터가 null인지 여부를 알 수 없습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // 캐스트를 통해 얇은 포인터와 비교하므로 팻 포인터는 "data" 부분 만 null-ness로 간주합니다.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// 다른 유형의 포인터로 캐스트합니다.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// (넓은) 포인터를 주소 및 메타 데이터 구성 요소로 분해합니다.
    ///
    /// 포인터는 나중에 [`from_raw_parts_mut`] 로 재구성 할 수 있습니다.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// 포인터가 null이면 `None` 를 반환하고 그렇지 않으면 `Some` 에 래핑 된 값에 대한 공유 참조를 반환합니다.값이 초기화되지 않은 경우 [`as_uninit_ref`] 를 대신 사용해야합니다.
    ///
    /// 변경 가능한 대응 물은 [`as_mut`] 를 참조하십시오.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 포인터가 NULL 인 *또는* 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 포인터는 초기화 된 `T` 인스턴스를 가리켜 야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 변경되지 않아야합니다 (`UnsafeCell` 내부 제외).
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    /// (초기화에 대한 부분은 아직 완전히 결정되지 않았지만, 그것이 될 때까지 유일하게 안전한 방법은 초기화되었는지 확인하는 것입니다.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null 확인되지 않은 버전
    ///
    /// 포인터가 null이 될 수 없다고 확신하고 `Option<&T>` 대신 `&T` 를 반환하는 일종의 `as_ref_unchecked` 를 찾고 있다면 포인터를 직접 역 참조 할 수 있습니다.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // 안전: 호출자는 `self` 가
        // null이 아닌 경우 참조.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// 포인터가 null이면 `None` 를 반환하고 그렇지 않으면 `Some` 에 래핑 된 값에 대한 공유 참조를 반환합니다.
    /// [`as_ref`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 변경 가능한 대응 물은 [`as_uninit_mut`] 를 참조하십시오.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 포인터가 NULL 인 *또는* 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 변경되지 않아야합니다 (`UnsafeCell` 내부 제외).
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // 안전: 발신자는 `self` 가 모든
        // 참조를위한 요구 사항.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// 포인터에서 오프셋을 계산합니다.
    ///
    /// `count` T 단위입니다.예를 들어, `count` 3은 `3 * size_of::<T>()` 바이트의 포인터 오프셋을 나타냅니다.
    ///
    /// # Safety
    ///
    /// 다음 조건 중 하나라도 위반하면 결과는 정의되지 않은 동작입니다.
    ///
    /// * 시작 포인터와 결과 포인터는 모두 동일한 할당 된 개체의 끝을지나 1 바이트 또는 범위 내에 있어야합니다.
    /// Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
    ///
    /// * 계산 된 오프셋 (바이트 단위 **)은 `isize` 를 오버플로 할 수 없습니다.
    ///
    /// * 경계에있는 오프셋은 주소 공간 인 "wrapping around" 에 의존 할 수 없습니다.즉,**바이트 단위** 의 무한 정밀도 합계가 사용에 적합해야합니다.
    ///
    /// 컴파일러와 표준 라이브러리는 일반적으로 할당이 오프셋이 문제가되는 크기에 도달하지 않도록합니다.
    /// 예를 들어 `Vec` 및 `Box` 는 `isize::MAX` 바이트 이상을 할당하지 않도록 보장하므로 `vec.as_ptr().add(vec.len())` 는 항상 안전합니다.
    ///
    /// 대부분의 플랫폼은 근본적으로 그러한 할당을 구성 할 수도 없습니다.
    /// 예를 들어, 알려진 64 비트 플랫폼은 페이지 테이블 제한 또는 주소 공간 분할로 인해 2 <sup>63</sup> 바이트에 대한 요청을 제공 할 수 없습니다.
    /// 그러나 일부 32 비트 및 16 비트 플랫폼은 물리적 주소 확장과 같은 것을 사용하여 `isize::MAX` 바이트 이상의 요청을 성공적으로 제공 할 수 있습니다.
    ///
    /// 따라서 할당 자 또는 메모리 매핑 파일에서 직접 획득 한 메모리는이 함수로 처리하기에는 너무 클 수 있습니다.
    ///
    /// 이러한 제약 조건을 충족하기 어려운 경우 대신 [`wrapping_offset`] 를 사용하는 것이 좋습니다.
    /// 이 방법의 유일한 장점은보다 적극적인 컴파일러 최적화를 가능하게한다는 것입니다.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // 안전: 발신자는 `offset` 에 대한 안전 계약을 유지해야합니다.
        // 호출자는 `self` 와 동일한 할당 된 개체를 가리켜 야하기 때문에 획득 한 포인터는 쓰기에 유효합니다.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// 래핑 산술을 사용하여 포인터에서 오프셋을 계산합니다.
    /// `count` T 단위입니다.예를 들어, `count` 3은 `3 * size_of::<T>()` 바이트의 포인터 오프셋을 나타냅니다.
    ///
    /// # Safety
    ///
    /// 이 작업 자체는 항상 안전하지만 결과 포인터를 사용하는 것은 안전하지 않습니다.
    ///
    /// 결과 포인터는 `self` 가 가리키는 동일한 할당 된 개체에 연결된 상태로 유지됩니다.
    /// 다른 할당 된 객체에 액세스하는 데 사용되지 *않을* 수 있습니다.Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
    ///
    /// 즉, `let z = x.wrapping_offset((y as isize) - (x as isize))` 는 `T` 의 크기가 `1` 이고 오버플로가 없다고 가정하더라도 `z` 를 `y` 와 동일하게 만들지 *않습니다*. `z` 는 `x` 가 연결된 개체에 계속 연결되어 있으며 `x` 및 `x` 가 아닌 경우에는 정의되지 않은 동작입니다. `y` 는 동일한 할당 된 개체를 가리 킵니다.
    ///
    /// [`offset`] 와 비교하여이 방법은 기본적으로 동일한 할당 된 객체 내에 머물러야하는 요구 사항을 지연시킵니다. [`offset`] 는 객체 경계를 넘을 때 즉시 정의되지 않은 동작입니다.`wrapping_offset` 는 포인터를 생성하지만 포인터가 연결된 개체의 범위를 벗어 났을 때 포인터가 역 참조되면 정의되지 않은 동작으로 이어집니다.
    /// [`offset`] 더 잘 최적화 될 수 있으므로 성능에 민감한 코드에서 선호됩니다.
    ///
    /// 지연된 검사는 최종 결과를 계산하는 동안 사용 된 중간 값이 아니라 역 참조 된 포인터의 값만 고려합니다.
    /// 예를 들어, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` 는 항상 `x` 와 동일합니다.즉, 할당 된 객체를 떠난 후 나중에 다시 들어갈 수 있습니다.
    ///
    /// 객체 경계를 넘어야하는 경우 포인터를 정수로 캐스팅하고 거기에서 산술을 수행합니다.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // 두 요소 씩 증가하는 원시 포인터를 사용하여 반복
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // 안전: `arith_offset` 내장 함수에는 호출 할 전제 조건이 없습니다.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// 포인터가 null이면 `None` 를 반환하고 그렇지 않으면 `Some` 에 래핑 된 값에 대한 고유 참조를 반환합니다.값이 초기화되지 않은 경우 [`as_uninit_mut`] 를 대신 사용해야합니다.
    ///
    /// 공유 상대에 대해서는 [`as_ref`] 를 참조하십시오.
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 포인터가 NULL 인 *또는* 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 포인터는 초기화 된 `T` 인스턴스를 가리켜 야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 다른 포인터를 통해 액세스 (읽기 또는 쓰기)되어서는 안됩니다.
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    /// (초기화에 대한 부분은 아직 완전히 결정되지 않았지만, 그것이 될 때까지 유일하게 안전한 방법은 초기화되었는지 확인하는 것입니다.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // 다음과 같이 인쇄됩니다. "[4, 2, 3]".
    /// ```
    ///
    /// # Null 확인되지 않은 버전
    ///
    /// 포인터가 null이 될 수 없다고 확신하고 `Option<&mut T>` 대신 `&mut T` 를 반환하는 일종의 `as_mut_unchecked` 를 찾고 있다면 포인터를 직접 역 참조 할 수 있습니다.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // 다음과 같이 인쇄됩니다. "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // 안전: 발신자는 `self` 가 다음에 대해 유효 함을 보장해야합니다.
        // null이 아닌 경우 변경 가능한 참조.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// 포인터가 null이면 `None` 를 반환하고, 그렇지 않으면 `Some` 에 래핑 된 값에 대한 고유 참조를 반환합니다.
    /// [`as_mut`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 공유 상대에 대해서는 [`as_uninit_ref`] 를 참조하십시오.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 포인터가 NULL 인 *또는* 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터가 올바르게 정렬되어야합니다.
    ///
    /// * [the module documentation] 에 정의 된 의미에서 "dereferencable" 여야합니다.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 다른 포인터를 통해 액세스 (읽기 또는 쓰기)되어서는 안됩니다.
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // 안전: 발신자는 `self` 가 모든
        // 참조를위한 요구 사항.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// 두 포인터가 동일한 지 여부를 반환합니다.
    ///
    /// 런타임에이 함수는 `self == other` 처럼 작동합니다.
    /// 그러나 일부 컨텍스트 (예: 컴파일 타임 평가)에서는 두 포인터의 동일성을 항상 결정할 수있는 것은 아니므로이 함수는 나중에 실제로 동일하다고 판명되는 포인터에 대해 `false` 를 가짜로 반환 할 수 있습니다.
    ///
    /// 그러나 `true` 를 반환하면 포인터가 동일하게 보장됩니다.
    ///
    /// 이 함수는 [`guaranteed_ne`] 의 미러이지만 그 반대는 아닙니다.두 함수 모두 `false` 를 반환하는 포인터 비교가 있습니다.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// 반환 값은 컴파일러 버전에 따라 변경 될 수 있으며 안전하지 않은 코드는 건전성을 위해이 함수의 결과에 의존하지 않을 수 있습니다.
    /// 이 함수에 의한 스퓨리어스 `false` 반환 값이 결과에 영향을 미치지 않고 성능에만 영향을 미치는 성능 최적화에만이 함수를 사용하는 것이 좋습니다.
    /// 이 메서드를 사용하여 런타임 및 컴파일 타임 코드가 다르게 동작하도록하는 결과는 탐색되지 않았습니다.
    /// 이 방법은 이러한 차이점을 도입하는 데 사용되어서는 안되며,이 문제를 더 잘 이해하기 전에 안정화되어서는 안됩니다.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// 두 포인터가 같지 않은지 여부를 반환합니다.
    ///
    /// 런타임에이 함수는 `self != other` 처럼 작동합니다.
    /// 그러나 일부 컨텍스트 (예: 컴파일 타임 평가)에서는 두 포인터의 부등식을 항상 결정할 수있는 것은 아니므로이 함수는 나중에 실제로 동일하지 않은 것으로 판명 된 포인터에 대해 `false` 를 가짜로 반환 할 수 있습니다.
    ///
    /// 그러나 `true` 를 반환하면 포인터가 같지 않음이 보장됩니다.
    ///
    /// 이 함수는 [`guaranteed_eq`] 의 미러이지만 그 반대는 아닙니다.두 함수 모두 `false` 를 반환하는 포인터 비교가 있습니다.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// 반환 값은 컴파일러 버전에 따라 변경 될 수 있으며 안전하지 않은 코드는 건전성을 위해이 함수의 결과에 의존하지 않을 수 있습니다.
    /// 이 함수에 의한 스퓨리어스 `false` 반환 값이 결과에 영향을 미치지 않고 성능에만 영향을 미치는 성능 최적화에만이 함수를 사용하는 것이 좋습니다.
    /// 이 메서드를 사용하여 런타임 및 컴파일 타임 코드가 다르게 동작하도록하는 결과는 탐색되지 않았습니다.
    /// 이 방법은 이러한 차이점을 도입하는 데 사용되어서는 안되며,이 문제를 더 잘 이해하기 전에 안정화되어서는 안됩니다.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// 두 포인터 사이의 거리를 계산합니다.반환 된 값은 T 단위입니다. 바이트 단위의 거리는 `mem::size_of::<T>()` 로 나뉩니다.
    ///
    /// 이 함수는 [`offset`] 의 역입니다.
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// 다음 조건 중 하나라도 위반하면 결과는 정의되지 않은 동작입니다.
    ///
    /// * 시작 포인터와 다른 포인터는 모두 동일한 할당 된 개체의 끝을지나 1 바이트 또는 경계 내에 있어야합니다.
    /// Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
    ///
    /// * 두 포인터는 동일한 객체에 대한 포인터에서 *파생* 되어야합니다.
    ///   (예는 아래를 참조하십시오.)
    ///
    /// * 포인터 사이의 거리 (바이트)는 `T` 크기의 정확한 배수 여야합니다.
    ///
    /// * 포인터 사이의 거리 (**바이트 단위**)는 `isize` 를 오버플로 할 수 없습니다.
    ///
    /// * 경계 내에있는 거리는 주소 공간 인 "wrapping around" 에 의존 할 수 없습니다.
    ///
    /// Rust 유형은 `isize::MAX` 보다 크지 않으며 Rust 할당은 주소 공간을 감싸지 않으므로 Rust 유형 `T` 의 일부 값 내에있는 두 포인터는 항상 마지막 두 조건을 충족합니다.
    ///
    /// 또한 표준 라이브러리는 일반적으로 할당이 오프셋이 문제가되는 크기에 도달하지 않도록 보장합니다.
    /// 예를 들어 `Vec` 및 `Box` 는 `isize::MAX` 바이트 이상을 할당하지 않도록 보장하므로 `ptr_into_vec.offset_from(vec.as_ptr())` 는 항상 마지막 두 조건을 충족합니다.
    ///
    /// 대부분의 플랫폼은 근본적으로 그렇게 큰 할당을 구성 할 수도 없습니다.
    /// 예를 들어, 알려진 64 비트 플랫폼은 페이지 테이블 제한 또는 주소 공간 분할로 인해 2 <sup>63</sup> 바이트에 대한 요청을 제공 할 수 없습니다.
    /// 그러나 일부 32 비트 및 16 비트 플랫폼은 물리적 주소 확장과 같은 것을 사용하여 `isize::MAX` 바이트 이상의 요청을 성공적으로 제공 할 수 있습니다.
    /// 따라서 할당 자 또는 메모리 매핑 파일에서 직접 획득 한 메모리는이 함수로 처리하기에는 너무 클 수 있습니다.
    /// ([`offset`] 및 [`add`] 에도 유사한 제한이 있으므로 이러한 대규모 할당에도 사용할 수 없습니다.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// `T` 가 Zero-Sized Type ("ZST") 인 경우이 함수 panics.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *잘못된* 사용법 :
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // ptr2_other를 ptr2 의 "alias" 로 설정하지만 ptr1 에서 파생됩니다.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // ptr2_other와 ptr2 는 다른 객체에 대한 포인터에서 파생되기 때문에 오프셋 계산은 동일한 주소를 가리 키더라도 정의되지 않은 동작입니다!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // 정의되지 않은 동작
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // 안전: 발신자는 `offset_from` 에 대한 안전 계약을 유지해야합니다.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// 포인터로부터 오프셋을 계산합니다 (`.offset(count as isize)`) 의 경우 편리함).
    ///
    /// `count` T 단위입니다.예를 들어, `count` 3은 `3 * size_of::<T>()` 바이트의 포인터 오프셋을 나타냅니다.
    ///
    /// # Safety
    ///
    /// 다음 조건 중 하나라도 위반하면 결과는 정의되지 않은 동작입니다.
    ///
    /// * 시작 포인터와 결과 포인터는 모두 동일한 할당 된 개체의 끝을지나 1 바이트 또는 범위 내에 있어야합니다.
    /// Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
    ///
    /// * 계산 된 오프셋 (바이트 단위 **)은 `isize` 를 오버플로 할 수 없습니다.
    ///
    /// * 경계에있는 오프셋은 주소 공간 인 "wrapping around" 에 의존 할 수 없습니다.즉, 무한 정밀도 합은 `usize` 에 맞아야합니다.
    ///
    /// 컴파일러와 표준 라이브러리는 일반적으로 할당이 오프셋이 문제가되는 크기에 도달하지 않도록합니다.
    /// 예를 들어 `Vec` 및 `Box` 는 `isize::MAX` 바이트 이상을 할당하지 않도록 보장하므로 `vec.as_ptr().add(vec.len())` 는 항상 안전합니다.
    ///
    /// 대부분의 플랫폼은 근본적으로 그러한 할당을 구성 할 수도 없습니다.
    /// 예를 들어, 알려진 64 비트 플랫폼은 페이지 테이블 제한 또는 주소 공간 분할로 인해 2 <sup>63</sup> 바이트에 대한 요청을 제공 할 수 없습니다.
    /// 그러나 일부 32 비트 및 16 비트 플랫폼은 물리적 주소 확장과 같은 것을 사용하여 `isize::MAX` 바이트 이상의 요청을 성공적으로 제공 할 수 있습니다.
    ///
    /// 따라서 할당 자 또는 메모리 매핑 파일에서 직접 획득 한 메모리는이 함수로 처리하기에는 너무 클 수 있습니다.
    ///
    /// 이러한 제약 조건을 충족하기 어려운 경우 대신 [`wrapping_add`] 를 사용하는 것이 좋습니다.
    /// 이 방법의 유일한 장점은보다 적극적인 컴파일러 최적화를 가능하게한다는 것입니다.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // 안전: 발신자는 `offset` 에 대한 안전 계약을 유지해야합니다.
        unsafe { self.offset(count as isize) }
    }

    /// 포인터로부터 오프셋을 계산합니다 (`.offset ((count as isize).wrapping_neg())`).
    ///
    /// `count` T 단위입니다.예를 들어, `count` 3은 `3 * size_of::<T>()` 바이트의 포인터 오프셋을 나타냅니다.
    ///
    /// # Safety
    ///
    /// 다음 조건 중 하나라도 위반하면 결과는 정의되지 않은 동작입니다.
    ///
    /// * 시작 포인터와 결과 포인터는 모두 동일한 할당 된 개체의 끝을지나 1 바이트 또는 범위 내에 있어야합니다.
    /// Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
    ///
    /// * 계산 된 오프셋은 `isize::MAX`**바이트** 를 초과 할 수 없습니다.
    ///
    /// * 경계에있는 오프셋은 주소 공간 인 "wrapping around" 에 의존 할 수 없습니다.즉, 무한 정밀도 합은 사용에 적합해야합니다.
    ///
    /// 컴파일러와 표준 라이브러리는 일반적으로 할당이 오프셋이 문제가되는 크기에 도달하지 않도록합니다.
    /// 예를 들어 `Vec` 및 `Box` 는 `isize::MAX` 바이트 이상을 할당하지 않도록 보장하므로 `vec.as_ptr().add(vec.len()).sub(vec.len())` 는 항상 안전합니다.
    ///
    /// 대부분의 플랫폼은 근본적으로 그러한 할당을 구성 할 수도 없습니다.
    /// 예를 들어, 알려진 64 비트 플랫폼은 페이지 테이블 제한 또는 주소 공간 분할로 인해 2 <sup>63</sup> 바이트에 대한 요청을 제공 할 수 없습니다.
    /// 그러나 일부 32 비트 및 16 비트 플랫폼은 물리적 주소 확장과 같은 것을 사용하여 `isize::MAX` 바이트 이상의 요청을 성공적으로 제공 할 수 있습니다.
    ///
    /// 따라서 할당 자 또는 메모리 매핑 파일에서 직접 획득 한 메모리는이 함수로 처리하기에는 너무 클 수 있습니다.
    ///
    /// 이러한 제약 조건을 충족하기 어려운 경우 대신 [`wrapping_sub`] 를 사용하는 것이 좋습니다.
    /// 이 방법의 유일한 장점은보다 적극적인 컴파일러 최적화를 가능하게한다는 것입니다.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // 안전: 발신자는 `offset` 에 대한 안전 계약을 유지해야합니다.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// 래핑 산술을 사용하여 포인터에서 오프셋을 계산합니다.
    /// (`.wrapping_offset(count as isize)`) 의 편리함
    ///
    /// `count` T 단위입니다.예를 들어, `count` 3은 `3 * size_of::<T>()` 바이트의 포인터 오프셋을 나타냅니다.
    ///
    /// # Safety
    ///
    /// 이 작업 자체는 항상 안전하지만 결과 포인터를 사용하는 것은 안전하지 않습니다.
    ///
    /// 결과 포인터는 `self` 가 가리키는 동일한 할당 된 개체에 연결된 상태로 유지됩니다.
    /// 다른 할당 된 객체에 액세스하는 데 사용되지 *않을* 수 있습니다.Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
    ///
    /// 즉, `let z = x.wrapping_add((y as usize) - (x as usize))` 는 `T` 의 크기가 `1` 이고 오버플로가 없다고 가정하더라도 `z` 를 `y` 와 동일하게 만들지 *않습니다*. `y` 는 동일한 할당 된 개체를 가리 킵니다.
    ///
    /// [`add`] 와 비교하여이 방법은 기본적으로 동일한 할당 된 객체 내에 머물러야하는 요구 사항을 지연시킵니다. [`add`] 는 객체 경계를 넘을 때 즉각적인 정의되지 않은 동작입니다.`wrapping_add` 는 포인터를 생성하지만 포인터가 연결된 개체의 범위를 벗어 났을 때 포인터가 역 참조되면 정의되지 않은 동작으로 이어집니다.
    /// [`add`] 더 잘 최적화 될 수 있으므로 성능에 민감한 코드에서 선호됩니다.
    ///
    /// 지연된 검사는 최종 결과를 계산하는 동안 사용 된 중간 값이 아니라 역 참조 된 포인터의 값만 고려합니다.
    /// 예를 들어, `x.wrapping_add(o).wrapping_sub(o)` 는 항상 `x` 와 동일합니다.즉, 할당 된 객체를 떠난 후 나중에 다시 들어갈 수 있습니다.
    ///
    /// 객체 경계를 넘어야하는 경우 포인터를 정수로 캐스팅하고 거기에서 산술을 수행합니다.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // 두 요소 씩 증가하는 원시 포인터를 사용하여 반복
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // 이 루프는 "1, 3, 5, " 를 인쇄합니다.
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// 래핑 산술을 사용하여 포인터에서 오프셋을 계산합니다.
    /// (`.wrapping_offset ((count as isize).wrapping_neg())`)
    ///
    /// `count` T 단위입니다.예를 들어, `count` 3은 `3 * size_of::<T>()` 바이트의 포인터 오프셋을 나타냅니다.
    ///
    /// # Safety
    ///
    /// 이 작업 자체는 항상 안전하지만 결과 포인터를 사용하는 것은 안전하지 않습니다.
    ///
    /// 결과 포인터는 `self` 가 가리키는 동일한 할당 된 개체에 연결된 상태로 유지됩니다.
    /// 다른 할당 된 객체에 액세스하는 데 사용되지 *않을* 수 있습니다.Rust 에서 모든 (stack-allocated) 변수는 별도의 할당 된 개체로 간주됩니다.
    ///
    /// 즉, `let z = x.wrapping_sub((x as usize) - (y as usize))` 는 `T` 의 크기가 `1` 이고 오버플로가 없다고 가정하더라도 `z` 를 `y` 와 동일하게 만들지 *않습니다*. `z` 는 `x` 가 연결된 개체에 계속 연결되어 있으며 `x` 및 `x` 가 아닌 경우에는 정의되지 않은 동작입니다. `y` 는 동일한 할당 된 개체를 가리 킵니다.
    ///
    /// [`sub`] 와 비교하여이 방법은 기본적으로 동일한 할당 된 객체 내에 머물러야하는 요구 사항을 지연시킵니다. [`sub`] 는 객체 경계를 넘을 때 즉각적인 정의되지 않은 동작입니다.`wrapping_sub` 는 포인터를 생성하지만 포인터가 연결된 개체의 범위를 벗어 났을 때 포인터가 역 참조되면 정의되지 않은 동작으로 이어집니다.
    /// [`sub`] 더 잘 최적화 될 수 있으므로 성능에 민감한 코드에서 선호됩니다.
    ///
    /// 지연된 검사는 최종 결과를 계산하는 동안 사용 된 중간 값이 아니라 역 참조 된 포인터의 값만 고려합니다.
    /// 예를 들어, `x.wrapping_add(o).wrapping_sub(o)` 는 항상 `x` 와 동일합니다.즉, 할당 된 객체를 떠난 후 나중에 다시 들어갈 수 있습니다.
    ///
    /// 객체 경계를 넘어야하는 경우 포인터를 정수로 캐스팅하고 거기에서 산술을 수행합니다.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // 두 요소 (backwards) 씩 증가하는 원시 포인터를 사용하여 반복
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // 이 루프는 "5, 3, 1, " 를 인쇄합니다.
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// 포인터 값을 `ptr` 로 설정합니다.
    ///
    /// `self` 가 크기가 지정되지 않은 유형에 대한 (fat) 포인터 인 경우이 작업은 포인터 부분에만 영향을 미치는 반면 크기가 지정된 유형에 대한 (thin) 포인터의 경우 단순 할당과 동일한 효과가 있습니다.
    ///
    /// 결과 포인터는 `val` 의 출처를 갖게됩니다. 즉, 팻 포인터의 경우이 작업은 `val` 의 데이터 포인터 값이 있지만 `self` 의 메타 데이터를 사용하여 새 팻 포인터를 만드는 것과 의미 상 동일합니다.
    ///
    ///
    /// # Examples
    ///
    /// 이 함수는 잠재적으로 팻 포인터에서 바이트 단위 포인터 산술을 허용하는 데 주로 유용합니다.
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // "3" 를 인쇄합니다
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // 안전: 얇은 포인터의 경우이 작업은 동일합니다.
        // 간단한 과제에.
        // 팻 포인터의 경우 현재 팻 포인터 레이아웃 구현에서 이러한 포인터의 첫 번째 필드는 항상 마찬가지로 할당 된 데이터 포인터입니다.
        //
        unsafe { *thin = val };
        self
    }

    /// 이동하지 않고 `self` 에서 값을 읽습니다.
    /// 이렇게하면 `self` 의 메모리가 변경되지 않습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::read`] 를 참조하십시오.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // 안전: 발신자는 `` 에 대한 안전 계약을 유지해야합니다.
        unsafe { read(self) }
    }

    /// `self` 에서 값을 이동하지 않고 휘발성 읽기를 수행합니다.이렇게하면 `self` 의 메모리가 변경되지 않습니다.
    ///
    /// 휘발성 작업은 I/O 메모리에서 작동하도록 의도되었으며 다른 휘발성 작업에서 컴파일러에 의해 제거되거나 순서가 변경되지 않습니다.
    ///
    ///
    /// 안전 문제 및 예는 [`ptr::read_volatile`] 를 참조하십시오.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // 안전: 발신자는 `read_volatile` 에 대한 안전 계약을 유지해야합니다.
        unsafe { read_volatile(self) }
    }

    /// 이동하지 않고 `self` 에서 값을 읽습니다.
    /// 이렇게하면 `self` 의 메모리가 변경되지 않습니다.
    ///
    /// `read` 와 달리 포인터가 정렬되지 않을 수 있습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::read_unaligned`] 를 참조하십시오.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // 안전: 발신자는 `read_unaligned` 에 대한 안전 계약을 유지해야합니다.
        unsafe { read_unaligned(self) }
    }

    /// `self` 에서 `dest` 로 `count * size_of<T>` 바이트를 복사합니다.
    /// 소스와 대상이 겹칠 수 있습니다.
    ///
    /// NOTE: 이것은 [`ptr::copy`] 와 *같은* 인수 순서를 갖습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::copy`] 를 참조하십시오.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // 안전: 발신자는 `copy` 에 대한 안전 계약을 유지해야합니다.
        unsafe { copy(self, dest, count) }
    }

    /// `self` 에서 `dest` 로 `count * size_of<T>` 바이트를 복사합니다.
    /// 소스와 대상이 겹치지 *않을* 수 있습니다.
    ///
    /// NOTE: 이것은 [`ptr::copy_nonoverlapping`] 와 *같은* 인수 순서를 갖습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::copy_nonoverlapping`] 를 참조하십시오.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // 안전: 발신자는 `copy_nonoverlapping` 에 대한 안전 계약을 유지해야합니다.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// `src` 에서 `self` 로 `count * size_of<T>` 바이트를 복사합니다.
    /// 소스와 대상이 겹칠 수 있습니다.
    ///
    /// NOTE: 이것은 [`ptr::copy`] 의 *반대* 인수 순서를 갖습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::copy`] 를 참조하십시오.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // 안전: 발신자는 `copy` 에 대한 안전 계약을 유지해야합니다.
        unsafe { copy(src, self, count) }
    }

    /// `src` 에서 `self` 로 `count * size_of<T>` 바이트를 복사합니다.
    /// 소스와 대상이 겹치지 *않을* 수 있습니다.
    ///
    /// NOTE: 이것은 [`ptr::copy_nonoverlapping`] 의 *반대* 인수 순서를 갖습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::copy_nonoverlapping`] 를 참조하십시오.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // 안전: 발신자는 `copy_nonoverlapping` 에 대한 안전 계약을 유지해야합니다.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// 가리키는 값의 소멸자 (있는 경우)를 실행합니다.
    ///
    /// 안전 문제 및 예는 [`ptr::drop_in_place`] 를 참조하십시오.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // 안전: 발신자는 `drop_in_place` 에 대한 안전 계약을 유지해야합니다.
        unsafe { drop_in_place(self) }
    }

    /// 이전 값을 읽거나 삭제하지 않고 주어진 값으로 메모리 위치를 덮어 씁니다.
    ///
    ///
    /// 안전 문제 및 예는 [`ptr::write`] 를 참조하십시오.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // 안전: 발신자는 `write` 에 대한 안전 계약을 유지해야합니다.
        unsafe { write(self, val) }
    }

    /// 지정된 포인터에서 memset을 호출하여 `self` 에서 시작하는 `count * size_of::<T>()` 바이트의 메모리를 `val` 로 설정합니다.
    ///
    ///
    /// 안전 문제 및 예는 [`ptr::write_bytes`] 를 참조하십시오.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // 안전: 발신자는 `write_bytes` 에 대한 안전 계약을 유지해야합니다.
        unsafe { write_bytes(self, val, count) }
    }

    /// 이전 값을 읽거나 삭제하지 않고 주어진 값으로 메모리 위치의 휘발성 쓰기를 수행합니다.
    ///
    /// 휘발성 작업은 I/O 메모리에서 작동하도록 의도되었으며 다른 휘발성 작업에서 컴파일러에 의해 제거되거나 순서가 변경되지 않습니다.
    ///
    ///
    /// 안전 문제 및 예는 [`ptr::write_volatile`] 를 참조하십시오.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // 안전: 발신자는 `write_volatile` 에 대한 안전 계약을 유지해야합니다.
        unsafe { write_volatile(self, val) }
    }

    /// 이전 값을 읽거나 삭제하지 않고 주어진 값으로 메모리 위치를 덮어 씁니다.
    ///
    ///
    /// `write` 와 달리 포인터가 정렬되지 않을 수 있습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::write_unaligned`] 를 참조하십시오.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // 안전: 발신자는 `write_unaligned` 에 대한 안전 계약을 유지해야합니다.
        unsafe { write_unaligned(self, val) }
    }

    /// `self` 의 값을 `src` 로 대체하여 둘 중 하나를 삭제하지 않고 이전 값을 반환합니다.
    ///
    ///
    /// 안전 문제 및 예는 [`ptr::replace`] 를 참조하십시오.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // 안전: 발신자는 `replace` 에 대한 안전 계약을 유지해야합니다.
        unsafe { replace(self, src) }
    }

    /// 초기화를 해제하지 않고 동일한 유형의 변경 가능한 두 위치에서 값을 바꿉니다.
    /// 그렇지 않으면 동등한 `mem::swap` 와 달리 중복 될 수 있습니다.
    ///
    /// 안전 문제 및 예는 [`ptr::swap`] 를 참조하십시오.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // 안전: 발신자는 `swap` 에 대한 안전 계약을 유지해야합니다.
        unsafe { swap(self, with) }
    }

    /// 포인터를 `align` 에 맞추기 위해 포인터에 적용해야하는 오프셋을 계산합니다.
    ///
    /// 포인터를 정렬 할 수없는 경우 구현은 `usize::MAX` 를 반환합니다.
    /// 구현에서 *항상*`usize::MAX` 를 반환하는 것이 허용됩니다.
    /// 알고리즘의 성능 만이 여기에서 사용 가능한 오프셋을 얻는 데 의존 할 수 있으며 정확성이 아닙니다.
    ///
    /// 오프셋은 바이트가 아닌 `T` 요소의 수로 표현됩니다.반환 된 값은 `wrapping_add` 메서드와 함께 사용할 수 있습니다.
    ///
    /// 포인터를 오프셋하는 것이 오버플로되지 않거나 포인터가 가리키는 할당을 초과하지 않는다는 보장은 없습니다.
    ///
    /// 반환 된 오프셋이 정렬 이외의 모든 측면에서 올바른지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    /// # Panics
    ///
    /// `align` 가 2의 거듭 제곱이 아닌 경우 panics 함수입니다.
    ///
    /// # Examples
    ///
    /// 인접한 `u8` 에 `u16` 로 액세스
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // 포인터는 `offset` 를 통해 정렬 될 수 있지만 할당 외부를 가리 킵니다.
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // 안전: `align` 는 위의 2의 거듭 제곱으로 확인되었습니다.
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// 원시 조각의 길이를 반환합니다.
    ///
    /// 반환 된 값은 바이트 수가 아니라 **요소** 의 수입니다.
    ///
    /// 이 함수는 포인터가 null이거나 정렬되지 않았기 때문에 원시 슬라이스를 슬라이스 참조로 캐스트 할 수없는 경우에도 안전합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // 안전: `*const [T]` 와 `FatPtr<T>` 의 레이아웃이 동일하기 때문에 안전합니다.
            // `std` 만이이를 보장 할 수 있습니다.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// 슬라이스의 버퍼에 대한 원시 포인터를 반환합니다.
    ///
    /// 이것은 `self` 를 `*mut T` 로 캐스트하는 것과 동일하지만 형식에 더 안전합니다.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// 경계 검사를 수행하지 않고 요소 또는 하위 조각에 대한 원시 포인터를 반환합니다.
    ///
    /// 범위를 벗어난 인덱스를 사용하여이 메서드를 호출하거나 `self` 가 역 참조 할 수없는 경우 결과 포인터가 사용되지 않더라도 *[정의되지 않은 동작]* 입니다.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // 안전: 발신자는 `self` 가 역 참조 가능하고 `index` 인바운드인지 확인합니다.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// 포인터가 null이면 `None` 를 반환하고, 그렇지 않으면 공유 슬라이스를 `Some` 에 래핑 된 값으로 반환합니다.
    /// [`as_ref`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 변경 가능한 대응 물은 [`as_uninit_slice_mut`] 를 참조하십시오.
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 포인터가 NULL 인 *또는* 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터는 `ptr.len() * mem::size_of::<T>()` 많은 바이트에 대한 읽기의 경우 [valid] 여야하며 올바르게 정렬되어야합니다.이것은 특히 다음을 의미합니다.
    ///
    ///     * 이 슬라이스의 전체 메모리 범위는 할당 된 단일 객체 내에 포함되어야합니다!
    ///       슬라이스는 할당 된 여러 개체에 걸쳐있을 수 없습니다.
    ///
    ///     * 길이가 0 인 슬라이스의 경우에도 포인터를 정렬해야합니다.
    ///     한 가지 이유는 열거 형 레이아웃 최적화가 다른 데이터와 구별하기 위해 정렬되고 널이 아닌 참조 (모든 길이의 슬라이스 포함)에 의존 할 수 있기 때문입니다.
    ///
    ///     [`NonNull::dangling()`] 를 사용하여 길이가 0 인 슬라이스에 대해 `data` 로 사용할 수있는 포인터를 얻을 수 있습니다.
    ///
    /// * 슬라이스의 총 크기 `ptr.len() * mem::size_of::<T>()` 는 `isize::MAX` 보다 크지 않아야합니다.
    ///   [`pointer::offset`] 의 안전 문서를 참조하십시오.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 변경되지 않아야합니다 (`UnsafeCell` 내부 제외).
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [`slice::from_raw_parts`][] 도 참조하십시오.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // 안전: 발신자는 `as_uninit_slice` 에 대한 안전 계약을 유지해야합니다.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// 포인터가 null이면 `None` 를 반환하고, 그렇지 않으면 `Some` 에 래핑 된 값에 고유 한 슬라이스를 반환합니다.
    /// [`as_mut`] 와 달리 값을 초기화 할 필요가 없습니다.
    ///
    /// 공유 상대에 대해서는 [`as_uninit_slice`] 를 참조하십시오.
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// 이 메서드를 호출 할 때 포인터가 NULL 인 *또는* 다음 사항이 모두 참인지 확인해야합니다.
    ///
    /// * 포인터는 `ptr.len() * mem::size_of::<T>()` 많은 바이트에 대한 읽기 및 쓰기의 경우 [valid] 여야하며 적절하게 정렬되어야합니다.이것은 특히 다음을 의미합니다.
    ///
    ///     * 이 슬라이스의 전체 메모리 범위는 할당 된 단일 객체 내에 포함되어야합니다!
    ///       슬라이스는 할당 된 여러 개체에 걸쳐있을 수 없습니다.
    ///
    ///     * 길이가 0 인 슬라이스의 경우에도 포인터를 정렬해야합니다.
    ///     한 가지 이유는 열거 형 레이아웃 최적화가 다른 데이터와 구별하기 위해 정렬되고 널이 아닌 참조 (모든 길이의 슬라이스 포함)에 의존 할 수 있기 때문입니다.
    ///
    ///     [`NonNull::dangling()`] 를 사용하여 길이가 0 인 슬라이스에 대해 `data` 로 사용할 수있는 포인터를 얻을 수 있습니다.
    ///
    /// * 슬라이스의 총 크기 `ptr.len() * mem::size_of::<T>()` 는 `isize::MAX` 보다 크지 않아야합니다.
    ///   [`pointer::offset`] 의 안전 문서를 참조하십시오.
    ///
    /// * 반환 된 수명 `'a` 는 임의로 선택되고 반드시 데이터의 실제 수명을 반영하지 않기 때문에 Rust 의 별칭 규칙을 적용해야합니다.
    ///   특히이 수명 기간 동안 포인터가 가리키는 메모리는 다른 포인터를 통해 액세스 (읽기 또는 쓰기)되어서는 안됩니다.
    ///
    /// 이 방법의 결과가 사용되지 않은 경우에도 적용됩니다!
    ///
    /// [`slice::from_raw_parts_mut`][] 도 참조하십시오.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // 안전: 발신자는 `as_uninit_slice_mut` 에 대한 안전 계약을 유지해야합니다.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// 포인터의 동등성
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}