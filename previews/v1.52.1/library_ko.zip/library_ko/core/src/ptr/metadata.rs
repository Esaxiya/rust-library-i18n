#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// 모든 지정 대상 유형의 포인터 메타 데이터 유형을 제공합니다.
///
/// # 포인터 메타 데이터
///
/// Rust 의 원시 포인터 유형 및 참조 유형은 다음 두 부분으로 구성되어 있다고 생각할 수 있습니다.
/// 값의 메모리 주소와 일부 메타 데이터를 포함하는 데이터 포인터.
///
/// 정적으로 크기가 지정된 유형 (`Sized` traits 를 구현) 및 `extern` 유형의 경우 포인터는 "얇다"라고합니다. 메타 데이터는 크기가 0이고 유형은 `()` 입니다.
///
///
/// [dynamically-sized types][dst] 에 대한 포인터는 "넓음"또는 "두꺼움"이라고하며 크기가 0이 아닌 메타 데이터를 갖습니다.
///
/// * 마지막 필드가 DST 인 구조체의 경우 메타 데이터는 마지막 필드의 메타 데이터입니다.
/// * `str` 유형의 경우 메타 데이터는 `usize` 와 같은 바이트 길이입니다.
/// * `[T]` 와 같은 슬라이스 유형의 경우 메타 데이터는 `usize` 와 같은 항목의 길이입니다.
/// * `dyn SomeTrait` 와 같은 trait 개체의 경우 메타 데이터는 [`DynMetadata<Self>`][DynMetadata] (예: `DynMetadata<dyn SomeTrait>`)입니다.
///
/// future 에서 Rust 언어는 포인터 메타 데이터가 다른 새로운 종류의 유형을 얻을 수 있습니다.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// 이 trait 의 포인트는 위에서 설명한대로 `()` 또는 `usize` 또는 `DynMetadata<_>` 인 `Metadata` 관련 유형입니다.
/// 모든 유형에 대해 자동으로 구현됩니다.
/// 해당 바운드 없이도 일반 컨텍스트에서 구현되는 것으로 가정 할 수 있습니다.
///
/// # Usage
///
/// 원시 포인터는 [`to_raw_parts`] 메서드를 사용하여 데이터 주소 및 메타 데이터 구성 요소로 분해 될 수 있습니다.
///
/// 또는 [`metadata`] 함수를 사용하여 메타 데이터 만 추출 할 수 있습니다.
/// 참조는 [`metadata`] 로 전달되고 암시 적으로 강제 될 수 있습니다.
///
/// (possibly-wide) 포인터는 [`from_raw_parts`] 또는 [`from_raw_parts_mut`] 를 사용하여 주소 및 메타 데이터에서 다시 합칠 수 있습니다.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` 에 대한 포인터 및 참조의 메타 데이터 유형입니다.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` 에서 trait bounds 유지
    //
    // `library/core/src/ptr/metadata.rs` 에서 여기와 동기화됩니다.
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// 이 trait 별칭을 구현하는 유형에 대한 포인터는 "얇습니다".
///
/// 여기에는 정적으로 '크기가 지정된'유형과 `extern` 유형이 포함됩니다.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait 별칭이 언어에서 안정되기 전에 이것을 안정화하지 마십시오?
pub trait Thin = Pointee<Metadata = ()>;

/// 포인터의 메타 데이터 구성 요소를 추출합니다.
///
/// `*mut T`, `&T` 또는 `&mut T` 유형의 값은 암시 적으로 `* const T` 로 강제 변환되므로이 함수에 직접 전달할 수 있습니다.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // 안전: `PtrRepr` 공용체의 값에 액세스하는 것은 * const T이므로 안전합니다.
    // 및 PtrComponents<T>메모리 레이아웃이 동일합니다.
    // std 만이이를 보장 할 수 있습니다.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// 데이터 주소 및 메타 데이터에서 (possibly-wide) 원시 포인터를 형성합니다.
///
/// 이 함수는 안전하지만 반환 된 포인터가 반드시 역 참조에 안전하지는 않습니다.
/// 슬라이스의 경우 안전 요구 사항은 [`slice::from_raw_parts`] 설명서를 참조하십시오.
/// trait 개체의 경우 메타 데이터는 동일한 기본 삭제 유형에 대한 포인터에서 가져와야합니다.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // 안전: `PtrRepr` 공용체의 값에 액세스하는 것은 * const T이므로 안전합니다.
    // 및 PtrComponents<T>메모리 레이아웃이 동일합니다.
    // std 만이이를 보장 할 수 있습니다.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// 원시 `*const` 포인터와 반대로 원시 `* mut` 포인터가 반환된다는 점을 제외하면 [`from_raw_parts`] 와 동일한 기능을 수행합니다.
///
///
/// 자세한 내용은 [`from_raw_parts`] 문서를 참조하십시오.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // 안전: `PtrRepr` 공용체의 값에 액세스하는 것은 * const T이므로 안전합니다.
    // 및 PtrComponents<T>메모리 레이아웃이 동일합니다.
    // std 만이이를 보장 할 수 있습니다.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` 바인딩을 피하기 위해 수동 impl이 필요했습니다.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` 바인딩을 피하기 위해 수동 impl이 필요했습니다.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait 개체 유형에 대한 메타 데이터입니다.
///
/// trait 객체 내에 저장된 구체적인 유형을 조작하는 데 필요한 모든 정보를 나타내는 vtable (가상 호출 테이블)에 대한 포인터입니다.
/// vtable은 특히 다음을 포함합니다.
///
/// * 유형 크기
/// * 유형 정렬
/// * 유형의 `drop_in_place` impl에 대한 포인터 (평범한 이전 데이터의 경우 작동하지 않을 수 있음)
/// * trait 의 유형 구현을위한 모든 메소드에 대한 포인터
///
/// 처음 세 개는 trait 개체를 할당, 삭제 및 할당 해제하는 데 필요하기 때문에 특별합니다.
///
/// `dyn` trait 개체 (예: `DynMetadata<u64>`)가 아닌 형식 매개 변수를 사용하여이 구조체의 이름을 지정할 수 있지만 해당 구조체의 의미있는 값을 얻을 수 없습니다.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// 모든 vtable의 공통 접두사입니다.trait 메서드에 대한 함수 포인터가 뒤에옵니다.
///
/// `DynMetadata::size_of` 등의 개인 구현 세부 정보
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// 이 vtable과 관련된 유형의 크기를 반환합니다.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// 이 vtable과 관련된 유형의 정렬을 반환합니다.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// 크기와 정렬을 함께 `Layout` 로 반환합니다.
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // 안전: 컴파일러는 구체적인 Rust 유형에 대해이 vtable을 내보냈습니다.
        // 유효한 레이아웃이있는 것으로 알려져 있습니다.`Layout::for_value` 와 동일한 근거.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` 경계를 피하기 위해 수동 단순화가 필요했습니다.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}