//! 표준 라이브러리에서 Panic 지원.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic 에 대한 정보를 제공하는 구조체입니다.
///
/// `PanicInfo` 구조체는 [`set_hook`] 함수에 의해 설정된 panic hook 에 전달됩니다.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic 와 관련된 페이로드를 반환합니다.
    ///
    /// 항상 그런 것은 아니지만 일반적으로 `&'static str` 또는 [`String`] 입니다.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate (`std` 가 아님)의 `panic!` 매크로가 형식 지정 문자열 및 일부 추가 인수와 함께 사용 된 경우 예를 들어 [`fmt::write`] 와 함께 사용할 준비가 된 해당 메시지를 반환합니다.
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// 가능한 경우 panic 가 시작된 위치에 대한 정보를 반환합니다.
    ///
    /// 이 메서드는 현재 항상 [`Some`] 를 반환하지만 future 버전에서는 변경 될 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: 가끔 None을 반환하도록 변경하면
        // std::panicking::default_hook 및 std::panicking::begin_panic_fmt 에서이 경우를 처리하십시오.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: downcast_ref: :<String>() 여기
        // libcore에서 String을 사용할 수 없기 때문에!
        // 페이로드는 `std::panic!` 가 여러 인수로 호출 될 때 문자열이지만이 경우 메시지도 사용할 수 있습니다.
        //

        self.location.fmt(formatter)
    }
}

/// panic 의 위치에 대한 정보를 포함하는 구조체입니다.
///
/// 이 구조는 [`PanicInfo::location()`] 에 의해 생성됩니다.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// 동등성과 순서에 대한 비교는 파일, 행, 열 우선 순위에서 이루어집니다.
/// 파일은 `Path` 가 아닌 문자열로 비교됩니다.
/// 자세한 내용은 [`Location: : file`]의 문서를 참조하세요.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// 이 함수 호출자의 소스 위치를 반환합니다.
    /// 해당 함수의 호출자가 주석을 달면 해당 호출 위치가 반환되고 추적되지 않는 함수 본문 내에서 첫 번째 호출까지 스택 위로 올라갑니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// 호출 된 [`Location`] 를 반환합니다.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// 이 함수의 정의 내에서 [`Location`] 를 반환합니다.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // 추적되지 않은 동일한 함수를 다른 위치에서 실행하면 동일한 결과를 얻을 수 있습니다.
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // 추적 된 함수를 다른 위치에서 실행하면 다른 값이 생성됩니다.
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic 가 생성 된 소스 파일의 이름을 반환합니다.
    ///
    /// # `&str`, `&Path` 아님
    ///
    /// 반환 된 이름은 컴파일 시스템의 소스 경로를 참조하지만이를 `&Path` 로 직접 나타내는 것은 유효하지 않습니다.
    /// 컴파일 된 코드는 컨텐츠를 제공하는 시스템과 다른 `Path` 구현으로 다른 시스템에서 실행될 수 있으며이 라이브러리에는 현재 다른 "host path" 유형이 없습니다.
    ///
    /// 가장 놀라운 동작은 모듈 시스템에서 여러 경로를 통해 "the same" 파일에 도달 할 수있는 경우 (일반적으로 `#[path = "..."]` 속성 또는 유사 항목 사용) 발생하며, 이로 인해 동일한 코드로 보이는 것이이 함수에서 다른 값을 반환 할 수 있습니다.
    ///
    ///
    /// # Cross-compilation
    ///
    /// 이 값은 호스트 플랫폼과 대상 플랫폼이 다를 때 `Path::new` 또는 유사한 생성자에 전달하는 데 적합하지 않습니다.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic 가 시작된 줄 번호를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic 가 시작된 열을 반환합니다.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// libstd에서 `panic_unwind` 및 기타 panic 런타임으로 데이터를 전달하기 위해 libstd에서 사용하는 내부 trait 입니다.
/// 조만간 안정 될 예정이 아니므로 사용하지 마십시오.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// 콘텐츠에 대한 완전한 소유권을 갖습니다.
    /// 반환 유형은 실제로 `Box<dyn Any + Send>` 이지만 libcore에서 `Box` 를 사용할 수 없습니다.
    ///
    /// 이 메서드가 호출 된 후 `self` 에는 일부 더미 기본값 만 남습니다.
    /// 이 메서드를 두 번 호출하거나이 메서드를 호출 한 후 `get` 를 호출하면 오류가 발생합니다.
    ///
    /// panic 런타임 (`__rust_start_panic`) 는 차용 된 `dyn BoxMeUp` 만 가져 오기 때문에 인수가 차용되었습니다.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// 내용을 빌리십시오.
    fn get(&mut self) -> &(dyn Any + Send);
}