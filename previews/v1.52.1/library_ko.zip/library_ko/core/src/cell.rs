//! 공유 가능한 변경 가능한 컨테이너.
//!
//! Rust 메모리 안전은이 규칙을 기반으로합니다. 개체 `T` 가 주어지면 다음 중 하나만 가질 수 있습니다.
//!
//! - 객체에 대한 여러 불변 참조 (`&T`) 가 있습니다 (**앨리어싱** 이라고도 함).
//! - 객체에 대한 하나의 가변 참조 (`&mut T`)를 가짐 (**mutability** 라고도 함).
//!
//! 이것은 Rust 컴파일러에 의해 시행됩니다.그러나이 규칙이 충분히 유연하지 않은 상황이 있습니다.때로는 객체에 대한 여러 참조를 가지고 있지만 변경해야하는 경우가 있습니다.
//!
//! 공유 가능한 변경 가능한 컨테이너는 앨리어싱이있는 경우에도 제어 된 방식으로 변경을 허용하기 위해 존재합니다.[`Cell<T>`] 와 [`RefCell<T>`] 모두 단일 스레드 방식으로이를 수행 할 수 있습니다.
//! 그러나 `Cell<T>` 와 `RefCell<T>` 는 스레드로부터 안전하지 않습니다 ([`Sync`] 를 구현하지 않음).
//! 여러 스레드간에 앨리어싱 및 변형을 수행해야하는 경우 [`Mutex<T>`], [`RwLock<T>`] 또는 [`atomic`] 유형을 사용할 수 있습니다.
//!
//! `Cell<T>` 및 `RefCell<T>` 유형의 값은 공유 참조를 통해 변경 될 수 있습니다 (예 :
//! 일반적인 `&T` 유형), 대부분의 Rust 유형은 고유 한 (`&mut T`) 참조를 통해서만 변경 될 수 있습니다.
//! 우리는 `Cell<T>` 및 `RefCell<T>` 가 '상속 된 가변성'을 나타내는 일반적인 Rust 유형과 달리 '내부 가변성'을 제공한다고 말합니다.
//!
//! 세포 유형에는 `Cell<T>` 와 `RefCell<T>` 의 두 가지 유형이 있습니다.`Cell<T>` 는 값을 `Cell<T>` 안팎으로 이동하여 내부 가변성을 구현합니다.
//! 값 대신 참조를 사용하려면 `RefCell<T>` 유형을 사용하여 변경하기 전에 쓰기 잠금을 획득해야합니다.`Cell<T>` 는 현재 내부 값을 검색하고 변경하는 방법을 제공합니다.
//!
//!  - [`Copy`] 를 구현하는 형식의 경우 [`get`](Cell::get) 메서드는 현재 내부 값을 검색합니다.
//!  - [`Default`] 를 구현하는 형식의 경우 [`take`](Cell::take) 메서드는 현재 내부 값을 [`Default::default()`] 로 대체하고 대체 된 값을 반환합니다.
//!  - 모든 유형에 대해 [`replace`](Cell::replace) 메서드는 현재 내부 값을 대체하고 대체 된 값을 반환하고 [`into_inner`](Cell::into_inner) 메서드는 `Cell<T>` 를 소비하고 내부 값을 반환합니다.
//!  또한 [`set`](Cell::set) 메서드는 내부 값을 대체하고 대체 된 값을 삭제합니다.
//!
//! `RefCell<T>` Rust 의 수명을 사용하여 '동적 차용'을 구현합니다.이 프로세스는 내부 값에 대한 일시적이고 배타적이며 변경 가능한 액세스를 요청할 수 있습니다.
//! `RefCell 차용<T>컴파일 타임에 완전히 정적으로 추적되는 Rust 의 기본 참조 유형과 달리`s는 '실행 시간에'추적됩니다.
//! `RefCell<T>` 차용은 동적이기 때문에 이미 가변적으로 차용 한 값을 차용 할 수 있습니다.이 경우 스레드 panic 가 발생합니다.
//!
//! # 내부 가변성을 선택할 때
//!
//! 값을 변경하기 위해 고유 한 액세스 권한을 가져야하는보다 일반적인 상속 된 변경 가능성은 Rust 가 포인터 앨리어싱에 대해 강력하게 추론하여 충돌 버그를 정적으로 방지 할 수 있도록하는 핵심 언어 요소 중 하나입니다.
//! 그 때문에 상속 된 변경 가능성이 선호되고 내부 변경 가능성은 최후의 수단입니다.
//! 세포 유형은 그렇지 않으면 허용되지 않는 돌연변이를 가능하게하기 때문에 내부 돌연변이가 적절할 수 있거나 심지어 *반드시* 사용되는 경우가 있습니다.
//!
//! * 불변의 가변성 'inside' 소개
//! * 논리적으로 변경할 수없는 메서드의 구현 세부 정보입니다.
//! * [`Clone`] 의 변형 구현.
//!
//! ## 불변의 가변성 'inside' 소개
//!
//! [`Rc<T>`] 및 [`Arc<T>`] 를 포함한 많은 공유 스마트 포인터 유형은 여러 당사자간에 복제 및 공유 할 수있는 컨테이너를 제공합니다.
//! 포함 된 값은 다중 앨리어싱 될 수 있으므로 `&mut` 가 아닌 `&` 로만 빌릴 수 있습니다.
//! 셀이 없으면 이러한 스마트 포인터 내부의 데이터를 전혀 변형 할 수 없습니다.
//!
//! 가변성을 다시 도입하기 위해 공유 포인터 유형에 `RefCell<T>` 를 넣는 것은 매우 일반적입니다.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // 동적 차용 범위를 제한하기 위해 새 블록을 만듭니다.
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // 캐시의 이전 대여가 범위를 벗어나도록하지 않은 경우 후속 대여로 인해 동적 스레드 panic 가 발생합니다.
//!     //
//!     // 이것은 `RefCell` 사용의 주요 위험입니다.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! 이 예에서는 `Arc<T>` 가 아닌 `Rc<T>` 를 사용합니다.`RefCell<T>`s는 단일 스레드 시나리오 용입니다.다중 스레드 상황에서 공유 변경이 필요한 경우 [`RwLock<T>`] 또는 [`Mutex<T>`] 사용을 고려하십시오.
//!
//! ## 논리적으로 변경할 수없는 메서드의 구현 세부 정보
//!
//! 때때로 "under the hood" 가 발생하는 돌연변이가 API에 노출되지 않는 것이 바람직 할 수 있습니다.
//! 이것은 논리적으로 연산이 불변하기 때문일 수 있지만, 예를 들어 캐싱은 구현이 변이를 수행하도록 강제합니다.또는 원래 `&self` 를 사용하도록 정의 된 trait 메서드를 구현하려면 변이를 사용해야하기 때문입니다.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // 비싼 계산이 여기에 간다
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` 의 변형 구현
//!
//! 이것은 단순히 특별하지만 일반적인 이전 사례입니다. 변경 불가능한 것처럼 보이는 작업에 대한 변경 가능성 숨기기.
//! [`clone`](Clone::clone) 메서드는 소스 값을 변경하지 않을 것으로 예상되며 `&mut self` 가 아닌 `&self` 를 사용하도록 선언되었습니다.
//! 따라서 `clone` 방법에서 발생하는 모든 돌연변이는 세포 유형을 사용해야합니다.
//! 예를 들어, [`Rc<T>`] 는 `Cell<T>` 내에서 참조 횟수를 유지합니다.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// 변경 가능한 메모리 위치입니다.
///
/// # Examples
///
/// 이 예제에서는 `Cell<T>` 가 변경 불가능한 구조체 내에서 변형을 활성화하는 것을 볼 수 있습니다.
/// 즉, "interior mutability" 를 활성화합니다.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // 오류: `my_struct` 는 변경할 수 없습니다.
/// // my_struct.regular_field =새로운 _ 값;
///
/// // 작동: `my_struct` 는 변경할 수 없지만 `special_field` 는 `Cell` 입니다.
/// // 항상 변경 될 수 있습니다.
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// 자세한 내용은 [module-level documentation](self) 를 참조하십시오.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T에 대한 `Default` 값을 사용하여 `Cell<T>` 를 만듭니다.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// 주어진 값을 포함하는 새로운 `Cell` 를 생성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// 포함 된 값을 설정합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// 두 셀의 값을 바꿉니다.
    /// `std::mem::swap` 와의 차이점은이 함수는 `&mut` 참조가 필요하지 않다는 것입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // 안전: 별도의 스레드에서 호출하면 위험 할 수 있지만 `Cell`
        // `!Sync` 이므로 이런 일이 발생하지 않습니다.
        // `Cell` 는이`셀`중 어느 것도 가리키는 것이 없도록하기 때문에 이것은 또한 포인터를 무효화하지 않습니다.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// 포함 된 값을 `val` 로 바꾸고 이전에 포함 된 값을 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // 안전: 별도의 스레드에서 호출하면 데이터 경합이 발생할 수 있습니다.
        // 하지만 `Cell` 는 `!Sync` 이므로 이런 일이 발생하지 않습니다.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// 값을 풉니 다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// 포함 된 값의 복사본을 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // 안전: 별도의 스레드에서 호출하면 데이터 경합이 발생할 수 있습니다.
        // 하지만 `Cell` 는 `!Sync` 이므로 이런 일이 발생하지 않습니다.
        unsafe { *self.value.get() }
    }

    /// 함수를 사용하여 포함 된 값을 업데이트하고 새 값을 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// 이 셀의 기본 데이터에 대한 원시 포인터를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 기본 데이터에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// 이 호출은 컴파일 타임에 `Cell` 를 가변적으로 차용하여 우리가 유일한 참조를 보유하도록 보장합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` 에서 `&Cell<T>` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // 안전: `&mut` 는 고유 한 액세스를 보장합니다.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// `Default::default()` 는 그대로두고 셀 값을 가져옵니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` 에서 `&[Cell<T>]` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // 안전: `Cell<T>` 는 `T` 와 동일한 메모리 레이아웃을 가지고 있습니다.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// 동적으로 확인되는 차용 규칙이있는 변경 가능한 메모리 위치
///
/// 자세한 내용은 [module-level documentation](self) 를 참조하십시오.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] 에서 반환 된 오류입니다.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] 에서 반환 된 오류입니다.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// 양수 값은 활성 `Ref` 의 수를 나타냅니다.음수 값은 활성 `RefMut` 의 수를 나타냅니다.
// 여러`RefMut`은 `RefCell` 의 별개의 비 중첩 구성 요소 (예: 슬라이스의 다른 범위)를 참조하는 경우에만 한 번에 활성화 될 수 있습니다.
//
// `Ref` `RefMut` 는 둘 다 크기가 두 단어이므로 `usize` 범위의 절반을 오버플로하기에 충분한`Ref` 또는`RefMut`이 존재하지 않을 것입니다.
// 따라서 `BorrowFlag` 는 아마도 오버플로되거나 언더 플로되지 않을 것입니다.
// 그러나 이것은 병리학 적 프로그램이 mem::forget Ref` 또는`RefMut`을 반복적으로 생성 할 수 있기 때문에 보장되지 않습니다.
// 따라서 모든 코드는 안전하지 않은 것을 방지하기 위해 오버플로 및 언더 플로를 명시 적으로 확인해야합니다. 또는 적어도 오버플로 또는 언더 플로가 발생하는 경우 올바르게 작동해야합니다 (예: BorrowRef::new 참조).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` 를 포함하는 새 `RefCell` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` 를 소비하여 래핑 된 값을 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // 이 함수는 `self` (`RefCell`)를 값으로 사용하므로 컴파일러는 현재 차용되지 않았는지 정적으로 확인합니다.
        //
        self.value.into_inner()
    }

    /// 래핑 된 값을 새 값으로 대체하고, 둘 중 하나를 초기화하지 않고 이전 값을 반환합니다.
    ///
    ///
    /// 이 기능은 [`std::mem::replace`](../mem/fn.replace.html) 에 해당합니다.
    ///
    /// # Panics
    ///
    /// 값이 현재 차용 된 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// 래핑 된 값을 `f` 에서 계산 된 새 값으로 대체하고 둘 중 하나를 초기화하지 않고 이전 값을 반환합니다.
    ///
    ///
    /// # Panics
    ///
    /// 값이 현재 차용 된 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// 둘 중 하나를 초기화하지 않고 `self` 의 래핑 된 값을 `other` 의 래핑 된 값으로 바꿉니다.
    ///
    ///
    /// 이 기능은 [`std::mem::swap`](../mem/fn.swap.html) 에 해당합니다.
    ///
    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// 래핑 된 값을 변경없이 차용합니다.
    ///
    /// 대여는 반환 된 `Ref` 가 범위를 벗어날 때까지 지속됩니다.
    /// 여러 개의 불변 차용을 동시에 가져올 수 있습니다.
    ///
    /// # Panics
    ///
    /// 값이 현재 변경 가능하게 차용 된 경우 Panics 입니다.
    /// 당황하지 않는 변형의 경우 [`try_borrow`](#method.try_borrow) 를 사용합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic 의 예 :
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// 래핑 된 값을 변경없이 차용하여 값이 현재 변경 가능하게 차용 된 경우 오류를 반환합니다.
    ///
    ///
    /// 대여는 반환 된 `Ref` 가 범위를 벗어날 때까지 지속됩니다.
    /// 여러 개의 불변 차용을 동시에 가져올 수 있습니다.
    ///
    /// 이것은 [`borrow`](#method.borrow) 의 당황하지 않는 변종입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // 안전: `BorrowRef` 는 변경 불가능한 액세스 만 보장합니다.
            // 빌린 동안 가치에.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// 래핑 된 값을 상호 차용합니다.
    ///
    /// 차용은 반환 된 `RefMut` 또는 그것에서 파생 된 모든`RefMut`이 범위를 종료 할 때까지 지속됩니다.
    ///
    /// 이 차용이 활성화 된 동안에는 값을 차용 할 수 없습니다.
    ///
    /// # Panics
    ///
    /// 값이 현재 차용 된 경우 Panics 입니다.
    /// 당황하지 않는 변형의 경우 [`try_borrow_mut`](#method.try_borrow_mut) 를 사용합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic 의 예 :
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// 래핑 된 값을 상호 차용하여 값이 현재 차용 된 경우 오류를 반환합니다.
    ///
    ///
    /// 차용은 반환 된 `RefMut` 또는 그것에서 파생 된 모든`RefMut`이 범위를 종료 할 때까지 지속됩니다.
    /// 이 차용이 활성화 된 동안에는 값을 차용 할 수 없습니다.
    ///
    /// 이것은 [`borrow_mut`](#method.borrow_mut) 의 당황하지 않는 변종입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // 안전: `BorrowRef` 는 고유 한 액세스를 보장합니다.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// 이 셀의 기본 데이터에 대한 원시 포인터를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 기본 데이터에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// 이 호출은 컴파일 타임에 `RefCell` 를 가변적으로 빌려주므로 동적 검사가 필요하지 않습니다.
    ///
    /// 그러나주의하십시오.이 방법은 `self` 가 변경 가능할 것으로 예상하며 일반적으로 `RefCell` 를 사용할 때는 그렇지 않습니다.
    ///
    /// `self` 가 변경 불가능한 경우 대신 [`borrow_mut`] 메소드를 살펴보십시오.
    ///
    /// 또한이 방법은 특수한 상황에서만 사용할 수 있으며 일반적으로 원하는 방법이 아닙니다.
    /// 의심스러운 경우 [`borrow_mut`] 를 대신 사용하십시오.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// 유출 된 가드가 `RefCell` 의 대여 상태에 미치는 영향을 취소합니다.
    ///
    /// 이 호출은 [`get_mut`] 와 유사하지만 더 전문적입니다.
    /// 차용이 없는지 확인하기 위해 `RefCell` 를 가변적으로 차용 한 다음 공유 차용을 추적하는 상태를 재설정합니다.
    /// 일부 `Ref` 또는 `RefMut` 차용이 유출 된 경우 관련이 있습니다.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// 래핑 된 값을 변경없이 차용하여 값이 현재 변경 가능하게 차용 된 경우 오류를 반환합니다.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` 와 달리이 메서드는 `Ref` 를 반환하지 않기 때문에 안전하지 않으므로 차용 플래그를 그대로 둡니다.
    /// 이 메서드에 의해 반환 된 참조가 살아있는 동안 `RefCell` 를 상호 차용하는 것은 정의되지 않은 동작입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // 안전: 현재 아무도 적극적으로 글을 쓰고 있지 않은지 확인합니다.
            // 반환 된 참조가 더 이상 사용되지 않을 때까지 아무도 쓰지 않도록하는 호출자의 책임입니다.
            // 또한 `self.value.get()` 는 `self` 가 소유 한 값을 나타내므로 `self` 의 수명 동안 유효합니다.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// 래핑 된 값을 가져와 `Default::default()` 를 제자리에 둡니다.
    ///
    /// # Panics
    ///
    /// 값이 현재 차용 된 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// 값이 현재 변경 가능하게 차용 된 경우 Panics 입니다.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T에 대한 `Default` 값을 사용하여 `RefCell<T>` 를 만듭니다.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell` 의 값이 현재 차용 된 경우 Panics 입니다.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // 다음과 같은 경우 차용을 늘리면 읽지 않는 값 (<=0)이 될 수 있습니다.
            // 1. 0보다 작았습니다. 즉, 쓰기 차용이 있으므로 Rust 의 참조 앨리어싱 규칙으로 인해 읽기 차용을 허용 할 수 없습니다.
            // 2.
            // 그것은 isize::MAX (최대 읽기 차용 양)이었고 isize::MIN (최대 쓰기 차용 양)로 넘쳤으므로 isize가 그렇게 많은 읽기 차용을 나타낼 수 없기 때문에 추가 읽기 차용을 허용 할 수 없습니다 (이는 다음 경우에만 발생할 수 있음). 당신은 작은 일정한 양의`Ref`s보다 mem::forget 더 많이 사용합니다.
            //
            //
            //
            //
            None
        } else {
            // 차용을 늘리면 다음과 같은 경우 읽기 값 (> 0)이 될 수 있습니다.
            // 1. =0, 즉 차용되지 않았으며 첫 번째 읽기 차용을 수행합니다.
            // 2. > 0 및 <isize::MAX 였습니다. 즉
            // 읽기 차용이 있었고 isize는 읽기 차용이 하나 더 있음을 나타낼만큼 충분히 큽니다.
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // 이 Ref가 존재하기 때문에, 우리는 차용 플래그가 읽기 차용이라는 것을 압니다.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // 대출 카운터가 쓰기 대출로 넘치지 않도록하십시오.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// 차용 한 참조를 `RefCell` 상자의 값으로 래핑합니다.
/// `RefCell<T>` 에서 불변하게 빌린 값에 대한 래퍼 유형입니다.
///
/// 자세한 내용은 [module-level documentation](self) 를 참조하십시오.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` 를 복사합니다.
    ///
    /// `RefCell` 는 이미 불변 적으로 빌려 왔으므로 실패 할 수 없습니다.
    ///
    /// `Ref::clone(...)` 로 사용되어야하는 관련 기능입니다.
    /// `Clone` 구현 또는 메서드는 `RefCell` 의 내용을 복제하기 위해 `r.borrow().clone()` 의 광범위한 사용을 방해합니다.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// 빌린 데이터의 구성 요소에 대해 새 `Ref` 를 만듭니다.
    ///
    /// `RefCell` 는 이미 불변 적으로 빌려 왔으므로 실패 할 수 없습니다.
    ///
    /// `Ref::map(...)` 로 사용해야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// 빌린 데이터의 선택적 구성 요소에 대해 새 `Ref` 를 만듭니다.
    /// 클로저가 `None` 를 반환하면 원래 가드가 `Err(..)` 로 반환됩니다.
    ///
    /// `RefCell` 는 이미 불변 적으로 빌려 왔으므로 실패 할 수 없습니다.
    ///
    /// `Ref::filter_map(...)` 로 사용되어야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// 빌린 데이터의 다른 구성 요소에 대해 `Ref` 를 여러`Ref`로 분할합니다.
    ///
    /// `RefCell` 는 이미 불변 적으로 빌려 왔으므로 실패 할 수 없습니다.
    ///
    /// `Ref::map_split(...)` 로 사용되어야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// 기본 데이터에 대한 참조로 변환합니다.
    ///
    /// 기본 `RefCell` 는 다시는 변경 불가능하게 빌릴 수 없으며 항상 이미 변경 불가능하게 빌린 것처럼 보입니다.
    ///
    /// 일정한 수 이상의 참조를 유출하는 것은 좋은 생각이 아닙니다.
    /// 총 누수가 적은 경우에만 `RefCell` 를 다시 빌릴 수 있습니다.
    ///
    /// `Ref::leak(...)` 로 사용되어야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // 이 Ref를 잊어 버리면 RefCell의 차용 카운터가 `'b` 수명 내에서 UNUSED로 돌아갈 수 없도록합니다.
        // 참조 추적 상태를 재설정하려면 빌린 RefCell에 대한 고유 한 참조가 필요합니다.
        // 원래 셀에서 더 이상 변경 가능한 참조를 만들 수 없습니다.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// 빌린 데이터의 구성 요소 (예: 열거 형 변형)에 대해 새 `RefMut` 를 만듭니다.
    ///
    /// `RefCell` 는 이미 가변적으로 차용되었으므로 실패 할 수 없습니다.
    ///
    /// `RefMut::map(...)` 로 사용되어야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): 대출 수표 수정
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// 빌린 데이터의 선택적 구성 요소에 대해 새 `RefMut` 를 만듭니다.
    /// 클로저가 `None` 를 반환하면 원래 가드가 `Err(..)` 로 반환됩니다.
    ///
    /// `RefCell` 는 이미 가변적으로 차용되었으므로 실패 할 수 없습니다.
    ///
    /// `RefMut::filter_map(...)` 로 사용되어야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): 대출 수표 수정
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // 안전: 함수는 기간 동안 독점 참조를 유지합니다.
        // `orig` 를 통해 호출되고 포인터는 함수 호출 내에서만 역 참조되므로 배타적 참조가 이스케이프되지 않습니다.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // 안전: 위와 동일합니다.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// 빌린 데이터의 다른 구성 요소에 대해 `RefMut` 를 여러`RefMut`으로 분할합니다.
    ///
    /// 기본 `RefCell` 는 반환 된`RefMut`이 모두 범위를 벗어날 때까지 변경 가능하게 차용 된 상태로 유지됩니다.
    ///
    /// `RefCell` 는 이미 가변적으로 차용되었으므로 실패 할 수 없습니다.
    ///
    /// `RefMut::map_split(...)` 로 사용되어야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// 기본 데이터에 대한 변경 가능한 참조로 변환합니다.
    ///
    /// 기본 `RefCell` 는 다시 빌릴 수 없으며 항상 이미 변경 가능하게 빌려서 표시되므로 반환 된 참조는 내부에 대한 유일한 참조가됩니다.
    ///
    ///
    /// `RefMut::leak(...)` 로 사용되어야하는 관련 기능입니다.
    /// 메서드는 `Deref` 를 통해 사용되는 `RefCell` 의 내용에서 동일한 이름의 메서드를 방해합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // 이 BorrowRefMut을 잊어 버림으로써 RefCell의 차입 카운터가 `'b` 수명 내에 UNUSED로 돌아갈 수 없도록합니다.
        // 참조 추적 상태를 재설정하려면 빌린 RefCell에 대한 고유 한 참조가 필요합니다.
        // 해당 수명 내에서 원래 셀에서 더 이상 참조를 만들 수 없으므로 현재는 남은 수명에 대한 유일한 참조가됩니다.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone 와 달리 new는 이니셜을 생성하기 위해 호출됩니다.
        // 가변 참조이므로 현재 기존 참조가 없어야합니다.
        // 따라서 clone은 가변 참조 횟수를 증가시키는 반면, 여기서는 UNUSED에서 UNUSED, 1로만 이동하는 것을 명시 적으로 허용합니다.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` 를 복제합니다.
    //
    // 이것은 각각의 `BorrowRefMut` 가 원래 객체의 뚜렷하고 겹치지 않는 범위에 대한 가변 참조를 추적하는 데 사용되는 경우에만 유효합니다.
    //
    // 이것은 Clone impl에 없으므로 코드가 이것을 암시 적으로 호출하지 않습니다.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // 대출 카운터가 흘러 내리지 않도록하십시오.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` 에서 변경 가능하게 빌린 값에 대한 래퍼 유형입니다.
///
/// 자세한 내용은 [module-level documentation](self) 를 참조하십시오.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust 의 내부 가변성을위한 핵심 프리미티브입니다.
///
/// 참조 `&T` 가있는 경우 일반적으로 Rust 에서 컴파일러는 `&T` 가 불변 데이터를 가리키는 지식을 기반으로 최적화를 수행합니다.예를 들어 별칭을 통해 또는 `&T` 를 `&mut T` 로 변환하여 해당 데이터를 변경하는 것은 정의되지 않은 동작으로 간주됩니다.
/// `UnsafeCell<T>` `&T` 에 대한 불변성 보장 옵트 아웃: 공유 참조 `&UnsafeCell<T>` 는 변경되는 데이터를 가리킬 수 있습니다.이것을 "interior mutability" 라고합니다.
///
/// `Cell<T>` 및 `RefCell<T>` 와 같이 내부 변경을 허용하는 다른 모든 유형은 내부적으로 `UnsafeCell` 를 사용하여 데이터를 래핑합니다.
///
/// 공유 참조에 대한 불변성 보장 만 `UnsafeCell` 의 영향을받습니다.변경 가능한 참조에 대한 고유성 보장은 영향을받지 않습니다.`UnsafeCell<T>` 를 사용하더라도 `&mut` 앨리어싱을 얻는 합법적 인 방법은 *없습니다*.
///
/// `UnsafeCell` API 자체는 기술적으로 매우 간단합니다. [`.get()`] 는 콘텐츠에 대한 원시 포인터 `*mut T` 를 제공합니다.원시 포인터를 올바르게 사용하는 것은 추상화 디자이너로서 _you_ 에 달려 있습니다.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// 정확한 Rust 앨리어싱 규칙은 다소 유동적이지만 요점은 논쟁의 여지가 없습니다.
///
/// - 안전 코드로 액세스 할 수있는 수명 `'a` (`&T` 또는 `&mut T` 참조)를 사용하여 안전 참조를 생성하는 경우 (예: 반환했기 때문에) 나머지에 대한 해당 참조와 모순되는 방식으로 데이터에 액세스해서는 안됩니다. `'a` 의.
/// 예를 들어, 이는 `UnsafeCell<T>` 에서 `*mut T` 를 가져와 `&T` 로 캐스트하는 경우 해당 참조의 수명이 만료 될 때까지 `T` 의 데이터는 변경 불가능한 상태로 유지되어야합니다 (물론 `T` 내에서 발견 된 모든 `UnsafeCell` 데이터를 모듈로).
/// 마찬가지로 안전한 코드로 릴리스되는 `&mut T` 참조를 생성하는 경우 해당 참조가 만료 될 때까지 `UnsafeCell` 내의 데이터에 액세스해서는 안됩니다.
///
/// - 항상 데이터 경쟁을 피해야합니다.여러 스레드가 동일한 `UnsafeCell` 에 액세스 할 수있는 경우 모든 쓰기는 다른 모든 액세스 (또는 원 자성 사용)와 관련하여 적절한 발생 전 관계를 가져야합니다.
///
/// 적절한 디자인을 지원하기 위해 다음 시나리오는 단일 스레드 코드에 대해 합법적으로 명시 적으로 선언됩니다.
///
/// 1. `&T` 참조는 안전한 코드로 해제 될 수 있으며 다른 `&T` 참조와 공존 할 수 있지만 `&mut T` 와는 공존 할 수 없습니다.
///
/// 2. `&mut T` 참조는 다른 `&mut T` 나 `&T` 가 공존하지 않는 경우 안전한 코드로 해제 될 수 있습니다.`&mut T` 는 항상 고유해야합니다.
///
/// `&UnsafeCell<T>` 의 내용을 변경하는 동안 (다른 `&UnsafeCell<T>` 가 셀 별칭을 참조하는 경우에도) 괜찮지 만 (위의 불변을 다른 방식으로 적용하는 경우) 여러 `&mut UnsafeCell<T>` 별칭을 갖는 것은 여전히 정의되지 않은 동작입니다.
/// 즉, `UnsafeCell` 는 `&UnsafeCell<_>` 참조를 통해 _shared_ accesses (_i.e._ 와 특별한 상호 작용을 갖도록 설계된 래퍼입니다.`&mut UnsafeCell<_>` 를 통해 _exclusive_ accesses (_e.g._ 를 다룰 때 마술은 전혀 없습니다): `&mut` 차용 기간 동안 셀이나 래핑 된 값 모두 별칭을 지정할 수 없습니다.
///
/// 이것은 `&mut T` 를 생성하는 _safe_ getter 인 [`.get_mut()`] 접근 자에 의해 표시됩니다.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// 다음은 셀의 별칭을 지정하는 여러 참조가 있음에도 불구하고 `UnsafeCell<_>` 의 내용을 제대로 변경하는 방법을 보여주는 예입니다.
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // 동일한 `x` 에 대한 여러/동시/공유 참조를 가져옵니다.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // 안전: 이 범위 내에는`x`의 내용에 대한 다른 참조가 없습니다.
///     // 그래서 우리는 사실상 독특합니다.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- 빌리다-+
///     *p1_exclusive += 27; // |
/// } // <---------- 이 지점을 넘어갈 수 없다 -------------------+
///
/// unsafe {
///     // 안전: 이 범위 내에서 아무도`x`의 콘텐츠에 대한 독점적 접근을 기대하지 않습니다.
///     // 동시에 여러 개의 공유 액세스를 가질 수 있습니다.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// 다음 예는 `UnsafeCell<T>` 에 대한 배타적 액세스가 `T` 에 대한 배타적 액세스를 의미한다는 사실을 보여줍니다.
///
/// ```rust
/// #![forbid(unsafe_code)] // 독점적 접근으로
///                         // `UnsafeCell` 투명한 no-op 래퍼이므로 여기서 `unsafe` 가 필요하지 않습니다.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // 컴파일 시간이 확인 된 `x` 에 대한 고유 참조를 가져옵니다.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // 독점 참조를 통해 무료로 내용을 변경할 수 있습니다.
/// *p_unique.get_mut() = 0;
/// // 또는 동등하게 :
/// x = UnsafeCell::new(0);
///
/// // 가치를 소유하면 무료로 콘텐츠를 추출 할 수 있습니다.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// 지정된 값을 래핑 할 `UnsafeCell` 의 새 인스턴스를 생성합니다.
    ///
    ///
    /// 메서드를 통한 내부 값에 대한 모든 액세스는 `unsafe` 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// 값을 풉니 다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// 래핑 된 값에 대한 변경 가능한 포인터를 가져옵니다.
    ///
    /// 이것은 모든 종류의 포인터로 캐스트 될 수 있습니다.
    /// `&mut T` 로 캐스팅 할 때 액세스가 고유한지 (활성 참조 없음, 변경 가능 여부) 확인하고 `&T` 로 캐스팅 할 때 진행되는 변경 또는 변경 가능한 별칭이 없는지 확인합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] 때문에 `UnsafeCell<T>` 에서 `T` 로 포인터를 캐스팅 할 수 있습니다.
        // 이것은 libstd의 특별한 상태를 악용합니다. 사용자 코드가 future 버전의 컴파일러에서 작동한다는 보장은 없습니다!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// 기본 데이터에 대한 변경 가능한 참조를 반환합니다.
    ///
    /// 이 호출은 `UnsafeCell` 를 (컴파일 시간에) 변경 가능하게 빌려 우리가 유일한 참조를 소유하도록 보장합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// 래핑 된 값에 대한 변경 가능한 포인터를 가져옵니다.
    /// [`get`] 와의 차이점은이 함수는 원시 포인터를 받아들이므로 임시 참조 생성을 피하는 데 유용합니다.
    ///
    /// 결과는 모든 종류의 포인터로 캐스트 될 수 있습니다.
    /// `&mut T` 로 캐스팅 할 때 액세스가 고유한지 (활성 참조 없음, 변경 가능 여부) 확인하고 `&T` 로 캐스팅 할 때 진행되는 변경 또는 변경 가능한 별칭이 없는지 확인합니다.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `get` 를 호출하려면 초기화되지 않은 데이터에 대한 참조를 만들어야하므로 `UnsafeCell` 를 점진적으로 초기화하려면 `raw_get` 가 필요합니다.
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] 때문에 `UnsafeCell<T>` 에서 `T` 로 포인터를 캐스팅 할 수 있습니다.
        // 이것은 libstd의 특별한 상태를 악용합니다. 사용자 코드가 future 버전의 컴파일러에서 작동한다는 보장은 없습니다!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T에 대한 `Default` 값을 사용하여 `UnsafeCell` 를 만듭니다.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}