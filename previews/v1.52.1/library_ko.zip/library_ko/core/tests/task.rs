use core::task::Poll;

#[test]
fn poll_const() {
    // `Poll` 의 메서드를 const 컨텍스트에서 사용할 수 있는지 테스트

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}