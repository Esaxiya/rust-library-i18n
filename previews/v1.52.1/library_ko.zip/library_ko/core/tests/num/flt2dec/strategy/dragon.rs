use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri가 너무 느립니다
fn exact_sanity_test() {
    // 이 테스트는 우리가 사용하는 C 런타임에 정의 된 `exp2` 라이브러리 함수의 일부 모퉁이 같은 경우라고 가정 할 수있는 것만 실행합니다.
    // VS 2013에서는이 테스트가 연결될 때 실패하므로이 기능에 버그가있는 것 같지만 VS 2015에서는 테스트가 제대로 실행되므로 버그가 수정 된 것으로 보입니다.
    //
    // 버그는 `exp2(-1057)` 의 반환 값의 차이 인 것 같습니다. VS 2013에서는 비트 패턴 0x2 와 함께 double을 반환하고 VS 2015에서는 0x20000 를 반환합니다.
    //
    //
    // 지금은 MSVC에서이 테스트를 완전히 무시하십시오. 어쨌든 다른 곳에서 테스트되었으므로 각 플랫폼의 exp2 구현을 테스트하는 데는 별 관심이 없습니다.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}