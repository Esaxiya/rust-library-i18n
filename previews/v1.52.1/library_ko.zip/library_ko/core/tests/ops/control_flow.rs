use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // 이것은 안정적인 표면적이 아니지만 LLVM이 항상 그것을 활용할 수는 없지만 `?` 를 저렴하게 유지하는 데 도움이됩니다.
    //
    // (슬프게도 결과와 옵션이 일치하지 않으므로 ControlFlow는 둘 다 일치시킬 수 없습니다.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}