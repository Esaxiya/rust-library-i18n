mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flat_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod peekable;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

use core::cell::Cell;

/// `None` 가 이미 반환 된 후 `next` 또는 next_back`이 호출 될 때마다 panics 하는 반복기입니다.
/// 이것은`Iterator`의 계약을 위반하지 않습니다.
/// 반복기 어댑터가 내부 반복기를 소진 한 후 폴링하지 않는지 테스트하는 데 사용됩니다.
///
pub struct NonFused<I> {
    iter: I,
    done: bool,
}

impl<I> NonFused<I> {
    pub fn new(iter: I) -> Self {
        Self { iter, done: false }
    }
}

impl<I> Iterator for NonFused<I>
where
    I: Iterator,
{
    type Item = I::Item;

    fn next(&mut self) -> Option<Self::Item> {
        assert!(!self.done, "this iterator has already returned None");
        self.iter.next().or_else(|| {
            self.done = true;
            None
        })
    }
}

impl<I> DoubleEndedIterator for NonFused<I>
where
    I: DoubleEndedIterator,
{
    fn next_back(&mut self) -> Option<Self::Item> {
        assert!(!self.done, "this iterator has already returned None");
        self.iter.next_back().or_else(|| {
            self.done = true;
            None
        })
    }
}

/// `None` 가 반환 된 후 `next` 또는 `next_back` 가 호출 될 때마다 panics 하는 반복기 래퍼입니다.
///
pub struct Unfuse<I> {
    iter: I,
    exhausted: bool,
}

impl<I> Unfuse<I> {
    pub fn new<T>(iter: T) -> Self
    where
        T: IntoIterator<IntoIter = I>,
    {
        Self { iter: iter.into_iter(), exhausted: false }
    }
}

impl<I> Iterator for Unfuse<I>
where
    I: Iterator,
{
    type Item = I::Item;

    fn next(&mut self) -> Option<Self::Item> {
        assert!(!self.exhausted);
        let next = self.iter.next();
        self.exhausted = next.is_none();
        next
    }
}

impl<I> DoubleEndedIterator for Unfuse<I>
where
    I: DoubleEndedIterator,
{
    fn next_back(&mut self) -> Option<Self::Item> {
        assert!(!self.exhausted);
        let next = self.iter.next_back();
        self.exhausted = next.is_none();
        next
    }
}

pub struct Toggle {
    is_empty: bool,
}

impl Iterator for Toggle {
    type Item = ();

    // `None` 와 `Some(())` 를 번갈아 가며
    fn next(&mut self) -> Option<Self::Item> {
        if self.is_empty {
            self.is_empty = false;
            None
        } else {
            self.is_empty = true;
            Some(())
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty { (0, Some(0)) } else { (1, Some(1)) }
    }
}

impl DoubleEndedIterator for Toggle {
    fn next_back(&mut self) -> Option<Self::Item> {
        self.next()
    }
}

/// 이것은 Iterator 계약을 따르는 반복자이지만 융합되지는 않습니다.
/// None을 한 번 반환 한 후 .next() 가 다시 호출되면 요소 생성을 시작합니다.
///
pub struct CycleIter<'a, T> {
    index: usize,
    data: &'a [T],
}

impl<'a, T> CycleIter<'a, T> {
    pub fn new(data: &'a [T]) -> Self {
        Self { index: 0, data }
    }
}

impl<'a, T> Iterator for CycleIter<'a, T> {
    type Item = &'a T;
    fn next(&mut self) -> Option<Self::Item> {
        let elt = self.data.get(self.index);
        self.index += 1;
        self.index %= 1 + self.data.len();
        elt
    }
}

#[derive(Debug)]
struct CountClone(Cell<i32>);

impl CountClone {
    pub fn new() -> Self {
        Self(Cell::new(0))
    }
}

impl PartialEq<i32> for CountClone {
    fn eq(&self, rhs: &i32) -> bool {
        self.0.get() == *rhs
    }
}

impl Clone for CountClone {
    fn clone(&self) -> Self {
        let ret = CountClone(self.0.clone());
        let n = self.0.get();
        self.0.set(n + 1);
        ret
    }
}