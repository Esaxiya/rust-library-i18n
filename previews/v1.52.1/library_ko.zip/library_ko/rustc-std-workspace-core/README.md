# `rustc-std-workspace-core` crate

이 crate 는 단순히 `libcore` 에 의존하고 모든 내용을 다시 내보내는 shim 및 빈 crate 입니다.
crate 는 표준 라이브러리가 crates.io 의 crates 에 의존하도록 권한을 부여하는 핵심입니다.

표준 라이브러리가 의존하는 crates.io 의 Crates 는 비어있는 crates.io 의 `rustc-std-workspace-core` crate 에 의존해야합니다.

`[patch]` 를 사용하여이 저장소의이 crate 로 재정의합니다.
결과적으로 crates.io 의 crates 는이 저장소에 정의 된 버전 인 `libcore` 에 대한 종속성 edge 를 끌어옵니다.
Cargo 가 crates 를 성공적으로 빌드하도록 모든 종속성 가장자리를 그려야합니다!

모든 것이 올바르게 작동하려면 crates.io 의 crates 가 이름이 `core` 인이 crate 에 의존해야합니다.이를 위해 다음을 사용할 수 있습니다.

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` 키를 사용하면 crate 의 이름이 `core` 로 변경되어 다음과 같이 표시됩니다.

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo 가 컴파일러를 호출 할 때 컴파일러에 의해 주입 된 암시 적 `extern crate core` 지시문을 충족합니다.




