//! `Cell` (scoped) 실존 수명에 대한 변형.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// 수명이있는 람다 애플리케이션을 입력합니다.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// 일생을 취하는 유형 람다, 즉, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) newtype FIXME(#52812) 를 사용하여 프로젝션 제한 사항을 해결하고 `&'a mut <T as ApplyL<'b>>::Out` 로 교체
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` 를 실행하는 동안 `self` 의 값을 `replacement` 로 설정하여 이전 값을 변경합니다.
    /// 이전 값은 `f` 에 의한 수정을 포함하여 panic 에 의해서도 `f` 가 종료 된 후 복원됩니다.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// `f` 가 패닉 상태 인 경우에도 셀이 항상 채워지도록 보장하는 래퍼입니다 (원래 상태로 선택적으로 `f` 에 의해 변경됨).
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` 를 실행하는 동안 `self` 의 값을 `value` 로 설정합니다.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}