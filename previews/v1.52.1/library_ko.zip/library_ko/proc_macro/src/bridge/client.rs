//! 클라이언트 측 유형.

use super::*;

macro_rules! define_handles {
    (
        'owned: $($oty:ident,)*
        'interned: $($ity:ident,)*
    ) => {
        #[repr(C)]
        #[allow(non_snake_case)]
        pub struct HandleCounters {
            $($oty: AtomicUsize,)*
            $($ity: AtomicUsize,)*
        }

        impl HandleCounters {
            // FIXME(eddyb) `const fn` 가 '정적'을 참조 할 수 있으면 래퍼 `fn` 포인터 대신 `static COUNTERS` 에 대한 참조를 사용합니다.
            //
            extern "C" fn get() -> &'static Self {
                static COUNTERS: HandleCounters = HandleCounters {
                    $($oty: AtomicUsize::new(1),)*
                    $($ity: AtomicUsize::new(1),)*
                };
                &COUNTERS
            }
        }

        // FIXME(eddyb) `server.rs` 에서 `HandleStore` 의 정의를 생성합니다.
        #[repr(C)]
        #[allow(non_snake_case)]
        pub(super) struct HandleStore<S: server::Types> {
            $($oty: handle::OwnedStore<S::$oty>,)*
            $($ity: handle::InternedStore<S::$ity>,)*
        }

        impl<S: server::Types> HandleStore<S> {
            pub(super) fn new(handle_counters: &'static HandleCounters) -> Self {
                HandleStore {
                    $($oty: handle::OwnedStore::new(&handle_counters.$oty),)*
                    $($ity: handle::InternedStore::new(&handle_counters.$ity),)*
                }
            }
        }

        $(
            #[repr(C)]
            pub(crate) struct $oty(handle::Handle);
            impl !Send for $oty {}
            impl !Sync for $oty {}

            // `Drop::drop` 를 고유 한 `drop` 방법으로 전달합니다.
            impl Drop for $oty {
                fn drop(&mut self) {
                    $oty(self.0).drop();
                }
            }

            impl<S> Encode<S> for $oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    let handle = self.0;
                    mem::forget(self);
                    handle.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, '_, HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$oty, $oty>
            {
                fn decode(r: &mut Reader<'_>, s: &mut HandleStore<server::MarkedTypes<S>>) -> Self {
                    s.$oty.take(handle::Handle::decode(r, &mut ()))
                }
            }

            impl<S> Encode<S> for &$oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> Decode<'_, 's, HandleStore<server::MarkedTypes<S>>>
                for &'s Marked<S::$oty, $oty>
            {
                fn decode(r: &mut Reader<'_>, s: &'s HandleStore<server::MarkedTypes<S>>) -> Self {
                    &s.$oty[handle::Handle::decode(r, &mut ())]
                }
            }

            impl<S> Encode<S> for &mut $oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, 's, HandleStore<server::MarkedTypes<S>>>
                for &'s mut Marked<S::$oty, $oty>
            {
                fn decode(
                    r: &mut Reader<'_>,
                    s: &'s mut HandleStore<server::MarkedTypes<S>>
                ) -> Self {
                    &mut s.$oty[handle::Handle::decode(r, &mut ())]
                }
            }

            impl<S: server::Types> Encode<HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$oty, $oty>
            {
                fn encode(self, w: &mut Writer, s: &mut HandleStore<server::MarkedTypes<S>>) {
                    s.$oty.alloc(self).encode(w, s);
                }
            }

            impl<S> DecodeMut<'_, '_, S> for $oty {
                fn decode(r: &mut Reader<'_>, s: &mut S) -> Self {
                    $oty(handle::Handle::decode(r, s))
                }
            }
        )*

        $(
            #[repr(C)]
            #[derive(Copy, Clone, PartialEq, Eq, Hash)]
            pub(crate) struct $ity(handle::Handle);
            impl !Send for $ity {}
            impl !Sync for $ity {}

            impl<S> Encode<S> for $ity {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, '_, HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$ity, $ity>
            {
                fn decode(r: &mut Reader<'_>, s: &mut HandleStore<server::MarkedTypes<S>>) -> Self {
                    s.$ity.copy(handle::Handle::decode(r, &mut ()))
                }
            }

            impl<S: server::Types> Encode<HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$ity, $ity>
            {
                fn encode(self, w: &mut Writer, s: &mut HandleStore<server::MarkedTypes<S>>) {
                    s.$ity.alloc(self).encode(w, s);
                }
            }

            impl<S> DecodeMut<'_, '_, S> for $ity {
                fn decode(r: &mut Reader<'_>, s: &mut S) -> Self {
                    $ity(handle::Handle::decode(r, s))
                }
            }
        )*
    }
}
define_handles! {
    'owned:
    FreeFunctions,
    TokenStream,
    TokenStreamBuilder,
    TokenStreamIter,
    Group,
    Literal,
    SourceFile,
    MultiSpan,
    Diagnostic,

    'interned:
    Punct,
    Ident,
    Span,
}

// FIXME(eddyb) 메서드 이름에 대한 패턴 일치를 통해 이러한 impls를 생성하고 `fn drop` 의 존재를 사용하여 위의 '소유 및'인턴 '을 구분할 수 있습니다.
//
// 또는 여기와 서버 decl에서 메서드에 대한 패턴 일치 대신 with_api에 특수 '모드'유형이 나열 될 수 있습니다.
//
//

impl Clone for TokenStream {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for TokenStreamIter {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for Group {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for Literal {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Literal")
            // `kind: Float` 에서와 같이 따옴표없이 종류 형식 지정
            .field("kind", &format_args!("{}", &self.debug_kind()))
            .field("symbol", &self.symbol())
            // {:#?} 모드에서도 한 줄에 `Some("...")` 포맷
            .field("suffix", &format_args!("{:?}", &self.suffix()))
            .field("span", &self.span())
            .finish()
    }
}

impl Clone for SourceFile {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.debug())
    }
}

macro_rules! define_client_side {
    ($($name:ident {
        $(fn $method:ident($($arg:ident: $arg_ty:ty),* $(,)?) $(-> $ret_ty:ty)*;)*
    }),* $(,)?) => {
        $(impl $name {
            $(pub(crate) fn $method($($arg: $arg_ty),*) $(-> $ret_ty)* {
                Bridge::with(|bridge| {
                    let mut b = bridge.cached_buffer.take();

                    b.clear();
                    api_tags::Method::$name(api_tags::$name::$method).encode(&mut b, &mut ());
                    reverse_encode!(b; $($arg),*);

                    b = bridge.dispatch.call(b);

                    let r = Result::<_, PanicMessage>::decode(&mut &b[..], &mut ());

                    bridge.cached_buffer = b;

                    r.unwrap_or_else(|e| panic::resume_unwind(e.into()))
                })
            })*
        })*
    }
}
with_api!(self, self, define_client_side);

enum BridgeState<'a> {
    /// 현재이 클라이언트에 연결된 서버가 없습니다.
    NotConnected,

    /// 서버가 연결되어 있으며 요청에 사용할 수 있습니다.
    Connected(Bridge<'a>),

    /// 브리지에 대한 액세스 권한이 독점적으로 획득됩니다 (예: `BridgeState::with` 동안).
    ///
    InUse,
}

enum BridgeStateL {}

impl<'a> scoped_cell::ApplyL<'a> for BridgeStateL {
    type Out = BridgeState<'a>;
}

thread_local! {
    static BRIDGE_STATE: scoped_cell::ScopedCell<BridgeStateL> =
        scoped_cell::ScopedCell::new(BridgeState::NotConnected);
}

impl BridgeState<'_> {
    /// 스레드 로컬 `BridgeState` 를 독점적으로 제어하고 `f` 에 변경 가능하게 전달합니다.
    /// 상태는 `f` 에 의한 수정을 포함하여 panic 에서도 `f` 가 종료 된 후 복원됩니다.
    ///
    ///
    /// NB, `f` 가 실행되는 동안 스레드 로컬 상태는 `BridgeState::InUse` 입니다.
    ///
    ///
    fn with<R>(f: impl FnOnce(&mut BridgeState<'_>) -> R) -> R {
        BRIDGE_STATE.with(|state| {
            state.replace(BridgeState::InUse, |mut state| {
                // FIXME(#52812) `RefMutL` 가 사라지면 `f` 를 `replace` 로 직접 전달
                f(&mut *state)
            })
        })
    }
}

impl Bridge<'_> {
    pub(crate) fn is_available() -> bool {
        BridgeState::with(|state| match state {
            BridgeState::Connected(_) | BridgeState::InUse => true,
            BridgeState::NotConnected => false,
        })
    }

    fn enter<R>(self, f: impl FnOnce() -> R) -> R {
        let force_show_panics = self.force_show_panics;
        // `proc_macro` 확장 내에서 기본 panic 출력을 숨 깁니다.
        // NB.서버는 다른 libstd를 사용할 수 있기 때문에 이것을 할 수 없습니다.
        static HIDE_PANICS_DURING_EXPANSION: Once = Once::new();
        HIDE_PANICS_DURING_EXPANSION.call_once(|| {
            let prev = panic::take_hook();
            panic::set_hook(Box::new(move |info| {
                let show = BridgeState::with(|state| match state {
                    BridgeState::NotConnected => true,
                    BridgeState::Connected(_) | BridgeState::InUse => force_show_panics,
                });
                if show {
                    prev(info)
                }
            }));
        });

        BRIDGE_STATE.with(|state| state.set(BridgeState::Connected(self), f))
    }

    fn with<R>(f: impl FnOnce(&mut Bridge<'_>) -> R) -> R {
        BridgeState::with(|state| match state {
            BridgeState::NotConnected => {
                panic!("procedural macro API is used outside of a procedural macro");
            }
            BridgeState::InUse => {
                panic!("procedural macro API is used while it's already in use");
            }
            BridgeState::Connected(bridge) => f(bridge),
        })
    }
}

/// 클라이언트 측 "global object" (일반적으로 함수 포인터). 서버에서 사용하는 `proc_macro` 와 다른 `proc_macro` 를 사용할 수 있지만 호환 가능하게 상호 작용할 수 있습니다.
///
///
/// NB, `F` 에는 FFI 친화적 인 메모리 레이아웃 (예: 포인터)이 있어야합니다.
/// `F` 에 사용되는 함수 포인터의 호출 ABI는 서버와 클라이언트간에 일치 할 필요가 없습니다. 클라이언트가 호출하는 (eventually) 와 서버간에 만 전달되기 때문입니다.
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
pub struct Client<F> {
    // FIXME(eddyb) `const fn` 가 '정적'을 참조 할 수 있으면 래퍼 `fn` 포인터 대신 `static COUNTERS` 에 대한 참조를 사용합니다.
    //
    pub(super) get_handle_counters: extern "C" fn() -> &'static HandleCounters,
    pub(super) run: extern "C" fn(Bridge<'_>, F) -> Buffer<u8>,
    pub(super) f: F,
}

/// 클라이언트 panics 처리, 브리지 입력, 입력 직렬화 해제 및 출력 직렬화를위한 클라이언트 측 도우미입니다.
///
// FIXME(eddyb) `Bridge::enter` 를 이것으로 대체할까요?
fn run_client<A: for<'a, 's> DecodeMut<'a, 's, ()>, R: Encode<()>>(
    mut bridge: Bridge<'_>,
    f: impl FnOnce(A) -> R,
) -> Buffer<u8> {
    // 초기 `cached_buffer` 에는 입력이 포함됩니다.
    let mut b = bridge.cached_buffer.take();

    panic::catch_unwind(panic::AssertUnwindSafe(|| {
        bridge.enter(|| {
            let reader = &mut &b[..];
            let input = A::decode(reader, &mut ());

            // 요청을 위해 `cached_buffer` 를 `Bridge` 에 다시 넣으십시오.
            Bridge::with(|bridge| bridge.cached_buffer = b.take());

            let output = f(input);

            // 출력 값을 위해 `cached_buffer` 를 다시 꺼내십시오.
            b = Bridge::with(|bridge| bridge.cached_buffer.take());

            // HACK(eddyb) 성공 값 (`Ok(output)`) 인코딩을 panic (`Err(e: PanicMessage)`) 인코딩과 분리하여 `bridge.enter(|| ...)` 범위를 벗어난 핸들을 피하고 성공을 인코딩하는 동안 발생할 수있는 panics 를 포착합니다.
            //
            // panics 는이 시점 이후에는 불가능해야하지만 이것은 `extern "C"` 에 도달하는 우발적 인 패닉을 방지하기 위해 방어 적으로 노력하는 것입니다 (`abort` 가되어야하지만 현재로서는 그렇지 않을 수 있으므로 잠재적으로 UB를 방지 할 수 있음).
            //
            //
            //
            //
            //
            //
            b.clear();
            Ok::<_, ()>(output).encode(&mut b, &mut ());
        })
    }))
    .map_err(PanicMessage::from)
    .unwrap_or_else(|e| {
        b.clear();
        Err::<(), _>(e).encode(&mut b, &mut ());
    });
    b
}

impl Client<fn(crate::TokenStream) -> crate::TokenStream> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn expand1(f: fn(crate::TokenStream) -> crate::TokenStream) -> Self {
        extern "C" fn run(
            bridge: Bridge<'_>,
            f: impl FnOnce(crate::TokenStream) -> crate::TokenStream,
        ) -> Buffer<u8> {
            run_client(bridge, |input| f(crate::TokenStream(input)).0)
        }
        Client { get_handle_counters: HandleCounters::get, run, f }
    }
}

impl Client<fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn expand2(
        f: fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        extern "C" fn run(
            bridge: Bridge<'_>,
            f: impl FnOnce(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
        ) -> Buffer<u8> {
            run_client(bridge, |(input, input2)| {
                f(crate::TokenStream(input), crate::TokenStream(input2)).0
            })
        }
        Client { get_handle_counters: HandleCounters::get, run, f }
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
pub enum ProcMacro {
    CustomDerive {
        trait_name: &'static str,
        attributes: &'static [&'static str],
        client: Client<fn(crate::TokenStream) -> crate::TokenStream>,
    },

    Attr {
        name: &'static str,
        client: Client<fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream>,
    },

    Bang {
        name: &'static str,
        client: Client<fn(crate::TokenStream) -> crate::TokenStream>,
    },
}

impl ProcMacro {
    pub fn name(&self) -> &'static str {
        match self {
            ProcMacro::CustomDerive { trait_name, .. } => trait_name,
            ProcMacro::Attr { name, .. } => name,
            ProcMacro::Bang { name, .. } => name,
        }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn custom_derive(
        trait_name: &'static str,
        attributes: &'static [&'static str],
        expand: fn(crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::CustomDerive { trait_name, attributes, client: Client::expand1(expand) }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn attr(
        name: &'static str,
        expand: fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::Attr { name, client: Client::expand2(expand) }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn bang(
        name: &'static str,
        expand: fn(crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::Bang { name, client: Client::expand1(expand) }
    }
}