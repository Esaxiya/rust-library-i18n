//! 새 매크로를 정의 할 때 매크로 작성자를위한 지원 라이브러리입니다.
//!
//! 표준 배포판에서 제공하는이 라이브러리는 함수형 매크로 `#[proc_macro]`, 매크로 속성 `#[proc_macro_attribute]` 및 사용자 정의 파생 속성`#[proc_macro_derive]`와 같이 절차 적으로 정의 된 매크로 정의의 인터페이스에서 사용되는 유형을 제공합니다.
//!
//!
//! 자세한 내용은 [the book] 를 참조하십시오.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// 현재 실행중인 프로그램에서 proc_macro에 액세스 할 수 있는지 여부를 판별합니다.
///
/// proc_macro crate 는 절차 적 매크로 구현 내에서만 사용하기위한 것입니다.이 crate panic 의 모든 함수는 빌드 스크립트 나 단위 테스트 또는 일반 Rust 바이너리와 같은 절차 적 매크로 외부에서 호출 된 경우입니다.
///
/// 매크로 및 비 매크로 사용 사례를 모두 지원하도록 설계된 Rust 라이브러리를 고려하여 `proc_macro::is_available()` 는 proc_macro의 API를 사용하는 데 필요한 인프라가 현재 사용 가능한지 여부를 감지하는 비 당황적인 방법을 제공합니다.
/// 프로 시저 매크로 내부에서 호출되면 true를, 다른 바이너리에서 호출하면 false를 반환합니다.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// tokens 의 추상 스트림 또는보다 구체적으로 token 트리의 시퀀스를 나타내는이 crate 에서 제공하는 기본 유형입니다.
/// 이 유형은 token 트리를 반복하고 반대로 여러 token 트리를 하나의 스트림으로 수집하기위한 인터페이스를 제공합니다.
///
///
/// 이것은 `#[proc_macro]`, `#[proc_macro_attribute]` 및 `#[proc_macro_derive]` 정의의 입력 및 출력입니다.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` 에서 오류가 반환되었습니다.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token 트리가없는 빈 `TokenStream` 를 반환합니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// 이 `TokenStream` 가 비어 있는지 확인합니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// 문자열을 tokens 로 나누고 해당 tokens 를 token 스트림으로 구문 분석하려고합니다.
/// 예를 들어 문자열에 불균형 구분 기호 또는 언어에없는 문자가 포함 된 경우 여러 가지 이유로 실패 할 수 있습니다.
///
/// 구문 분석 된 스트림의 모든 tokens 는 `Span::call_site()` 범위를 얻습니다.
///
/// NOTE: 일부 오류로 인해 `LexError` 를 반환하는 대신 panics 가 발생할 수 있습니다.우리는 나중에 이러한 오류를`LexError`로 변경할 권리를 보유합니다.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, 브리지는 `to_string` 만 제공하고이를 기반으로 `fmt::Display` 를 구현합니다 (둘 사이의 일반적인 관계의 반대).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// `Delimiter::None` 구분 기호와 음수 리터럴이있는`TokenTree: : Group`을 제외하고는 token 스트림을 동일한 token 스트림 (모듈로 범위)으로 다시 무손실 변환 할 수있는 문자열로 인쇄합니다.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// 디버깅에 편리한 형식으로 token 를 인쇄합니다.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// 단일 token 트리를 포함하는 token 스트림을 만듭니다.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// 여러 token 트리를 단일 스트림으로 수집합니다.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token 스트림에 대한 "flattening" 작업은 여러 token 스트림에서 token 트리를 단일 스트림으로 수집합니다.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) 가능한 최적화 된 구현 if/when 를 사용하십시오.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// 반복기와 같은 `TokenStream` 유형에 대한 공개 구현 세부 사항.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `TokenStream`의`TokenTree`에 대한 반복기입니다.
    /// 반복은 "shallow" 입니다. 예를 들어 반복기는 구분 된 그룹으로 반복되지 않고 전체 그룹을 token 트리로 반환합니다.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` 임의의 tokens 를 받아들이고 입력을 설명하는 `TokenStream` 로 확장합니다.
/// 예를 들어 `quote!(a + b)` 는 계산시 `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// 인용 해제는 `$` 로 수행되며 단일 다음 ident를 인용되지 않은 용어로 사용하여 작동합니다.
/// `$` 자체를 인용하려면 `$$` 를 사용하십시오.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// 매크로 확장 정보와 함께 소스 코드의 영역입니다.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` 범위에서 지정된 `message` 를 사용하여 새 `Diagnostic` 를 만듭니다.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// 매크로 정의 사이트에서 확인되는 범위입니다.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// 현재 프로 시저 매크로 호출 범위입니다.
    /// 이 스팬으로 생성 된 식별자는 마치 매크로 호출 위치 (호출 사이트 위생)에서 직접 작성된 것처럼 확인되고 매크로 호출 사이트의 다른 코드도 참조 할 수 있습니다.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` 위생을 나타내며 때로는 매크로 정의 사이트 (로컬 변수, 레이블, `$crate`) 및 때로는 매크로 호출 사이트 (다른 모든 것)에서 해결되는 범위입니다.
    ///
    /// 스팬 위치는 호출 사이트에서 가져옵니다.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// 이 범위가 가리키는 원본 소스 파일입니다.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `self` 가 생성 된 이전 매크로 확장의 tokens 에 대한 `Span` 입니다 (있는 경우).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` 가 생성 된 원본 소스 코드의 범위입니다.
    /// 이 `Span` 가 다른 매크로 확장에서 생성되지 않은 경우 반환 값은 `*self` 와 동일합니다.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// 이 범위의 소스 파일에서 시작 line/column 를 가져옵니다.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// 이 범위의 소스 파일에서 끝 line/column 를 가져옵니다.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` 및 `other` 를 포함하는 새 범위를 만듭니다.
    ///
    /// `self` 와 `other` 가 다른 파일에있는 경우 `None` 를 반환합니다.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` 와 동일한 line/column 정보로 새 범위를 생성하지만 `other` 에있는 것처럼 기호를 확인합니다.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` 와 동일한 이름 확인 동작을 사용하지만 `other` 의 line/column 정보를 사용하여 새 범위를 만듭니다.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// 스팬과 비교하여 동일한 지 확인합니다.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// 범위 뒤에있는 소스 텍스트를 반환합니다.
    /// 이렇게하면 공백과 주석을 포함하여 원본 소스 코드가 유지됩니다.
    /// 범위가 실제 소스 코드에 해당하는 경우에만 결과를 반환합니다.
    ///
    /// Note: 매크로의 관찰 가능한 결과는이 소스 텍스트가 아닌 tokens 에만 의존해야합니다.
    ///
    /// 이 기능의 결과는 진단용으로 만 사용하기위한 최선의 노력입니다.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// 디버깅에 편리한 형식으로 범위를 인쇄합니다.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` 의 시작 또는 끝을 나타내는 행-열 쌍입니다.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 스팬이 (inclusive) 를 시작하거나 끝나는 소스 파일의 1-인덱싱 된 행입니다.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 범위가 (inclusive) 를 시작하거나 끝나는 소스 파일의 0 인덱스 열 (UTF-8 문자)입니다.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// 주어진 `Span` 의 소스 파일.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// 이 소스 파일의 경로를 가져옵니다.
    ///
    /// ### Note
    /// 이 `SourceFile` 와 연관된 코드 범위가 외부 매크로 인이 매크로에 의해 생성 된 경우 이것은 파일 시스템의 실제 경로가 아닐 수 있습니다.
    /// [`is_real`] 를 사용하여 확인하십시오.
    ///
    /// 또한 `is_real` 가 `true` 를 반환하더라도 `--remap-path-prefix` 가 명령 줄에서 전달되면 주어진 경로가 실제로 유효하지 않을 수 있습니다.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// 이 소스 파일이 실제 소스 파일이고 외부 매크로의 확장에 의해 생성되지 않은 경우 `true` 를 반환합니다.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // 이것은 인터 크레이트 스팬이 구현 될 때까지 해킹이며 외부 매크로에서 생성 된 스팬에 대한 실제 소스 파일을 가질 수 있습니다.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// 단일 token 또는 구분 된 token 트리 시퀀스 (예: `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// 대괄호 구분 기호로 둘러싸인 token 스트림입니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// 식별자.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// 단일 구두점 문자 (`+`, `,`, `$` 등).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// 리터럴 문자 (`'a'`), 문자열 (`"hello"`), 숫자 (`2.3`) 등
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// 포함 된 token 또는 구분 된 스트림의 `span` 메서드에 위임하여이 트리의 범위를 반환합니다.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *이 token* 에 대한 범위를 구성합니다.
    ///
    /// 이 token 가 `Group` 인 경우이 메서드는 각 내부 tokens 의 범위를 구성하지 않으며 단순히 각 변형의 `set_span` 메서드에 위임됩니다.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// 디버깅에 편리한 형태로 token 트리를 인쇄합니다.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // 이들 각각은 파생 된 디버그의 구조체 유형에 이름이 있으므로 추가 간접 레이어를 사용하지 마십시오.
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, 브리지는 `to_string` 만 제공하고이를 기반으로 `fmt::Display` 를 구현합니다 (둘 사이의 일반적인 관계의 반대).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// `Delimiter::None` 구분 기호와 음수 리터럴이있는`TokenTree: : Group`을 제외하고는 token 트리를 동일한 token 트리 (모듈로 범위)로 다시 무손실 변환 할 수있는 문자열로 인쇄합니다.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// 구분 된 token 스트림.
///
/// `Group` 는 내부적으로 '구분자'로 둘러싸인 `TokenStream` 를 포함합니다.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token 트리 시퀀스를 구분하는 방법을 설명합니다.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// 예를 들어 "macro variable" `$var` 에서 오는 tokens 주위에 나타날 수있는 암시 적 구분 기호입니다.
    /// `$var` 가 `1 + 2` 인 `$var * 3` 와 같은 경우 운영자 우선 순위를 유지하는 것이 중요합니다.
    /// 암시 적 구분 기호는 문자열을 통한 token 스트림의 왕복을 유지하지 못할 수 있습니다.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// 지정된 구분 기호와 token 스트림을 사용하여 새 `Group` 를 만듭니다.
    ///
    /// 이 생성자는이 그룹의 범위를 `Span::call_site()` 로 설정합니다.
    /// 범위를 변경하려면 아래 `set_span` 방법을 사용할 수 있습니다.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// 이 `Group` 의 구분자를 리턴합니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// 이 `Group` 에서 구분 된 tokens 의 `TokenStream` 를 반환합니다.
    ///
    /// 반환 된 token 스트림에는 위에서 반환 된 구분 기호가 포함되지 않습니다.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// 전체 `Group` 에 걸쳐이 token 스트림의 구분 기호에 대한 범위를 반환합니다.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// 이 그룹의 여는 구분 기호를 가리키는 범위를 반환합니다.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// 이 그룹의 닫는 구분 기호를 가리키는 범위를 반환합니다.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// 이 '그룹'의 구분자에 대한 범위를 구성하지만 내부 tokens 는 구성하지 않습니다.
    ///
    /// 이 메서드는이 그룹에 포함 된 모든 내부 tokens 의 범위를 설정하지 **않습니다**, 오히려 `Group` 수준에서 구분 기호 tokens 의 범위 만 설정합니다.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, 브리지는 `to_string` 만 제공하고이를 기반으로 `fmt::Display` 를 구현합니다 (둘 사이의 일반적인 관계의 반대).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// `Delimiter::None` 구분 기호가있는 'TokenTree: : Group'을 제외하고 동일한 그룹 (모듈로 범위)으로 다시 무손실 변환 할 수있는 문자열로 그룹을 인쇄합니다.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` 는 `+`, `-` 또는 `#` 와 같은 단일 구두점 문자입니다.
///
/// `+=` 와 같은 다중 문자 연산자는 `Spacing` 의 다른 형식이 반환 된 두 개의 `Punct` 인스턴스로 표시됩니다.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// `Punct` 다음에 다른 `Punct` 가 바로 뒤에 오는지 아니면 다른 token 또는 공백이 뒤에 오는지 여부.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// 예를 들어, `+` 는 `+ =`, `+ident` 또는 `+()` 에서 `Alone` 입니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// 예를 들어, `+` 는 `+=` 또는 `'#` 에서 `Joint` 입니다.
    /// 또한 작은 따옴표 `'` 는 식별자와 결합하여 수명 `'ident` 를 형성 할 수 있습니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// 주어진 문자와 간격으로 새로운 `Punct` 를 만듭니다.
    /// `ch` 인수는 언어에서 허용하는 유효한 구두점 문자 여야합니다. 그렇지 않으면 함수는 panic 가됩니다.
    ///
    /// 반환 된 `Punct` 의 기본 범위는 `Span::call_site()` 이며 아래의 `set_span` 메서드를 사용하여 추가로 구성 할 수 있습니다.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// 이 구두점 문자의 값을 `char` 로 리턴합니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// 이 구두점 문자의 간격을 반환하여 token 스트림에서 다른 `Punct` 가 바로 뒤에 오는지 여부를 표시하여 잠재적으로 다중 문자 연산자 (`Joint`) 로 결합 될 수 있는지 아니면 뒤에 다른 token 또는 공백 (`Alone`) 가 뒤에 오는지 여부를 나타냅니다. 끝났습니다.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// 이 구두점 문자의 범위를 반환합니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// 이 구두점 문자의 범위를 구성하십시오.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, 브리지는 `to_string` 만 제공하고이를 기반으로 `fmt::Display` 를 구현합니다 (둘 사이의 일반적인 관계의 반대).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// 동일한 문자로 다시 무손실 변환이 가능해야하는 문자열로 구두점 문자를 인쇄합니다.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// 식별자 (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// 지정된 `span` 뿐만 아니라 지정된 `string` 로 새 `Ident` 를 만듭니다.
    /// `string` 인수는 언어에서 허용하는 유효한 식별자 여야합니다 (키워드 포함, 예: `self` 또는 `fn`).그렇지 않으면 함수는 panic 가됩니다.
    ///
    /// 현재 rustc 에있는 `span` 는이 식별자에 대한 위생 정보를 구성합니다.
    ///
    /// 이 시점에서 `Span::call_site()` 는 "call-site" 위생에 명시 적으로 옵트 인합니다. 즉,이 범위로 생성 된 식별자는 마치 매크로 호출 위치에 직접 작성된 것처럼 확인되고 매크로 호출 사이트의 다른 코드는 다음을 참조 할 수 있습니다. 그들도.
    ///
    ///
    /// `Span::def_site()` 와 같은 이후 범위는 "definition-site" 위생에 대한 옵트 인을 허용합니다. 즉,이 범위로 생성 된 식별자는 매크로 정의의 위치에서 확인되고 매크로 호출 사이트의 다른 코드는이를 참조 할 수 없습니다.
    ///
    /// 현재 위생의 중요성으로 인해이 생성자는 다른 tokens 와 달리 건설시 `Span` 를 지정해야합니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` 와 동일하지만 원시 식별자 (`r#ident`) 를 만듭니다.
    /// `string` 인수는 언어에서 허용하는 유효한 식별자 (키워드 포함, 예: `fn`)입니다.
    /// 경로 세그먼트에서 사용할 수있는 키워드 (예 :
    /// `self`, `super`)는 지원되지 않으며 panic 가 발생합니다.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) 가 반환 한 전체 문자열을 포함하는이 `Ident` 의 범위를 반환합니다.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// 이 `Ident` 의 범위를 구성하여 위생 컨텍스트를 변경할 수 있습니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, 브리지는 `to_string` 만 제공하고이를 기반으로 `fmt::Display` 를 구현합니다 (둘 사이의 일반적인 관계의 반대).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// 동일한 식별자로 다시 무손실 변환이 가능해야하는 문자열로 식별자를 인쇄합니다.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// 리터럴 문자열 (`"hello"`), 바이트 문자열 (`b"hello"`), 문자 (`'a'`), 바이트 문자 (`b'a'`), 접미사가 있거나없는 정수 또는 부동 소수점 숫자 (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true` 및 `false` 와 같은 부울 리터럴은 여기에 속하지 않으며`Ident`입니다.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// 지정된 값을 사용하여 새로운 접미사가 붙은 정수 리터럴을 만듭니다.
        ///
        /// 이 함수는 지정된 정수 값이 token 의 첫 번째 부분이고 적분도 끝에 접미사가 붙는 `1u32` 와 같은 정수를 생성합니다.
        /// 음수에서 생성 된 리터럴은 `TokenStream` 또는 문자열을 통한 왕복에서 살아남지 못할 수 있으며 두 개의 tokens (`-` 및 양수 리터럴)로 나눌 수 있습니다.
        ///
        ///
        /// 이 방법을 통해 생성 된 리터럴은 기본적으로 `Span::call_site()` 범위를 가지며 아래의 `set_span` 방법으로 구성 할 수 있습니다.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// 지정된 값을 사용하여 접미사가없는 새 정수 리터럴을 만듭니다.
        ///
        /// 이 함수는 지정된 정수 값이 token 의 첫 부분 인 `1` 와 같은 정수를 생성합니다.
        /// 이 token 에는 접미사가 지정되지 않았습니다. 즉, `Literal::i8_unsuffixed(1)` 와 같은 호출은 `Literal::u32_unsuffixed(1)` 와 동일합니다.
        /// 음수로 생성 된 리터럴은 `TokenStream` 또는 문자열을 통한로운 트립에서 살아남지 못할 수 있으며 두 개의 tokens (`-` 및 양수 리터럴)로 나눌 수 있습니다.
        ///
        ///
        /// 이 방법을 통해 생성 된 리터럴은 기본적으로 `Span::call_site()` 범위를 가지며 아래의 `set_span` 방법으로 구성 할 수 있습니다.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// 접미사가없는 새 부동 소수점 리터럴을 만듭니다.
    ///
    /// 이 생성자는 float의 값이 token 로 직접 방출되지만 접미사가 사용되지 않는 `Literal::i8_unsuffixed` 와 유사하므로 나중에 컴파일러에서 `f64` 로 추론 할 수 있습니다.
    ///
    /// 음수로 생성 된 리터럴은 `TokenStream` 또는 문자열을 통한로운 트립에서 살아남지 못할 수 있으며 두 개의 tokens (`-` 및 양수 리터럴)로 나눌 수 있습니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 지정된 float가 유한해야합니다. 예를 들어 무한대이거나 NaN이면이 함수는 panic 가됩니다.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// 접미사가 붙은 새 부동 소수점 리터럴을 만듭니다.
    ///
    /// 이 생성자는 지정된 값이 token 의 앞 부분이고 `f32` 가 token 의 접미사 인 `1.0f32` 와 같은 리터럴을 만듭니다.
    /// 이 token 는 항상 컴파일러에서 `f32` 로 추론됩니다.
    /// 음수로 생성 된 리터럴은 `TokenStream` 또는 문자열을 통한로운 트립에서 살아남지 못할 수 있으며 두 개의 tokens (`-` 및 양수 리터럴)로 나눌 수 있습니다.
    ///
    ///
    /// # Panics
    ///
    /// 이 함수는 지정된 float가 유한해야합니다. 예를 들어 무한대이거나 NaN이면이 함수는 panic 가됩니다.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// 접미사가없는 새 부동 소수점 리터럴을 만듭니다.
    ///
    /// 이 생성자는 float의 값이 token 로 직접 방출되지만 접미사가 사용되지 않는 `Literal::i8_unsuffixed` 와 유사하므로 나중에 컴파일러에서 `f64` 로 추론 할 수 있습니다.
    ///
    /// 음수로 생성 된 리터럴은 `TokenStream` 또는 문자열을 통한로운 트립에서 살아남지 못할 수 있으며 두 개의 tokens (`-` 및 양수 리터럴)로 나눌 수 있습니다.
    ///
    /// # Panics
    ///
    /// 이 함수는 지정된 float가 유한해야합니다. 예를 들어 무한대이거나 NaN이면이 함수는 panic 가됩니다.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// 접미사가 붙은 새 부동 소수점 리터럴을 만듭니다.
    ///
    /// 이 생성자는 지정된 값이 token 의 앞 부분이고 `f64` 가 token 의 접미사 인 `1.0f64` 와 같은 리터럴을 만듭니다.
    /// 이 token 는 항상 컴파일러에서 `f64` 로 추론됩니다.
    /// 음수로 생성 된 리터럴은 `TokenStream` 또는 문자열을 통한로운 트립에서 살아남지 못할 수 있으며 두 개의 tokens (`-` 및 양수 리터럴)로 나눌 수 있습니다.
    ///
    ///
    /// # Panics
    ///
    /// 이 함수는 지정된 float가 유한해야합니다. 예를 들어 무한대이거나 NaN이면이 함수는 panic 가됩니다.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// 문자열 리터럴.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// 문자 리터럴.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// 바이트 문자열 리터럴.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// 이 리터럴을 포함하는 범위를 반환합니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// 이 리터럴에 연결된 범위를 구성합니다.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `range` 범위의 소스 바이트 만 포함하는 `self.span()` 의 하위 집합 인 `Span` 를 반환합니다.
    /// 트리밍 될 범위가 `self` 의 범위를 벗어나면 `None` 를 반환합니다.
    ///
    // FIXME(SergioBenitez): 바이트 범위가 소스의 UTF-8 경계에서 시작하고 끝나는 지 확인하십시오.
    // 그렇지 않으면 소스 텍스트가 인쇄 될 때 panic 가 다른 곳에서 발생할 가능성이 있습니다.
    // FIXME(SergioBenitez): 사용자가 `self.span()` 가 실제로 무엇에 매핑되는지 알 수있는 방법이 없으므로이 메서드는 현재 맹목적으로 만 호출 할 수 있습니다.
    // 예를 들어 'c' 문자의 `to_string()` 는 "'\u{63}'" 를 반환합니다.사용자가 소스 텍스트가 'c' 인지 '\u{63}' 인지 알 수있는 방법이 없습니다.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` 와 비슷하지만 `Bound<&T>` 용입니다.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, 브리지는 `to_string` 만 제공하고이를 기반으로 `fmt::Display` 를 구현합니다 (둘 사이의 일반적인 관계의 반대).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// 리터럴을 손실없이 동일한 리터럴로 다시 변환 할 수 있어야하는 문자열로 인쇄합니다 (부동 소수점 리터럴에 대해 가능한 반올림 제외).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// 환경 변수에 대한 액세스를 추적합니다.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// 환경 변수를 검색하고이를 추가하여 종속성 정보를 빌드하십시오.
    /// 컴파일러를 실행하는 빌드 시스템은 컴파일 중에 변수에 액세스했음을 알고 해당 변수의 값이 변경되면 빌드를 다시 실행할 수 있습니다.
    ///
    /// 종속성 추적 외에도이 함수는 인수가 UTF-8 여야한다는 점을 제외하고 표준 라이브러리의 `env::var` 와 동일해야합니다.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}