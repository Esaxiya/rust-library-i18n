# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate 에 대한 문서를 참조하십시오.