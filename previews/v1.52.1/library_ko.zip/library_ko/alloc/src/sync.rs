#![stable(feature = "rust1", since = "1.0.0")]

//! 스레드로부터 안전한 참조 계수 포인터.
//!
//! 자세한 내용은 [`Arc<T>`][Arc] 문서를 참조하십시오.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` 에 대해 만들 수있는 참조 양에 대한 소프트 제한입니다.
///
/// 이 제한을 초과하면 _exactly_ `MAX_REFCOUNT + 1` 참조에서 프로그램이 중단됩니다 (반드시 그런 것은 아님).
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer는 메모리 펜스를 지원하지 않습니다.
// Arc/Weak 구현에서 오 탐지보고를 방지하려면 대신 동기화에 원자 부하를 사용합니다.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// 스레드로부터 안전한 참조 계수 포인터.'Arc' 는 'Atomically Reference Counted'를 나타냅니다.
///
/// `Arc<T>` 유형은 힙에 할당 된 `T` 유형 값의 공유 소유권을 제공합니다.`Arc` 에서 [`clone`][clone] 를 호출하면 참조 횟수를 늘리면서 소스 `Arc` 와 동일한 힙 할당을 가리키는 새 `Arc` 인스턴스가 생성됩니다.
/// 주어진 할당에 대한 마지막 `Arc` 포인터가 파괴되면 해당 할당에 저장된 값 (종종 "inner value" 라고 함)도 삭제됩니다.
///
/// Rust 의 공유 참조는 기본적으로 변경을 허용하지 않으며 `Arc` 도 예외는 아닙니다. 일반적으로 `Arc` 내부의 항목에 대한 변경 가능한 참조를 얻을 수 없습니다.`Arc` 를 통해 변경해야하는 경우 [`Mutex`][mutex], [`RwLock`][rwlock] 또는 [`Atomic`][atomic] 유형 중 하나를 사용하십시오.
///
/// ## 스레드 안전성
///
/// [`Rc<T>`] 와 달리 `Arc<T>` 는 참조 카운팅에 원자 연산을 사용합니다.이것은 스레드로부터 안전하다는 것을 의미합니다.단점은 원자 적 연산이 일반 메모리 액세스보다 더 비싸다는 것입니다.스레드간에 참조 횟수 할당을 공유하지 않는 경우 오버 헤드를 줄이기 위해 [`Rc<T>`] 를 사용하는 것이 좋습니다.
/// [`Rc<T>`] 컴파일러가 스레드간에 [`Rc<T>`] 를 전송하려는 시도를 포착하므로 안전한 기본값입니다.
/// 그러나 라이브러리 소비자에게 더 많은 유연성을 제공하기 위해 라이브러리는 `Arc<T>` 를 선택할 수 있습니다.
///
/// `Arc<T>` `T` 가 [`Send`] 및 [`Sync`] 를 구현하는 한 [`Send`] 및 [`Sync`] 를 구현합니다.
/// 스레드로부터 안전하도록 `Arc<T>` 에 스레드로부터 안전하지 않은 유형 `T` 를 넣을 수없는 이유는 무엇입니까?이것은 처음에는 다소 반 직관적 일 수 있습니다. 결국 `Arc<T>` 스레드 안전의 요점이 아닌가요?핵심은 이것이다: `Arc<T>` 는 동일한 데이터에 대한 다중 소유권을 갖는 스레드를 안전하게 만들지 만 데이터에 스레드 안전성을 추가하지는 않습니다.
///
/// `Arc <`[`RefCell 고려<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] 가 아니고 `Arc<T>` 가 항상 [`Send`] 이면`Arc <`[`RefCell<T>`]`>`도 마찬가지입니다.
/// 하지만 문제가 생겼습니다.
/// [`RefCell<T>`] 스레드로부터 안전하지 않습니다.비 원자 연산을 사용하여 차용 횟수를 추적합니다.
///
/// 결국 이것은 `Arc<T>` 를 일종의 [`std::sync`] 유형, 일반적으로 [`Mutex<T>`][mutex] 와 페어링해야 할 수 있음을 의미합니다.
///
/// ## `Weak` 를 사용한 브레이킹 사이클
///
/// [`downgrade`][downgrade] 메서드는 소유하지 않은 [`Weak`] 포인터를 만드는 데 사용할 수 있습니다.[`Weak`] 포인터는 `Arc` 로 [`upgrade`][업그레이드] 할 수 있지만 할당에 저장된 값이 이미 삭제 된 경우 [`None`] 를 반환합니다.
/// 즉, `Weak` 포인터는 할당 내의 값을 유지하지 않습니다.그러나 그들은 할당 (가치에 대한 백업 저장소)을 살아있는 상태로 유지합니다.
///
/// `Arc` 포인터 사이의주기는 할당 해제되지 않습니다.
/// 이러한 이유로 [`Weak`] 는 사이클을 중단하는 데 사용됩니다.예를 들어, 트리에는 부모 노드에서 자식으로의 강력한 `Arc` 포인터와 자식에서 부모로의 [`Weak`] 포인터가있을 수 있습니다.
///
/// # 참조 복제
///
/// 기존 참조 카운트 포인터에서 새 참조를 만드는 것은 [`Arc<T>`][Arc] 및 [`Weak<T>`][Weak] 에 대해 구현 된 `Clone` trait 를 사용하여 수행됩니다.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // 아래의 두 구문은 동일합니다.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b 및 foo는 모두 동일한 메모리 위치를 가리키는 호입니다.
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ([`Deref`][deref] trait 를 통해) `T` 를 자동으로 역 참조하므로 `Arc<T>` 유형의 값에 대해 'T'의 메서드를 호출 할 수 있습니다.`T`의 메서드와 이름 충돌을 피하기 위해 `Arc<T>` 자체의 메서드는 [fully qualified syntax] 를 사용하여 호출되는 관련 함수입니다.
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `아크<T>`의 `Clone` 와 같은 traits 구현은 정규화 된 구문을 사용하여 호출 할 수도 있습니다.
/// 어떤 사람들은 정규화 된 구문을 선호하는 반면 다른 사람들은 메서드 호출 구문을 선호합니다.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // 메서드 호출 구문
/// let arc2 = arc.clone();
/// // 정규화 된 구문
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] 내부 값이 이미 삭제되었을 수 있으므로 `T` 에 대한 자동 역 참조를 수행하지 않습니다.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// 스레드간에 변경 불가능한 데이터 공유 :
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// 여기서는 이러한 테스트를 실행하지 **않습니다**.
// windows 빌더는 쓰레드가 메인 쓰레드보다 오래 살아남은 다음 동시에 종료하면 (무언가 교착 상태) 매우 불행 해 지므로 이러한 테스트를 실행하지 않음으로써이를 완전히 피할 수 있습니다.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// 변경 가능한 [`AtomicUsize`] 공유 :
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// 일반적인 참조 계수의 더 많은 예는 [`rc` documentation][rc_examples] 를 참조하십시오.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` 관리 할당에 대한 비 소유 참조를 보유하는 [`Arc`] 버전입니다.
/// 할당은 [`Option`]`<`[`Arc`]`를 반환하는 `Weak` 포인터에서 [`upgrade`] 를 호출하여 액세스합니다.<T>>`.
///
/// `Weak` 참조는 소유권에 포함되지 않기 때문에 할당에 저장된 값이 삭제되는 것을 방지하지 않으며 `Weak` 자체는 여전히 존재하는 값에 대해 보장하지 않습니다.
///
/// 따라서 [`업그레이드`] d시 [`None`] 를 반환 할 수 있습니다.
/// 그러나 `Weak` 참조는 할당 자체 (백킹 저장소)가 할당 해제되는 것을 방지 *합니다*.
///
/// `Weak` 포인터는 내부 값이 삭제되는 것을 방지하지 않고 [`Arc`] 가 관리하는 할당에 대한 임시 참조를 유지하는 데 유용합니다.
/// 또한 상호 소유 참조는 [`Arc`] 가 삭제되는 것을 허용하지 않으므로 [`Arc`] 포인터 간의 순환 참조를 방지하는데도 사용됩니다.
/// 예를 들어, 트리는 부모 노드에서 자식으로의 강력한 [`Arc`] 포인터와 자식에서 부모로의 `Weak` 포인터를 가질 수 있습니다.
///
/// `Weak` 포인터를 얻는 일반적인 방법은 [`Arc::downgrade`] 를 호출하는 것입니다.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // 이것은 열거 형에서이 유형의 크기를 최적화 할 수있는 `NonNull` 이지만 반드시 유효한 포인터는 아닙니다.
    //
    // `Weak::new` 힙에 공간을 할당 할 필요가 없도록 `usize::MAX` 로 설정합니다.
    // RcBox에 최소 2 개의 정렬이 있기 때문에 실제 포인터가 가질 수있는 값이 아닙니다.
    // 이것은 `T: Sized` 일 때만 가능합니다.크기가 지정되지 않은 `T` 는 결코 매달리지 않습니다.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// 이것은 가능한 필드 재정렬에 대한 repr(C) 에서 future-증거이며, 변경 가능한 내부 유형의 안전한 [into|from]_raw() 를 방해 할 수 있습니다.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX 값은 약한 포인터를 업그레이드하거나 강한 포인터를 다운 그레이드하는 기능을 일시적으로 "locking" 에 대한 감시자 역할을합니다.이것은 `make_mut` 및 `get_mut` 에서 레이스를 피하는 데 사용됩니다.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// 새로운 `Arc<T>` 를 생성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // 약한 포인터 수를 모든 강한 포인터 (kinda) 가 보유하는 약한 포인터 인 1로 시작합니다. 자세한 내용은 std/rc.rs 를 참조하십시오.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// 자신에 대한 약한 참조를 사용하여 새로운 `Arc<T>` 를 생성합니다.
    /// 이 함수가 반환되기 전에 약한 참조를 업그레이드하려고하면 `None` 값이 생성됩니다.
    /// 그러나 약한 참조는 자유롭게 복제하여 나중에 사용하기 위해 저장할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // 단일 약한 참조를 사용하여 "uninitialized" 상태에서 내부를 구성합니다.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // 약한 포인터의 소유권을 포기하지 않는 것이 중요합니다. 그렇지 않으면 `data_fn` 가 반환 될 때 메모리가 해제 될 수 있습니다.
        // 정말로 소유권을 전달하고 싶다면 추가로 약한 포인터를 만들 수 있지만, 그렇지 않으면 필요하지 않을 수있는 약한 참조 카운트에 대한 추가 업데이트가 발생합니다.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // 이제 내부 값을 올바르게 초기화하고 약한 참조를 강한 참조로 바꿀 수 있습니다.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // 데이터 필드에 대한 위의 쓰기는 0이 아닌 강력한 카운트를 관찰하는 모든 스레드에서 볼 수 있어야합니다.
            // 따라서 `Weak::upgrade` 에서 `compare_exchange_weak` 와 동기화하려면 최소한 "Release" 순서가 필요합니다.
            //
            // "Acquire" 주문이 필요하지 않습니다.
            // `data_fn` 의 가능한 동작을 고려할 때 업그레이드 할 수없는 `Weak` 를 참조하여 수행 할 수있는 작업 만 살펴보면됩니다.
            //
            // - `Weak` 를 *복제* 하여 약한 참조 횟수를 늘릴 수 있습니다.
            // - 이러한 클론을 삭제하여 약한 참조 수를 줄일 수 있습니다 (하지만 절대 0이 아님).
            //
            // 이러한 부작용은 우리에게 어떤 방식으로도 영향을 미치지 않으며 안전한 코드만으로는 다른 부작용이 불가능합니다.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // 강력한 참조는 공유 된 약한 참조를 집합 적으로 소유해야하므로 이전 약한 참조에 대해 소멸자를 실행하지 마십시오.
        //
        mem::forget(weak);
        strong
    }

    /// 초기화되지 않은 내용으로 새로운 `Arc` 를 생성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 지연된 초기화 :
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 메모리가 `0` 바이트로 채워지는 초기화되지 않은 내용으로 새로운 `Arc` 를 구성합니다.
    ///
    ///
    /// 이 방법의 올 바르고 잘못된 사용 예는 [`MaybeUninit::zeroed`][zeroed] 를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 새로운 `Pin<Arc<T>>` 를 생성합니다.
    /// `T` 가 `Unpin` 를 구현하지 않으면 `data` 가 메모리에 고정되어 이동할 수 없습니다.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// 새로운 `Arc<T>` 를 생성하고 할당이 실패하면 오류를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // 약한 포인터 수를 모든 강한 포인터 (kinda) 가 보유하는 약한 포인터 인 1로 시작합니다. 자세한 내용은 std/rc.rs 를 참조하십시오.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// 초기화되지 않은 내용으로 새로운 `Arc` 를 생성하고 할당이 실패하면 오류를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // 지연된 초기화 :
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// 메모리가 `0` 바이트로 채워지고 할당이 실패하면 오류를 반환하는 초기화되지 않은 내용으로 새 `Arc` 를 구성합니다.
    ///
    ///
    /// 이 방법의 올 바르고 잘못된 사용 예는 [`MaybeUninit::zeroed`][zeroed] 를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc` 에 정확히 하나의 강력한 참조가있는 경우 내부 값을 반환합니다.
    ///
    /// 그렇지 않으면 [`Err`] 가 전달 된 동일한 `Arc` 와 함께 반환됩니다.
    ///
    ///
    /// 뛰어난 약한 참조가 있어도 성공합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // 암시 적 strong-weak 참조를 정리하기 위해 약한 포인터 만들기
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// 초기화되지 않은 내용으로 원자 적으로 참조 카운트 된 새로운 슬라이스를 생성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 지연된 초기화 :
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// `0` 바이트로 채워진 메모리를 사용하여 초기화되지 않은 내용을 사용하여 원자 적으로 참조 카운트 된 새 슬라이스를 구성합니다.
    ///
    ///
    /// 이 방법의 올 바르고 잘못된 사용 예는 [`MaybeUninit::zeroed`][zeroed] 를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` 로 변환합니다.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] 와 마찬가지로 내부 값이 실제로 초기화 된 상태인지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 즉시 정의되지 않은 동작이 발생합니다.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 지연된 초기화 :
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` 로 변환합니다.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] 와 마찬가지로 내부 값이 실제로 초기화 된 상태인지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 즉시 정의되지 않은 동작이 발생합니다.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 지연된 초기화 :
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` 를 소비하고 래핑 된 포인터를 반환합니다.
    ///
    /// 메모리 누수를 방지하려면 [`Arc::from_raw`] 를 사용하여 포인터를 `Arc` 로 다시 변환해야합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// 데이터에 대한 원시 포인터를 제공합니다.
    ///
    /// 카운트는 어떤 방식으로도 영향을받지 않으며 `Arc` 는 소비되지 않습니다.
    /// 포인터는 `Arc` 에 강력한 카운트가있는 한 유효합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // 안전: Deref::deref 또는 RcBoxPtr::inner 를 통과 할 수 없습니다.
        // 이것은 예를 들어 raw/mut 출처를 유지하는 데 필요합니다.
        // `get_mut` Rc가 `from_raw` 를 통해 복구 된 후 포인터를 통해 쓸 수 있습니다.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// 원시 포인터에서 `Arc<T>` 를 생성합니다.
    ///
    /// 원시 포인터는 [`Arc<U>::into_raw`][into_raw] 에 대한 호출에 의해 이전에 반환 되었어야합니다. 여기서 `U` 는 `T` 와 크기 및 정렬이 동일해야합니다.
    /// `U` 가 `T` 이면 이것은 사소한 사실입니다.
    /// `U` 가 `T` 가 아니지만 크기와 정렬이 같으면 기본적으로 다른 유형의 변환 참조와 같습니다.
    /// 이 경우 적용되는 제한 사항에 대한 자세한 내용은 [`mem::transmute`][transmute] 를 참조하십시오.
    ///
    /// `from_raw` 사용자는 `T` 의 특정 값이 한 번만 삭제되었는지 확인해야합니다.
    ///
    /// 이 함수는 반환 된 `Arc<T>` 에 액세스하지 않더라도 부적절한 사용으로 인해 메모리가 안전하지 않을 수 있으므로 안전하지 않습니다.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // 누출을 방지하려면 `Arc` 로 다시 변환하십시오.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` 에 대한 추가 호출은 메모리에 안전하지 않습니다.
    /// }
    ///
    /// // `x` 가 위의 범위를 벗어 났을 때 메모리가 해제되었으므로 `x_ptr` 는 이제 매달려 있습니다!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // 원래 ArcInner를 찾기 위해 오프셋을 반전합니다.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// 이 할당에 대한 새 [`Weak`] 포인터를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // 이 Relaxed는 아래 CAS에서 값을 확인하고 있기 때문에 괜찮습니다.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // 약한 카운터가 현재 "locked" 인지 확인하십시오.그렇다면 회전하십시오.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: 이 코드는 현재 오버플로 가능성을 무시합니다.
            // usize::MAX 로;일반적으로 Rc와 Arc는 오버플로를 처리하기 위해 조정되어야합니다.
            //

            // Clone() 와 달리 `is_unique` 에서 오는 쓰기와 동기화하기 위해 Acquire 읽기가 필요하므로 쓰기 이전의 이벤트가이 읽기 전에 발생합니다.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // 매달린 Weak을 생성하지 않도록하십시오
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// 이 할당에 대한 [`Weak`] 포인터의 수를 가져옵니다.
    ///
    /// # Safety
    ///
    /// 이 방법 자체는 안전하지만 올바르게 사용하려면 추가주의가 필요합니다.
    /// 다른 스레드는이 메서드 호출과 결과에 대한 작업 사이를 포함하여 언제든지 약한 수를 변경할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // 이 주장은 우리가 쓰레드간에 `Arc` 또는 `Weak` 를 공유하지 않았기 때문에 결정적입니다.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // 약한 카운트가 현재 잠겨 있으면 잠금을 취하기 직전에 카운트 값은 0입니다.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// 이 할당에 대한 강력한 (`Arc`) 포인터 수를 가져옵니다.
    ///
    /// # Safety
    ///
    /// 이 방법 자체는 안전하지만 올바르게 사용하려면 추가주의가 필요합니다.
    /// 다른 스레드는이 메서드 호출과 결과에 대한 작업 사이를 포함하여 언제든지 강력한 카운트를 변경할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // 이 주장은 우리가 쓰레드간에 `Arc` 를 공유하지 않았기 때문에 결정적입니다.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// 제공된 포인터와 연결된 `Arc<T>` 의 강력한 참조 카운트를 1 씩 증가시킵니다.
    ///
    /// # Safety
    ///
    /// 포인터는 `Arc::into_raw` 를 통해 얻어야하며 연관된 `Arc` 인스턴스가 유효해야합니다 (예 :
    /// 이 메서드의 기간 동안 강력한 수는 1) 이상이어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // 이 주장은 우리가 쓰레드간에 `Arc` 를 공유하지 않았기 때문에 결정적입니다.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // 아크를 유지하지만 수동 드롭으로 래핑하여 참조 횟수를 건드리지 마십시오.
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // 이제 refcount를 늘리 되 새 refcount도 삭제하지 마십시오.
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// 제공된 포인터와 연결된 `Arc<T>` 의 강력한 참조 횟수를 1 씩 감소시킵니다.
    ///
    /// # Safety
    ///
    /// 포인터는 `Arc::into_raw` 를 통해 얻어야하며 연관된 `Arc` 인스턴스가 유효해야합니다 (예 :
    /// 이 메서드를 호출 할 때 강력한 수는 1) 이상이어야합니다.
    /// 이 메서드는 최종 `Arc` 및 백업 스토리지를 릴리스하는 데 사용할 수 있지만 최종 `Arc` 가 릴리스 된 후에는 호출하지 **해서는 안됩니다**.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // 이러한 주장은 우리가 스레드간에 `Arc` 를 공유하지 않았기 때문에 결정적입니다.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // 이 호가 살아있는 동안 내부 포인터가 유효하다는 것을 보장하기 때문에이 안전하지 않은 것은 괜찮습니다.
        // 또한 내부 데이터도 `Sync` 이기 때문에 `ArcInner` 구조 자체가 `Sync` 라는 것을 알고 있으므로 이러한 내용에 대한 불변 포인터를 빌려도 괜찮습니다.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` 의 인라인되지 않은 부분.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // 박스 할당 자체를 해제 할 수는 없지만 (여전히 약한 포인터가있을 수 있음)이 시점에서 데이터를 삭제하십시오.
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // 모든 강력한 참조가 집합 적으로 보유한 약한 참조를 삭제합니다.
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// 두 개의 'Arc'가 동일한 할당을 가리키면 `true` 를 반환합니다 ([`ptr::eq`] 와 유사한 맥락에서).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// 값에 제공된 레이아웃이있는 경우 크기를 조정할 수없는 내부 값에 충분한 공간이있는 `ArcInner<T>` 를 할당합니다.
    ///
    /// 함수 `mem_to_arcinner` 는 데이터 포인터와 함께 호출되며 `ArcInner<T>` 에 대한 (잠재적으로 뚱뚱한) 포인터를 반환해야합니다.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // 주어진 값 레이아웃을 사용하여 레이아웃을 계산합니다.
        // 이전에는 `&*(ptr as* const ArcInner<T>)` 표현식에서 레이아웃이 계산되었지만 이로 인해 잘못 정렬 된 참조가 생성되었습니다 (#54908 참조).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// 값에 제공된 레이아웃이있는 크기가 조정되지 않은 내부 값에 충분한 공간이있는 `ArcInner<T>` 를 할당하고 할당에 실패하면 오류를 반환합니다.
    ///
    ///
    /// 함수 `mem_to_arcinner` 는 데이터 포인터와 함께 호출되며 `ArcInner<T>` 에 대한 (잠재적으로 뚱뚱한) 포인터를 반환해야합니다.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // 주어진 값 레이아웃을 사용하여 레이아웃을 계산합니다.
        // 이전에는 `&*(ptr as* const ArcInner<T>)` 표현식에서 레이아웃이 계산되었지만 이로 인해 잘못 정렬 된 참조가 생성되었습니다 (#54908 참조).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner 초기화
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// 크기가 지정되지 않은 내부 값에 충분한 공간이있는 `ArcInner<T>` 를 할당합니다.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // 주어진 값을 사용하여 `ArcInner<T>` 에 할당하십시오.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // 값을 바이트로 복사
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // 내용을 삭제하지 않고 할당 해제
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// 주어진 길이로 `ArcInner<[T]>` 를 할당합니다.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// 슬라이스에서 새로 할당 된 Arc로 요소 복사 <\[T\]>
    ///
    /// 호출자가 소유권을 가져 오거나 `T: Copy` 를 바인딩해야하므로 안전하지 않습니다.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// 특정 크기로 알려진 반복기에서 `Arc<[T]>` 를 구성합니다.
    ///
    /// 크기가 잘못되면 동작이 정의되지 않습니다.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T 요소를 복제하는 동안 Panic 가드.
        // panic 의 경우 새 ArcInner에 기록 된 요소가 삭제 된 다음 메모리가 해제됩니다.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // 첫 번째 요소에 대한 포인터
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // 공습 경보 해제.가드를 잊어 버려 새로운 ArcInner를 해방하지 마십시오.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` 에 사용되는 전문화 trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` 포인터의 복제본을 만듭니다.
    ///
    /// 이렇게하면 동일한 할당에 대한 또 다른 포인터가 만들어지고 강력한 참조 수가 증가합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // 원래 참조를 알고 있으면 다른 스레드가 객체를 잘못 삭제하는 것을 방지하므로 완화 된 순서를 사용하는 것이 좋습니다.
        //
        // [Boost documentation][1] 에 설명 된대로 참조 카운터를 늘리는 것은 항상 memory_order_relaxed를 사용하여 수행 할 수 있습니다. 객체에 대한 새 참조는 기존 참조에서만 형성 할 수 있으며 한 스레드에서 다른 스레드로 기존 참조를 전달하면 필요한 동기화가 이미 제공되어야합니다.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // 그러나 누군가가 Arcs를`mem: : forget`ing하는 경우에 대비하여 대규모 refcount에 대해 경계해야합니다.
        // 이 작업을 수행하지 않으면 카운트가 오버플로 될 수 있으며 사용자는 무료로 사용할 수 있습니다.
        // 참조 횟수를 한 번에 증가시키는 ~2 억 개의 스레드가 없다는 가정하에 `isize::MAX` 로 급격히 포화 상태입니다.
        //
        // 이 branch 는 어떤 현실적인 프로그램에서도 사용되지 않습니다.
        //
        // 우리는 그러한 프로그램이 엄청나게 퇴보하기 때문에 중단하고이를 지원하는 데 관심이 없습니다.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// 주어진 `Arc` 에 대한 가변 참조를 만듭니다.
    ///
    /// 동일한 할당에 대한 다른 `Arc` 또는 [`Weak`] 포인터가있는 경우 `make_mut` 는 새 할당을 만들고 내부 값에 대해 [`clone`][clone] 를 호출하여 고유 한 소유권을 보장합니다.
    /// 이를 기록 중 복제라고도합니다.
    ///
    /// 이것은 나머지 `Weak` 포인터를 분리하는 [`Rc::make_mut`] 의 동작과 다릅니다.
    ///
    /// 복제가 아닌 실패하는 [`get_mut`][get_mut] 도 참조하십시오.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // 아무것도 복제하지 않습니다
    /// let mut other_data = Arc::clone(&data); // 내부 데이터를 복제하지 않습니다.
    /// *Arc::make_mut(&mut data) += 1;         // 내부 데이터 복제
    /// *Arc::make_mut(&mut data) += 1;         // 아무것도 복제하지 않습니다
    /// *Arc::make_mut(&mut other_data) *= 2;   // 아무것도 복제하지 않습니다
    ///
    /// // 이제 `data` 및 `other_data` 는 다른 할당을 가리 킵니다.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // 우리는 강한 참조와 약한 참조를 모두 보유하고 있습니다.
        // 따라서 강력한 참조 만 해제한다고해서 메모리 할당이 해제되는 것은 아닙니다.
        //
        // Acquire를 사용하여 `strong` 에 릴리스 쓰기 (즉, 감소) 전에 발생하는 `weak` 에 대한 쓰기를 확인합니다.
        // 우리는 약한 카운트를 가지고 있기 때문에 ArcInner 자체가 할당 해제 될 가능성은 없습니다.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // 또 다른 강력한 포인터가 있으므로 복제해야합니다.
            // 복제 된 값을 직접 쓸 수 있도록 메모리를 미리 할당합니다.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // 이것은 근본적으로 최적화이기 때문에 위의 내용으로 충분합니다. 우리는 항상 약한 포인터를 떨어 뜨리고 경주합니다.
            // 최악의 경우 불필요하게 새로운 Arc를 할당하게됩니다.
            //

            // 마지막 강한 참조를 제거했지만 추가로 약한 참조가 남아 있습니다.
            // 내용을 새 Arc로 이동하고 다른 약한 참조를 무효화합니다.
            //

            // 약한 카운트는 강한 참조를 가진 스레드에 의해서만 잠길 수 있기 때문에 `weak` 의 읽기가 usize::MAX (즉, 잠김)를 산출하는 것은 불가능합니다.
            //
            //

            // 필요에 따라 ArcInner를 정리할 수 있도록 암시 적 약한 포인터를 구체화합니다.
            //
            let _weak = Weak { ptr: this.ptr };

            // 데이터를 훔칠 수있어 남은 건 Weaks뿐
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // 우리는 두 종류의 유일한 참조였습니다.강력한 참조 수를 백업합니다.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` 와 마찬가지로 우리의 참조는 처음부터 고유했거나 내용을 복제 할 때 하나가 되었기 때문에 안전하지 않습니다.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// 동일한 할당에 대한 다른 `Arc` 또는 [`Weak`] 포인터가없는 경우 지정된 `Arc` 에 대한 변경 가능한 참조를 반환합니다.
    ///
    ///
    /// 공유 값을 변경하는 것이 안전하지 않기 때문에 그렇지 않으면 [`None`] 를 반환합니다.
    ///
    /// 다른 포인터가있을 때 내부 값을 [`clone`][clone] 하는 [`make_mut`][make_mut] 도 참조하십시오.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // 반환 된 포인터가 T에 반환 될 *유일한* 포인터라는 것을 보장하기 때문에이 안전하지 않은 것은 괜찮습니다.
            // 이 시점에서 참조 횟수는 1로 보장되며 Arc 자체가 `mut` 여야하므로 내부 데이터에 대한 유일한 참조를 반환합니다.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// 확인없이 주어진 `Arc` 에 대한 가변 참조를 반환합니다.
    ///
    /// 안전하고 적절한 검사를 수행하는 [`get_mut`] 도 참조하십시오.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// 동일한 할당에 대한 다른 `Arc` 또는 [`Weak`] 포인터는 반환 된 차용 기간 동안 역 참조되지 않아야합니다.
    ///
    /// 예를 들어 `Arc::new` 바로 뒤에 그러한 포인터가 존재하지 않는 경우는 사소한 경우입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" 필드를 포함하는 참조를 만들지 *않도록* 주의해야합니다. 참조 횟수에 대한 동시 액세스를 별칭으로 사용하기 때문입니다 (예 :
        // `Weak` 에 의해).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// 이것이 기본 데이터에 대한 고유 한 참조 (약한 참조 포함)인지 확인합니다.
    ///
    ///
    /// 이를 위해서는 약한 참조 수를 잠 가야합니다.
    fn is_unique(&mut self) -> bool {
        // 우리가 유일한 약한 포인터 홀더 인 것처럼 보이면 약한 포인터 수를 잠급니다.
        //
        // 여기서 획득 레이블은 `weak` 카운트 (릴리스를 사용하는 `Weak::drop` 를 통해)가 감소하기 전에 `strong` (특히 `Weak::upgrade` 에서)에 대한 쓰기와 사전 발생 관계를 보장합니다.
        // 업그레이드 된 약한 참조가 삭제되지 않은 경우 여기에서 CAS가 실패하므로 동기화 할 필요가 없습니다.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop` 의 `strong` 카운터 감소와 동기화하려면 `Acquire` 여야합니다. 이는 마지막 참조가 삭제 될 때 발생하는 유일한 액세스입니다.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // 여기서 릴리스 쓰기는 `downgrade` 의 읽기와 동기화되어 쓰기 후에 위의 `strong` 읽기가 발생하는 것을 효과적으로 방지합니다.
            //
            //
            self.inner().weak.store(1, Release); // 자물쇠를 풀다
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` 를 삭제합니다.
    ///
    /// 강력한 참조 횟수가 감소합니다.
    /// 강력한 참조 횟수가 0에 도달하면 다른 참조 (있는 경우) 만 [`Weak`] 이므로 내부 값을 `drop` 합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // 아무것도 인쇄하지 않습니다
    /// drop(foo2);   // "dropped!" 인쇄
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` 는 이미 원자 적이므로 객체를 삭제하지 않는 한 다른 스레드와 동기화 할 필요가 없습니다.
        // 이 동일한 논리가 `weak` 카운트에 대한 아래 `fetch_sub` 에 적용됩니다.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // 이 펜스는 데이터 사용 순서 변경 및 데이터 삭제를 방지하는 데 필요합니다.
        // `Release` 로 표시되기 때문에 참조 카운트의 감소는이 `Acquire` 펜스와 동기화됩니다.
        // 이것은 데이터의 사용이 참조 카운트를 줄이기 전에 발생한다는 것을 의미하며, 이는 데이터 삭제 전에 발생하는이 펜스 이전에 발생합니다.
        //
        // [Boost documentation][1] 에서 설명했듯이
        //
        // > 하나의 개체에 대한 가능한 액세스를 적용하는 것이 중요합니다.
        // > 스레드 (기존 참조를 통해)를 *삭제하기 전에* 발생
        // > 다른 스레드의 개체.이것은 "release" 에 의해 달성됩니다
        // > 참조 삭제 후 작업 (객체에 대한 모든 액세스
        // > 이 참조를 통해 분명히 이전에 발생 했어야 함) 및
        // > "acquire" 개체를 삭제하기 전에 작업.
        //
        // 특히 Arc의 내용은 일반적으로 불변이지만 Mutex와 같은 것에 내부 쓰기를 할 수 있습니다.<T>.
        // Mutex는 삭제 될 때 획득되지 않으므로 스레드 A의 쓰기를 스레드 B에서 실행중인 소멸자가 볼 수 있도록 만드는 동기화 논리에 의존 할 수 없습니다.
        //
        //
        // 또한 여기에서 Acquire 펜스는 Acquire로드로 대체 될 수 있으며, 이는 경쟁이 심한 상황에서 성능을 향상시킬 수 있습니다.[2] 를 참조하십시오.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` 를 구체적인 유형으로 다운 캐스트하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// 메모리를 할당하지 않고 새로운 `Weak<T>` 를 생성합니다.
    /// 반환 값에서 [`upgrade`] 를 호출하면 항상 [`None`] 가 제공됩니다.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// 데이터 필드에 대한 어설 션을 만들지 않고 참조 횟수에 액세스 할 수있는 도우미 유형입니다.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// 이 `Weak<T>` 가 가리키는 오브젝트 `T` 에 대한 원시 포인터를 리턴합니다.
    ///
    /// 포인터는 강력한 참조가있는 경우에만 유효합니다.
    /// 포인터가 매달려 있거나 정렬되지 않았거나 아니면 [`null`] 일 수도 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // 둘 다 동일한 객체를 가리 킵니다.
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // 여기에있는 강한 사람은 그것을 살아있게 유지하므로 우리는 여전히 객체에 접근 할 수 있습니다.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // 그러나 더 이상은 아닙니다.
    /// // weak.as_ptr() 를 수행 할 수 있지만 포인터에 액세스하면 정의되지 않은 동작이 발생합니다.
    /// // assert_eq! ("hello", 안전하지 않음 {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // 포인터가 매달려 있으면 센티넬을 직접 반환합니다.
            // 페이로드가 적어도 ArcInner (usize) 만큼 정렬되어 있으므로 유효한 페이로드 주소가 될 수 없습니다.
            ptr as *const T
        } else {
            // 안전: is_dangling이 false를 반환하면 포인터가 참조 할 수 없습니다.
            // 이 시점에서 페이로드가 삭제 될 수 있으며 출처를 유지해야하므로 원시 포인터 조작을 사용하십시오.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` 를 소비하고 원시 포인터로 바꿉니다.
    ///
    /// 이는 약한 포인터를 원시 포인터로 변환하는 동시에 하나의 약한 참조의 소유권을 유지합니다 (약한 수는이 작업에 의해 수정되지 않음).
    /// [`from_raw`] 를 사용하여 `Weak<T>` 로 되돌릴 수 있습니다.
    ///
    /// [`as_ptr`] 와 마찬가지로 포인터 대상에 액세스하는 것과 동일한 제한이 적용됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] 에서 이전에 만든 원시 포인터를 다시 `Weak<T>` 로 변환합니다.
    ///
    /// 이것은 안전하게 강력한 참조를 얻거나 (나중에 [`upgrade`] 를 호출하여) `Weak<T>` 를 삭제하여 약한 카운트를 할당 해제하는 데 사용할 수 있습니다.
    ///
    /// 하나의 약한 참조에 대한 소유권을 갖습니다 ([`new`] 에 의해 생성 된 포인터는 아무것도 소유하지 않기 때문에 예외입니다. 메서드는 여전히 작동합니다).
    ///
    /// # Safety
    ///
    /// 포인터는 [`into_raw`] 에서 시작되어야하며 여전히 잠재적 인 약한 참조를 소유해야합니다.
    ///
    /// 이것을 호출 할 때 강한 카운트는 0이 될 수 있습니다.
    /// 그럼에도 불구하고 이것은 현재 원시 포인터로 표시되는 하나의 약한 참조의 소유권을 가져 오므로 (약한 카운트는이 작업에 의해 수정되지 않음) [`into_raw`] 에 대한 이전 호출과 쌍을 이루어야합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // 마지막 약한 수를 줄입니다.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // 입력 포인터가 파생되는 방법에 대한 컨텍스트는 Weak::as_ptr 를 참조하십시오.

        let ptr = if is_dangling(ptr as *mut T) {
            // 이것은 매달린 Weak입니다.
            ptr as *mut ArcInner<T>
        } else {
            // 그렇지 않으면 포인터가 매달려 있지 않은 Weak에서 온 것이 보장됩니다.
            // 안전: ptr이 실제 (잠재적으로 삭제 된) T를 참조하므로 data_offset을 호출해도 안전합니다.
            let offset = unsafe { data_offset(ptr) };
            // 따라서 전체 RcBox를 얻기 위해 오프셋을 반대로합니다.
            // SAFETY: 포인터가 Weak에서 시작되었으므로이 오프셋은 안전합니다.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // 안전: 이제 원래 Weak 포인터를 복구 했으므로 Weak을 만들 수 있습니다.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` 포인터를 [`Arc`] 로 업그레이드하려고 시도하여 성공하면 내부 값 삭제를 지연시킵니다.
    ///
    ///
    /// 내부 값이 삭제 된 경우 [`None`] 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // 강력한 포인터를 모두 파괴하십시오.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // 이 함수는 참조 카운트를 0에서 1로 가져 가지 않아야하므로 CAS 루프를 사용하여 fetch_add 대신 강력한 카운트를 증가시킵니다.
        //
        //
        let inner = self.inner()?;

        // 우리가 관찰 할 수있는 0의 쓰기는 필드를 영구적으로 0 상태로 남겨두고 (따라서 "stale" 읽기가 0이면 괜찮음) 다른 값은 아래 CAS를 통해 확인되기 때문에 부하가 완화됩니다.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // 이 작업을 수행하는 이유는 `Arc::clone` 의 주석을 참조하십시오 (`mem::forget` 의 경우).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed는 새로운 상태에 대한 기대가 없기 때문에 실패 사례에 대해 괜찮습니다.
            // `Weak` 참조가 이미 생성 된 후 내부 값을 초기화 할 수있는 경우 성공 사례를 `Arc::new_cyclic` 와 동기화하려면 Acquire가 필요합니다.
            // 이 경우 완전히 초기화 된 값을 관찰 할 수 있습니다.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // 위에서 null 확인
                Err(old) => n = old,
            }
        }
    }

    /// 이 할당을 가리키는 강력한 (`Arc`) 포인터의 수를 가져옵니다.
    ///
    /// [`Weak::new`] 를 사용하여 `self` 를 만든 경우 0을 반환합니다.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// 이 할당을 가리키는 `Weak` 포인터 수의 근사치를 가져옵니다.
    ///
    /// [`Weak::new`] 를 사용하여 `self` 를 만들었거나 강력한 포인터가 남아 있지 않으면 0을 반환합니다.
    ///
    /// # Accuracy
    ///
    /// 구현 세부 사항으로 인해 다른 스레드가 동일한 할당을 가리키는`Arc` 또는`Weak`을 조작 할 때 반환 된 값이 어느 방향 으로든 1 씩 벗어날 수 있습니다.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // 약한 수를 읽은 후 하나 이상의 강한 포인터가 있음을 관찰했기 때문에 암시 적 약한 참조 (강한 참조가 살아있을 때마다 표시됨)가 약한 수를 관찰했을 때 여전히 주변에 있었으므로 안전하게 뺄 수 있다는 것을 알고 있습니다.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// 포인터가 매달려 있고 할당 된 `ArcInner` 가 없을 때 (즉,이 `Weak` 가 `Weak::new` 에 의해 생성 된 경우) `None` 를 반환합니다.
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // 필드가 동시에 변경 될 수 있으므로 "data" 필드를 포함하는 참조를 만들지 *않도록* 주의합니다 (예: 마지막 `Arc` 가 삭제되면 데이터 필드가 제자리에 삭제됩니다).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// 두 개의`Weak`이 동일한 할당 ([`ptr::eq`] 와 유사)을 가리 키거나 둘 다 할당을 가리 키지 않는 경우 (`Weak::new()`) 로 생성 되었기 때문에) `true` 를 반환합니다.
    ///
    ///
    /// # Notes
    ///
    /// 이것은 포인터를 비교하기 때문에 `Weak::new()` 가 할당을 가리 키지 않더라도 서로 동일하다는 것을 의미합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` 비교.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// 동일한 할당을 가리키는 `Weak` 포인터의 복제본을 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // 이것이 완화 된 이유는 Arc::clone() 의 주석을 참조하십시오.
        // fetch_add (잠금 무시)를 사용할 수 있습니다. 약한 개수는 *다른* 약한 포인터가 존재하지 않는 곳에서만 잠기기 때문입니다.
        //
        // (따라서이 경우이 코드를 실행할 수 없습니다).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // 이 작업을 수행하는 이유는 Arc::clone() 의 주석을 참조하십시오 (mem::forget 의 경우).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// 메모리를 할당하지 않고 새로운 `Weak<T>` 를 생성합니다.
    /// 반환 값에서 [`upgrade`] 를 호출하면 항상 [`None`] 가 제공됩니다.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` 포인터를 삭제합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // 아무것도 인쇄하지 않습니다
    /// drop(foo);        // "dropped!" 인쇄
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // 우리가 마지막 약한 포인터라는 것을 알게되면 데이터를 완전히 할당 해제 할 때입니다.메모리 순서에 대해서는 Arc::drop() 의 토론을 참조하십시오.
        //
        // 약한 카운트는 정확히 하나의 약한 참조가있는 경우에만 잠글 수 있기 때문에 여기서 잠긴 상태를 확인할 필요가 없습니다. 즉, 잠금이 해제 된 후에 만 발생할 수있는 나머지 약한 참조에서만 드롭이 실행될 수 있습니다.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// 여기서는이 전문화를 `&T` 에 대한보다 일반적인 최적화가 아닌 여기서 수행하고 있습니다. 그렇지 않으면 ref에 대한 모든 동등성 검사에 비용이 추가되기 때문입니다.
/// 우리는`Arc`가 큰 값을 저장하는 데 사용된다고 가정합니다.이 값은 복제 속도가 느리지 만 동등성을 확인하기에는 무거워서이 비용을 더 쉽게 갚을 수 있습니다.
///
/// 또한 두 개의`&T`보다 동일한 값을 가리키는 두 개의 `Arc` 클론이있을 가능성이 더 높습니다.
///
/// 우리는 `T: Eq` 를 `PartialEq` 로 고의적으로 비 반사적 일 때만 이것을 할 수 있습니다.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// 두 개의 'Arc'가 동일합니다.
    ///
    /// 두 개의 'Arc'는 서로 다른 할당에 저장되어 있어도 내부 값이 같으면 동일합니다.
    ///
    /// `T` 가 `Eq` (동등의 반사성을 의미 함)도 구현하는 경우 동일한 할당을 가리키는 두 개의 'Arc'는 항상 동일합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// 두 개의 'Arc'가 같지 않습니다.
    ///
    /// 두 개의 'Arc'는 내부 값이 같지 않으면 같지 않습니다.
    ///
    /// `T` 가 `Eq` (동등의 반사성을 의미 함)도 구현하는 경우 동일한 값을 가리키는 두 개의 'Arc'는 동일하지 않습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// 두 개의 'Arc'에 대한 부분 비교.
    ///
    /// 이 둘은 내부 값에서 `partial_cmp()` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// 두 개의 'Arc'에 대한 비교보다 작습니다.
    ///
    /// 둘은 내부 값에서 `<` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 두 개의 '호'에 대한 '작거나 같음'비교.
    ///
    /// 이 둘은 내부 값에서 `<=` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// 두 개의 'Arc'에 대한 비교보다 큽니다.
    ///
    /// 둘은 내부 값에서 `>` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 두 개의 '호'에 대한 '크거나 같음'비교.
    ///
    /// 이 둘은 내부 값에서 `>=` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// 두 개의 'Arc'비교.
    ///
    /// 이 둘은 내부 값에서 `cmp()` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` 에 대한 `Default` 값을 사용하여 새 `Arc<T>` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// 참조 횟수가 계산 된 슬라이스를 할당하고`v` 항목을 복제하여 채 웁니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// 참조 카운트 `str` 를 할당하고 여기에 `v` 를 복사합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// 참조 카운트 `str` 를 할당하고 여기에 `v` 를 복사합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// 박스형 개체를 새로운 참조 계산 할당으로 이동합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// 참조 카운트 된 슬라이스를 할당하고`v`의 항목을 여기로 이동합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec이 메모리를 해제하도록 허용하지만 내용을 파괴하지는 않습니다.
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` 의 각 요소를 가져와 `Arc<[T]>` 로 수집합니다.
    ///
    /// # 성능 특성
    ///
    /// ## 일반적인 경우
    ///
    /// 일반적으로 `Arc<[T]>` 로의 수집은 먼저 `Vec<T>` 로 수집하여 수행됩니다.즉, 다음을 작성할 때 :
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// 이것은 우리가 쓴 것처럼 작동합니다.
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // 첫 번째 할당 세트가 여기에서 발생합니다.
    ///     .into(); // 여기서 `Arc<[T]>` 에 대한 두 번째 할당이 발생합니다.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// 이것은 `Vec<T>` 를 구성하는 데 필요한만큼 여러 번 할당 한 다음 `Vec<T>` 를 `Arc<[T]>` 로 전환하기 위해 한 번 할당합니다.
    ///
    ///
    /// ## 알려진 길이의 반복자
    ///
    /// `Iterator` 가 `TrustedLen` 를 구현하고 정확한 크기이면 `Arc<[T]>` 에 대해 단일 할당이 이루어집니다.예를 들면 :
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // 여기서는 단일 할당 만 발생합니다.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` 로 수집하는 데 사용되는 전문화 trait.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // 이것은 `TrustedLen` 반복자의 경우입니다.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // 안전: 반복자의 길이와 길이가 정확한지 확인해야합니다.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // 정상적인 구현으로 돌아갑니다.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// 포인터 뒤의 페이로드에 대한 `ArcInner` 내에서 오프셋을 가져옵니다.
///
/// # Safety
///
/// 포인터는 T의 이전에 유효한 인스턴스를 가리켜 야하며 유효한 메타 데이터를 가져야하지만 T는 삭제할 수 있습니다.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // 크기가 지정되지 않은 값을 ArcInner의 끝에 맞 춥니 다.
    // RcBox는 repr(C) 이기 때문에 항상 메모리의 마지막 필드가됩니다.
    // 안전: 가능한 유일한 크기가 지정되지 않은 유형은 슬라이스, trait 객체,
    // 외부 유형, 입력 안전 요구 사항은 현재 align_of_val_raw의 요구 사항을 충족하기에 충분합니다.이것은 std 외부에서 의존 할 수없는 언어의 구현 세부 사항입니다.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}