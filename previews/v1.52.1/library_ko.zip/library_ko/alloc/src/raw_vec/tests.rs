use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // 타사 할당 자와 `RawVec` 간의 통합 테스트를 작성하는 것은 `RawVec` API가 오류가있는 할당 방법을 노출하지 않기 때문에 약간 까다롭기 때문에 할당자가 소진되었을 때 어떤 일이 발생하는지 확인할 수 없습니다 (panic 감지 이상).
    //
    //
    // 대신 `RawVec` 메서드가 스토리지를 예약 할 때 최소한 Allocator API를 통과하는지 확인합니다.
    //
    //
    //
    //
    //

    // 할당 시도가 실패하기 전에 고정 된 양의 연료를 소비하는 멍청한 할당 자입니다.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (재 할당이 발생하므로 50 + 150=200 단위의 연료 사용)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // 첫째, `reserve` 는 `reserve_exact` 와 같이 할당합니다.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97은 7의 두 배 이상이므로 `reserve` 는 `reserve_exact` 처럼 작동합니다.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3은 12의 절반보다 작으므로 `reserve` 는 기하 급수적으로 증가해야합니다.
        // 이 테스트를 작성하는 시점에서 증가 계수는 2이므로 새 용량은 24이지만 1.5 의 증가 계수도 괜찮습니다.
        //
        // 따라서 `>= 18` 가 주장됩니다.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}