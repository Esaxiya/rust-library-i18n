#![stable(feature = "wake_trait", since = "1.51.0")]
//! 비동기 작업 작업을위한 유형 및 Traits
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// 실행자에서 작업 깨우기 구현.
///
/// 이 trait 는 [`Waker`] 를 만드는 데 사용할 수 있습니다.
/// 실행자는이 trait 의 구현을 정의하고이를 사용하여 해당 실행자에서 실행되는 작업에 전달할 Waker를 구성 할 수 있습니다.
///
/// 이 trait 는 [`RawWaker`] 를 구성하는 것에 대한 메모리 안전하고 인체 공학적 대안입니다.
/// 작업을 깨우는 데 사용되는 데이터가 [`Arc`] 에 저장되는 공통 실행기 디자인을 지원합니다.
/// 일부 실행기 (특히 임베디드 시스템 용)는이 API를 사용할 수 없기 때문에 [`RawWaker`] 가 해당 시스템의 대안으로 존재합니다.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// future 를 가져와 현재 스레드에서 완료 될 때까지 실행하는 기본 `block_on` 함수입니다.
///
/// **Note:** 이 예제는 단순성을 위해 정확성을 교환합니다.
/// 교착 상태를 방지하기 위해 프로덕션 등급 구현은 `thread::unpark` 에 대한 중간 호출과 중첩 된 호출도 처리해야합니다.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// 호출 될 때 현재 스레드를 깨우는 waker.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// future 를 실행하여 현재 스레드에서 완료합니다.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // 폴링 될 수 있도록 future 를 고정합니다.
///     let mut fut = Box::pin(fut);
///
///     // future 에 전달할 새 컨텍스트를 만듭니다.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future 를 실행하여 완료합니다.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// 이 작업을 깨우십시오.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// 웨이 커를 사용하지 않고이 작업을 깨 웁니다.
    ///
    /// 실행기가 waker를 사용하지 않고 더 저렴한 방법으로 wake를 지원하는 경우이 메소드를 재정의해야합니다.
    /// 기본적으로 [`Arc`] 를 복제하고 복제에서 [`wake`] 를 호출합니다.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // 안전: 이것은 raw_waker가 안전하게 구성하기 때문에 안전합니다.
        // Arc의 RawWaker<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker를 구성하는이 비공개 함수는
// 이것을 `From<Arc<W>> for RawWaker` impl에 인라인하여 `From<Arc<W>> for Waker` 의 안전이 올바른 trait 디스패치에 의존하지 않도록 보장하고 대신 두 impl 모두이 함수를 직접 명시 적으로 호출합니다.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // 복제 할 호의 참조 횟수를 늘립니다.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // 가치로 깨우기, Arc를 Wake::wake 기능으로 이동
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // 참조로 깨우기, 웨이 커를 드롭하지 않도록 수동 드롭으로 감싸십시오.
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Arc on drop의 참조 횟수를 줄입니다.
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}