//! 연속적인 시퀀스에 대한 동적 크기보기, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! 슬라이스는 포인터와 길이로 표시되는 메모리 블록에 대한 뷰입니다.
//!
//! ```
//! // Vec 슬라이스
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // 배열을 슬라이스로 강제 변환
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! 슬라이스는 변경 가능하거나 공유됩니다.
//! 공유 슬라이스 유형은 `&[T]` 이고 변경 가능한 슬라이스 유형은 `&mut [T]` 이며 여기서 `T` 는 요소 유형을 나타냅니다.
//! 예를 들어 가변 슬라이스가 가리키는 메모리 블록을 변경할 수 있습니다.
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! 이 모듈에 포함 된 내용은 다음과 같습니다.
//!
//! ## Structs
//!
//! 슬라이스에 대한 반복을 나타내는 [`Iter`] 와 같이 슬라이스에 유용한 몇 가지 구조체가 있습니다.
//!
//! ## Trait 구현
//!
//! 슬라이스에 대한 공통 traits 의 여러 구현이 있습니다.몇 가지 예는 다음과 같습니다.
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], 요소 유형이 [`Eq`] 또는 [`Ord`] 인 슬라이스
//! * [`Hash`] - 요소 유형이 [`Hash`] 인 슬라이스의 경우.
//!
//! ## Iteration
//!
//! 슬라이스는 `IntoIterator` 를 구현합니다.반복기는 슬라이스 요소에 대한 참조를 생성합니다.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! 가변 슬라이스는 요소에 대한 가변 참조를 생성합니다.
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! 이 반복기는 슬라이스의 요소에 대한 가변 참조를 생성하므로 슬라이스의 요소 유형은 `i32` 인 반면 반복기의 요소 유형은 `&mut i32` 입니다.
//!
//!
//! * [`.iter`] [`.iter_mut`] 는 기본 반복자를 반환하는 명시 적 메서드입니다.
//! * 반복자를 반환하는 추가 메서드는 [`.split`], [`.splitn`], [`.chunks`], [`.windows`] 등입니다.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// 이 모듈에서 사용하는 대부분은 테스트 구성에서만 사용됩니다.
// unused_imports 경고를 고치는 것보다 끄는 것이 더 깨끗합니다.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// 기본 슬라이스 확장 방법
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB를 테스트하는 동안 `vec!` 매크로를 구현하는 데 필요합니다. 자세한 내용은이 파일의 `hack` 모듈을 참조하십시오.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB를 테스트하는 동안 `Vec::clone` 구현에 필요합니다. 자세한 내용은이 파일의 `hack` 모듈을 참조하십시오.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` 를 사용할 수없는 경우이 세 가지 기능은 실제로 `impl [T]` 에는 있지만 `core::slice::SliceExt` 에는없는 메서드이므로 `test_permutations` 테스트를 위해 이러한 기능을 제공해야합니다.
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // 이것은 `vec!` 매크로에서 주로 사용되며 성능 회귀를 유발하므로 여기에 인라인 속성을 추가해서는 안됩니다.
    // 토론 및 성능 결과는 #71204 를 참조하십시오.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // 항목은 아래 루프에서 초기화 된 것으로 표시되었습니다.
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM이 경계 검사를 제거하는 데 필요하며 zip보다 더 나은 코드 생성이 있습니다.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec이 할당되고 위에서 최소한이 길이로 초기화되었습니다.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` 의 용량으로 위에서 할당하고 아래의 ptr::copy_to_non_overlapping 에서 `s.len()` 로 초기화합니다.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// 슬라이스를 정렬합니다.
    ///
    /// 이 정렬은 안정적이며 (즉, 동일한 요소를 재정렬하지 않음)*O*(*n*\*log(* n*)) 최악의 경우).
    ///
    /// 적용 가능한 경우 불안정한 정렬이 선호됩니다. 일반적으로 안정적인 정렬보다 빠르고 보조 메모리를 할당하지 않기 때문입니다.
    /// [`sort_unstable`](slice::sort_unstable) 를 참조하십시오.
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 [timsort](https://en.wikipedia.org/wiki/Timsort) 에서 영감을 얻은 적응 형 반복 병합 정렬입니다.
    /// 슬라이스가 거의 정렬 된 경우 또는 차례로 연결된 둘 이상의 정렬 된 시퀀스로 구성된 경우 매우 빠르도록 설계되었습니다.
    ///
    ///
    /// 또한 임시 스토리지를 `self` 크기의 절반으로 할당하지만 짧은 슬라이스의 경우 비 할당 삽입 정렬이 대신 사용됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// 비교 기능을 사용하여 슬라이스를 정렬합니다.
    ///
    /// 이 정렬은 안정적이며 (즉, 동일한 요소를 재정렬하지 않음)*O*(*n*\*log(* n*)) 최악의 경우).
    ///
    /// 비교기 함수는 슬라이스의 요소에 대한 전체 순서를 정의해야합니다.순서가 전체가 아닌 경우 요소의 순서가 지정되지 않습니다.
    /// 다음과 같은 경우 주문은 총 주문입니다 (모든 `a`, `b` 및 `c`).
    ///
    /// * 전체 및 비대칭: `a < b`, `a == b` 또는 `a > b` 중 정확히 하나가 참이고
    /// * 전이, `a < b` 및 `b < c` 는 `a < c` 를 의미합니다.`==` 와 `>` 모두 동일해야합니다.
    ///
    /// 예를 들어, [`f64`] 는 `NaN != NaN` 때문에 [`Ord`] 를 구현하지 않지만 슬라이스에 `NaN` 가 포함되어 있지 않다는 것을 알면 `partial_cmp` 를 정렬 함수로 사용할 수 있습니다.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// 적용 가능한 경우 불안정한 정렬이 선호됩니다. 일반적으로 안정적인 정렬보다 빠르고 보조 메모리를 할당하지 않기 때문입니다.
    /// [`sort_unstable_by`](slice::sort_unstable_by) 를 참조하십시오.
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 [timsort](https://en.wikipedia.org/wiki/Timsort) 에서 영감을 얻은 적응 형 반복 병합 정렬입니다.
    /// 슬라이스가 거의 정렬 된 경우 또는 차례로 연결된 둘 이상의 정렬 된 시퀀스로 구성된 경우 매우 빠르도록 설계되었습니다.
    ///
    /// 또한 임시 스토리지를 `self` 크기의 절반으로 할당하지만 짧은 슬라이스의 경우 비 할당 삽입 정렬이 대신 사용됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // 역 정렬
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// 키 추출 기능을 사용하여 슬라이스를 정렬합니다.
    ///
    /// 이 정렬은 안정적이며 (즉, 동일한 요소를 재정렬하지 않음)*O*(*m*\* * n *\* log(*n*)) 최악의 경우, 여기서 핵심 기능은 *O*(*m*)입니다.
    ///
    /// 값 비싼 주요 기능 (예 :
    /// 간단한 속성 액세스 또는 기본 작업이 아닌 함수), [`sort_by_cached_key`](slice::sort_by_cached_key) 는 요소 키를 다시 계산하지 않기 때문에 훨씬 더 빠릅니다.
    ///
    ///
    /// 적용 가능한 경우 불안정한 정렬이 선호됩니다. 일반적으로 안정적인 정렬보다 빠르고 보조 메모리를 할당하지 않기 때문입니다.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) 를 참조하십시오.
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 [timsort](https://en.wikipedia.org/wiki/Timsort) 에서 영감을 얻은 적응 형 반복 병합 정렬입니다.
    /// 슬라이스가 거의 정렬 된 경우 또는 차례로 연결된 둘 이상의 정렬 된 시퀀스로 구성된 경우 매우 빠르도록 설계되었습니다.
    ///
    /// 또한 임시 스토리지를 `self` 크기의 절반으로 할당하지만 짧은 슬라이스의 경우 비 할당 삽입 정렬이 대신 사용됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// 키 추출 기능을 사용하여 슬라이스를 정렬합니다.
    ///
    /// 정렬 중에 키 기능은 요소 당 한 번만 호출됩니다.
    ///
    /// 이 정렬은 안정적이며 (즉, 동일한 요소를 재정렬하지 않음)*O*(*m*\* * n *+* n *\* log(*n*)) 최악의 경우, 여기서 키 함수는 *O*(*m*) .
    ///
    /// 간단한 키 기능 (예: 속성 액세스 또는 기본 작업 인 기능)의 경우 [`sort_by_key`](slice::sort_by_key) 가 더 빠를 수 있습니다.
    ///
    /// # 현재 구현
    ///
    /// 현재 알고리즘은 Orson Peters의 [pattern-defeating quicksort][pdqsort] 를 기반으로합니다.이 알고리즘은 임의의 퀵 정렬의 빠른 평균 사례와 힙 정렬의 빠른 최악의 경우를 결합하는 동시에 특정 패턴의 슬라이스에서 선형 시간을 달성합니다.
    /// 일부 무작위 화를 사용하여 퇴화 사례를 방지하지만 고정 된 seed 를 사용하여 항상 결정적 동작을 제공합니다.
    ///
    /// 최악의 경우 알고리즘은 슬라이스 길이의 `Vec<(K, usize)>` 에 임시 저장소를 할당합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // 할당을 줄이기 위해 가능한 가장 작은 유형으로 vector 를 인덱싱하는 도우미 매크로입니다.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` 의 요소는 인덱싱되므로 고유하므로 모든 정렬이 원본 슬라이스에 대해 안정적입니다.
                // 여기서는 메모리 할당량이 적기 때문에 `sort_unstable` 를 사용합니다.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` 를 새 `Vec` 로 복사합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // 여기서 `s` 및 `x` 는 독립적으로 수정할 수 있습니다.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// 할당자를 사용하여 `self` 를 새 `Vec` 에 복사합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // 여기서 `s` 및 `x` 는 독립적으로 수정할 수 있습니다.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, 자세한 내용은이 파일의 `hack` 모듈을 참조하십시오.
        hack::to_vec(self, alloc)
    }

    /// 복제 또는 할당없이 `self` 를 vector 로 변환합니다.
    ///
    /// 결과 vector 는`Vec를 통해 상자로 다시 변환 할 수 있습니다.<T>`의 `into_boxed_slice` 방식.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` `x` 로 변환되어 더 이상 사용할 수 없습니다.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, 자세한 내용은이 파일의 `hack` 모듈을 참조하십시오.
        hack::into_vec(self)
    }

    /// 슬라이스를 `n` 번 반복하여 vector 를 만듭니다.
    ///
    /// # Panics
    ///
    /// 이 기능은 용량이 오버플로되면 panic 가됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// 오버플로시 panic :
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` 가 0보다 크면 `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` 로 분할 할 수 있습니다.
        // `2^expn` `n` 의 가장 왼쪽 '1' 비트가 나타내는 숫자이고 `rem` 는 `n` 의 나머지 부분입니다.
        //
        //

        // `Vec` 를 사용하여 `set_len()` 에 액세스합니다.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` 반복은 `buf` expn` 배를 두 배로하여 수행됩니다.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` 이면 맨 왼쪽 '1' 까지 남은 비트가 있습니다.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` 용량은 `self.len() * n` 입니다.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) 반복은 `buf` 자체에서 첫 번째 `rem` 반복을 복사하여 수행됩니다.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // 이것은 `2^expn > rem` 이후로 겹치지 않습니다.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` 조각을 단일 값 `Self::Output` 로 병합합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` 슬라이스를 단일 값 `Self::Output` 로 평평하게 만들고 각각 사이에 지정된 구분 기호를 배치합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` 슬라이스를 단일 값 `Self::Output` 로 평평하게 만들고 각각 사이에 지정된 구분 기호를 배치합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// 각 바이트가 해당 ASCII 대문자에 매핑되는이 슬라이스의 복사본을 포함하는 vector 를 반환합니다.
    ///
    ///
    /// ASCII 문자 'a'-'z' 는 'A'-'Z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 내부 값을 대문자로 바꾸려면 [`make_ascii_uppercase`] 를 사용하십시오.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// 각 바이트가 해당 ASCII 소문자로 매핑되는이 슬라이스의 복사본을 포함하는 vector 를 반환합니다.
    ///
    ///
    /// ASCII 문자 'A'-'Z' 는 'a'-'z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 제자리에서 값을 소문자로 지정하려면 [`make_ascii_lowercase`] 를 사용합니다.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// 특정 종류의 데이터에 대한 슬라이스 용 확장 traits
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](slice::concat)에 대한 도우미 trait.
///
/// Note: `Item` 유형 매개 변수는이 trait 에서 사용되지 않지만 impls가 더 일반적 일 수 있습니다.
/// 이것이 없으면 다음 오류가 발생합니다.
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// 여러 `Borrow<[_]>` impls가있는 `V` 유형이 존재할 수 있으므로 여러 `T` 유형이 적용됩니다.
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// 연결 후 결과 유형
    type Output;

    /// [`[T]: : concat`](slice::concat) 구현
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`](slice::join)에 대한 도우미 trait
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// 연결 후 결과 유형
    type Output;

    /// [`[T]: : join`](slice::join) 구현
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// 슬라이스에 대한 표준 trait 구현
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // 덮어 쓰지 않을 대상에 아무것도 드롭하십시오.
        target.truncate(self.len());

        // target.len 위의 잘림으로 인해 <= self.len 이므로 여기의 슬라이스는 항상 인바운드입니다.
        //
        let (init, tail) = self.split_at(target.len());

        // 포함 된 값의 allocations/resources 를 재사용합니다.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` 를 미리 정렬 된 시퀀스 `v[1..]` 에 삽입하여 전체 `v[..]` 가 정렬되도록합니다.
///
/// 이것은 삽입 정렬의 필수 서브 루틴입니다.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // 여기에 삽입을 구현하는 세 가지 방법이 있습니다.
            //
            // 1. 첫 번째 요소가 최종 목적지에 도달 할 때까지 인접한 요소를 바꿉니다.
            //    그러나 이런 식으로 우리는 필요 이상으로 데이터를 복사합니다.
            //    요소가 큰 구조 (복사 비용이 많이 드는) 인 경우이 방법은 느립니다.
            //
            // 2. 첫 번째 요소의 올바른 위치를 찾을 때까지 반복하십시오.
            // 그런 다음 다음 요소를 이동하여 공간을 만들고 마지막으로 나머지 구멍에 배치합니다.
            // 이것은 좋은 방법입니다.
            //
            // 3. 첫 번째 요소를 임시 변수에 복사하십시오.올바른 위치를 찾을 때까지 반복하십시오.
            // 계속 진행하면서 모든 순회 요소를 그 앞의 슬롯에 복사합니다.
            // 마지막으로 임시 변수의 데이터를 나머지 구멍으로 복사합니다.
            // 이 방법은 아주 좋습니다.
            // 벤치 마크는 두 번째 방법보다 약간 더 나은 성능을 보여주었습니다.
            //
            // 모든 방법이 벤치마킹되었으며 세 번째 방법이 최상의 결과를 보여주었습니다.그래서 우리는 그것을 선택했습니다.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // 삽입 프로세스의 중간 상태는 항상 `hole` 에 의해 추적되며 두 가지 용도로 사용됩니다.
            // 1. `is_less` 의 panics 에서 `v` 의 무결성을 보호합니다.
            // 2. `v` 의 나머지 구멍을 끝까지 채 웁니다.
            //
            // Panic 안전 :
            //
            // 프로세스 중 어느 시점에서 `is_less` panics 가 발생하면 `hole` 가 떨어지고 `v` 의 구멍을 `tmp` 로 채우므로 `v` 가 처음에 정확히 한 번 보유한 모든 개체를 여전히 보유 할 수 있습니다.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` 삭제되어 `tmp` 를 `v` 의 나머지 구멍에 복사합니다.
        }
    }

    // 드롭하면 `src` 에서 `dest` 로 복사됩니다.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `buf` 를 임시 저장소로 사용하여 감소하지 않는 실행 `v[..mid]` 및 `v[mid..]` 를 병합하고 결과를 `v[..]` 에 저장합니다.
///
/// # Safety
///
/// 두 슬라이스는 비어 있지 않아야하며 `mid` 는 경계 내에 있어야합니다.
/// 버퍼 `buf` 는 더 짧은 슬라이스의 사본을 보유 할 수있을만큼 길어야합니다.
/// 또한 `T` 는 크기가 0 인 유형이 아니어야합니다.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // 병합 프로세스는 먼저 짧은 실행을 `buf` 로 복사합니다.
    // 그런 다음 새로 복사 된 실행과 더 긴 실행을 앞으로 (또는 뒤로) 추적하여 다음 소비되지 않은 요소를 비교하고 더 작은 (또는 더 큰) 요소를 `v` 에 복사합니다.
    //
    // 더 짧은 실행이 완전히 소비되면 프로세스가 완료됩니다.더 긴 런이 먼저 소모되면 더 짧은 런의 남은 부분을 `v` 의 나머지 구멍에 복사해야합니다.
    //
    // 프로세스의 중간 상태는 항상 `hole` 에 의해 추적되며 두 가지 용도로 사용됩니다.
    // 1. `is_less` 의 panics 에서 `v` 의 무결성을 보호합니다.
    // 2. 더 긴 실행이 먼저 소모되면 `v` 의 나머지 구멍을 채 웁니다.
    //
    // Panic 안전 :
    //
    // 프로세스 중 어느 시점에서 `is_less` panics 가 발생하면 `hole` 가 떨어지고 `buf` 의 사용되지 않은 범위로 `v` 의 구멍을 채우므로 `v` 가 처음에 정확히 한 번 보유한 모든 개체를 유지합니다.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // 왼쪽 실행이 더 짧습니다.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // 처음에 이러한 포인터는 배열의 시작을 가리 킵니다.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // 적은 쪽을 소비하십시오.
            // 동일한 경우 안정성을 유지하기 위해 왼쪽 실행을 선호합니다.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // 올바른 실행은 더 짧습니다.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // 처음에 이러한 포인터는 배열의 끝을 지납니다.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // 더 큰면을 소비하십시오.
            // 동일한 경우 안정성을 유지하기 위해 올바른 실행을 선호합니다.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // 마지막으로 `hole` 가 삭제됩니다.
    // 더 짧은 실행이 완전히 소모되지 않았다면 남은 것은 이제 `v` 의 구멍에 복사됩니다.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // 드롭하면 범위 `start..end` 를 `dest..` 로 복사합니다.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` 크기가 0이 아니므로 크기로 나누어도됩니다.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// 이 병합 정렬은 [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) 에 자세히 설명 된 TimSort에서 일부 (전부는 아님) 아이디어를 차용합니다.
///
///
/// 알고리즘은 내림차순 및 비 내림차순 하위 시퀀스를 식별하며이를 자연 실행이라고합니다.아직 병합되지 않은 보류중인 실행 스택이 있습니다.
/// 새로 발견 된 각 실행이 스택으로 푸시되고 다음 두 개의 불변성이 충족 될 때까지 인접한 실행의 일부 쌍이 병합됩니다.
///
/// 1. `1..runs.len()` 의 모든 `i` 에 대해 : `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` 의 모든 `i` 에 대해 : `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// 불변성은 총 실행 시간이 *O*(*n*\*log(* n*)) 최악의 경우입니다.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // 이 길이까지의 조각은 삽입 정렬을 사용하여 정렬됩니다.
    const MAX_INSERTION: usize = 20;
    // 매우 짧은 실행은 삽입 정렬을 사용하여 적어도이 많은 요소에 걸쳐 확장됩니다.
    const MIN_RUN: usize = 10;

    // 정렬은 크기가 0 인 유형에서 의미있는 동작이 없습니다.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // 짧은 배열은 할당을 피하기 위해 삽입 정렬을 통해 제자리에서 정렬됩니다.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // 스크래치 메모리로 사용할 버퍼를 할당하십시오.길이 0을 유지하여 `is_less` panics 인 경우 복사본에서 실행되는 dtor의 위험없이 `v` 내용의 얕은 복사본을 유지할 수 있습니다.
    //
    // 두 개의 정렬 된 실행을 병합 할 때이 버퍼는 더 짧은 실행의 사본을 보유하며 항상 최대 `len / 2` 길이를 갖습니다.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` 에서 자연스러운 실행을 식별하기 위해 뒤로 이동합니다.
    // 이상한 결정처럼 보일 수 있지만 병합이 더 자주 (forwards) 반대 방향으로 진행된다는 사실을 고려하십시오.
    // 벤치 마크에 따르면 앞으로 병합하는 것이 뒤로 병합하는 것보다 약간 빠릅니다.
    // 결론적으로, 뒤로 이동하여 실행을 식별하면 성능이 향상됩니다.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // 다음 자연 런을 찾고 엄격하게 하강하는 경우 반전하십시오.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // 너무 짧은 경우 실행에 더 많은 요소를 삽입하십시오.
        // 삽입 정렬은 짧은 시퀀스의 병합 정렬보다 빠르므로 성능이 크게 향상됩니다.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // 이 런을 스택으로 푸시합니다.
        runs.push(Run { start, len: end - start });
        end = start;

        // 불변을 충족시키기 위해 인접 런의 일부 쌍을 병합합니다.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // 마지막으로 정확히 하나의 실행이 스택에 남아 있어야합니다.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // 실행 스택을 검사하고 병합 할 다음 실행 쌍을 식별합니다.
    // 보다 구체적으로, `Some(r)` 가 반환되면 `runs[r]` 와 `runs[r + 1]` 가 다음에 병합되어야 함을 의미합니다.
    // 알고리즘이 대신 새 실행을 계속 빌드해야하는 경우 `None` 가 반환됩니다.
    //
    // TimSort는 다음과 같이 버그가 많은 구현으로 유명합니다.
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // 이야기의 요지는 스택의 상위 4 개 실행에서 불변성을 적용해야한다는 것입니다.
    // 상위 3 개에만 적용하는 것만으로는 스택의 *모든* 실행에 대해 불변성이 유지되도록하는 데 충분하지 않습니다.
    //
    // 이 함수는 상위 4 개 실행에 대한 불변을 올바르게 확인합니다.
    // 또한 최상위 실행이 인덱스 0에서 시작되면 정렬을 완료하기 위해 스택이 완전히 축소 될 때까지 항상 병합 작업을 요구합니다.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}