//! # Rust 코어 할당 및 컬렉션 라이브러리
//!
//! 이 라이브러리는 힙 할당 값을 관리하기위한 스마트 포인터 및 컬렉션을 제공합니다.
//!
//! libcore와 같은이 라이브러리는 내용이 [`std` crate](../std/index.html) 로 다시 내보내지기 때문에 일반적으로 직접 사용할 필요가 없습니다.
//! 그러나 `#![no_std]` 속성을 사용하는 Crates 는 일반적으로 `std` 에 의존하지 않으므로 대신이 crate 를 사용합니다.
//!
//! ## 박스형 값
//!
//! [`Box`] 유형은 스마트 포인터 유형입니다.[`Box`] 의 소유자는 한 명만있을 수 있으며 소유자는 힙에있는 컨텐츠를 변경하도록 결정할 수 있습니다.
//!
//! 이 유형은 `Box` 값의 크기가 포인터의 크기와 동일하므로 스레드간에 효율적으로 전송할 수 있습니다.
//! 트리와 유사한 데이터 구조는 종종 각 노드에 부모가 하나만 있기 때문에 상자로 구축됩니다.
//!
//! ## 참조 횟수 포인터
//!
//! [`Rc`] 유형은 스레드 내에서 메모리를 공유하기위한 비스 레드 세이프 참조 계수 포인터 유형입니다.
//! [`Rc`] 포인터는 `T` 유형을 래핑하고 공유 참조 인 `&T` 에 대한 액세스 만 허용합니다.
//!
//! 이 유형은 상속 된 변경 가능성 (예: [`Box`] 사용)이 애플리케이션에 너무 제한적일 때 유용하며, 변경을 허용하기 위해 종종 [`Cell`] 또는 [`RefCell`] 유형과 쌍을 이룹니다.
//!
//!
//! ## 원자 적으로 계산 된 포인터 참조
//!
//! [`Arc`] 유형은 [`Rc`] 유형에 상응하는 스레드 세이프 유형입니다.포함 된 유형 `T` 를 공유 할 수 있어야한다는 점을 제외하면 [`Rc`] 와 동일한 기능을 모두 제공합니다.
//! 또한 [`Arc<T>`][`Arc`] 자체는 보낼 수 있지만 [`Rc<T>`][`Rc`] 는 보낼 수 없습니다.
//!
//! 이 유형은 포함 된 데이터에 대한 공유 액세스를 허용하며 공유 리소스의 변형을 허용하기 위해 뮤텍스와 같은 동기화 기본 요소와 종종 쌍을 이룹니다.
//!
//! ## Collections
//!
//! 가장 일반적인 범용 데이터 구조의 구현이이 라이브러리에 정의되어 있습니다.[standard collections library](../std/collections/index.html) 를 통해 다시 내보내집니다.
//!
//! ## 힙 인터페이스
//!
//! [`alloc`](alloc/index.html) 모듈은 기본 전역 할당 자에 대한 저수준 인터페이스를 정의합니다.libc 할당 자 API와 호환되지 않습니다.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// 기술적으로 이것은 rustdoc의 버그입니다. rustdoc은 `#[lang = slice_alloc]` 블록에 대한 문서가 `&[T]` 용이라는 것을보고 `core` 에서이 기능을 사용하는 문서도 가지고 있으며 기능 게이트가 활성화되지 않은 것에 화를냅니다.
// 이상적으로는 다른 crates 의 문서에 대한 기능 게이트를 확인하지 않지만 lang 항목에만 나타날 수 있으므로 수정할 가치가없는 것 같습니다.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// 이 라이브러리 테스트 허용

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// 다른 모듈에서 사용하는 내부 매크로가있는 모듈 (다른 모듈보다 먼저 포함되어야 함).
#[macro_use]
mod macros;

// 낮은 수준의 할당 전략을 위해 제공되는 힙

pub mod alloc;

// 위의 힙을 사용하는 기본 유형

// 테스트 cfg에서 빌드 할 때 lang-items가 중복되지 않도록 `boxed.rs` 에서 모드를 조건부로 정의해야합니다.또한 코드에 `use boxed::Box;` 선언을 허용해야합니다.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}