//! 단일 스레드 참조 계수 포인터.'Rc' 는 'Reference
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] 유형은 힙에 할당 된 `T` 유형 값의 공유 소유권을 제공합니다.
//! [`Rc`] 에서 [`clone`][clone] 를 호출하면 힙의 동일한 할당에 대한 새 포인터가 생성됩니다.
//! 주어진 할당에 대한 마지막 [`Rc`] 포인터가 파괴되면 해당 할당에 저장된 값 (종종 "inner value" 라고 함)도 삭제됩니다.
//!
//! Rust 의 공유 참조는 기본적으로 변경을 허용하지 않으며 [`Rc`] 도 예외는 아닙니다. 일반적으로 [`Rc`] 내부의 항목에 대한 변경 가능한 참조를 얻을 수 없습니다.
//! 변경이 필요한 경우 [`Rc`] 안에 [`Cell`] 또는 [`RefCell`] 를 넣으십시오.[an example of mutability inside an `Rc`][mutability] 를 참조하십시오.
//!
//! [`Rc`] 비 원자 참조 계수를 사용합니다.
//! 이는 오버 헤드가 매우 낮지 만 스레드간에 [`Rc`] 를 보낼 수 없기 때문에 [`Rc`] 는 [`Send`][send] 를 구현하지 않음을 의미합니다.
//! 결과적으로 Rust 컴파일러는 *컴파일 시간* 에 스레드간에 [`Rc`]를 전송하지 않는지 확인합니다.
//! 다중 스레드 원자 참조 계산이 필요한 경우 [`sync::Arc`][arc] 를 사용하십시오.
//!
//! [`downgrade`][downgrade] 메서드는 소유하지 않은 [`Weak`] 포인터를 만드는 데 사용할 수 있습니다.
//! [`Weak`] 포인터는 [`Rc`] 로 [`upgrade`][업그레이드] 할 수 있지만 할당에 저장된 값이 이미 삭제 된 경우 [`None`] 를 반환합니다.
//! 즉, `Weak` 포인터는 할당 내의 값을 유지하지 않습니다.그러나 그들은 할당 (내부 값에 대한 백업 저장소)을 살아있는 상태로 유지합니다.
//!
//! [`Rc`] 포인터 사이의주기는 할당 해제되지 않습니다.
//! 이러한 이유로 [`Weak`] 는 사이클을 중단하는 데 사용됩니다.
//! 예를 들어, 트리는 부모 노드에서 자식으로의 강력한 [`Rc`] 포인터와 자식에서 부모로의 [`Weak`] 포인터를 가질 수 있습니다.
//!
//! `Rc<T>` ([`Deref`] trait 를 통해) `T` 를 자동으로 역 참조하므로 [`Rc<T>`][`Rc`] 유형의 값에 대해 'T'의 메서드를 호출 할 수 있습니다.
//! `T`의 메서드와 이름 충돌을 피하기 위해 [`Rc<T>`][`Rc`] 자체의 메서드는 [fully qualified syntax] 를 사용하여 호출되는 관련 함수입니다.
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`의 `Clone` 와 같은 traits 구현은 정규화 된 구문을 사용하여 호출 할 수도 있습니다.
//! 어떤 사람들은 정규화 된 구문을 선호하는 반면 다른 사람들은 메서드 호출 구문을 선호합니다.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // 메서드 호출 구문
//! let rc2 = rc.clone();
//! // 정규화 된 구문
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] 내부 값이 이미 삭제되었을 수 있으므로 `T` 에 대한 자동 역 참조를 수행하지 않습니다.
//!
//! # 참조 복제
//!
//! 기존 참조 카운트 포인터와 동일한 할당에 대한 새 참조를 만드는 것은 [`Rc<T>`][`Rc`] 및 [`Weak<T>`][`Weak`] 에 대해 구현 된 `Clone` trait 를 사용하여 수행됩니다.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // 아래의 두 구문은 동일합니다.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a와 b는 모두 foo와 동일한 메모리 위치를 가리 킵니다.
//! ```
//!
//! `Rc::clone(&from)` 구문은 코드의 의미를보다 명시 적으로 전달하기 때문에 가장 관용적입니다.
//! 위의 예에서이 구문을 사용하면이 코드가 foo의 전체 내용을 복사하는 대신 새 참조를 생성하고 있음을 쉽게 확인할 수 있습니다.
//!
//! # Examples
//!
//! 주어진 `Owner` 가`가젯`세트를 소유하는 시나리오를 고려하십시오.
//! 우리는`Gadget`이 `Owner` 를 가리 키도록하고 싶습니다.하나 이상의 가젯이 동일한 `Owner` 에 속할 수 있기 때문에 고유 한 소유권으로는이를 수행 할 수 없습니다.
//! [`Rc`] 여러`Gadget`간에 `Owner` 를 공유하고 `Gadget` 포인트가있는 한 `Owner` 를 할당 된 상태로 유지할 수 있습니다.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... 기타 분야
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... 기타 분야
//! }
//!
//! fn main() {
//!     // 참조 카운트 `Owner` 를 만듭니다.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` 에 속하는`가젯`을 만듭니다.
//!     // `Rc<Owner>` 를 복제하면 동일한 `Owner` 할당에 대한 새 포인터가 제공되어 프로세스에서 참조 횟수가 증가합니다.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // 로컬 변수 `gadget_owner` 를 폐기하십시오.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` 를 삭제 했음에도 불구하고`Gadget`의 `Owner` 이름을 인쇄 할 수 있습니다.
//!     // 이것은 우리가 가리키는 `Owner` 가 아니라 하나의 `Rc<Owner>` 만 떨어 뜨 렸기 때문입니다.
//!     // 동일한 `Owner` 할당을 가리키는 다른 `Rc<Owner>` 가있는 한 라이브 상태로 유지됩니다.
//!     // 필드 프로젝션 `gadget1.owner.name` 는 `Rc<Owner>` 가 `Owner` 를 자동으로 역 참조하기 때문에 작동합니다.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // 함수가 끝나면 `gadget1` 와 `gadget2` 가 파괴되고 `Owner` 에 대한 마지막 참조 참조가 함께 표시됩니다.
//!     // Gadget Man도 이제 파괴됩니다.
//!     //
//! }
//! ```
//!
//! 요구 사항이 변경되고 `Owner` 에서 `Gadget` 로 이동할 수 있어야하는 경우 문제가 발생합니다.
//! `Owner` 에서 `Gadget` 로의 [`Rc`] 포인터는주기를 도입합니다.
//! 즉, 참조 횟수가 0에 도달 할 수 없으며 할당이 파괴되지 않습니다.
//! 메모리 누수.이 문제를 해결하기 위해 [`Weak`] 포인터를 사용할 수 있습니다.
//!
//! Rust 는 실제로 처음에이 루프를 생성하는 것을 다소 어렵게 만듭니다.서로를 가리키는 두 개의 값으로 끝나려면 그 중 하나가 변경 가능해야합니다.
//! [`Rc`] 는 래핑하는 값에 대한 공유 참조 만 제공하여 메모리 안전을 강화하고 직접 변형을 허용하지 않기 때문에 어렵습니다.
//! *interior mutability* 를 제공하는 [`RefCell`] 에서 변경하려는 값의 일부를 래핑해야합니다. 공유 참조를 통해 변경 가능성을 달성하는 방법입니다.
//! [`RefCell`] 런타임에 Rust 의 차용 규칙을 적용합니다.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... 기타 분야
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... 기타 분야
//! }
//!
//! fn main() {
//!     // 참조 카운트 `Owner` 를 만듭니다.
//!     // 공유 참조를 통해 변형 할 수 있도록`Owner`의`Gadget`의 vector 를 `RefCell` 안에 넣었습니다.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // 이전과 같이 `gadget_owner` 에 속하는`가젯`을 만듭니다.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // '가젯'을 `Owner` 에 추가합니다.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` 다이나믹 빌리는 여기서 끝납니다.
//!     }
//!
//!     // '가젯'을 반복하여 세부 정보를 인쇄합니다.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` 입니다.
//!         // `Weak` 포인터는 할당이 여전히 존재한다고 보장 할 수 없기 때문에 `Option<Rc<Gadget>>` 를 반환하는 `upgrade` 를 호출해야합니다.
//!         //
//!         //
//!         // 이 경우 할당이 여전히 존재한다는 것을 알고 있으므로 간단히 `unwrap` 를 `Option` 로 지정합니다.
//!         // 더 복잡한 프로그램에서는 `None` 결과에 대해 우아한 오류 처리가 필요할 수 있습니다.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // 함수가 끝나면 `gadget_owner`, `gadget1` 및 `gadget2` 가 삭제됩니다.
//!     // 이제 가젯에 대한 강력한 (`Rc`) 포인터가 없으므로 파괴됩니다.
//!     // 이렇게하면 Gadget Man의 참조 횟수가 0이되므로 역시 파괴됩니다.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// 이것은 가능한 필드 재정렬에 대한 repr(C) 에서 future-증거이며, 변경 가능한 내부 유형의 안전한 [into|from]_raw() 를 방해 할 수 있습니다.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// 단일 스레드 참조 계수 포인터.'Rc' 는 'Reference
/// Counted'.
///
/// 자세한 내용은 [module-level documentation](./index.html) 를 참조하십시오.
///
/// `Rc` 의 고유 한 메서드는 모두 관련 함수이므로 `value.get_mut()` 대신 [`Rc::get_mut(&mut value)`][get_mut] 로 호출해야합니다.
/// 이것은 내부 유형 `T` 의 메소드와의 충돌을 방지합니다.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // 이 Rc가 살아있는 동안 내부 포인터가 유효하다는 것을 보장하기 때문에이 안전하지 않은 것은 괜찮습니다.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// 새로운 `Rc<T>` 를 생성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // 모든 strong 포인터가 소유 한 암시 적 weak 포인터가 있으며, 이는 weak 포인터가 strong 포인터 내부에 저장되어 있어도 strong 소멸자가 실행되는 동안 약한 소멸자가 할당을 해제하지 않도록합니다.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// 자신에 대한 약한 참조를 사용하여 새로운 `Rc<T>` 를 생성합니다.
    /// 이 함수가 반환되기 전에 약한 참조를 업그레이드하려고하면 `None` 값이 생성됩니다.
    ///
    /// 그러나 약한 참조는 자유롭게 복제하여 나중에 사용하기 위해 저장할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... 더 많은 분야
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // 단일 약한 참조를 사용하여 "uninitialized" 상태에서 내부를 구성합니다.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // 약한 포인터의 소유권을 포기하지 않는 것이 중요합니다. 그렇지 않으면 `data_fn` 가 반환 될 때 메모리가 해제 될 수 있습니다.
        // 정말로 소유권을 전달하고 싶다면 추가로 약한 포인터를 만들 수 있지만, 그렇지 않으면 필요하지 않을 수있는 약한 참조 카운트에 대한 추가 업데이트가 발생합니다.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // 강력한 참조는 공유 된 약한 참조를 집합 적으로 소유해야하므로 이전 약한 참조에 대해 소멸자를 실행하지 마십시오.
        //
        mem::forget(weak);
        strong
    }

    /// 초기화되지 않은 내용으로 새로운 `Rc` 를 생성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 지연된 초기화 :
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 메모리가 `0` 바이트로 채워지는 초기화되지 않은 내용으로 새로운 `Rc` 를 구성합니다.
    ///
    ///
    /// 이 방법의 올 바르고 잘못된 사용 예는 [`MaybeUninit::zeroed`][zeroed] 를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 새로운 `Rc<T>` 를 생성하고 할당이 실패하면 오류를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // 모든 strong 포인터가 소유 한 암시 적 weak 포인터가 있으며, 이는 weak 포인터가 strong 포인터 내부에 저장되어 있어도 strong 소멸자가 실행되는 동안 약한 소멸자가 할당을 해제하지 않도록합니다.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// 초기화되지 않은 내용으로 새로운 `Rc` 를 생성하고 할당이 실패하면 오류를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // 지연된 초기화 :
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// 메모리가 `0` 바이트로 채워지고 할당이 실패하면 오류를 반환하는 초기화되지 않은 내용으로 새 `Rc` 를 구성합니다.
    ///
    ///
    /// 이 방법의 올 바르고 잘못된 사용 예는 [`MaybeUninit::zeroed`][zeroed] 를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// 새로운 `Pin<Rc<T>>` 를 생성합니다.
    /// `T` 가 `Unpin` 를 구현하지 않으면 `value` 가 메모리에 고정되어 이동할 수 없습니다.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` 에 정확히 하나의 강력한 참조가있는 경우 내부 값을 반환합니다.
    ///
    /// 그렇지 않으면 [`Err`] 가 전달 된 동일한 `Rc` 와 함께 반환됩니다.
    ///
    ///
    /// 뛰어난 약한 참조가 있어도 성공합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // 포함 된 개체 복사

                // Weaks에게 strong count를 줄여서 승격 할 수 없음을 표시 한 다음, 가짜 Weak을 만들어 드롭 로직을 처리하는 동시에 암시 적 "strong weak" 포인터를 제거합니다.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// 초기화되지 않은 내용으로 새로운 참조 카운트 슬라이스를 구성합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 지연된 초기화 :
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// `0` 바이트로 채워지는 메모리를 사용하여 초기화되지 않은 내용으로 새로운 참조 카운트 슬라이스를 구성합니다.
    ///
    ///
    /// 이 방법의 올 바르고 잘못된 사용 예는 [`MaybeUninit::zeroed`][zeroed] 를 참조하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` 로 변환합니다.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] 와 마찬가지로 내부 값이 실제로 초기화 된 상태인지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 즉시 정의되지 않은 동작이 발생합니다.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 지연된 초기화 :
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` 로 변환합니다.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] 와 마찬가지로 내부 값이 실제로 초기화 된 상태인지 확인하는 것은 호출자에게 달려 있습니다.
    ///
    /// 콘텐츠가 아직 완전히 초기화되지 않았을 때 이것을 호출하면 즉시 정의되지 않은 동작이 발생합니다.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 지연된 초기화 :
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` 를 소비하고 래핑 된 포인터를 반환합니다.
    ///
    /// 메모리 누수를 방지하려면 [`Rc::from_raw`][from_raw] 를 사용하여 포인터를 `Rc` 로 다시 변환해야합니다.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// 데이터에 대한 원시 포인터를 제공합니다.
    ///
    /// 카운트는 어떤 방식으로도 영향을받지 않으며 `Rc` 는 소비되지 않습니다.
    /// 포인터는 `Rc` 에 강력한 카운트가있는 한 유효합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // 안전: Deref::deref 또는 Rc::inner 를 통과 할 수 없습니다.
        // 이것은 예를 들어 raw/mut 출처를 유지하는 데 필요합니다.
        // `get_mut` Rc가 `from_raw` 를 통해 복구 된 후 포인터를 통해 쓸 수 있습니다.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// 원시 포인터에서 `Rc<T>` 를 생성합니다.
    ///
    /// 원시 포인터는 [`Rc<U>::into_raw`][into_raw] 에 대한 호출에 의해 이전에 반환 되었어야합니다. 여기서 `U` 는 `T` 와 크기 및 정렬이 동일해야합니다.
    /// `U` 가 `T` 이면 이것은 사소한 사실입니다.
    /// `U` 가 `T` 가 아니지만 크기와 정렬이 같으면 기본적으로 다른 유형의 변환 참조와 같습니다.
    /// 이 경우 적용되는 제한 사항에 대한 자세한 내용은 [`mem::transmute`][transmute] 를 참조하십시오.
    ///
    /// `from_raw` 사용자는 `T` 의 특정 값이 한 번만 삭제되었는지 확인해야합니다.
    ///
    /// 이 함수는 반환 된 `Rc<T>` 에 액세스하지 않더라도 부적절한 사용으로 인해 메모리가 안전하지 않을 수 있으므로 안전하지 않습니다.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // 누출을 방지하려면 `Rc` 로 다시 변환하십시오.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` 에 대한 추가 호출은 메모리에 안전하지 않습니다.
    /// }
    ///
    /// // `x` 가 위의 범위를 벗어 났을 때 메모리가 해제되었으므로 `x_ptr` 는 이제 매달려 있습니다!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // 원래 RcBox를 찾으려면 오프셋을 반전하십시오.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// 이 할당에 대한 새 [`Weak`] 포인터를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // 매달린 Weak을 생성하지 않도록하십시오
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// 이 할당에 대한 [`Weak`] 포인터의 수를 가져옵니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// 이 할당에 대한 강력한 (`Rc`) 포인터 수를 가져옵니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// 이 할당에 대한 다른 `Rc` 또는 [`Weak`] 포인터가 없으면 `true` 를 반환합니다.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// 동일한 할당에 대한 다른 `Rc` 또는 [`Weak`] 포인터가없는 경우 지정된 `Rc` 에 대한 변경 가능한 참조를 반환합니다.
    ///
    ///
    /// 공유 값을 변경하는 것이 안전하지 않기 때문에 그렇지 않으면 [`None`] 를 반환합니다.
    ///
    /// 다른 포인터가있을 때 내부 값을 [`clone`][clone] 하는 [`make_mut`][make_mut] 도 참조하십시오.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// 검사없이 주어진 `Rc` 에 대한 가변 참조를 반환합니다.
    ///
    /// 안전하고 적절한 검사를 수행하는 [`get_mut`] 도 참조하십시오.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// 동일한 할당에 대한 다른 `Rc` 또는 [`Weak`] 포인터는 반환 된 차용 기간 동안 역 참조되지 않아야합니다.
    ///
    /// 예를 들어 `Rc::new` 바로 뒤에 그러한 포인터가 존재하지 않는 경우는 사소한 경우입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // 참조 횟수에 대한 액세스와 충돌 할 수 있으므로 "count" 필드를 다루는 참조를 만들지 *않도록* 주의합니다 (예 :
        // `Weak` 에 의해).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// 두 개의 'Rc'가 동일한 할당 ([`ptr::eq`] 와 유사한 정맥)을 가리키는 경우 `true` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// 주어진 `Rc` 에 대한 가변 참조를 만듭니다.
    ///
    /// 동일한 할당에 대한 다른 `Rc` 포인터가있는 경우 `make_mut` 는 고유 한 소유권을 보장하기 위해 새 할당에 대한 내부 값을 [`clone`] 합니다.
    /// 이를 기록 중 복제라고도합니다.
    ///
    /// 이 할당에 대한 다른 `Rc` 포인터가없는 경우이 할당에 대한 [`Weak`] 포인터는 연결 해제됩니다.
    ///
    /// 복제가 아닌 실패하는 [`get_mut`] 도 참조하십시오.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // 아무것도 복제하지 않습니다
    /// let mut other_data = Rc::clone(&data);    // 내부 데이터를 복제하지 않습니다.
    /// *Rc::make_mut(&mut data) += 1;        // 내부 데이터 복제
    /// *Rc::make_mut(&mut data) += 1;        // 아무것도 복제하지 않습니다
    /// *Rc::make_mut(&mut other_data) *= 2;  // 아무것도 복제하지 않습니다
    ///
    /// // 이제 `data` 및 `other_data` 는 다른 할당을 가리 킵니다.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] 포인터가 연결 해제됩니다.
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // 데이터를 복제해야합니다. 다른 Rcs가 있습니다.
            // 복제 된 값을 직접 쓸 수 있도록 메모리를 미리 할당합니다.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // 데이터를 훔칠 수있어 남은 건 Weaks뿐
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // 암시 적 strong-weak 참조 제거 (여기에서 가짜 Weak을 만들 필요 없음-다른 Weak이 우리를 위해 정리할 수 있음을 알고 있음)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // 반환 된 포인터가 T에 반환 될 *유일한* 포인터라는 것을 보장하기 때문에이 안전하지 않은 것은 괜찮습니다.
        // 이 시점에서 참조 횟수는 1로 보장되며 `Rc<T>` 자체가 `mut` 여야하므로 할당에 대한 유일한 참조를 반환합니다.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` 를 구체적인 유형으로 다운 캐스트하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// 값에 제공된 레이아웃이있는 경우 크기를 조정할 수없는 내부 값에 충분한 공간이있는 `RcBox<T>` 를 할당합니다.
    ///
    /// 함수 `mem_to_rcbox` 는 데이터 포인터와 함께 호출되며 `RcBox<T>` 에 대한 (잠재적으로 뚱뚱한) 포인터를 반환해야합니다.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // 주어진 값 레이아웃을 사용하여 레이아웃을 계산합니다.
        // 이전에는 `&*(ptr as* const RcBox<T>)` 표현식에서 레이아웃이 계산되었지만 이로 인해 잘못 정렬 된 참조가 생성되었습니다 (#54908 참조).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// 값에 제공된 레이아웃이있는 크기가 조정되지 않은 내부 값에 충분한 공간이있는 `RcBox<T>` 를 할당하고 할당에 실패하면 오류를 반환합니다.
    ///
    ///
    /// 함수 `mem_to_rcbox` 는 데이터 포인터와 함께 호출되며 `RcBox<T>` 에 대한 (잠재적으로 뚱뚱한) 포인터를 반환해야합니다.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // 주어진 값 레이아웃을 사용하여 레이아웃을 계산합니다.
        // 이전에는 `&*(ptr as* const RcBox<T>)` 표현식에서 레이아웃이 계산되었지만 이로 인해 잘못 정렬 된 참조가 생성되었습니다 (#54908 참조).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // 레이아웃에 할당하십시오.
        let ptr = allocate(layout)?;

        // RcBox 초기화
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// 크기가 지정되지 않은 내부 값에 충분한 공간이있는 `RcBox<T>` 를 할당합니다.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // 주어진 값을 사용하여 `RcBox<T>` 에 할당하십시오.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // 값을 바이트로 복사
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // 내용을 삭제하지 않고 할당 해제
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// 주어진 길이로 `RcBox<[T]>` 를 할당합니다.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// 슬라이스에서 새로 할당 된 Rc <\[T\]>로 요소 복사
    ///
    /// 호출자가 소유권을 갖거나 `T: Copy` 를 바인딩해야하기 때문에 안전하지 않습니다.
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// 특정 크기로 알려진 반복기에서 `Rc<[T]>` 를 구성합니다.
    ///
    /// 크기가 잘못되면 동작이 정의되지 않습니다.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T 요소를 복제하는 동안 Panic 가드.
        // panic 의 경우 새 RcBox에 기록 된 요소가 삭제 된 다음 메모리가 해제됩니다.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // 첫 번째 요소에 대한 포인터
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // 공습 경보 해제.가드를 잊어 버려 새로운 RcBox를 해제하지 마십시오.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` 에 사용되는 전문화 trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` 를 삭제합니다.
    ///
    /// 강력한 참조 횟수가 감소합니다.
    /// 강력한 참조 횟수가 0에 도달하면 다른 참조 (있는 경우) 만 [`Weak`] 이므로 내부 값을 `drop` 합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // 아무것도 인쇄하지 않습니다
    /// drop(foo2);   // "dropped!" 인쇄
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // 포함 된 개체를 파괴
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // 내용이 삭제되었으므로 암시 적 "strong weak" 포인터를 제거합니다.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` 포인터의 복제본을 만듭니다.
    ///
    /// 이렇게하면 동일한 할당에 대한 또 다른 포인터가 만들어지고 강력한 참조 수가 증가합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` 에 대한 `Default` 값을 사용하여 새 `Rc<T>` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` 에 메서드가 있어도 `Eq` 에 특화 할 수 있도록 해킹합니다.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// 여기서는이 전문화를 `&T` 에 대한보다 일반적인 최적화가 아닌 여기서 수행하고 있습니다. 그렇지 않으면 ref에 대한 모든 동등성 검사에 비용이 추가되기 때문입니다.
/// 우리는`Rc`가 큰 값을 저장하는 데 사용된다고 가정합니다.이 값은 복제 속도가 느리지 만 동등성을 확인하기에는 무거워서이 비용을 더 쉽게 지불 할 수 있습니다.
///
/// 또한 두 개의`&T`보다 동일한 값을 가리키는 두 개의 `Rc` 클론이있을 가능성이 더 높습니다.
///
/// 우리는 `T: Eq` 를 `PartialEq` 로 고의적으로 비 반사적 일 때만 이것을 할 수 있습니다.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// 두 개의 'Rc'에 대한 동등성.
    ///
    /// 두 개의 'Rc'는 서로 다른 할당에 저장되어 있어도 내부 값이 같으면 동일합니다.
    ///
    /// `T` 가 `Eq` (동등의 반사성을 의미 함)도 구현하는 경우 동일한 할당을 가리키는 두 개의 'Rc'는 항상 동일합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// 두 개의 'Rc'에 대한 부등식.
    ///
    /// 두 개의 'Rc'는 내부 값이 같지 않으면 같지 않습니다.
    ///
    /// `T` 가 `Eq` (동등의 반사성을 의미 함)도 구현하는 경우 동일한 할당을 가리키는 두 개의 'Rc'는 동일하지 않습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// 두 개의 'Rc'에 대한 부분 비교.
    ///
    /// 이 둘은 내부 값에서 `partial_cmp()` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// 두 개의 'Rc'에 대한 비교보다 작습니다.
    ///
    /// 둘은 내부 값에서 `<` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 두 개의 'Rc'에 대한 '작거나 같음'비교.
    ///
    /// 이 둘은 내부 값에서 `<=` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// 두 개의 'Rc'에 대한 비교보다 큽니다.
    ///
    /// 둘은 내부 값에서 `>` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 두 개의 'Rc'에 대한 '크거나 같음'비교.
    ///
    /// 이 둘은 내부 값에서 `>=` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// 두 개의 'Rc'에 대한 비교.
    ///
    /// 이 둘은 내부 값에서 `cmp()` 를 호출하여 비교됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// 참조 횟수가 계산 된 슬라이스를 할당하고`v` 항목을 복제하여 채 웁니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// 참조 카운트 문자열 슬라이스를 할당하고 여기에 `v` 를 복사합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// 참조 카운트 문자열 슬라이스를 할당하고 여기에 `v` 를 복사합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// 박스형 개체를 새 참조 계산 할당으로 이동합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// 참조 카운트 된 슬라이스를 할당하고`v`의 항목을 여기로 이동합니다.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec이 메모리를 해제하도록 허용하지만 내용을 파괴하지는 않습니다.
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` 의 각 요소를 가져와 `Rc<[T]>` 로 수집합니다.
    ///
    /// # 성능 특성
    ///
    /// ## 일반적인 경우
    ///
    /// 일반적으로 `Rc<[T]>` 로의 수집은 먼저 `Vec<T>` 로 수집하여 수행됩니다.즉, 다음을 작성할 때 :
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// 이것은 우리가 쓴 것처럼 작동합니다.
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // 첫 번째 할당 세트가 여기에서 발생합니다.
    ///     .into(); // 여기서 `Rc<[T]>` 에 대한 두 번째 할당이 발생합니다.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// 이것은 `Vec<T>` 를 구성하는 데 필요한만큼 여러 번 할당 한 다음 `Vec<T>` 를 `Rc<[T]>` 로 전환하기 위해 한 번 할당합니다.
    ///
    ///
    /// ## 알려진 길이의 반복자
    ///
    /// `Iterator` 가 `TrustedLen` 를 구현하고 정확한 크기이면 `Rc<[T]>` 에 대해 단일 할당이 이루어집니다.예를 들면 :
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // 여기서는 단일 할당 만 발생합니다.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` 로 수집하는 데 사용되는 전문화 trait.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // 이것은 `TrustedLen` 반복자의 경우입니다.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // 안전: 반복자의 길이와 길이가 정확한지 확인해야합니다.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // 정상적인 구현으로 돌아갑니다.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` 관리 할당에 대한 비 소유 참조를 보유하는 [`Rc`] 버전입니다.할당은 [`Option`]`<`[`Rc`]`를 반환하는 `Weak` 포인터에서 [`upgrade`] 를 호출하여 액세스합니다.<T>>`.
///
/// `Weak` 참조는 소유권에 포함되지 않기 때문에 할당에 저장된 값이 삭제되는 것을 방지하지 않으며 `Weak` 자체는 여전히 존재하는 값에 대해 보장하지 않습니다.
/// 따라서 [`업그레이드`] d시 [`None`] 를 반환 할 수 있습니다.
/// 그러나 `Weak` 참조는 할당 자체 (백킹 저장소)가 할당 해제되는 것을 방지 *합니다*.
///
/// `Weak` 포인터는 내부 값이 삭제되는 것을 방지하지 않고 [`Rc`] 가 관리하는 할당에 대한 임시 참조를 유지하는 데 유용합니다.
/// 또한 상호 소유 참조는 [`Rc`] 가 삭제되는 것을 허용하지 않으므로 [`Rc`] 포인터 간의 순환 참조를 방지하는데도 사용됩니다.
/// 예를 들어, 트리는 부모 노드에서 자식으로의 강력한 [`Rc`] 포인터와 자식에서 부모로의 `Weak` 포인터를 가질 수 있습니다.
///
/// `Weak` 포인터를 얻는 일반적인 방법은 [`Rc::downgrade`] 를 호출하는 것입니다.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // 이것은 열거 형에서이 유형의 크기를 최적화 할 수있는 `NonNull` 이지만 반드시 유효한 포인터는 아닙니다.
    //
    // `Weak::new` 힙에 공간을 할당 할 필요가 없도록 `usize::MAX` 로 설정합니다.
    // RcBox에 최소 2 개의 정렬이 있기 때문에 실제 포인터가 가질 수있는 값이 아닙니다.
    // 이것은 `T: Sized` 일 때만 가능합니다.크기가 지정되지 않은 `T` 는 결코 매달리지 않습니다.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// 메모리를 할당하지 않고 새로운 `Weak<T>` 를 생성합니다.
    /// 반환 값에서 [`upgrade`] 를 호출하면 항상 [`None`] 가 제공됩니다.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// 데이터 필드에 대한 어설 션을 만들지 않고 참조 횟수에 액세스 할 수있는 도우미 유형입니다.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// 이 `Weak<T>` 가 가리키는 오브젝트 `T` 에 대한 원시 포인터를 리턴합니다.
    ///
    /// 포인터는 강력한 참조가있는 경우에만 유효합니다.
    /// 포인터가 매달려 있거나 정렬되지 않았거나 아니면 [`null`] 일 수도 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // 둘 다 동일한 객체를 가리 킵니다.
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // 여기에있는 강한 사람은 그것을 살아있게 유지하므로 우리는 여전히 객체에 접근 할 수 있습니다.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // 그러나 더 이상은 아닙니다.
    /// // weak.as_ptr() 를 수행 할 수 있지만 포인터에 액세스하면 정의되지 않은 동작이 발생합니다.
    /// // assert_eq! ("hello", 안전하지 않음 {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // 포인터가 매달려 있으면 센티넬을 직접 반환합니다.
            // 페이로드가 최소한 RcBox (usize) 만큼 정렬되어 있으므로 유효한 페이로드 주소가 될 수 없습니다.
            ptr as *const T
        } else {
            // 안전: is_dangling이 false를 반환하면 포인터가 참조 할 수 없습니다.
            // 이 시점에서 페이로드가 삭제 될 수 있으며 출처를 유지해야하므로 원시 포인터 조작을 사용하십시오.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` 를 소비하고 원시 포인터로 바꿉니다.
    ///
    /// 이는 약한 포인터를 원시 포인터로 변환하는 동시에 하나의 약한 참조의 소유권을 유지합니다 (약한 수는이 작업에 의해 수정되지 않음).
    /// [`from_raw`] 를 사용하여 `Weak<T>` 로 되돌릴 수 있습니다.
    ///
    /// [`as_ptr`] 와 마찬가지로 포인터 대상에 액세스하는 것과 동일한 제한이 적용됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// [`into_raw`] 에서 이전에 만든 원시 포인터를 다시 `Weak<T>` 로 변환합니다.
    ///
    /// 이것은 안전하게 강력한 참조를 얻거나 (나중에 [`upgrade`] 를 호출하여) `Weak<T>` 를 삭제하여 약한 카운트를 할당 해제하는 데 사용할 수 있습니다.
    ///
    /// 하나의 약한 참조에 대한 소유권을 갖습니다 ([`new`] 에 의해 생성 된 포인터는 아무것도 소유하지 않기 때문에 예외입니다. 메서드는 여전히 작동합니다).
    ///
    /// # Safety
    ///
    /// 포인터는 [`into_raw`] 에서 시작되어야하며 여전히 잠재적 인 약한 참조를 소유해야합니다.
    ///
    /// 이것을 호출 할 때 강한 카운트는 0이 될 수 있습니다.
    /// 그럼에도 불구하고 이것은 현재 원시 포인터로 표시되는 하나의 약한 참조의 소유권을 가져 오므로 (약한 카운트는이 작업에 의해 수정되지 않음) [`into_raw`] 에 대한 이전 호출과 쌍을 이루어야합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // 마지막 약한 수를 줄입니다.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // 입력 포인터가 파생되는 방법에 대한 컨텍스트는 Weak::as_ptr 를 참조하십시오.

        let ptr = if is_dangling(ptr as *mut T) {
            // 이것은 매달린 Weak입니다.
            ptr as *mut RcBox<T>
        } else {
            // 그렇지 않으면 포인터가 매달려 있지 않은 Weak에서 온 것이 보장됩니다.
            // 안전: ptr이 실제 (잠재적으로 삭제 된) T를 참조하므로 data_offset을 호출해도 안전합니다.
            let offset = unsafe { data_offset(ptr) };
            // 따라서 전체 RcBox를 얻기 위해 오프셋을 반대로합니다.
            // SAFETY: 포인터가 Weak에서 시작되었으므로이 오프셋은 안전합니다.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // 안전: 이제 원래 Weak 포인터를 복구 했으므로 Weak을 만들 수 있습니다.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` 포인터를 [`Rc`] 로 업그레이드하려고 시도하여 성공하면 내부 값 삭제를 지연시킵니다.
    ///
    ///
    /// 내부 값이 삭제 된 경우 [`None`] 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // 강력한 포인터를 모두 파괴하십시오.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// 이 할당을 가리키는 강력한 (`Rc`) 포인터의 수를 가져옵니다.
    ///
    /// [`Weak::new`] 를 사용하여 `self` 를 만든 경우 0을 반환합니다.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// 이 할당을 가리키는 `Weak` 포인터의 수를 가져옵니다.
    ///
    /// 강력한 포인터가 남아 있지 않으면 0을 반환합니다.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // 암시 적 약한 ptr 빼기
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// 포인터가 매달려 있고 할당 된 `RcBox` 가 없을 때 (즉,이 `Weak` 가 `Weak::new` 에 의해 생성 된 경우) `None` 를 반환합니다.
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // 필드가 동시에 변경 될 수 있으므로 "data" 필드를 포함하는 참조를 만들지 *않도록* 주의합니다 (예: 마지막 `Rc` 가 삭제되면 데이터 필드가 제자리에 삭제됩니다).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// 두 개의`Weak`이 동일한 할당 ([`ptr::eq`] 와 유사)을 가리 키거나 둘 다 할당을 가리 키지 않는 경우 (`Weak::new()`) 로 생성 되었기 때문에) `true` 를 반환합니다.
    ///
    ///
    /// # Notes
    ///
    /// 이것은 포인터를 비교하기 때문에 `Weak::new()` 가 할당을 가리 키지 않더라도 서로 동일하다는 것을 의미합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` 비교.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` 포인터를 삭제합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // 아무것도 인쇄하지 않습니다
    /// drop(foo);        // "dropped!" 인쇄
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // 약한 카운트는 1에서 시작하고 모든 강한 포인터가 사라진 경우에만 0이됩니다.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// 동일한 할당을 가리키는 `Weak` 포인터의 복제본을 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// 초기화하지 않고 `T` 에 대한 메모리를 할당하여 새 `Weak<T>` 를 구성합니다.
    /// 반환 값에서 [`upgrade`] 를 호출하면 항상 [`None`] 가 제공됩니다.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget 를 안전하게 처리하기 위해 여기에서 확인 _ 추가했습니다.특히
// mem::forget Rcs (또는 Weaks) 인 경우 ref-count가 오버플로 될 수 있으며 미해결 Rcs (또는 Weaks)가 존재하는 동안 할당을 해제 할 수 있습니다.
//
// 이것은 우리가 무슨 일이 일어나는지 신경 쓰지 않는 그러한 퇴보적인 시나리오이기 때문에 중단합니다. 실제 프로그램은 이것을 경험해서는 안됩니다.
//
// 소유권 및 이동 시맨틱 덕분에 Rust 에서 실제로 복제 할 필요가 없기 때문에 오버 헤드는 무시할 수있을 것입니다.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // 값을 삭제하는 대신 오버플로시 중단하려고합니다.
        // 이것이 호출 될 때 참조 횟수는 0이되지 않습니다.
        // 그럼에도 불구하고 여기에 중단을 삽입하여 그렇지 않으면 놓친 최적화에서 LLVM을 암시합니다.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // 값을 삭제하는 대신 오버플로시 중단하려고합니다.
        // 이것이 호출 될 때 참조 횟수는 0이되지 않습니다.
        // 그럼에도 불구하고 여기에 중단을 삽입하여 그렇지 않으면 놓친 최적화에서 LLVM을 암시합니다.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// 포인터 뒤의 페이로드에 대한 `RcBox` 내에서 오프셋을 가져옵니다.
///
/// # Safety
///
/// 포인터는 T의 이전에 유효한 인스턴스를 가리켜 야하며 유효한 메타 데이터를 가져야하지만 T는 삭제할 수 있습니다.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // 크기가 조정되지 않은 값을 RcBox의 끝에 맞 춥니 다.
    // RcBox는 repr(C) 이기 때문에 항상 메모리의 마지막 필드가됩니다.
    // 안전: 가능한 유일한 크기가 지정되지 않은 유형은 슬라이스, trait 객체,
    // 외부 유형, 입력 안전 요구 사항은 현재 align_of_val_raw의 요구 사항을 충족하기에 충분합니다.이것은 std 외부에서 의존 할 수없는 언어의 구현 세부 사항입니다.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}