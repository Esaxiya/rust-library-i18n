//! 유니 코드 문자열 조각.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` 유형은 두 가지 주요 문자열 유형 중 하나이며 다른 하나는 `String` 입니다.
//! `String` 대응 물과 달리 내용은 대여됩니다.
//!
//! # 기본 사용법
//!
//! `&str` 유형의 기본 문자열 선언 :
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! 여기에서는 문자열 슬라이스라고도하는 문자열 리터럴을 선언했습니다.
//! 문자열 리터럴에는 정적 수명이 있습니다. 즉, 문자열 `hello_world` 가 전체 프로그램 기간 동안 유효 함을 보장합니다.
//!
//! `hello_world`의 수명도 명시 적으로 지정할 수 있습니다.
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// 이 모듈에서 사용하는 대부분은 테스트 구성에서만 사용됩니다.
// unused_imports 경고를 고치는 것보다 끄는 것이 더 깨끗합니다.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` 의 `str` 는 여기서 의미가 없습니다.
/// trait 의이 유형 매개 변수는 다른 impl을 활성화하기 위해서만 존재합니다.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // 하드 코딩 된 크기의 루프는 훨씬 빠르게 실행되며 분리기 길이가 작은 경우를 전문화
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // 0이 아닌 임의의 크기 대체
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// 두 Vec 모두에서 작동하는 최적화 된 조인 구현<T>(T: Copy) 및 String의 내부 vec 현재 (2018-05-13) 에는 유형 추론 및 전문화에 버그가 있습니다 (문제 #36262 참조) 이러한 이유로 SliceConcat<T>T: Copy 및 SliceConcat에 특화되지 않았습니다.<str>이 기능의 유일한 사용자입니다.
// 그것이 고정 된 시간 동안 제자리에 남아 있습니다.
//
// String-join의 경계는 S: Borrow입니다.<str>Vec-join Borrow <[T]> [T] 및 str의 경우 둘 다 impl AsRef <[T]> 일부 T에 대해
// => s.borrow().as_ref() 그리고 우리는 항상 조각이 있습니다
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // 첫 번째 조각은 앞에 구분 기호가없는 유일한 조각입니다.
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` 계산이 오버플로되는 경우 결합 된 Vec의 정확한 총 길이를 계산합니다. 어쨌든 메모리가 부족할 수있는 panic 가 발생하고 나머지 함수는 안전을 위해 사전 할당 된 전체 Vec를 필요로합니다.
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // 초기화되지 않은 버퍼 준비
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // 경계 검사없이 구분자 및 슬라이스를 복사하면 작은 구분자에 대해 하드 코딩 된 오프셋이있는 루프가 생성됩니다 (~ x2).
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // 이상한 차용 구현은 길이 계산과 실제 복사본에 대해 다른 조각을 반환 할 수 있습니다.
        //
        // 호출자에게 초기화되지 않은 바이트를 노출하지 않도록하십시오.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// 문자열 조각에 대한 메서드.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// 복사 또는 할당없이 `Box<str>` 를 `Box<[u8]>` 로 변환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// 패턴의 모든 일치를 다른 문자열로 바꿉니다.
    ///
    /// `replace` 새 [`String`] 를 만들고이 문자열 조각의 데이터를 여기에 복사합니다.
    /// 이렇게하는 동안 일치하는 패턴을 찾으려고 시도합니다.
    /// 발견되면 대체 문자열 슬라이스로 대체합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// 패턴이 일치하지 않는 경우 :
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// 패턴의 처음 N 개 일치 항목을 다른 문자열로 바꿉니다.
    ///
    /// `replacen` 새 [`String`] 를 만들고이 문자열 조각의 데이터를 여기에 복사합니다.
    /// 이렇게하는 동안 일치하는 패턴을 찾으려고 시도합니다.
    /// 발견되면 최대 `count` 번 대체 문자열 슬라이스로 대체합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// 패턴이 일치하지 않는 경우 :
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // 재 할당 시간 단축
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// 이 문자열 슬라이스에 해당하는 소문자를 새 [`String`] 로 반환합니다.
    ///
    /// 'Lowercase' 유니 코드 파생 코어 속성 `Lowercase` 의 조건에 따라 정의됩니다.
    ///
    /// 일부 문자는 대소 문자를 변경할 때 여러 문자로 확장 될 수 있으므로이 함수는 매개 변수를 제자리에서 수정하는 대신 [`String`] 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// 시그마를 사용한 까다로운 예 :
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // 그러나 단어의 끝에는 σ가 아니라 ς입니다.
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// 대소 문자가없는 언어는 변경되지 않습니다.
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ는 ς에 매핑되는 단어의 끝을 제외하고 σ에 매핑됩니다.
                // 이것은 유일한 조건부 (contextual) 이지만 `SpecialCasing.txt` 의 언어 독립적 매핑이므로 일반적인 "condition" 메커니즘을 사용하는 대신 하드 코딩하십시오.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` 의 정의를 위해.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// 이 문자열 슬라이스에 해당하는 대문자를 새로운 [`String`] 로 반환합니다.
    ///
    /// 'Uppercase' 유니 코드 파생 핵심 속성 `Uppercase` 의 조건에 따라 정의됩니다.
    ///
    /// 일부 문자는 대소 문자를 변경할 때 여러 문자로 확장 될 수 있으므로이 함수는 매개 변수를 제자리에서 수정하는 대신 [`String`] 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// 대소 문자가없는 스크립트는 변경되지 않습니다.
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// 한 문자가 여러 개가 될 수 있습니다.
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// 복사 또는 할당없이 [`Box<str>`] 를 [`String`] 로 변환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// 문자열 `n` 를 반복하여 새 [`String`] 를 만듭니다.
    ///
    /// # Panics
    ///
    /// 이 기능은 용량이 오버플로되면 panic 가됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// 오버플로시 panic :
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// 각 문자가 해당 ASCII 대문자로 매핑되는이 문자열의 복사본을 반환합니다.
    ///
    ///
    /// ASCII 문자 'a'-'z' 는 'A'-'Z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 내부 값을 대문자로 바꾸려면 [`make_ascii_uppercase`] 를 사용하십시오.
    ///
    /// 비 ASCII 문자 외에 ASCII 문자를 대문자로하려면 [`to_uppercase`] 를 사용하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 불변을 유지합니다.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// 각 문자가 해당 ASCII 소문자로 매핑되는이 문자열의 복사본을 반환합니다.
    ///
    ///
    /// ASCII 문자 'A'-'Z' 는 'a'-'z' 에 매핑되지만 비 ASCII 문자는 변경되지 않습니다.
    ///
    /// 제자리에서 값을 소문자로 지정하려면 [`make_ascii_lowercase`] 를 사용합니다.
    ///
    /// 비 ASCII 문자 외에 ASCII 문자를 소문자로하려면 [`to_lowercase`] 를 사용하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 불변을 유지합니다.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// 문자열에 유효한 UTF-8 가 포함되어 있는지 확인하지 않고 박스형 바이트 조각을 박스형 문자열 조각으로 변환합니다.
///
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}