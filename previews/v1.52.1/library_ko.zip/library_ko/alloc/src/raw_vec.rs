#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// 새 메모리의 내용은 초기화되지 않습니다.
    Uninitialized,
    /// 새 메모리는 0으로 보장됩니다.
    Zeroed,
}

/// 관련된 모든 코너 케이스에 대해 걱정할 필요없이 힙에 메모리 버퍼를보다 인체 공학적으로 할당, 재 할당 및 할당 해제하는 저수준 유틸리티입니다.
///
/// 이 유형은 Vec 및 VecDeque와 같은 고유 한 데이터 구조를 구축하는 데 탁월합니다.
/// 특히:
///
/// * 크기가 0 인 유형에서 `Unique::dangling()` 를 생성합니다.
/// * 길이가 0 인 할당에서 `Unique::dangling()` 를 생성합니다.
/// * `Unique::dangling()` 해제를 방지합니다.
/// * 용량 계산에서 모든 오버플로를 포착합니다 ("capacity overflow" panics 로 승격).
/// * isize::MAX 바이트 이상을 할당하는 32 비트 시스템으로부터 보호합니다.
/// * 길이가 넘치지 않도록 보호합니다.
/// * 잘못된 할당을 위해 `handle_alloc_error` 를 호출합니다.
/// * `ptr::Unique` 를 포함하여 사용자에게 모든 관련 혜택을 제공합니다.
/// * 할당 자에서 반환 된 초과분을 사용하여 사용 가능한 최대 용량을 사용합니다.
///
/// 이 유형은 어쨌든 관리하는 메모리를 검사하지 않습니다.떨어 뜨리면 메모리가 *비워 지지만* 내용물을 떨어 뜨리려고 시도하지는 않습니다.
/// `RawVec` 내부에 *저장된* 실제 물건을 처리하는 것은 `RawVec` 의 사용자에게 달려 있습니다.
///
/// 크기가 0 인 유형의 초과는 항상 무한하므로 `capacity()` 는 항상 `usize::MAX` 를 반환합니다.
/// 이것은 `capacity()` 가 길이를 산출하지 않기 때문에 `Box<[T]>` 로이 유형을 라운드 트립 할 때주의해야 함을 의미합니다.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): 이것은 `#[unstable]` const fn`이 `min_const_fn` 를 따를 필요가 없어서`min_const_fn`s에서도 호출 될 수 없기 때문에 존재합니다.
    ///
    /// `RawVec<T>::new` 또는 종속성을 변경하는 경우 실제로 `min_const_fn` 를 위반하는 항목을 도입하지 않도록주의하십시오.
    ///
    /// NOTE: 우리는이 해킹을 피하고 `min_const_fn` 준수를 요구하지만 `#[rustc_const_unstable(feature = "foo", issue = "01234")]` 가있을 때 `foo` 를 활성화하지 않는 사용자 코드에서 반드시 `stable(...) const fn`/사용자 코드에서 호출하는 것을 허용하지 않는 일부 `#[rustc_force_min_const_fn]` 속성과의 준수를 확인할 수 있습니다.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// 할당하지 않고 가능한 가장 큰 `RawVec` (시스템 힙에서)를 만듭니다.
    /// `T` 의 크기가 양수이면 용량이 `0` 인 `RawVec` 가됩니다.
    /// `T` 의 크기가 0이면 `usize::MAX` 용량의 `RawVec` 를 만듭니다.
    /// 지연된 할당을 구현하는 데 유용합니다.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` 에 대한 용량 및 정렬 요구 사항을 정확히 충족하는 `RawVec` (시스템 힙에)를 만듭니다.
    /// 이는 `capacity` 가 `0` 이거나 `T` 의 크기가 0 일 때 `RawVec::new` 를 호출하는 것과 같습니다.
    /// `T` 의 크기가 0 인 경우 요청 된 용량의 `RawVec` 를 얻지 못함을 의미합니다.
    ///
    /// # Panics
    ///
    /// 요청 된 용량이 `isize::MAX` 바이트를 초과하는 경우 Panics.
    ///
    /// # Aborts
    ///
    /// OOM에서 중단합니다.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` 와 비슷하지만 버퍼가 0이되도록 보장합니다.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// 포인터와 용량에서 `RawVec` 를 재구성합니다.
    ///
    /// # Safety
    ///
    /// `ptr` 는 지정된 `capacity` 와 함께 시스템 힙에 할당되어야합니다.
    /// `capacity` 는 크기 유형에 대해 `isize::MAX` 를 초과 할 수 없습니다.(32 비트 시스템에만 해당).
    /// ZST vectors 는 최대 `usize::MAX` 의 용량을 가질 수 있습니다.
    /// `ptr` 및 `capacity` 가 `RawVec` 에서 제공되는 경우 이는 보장됩니다.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs는 멍청합니다.건너 뛰기 :
    // - 모든 힙 할당자는 8 바이트 미만의 요청을 최소 8 바이트로 반올림 할 가능성이 높기 때문에 요소 크기가 1이면 8입니다.
    //
    // - 요소가 중간 크기 인 경우 4입니다 (<=1KiB).
    // - 1 그렇지 않으면 매우 짧은 Vecs에 너무 많은 공간을 낭비하지 않도록합니다.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` 와 비슷하지만 반환 된 `RawVec` 에 대한 할당 자 선택에 대해 매개 변수화되었습니다.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" 를 의미합니다.크기가 0 인 유형은 무시됩니다.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` 와 비슷하지만 반환 된 `RawVec` 에 대한 할당 자 선택에 대해 매개 변수화되었습니다.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` 와 비슷하지만 반환 된 `RawVec` 에 대한 할당 자 선택에 대해 매개 변수화되었습니다.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` 를 `RawVec<T>` 로 변환합니다.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// 지정된 `len` 를 사용하여 전체 버퍼를 `Box<[MaybeUninit<T>]>` 로 변환합니다.
    ///
    /// 이렇게하면 수행되었을 수있는 모든 `cap` 변경 사항이 올바르게 재구성됩니다.(자세한 내용은 유형 설명을 참조하십시오.)
    ///
    /// # Safety
    ///
    /// * `len` 가장 최근에 요청한 용량보다 크거나 같아야합니다.
    /// * `len` `self.capacity()` 보다 작거나 같아야합니다.
    ///
    /// 할당자가 요청한 것보다 더 큰 메모리 블록을 할당하고 반환 할 수 있으므로 요청 된 용량과 `self.capacity()` 가 다를 수 있습니다.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // 안전 요구 사항의 절반을 온 전성 확인합니다 (다른 절반은 확인할 수 없음).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // 여기서 `unwrap_or_else` 는 생성되는 LLVM IR의 양을 늘리기 때문에 피합니다.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// 포인터, 용량 및 할당 자에서 `RawVec` 를 재구성합니다.
    ///
    /// # Safety
    ///
    /// `ptr` 는 (주어진 할당 자 `alloc` 를 통해) 주어진 `capacity` 와 함께 할당되어야합니다.
    /// `capacity` 는 크기 유형에 대해 `isize::MAX` 를 초과 할 수 없습니다.
    /// (32 비트 시스템에만 해당).
    /// ZST vectors 는 최대 `usize::MAX` 의 용량을 가질 수 있습니다.
    /// `ptr` 및 `capacity` 가 `alloc` 를 통해 생성 된 `RawVec` 에서 제공되는 경우 이는 보장됩니다.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// 할당 시작에 대한 원시 포인터를 가져옵니다.
    /// `capacity == 0` 또는 `T` 의 크기가 0 인 경우 `Unique::dangling()` 입니다.
    /// 전자의 경우주의해야합니다.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// 할당 용량을 가져옵니다.
    ///
    /// `T` 의 크기가 0이면 항상 `usize::MAX` 입니다.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// 이 `RawVec` 를 지원하는 할당 자에 대한 공유 참조를 리턴합니다.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // 할당 된 메모리 청크가 있으므로 현재 레이아웃을 얻기 위해 런타임 검사를 우회 할 수 있습니다.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// 버퍼에 `len + additional` 요소를 보유하기에 충분한 공간이 있는지 확인합니다.
    /// 용량이 아직 충분하지 않은 경우 상각 *O*(1) 동작을 얻기 위해 충분한 공간과 편안한 여유 공간을 재 할당합니다.
    ///
    /// 불필요하게 panic 가되는 경우이 동작을 제한합니다.
    ///
    /// `len` 가 `self.capacity()` 를 초과하면 요청 된 공간을 실제로 할당하지 못할 수 있습니다.
    /// 이것은 실제로 안전하지 않은 것은 아니지만이 함수의 동작에 의존하는 *사용자* 가 작성한 안전하지 않은 코드가 손상 될 수 있습니다.
    ///
    /// 이는 `extend` 와 같은 대량 푸시 작업을 구현하는 데 이상적입니다.
    ///
    /// # Panics
    ///
    /// 새 용량이 `isize::MAX` 바이트를 초과하는 경우 Panics.
    ///
    /// # Aborts
    ///
    /// OOM에서 중단합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // len이 `isize::MAX` 를 초과하면 예약이 중단되거나 당황했을 것이므로 지금 확인하지 않아도 안전합니다.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` 와 동일하지만 당황하거나 중단하는 대신 오류를 반환합니다.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// 버퍼에 `len + additional` 요소를 보유하기에 충분한 공간이 있는지 확인합니다.
    /// 아직 그렇지 않은 경우 필요한 최소 메모리 양을 재 할당합니다.
    /// 일반적으로 이것은 정확히 필요한 메모리 양이지만 원칙적으로 할당자는 요청한 것보다 더 많이 돌려 줄 수 있습니다.
    ///
    ///
    /// `len` 가 `self.capacity()` 를 초과하면 요청 된 공간을 실제로 할당하지 못할 수 있습니다.
    /// 이것은 실제로 안전하지 않은 것은 아니지만이 함수의 동작에 의존하는 *사용자* 가 작성한 안전하지 않은 코드가 손상 될 수 있습니다.
    ///
    /// # Panics
    ///
    /// 새 용량이 `isize::MAX` 바이트를 초과하는 경우 Panics.
    ///
    /// # Aborts
    ///
    /// OOM에서 중단합니다.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` 와 동일하지만 당황하거나 중단하는 대신 오류를 반환합니다.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// 할당을 지정된 양으로 줄입니다.
    /// 주어진 양이 0이면 실제로 완전히 할당 해제됩니다.
    ///
    /// # Panics
    ///
    /// Panics 주어진 양이 현재 용량보다 *큰* 경우.
    ///
    /// # Aborts
    ///
    /// OOM에서 중단합니다.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// 필요한 추가 용량을 충족하기 위해 버퍼를 확장해야하는 경우 반환합니다.
    /// `grow` 를 인라인하지 않고 인라인 예약 호출을 가능하게하는 데 주로 사용됩니다.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // 이 메서드는 일반적으로 여러 번 인스턴스화됩니다.그래서 우리는 컴파일 시간을 개선하기 위해 가능한 한 작기를 원합니다.
    // 그러나 생성 된 코드를 더 빠르게 실행하기 위해 가능한 한 많은 내용을 정적으로 계산할 수 있기를 원합니다.
    // 따라서이 메서드는 `T` 에 의존하는 모든 코드가 그 안에 있도록 신중하게 작성되었으며, 가능한 한 `T` 에 의존하지 않는 코드는 `T` 보다 제네릭이 아닌 함수에 있습니다.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // 이것은 호출 컨텍스트에 의해 보장됩니다.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` 가 다음과 같을 때 `usize::MAX` 의 용량을 반환하기 때문에
            // 0, 여기에 도달하는 것은 반드시 `RawVec` 가 과도하다는 것을 의미합니다.
            return Err(CapacityOverflow);
        }

        // 슬프게도 우리가이 수표에 대해 정말 할 수있는 일은 없습니다.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // 이것은 기하 급수적 인 성장을 보장합니다.
        // `cap <= isize::MAX` 와 `cap` 의 유형이 `usize` 이기 때문에 두 배로 오버플로 할 수 없습니다.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` 보다 일반적이지 않습니다.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // 이 메서드에 대한 제약은 `grow_amortized` 의 제약 조건과 거의 동일하지만이 메서드는 일반적으로 인스턴스화되는 빈도가 적으므로 덜 중요합니다.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // 유형 크기가 다음과 같을 때 `usize::MAX` 의 용량을 반환하기 때문에
            // 0, 여기에 도달하는 것은 반드시 `RawVec` 가 과도하다는 것을 의미합니다.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` 보다 일반적이지 않습니다.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// 이 함수는 컴파일 시간을 최소화하기 위해 `RawVec` 외부에 있습니다.자세한 내용은 `RawVec::grow_amortized` 위의 주석을 참조하십시오.
// (실제로 보이는 다른 `A` 유형의 수가 `T` 유형의 수보다 훨씬 적기 때문에 `A` 매개 변수는 중요하지 않습니다.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` 의 크기를 최소화하려면 여기에서 오류를 확인하십시오.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // 할당자는 정렬 평등을 확인합니다.
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// 내용을 삭제하려고 *하지 않고*`RawVec` 가 소유 한 메모리를 해제합니다.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// 예약 오류 처리를위한 중앙 기능.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// 다음 사항을 보장해야합니다.
// * 우리는 `> isize::MAX` 바이트 크기 객체를 할당하지 않습니다.
// * 우리는 `usize::MAX` 를 오버플로하지 않고 실제로 너무 적게 할당합니다.
//
// 64 비트에서는 `> isize::MAX` 바이트를 할당하려는 시도가 확실히 실패하므로 오버플로만 확인하면됩니다.
// 32 비트 및 16 비트에서는 PAE 또는 x32 와 같이 사용자 공간에서 4GB를 모두 사용할 수있는 플랫폼에서 실행중인 경우이를 위해 추가 가드를 추가해야합니다.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// 용량 오버플로보고를 담당하는 하나의 중앙 기능.
// 이렇게하면 panics 와 관련된 코드 생성이 최소화됩니다. 모듈 전체에 걸쳐 panics 가있는 위치가 하나만 있기 때문입니다.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}