//! UTF-8로 인코딩되고 확장 가능한 문자열입니다.
//!
//! 이 모듈에는 [`String`] 유형, 문자열로 변환하기위한 [`ToString`] trait 및 [`String`] 작업으로 인해 발생할 수있는 여러 오류 유형이 포함되어 있습니다.
//!
//!
//! # Examples
//!
//! 문자열 리터럴에서 새 [`String`] 를 만드는 방법에는 여러 가지가 있습니다.
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! 다음과 연결하여 기존 [`String`] 에서 새 [`String`] 를 만들 수 있습니다.
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! 유효한 UTF-8 바이트의 vector 가 있으면 [`String`] 를 만들 수 있습니다.반대로도 할 수 있습니다.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // 이 바이트가 유효하다는 것을 알고 있으므로 `unwrap()` 를 사용합니다.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8로 인코딩되고 확장 가능한 문자열입니다.
///
/// `String` 유형은 문자열 내용에 대한 소유권이있는 가장 일반적인 문자열 유형입니다.빌린 상대 인 원시 [`str`] 와 밀접한 관계가 있습니다.
///
/// # Examples
///
/// [`String::from`] 를 사용하여 [a literal string][`str`] 에서 `String` 를 만들 수 있습니다.
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// [`push`] 메서드를 사용하여 [`char`] 를 `String` 에 추가하고 [`push_str`] 메서드를 사용하여 [`&str`] 를 추가 할 수 있습니다.
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// UTF-8 바이트의 vector 가있는 경우 [`from_utf8`] 메서드를 사용하여 `String` 를 만들 수 있습니다.
///
/// ```
/// // vector 의 일부 바이트
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // 이 바이트가 유효하다는 것을 알고 있으므로 `unwrap()` 를 사용합니다.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`은 항상 유효한 UTF-8 입니다.여기에는 몇 가지 의미가 있습니다. 첫 번째는 UTF-8이 아닌 문자열이 필요한 경우 [`OsString`] 를 고려한다는 것입니다.비슷하지만 UTF-8 제약이 없습니다.두 번째 의미는 `String` 로 인덱싱 할 수 없다는 것입니다.
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// 인덱싱은 일정한 시간 작업을위한 것이지만 UTF-8 인코딩은이를 허용하지 않습니다.게다가 인덱스가 어떤 종류의 것을 반환해야하는지 (바이트, 코드 포인트 또는 자소 클러스터)가 명확하지 않습니다.
/// [`bytes`] 및 [`chars`] 메서드는 각각 처음 두 개에 대한 반복자를 반환합니다.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`의 구현 [`Deref`]`<Target=str>`, 따라서 [`str`]의 모든 메서드를 상속합니다.또한 이것은 앰퍼샌드 (`&`) 를 사용하여 [`&str`] 를받는 함수에 `String` 를 전달할 수 있음을 의미합니다.
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// 이렇게하면 `String` 에서 [`&str`] 가 생성되어 전달됩니다.이 변환은 매우 저렴하므로 일반적으로 함수는 특정 이유로 `String` 가 필요하지 않는 한 [`&str`]을 인수로 받아들입니다.
///
/// 어떤 경우에는 Rust 에 [`Deref`] 강제 변환이라고하는이 변환을 수행하는 데 충분한 정보가 없습니다.다음 예에서 문자열 슬라이스 [`&'a str`][`&str`] 는 trait `TraitExample` 를 구현하고 `example_func` 함수는 trait 를 구현하는 모든 것을 취합니다.
/// 이 경우 Rust 는 두 개의 암시 적 변환을 수행해야하는데, Rust 에는 수행 할 수단이 없습니다.
/// 따라서 다음 예제는 컴파일되지 않습니다.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// 대신 작동하는 두 가지 옵션이 있습니다.첫 번째는 [`as_str()`] 메서드를 사용하여 문자열을 포함하는 문자열 슬라이스를 명시 적으로 추출하여 `example_func(&example_string);` 줄을 `example_func(example_string.as_str());` 로 변경하는 것입니다.
/// 두 번째 방법은 `example_func(&example_string);` 를 `example_func(&*example_string);` 로 변경합니다.
/// 이 경우 `String` 를 [`str`][`&str`] 로 역 참조한 다음 [`str`][`&str`] 를 다시 [`&str`] 로 참조합니다.
/// 두 번째 방법은 더 관용적이지만 둘 다 암시 적 변환에 의존하는 대신 명시 적으로 변환을 수행합니다.
///
/// # Representation
///
/// `String` 는 일부 바이트에 대한 포인터, 길이 및 용량의 세 가지 구성 요소로 구성됩니다.포인터는 `String` 가 데이터를 저장하는 데 사용하는 내부 버퍼를 가리 킵니다.길이는 현재 버퍼에 저장된 바이트 수이고 용량은 버퍼의 크기 (바이트)입니다.
///
/// 따라서 길이는 항상 용량보다 작거나 같습니다.
///
/// 이 버퍼는 항상 힙에 저장됩니다.
///
/// [`as_ptr`], [`len`] 및 [`capacity`] 메서드를 사용하여이를 볼 수 있습니다.
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts가 안정화되면 업데이트합니다.
/// // 문자열의 데이터 자동 삭제 방지
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // 스토리에는 19 바이트가 있습니다.
/// assert_eq!(19, len);
///
/// // ptr, len 및 용량으로 문자열을 다시 빌드 할 수 있습니다.
/// // 구성 요소가 유효한지 확인할 책임이 있기 때문에 이것은 모두 안전하지 않습니다.
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// `String` 에 충분한 용량이 있으면 여기에 요소를 추가해도 재 할당되지 않습니다.예를 들어 다음 프로그램을 고려하십시오.
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// 그러면 다음이 출력됩니다.
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// 처음에는 메모리가 전혀 할당되지 않았지만 문자열에 추가하면 용량이 적절하게 증가합니다.대신 [`with_capacity`] 방법을 사용하여 처음에 올바른 용량을 할당하는 경우 :
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// 우리는 다른 출력으로 끝납니다.
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// 여기에서는 루프 내부에 더 많은 메모리를 할당 할 필요가 없습니다.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// `String` 를 UTF-8 바이트 vector 에서 변환 할 때 가능한 오류 값입니다.
///
/// 이 유형은 [`String`] 의 [`from_utf8`] 메소드에 대한 오류 유형입니다.
/// 재 할당을 조심스럽게 피하도록 설계되었습니다. [`into_bytes`] 메서드는 변환 시도에 사용 된 vector 바이트를 반환합니다.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] 에서 제공하는 [`Utf8Error`] 유형은 [`u8`]의 슬라이스를 [`&str`] 로 변환 할 때 발생할 수있는 오류를 나타냅니다.
/// 이러한 의미에서 `FromUtf8Error` 와 유사하며 [`utf8_error`] 방법을 통해 `FromUtf8Error` 에서 얻을 수 있습니다.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// // vector 의 일부 잘못된 바이트
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 바이트 슬라이스에서 `String` 를 변환 할 때 가능한 오류 값입니다.
///
/// 이 유형은 [`String`] 의 [`from_utf16`] 메소드에 대한 오류 유형입니다.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// 비어있는 새 `String` 를 만듭니다.
    ///
    /// `String` 가 비어 있으면 초기 버퍼를 할당하지 않습니다.이는이 초기 작업이 매우 저렴하다는 것을 의미하지만 나중에 데이터를 추가 할 때 과도한 할당이 발생할 수 있습니다.
    ///
    /// `String` 가 보유 할 데이터의 양을 알고 있다면 과도한 재 할당을 방지하기 위해 [`with_capacity`] 방법을 고려하십시오.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// 특정 용량으로 비어있는 새 `String` 를 만듭니다.
    ///
    /// '문자열'에는 데이터를 저장할 내부 버퍼가 있습니다.
    /// 용량은 해당 버퍼의 길이이며 [`capacity`] 방법으로 쿼리 할 수 있습니다.
    /// 이 메소드는 빈 `String` 를 작성하지만 `capacity` 바이트를 보유 할 수있는 초기 버퍼가있는 하나를 작성합니다.
    /// 이것은 `String` 에 많은 데이터를 추가하여 수행해야하는 재 할당 횟수를 줄일 때 유용합니다.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// 주어진 용량이 `0` 이면 할당이 발생하지 않으며이 방법은 [`new`] 방법과 동일합니다.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // 문자열에는 더 많은 용량이 있어도 문자가 없습니다.
    /// assert_eq!(s.len(), 0);
    ///
    /// // 이 모든 작업은 재 할당없이 수행됩니다.
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ...하지만 이로 인해 문자열이 재 할당 될 수 있습니다.
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) 에서는이 방법 정의에 필요한 고유 `[T]::to_vec` 방법을 사용할 수 없습니다.
    // 테스트 목적으로이 방법이 필요하지 않으므로 자세한 내용은 slice.rs 의 slice::hack 모듈을 참조하십시오.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector 바이트를 `String` 로 변환합니다.
    ///
    /// ([`String`]) 문자열은 ([`u8`]) 바이트로 구성되고 ([`Vec<u8>`]) 바이트의 vector 는 바이트로 구성되므로이 함수는 둘 사이를 변환합니다.
    /// 모든 바이트 슬라이스가 유효한`String`은 아니지만 `String` 는 유효한 UTF-8 여야합니다.
    /// `from_utf8()` 바이트가 유효한 UTF-8 인지 확인한 다음 변환을 수행합니다.
    ///
    /// 바이트 슬라이스가 유효한 UTF-8 임을 확신하고 유효성 검사의 오버 헤드를 발생시키지 않으려면이 함수의 안전하지 않은 버전 인 [`from_utf8_unchecked`] 가 있습니다.이 함수는 동작이 동일하지만 검사를 건너 뜁니다.
    ///
    ///
    /// 이 방법은 효율성을 위해 vector 를 복사하지 않도록주의합니다.
    ///
    /// `String` 대신 [`&str`] 가 필요한 경우 [`str::from_utf8`] 를 고려하십시오.
    ///
    /// 이 방법의 반대는 [`into_bytes`] 입니다.
    ///
    /// # Errors
    ///
    /// 슬라이스가 UTF-8 가 아닌 경우 제공된 바이트가 UTF-8 가 아닌 이유에 대한 설명과 함께 [`Err`] 를 반환합니다.이동 한 vector 도 포함됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // vector 의 일부 바이트
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // 이 바이트가 유효하다는 것을 알고 있으므로 `unwrap()` 를 사용합니다.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 잘못된 바이트 :
    ///
    /// ```
    /// // vector 의 일부 잘못된 바이트
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// 이 오류로 수행 할 수있는 작업에 대한 자세한 내용은 [`FromUtf8Error`] 문서를 참조하세요.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// 잘못된 문자를 포함하여 바이트 조각을 문자열로 변환합니다.
    ///
    /// 문자열은 ([`u8`]) 바이트로 구성되고 ([`&[u8]`][byteslice]) 바이트 조각은 바이트로 구성되므로이 함수는 둘 사이를 변환합니다.모든 바이트 조각이 유효한 문자열은 아니지만 문자열은 유효한 UTF-8 여야합니다.
    /// 이 변환 중에 `from_utf8_lossy()` 는 유효하지 않은 UTF-8 시퀀스를 다음과 같은 [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] 로 대체합니다.
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// 바이트 슬라이스가 유효한 UTF-8 임을 확신하고 변환 오버 헤드를 발생시키지 않으려면이 함수의 안전하지 않은 버전 인 [`from_utf8_unchecked`] 가 있습니다.이 함수는 동작이 동일하지만 검사를 건너 뜁니다.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// 이 함수는 [`Cow<'a, str>`] 를 반환합니다.바이트 조각이 유효하지 않은 UTF-8 이면 대체 문자를 삽입해야합니다. 그러면 문자열 크기가 변경되므로 `String` 가 필요합니다.
    /// 그러나 이미 유효한 UTF-8 이면 새 할당이 필요하지 않습니다.
    /// 이 반환 유형을 사용하면 두 경우를 모두 처리 할 수 있습니다.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // vector 의 일부 바이트
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 잘못된 바이트 :
    ///
    /// ```
    /// // 일부 잘못된 바이트
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16으로 인코딩 된 vector `v` 를 `String` 로 디코딩하여 `v` 에 잘못된 데이터가 포함 된 경우 [`Err`] 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // collect: : <Result<_, _>> ().
        // FIXME: #48994 가 닫히면 기능을 다시 단순화 할 수 있습니다.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// UTF-16으로 인코딩 된 슬라이스 `v` 를 `String` 로 디코딩하여 잘못된 데이터를 [the replacement character (`U+FFFD`)][U+FFFD] 로 바꿉니다.
    ///
    /// [`Cow<'a, str>`] 를 반환하는 [`from_utf8_lossy`] 와 달리 UTF-16 에서 UTF-8 로 변환하려면 메모리 할당이 필요하므로 `from_utf16_lossy` 는 `String` 를 반환합니다.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String` 를 원시 구성 요소로 분해합니다.
    ///
    /// 기본 데이터에 대한 원시 포인터, 문자열 길이 (바이트) 및 할당 된 데이터 용량 (바이트)을 반환합니다.
    /// 이들은 [`from_raw_parts`] 에 대한 인수와 동일한 순서로 동일한 인수입니다.
    ///
    /// 이 함수를 호출 한 후 호출자는 이전에 `String` 에서 관리 한 메모리를 담당합니다.
    /// 이를 수행하는 유일한 방법은 [`from_raw_parts`] 함수를 사용하여 원시 포인터, 길이 및 용량을 `String` 로 다시 변환하여 소멸자가 정리를 수행 할 수 있도록하는 것입니다.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// 길이, 용량 및 포인터에서 새 `String` 를 만듭니다.
    ///
    /// # Safety
    ///
    /// 확인되지 않은 불변의 수가 많기 때문에 매우 안전하지 않습니다.
    ///
    /// * `buf` 의 메모리는 표준 라이브러리에서 사용하는 동일한 할당 자에 의해 정확히 1의 필수 정렬로 이전에 할당되어야합니다.
    /// * `length` `capacity` 보다 작거나 같아야합니다.
    /// * `capacity` 올바른 값이어야합니다.
    /// * `buf` 의 첫 번째 `length` 바이트는 유효한 UTF-8 여야합니다.
    ///
    /// 이를 위반하면 할당 자의 내부 데이터 구조가 손상되는 것과 같은 문제가 발생할 수 있습니다.
    ///
    /// `buf` 의 소유권은 `String` 로 효과적으로 전송되어 포인터가 가리키는 메모리 내용을 마음대로 할당 해제, 재 할당 또는 변경할 수 있습니다.
    /// 이 함수를 호출 한 후에는 다른 어떤 것도 포인터를 사용하지 않도록하십시오.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts가 안정화되면 업데이트합니다.
    ///     // 문자열의 데이터 자동 삭제 방지
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// 문자열에 유효한 UTF-8 가 포함되어 있는지 확인하지 않고 vector 바이트를 `String` 로 변환합니다.
    ///
    /// 자세한 내용은 안전한 버전 [`from_utf8`] 를 참조하십시오.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// 이 함수는 전달 된 바이트가 유효한 UTF-8 인지 확인하지 않기 때문에 안전하지 않습니다.
    /// 이 제약 조건을 위반하면 나머지 표준 라이브러리가`String`이 유효한 UTF-8 라고 가정하므로 `String` 의 future 사용자에게 메모리 안전 문제가 발생할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // vector 의 일부 바이트
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` 를 바이트 vector 로 변환합니다.
    ///
    /// 이것은 `String` 를 소비하므로 내용을 복사 할 필요가 없습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// 전체 `String` 를 포함하는 문자열 조각을 추출합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` 를 가변 문자열 슬라이스로 변환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// 이 `String` 의 끝에 주어진 문자열 조각을 추가합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// 이`String`의 용량을 바이트 단위로 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// 이`String`의 용량이 길이보다 `additional` 바이트 이상 큰지 확인합니다.
    ///
    /// 빈번한 재 할당을 방지하기 위해 원하는 경우 용량을 `additional` 바이트 이상 늘릴 수 있습니다.
    ///
    ///
    /// 이 "at least" 동작을 원하지 않는 경우 [`reserve_exact`] 방법을 참조하십시오.
    ///
    /// # Panics
    ///
    /// Panics 새 용량이 [`usize`] 를 초과하는 경우.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// 이것은 실제로 용량을 증가시키지 않을 수 있습니다.
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s는 이제 길이가 2이고 용량이 10입니다.
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // 우리는 이미 8 개의 추가 용량을 가지고 있으므로 이것을 ...
    /// s.reserve(8);
    ///
    /// // ... 실제로 증가하지 않습니다.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// 이`String`의 용량이 길이보다 `additional` 바이트 더 큰지 확인합니다.
    ///
    /// 할당 자보다 더 잘 아는 경우가 아니면 [`reserve`] 방법 사용을 고려하십시오.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics 새 용량이 `usize` 를 초과하는 경우.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// 이것은 실제로 용량을 증가시키지 않을 수 있습니다.
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s는 이제 길이가 2이고 용량이 10입니다.
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // 우리는 이미 8 개의 추가 용량을 가지고 있으므로 이것을 ...
    /// s.reserve_exact(8);
    ///
    /// // ... 실제로 증가하지 않습니다.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// 주어진 `String` 에 삽입 할 최소 `additional` 이상의 요소에 대한 용량을 예약하려고합니다.
    /// 컬렉션은 빈번한 재 할당을 피하기 위해 더 많은 공간을 예약 할 수 있습니다.
    /// `reserve` 를 호출하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// # Errors
    ///
    /// 용량이 오버플로되거나 할당자가 오류를보고하면 오류가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // 메모리를 미리 예약하고, 할 수 없으면 종료합니다.
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 이제 우리는 복잡한 작업 중에 이것이 OOM이 불가능하다는 것을 알고 있습니다.
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// 주어진 `String` 에 정확히 `additional` 더 많은 요소가 삽입되도록 최소 용량을 예약하려고합니다.
    ///
    /// `reserve_exact` 를 호출하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// 할당자는 요청한 것보다 더 많은 공간을 컬렉션에 제공 할 수 있습니다.
    /// 따라서 용량을 정확하게 최소화 할 수 없습니다.
    /// future 삽입이 예상되는 경우 `reserve` 를 선호합니다.
    ///
    /// # Errors
    ///
    /// 용량이 오버플로되거나 할당자가 오류를보고하면 오류가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // 메모리를 미리 예약하고, 할 수 없으면 종료합니다.
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 이제 우리는 복잡한 작업 중에 이것이 OOM이 불가능하다는 것을 알고 있습니다.
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// 길이와 일치하도록이 `String` 의 용량을 줄입니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// 이 `String` 의 용량을 하한으로 축소합니다.
    ///
    /// 용량은 최소한 길이와 제공된 값만큼 크게 유지됩니다.
    ///
    ///
    /// 현재 용량이 하한보다 작 으면 작동하지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// 주어진 [`char`] 를이 `String` 의 끝에 추가합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// 이`String` 내용의 바이트 조각을 반환합니다.
    ///
    /// 이 방법의 반대는 [`from_utf8`] 입니다.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// 이 `String` 를 지정된 길이로 줄입니다.
    ///
    /// `new_len` 가 문자열의 현재 길이보다 크면 아무 효과가 없습니다.
    ///
    ///
    /// 이 방법은 문자열의 할당 된 용량에 영향을주지 않습니다.
    ///
    /// # Panics
    ///
    /// `new_len` 가 [`char`] 경계에 있지 않은 경우 Panics.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// 문자열 버퍼에서 마지막 문자를 제거하고 반환합니다.
    ///
    /// 이 `String` 가 비어 있으면 [`None`] 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// 이 `String` 의 바이트 위치에서 [`char`] 를 제거하고 반환합니다.
    ///
    /// 이것은 버퍼의 모든 요소를 복사해야하므로 *O*(*n*) 연산입니다.
    ///
    /// # Panics
    ///
    /// `idx` 가`String`의 길이보다 크거나 같거나 [`char`] 경계에 있지 않은 경우 Panics.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` 에서 `pat` 패턴의 모든 일치를 제거합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// 일치 항목은 반복적으로 감지 및 제거되므로 패턴이 겹치는 경우 첫 번째 패턴 만 제거됩니다.
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // 안전: 시작과 끝은 당 utf8 바이트 경계에 있습니다.
        // Searcher 문서
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// 술어로 지정된 문자 만 보유합니다.
    ///
    /// 즉, `f(c)` 가 `false` 를 반환하도록 모든 문자 `c` 를 제거합니다.
    /// 이 방법은 제자리에서 작동하여 각 문자를 원래 순서대로 정확히 한 번 방문하고 유지 된 문자의 순서를 유지합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// 정확한 순서는 인덱스와 같은 외부 상태를 추적하는 데 유용 할 수 있습니다.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // idx가 다음 문자를 가리 킵니다.
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// 이 `String` 의 바이트 위치에 문자를 삽입합니다.
    ///
    /// 버퍼의 모든 요소를 복사해야하므로 *O*(*n*) 작업입니다.
    ///
    /// # Panics
    ///
    /// `idx` 가`String`의 길이보다 크거나 [`char`] 경계에 있지 않은 경우 Panics.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// 바이트 위치에서이 `String` 에 문자열 슬라이스를 삽입합니다.
    ///
    /// 버퍼의 모든 요소를 복사해야하므로 *O*(*n*) 작업입니다.
    ///
    /// # Panics
    ///
    /// `idx` 가`String`의 길이보다 크거나 [`char`] 경계에 있지 않은 경우 Panics.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// 이 `String` 의 내용에 대한 변경 가능한 참조를 리턴합니다.
    ///
    /// # Safety
    ///
    /// 이 함수는 전달 된 바이트가 유효한 UTF-8 인지 확인하지 않기 때문에 안전하지 않습니다.
    /// 이 제약 조건을 위반하면 나머지 표준 라이브러리가`String`이 유효한 UTF-8 라고 가정하므로 `String` 의 future 사용자에게 메모리 안전 문제가 발생할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// 이 `String` 의 길이를 [`char`] 또는 자소가 아닌 바이트 단위로 반환합니다.
    /// 즉, 인간이 현의 길이를 고려하는 것과 다를 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// 이 `String` 의 길이가 0이면 `true` 를 반환하고 그렇지 않으면 `false` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 주어진 바이트 인덱스에서 문자열을 두 개로 분할합니다.
    ///
    /// 새로 할당 된 `String` 를 반환합니다.
    /// `self` `[0, at)` 바이트를 포함하고 반환 된 `String` 에는 `[at, len)` 바이트가 포함됩니다.
    /// `at` UTF-8 코드 포인트의 경계에 있어야합니다.
    ///
    /// `self` 의 용량은 변경되지 않습니다.
    ///
    /// # Panics
    ///
    /// `at` 가 `UTF-8` 코드 포인트 경계에 있지 않거나 문자열의 마지막 코드 포인트를 초과하는 경우 Panics 입니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// 이 `String` 를 잘라내어 모든 내용을 제거합니다.
    ///
    /// 이것은 `String` 의 길이가 0임을 의미하지만 용량에 영향을 미치지 않습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` 에서 지정된 범위를 제거하고 제거 된 `chars` 를 생성하는 드레 이닝 반복기를 만듭니다.
    ///
    ///
    /// Note: 반복자가 끝까지 사용되지 않더라도 요소 범위는 제거됩니다.
    ///
    /// # Panics
    ///
    /// Panics 시작점 또는 끝 점이 [`char`] 경계에 있지 않거나 경계를 벗어난 경우.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 문자열에서 β까지 범위를 제거합니다.
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // 전체 범위는 문자열을 지 웁니다.
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // 메모리 안전성
        //
        // Drain 의 문자열 버전에는 vector 버전의 메모리 안전 문제가 없습니다.
        // 데이터는 일반 바이트입니다.
        // 범위 제거는 Drop에서 발생하기 때문에 Drain 반복기가 누출되면 제거가 발생하지 않습니다.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // 두 개의 동시 대출을 꺼내십시오.
        // &mut String은 Drop에서 반복이 끝날 때까지 액세스 할 수 없습니다.
        let self_ptr = self as *mut _;
        // 안전: `slice::range` 및 `is_char_boundary` 는 적절한 경계 검사를 수행합니다.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// 문자열에서 지정된 범위를 제거하고 지정된 문자열로 바꿉니다.
    /// 주어진 문자열은 범위와 길이가 같을 필요가 없습니다.
    ///
    /// # Panics
    ///
    /// Panics 시작점 또는 끝 점이 [`char`] 경계에 있지 않거나 경계를 벗어난 경우.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 문자열에서 β까지 범위를 바꿉니다.
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // 메모리 안전성
        //
        // Replace_range에는 vector Splice의 메모리 안전 문제가 없습니다.
        // vector 버전의.데이터는 일반 바이트입니다.

        // 경고: 이 변수를 인라인하면 (#81138) 가 부적절합니다.
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // 경고: 이 변수를 인라인하면 (#81138) 가 부적절합니다.
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` 를 다시 사용하면 불건전합니다 (#81138) `range` 가보고 한 범위는 동일하게 유지되지만 적대적인 구현은 호출간에 변경 될 수 있습니다.
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// 이 `String` 를 [`Box`]`<`[`str`]`>`로 변환합니다.
    ///
    /// 이렇게하면 초과 용량이 감소합니다.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` 로 변환을 시도한 [`u8`] 바이트 조각을 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // vector 의 일부 잘못된 바이트
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` 로 변환하려고 시도한 바이트를 반환합니다.
    ///
    /// 이 방법은 할당을 피하기 위해 신중하게 구성됩니다.
    /// 오류를 소비하고 바이트를 이동하므로 바이트 사본을 만들 필요가 없습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // vector 의 일부 잘못된 바이트
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// 변환 실패에 대한 자세한 내용을 보려면 `Utf8Error` 를 가져옵니다.
    ///
    /// [`std::str`] 에서 제공하는 [`Utf8Error`] 유형은 [`u8`]의 슬라이스를 [`&str`] 로 변환 할 때 발생할 수있는 오류를 나타냅니다.
    /// 이런 의미에서 `FromUtf8Error` 와 유사합니다.
    /// 사용에 대한 자세한 내용은 설명서를 참조하십시오.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// // vector 의 일부 잘못된 바이트
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // 여기서 첫 번째 바이트는 유효하지 않습니다.
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // 우리는`String`에 대해 반복하고 있기 때문에 반복자에서 첫 번째 문자열을 가져 와서 모든 후속 문자열에 추가하여 적어도 하나의 할당을 피할 수 있습니다.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // CoW를 반복하기 때문에 (potentially) 는 첫 번째 항목을 가져 와서 모든 후속 항목에 추가하여 하나 이상의 할당을 피할 수 있습니다.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` 의 impl에 위임하는 편의 impl.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// 빈 `String` 를 만듭니다.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// 두 문자열을 연결하기위한 `+` 연산자를 구현합니다.
///
/// 이것은 왼쪽에서 `String` 를 소비하고 버퍼를 재사용합니다 (필요한 경우 증가).
/// 이는 새로운 `String` 를 할당하고 모든 작업에서 전체 내용을 복사하는 것을 방지하기 위해 수행되며, 반복 된 연결로 *n* 바이트 문자열을 빌드 할 때 *O*(*n*^ 2) 실행 시간으로 이어집니다.
///
///
/// 오른쪽의 문자열은 차용 된 것입니다.그 내용은 반환 된 `String` 에 복사됩니다.
///
/// # Examples
///
/// 두 개의`String`을 연결하면 첫 번째 값을 값으로 취하고 두 번째를 차용합니다.
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` 이동되어 더 이상 여기에서 사용할 수 없습니다.
/// ```
///
/// 첫 번째 `String` 를 계속 사용하려면 복제하고 대신 복제에 추가 할 수 있습니다.
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` 여기서는 여전히 유효합니다.
/// ```
///
/// `&str` 슬라이스 연결은 첫 번째 슬라이스를 `String` 로 변환하여 수행 할 수 있습니다.
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` 에 추가하기위한 `+=` 연산자를 구현합니다.
///
/// 이것은 [`push_str`][String::push_str] 방법과 동일한 동작을합니다.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] 의 유형 별명입니다.
///
/// 이 별칭은 이전 버전과의 호환성을 위해 존재하며 결국 더 이상 사용되지 않을 수 있습니다.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// 값을 `String` 로 변환하기위한 trait 입니다.
///
/// 이 trait 는 [`Display`] trait 를 구현하는 모든 유형에 대해 자동으로 구현됩니다.
/// 따라서 `ToString` 를 직접 구현해서는 안됩니다.
/// [`Display`] 대신 구현되어야하며 `ToString` 구현을 무료로받을 수 있습니다.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// 주어진 값을 `String` 로 변환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// 이 구현에서 `Display` 구현이 오류를 반환하는 경우 `to_string` 메서드 panics 입니다.
/// 이것은 `fmt::Write for String` 자체가 오류를 반환하지 않기 때문에 잘못된 `Display` 구현을 나타냅니다.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // 일반적인 지침은 일반 함수를 인라인하지 않는 것입니다.
    // 그러나이 방법에서 `#[inline]` 를 제거하면 무시할 수없는 회귀가 발생합니다.
    // 이를 제거하려는 마지막 시도 인 <https://github.com/rust-lang/rust/pull/74852> 를 참조하십시오.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` 를 `String` 로 변환합니다.
    ///
    /// 결과는 힙에 할당됩니다.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: 테스트는 libstd를 가져와 여기에 오류가 발생합니다.
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// 주어진 박스형 `str` 슬라이스를 `String` 로 변환합니다.
    /// `str` 슬라이스가 소유되어 있다는 점은 주목할 만합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// 지정된 `String` 를 소유 한 박스형 `str` 슬라이스로 변환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// 문자열 조각을 Borrowed 변형으로 변환합니다.
    /// 힙 할당이 수행되지 않고 문자열이 복사되지 않습니다.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// 문자열을 소유 변형으로 변환합니다.
    /// 힙 할당이 수행되지 않고 문자열이 복사되지 않습니다.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// String 참조를 Borrowed 변형으로 변환합니다.
    /// 힙 할당이 수행되지 않고 문자열이 복사되지 않습니다.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// 주어진 `String` 를 `u8` 유형의 값을 보유하는 vector `Vec` 로 변환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` 의 드레 이닝 반복기입니다.
///
/// 이 구조체는 [`String`] 에서 [`drain`] 메서드에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// 소멸자에서&'a mut String으로 사용됩니다.
    string: *mut String,
    /// 제거 할 부분의 시작
    start: usize,
    /// 제거 할 부품의 끝
    end: usize,
    /// 제거 할 현재 남은 범위
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain 를 사용하십시오.
            // "Reaffirm" 경계는 panic 코드가 다시 삽입되지 않도록 확인합니다.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// 이 반복기의 나머지 (하위) 문자열을 슬라이스로 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: 안정화 할 때 AsRef impls의 주석을 해제하십시오.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` 를 안정화 할 때 주석을 제거하십시오.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> for Drain <'a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}