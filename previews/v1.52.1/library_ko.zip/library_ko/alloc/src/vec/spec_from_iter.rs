use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter 에 사용되는 전문화 trait
///
/// ## 위임 그래프 :
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // 일반적인 경우는 vector 를 vector 에 즉시 다시 수집하는 함수에 전달하는 것입니다.
        // IntoIter가 전혀 발전되지 않은 경우이를 단락시킬 수 있습니다.
        // 그것이 발전되었을 때 우리는 또한 메모리를 재사용하고 데이터를 앞으로 옮길 수 있습니다.
        // 그러나 결과 Vec이 일반 FromIterator 구현을 통해 생성하는 것보다 사용되지 않은 용량이 많지 않을 때만 그렇게합니다.
        //
        // Vec의 할당 동작이 의도적으로 지정되지 않았기 때문에 이러한 제한은 반드시 필요한 것은 아닙니다.
        // 그러나 그것은 보수적 인 선택입니다.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() 자체가 빈 Vecs에 대해 spec_from에 위임하므로 spec_extend() 에 위임해야합니다.
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// 이것은 spec_extend가 최종 용량 + 길이를 추론하기 위해 더 많은 단계를 수행해야하기 때문에 `iterator.as_slice().to_vec()` 를 사용하므로 더 많은 작업을 수행합니다.
// `to_vec()` 정확한 금액을 직접 할당하고 정확하게 채 웁니다.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) 에서는이 방법 정의에 필요한 고유 `[T]::to_vec` 방법을 사용할 수 없습니다.
    // 대신 cfg(test) NB에서만 사용할 수있는 `slice::to_vec` 기능을 사용하십시오. 자세한 내용은 slice.rs 의 slice::hack 모듈을 참조하십시오.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}