use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// 요소를 제거해야하는지 결정하기 위해 클로저를 사용하는 반복기입니다.
///
/// 이 구조체는 [`Vec::drain_filter`] 에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next` 에 대한 다음 호출에서 검사 할 항목의 인덱스입니다.
    pub(super) idx: usize,
    /// 지금까지 (removed) 가 배수 된 항목 수입니다.
    pub(super) del: usize,
    /// 배수 전 `vec` 의 원래 길이.
    pub(super) old_len: usize,
    /// 필터 테스트 술어.
    pub(super) pred: F,
    /// 필터 테스트 조건 자에서 panic 가 발생했음을 나타내는 플래그입니다.
    /// 이것은 `DrainFilter` 의 나머지 소비를 방지하기 위해 드롭 구현에서 힌트로 사용됩니다.
    /// 처리되지 않은 항목은 `vec` 에서 백 시프트되지만 추가 항목은 필터 조건 자에 의해 삭제되거나 테스트되지 않습니다.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// 기본 할당 자에 대한 참조를 반환합니다.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // 술어가 호출 된 *후* 색인을 업데이트하십시오.
                // 인덱스가 이전에 업데이트되고 술어 panics 가 업데이트되면이 인덱스의 요소가 유출됩니다.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // 이것은 꽤 엉망인 상태이며, 분명히해야 할 일이 없습니다.
                        // 우리는 `pred` 를 계속 실행하고 싶지 않으므로 처리되지 않은 모든 요소를 백 시프트하고 vec에게 여전히 존재한다고 알려줍니다.
                        //
                        // 백 시프트는 술어의 panic 이전에 성공적으로 드레 이닝 된 마지막 항목의 이중 드롭을 방지하는 데 필요합니다.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // 필터 술어가 아직 패닉되지 않은 경우 나머지 요소를 사용하십시오.
        // 우리는 이미 당황했거나 여기 소비가 panics 인지 여부에 관계없이 나머지 요소를 뒤로 이동합니다.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}