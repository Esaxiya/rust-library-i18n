use core::ptr::{self};
use core::slice::{self};

// 반복 대상 슬라이스, 즉 헤드를 삭제하는 내부 반복을위한 도우미 구조체입니다.
// 소스 슬라이스 (꼬리)는 IntoIter에 의해 삭제됩니다.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}