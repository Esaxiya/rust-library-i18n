use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// 소스 할당을 재사용하면서 반복기 파이프 라인을 Vec에 수집하기위한 전문화 마커, 즉
/// 파이프 라인을 제자리에서 실행합니다.
///
/// SourceIter 상위 trait 는 재사용 할 할당에 액세스하기 위해 전문화 함수에 필요합니다.
/// 그러나 전문화가 유효하기에는 충분하지 않습니다.
/// impl에 대한 추가 경계를 참조하십시오.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-내부 SourceIter/InPlaceIterable traits 는 어댑터 체인으로 만 구현됩니다. <Adapter<Adapter<IntoIter>>> (모두 core/std 소유).
// 어댑터 구현 (`impl<I: Trait> Trait for Adapter<I>` 이상)에 대한 추가 경계는 이미 전문화 traits (Copy, TrustedRandomAccess, FusedIterator)로 표시된 다른 traits 에만 의존합니다.
//
// I.e. 마커는 사용자 제공 유형의 수명에 의존하지 않습니다.여러 다른 전문화가 이미 의존하고있는 Modulo the Copy 구멍.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds 를 통해 표현할 수없는 추가 요구 사항입니다.대신 const eval에 의존합니다.
        // a) 재사용 할 할당이 없기 때문에 ZST가없고 포인터 산술이 panic b) Alloc 계약에서 요구하는 크기 일치 c) Alloc 계약에서 요구하는대로 정렬 일치
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // 보다 일반적인 구현으로 대체
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // 이후 try-fold 사용
        // - 일부 반복기 어댑터에 대해 더 나은 벡터화
        // - 대부분의 내부 반복 방법과 달리 &mut 자체 만 필요합니다.
        // - 그것은 우리가 내부를 통해 쓰기 포인터를 스레딩하고 결국 다시 가져올 수있게합니다.
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // 반복이 성공했습니다. 머리를 떨어 뜨리지 마십시오.
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // SourceIter 계약이 유지되었는지 확인하십시오.주의 사항: 그렇지 않은 경우이 시점까지 도달하지 못할 수도 있습니다.
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable 계약을 확인하십시오.이터레이터가 소스 포인터를 전진 한 경우에만 가능합니다.
        // TrustedRandomAccess를 통해 확인되지 않은 액세스를 사용하는 경우 소스 포인터는 초기 위치에 유지되며 참조로 사용할 수 없습니다.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // 소스의 꼬리 부분에 남아있는 값을 모두 삭제하지만 panics 를 삭제하면 IntoIter가 범위를 벗어나면 할당 자체가 삭제되는 것을 방지하고 수집 된 모든 요소를 dst_buf로 유출합니다.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // try_fold가 소스 포인터에 대한 배타적 참조를 가지고 있기 때문에 InPlaceIterable 계약은 여기서 정확하게 확인할 수 없습니다. 우리가 할 수있는 것은 그것이 여전히 범위 내에 있는지 확인하는 것입니다.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}