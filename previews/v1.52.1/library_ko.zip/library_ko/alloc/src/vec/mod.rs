//! `Vec<T>` 로 작성된 힙 할당 컨텐츠가있는 연속 확장 가능한 배열 유형입니다.
//!
//! Vectors 에는 `O(1)` 인덱싱, 분할 된 `O(1)` 푸시 (끝까지) 및 `O(1)` 팝 (끝부터)이 있습니다.
//!
//!
//! Vectors 는 `isize::MAX` 바이트 이상을 할당하지 않도록합니다.
//!
//! # Examples
//!
//! [`Vec::new`] 를 사용하여 [`Vec`] 를 명시 적으로 만들 수 있습니다.
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... 또는 [`vec!`] 매크로를 사용하여 :
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // 10 개의 0
//! ```
//!
//! vector 의 끝에 값을 [`push`] 할 수 있습니다 (필요에 따라 vector 가 증가 함).
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! 값을 표시하는 방식은 거의 동일합니다.
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors 는 인덱싱도 지원합니다 ([`Index`] 및 [`IndexMut`] traits 를 통해) :
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// 연속 확장 가능한 배열 유형으로, `Vec<T>` 로 작성되고 'vector' 로 발음됩니다.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] 매크로는 초기화를보다 편리하게하기 위해 제공됩니다.
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// 또한 주어진 값으로 `Vec<T>` 의 각 요소를 초기화 할 수 있습니다.
/// 이것은 특히 0의 vector 를 초기화 할 때 별도의 단계에서 할당 및 초기화를 수행하는 것보다 더 효율적일 수 있습니다.
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // 다음은 동일하지만 잠재적으로 더 느립니다.
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// 자세한 내용은 [Capacity and Reallocation](#capacity-and-reallocation) 를 참조하십시오.
///
/// `Vec<T>` 를 효율적인 스택으로 사용 :
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // 3, 2, 1 인쇄
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` 유형은 [`Index`] trait 를 구현하므로 인덱스별로 값에 액세스 할 수 있습니다.예를 들면 다음과 같습니다.
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // '2' 가 표시됩니다.
/// ```
///
/// 그러나주의하십시오. `Vec` 에없는 인덱스에 액세스하려고하면 소프트웨어가 panic!너는 이것을 못해:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// 인덱스가 `Vec` 에 있는지 확인하려면 [`get`] 및 [`get_mut`] 를 사용하십시오.
///
/// # Slicing
///
/// `Vec` 는 변경 가능합니다.반면에 슬라이스는 읽기 전용 개체입니다.
/// [slice][prim@slice] 를 얻으려면 [`&`] 를 사용하십시오.예:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... 그리고 그게 전부입니다!
/// // 다음과 같이 할 수도 있습니다.
/// let u: &[usize] = &v;
/// // 또는 다음과 같이 :
/// let u: &[_] = &v;
/// ```
///
/// Rust 에서는 읽기 액세스를 제공하려는 경우 vectors 보다 슬라이스를 인수로 전달하는 것이 더 일반적입니다.[`String`] 와 [`&str`] 도 마찬가지입니다.
///
/// # 용량 및 재 할당
///
/// vector 의 용량은 vector 에 추가 될 future 요소에 할당 된 공간의 양입니다.이것은 vector 내의 실제 요소 수를 지정하는 vector 의 *length* 와 혼동하지 마십시오.
/// vector 의 길이가 용량을 초과하면 용량이 자동으로 증가하지만 요소를 재 할당해야합니다.
///
/// 예를 들어 용량이 10이고 길이가 0 인 vector 는 10 개의 추가 요소를위한 공간이있는 빈 vector 입니다.10 개 이하의 요소를 vector 에 푸시해도 용량이 변경되거나 재 할당이 발생하지 않습니다.
/// 그러나 vector 의 길이가 11로 증가하면 재 할당해야하므로 속도가 느려질 수 있습니다.이러한 이유로 vector 의 크기를 지정하기 위해 가능하면 [`Vec::with_capacity`] 를 사용하는 것이 좋습니다.
///
/// # Guarantees
///
/// 믿을 수 없을 정도로 근본적인 특성으로 인해 `Vec` 는 디자인에 대해 많은 보증을합니다.이것은 일반적인 경우에 가능한 한 낮은 오버 헤드를 보장하고 안전하지 않은 코드에 의해 원시적 인 방법으로 올바르게 조작 될 수 있습니다.이러한 보증은 규정되지 않은 `Vec<T>` 를 나타냅니다.
/// 추가 유형 매개 변수가 추가되면 (예: 사용자 지정 할당자를 지원하기 위해) 기본값을 재정의하면 동작이 변경 될 수 있습니다.
///
/// 가장 근본적으로 `Vec` 는 항상 (포인터, 용량, 길이) 3 중항이 될 것입니다.그 이상도 이하도 아닌.이러한 필드의 순서는 완전히 지정되지 않았으므로 적절한 방법을 사용하여 수정해야합니다.
/// 포인터는 null이 아니므로이 형식은 null 포인터에 최적화됩니다.
///
/// 그러나 포인터는 실제로 할당 된 메모리를 가리 키지 않을 수 있습니다.
/// 특히, [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] 를 통해 용량이 0 인 `Vec` 를 구성하거나 빈 Vec에서 [`shrink_to_fit`] 를 호출하면 메모리가 할당되지 않습니다.마찬가지로, 크기가 0 인 유형을 `Vec` 에 저장하면 해당 유형에 대한 공간이 할당되지 않습니다.
/// *이 경우 `Vec` 는 [`capacity`] 0* 을보고하지 않을 수 있습니다.
/// `Vec` 다음 경우에만 할당됩니다. [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// 일반적으로`Vec`의 할당 세부 사항은 매우 미묘합니다. `Vec` 를 사용하여 메모리를 할당하고 다른 용도로 사용하려는 경우 (안전하지 않은 코드로 전달하거나 자체 메모리 기반 컬렉션을 구축하려는 경우) 확인하십시오. `from_raw_parts` 를 사용하여 `Vec` 를 복구 한 다음 삭제하여이 메모리를 할당 해제합니다.
///
/// `Vec` 에 할당 된 메모리가 *있다* 면, 가리키는 메모리는 힙에 있고 (할당 자 Rust 에 의해 정의 된대로 기본적으로 사용하도록 구성됨) 포인터가 [`len`] 초기화 된 연속 요소를 순서대로 가리 킵니다 (원하는대로 슬라이스로 강제 변환했는지 확인) 뒤에 [`capacity`]`,`[`len`] 논리적으로 초기화되지 않은 연속 요소가 표시됩니다.
///
///
/// 용량이 4 인 요소 `'a'` 및 `'b'` 를 포함하는 vector 는 아래와 같이 시각화 할 수 있습니다.상단 부분은 `Vec` 구조체이며 힙, 길이 및 용량의 할당 헤드에 대한 포인터를 포함합니다.
/// 아래쪽 부분은 연속 메모리 블록 인 힙에 대한 할당입니다.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** 는 초기화되지 않은 메모리를 나타냅니다. [`MaybeUninit`] 를 참조하십시오.
/// - Note: ABI는 안정적이지 않으며 `Vec` 는 메모리 레이아웃 (필드 순서 포함)에 대해 보장하지 않습니다.
///
/// `Vec` 두 가지 이유로 요소가 실제로 스택에 저장되는 "small optimization" 를 수행하지 않습니다.
///
/// * 안전하지 않은 코드가 `Vec` 를 올바르게 조작하기가 더 어려워집니다.`Vec` 의 내용은 이동 만된다면 안정적인 주소를 가지지 못하며 `Vec` 가 실제로 메모리를 할당했는지 확인하기가 더 어려울 것입니다.
///
/// * 모든 액세스에 대해 추가 branch 가 발생하는 일반적인 경우에 불이익을줍니다.
///
/// `Vec` 완전히 비어 있어도 자동으로 축소되지 않습니다.이렇게하면 불필요한 할당이나 할당 해제가 발생하지 않습니다.`Vec` 를 비운 다음 동일한 [`len`] 로 다시 채우면 할당 자에 대한 호출이 발생하지 않습니다.사용하지 않는 메모리를 확보하려면 [`shrink_to_fit`] 또는 [`shrink_to`] 를 사용하십시오.
///
/// [`push`] [`insert`] 는보고 된 용량이 충분한 경우 절대 (재) 할당하지 않습니다.[`push`] 및 [`insert`] 는 [`len`]`==`[`capacity`] 인 경우 * (재) 할당합니다.즉,보고 된 용량이 완전히 정확하고 신뢰할 수 있습니다.원하는 경우 `Vec` 에 의해 할당 된 메모리를 수동으로 해제하는 데 사용할 수도 있습니다.
/// 대량 삽입 방법은 필요하지 않은 경우에도 재 할당 될 수 있습니다.
///
/// `Vec` 가득 차거나 [`reserve`] 가 호출 될 때 재 할당 할 때 특정 성장 전략을 보장하지 않습니다.현재 전략은 기본적이며 일정하지 않은 성장 인자를 사용하는 것이 바람직 할 수 있습니다.어떤 전략을 사용하든 물론 *O*(1) 상각 [`push`] 를 보장합니다.
///
/// `vec![x; n]`, `vec![a, b, c, d]` 및 [`Vec::with_capacity(n)`][`Vec::with_capacity`] 는 모두 정확히 요청 된 용량으로 `Vec` 를 생성합니다.
/// [`len`]`==`[`capacity`]([`vec!`] 매크로의 경우)이면 요소를 재 할당하거나 이동하지 않고도 `Vec<T>` 와 [`Box<[T]>`][owned slice] 간에 `Vec<T>` 를 변환 할 수 있습니다.
///
/// `Vec` 제거 된 데이터를 구체적으로 덮어 쓰지 않고 특별히 보존하지도 않습니다.초기화되지 않은 메모리는 원하는대로 사용할 수있는 스크래치 공간입니다.일반적으로 가장 효율적이거나 구현하기 쉬운 모든 작업을 수행합니다.보안을 위해 삭제 된 데이터에 의존하지 마십시오.
/// `Vec` 를 삭제하더라도 해당 버퍼는 다른 `Vec` 에서 단순히 재사용 될 수 있습니다.
/// 'Vec'의 메모리를 먼저 제로화하더라도 옵티마이 저가이를 보존해야하는 부작용으로 간주하지 않기 때문에 실제로 발생하지 않을 수 있습니다.
/// 그러나 우리가 깨지 않을 한 가지 경우가 있습니다. `unsafe` 코드를 사용하여 초과 용량에 쓴 다음 일치하도록 길이를 늘리는 것은 항상 유효합니다.
///
/// 현재 `Vec` 는 요소가 삭제되는 순서를 보장하지 않습니다.
/// 주문이 과거에 변경되었으며 다시 변경 될 수 있습니다.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// 고유 한 방법
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// 비어있는 새로운 `Vec<T>` 를 생성합니다.
    ///
    /// vector 는 요소가 푸시 될 때까지 할당되지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// 지정된 용량으로 비어있는 새 `Vec<T>` 를 구성합니다.
    ///
    /// vector 는 재 할당없이 정확히 `capacity` 요소를 보유 할 수 있습니다.
    /// `capacity` 가 0이면 vector 는 할당되지 않습니다.
    ///
    /// 반환 된 vector 에는 *capacity* 가 지정되어 있지만 vector 의 *length* 는 0이됩니다.
    ///
    /// 길이와 용량의 차이에 대한 설명은 *[용량 및 재 할당]* 을 참조하십시오.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector 에는 더 많은 용량이 있어도 항목이 없습니다.
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // 이 모든 작업은 재 할당없이 수행됩니다.
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ...하지만 이것은 vector 를 재 할당하게 만들 수 있습니다.
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// 다른 vector 의 원시 구성 요소에서 직접 `Vec<T>` 를 만듭니다.
    ///
    /// # Safety
    ///
    /// 확인되지 않은 불변의 수가 많기 때문에 매우 안전하지 않습니다.
    ///
    /// * `ptr` [`String`]/`Vec을 통해 이전에 할당되어야합니다.<T>`(적어도 그렇지 않다면 부정확 할 가능성이 높습니다).
    /// * `T` `ptr` 가 할당 된 것과 동일한 크기와 정렬을 가져야합니다.
    ///   (덜 엄격한 정렬을 갖는 `T` 로는 충분하지 않습니다. 정렬은 동일한 레이아웃으로 메모리를 할당하고 할당 해제해야한다는 [`dealloc`] 요구 사항을 충족하기 위해 실제로 동일해야합니다.)
    ///
    /// * `length` `capacity` 보다 작거나 같아야합니다.
    /// * `capacity` 포인터가 할당 된 용량이어야합니다.
    ///
    /// 이를 위반하면 할당 자의 내부 데이터 구조가 손상되는 것과 같은 문제가 발생할 수 있습니다.예를 들어 `size_t` 길이의 C `char` 배열에 대한 포인터에서 `Vec<u8>` 를 빌드하는 것은 안전하지 **않습니다**.
    /// 할당자가 정렬에 관심이 있고이 두 유형이 서로 다른 정렬을 갖기 때문에 `Vec<u16>` 및 해당 길이에서 하나를 빌드하는 것도 안전하지 않습니다.
    /// 버퍼는 정렬 2 (`u16` 의 경우)로 할당되었지만 `Vec<u8>` 로 전환 한 후에는 정렬 1로 할당 해제됩니다.
    ///
    /// `ptr` 의 소유권은 `Vec<T>` 로 효과적으로 전송되어 포인터가 가리키는 메모리 내용을 마음대로 할당 해제, 재 할당 또는 변경할 수 있습니다.
    /// 이 함수를 호출 한 후에는 다른 어떤 것도 포인터를 사용하지 않도록하십시오.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME vec_into_raw_parts가 안정화되면 업데이트합니다.
    ///     // `v`의 소멸자를 실행하지 않도록하여 할당을 완전히 제어합니다.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` 에 대한 다양한 중요한 정보를 꺼내십시오.
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4, 5, 6으로 메모리 덮어 쓰기
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // 모든 것을 다시 Vec에 통합
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// 비어있는 새로운 `Vec<T, A>` 를 생성합니다.
    ///
    /// vector 는 요소가 푸시 될 때까지 할당되지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// 제공된 할당 자로 지정된 용량으로 비어있는 새 `Vec<T, A>` 를 구성합니다.
    ///
    /// vector 는 재 할당없이 정확히 `capacity` 요소를 보유 할 수 있습니다.
    /// `capacity` 가 0이면 vector 는 할당되지 않습니다.
    ///
    /// 반환 된 vector 에는 *capacity* 가 지정되어 있지만 vector 의 *length* 는 0이됩니다.
    ///
    /// 길이와 용량의 차이에 대한 설명은 *[용량 및 재 할당]* 을 참조하십시오.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector 에는 더 많은 용량이 있어도 항목이 없습니다.
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // 이 모든 작업은 재 할당없이 수행됩니다.
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ...하지만 이것은 vector 를 재 할당하게 만들 수 있습니다.
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// 다른 vector 의 원시 구성 요소에서 직접 `Vec<T, A>` 를 만듭니다.
    ///
    /// # Safety
    ///
    /// 확인되지 않은 불변의 수가 많기 때문에 매우 안전하지 않습니다.
    ///
    /// * `ptr` [`String`]/`Vec을 통해 이전에 할당되어야합니다.<T>`(적어도 그렇지 않다면 부정확 할 가능성이 높습니다).
    /// * `T` `ptr` 가 할당 된 것과 동일한 크기와 정렬을 가져야합니다.
    ///   (덜 엄격한 정렬을 갖는 `T` 로는 충분하지 않습니다. 정렬은 동일한 레이아웃으로 메모리를 할당하고 할당 해제해야한다는 [`dealloc`] 요구 사항을 충족하기 위해 실제로 동일해야합니다.)
    ///
    /// * `length` `capacity` 보다 작거나 같아야합니다.
    /// * `capacity` 포인터가 할당 된 용량이어야합니다.
    ///
    /// 이를 위반하면 할당 자의 내부 데이터 구조가 손상되는 것과 같은 문제가 발생할 수 있습니다.예를 들어 `size_t` 길이의 C `char` 배열에 대한 포인터에서 `Vec<u8>` 를 빌드하는 것은 안전하지 **않습니다**.
    /// 할당자가 정렬에 관심이 있고이 두 유형이 서로 다른 정렬을 갖기 때문에 `Vec<u16>` 및 해당 길이에서 하나를 빌드하는 것도 안전하지 않습니다.
    /// 버퍼는 정렬 2 (`u16` 의 경우)로 할당되었지만 `Vec<u8>` 로 전환 한 후에는 정렬 1로 할당 해제됩니다.
    ///
    /// `ptr` 의 소유권은 `Vec<T>` 로 효과적으로 전송되어 포인터가 가리키는 메모리 내용을 마음대로 할당 해제, 재 할당 또는 변경할 수 있습니다.
    /// 이 함수를 호출 한 후에는 다른 어떤 것도 포인터를 사용하지 않도록하십시오.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME vec_into_raw_parts가 안정화되면 업데이트합니다.
    ///     // `v`의 소멸자를 실행하지 않도록하여 할당을 완전히 제어합니다.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` 에 대한 다양한 중요한 정보를 꺼내십시오.
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4, 5, 6으로 메모리 덮어 쓰기
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // 모든 것을 다시 Vec에 통합
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>` 를 원시 구성 요소로 분해합니다.
    ///
    /// 기본 데이터에 대한 원시 포인터, vector 의 길이 (요소) 및 데이터의 할당 된 용량 (요소)을 반환합니다.
    /// 이들은 [`from_raw_parts`] 에 대한 인수와 동일한 순서로 동일한 인수입니다.
    ///
    /// 이 함수를 호출 한 후 호출자는 이전에 `Vec` 에서 관리 한 메모리를 담당합니다.
    /// 이를 수행하는 유일한 방법은 [`from_raw_parts`] 함수를 사용하여 원시 포인터, 길이 및 용량을 `Vec` 로 다시 변환하여 소멸자가 정리를 수행 할 수 있도록하는 것입니다.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // 이제 원시 포인터를 호환 가능한 유형으로 변환하는 것과 같이 구성 요소를 변경할 수 있습니다.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>` 를 원시 구성 요소로 분해합니다.
    ///
    /// 기본 데이터에 대한 원시 포인터, vector 의 길이 (요소), 데이터의 할당 된 용량 (요소) 및 할당자를 반환합니다.
    /// 이들은 [`from_raw_parts_in`] 에 대한 인수와 동일한 순서로 동일한 인수입니다.
    ///
    /// 이 함수를 호출 한 후 호출자는 이전에 `Vec` 에서 관리 한 메모리를 담당합니다.
    /// 이를 수행하는 유일한 방법은 [`from_raw_parts_in`] 함수를 사용하여 원시 포인터, 길이 및 용량을 `Vec` 로 다시 변환하여 소멸자가 정리를 수행 할 수 있도록하는 것입니다.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // 이제 원시 포인터를 호환 가능한 유형으로 변환하는 것과 같이 구성 요소를 변경할 수 있습니다.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector 가 재할 당하지 않고 보유 할 수있는 요소의 수를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// 주어진 `Vec<T>` 에 삽입 할 최소 `additional` 이상의 요소에 대한 용량을 예약합니다.
    /// 컬렉션은 빈번한 재 할당을 피하기 위해 더 많은 공간을 예약 할 수 있습니다.
    /// `reserve` 를 호출하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// # Panics
    ///
    /// 새 용량이 `isize::MAX` 바이트를 초과하는 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// 지정된 `Vec<T>` 에 삽입 할 요소를 정확히 `additional` 개 이상에 대한 최소 용량을 예약합니다.
    ///
    /// `reserve_exact` 를 호출하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// 할당자는 요청한 것보다 더 많은 공간을 컬렉션에 제공 할 수 있습니다.
    /// 따라서 용량을 정확하게 최소화 할 수 없습니다.
    /// future 삽입이 예상되는 경우 `reserve` 를 선호합니다.
    ///
    /// # Panics
    ///
    /// Panics 새 용량이 `usize` 를 초과하는 경우.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// 주어진 `Vec<T>` 에 삽입 할 최소 `additional` 이상의 요소에 대한 용량을 예약하려고합니다.
    /// 컬렉션은 빈번한 재 할당을 피하기 위해 더 많은 공간을 예약 할 수 있습니다.
    /// `try_reserve` 를 호출하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// # Errors
    ///
    /// 용량이 오버플로되거나 할당자가 오류를보고하면 오류가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // 메모리를 미리 예약하고, 할 수 없으면 종료합니다.
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 이제 우리는 복잡한 작업 중에 이것이 OOM이 불가능하다는 것을 알고 있습니다.
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // 매우 복잡한
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// 주어진 `Vec<T>` 에 정확히 `additional` 요소가 삽입되도록 최소 용량을 예약하려고합니다.
    /// `try_reserve_exact` 를 호출 한 후 `Ok(())` 를 반환하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    ///
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// 할당자는 요청한 것보다 더 많은 공간을 컬렉션에 제공 할 수 있습니다.
    /// 따라서 용량을 정확하게 최소화 할 수 없습니다.
    /// future 삽입이 예상되는 경우 `reserve` 를 선호합니다.
    ///
    /// # Errors
    ///
    /// 용량이 오버플로되거나 할당자가 오류를보고하면 오류가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // 메모리를 미리 예약하고, 할 수 없으면 종료합니다.
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // 이제 우리는 복잡한 작업 중에 이것이 OOM이 불가능하다는 것을 알고 있습니다.
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // 매우 복잡한
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// 가능한 한 vector 의 용량을 줄입니다.
    ///
    /// 가능한 한 길이에 가깝게 드롭되지만 할당자는 여전히 vector 에 몇 가지 요소를위한 공간이 있음을 알릴 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // 용량은 길이보다 적지 않으며 동일하면 할 일이 없으므로 `RawVec::shrink_to_fit` 에서 더 큰 용량으로 만 호출하여 panic 케이스를 피할 수 있습니다.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// 하한으로 vector 의 용량을 축소합니다.
    ///
    /// 용량은 최소한 길이와 제공된 값만큼 크게 유지됩니다.
    ///
    ///
    /// 현재 용량이 하한보다 작 으면 작동하지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector 를 [`Box<[T]>`][owned slice] 로 변환합니다.
    ///
    /// 이렇게하면 초과 용량이 감소합니다.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// 초과 용량이 제거됩니다.
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector 를 줄여 첫 번째 `len` 요소를 유지하고 나머지는 삭제합니다.
    ///
    /// `len` 가 vector 의 현재 길이보다 크면 효과가 없습니다.
    ///
    /// [`drain`] 메서드는 `truncate` 를 에뮬레이트 할 수 있지만 초과 요소가 삭제되지 않고 반환되도록합니다.
    ///
    ///
    /// 이 방법은 vector 의 할당 된 용량에 영향을 미치지 않습니다.
    ///
    /// # Examples
    ///
    /// 다섯 요소 vector 를 두 요소로 자릅니다.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len` 가 vector 의 현재 길이보다 크면 잘림이 발생하지 않습니다.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` 가 [`clear`] 메서드를 호출하는 것과 같을 때 자르기.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // 다음과 같은 이유로 안전합니다.
        //
        // * `drop_in_place` 에 전달 된 슬라이스가 유효합니다.`len > self.len` 케이스는 잘못된 슬라이스 생성을 방지하며
        // * vector 의 `len` 는 `drop_in_place` 를 호출하기 전에 축소되어 `drop_in_place` 가 panic 에 한 번 있으면 값이 두 번 삭제되지 않습니다 (panics 가 두 번이면 프로그램이 중단됨).
        //
        //
        //
        unsafe {
            // Note: 이것은 `>=` 가 아니라 `>` 라는 의도입니다.
            //       `>=` 로 변경하면 경우에 따라 성능에 부정적인 영향을 미칩니다.
            //       자세한 내용은 #78884 를 참조하십시오.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// 전체 vector 를 포함하는 슬라이스를 추출합니다.
    ///
    /// `&s[..]` 와 동일합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// 전체 vector 의 가변 슬라이스를 추출합니다.
    ///
    /// `&mut s[..]` 와 동일합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector 의 버퍼에 대한 원시 포인터를 반환합니다.
    ///
    /// 호출자는 vector 가이 함수가 반환하는 포인터보다 오래 지속되는지 확인해야합니다. 그렇지 않으면 가비지를 가리키게됩니다.
    /// vector 를 수정하면 해당 버퍼가 재 할당 될 수 있으며, 이로 인해 포인터도 유효하지 않게됩니다.
    ///
    /// 호출자는 또한 포인터 (non-transitively) 가 가리키는 메모리가이 포인터 또는 포인터에서 파생 된 포인터를 사용하여 기록되지 않도록해야합니다 (`UnsafeCell` 내부 제외).
    /// 슬라이스의 내용을 변경해야하는 경우 [`as_mut_ptr`] 를 사용하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // 중간 참조를 만드는 `deref` 를 통과하지 않도록 같은 이름의 슬라이스 메서드를 섀도 잉합니다.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector 의 버퍼에 대한 안전하지 않은 가변 포인터를 반환합니다.
    ///
    /// 호출자는 vector 가이 함수가 반환하는 포인터보다 오래 지속되는지 확인해야합니다. 그렇지 않으면 가비지를 가리키게됩니다.
    ///
    /// vector 를 수정하면 해당 버퍼가 재 할당 될 수 있으며, 이로 인해 포인터도 유효하지 않게됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 개 요소에 대해 충분히 큰 vector 를 할당합니다.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // 원시 포인터 쓰기를 통해 요소를 초기화 한 다음 길이를 설정합니다.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // 중간 참조를 만드는 `deref_mut` 를 통과하지 않도록 같은 이름의 슬라이스 메서드를 섀도 잉합니다.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// 기본 할당 자에 대한 참조를 반환합니다.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector 의 길이를 `new_len` 로 강제 설정합니다.
    ///
    /// 이것은 유형의 정상 불변을 유지하지 않는 저수준 작업입니다.
    /// 일반적으로 vector 의 길이 변경은 [`truncate`], [`resize`], [`extend`] 또는 [`clear`] 와 같은 안전한 작업 중 하나를 사용하여 수행됩니다.
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] 보다 작거나 같아야합니다.
    /// - `old_len..new_len` 의 요소는 초기화되어야합니다.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// 이 방법은 vector 가 특히 FFI를 통해 다른 코드에 대한 버퍼 역할을하는 상황에 유용 할 수 있습니다.
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // 이것은 문서 예제를위한 최소한의 골격 일뿐입니다.
    /// # // 이것을 실제 라이브러리의 시작점으로 사용하지 마십시오.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI 방법의 문서에 따라 "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // 안전: `deflateGetDictionary` 가 `Z_OK` 를 반환하면 다음을 유지합니다.
    ///     // 1. `dict_length` 요소가 초기화되었습니다.
    ///     // 2.
    ///     // `dict_length` <= `set_len` 를 안전하게 호출 할 수있는 용량 (32_768).
    ///     unsafe {
    ///         // FFI 전화 걸기 ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... 초기화 된 길이로 업데이트합니다.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// 다음 예제는 소리가 나지만 내부 vectors 가 `set_len` 호출 전에 해제되지 않았기 때문에 메모리 누수가 있습니다.
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` 비어 있으므로 요소를 초기화 할 필요가 없습니다.
    /// // 2. `0 <= capacity` 항상 `capacity` 가 무엇이든 보유합니다.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// 일반적으로 여기에서는 [`clear`] 를 사용하여 내용을 올바르게 삭제하여 메모리 누수를 방지합니다.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector 에서 요소를 제거하고 반환합니다.
    ///
    /// 제거 된 요소는 vector 의 마지막 요소로 대체됩니다.
    ///
    /// 이것은 순서를 유지하지 않지만 O(1) 입니다.
    ///
    /// # Panics
    ///
    /// `index` 가 범위를 벗어난 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // self [index]를 마지막 요소로 대체합니다.
            // 위의 경계 검사가 성공하면 마지막 요소가 있어야합니다 (self [index] 자체 일 수 있음).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector 내의 위치 `index` 에 요소를 삽입하고 그 뒤의 모든 요소를 오른쪽으로 이동합니다.
    ///
    ///
    /// # Panics
    ///
    /// `index > len` 인 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // 새 요소를위한 공간
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // 새로운 가치를 담을 자리
            //
            {
                let p = self.as_mut_ptr().add(index);
                // 공간을 만들기 위해 모든 것을 이동하십시오.
                // (`index` 번째 요소를 두 개의 연속 된 위치로 복제합니다.)
                ptr::copy(p, p.offset(1), len - index);
                // 'index'번째 요소의 첫 번째 사본을 덮어 쓰면서 작성합니다.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector 내의 `index` 위치에있는 요소를 제거하고 반환하여 그 뒤의 모든 요소를 왼쪽으로 이동합니다.
    ///
    ///
    /// # Panics
    ///
    /// `index` 가 범위를 벗어난 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // 우리가 취하고있는 곳.
                let ptr = self.as_mut_ptr().add(index);
                // 스택과 vector 에 동시에 값의 복사본을 안전하지 않게 복사하여 복사하십시오.
                //
                ret = ptr::read(ptr);

                // 그 자리를 채우기 위해 모든 것을 아래로 이동하십시오.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// 술어로 지정된 요소 만 보유합니다.
    ///
    /// 즉, `f(&e)` 가 `false` 를 반환하도록 모든 요소 `e` 를 제거합니다.
    /// 이 메서드는 제자리에서 작동하여 각 요소를 원래 순서대로 정확히 한 번 방문하고 유지 된 요소의 순서를 유지합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// 요소는 원래 순서대로 정확히 한 번 방문하기 때문에 외부 상태를 사용하여 유지할 요소를 결정할 수 있습니다.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // 드롭 가드가 실행되지 않으면 프로세스 중에 약간의 구멍이 생길 수 있으므로 이중 낙하를 피하십시오.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-처리 된 len-> |^-다음 확인
        //                  | <-cnt 삭제-> |
        //      | <-원본 _ 렌즈-> |Kept: 술어가 true를 리턴하는 요소.
        //
        // 구멍: 이동 또는 드롭 된 요소 슬롯.
        // 선택 취소: 선택 취소 된 유효한 요소입니다.
        //
        // 이 드롭 가드는 조건 자 또는 요소의 `drop` 가 패닉되었을 때 호출됩니다.
        // 검사되지 않은 요소를 구멍을 덮고 `set_len` 를 올바른 길이로 이동합니다.
        // 술어와 `drop` 가 패닉을 일으키지 않는 경우 최적화됩니다.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // 안전: 체크되지 않은 후행 항목은 절대 만지지 않기 때문에 유효해야합니다.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // 안전: 구멍을 채운 후 모든 항목이 연속 메모리에 있습니다.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // 안전: 선택되지 않은 요소는 유효해야합니다.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` 가 당황한 경우 이중 드롭을 피하기 위해 일찍 진행하십시오.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // 안전: 떨어 뜨린 후에는이 요소를 다시는 만지지 않습니다.
                unsafe { ptr::drop_in_place(cur) };
                // 우리는 이미 카운터를 진행했습니다.
                continue;
            }
            if g.deleted_cnt > 0 {
                // 안전: `deleted_cnt`> 0이므로 구멍 슬롯이 현재 요소와 겹치지 않아야합니다.
                // 이동을 위해 복사를 사용하고이 요소를 다시는 만지지 않습니다.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // 모든 항목이 처리됩니다.이것은 LLVM에 의해 `set_len` 에 최적화 될 수 있습니다.
        drop(g);
    }

    /// vector 에서 동일한 키로 확인되는 첫 번째 연속 요소를 제외한 모든 요소를 제거합니다.
    ///
    ///
    /// vector 가 정렬되면 모든 중복 항목이 제거됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// vector 에서 주어진 등식 관계를 만족하는 연속 요소 중 첫 번째 요소를 제외하고 모두 제거합니다.
    ///
    /// `same_bucket` 함수는 vector 의 두 요소에 대한 참조를 전달하며 요소가 동일한 지 확인해야합니다.
    /// 요소는 슬라이스의 순서와 반대 순서로 전달되므로 `same_bucket(a, b)` 가 `true` 를 반환하면 `a` 가 제거됩니다.
    ///
    ///
    /// vector 가 정렬되면 모든 중복 항목이 제거됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// 컬렉션 뒤에 요소를 추가합니다.
    ///
    /// # Panics
    ///
    /// 새 용량이 `isize::MAX` 바이트를 초과하는 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // 이것은 우리가> isize::MAX 바이트를 할당하거나 0 크기 유형에 대해 길이 증가가 오버플로되는 경우 panic 또는 중단됩니다.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector 에서 마지막 요소를 제거하고 반환하거나 비어있는 경우 [`None`] 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` 의 모든 요소를 `Self` 로 이동하고 `other` 는 비워 둡니다.
    ///
    /// # Panics
    ///
    /// vector 의 요소 수가 `usize` 를 오버플로하는 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// 다른 버퍼에서 `Self` 에 요소를 추가합니다.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// vector 에서 지정된 범위를 제거하고 제거 된 항목을 생성하는 드레 이닝 반복기를 만듭니다.
    ///
    /// 반복기가 삭제되면 ** 반복자가 완전히 사용되지 않았더라도 범위의 모든 요소가 vector 에서 제거됩니다.
    /// 반복기가 삭제되지 **않으면**(예: [`mem::forget`] 사용), 제거되는 요소의 수는 지정되지 않습니다.
    ///
    /// # Panics
    ///
    /// 시작점이 끝점보다 크거나 끝 점이 vector 의 길이보다 큰 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // 전체 범위는 vector 를 지 웁니다.
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // 메모리 안전성
        //
        // Drain 가 처음 생성 될 때 Drain 의 소멸자가 실행되지 않는 경우 초기화되지 않거나 이동 된 요소에 액세스 할 수 없도록 소스 vector 의 길이를 줄입니다.
        //
        //
        // Drain 는 제거 할 값을 ptr::read 합니다.
        // 완료되면 vec의 나머지 꼬리가 다시 복사되어 구멍을 덮고 vector 길이가 새 길이로 복원됩니다.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain 가 누출 될 경우 안전하도록 self.vec 길이를 시작하도록 설정
            self.set_len(start);
            // IterMut에서 차용을 사용하여 전체 Drain 반복기 (예: &mut T)의 차용 동작을 나타냅니다.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector 를 지우고 모든 값을 제거합니다.
    ///
    /// 이 방법은 vector 의 할당 된 용량에 영향을 미치지 않습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// 'length' 라고도하는 vector 의 요소 수를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector 에 요소가 없으면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 지정된 인덱스에서 컬렉션을 두 개로 분할합니다.
    ///
    /// `[at, len)` 범위의 요소를 포함하는 새로 할당 된 vector 를 반환합니다.
    /// 호출 후 원래 vector 에는 이전 용량이 변경되지 않은 `[0, at)` 요소가 포함되어 있습니다.
    ///
    ///
    /// # Panics
    ///
    /// `at > len` 인 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // 새로운 vector 는 원래 버퍼를 차지하고 복사를 피할 수 있습니다.
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // 안전하지 않게 `set_len` 하고 항목을 `other` 로 복사합니다.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `len` 가 `new_len` 와 같도록 `Vec` 내부 크기를 조정합니다.
    ///
    /// `new_len` 가 `len` 보다 크면 `Vec` 는 `f` 클로저를 호출 한 결과로 채워진 각 추가 슬롯과 함께 차이만큼 확장됩니다.
    ///
    /// `f` 의 반환 값은 생성 된 순서대로 `Vec` 에서 끝납니다.
    ///
    /// `new_len` 가 `len` 보다 작 으면 `Vec` 는 단순히 잘립니다.
    ///
    /// 이 방법은 클로저를 사용하여 푸시 할 때마다 새로운 값을 생성합니다.주어진 값을 [`Clone`] 로 지정하려면 [`Vec::resize`] 를 사용하십시오.
    /// [`Default`] trait 를 사용하여 값을 생성하려는 경우 [`Default::default`] 를 두 번째 인수로 전달할 수 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` 를 소비하고 누출하여 내용에 대한 가변 참조를 반환합니다. `&'a mut [T]`.
    /// 유형 `T` 는 선택한 수명 `'a` 보다 오래 지속되어야합니다.
    /// 유형에 정적 참조 만 있거나 전혀없는 경우 `'static` 로 선택할 수 있습니다.
    ///
    /// 이 기능은 누수 된 메모리를 복구 할 방법이 없다는 점을 제외하면 [`Box`] 의 [`leak`][Box::leak] 기능과 유사합니다.
    ///
    ///
    /// 이 기능은 프로그램의 남은 수명 동안 유지되는 데이터에 주로 유용합니다.
    /// 반환 된 참조를 삭제하면 메모리 누수가 발생합니다.
    ///
    /// # Examples
    ///
    /// 간단한 사용법 :
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector 의 남은 여유 용량을 `MaybeUninit<T>` 의 슬라이스로 반환합니다.
    ///
    /// 반환 된 슬라이스를 사용하여 vector 를 데이터로 채울 수 있습니다 (예 :
    /// [`set_len`] 메서드를 사용하여 데이터를 초기화 된 것으로 표시하기 전에 파일에서 읽음).
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 개의 요소에 대해 충분히 큰 vector 를 할당합니다.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // 처음 3 개 요소를 채우십시오.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector 의 처음 3 개 요소를 초기화 된 것으로 표시합니다.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // 이 메서드는 버퍼에 대한 포인터의 무효화를 방지하기 위해 `split_at_spare_mut` 측면에서 구현되지 않습니다.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector 콘텐츠를 `T` 의 슬라이스로 반환하고 vector 의 남은 여유 용량을 `MaybeUninit<T>` 의 슬라이스로 반환합니다.
    ///
    /// 반환 된 예비 용량 슬라이스는 데이터를 [`set_len`] 방법을 사용하여 초기화 된 것으로 표시하기 전에 데이터로 vector 를 채우는 데 사용할 수 있습니다 (예: 파일에서 읽기).
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// 이 API는 최적화 목적으로주의해서 사용해야하는 저수준 API입니다.
    /// `Vec` 에 데이터를 추가해야하는 경우 정확한 요구 사항에 따라 [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] 또는 [`resize_with`] 를 사용할 수 있습니다.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 개 요소를위한 충분한 추가 공간을 예약하십시오.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // 다음 4 개 요소를 채우십시오.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector 의 4 개 요소를 초기화 된 것으로 표시합니다.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len은 무시되므로 변경되지 않습니다.
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// 안전성: 반환 된 .2 (&mut 사용)를 변경하는 것은 `.set_len(_)` 를 호출하는 것과 동일한 것으로 간주됩니다.
    ///
    /// 이 방법은 `extend_from_within` 에서 한 번에 모든 vec 부품에 고유 한 액세스 권한을 갖는 데 사용됩니다.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` 요소에 대해 유효 함이 보장됩니다.
        // - `spare_ptr` 버퍼를 지나는 한 요소를 가리 키므로 `initialized` 와 겹치지 않습니다.
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `len` 가 `new_len` 와 같도록 `Vec` 내부 크기를 조정합니다.
    ///
    /// `new_len` 가 `len` 보다 크면 `Vec` 는 `value` 로 채워진 각 추가 슬롯과 함께 차이만큼 확장됩니다.
    ///
    /// `new_len` 가 `len` 보다 작 으면 `Vec` 는 단순히 잘립니다.
    ///
    /// 이 메서드는 전달 된 값을 복제 할 수 있도록 `T` 에서 [`Clone`] 를 구현해야합니다.
    /// 더 많은 유연성이 필요하거나 [`Clone`] 대신 [`Default`] 에 의존하려는 경우 [`Vec::resize_with`] 를 사용하십시오.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// 슬라이스의 모든 요소를 복제하고 `Vec` 에 추가합니다.
    ///
    /// 슬라이스 `other` 를 반복하고 각 요소를 복제 한 다음이 `Vec` 에 추가합니다.
    /// `other` vector 는 순서대로 순회됩니다.
    ///
    /// 이 기능은 슬라이스로 작업하도록 특화되어 있다는 점을 제외하면 [`extend`] 와 동일합니다.
    ///
    /// Rust 가 전문화되면이 함수는 더 이상 사용되지 않을 가능성이 높습니다 (그러나 여전히 사용 가능).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` 범위에서 vector 의 끝까지 요소를 복사합니다.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` 주어진 범위가 자기 인덱싱에 유효 함을 보장합니다.
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// 이 코드는 `extend_with_{element,default}` 를 일반화합니다.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// 주어진 생성기를 사용하여 vector 를 `n` 값으로 확장합니다.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // SetLenOnDrop을 사용하여 컴파일러가 `ptr` 에서 self.set_len() 까지의 별칭이 아닌 저장소를 인식하지 못할 수있는 버그를 해결합니다.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // 마지막 요소를 제외한 모든 요소 작성
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics 의 경우 모든 단계에서 길이를 늘립니다.
                local_len.increment_len(1);
            }

            if n > 0 {
                // 불필요하게 복제하지 않고 마지막 요소를 직접 작성할 수 있습니다.
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // 스코프 가드에 의해 설정된 len
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait 구현에 따라 vector 에서 연속적으로 반복되는 요소를 제거합니다.
    ///
    ///
    /// vector 가 정렬되면 모든 중복 항목이 제거됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// 내부 방법 및 기능
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` 유효한 색인이어야합니다
    /// - `self.capacity() - self.len()` `>= src.len()` 여야합니다.
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len은 요소를 초기화 한 후에 만 증가합니다.
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - 발신자는 src 가 유효한 색인임을 보증합니다.
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - 요소가 `MaybeUninit::write` 로 초기화되었으므로 len을 늘려도됩니다.
            // - len은 누출을 방지하기 위해 각 요소 다음에 증가합니다 (문제 #82533 참조).
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - 호출자는 `src` 가 유효한 색인임을 보증합니다.
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - 두 포인터 모두 고유 한 슬라이스 참조 (`&mut [_]`)에서 생성되므로 유효하고 겹치지 않습니다.
            //
            // - 요소는: Copy이므로 원래 값으로 아무것도 수행하지 않고 복사해도됩니다.
            // - `count` `source` 의 len과 같으므로 소스는 `count` 읽기에 유효합니다.
            // - `.reserve(count)` `spare.len() >= count` 를 보장하므로 예비가 `count` 쓰기에 유효합니다.
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - 요소는 `copy_nonoverlapping` 에 의해 방금 초기화되었습니다.
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec에 대한 일반적인 trait 구현
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) 에서는이 방법 정의에 필요한 고유 `[T]::to_vec` 방법을 사용할 수 없습니다.
    // 대신 cfg(test) NB에서만 사용할 수있는 `slice::to_vec` 기능을 사용하십시오. 자세한 내용은 slice.rs 의 slice::hack 모듈을 참조하십시오.
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // 덮어 쓰지 않을 모든 것을 삭제
        self.truncate(other.len());

        // self.len 위의 잘림으로 인해 <= other.len 이므로 여기의 슬라이스는 항상 인바운드입니다.
        //
        let (init, tail) = other.split_at(self.len());

        // 포함 된 값의 allocations/resources 를 재사용합니다.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// 소비 반복자, 즉 vector 에서 각 값을 (시작에서 끝으로) 이동하는 반복기를 만듭니다.
    /// 이것을 호출 한 후에는 vector 를 사용할 수 없습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s는 &String 가 아닌 문자열 유형을가집니다.
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // 적용 할 추가 최적화가 없을 때 다양한 SpecFrom/SpecExtend 구현이 위임하는 리프 메서드
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // 이것은 일반 반복자의 경우입니다.
        //
        // 이 기능은 다음과 같은 도덕적이어야합니다.
        //
        //      for item in iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB는 주소 공간을 할당해야했기 때문에 오버플로 할 수 없습니다.
                self.set_len(len + 1);
            }
        }
    }

    /// vector 의 지정된 범위를 지정된 `replace_with` 반복기로 바꾸고 제거 된 항목을 생성하는 스 플라이 싱 반복기를 만듭니다.
    ///
    /// `replace_with` `range` 와 길이가 같을 필요는 없습니다.
    ///
    /// `range` 이터레이터가 끝까지 소비되지 않더라도 제거됩니다.
    ///
    /// `Splice` 값이 누출되면 vector 에서 제거되는 요소의 수는 지정되지 않습니다.
    ///
    /// 입력 반복기 `replace_with` 는 `Splice` 값이 삭제 될 때만 사용됩니다.
    ///
    /// 다음과 같은 경우에 최적입니다.
    ///
    /// * 꼬리 (`range` 이후 vector 의 요소)는 비어 있습니다.
    /// * 또는 `replace_with` 는`range`의 길이보다 적거나 같은 요소를 생성합니다.
    /// * 또는 `size_hint()` 의 하한이 정확합니다.
    ///
    /// 그렇지 않으면 임시 vector 가 할당되고 꼬리가 두 번 이동합니다.
    ///
    /// # Panics
    ///
    /// 시작점이 끝점보다 크거나 끝 점이 vector 의 길이보다 큰 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// 요소를 제거해야하는지 결정하기 위해 클로저를 사용하는 반복자를 만듭니다.
    ///
    /// 클로저가 true를 반환하면 요소가 제거되고 양보됩니다.
    /// 클로저가 false를 반환하면 요소는 vector 에 남아 있고 반복기에 의해 생성되지 않습니다.
    ///
    /// 이 메서드를 사용하는 것은 다음 코드와 동일합니다.
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // 여기에 귀하의 코드
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// 그러나 `drain_filter` 는 사용하기가 더 쉽습니다.
    /// `drain_filter` 또한 배열의 요소를 대량으로 백 시프트 할 수 있기 때문에 더 효율적입니다.
    ///
    /// `drain_filter` 를 사용하면 유지 또는 제거 여부에 관계없이 필터 클로저의 모든 요소를 변경할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// 배열을 짝수와 확률로 분할하여 원래 할당을 재사용합니다.
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // 우리가 새는 것을 막아라 (누수 증폭)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Vec으로 푸시하기 전에 참조에서 요소를 복사하는 구현을 확장하십시오.
///
/// 이 구현은 [`copy_from_slice`] 를 사용하여 전체 슬라이스를 한 번에 추가하는 슬라이스 반복기에 특화되어 있습니다.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors 의 비교를 구현합니다. [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors 의 순서를 구현합니다. [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] 에 드롭을 사용하십시오. 원시 슬라이스를 사용하여 vector 의 요소를 가장 약한 필수 유형으로 참조하십시오.
            //
            // 특정 경우에 유효성에 대한 질문을 피할 수 있습니다.
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec은 할당 해제를 처리합니다.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// 빈 `Vec<T>` 를 만듭니다.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: 테스트는 libstd를 가져와 여기에 오류가 발생합니다.
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: 테스트는 libstd를 가져와 여기에 오류가 발생합니다.
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// 크기가 요청 된 배열의 크기와 정확히 일치하는 경우 `Vec<T>` 의 전체 내용을 배열로 가져옵니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// 길이가 일치하지 않으면 입력이 `Err` 로 돌아옵니다.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// `Vec<T>` 의 접두사 만 받아도 괜찮다면 먼저 [`.truncate(N)`](Vec::truncate) 를 호출 할 수 있습니다.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // 안전: `.set_len(0)` 는 항상 소리가납니다.
        unsafe { vec.set_len(0) };

        // 안전: `Vec`의 포인터는 항상 올바르게 정렬됩니다.
        // 배열에 필요한 정렬은 항목과 동일합니다.
        // 이전에 충분한 항목이 있는지 확인했습니다.
        // `set_len` 가 `Vec` 에 항목을 드롭하지 않도록 지시하므로 항목은 이중 드롭되지 않습니다.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}