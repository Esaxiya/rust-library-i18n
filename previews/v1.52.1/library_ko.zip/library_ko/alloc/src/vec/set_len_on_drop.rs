// `SetLenOnDrop` 값이 범위를 벗어날 때 vec의 길이를 설정합니다.
//
// 아이디어는 다음과 같습니다. SetLenOnDrop의 길이 필드는 옵티마이 저가 Vec의 데이터 포인터를 통해 어떤 저장소와도 별칭을 사용하지 않는 것을 보게 될 지역 변수입니다.
// 이것은 별칭 분석 문제 #32155 에 대한 해결 방법입니다.
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}