use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// 중복되는 전문화의 우선 순위를 수동으로 지정하는 데 필요한 Vec::from_iter 용 또 다른 전문화 trait 자세한 내용은 [`SpecFromIter`](super::SpecFromIter) 를 참조하십시오.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // 이터 러블이 비어 있지 않은 경우 모든 경우에 vector 가이 반복에서 확장되지만 extend_desugared() 의 루프는 몇 번의 후속 루프 반복에서 vector 가 가득 찬 것을 보지 않을 것이므로 첫 번째 반복을 펼치십시오.
        //
        // 그래서 우리는 더 나은 branch 예측을 얻습니다.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // extend() 자체가 빈 Vecs에 대해 spec_from에 위임하므로 spec_extend() 에 위임해야합니다.
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // extend() 자체가 빈 Vecs에 대해 spec_from에 위임하므로 spec_extend() 에 위임해야합니다.
        //
        vector.spec_extend(iterator);
        vector
    }
}