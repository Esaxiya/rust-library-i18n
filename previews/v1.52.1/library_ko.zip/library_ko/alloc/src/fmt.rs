//! '문자열'형식화 및 인쇄를위한 유틸리티입니다.
//!
//! 이 모듈에는 [`format!`] 구문 확장에 대한 런타임 지원이 포함되어 있습니다.
//! 이 매크로는 런타임에 인수를 문자열로 형식화하기 위해이 모듈에 대한 호출을 내보내도록 컴파일러에서 구현됩니다.
//!
//! # Usage
//!
//! [`format!`] 매크로는 C의 `printf`/`fprintf` 함수 또는 Python 의 `str.format` 함수에서 오는 매크로에 익숙합니다.
//!
//! [`format!`] 확장의 몇 가지 예는 다음과 같습니다.
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" 앞에 0이있는
//! ```
//!
//! 이로부터 첫 번째 인수가 형식 문자열임을 알 수 있습니다.컴파일러는 이것이 문자열 리터럴이어야합니다.(유효성 검사를 수행하기 위해) 전달 된 변수 일 수 없습니다.
//! 그런 다음 컴파일러는 형식 문자열을 구문 분석하고 제공된 인수 목록이이 형식 문자열에 전달하기에 적합한 지 결정합니다.
//!
//! 단일 값을 문자열로 변환하려면 [`to_string`] 메서드를 사용합니다.[`Display`] 형식 trait 를 사용합니다.
//!
//! ## 위치 매개 변수
//!
//! 각 형식화 인수는 참조하는 값 인수를 지정할 수 있으며 생략하면 "the next argument" 로 간주됩니다.
//! 예를 들어, 형식 문자열 `{} {} {}` 는 세 개의 매개 변수를 취하며 주어진 순서와 동일한 순서로 형식화됩니다.
//! 그러나 형식 문자열 `{2} {1} {0}` 는 인수를 역순으로 형식화합니다.
//!
//! 두 가지 유형의 위치 지정자를 혼합하기 시작하면 상황이 약간 까다로울 수 있습니다."next argument" 지정자는 인수에 대한 반복자로 생각할 수 있습니다.
//! "next argument" 지정자를 볼 때마다 반복기가 진행됩니다.이로 인해 다음과 같은 동작이 발생합니다.
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! 인수에 대한 내부 반복기는 첫 번째 `{}` 가 표시 될 때까지 진행되지 않았으므로 첫 번째 인수를 인쇄합니다.그런 다음 두 번째 `{}` 에 도달하면 반복기가 두 번째 인수로 진행됩니다.
//! 본질적으로 인수 이름을 명시 적으로 지정하는 매개 변수는 위치 지정자 측면에서 인수 이름을 지정하지 않는 매개 변수에 영향을주지 않습니다.
//!
//! 모든 인수를 사용하려면 형식 문자열이 필요합니다. 그렇지 않으면 컴파일 시간 오류입니다.형식 문자열에서 동일한 인수를 두 번 이상 참조 할 수 있습니다.
//!
//! ## 명명 된 매개 변수
//!
//! Rust 자체에는 함수에 대한 명명 된 매개 변수에 해당하는 Python 와 유사한 기능이 없지만 [`format!`] 매크로는 명명 된 매개 변수를 활용할 수있는 구문 확장입니다.
//! 명명 된 매개 변수는 인수 목록 끝에 나열되며 구문은 다음과 같습니다.
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! 예를 들어 다음 [`format!`] 표현식은 모두 명명 된 인수를 사용합니다.
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! 이름이있는 인수 뒤에 위치 매개 변수 (이름이없는 매개 변수)를 넣는 것은 유효하지 않습니다.위치 매개 변수와 마찬가지로 형식 문자열에서 사용하지 않는 명명 된 매개 변수를 제공하는 것은 유효하지 않습니다.
//!
//! # 매개 변수 형식 지정
//!
//! 형식화되는 각 인수는 여러 형식화 매개 변수 ([the syntax](#syntax)) 의 `format_spec` 에 해당)로 변환 될 수 있습니다. 이러한 매개 변수는 형식화되는 문자열 표현에 영향을줍니다.
//!
//! ## Width
//!
//! ```
//! // 이 모든 인쇄 "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! 형식이 차지해야하는 "minimum width" 의 매개 변수입니다.
//! 값의 문자열이 이만큼 많은 문자를 채우지 않으면 fill/alignment 에 지정된 패딩이 필요한 공간을 차지하는 데 사용됩니다 (아래 참조).
//!
//! 너비 값은 두 번째 인수가 너비를 지정하는 [`usize`] 임을 나타내는 접미사 `$` 를 추가하여 매개 변수 목록에서 [`usize`] 로 제공 할 수도 있습니다.
//!
//! 달러 구문으로 인수를 참조하는 것은 "next argument" 카운터에 영향을주지 않으므로 일반적으로 위치별로 인수를 참조하거나 명명 된 인수를 사용하는 것이 좋습니다.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! 선택적 채우기 문자 및 정렬은 일반적으로 [`width`](#width) 매개 변수와 함께 제공됩니다.`width` 이전, `:` 바로 뒤에 정의되어야합니다.
//! 이는 형식화되는 값이 `width` 보다 작은 경우 일부 추가 문자가 그 주위에 인쇄됨을 나타냅니다.
//! 채우기는 다양한 정렬에 대해 다음과 같은 변형으로 제공됩니다.
//!
//! * `[fill]<` - 인수는 `width` 열에서 왼쪽 정렬됩니다.
//! * `[fill]^` - 인수는 `width` 열에서 가운데 정렬됩니다.
//! * `[fill]>` - 인수는 `width` 열에서 오른쪽 정렬됩니다.
//!
//! 비 숫자에 대한 기본 [fill/alignment](#fillalignment) 는 공백이며 왼쪽 정렬입니다.숫자 포맷터의 기본값은 공백 문자이지만 오른쪽 정렬입니다.
//! `0` 플래그 (아래 참조)가 숫자에 대해 지정되면 암시 적 채우기 문자는 `0` 입니다.
//!
//! 일부 유형에서는 정렬이 구현되지 않을 수 있습니다.특히 `Debug` trait 에서는 일반적으로 구현되지 않습니다.
//! 패딩이 적용되는지 확인하는 좋은 방법은 입력 형식을 지정한 다음 결과 문자열을 패딩하여 출력을 얻는 것입니다.
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "안녕하세요 Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! 이들은 모두 포맷터의 동작을 변경하는 플래그입니다.
//!
//! * `+` - 이것은 숫자 유형을위한 것이며 기호가 항상 인쇄되어야 함을 나타냅니다.양수 기호는 기본적으로 인쇄되지 않으며 음수 기호는 기본적으로 `Signed` trait 에 대해서만 인쇄됩니다.
//! 이 플래그는 올바른 기호 (`+` 또는 `-`)가 항상 인쇄되어야 함을 나타냅니다.
//! * `-` - 현재 사용되지 않음
//! * `#` - 이 플래그는 "alternate" 형식의 인쇄를 사용해야 함을 나타냅니다.대체 형식은 다음과 같습니다.
//!     * `#?` - [`Debug`] 형식을 예쁘게 인쇄하십시오.
//!     * `#x` - 인수 앞에 `0x` 가 붙습니다.
//!     * `#X` - 인수 앞에 `0x` 가 붙습니다.
//!     * `#b` - 인수 앞에 `0b` 가 붙습니다.
//!     * `#o` - 인수 앞에 `0o` 가 붙습니다.
//! * `0` - 이것은 `width` 에 대한 패딩이 `0` 문자로 수행되고 서명을 인식해야 함을 정수 형식에 표시하는 데 사용됩니다.
//! `{:08}` 와 같은 형식은 정수 `1` 에 대해 `00000001` 를 생성하는 반면 동일한 형식은 정수 `-1` 에 대해 `-0000001` 를 생성합니다.
//! 음수 버전은 양수 버전보다 0이 하나 적습니다.
//!         패딩 0은 항상 부호 (있는 경우)와 숫자 앞에 배치됩니다.`#` 플래그와 함께 사용하면 유사한 규칙이 적용됩니다. 패딩 0은 접두사 뒤, 숫자 앞에 삽입됩니다.
//!         접두사는 총 너비에 포함됩니다.
//!
//! ## Precision
//!
//! 숫자가 아닌 유형의 경우 "maximum width" 로 간주 될 수 있습니다.
//! 결과 문자열이이 너비보다 길면이 문자 수까지 잘리고 해당 매개 변수가 설정된 경우 잘린 값은 적절한 `fill`, `alignment` 및 `width` 와 함께 방출됩니다.
//!
//! 정수 유형의 경우 무시됩니다.
//!
//! 부동 소수점 유형의 경우 소수점 뒤에 인쇄해야하는 자릿수를 나타냅니다.
//!
//! 원하는 `precision` 를 지정하는 세 가지 방법이 있습니다.
//!
//! 1. 정수 `.N` :
//!
//!    정수 `N` 자체가 정밀도입니다.
//!
//! 2. 달러 기호 `.N$` 가 뒤에 오는 정수 또는 이름 :
//!
//!    정밀도로 *argument*`N` (`usize` 여야 함) 형식을 사용하십시오.
//!
//! 3. 별표 `.*` :
//!
//!    `.*` 이 `{...}` 는 하나가 아닌 *두* 형식 입력과 연관되어 있음을 의미합니다. 첫 번째 입력은 `usize` 정밀도를 보유하고 두 번째 입력은 인쇄 할 값을 보유합니다.
//!    이 경우 형식 문자열 `{<arg>:<spec>.*}` 를 사용하는 경우 `<arg>` 부분은 인쇄 할* 값 *을 참조하고 `precision` 는 `<arg>` 앞의 입력에 있어야합니다.
//!
//! 예를 들어, 다음 호출은 모두 동일한 `Hello x is 0.01000` 를 인쇄합니다.
//!
//! ```
//! // 안녕하세요 {arg 0 ("x")} 는 {arg 1 (0.01) with precision specified inline (5)} 입니다.
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // 안녕하세요 {arg 1 ("x")} 는 {arg 2 (0.01) with precision specified in arg 0 (5)} 입니다.
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // 안녕하세요 {arg 0 ("x")} 는 {arg 2 (0.01) with precision specified in arg 1 (5)} 입니다.
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // 안녕하세요 {next arg ("x")} 는 {second of next two args (0.01) with precision specified in first of next two args (5)} 입니다.
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // 안녕하세요 {next arg ("x")} 는 {arg 2 (0.01) with precision specified in its predecessor (5)} 입니다.
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // 안녕하세요 {next arg ("x")} 는 {arg "number" (0.01) with precision specified in arg "prec" (5)} 입니다.
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! 이 동안 :
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! 크게 다른 세 가지를 인쇄하십시오.
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! 일부 프로그래밍 언어에서 문자열 형식화 함수의 동작은 운영 체제의 로케일 설정에 따라 다릅니다.
//! Rust 의 표준 라이브러리에서 제공하는 형식 함수는 로케일 개념이 없으며 사용자 구성에 관계없이 모든 시스템에서 동일한 결과를 생성합니다.
//!
//! 예를 들어, 다음 코드는 시스템 로케일이 점이 아닌 소수 구분 기호를 사용하더라도 항상 `1.5` 를 인쇄합니다.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! 리터럴 문자 `{` 및 `}` 는 동일한 문자를 앞에 두어 문자열에 포함될 수 있습니다.예를 들어 `{` 문자는 `{{` 로 이스케이프되고 `}` 문자는 `}}` 로 이스케이프됩니다.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! 요약하면 여기에서 형식 문자열의 전체 문법을 찾을 수 있습니다.
//! 사용 된 서식 지정 언어의 구문은 다른 언어에서 가져온 것이므로 너무 이질적이어서는 안됩니다.인수는 Python 와 유사한 구문으로 형식이 지정됩니다. 즉, 인수는 C와 같은 `%` 대신 `{}` 로 둘러싸여 있습니다.
//! 형식화 구문의 실제 문법은 다음과 같습니다.
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! 위의 문법에서 `text` 는 `'{'` 또는 `'}'` 문자를 포함 할 수 없습니다.
//!
//! # traits 서식 지정
//!
//! 인수가 특정 유형으로 형식화되도록 요청할 때 실제로 인수가 특정 trait 에 속하도록 요청하는 것입니다.
//! 이를 통해 `{:x}` 를 통해 여러 실제 유형을 형식화 할 수 있습니다 (예: [`i8`] 및 [`isize`]).traits 에 대한 유형의 현재 매핑은 다음과 같습니다.
//!
//! * *1 개* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ 소문자 16 진수 정수가있는 [`Debug`]
//! * `X?` ⇒ 대문자 16 진수 정수가있는 [`Debug`]
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! 이것이 의미하는 바는 [`fmt::Binary`][`Binary`] trait 를 구현하는 모든 유형의 인수가 `{:b}` 로 형식화 될 수 있다는 것입니다.표준 라이브러리에 의해 여러 기본 유형에 대한 이러한 traits 에 대한 구현도 제공됩니다.
//!
//! 형식이 지정되지 않은 경우 (`{}` 또는 `{:6}` 에서와 같이) 사용되는 형식 trait 는 [`Display`] trait 입니다.
//!
//! 자신의 유형에 대해 trait 형식을 구현할 때 서명 메서드를 구현해야합니다.
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // 우리의 맞춤 유형
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! 형식은 참조에 의해 `self` 로 전달되고 함수는 `f.buf` 스트림으로 출력을 내 보냅니다.요청 된 형식 매개 변수를 올바르게 준수하는 것은 각 형식 trait 구현에 달려 있습니다.
//! 이러한 매개 변수의 값은 [`Formatter`] 구조체의 필드에 나열됩니다.이를 돕기 위해 [`Formatter`] 구조체는 몇 가지 도우미 메서드도 제공합니다.
//!
//! 또한이 함수의 반환 값은 [`Result`]`<(),`[`std: : fmt::Error`]`>`의 유형 별칭 인 [`fmt::Result`] 입니다.
//! 형식화 구현은 [`Formatter`] 에서 오류를 전파해야합니다 (예: [`write!`] 호출시).
//! 그러나 오류를 허위로 반환해서는 안됩니다.
//! 즉, 형식화 구현은 전달 된 [`Formatter`] 가 오류를 반환하는 경우에만 오류를 반환해야하며 반환 할 수도 있습니다.
//! 이는 함수 시그니처가 제안하는 것과는 달리 문자열 형식화는 오류가없는 작업이기 때문입니다.
//! 이 함수는 기본 스트림에 대한 쓰기가 실패 할 수 있기 때문에 결과 만 반환하고 오류가 발생했다는 사실을 스택에 전파하는 방법을 제공해야합니다.
//!
//! traits 형식을 구현하는 예는 다음과 같습니다.
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` 값은 `Write` trait 를 구현합니다. 이것이 바로 쓰기입니다!매크로가 필요합니다.
//!         // 이 형식화는 문자열 형식화에 제공된 다양한 플래그를 무시합니다.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // 다른 traits 는 유형의 다른 형태의 출력을 허용합니다.
//! // 이 형식의 의미는 vector 의 크기를 인쇄하는 것입니다.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Formatter 개체에서 도우미 메서드 `pad_integral` 를 사용하여 형식 지정 플래그를 준수합니다.
//!         // 자세한 내용은 메서드 설명서를 참조하십시오. `pad` 함수를 사용하여 문자열을 채울 수 있습니다.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` 대 `fmt::Debug`
//!
//! 이 두 가지 형식 traits 는 서로 다른 목적을 가지고 있습니다.
//!
//! - [`fmt::Display`][`Display`] 구현은 유형이 항상 UTF-8 문자열로 충실하게 표현 될 수 있다고 주장합니다.모든 유형이 [`Display`] trait 를 구현할 것으로 예상되지 **않습니다**.
//! - [`fmt::Debug`][`Debug`] **모든** 공개 유형에 대해 구현을 구현해야합니다.
//!   출력은 일반적으로 가능한 한 충실하게 내부 상태를 나타냅니다.
//!   [`Debug`] trait 의 목적은 Rust 코드 디버깅을 용이하게하는 것입니다.대부분의 경우 `#[derive(Debug)]` 를 사용하는 것으로 충분하며 권장됩니다.
//!
//! 두 traits 의 출력에 대한 몇 가지 예 :
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # 관련 매크로
//!
//! [`format!`] 제품군에는 관련 매크로가 많이 있습니다.현재 구현 된 항목은 다음과 같습니다.
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! 이것과 [`writeln!`] 는 지정된 스트림에 형식 문자열을 내보내는 데 사용되는 두 개의 매크로입니다.이는 형식 문자열의 중간 할당을 방지하고 대신 출력을 직접 작성하는 데 사용됩니다.
//! 내부적으로이 함수는 실제로 [`std::io::Write`] trait 에 정의 된 [`write_fmt`] 함수를 호출합니다.
//! 사용 예는 다음과 같습니다.
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! 이것과 [`println!`] 는 stdout 로 출력을 내 보냅니다.[`write!`] 매크로와 마찬가지로 이러한 매크로의 목표는 출력을 인쇄 할 때 중간 할당을 피하는 것입니다.사용 예는 다음과 같습니다.
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] 및 [`eprintln!`] 매크로는 stderr 로 출력을 내보내는 것을 제외하고는 각각 [`print!`] 및 [`println!`] 와 동일합니다.
//!
//! ### `format_args!`
//!
//! 이것은 형식 문자열을 설명하는 불투명 한 개체를 안전하게 전달하는 데 사용되는 흥미로운 매크로입니다.이 개체는 생성하는 데 힙 할당이 필요하지 않으며 스택의 정보 만 참조합니다.
//! 내부적으로 모든 관련 매크로가 이와 관련하여 구현됩니다.
//! 먼저 몇 가지 사용 예는 다음과 같습니다.
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] 매크로의 결과는 [`fmt::Arguments`] 유형의 값입니다.
//! 이 구조는 형식 문자열을 처리하기 위해이 모듈 내부의 [`write`] 및 [`format`] 함수에 전달 될 수 있습니다.
//! 이 매크로의 목표는 형식화 문자열을 처리 할 때 중간 할당을 더욱 방지하는 것입니다.
//!
//! 예를 들어 로깅 라이브러리는 표준 형식화 구문을 사용할 수 있지만 출력이 어디로 가야할지 결정될 때까지이 구조를 내부적으로 전달합니다.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format` 함수는 [`Arguments`] 구조체를 사용하여 형식화 된 결과 문자열을 반환합니다.
///
///
/// [`Arguments`] 인스턴스는 [`format_args!`] 매크로를 사용하여 만들 수 있습니다.
///
/// # Examples
///
/// 기본 사용법 :
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format!`] 를 사용하는 것이 바람직 할 수 있습니다.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}