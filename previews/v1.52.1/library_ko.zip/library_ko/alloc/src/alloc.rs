//! 메모리 할당 API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // 글로벌 할당자를 호출하는 마법의 상징입니다.rustc 는 `__rg_alloc` 등을 호출하도록 생성합니다.
    // `#[global_allocator]` 속성 (속성 매크로를 확장하는 코드가 해당 함수를 생성 함)이 있거나 libstd (`__rdl_alloc` 등)에서 기본 구현을 호출하는 경우
    //
    // `library/std/src/alloc.rs` 에서) 그렇지 않으면.
    // LLVM의 rustc fork 는 또한 이러한 함수 이름을 각각 `malloc`, `realloc` 및 `free` 와 같이 최적화 할 수 있도록 특수한 경우입니다.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// 전역 메모리 할당 자입니다.
///
/// 이 유형은 `#[global_allocator]` 속성에 등록 된 할당 자 (있을 경우) 또는 `std` crate 의 기본값으로 호출을 전달하여 [`Allocator`] trait 를 구현합니다.
///
///
/// Note: 이 유형은 불안정하지만 제공하는 기능은 [free functions in `alloc`](self#functions) 를 통해 액세스 할 수 있습니다.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// 전역 할당 자로 메모리를 할당합니다.
///
/// 이 함수는 `#[global_allocator]` 속성이있는 경우 등록 된 할당 자의 [`GlobalAlloc::alloc`] 메서드 또는 `std` crate 의 기본값으로 호출을 전달합니다.
///
///
/// 이 기능은 [`Global`] 유형의 `alloc` 방법과 [`Allocator`] trait 가 안정되면 더 이상 사용되지 않을 것으로 예상됩니다.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] 를 참조하십시오.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// 전역 할당 자로 메모리를 할당 해제합니다.
///
/// 이 함수는 `#[global_allocator]` 속성이있는 경우 등록 된 할당 자의 [`GlobalAlloc::dealloc`] 메서드 또는 `std` crate 의 기본값으로 호출을 전달합니다.
///
///
/// 이 기능은 [`Global`] 유형의 `dealloc` 방법과 [`Allocator`] trait 가 안정되면 더 이상 사용되지 않을 것으로 예상됩니다.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] 를 참조하십시오.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// 전역 할당 자로 메모리를 재 할당합니다.
///
/// 이 함수는 `#[global_allocator]` 속성이있는 경우 등록 된 할당 자의 [`GlobalAlloc::realloc`] 메서드 또는 `std` crate 의 기본값으로 호출을 전달합니다.
///
///
/// 이 기능은 [`Global`] 유형의 `realloc` 방법과 [`Allocator`] trait 가 안정되면 더 이상 사용되지 않을 것으로 예상됩니다.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] 를 참조하십시오.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// 전역 할당자를 사용하여 0으로 초기화 된 메모리를 할당합니다.
///
/// 이 함수는 `#[global_allocator]` 속성이있는 경우 등록 된 할당 자의 [`GlobalAlloc::alloc_zeroed`] 메서드 또는 `std` crate 의 기본값으로 호출을 전달합니다.
///
///
/// 이 기능은 [`Global`] 유형의 `alloc_zeroed` 방법과 [`Allocator`] trait 가 안정되면 더 이상 사용되지 않을 것으로 예상됩니다.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] 를 참조하십시오.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // 안전: `layout` 는 크기가 0이 아닙니다.
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // 안전: `Allocator::grow` 와 동일
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // 안전: `old_size` 가 `new_size` 보다 크거나 같으므로 `new_size` 는 0이 아닙니다.
            // 안전 조건에서 요구하는대로.발신자가 다른 조건을 유지해야합니다.
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` 아마도 `new_size >= old_layout.size()` 또는 유사한 것을 확인합니다.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // 안전: `new_layout.size()` 는 `old_size` 보다 크거나 같아야하기 때문에
            // 이전 및 새 메모리 할당은 모두 `old_size` 바이트의 읽기 및 쓰기에 유효합니다.
            // 또한 이전 할당이 아직 할당 해제되지 않았기 때문에 `new_ptr` 와 겹칠 수 없습니다.
            // 따라서 `copy_nonoverlapping` 에 대한 호출은 안전합니다.
            // `dealloc` 에 대한 안전 계약은 발신자가 유지해야합니다.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // 안전: `layout` 는 크기가 0이 아닙니다.
            // 다른 조건은 발신자가 유지해야합니다.
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 안전: 모든 조건은 발신자가 유지해야합니다.
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 안전: 모든 조건은 발신자가 유지해야합니다.
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // 안전: 발신자가 조건을 준수해야합니다.
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // 안전: `new_size` 는 0이 아닙니다.발신자가 다른 조건을 유지해야합니다.
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` 아마도 `new_size <= old_layout.size()` 또는 유사한 것을 확인합니다.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // 안전: `new_size` 는 `old_layout.size()` 보다 작거나 같아야하기 때문에
            // 이전 및 새 메모리 할당은 모두 `new_size` 바이트의 읽기 및 쓰기에 유효합니다.
            // 또한 이전 할당이 아직 할당 해제되지 않았기 때문에 `new_ptr` 와 겹칠 수 없습니다.
            // 따라서 `copy_nonoverlapping` 에 대한 호출은 안전합니다.
            // `dealloc` 에 대한 안전 계약은 발신자가 유지해야합니다.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// 고유 포인터에 대한 할당 자입니다.
// 이 기능은 해제되지 않아야합니다.그럴 경우 MIR 코드 생성이 실패합니다.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// 이 서명은 `Box` 와 동일해야합니다. 그렇지 않으면 ICE가 발생합니다.
// `Box` 에 추가 매개 변수가 추가되면 (예: `A: Allocator`) 여기에도 추가되어야합니다.
// 예를 들어 `Box` 가 `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` 로 변경되면이 기능도 `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` 로 변경되어야합니다.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # 할당 오류 처리기

extern "Rust" {
    // 전역 할당 오류 처리기를 호출하는 마법의 상징입니다.
    // rustc 는 `#[alloc_error_handler]` 가있는 경우 `__rg_oom` 를 호출하도록 생성하고 그렇지 않으면 (`__rdl_oom`) 아래의 기본 구현을 호출합니다.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// 메모리 할당 오류 또는 실패시 중단합니다.
///
/// 할당 오류에 대한 응답으로 계산을 중단하려는 메모리 할당 API 호출자는 `panic!` 또는 이와 유사한 것을 직접 호출하는 대신이 함수를 호출하는 것이 좋습니다.
///
///
/// 이 함수의 기본 동작은 메시지를 표준 오류로 인쇄하고 프로세스를 중단하는 것입니다.
/// [`set_alloc_error_hook`] 및 [`take_alloc_error_hook`] 로 대체 할 수 있습니다.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// 할당 테스트의 경우 `std::alloc::handle_alloc_error` 를 직접 사용할 수 있습니다.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // 생성 된 `__rust_alloc_error_handler` 를 통해 호출

    // `#[alloc_error_handler]` 가없는 경우
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // `#[alloc_error_handler]` 가있는 경우
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// 클론을 사전 할당되고 초기화되지 않은 메모리로 전문화합니다.
/// `Box::clone` 및 `Rc`/`Arc::make_mut` 에서 사용됩니다.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *first* 를 할당하면 옵티마이 저가 로컬 및 이동을 건너 뛰고 제자리에 복제 된 값을 생성 할 수 있습니다.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // 로컬 값을 사용하지 않고 항상 제자리에서 복사 할 수 있습니다.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}