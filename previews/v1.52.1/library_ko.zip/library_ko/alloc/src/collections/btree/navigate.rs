use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// 일시적으로 동일한 범위의 변경 불가능한 다른 항목을 가져옵니다.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 트리에서 지정된 범위를 구분하는 별개의 리프 가장자리를 찾습니다.
    /// 한 쌍의 다른 핸들을 동일한 트리 또는 한 쌍의 빈 옵션으로 반환합니다.
    ///
    /// # Safety
    ///
    /// `BorrowType` 가 `Immut` 가 아니면 중복 핸들을 사용하여 동일한 KV를 두 번 방문하지 마십시오.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` 와 동일하지만 더 효율적입니다.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// 트리에서 특정 범위를 구분하는 잎 가장자리 쌍을 찾습니다.
    ///
    /// 결과는 `BTreeMap` 의 트리와 같이 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // 안전: 우리의 차입 유형은 변경할 수 없습니다.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// 전체 트리를 구분하는 한 쌍의 잎 가장자리를 찾습니다.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// 고유 참조를 지정된 범위를 구분하는 리프 가장자리 쌍으로 분할합니다.
    /// 결과는 (some) 변이를 허용하는 고유하지 않은 참조이므로 신중하게 사용해야합니다.
    ///
    /// 결과는 `BTreeMap` 의 트리와 같이 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    ///
    ///
    /// # Safety
    /// 중복 핸들을 사용하여 동일한 KV를 두 번 방문하지 마십시오.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// 고유 한 참조를 트리의 전체 범위를 구분하는 한 쌍의 리프 가장자리로 분할합니다.
    /// 결과는 변경 (값만)을 허용하는 고유하지 않은 참조이므로주의해서 사용해야합니다.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // 여기서 루트 NodeRef를 복제합니다. 동일한 KV를 두 번 방문하지 않고 값 참조가 겹치지 않습니다.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// 고유 한 참조를 트리의 전체 범위를 구분하는 한 쌍의 리프 가장자리로 분할합니다.
    /// 결과는 대규모 파괴적인 돌연변이를 허용하는 고유하지 않은 참조이므로 최대한주의해서 사용해야합니다.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // 여기서 루트 NodeRef를 복제합니다. 루트에서 얻은 참조와 겹치는 방식으로 액세스하지 않습니다.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// 리프 edge 핸들이 주어지면 동일한 리프 노드 또는 조상 노드에있는 오른쪽의 인접 KV에 대한 핸들과 함께 [`Result::Ok`] 를 반환합니다.
    ///
    /// 리프 edge 가 트리의 마지막 리프이면 루트 노드와 함께 [`Result::Err`] 를 반환합니다.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// 리프 edge 핸들이 주어지면 동일한 리프 노드 또는 조상 노드에있는 왼쪽의 인접한 KV에 대한 핸들과 함께 [`Result::Ok`] 를 반환합니다.
    ///
    /// 리프 edge 가 트리의 첫 번째 리프이면 루트 노드와 함께 [`Result::Err`] 를 반환합니다.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// 내부 edge 핸들이 주어지면 오른쪽의 인접한 KV에 대한 핸들과 함께 [`Result::Ok`] 를 반환합니다.이 핸들은 동일한 내부 노드 또는 조상 노드에 있습니다.
    ///
    /// 내부 edge 가 트리의 마지막 항목이면 루트 노드와 함께 [`Result::Err`] 를 반환합니다.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// 죽어가는 나무에 잎 edge 핸들이 주어지면 오른쪽에있는 다음 잎 edge 와 그 사이에있는 키-값 쌍 (같은 잎 노드, 조상 노드 또는 존재하지 않음)을 반환합니다.
    ///
    ///
    /// 이 메서드는 또한 끝에 도달 한 모든 node(s) 를 할당 해제합니다.
    /// 이는 키-값 쌍이 더 이상 존재하지 않으면 트리의 나머지 전체가 할당 해제되고 반환 할 항목이 남지 않음을 의미합니다.
    ///
    /// # Safety
    /// 주어진 edge 는 상대 `deallocating_next_back` 에 의해 이전에 반환되지 않았어야합니다.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// 죽어가는 나무에 잎 edge 핸들이 주어지면 왼쪽에있는 다음 잎 edge 와 그 사이에있는 키-값 쌍 (동일 잎 노드, 조상 노드 또는 존재하지 않음)을 반환합니다.
    ///
    ///
    /// 이 메서드는 또한 끝에 도달 한 모든 node(s) 를 할당 해제합니다.
    /// 이는 키-값 쌍이 더 이상 존재하지 않으면 트리의 나머지 전체가 할당 해제되고 반환 할 항목이 남지 않음을 의미합니다.
    ///
    /// # Safety
    /// 주어진 edge 는 상대 `deallocating_next` 에 의해 이전에 반환되지 않았어야합니다.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// 리프에서 루트까지 노드 더미를 할당 해제합니다.
    /// 이것은 `deallocating_next` 와 `deallocating_next_back` 가 트리의 양쪽에서 니블 링되고 동일한 edge 에 도달 한 후 트리의 나머지 부분을 할당 해제하는 유일한 방법입니다.
    /// 모든 키와 값이 반환되었을 때만 호출되도록 의도되었으므로 키나 값에 대해 정리가 수행되지 않습니다.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 리프 edge 핸들을 다음 리프 edge 로 이동하고 그 사이의 키와 값에 대한 참조를 반환합니다.
    ///
    ///
    /// # Safety
    /// 여행하는 방향에 다른 KV가 있어야합니다.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// 리프 edge 핸들을 이전 리프 edge 로 이동하고 그 사이의 키 및 값에 대한 참조를 반환합니다.
    ///
    ///
    /// # Safety
    /// 여행하는 방향에 다른 KV가 있어야합니다.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 리프 edge 핸들을 다음 리프 edge 로 이동하고 그 사이의 키와 값에 대한 참조를 반환합니다.
    ///
    ///
    /// # Safety
    /// 여행하는 방향에 다른 KV가 있어야합니다.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // 벤치 마크에 따르면 마지막으로하는 것이 더 빠릅니다.
        kv.into_kv_valmut()
    }

    /// 리프 edge 핸들을 이전 리프로 이동하고 그 사이의 키와 값에 대한 참조를 반환합니다.
    ///
    ///
    /// # Safety
    /// 여행하는 방향에 다른 KV가 있어야합니다.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // 벤치 마크에 따르면 마지막으로하는 것이 더 빠릅니다.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// 리프 edge 핸들을 다음 리프 edge 로 이동하고 그 사이에 키와 값을 반환하여 남은 노드를 할당 해제하고 해당 edge 는 부모 노드에 매달린 상태로 둡니다.
    ///
    /// # Safety
    /// - 여행하는 방향에 다른 KV가 있어야합니다.
    /// - 해당 KV는 트리를 가로 지르는 데 사용되는 핸들의 사본에서 상대 `next_back_unchecked` 에 의해 이전에 리턴되지 않았습니다.
    ///
    /// 업데이트 된 핸들로 진행하는 유일한 안전한 방법은 비교, 삭제, 안전 조건에 따라이 메서드를 다시 호출하거나 안전 조건에 따라 상대 `next_back_unchecked` 를 호출하는 것입니다.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// 리프 edge 핸들을 이전 리프 edge 로 이동하고 그 사이에 키와 값을 반환하여 남은 노드를 할당 해제하고 해당 edge 는 부모 노드에 매달려 있습니다.
    ///
    /// # Safety
    /// - 여행하는 방향에 다른 KV가 있어야합니다.
    /// - 해당 리프 edge 는 트리를 가로 지르는 데 사용되는 핸들의 복사본에서 상대 `next_unchecked` 에 의해 이전에 반환되지 않았습니다.
    ///
    /// 업데이트 된 핸들로 진행하는 유일한 안전한 방법은 비교, 삭제, 안전 조건에 따라이 메서드를 다시 호출하거나 안전 조건에 따라 상대 `next_unchecked` 를 호출하는 것입니다.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 노드 안이나 아래에있는 가장 왼쪽의 잎 edge 를 반환합니다. 즉, 앞으로 탐색 할 때 먼저 필요로하는 edge 를 반환합니다 (또는 뒤로 탐색 할 때 마지막으로 탐색 할 때 마지막).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// 노드 안이나 아래의 맨 오른쪽 리프 edge 를 반환합니다. 즉, 앞으로 탐색 할 때 마지막으로 (또는 뒤로 탐색 할 때 먼저) 필요한 edge 를 반환합니다.
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// 오름차순 키 순서로 리프 노드 및 내부 KV를 방문하고 깊이 우선 순서로 전체 내부 노드를 방문합니다. 즉, 내부 노드가 개별 KV 및 하위 노드보다 우선합니다.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// (하위) 트리의 요소 수를 계산합니다.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// 순방향 탐색을 위해 KV에 가장 가까운 리프 edge 를 반환합니다.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// 뒤로 탐색을 위해 KV에 가장 가까운 리프 edge 를 반환합니다.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}