use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 형제와 병합하거나 훔쳐서 부족할 수있는 노드를 비축합니다.
    /// 성공했지만 상위 노드를 축소하는 대신 축소 된 상위 노드를 반환합니다.
    /// 노드가 빈 루트 인 경우 `Err` 를 반환합니다.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 부족할 수있는 노드를 비축하고 이로 인해 상위 노드가 축소되면 반복적으로 상위 노드를 비축합니다.
    /// 트리를 수정 한 경우 `true` 를 반환하고 루트 노드가 비어있어서 고정되지 않은 경우 `false` 를 반환합니다.
    ///
    /// 이 메서드는 입력시 조상이 이미 부족할 것으로 예상하지 않으며 빈 조상을 만나면 panics 가됩니다.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// 상단의 빈 레벨을 제거하지만 전체 트리가 비어있는 경우 빈 리프를 유지합니다.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// 트리의 오른쪽 경계에있는 언더 풀 노드를 비축하거나 병합합니다.
    /// 루트도 아니고 가장 오른쪽 edge 도 아닌 다른 노드에는 이미 최소 MIN_LEN 요소가 있어야합니다.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border` 의 대칭 클론.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// 트리의 오른쪽 경계에 부족한 노드를 비축하십시오.
    /// 루트도 아니고 가장 오른쪽 edge 도 아닌 다른 노드는 최대 MIN_LEN 요소를 훔칠 수 있도록 준비해야합니다.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // 가장 오른쪽에있는 아이가 부족한지 확인하십시오.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // 우리는 훔쳐 야합니다.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // 더 아래로 가십시오.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// 오른쪽 자식이 부족하지 않다고 가정하고 왼쪽 자식을 비축하고 부족하지 않고 자식을 차례로 병합 할 수 있도록 추가 요소를 제공합니다.
    ///
    /// 왼쪽 자식을 반환합니다.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` 병합이 다음 수준에서 발생하는 경우 재조정을 방지합니다.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// 왼쪽 자식이 부족하지 않다고 가정하고 오른쪽 자식을 비축하고 부족하지 않고 자식을 차례로 병합 할 수 있도록 추가 요소를 제공합니다.
    ///
    /// 올바른 아이가 끝날 때마다 돌아갑니다.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` 병합이 다음 수준에서 발생하는 경우 재조정을 방지합니다.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}