use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// 특정 이벤트를 모니터링하는 충돌 테스트 더미 인스턴스의 청사진입니다.
/// 일부 인스턴스는 어떤 시점에서 panic 로 구성 될 수 있습니다.
/// 이벤트는 `clone`, `drop` 또는 일부 익명 `query` 입니다.
///
/// 충돌 테스트 더미는 ID로 식별되고 정렬되므로 BTreeMap에서 키로 사용할 수 있습니다.
/// 의도적으로 사용하는 구현은 `Debug` trait 를 제외하고 crate 에 정의 된 항목에 의존하지 않습니다.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// 충돌 테스트 더미 디자인을 만듭니다.`id` 는 인스턴스의 순서와 동일성을 결정합니다.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// 발생하는 이벤트와 선택적으로 panics 를 기록하는 충돌 테스트 더미의 인스턴스를 만듭니다.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// 더미의 인스턴스가 복제 된 횟수를 반환합니다.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// 더미의 인스턴스가 삭제 된 횟수를 반환합니다.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// 더미의 인스턴스가 `query` 멤버를 호출 한 횟수를 반환합니다.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// 결과가 이미 제공된 일부 익명 쿼리.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}