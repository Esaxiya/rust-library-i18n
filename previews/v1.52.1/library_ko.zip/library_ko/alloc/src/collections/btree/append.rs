use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// 두 오름차순 반복자의 합집합에서 모든 키-값 쌍을 추가하여 그 과정에서 `length` 변수를 증가시킵니다.후자는 드롭 핸들러가 당황 할 때 호출자가 누출을 피하는 것을 더 쉽게 만듭니다.
    ///
    /// 두 반복자가 동일한 키를 생성하는 경우이 메서드는 왼쪽 반복기에서 쌍을 삭제하고 오른쪽 반복기에서 쌍을 추가합니다.
    ///
    /// `BTreeMap` 와 같이 트리가 엄격하게 오름차순으로 끝나도록하려면 두 반복자가 모두 트리에있는 모든 키보다 큰 키를 생성해야합니다.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // `left` 와 `right` 를 선형 시간으로 정렬 된 시퀀스로 병합 할 준비를합니다.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // 한편, 정렬 된 시퀀스에서 선형 시간으로 트리를 만듭니다.
        self.bulk_push(iter, length)
    }

    /// 모든 키-값 쌍을 트리의 끝에 밀어 넣어 `length` 변수를 증가시킵니다.
    /// 후자는 반복자가 당황 할 때 호출자가 누출을 피하는 것을 더 쉽게 만듭니다.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // 모든 키-값 쌍을 반복하여 올바른 수준의 노드로 푸시합니다.
        for (key, value) in iter {
            // 키-값 쌍을 현재 리프 노드로 푸시 해보십시오.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // 남은 공간이 없습니다.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // 남은 공간이있는 노드를 찾았습니다. 여기를 누르세요.
                                open_node = parent;
                                break;
                            } else {
                                // 다시 올라갑니다.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // 우리는 맨 위에 있고 새로운 루트 노드를 만들고 거기에 밀어 넣습니다.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // 키-값 쌍 및 새 오른쪽 하위 트리를 푸시합니다.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // 다시 맨 오른쪽 잎으로 내려갑니다.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // 반복자가 패닉을 일으키더라도 맵이 추가 된 요소를 삭제하도록 반복 할 때마다 길이를 늘립니다.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// 정렬 된 두 시퀀스를 하나로 병합하기위한 반복기
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// 두 키가 같으면 올바른 소스에서 키-값 쌍을 반환합니다.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}