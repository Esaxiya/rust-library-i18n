// 이것은 이상을 따르는 구현 시도입니다.
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust 에는 실제로 종속 유형과 다형성 재귀가 없기 때문에 많은 안전하지 않습니다.
//

// 이 모듈의 주요 목표는 트리를 일반적인 (이상한 모양의) 컨테이너로 취급하고 대부분의 B-트리 불변을 처리하지 않음으로써 복잡성을 피하는 것입니다.
//
// 따라서이 모듈은 항목이 정렬되었는지, 어떤 노드가 부족할 수 있는지 또는 부족이 무엇을 의미하는지는 상관하지 않습니다.그러나 우리는 몇 가지 불변성에 의존합니다.
//
// - 나무는 균일 한 depth/height 를 가져야합니다.이것은 주어진 노드에서 리프로 내려가는 모든 경로가 정확히 같은 길이를 가짐을 의미합니다.
// - 길이가 `n` 인 노드에는 `n` 키, `n` 값 및 `n + 1` 가장자리가 있습니다.
//   이는 빈 노드에도 하나 이상의 edge 가 있음을 의미합니다.
//   리프 노드의 경우 "having an edge" 는 리프 가장자리가 비어 있고 데이터 표현이 필요하지 않기 때문에 노드에서 위치를 식별 할 수 있음을 의미합니다.
// 내부 노드에서 edge 는 위치를 식별하고 자식 노드에 대한 포인터를 포함합니다.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// 리프 노드의 기본 표현과 내부 노드 표현의 일부입니다.
struct LeafNode<K, V> {
    /// 우리는 `K` 와 `V` 에서 공변이되기를 원합니다.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// 이 노드의 인덱스는 부모 노드의 `edges` 배열에 있습니다.
    /// `*node.parent.edges[node.parent_idx]` `node` 와 동일해야합니다.
    /// 이것은 `parent` 가 널이 아닌 경우에만 초기화됩니다.
    parent_idx: MaybeUninit<u16>,

    /// 이 노드가 저장하는 키 및 값의 수입니다.
    len: u16,

    /// 노드의 실제 데이터를 저장하는 배열입니다.
    /// 각 배열의 첫 번째 `len` 요소 만 초기화되고 유효합니다.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// 새 `LeafNode` 를 제자리에서 초기화합니다.
    unsafe fn init(this: *mut Self) {
        // 일반적인 정책으로 Valgrind에서 약간 더 빠르고 쉽게 추적 할 수 있어야하므로 가능한 경우 필드를 초기화하지 않은 상태로 둡니다.
        //
        unsafe {
            // parent_idx, 키 및 값은 모두 MaybeUninit입니다.
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// 새로운 박스형 `LeafNode` 를 만듭니다.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// 내부 노드의 기본 표현입니다.`LeafNode`와 마찬가지로 초기화되지 않은 키와 값을 삭제하지 않도록`BoxedNode` 뒤에 숨겨야합니다.
/// `InternalNode` 에 대한 모든 포인터는 노드의 기본 `LeafNode` 부분에 대한 포인터로 직접 캐스팅 될 수 있으므로 포인터가 가리키는 두 노드를 확인하지 않고도 코드가 리프 및 내부 노드에서 일반적으로 작동 할 수 있습니다.
///
/// 이 속성은 `repr(C)` 를 사용하여 활성화됩니다.
///
#[repr(C)]
// gdb_providers.py 인트로 스펙 션에이 유형 이름을 사용합니다.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// 이 노드의 자식에 대한 포인터입니다.
    /// `len + 1` 이들 중 일부는 초기화되고 유효한 것으로 간주됩니다.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// 새로운 박스형 `InternalNode` 를 만듭니다.
    ///
    /// # Safety
    /// 내부 노드의 불변은 초기화되고 유효한 edge 가 하나 이상 있다는 것입니다.
    /// 이 기능은 그러한 edge 를 설정하지 않습니다.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // 데이터를 초기화하기 만하면됩니다.가장자리는 MaybeUninit입니다.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// 노드에 대한 관리되는 널이 아닌 포인터.이것은 `LeafNode<K, V>` 에 대한 소유 포인터이거나 `InternalNode<K, V>` 에 대한 소유 포인터입니다.
///
/// 그러나 `BoxedNode` 에는 실제로 포함 된 두 가지 유형의 노드에 대한 정보가 포함되어 있지 않으며 부분적으로 이러한 정보 부족으로 인해 별도의 유형이 아니며 소멸자가 없습니다.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// 소유 된 트리의 루트 노드입니다.
///
/// 여기에는 소멸자가 없으므로 수동으로 정리해야합니다.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// 처음에는 비어있는 자체 루트 노드가있는 새 소유 트리를 반환합니다.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` 0이 아니어야합니다.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// 소유 한 루트 노드를 상호 차용합니다.
    /// `reborrow_mut` 와 달리 반환 값을 사용하여 루트를 파괴 할 수없고 트리에 대한 다른 참조가있을 수 없기 때문에 안전합니다.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 소유 한 루트 노드를 약간 변경합니다.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 순회를 허용하고 파괴적인 방법 만 제공하는 참조로 비가 역적으로 전환합니다.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// 이전 루트 노드를 가리키는 단일 edge 가있는 새 내부 노드를 추가하고 새 노드를 루트 노드로 만들고 반환합니다.
    /// 이렇게하면 높이가 1 씩 증가하고 `pop_internal_level` 와 반대입니다.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, 우리가 지금 내부라는 것을 잊었다는 점만 빼면
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 첫 번째 자식을 새 루트 노드로 사용하여 내부 루트 노드를 제거합니다.
    /// 루트 노드에 자식이 하나만있을 때만 호출되도록 의도되었으므로 키, 값 및 기타 자식에 대해 정리가 수행되지 않습니다.
    ///
    /// 이것은 높이를 1 감소시키고 `push_internal_level` 의 반대입니다.
    ///
    /// `Root` 개체에 대한 단독 액세스가 필요하지만 루트 노드에는 액세스 할 수 없습니다.
    /// 루트 노드에 대한 다른 핸들이나 참조를 무효화하지 않습니다.
    ///
    /// Panics 내부 수준이없는 경우, 즉 루트 노드가 리프 인 경우.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // 안전: 우리는 내부적이라고 주장했습니다.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // 안전: 우리는 `self` 를 독점적으로 차용했으며 차용 유형은 배타적입니다.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // 안전: 첫 번째 edge 는 항상 초기화됩니다.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` 는 `BorrowType` 가 `Mut` 인 경우에도 `K` 및 `V` 에서 항상 공변입니다.
// 이것은 기술적으로 잘못되었지만 `K` 및 `V` 에 대해 완전히 일반적으로 유지되기 때문에 `NodeRef` 의 내부 사용으로 인해 안전하지 않은 결과를 초래할 수 없습니다.
//
// 그러나 공용 유형이 `NodeRef` 를 래핑 할 때마다 올바른 분산이 있는지 확인하십시오.
//
/// 노드에 대한 참조입니다.
///
/// 이 유형에는 작동 방식을 제어하는 여러 매개 변수가 있습니다.
/// - `BorrowType`: 차용의 종류를 설명하고 평생을 전달하는 더미 유형입니다.
///    - 이것이 `Immut<'a>` 일 때 `NodeRef` 는 대략 `&'a Node` 처럼 작동합니다.
///    - 이것이 `ValMut<'a>` 인 경우 `NodeRef` 는 키 및 트리 구조와 관련하여 대략 `&'a Node` 와 유사하게 작동하지만 트리 전체의 값에 대한 많은 가변 참조가 공존 할 수 있습니다.
///    - 이것이 `Mut<'a>` 일 때 `NodeRef` 는 대략 `&'a mut Node` 처럼 작동하지만 삽입 메소드는 값에 대한 가변 포인터가 공존하도록 허용합니다.
///    - 이것이 `Owned` 인 경우 `NodeRef` 는 대략 `Box<Node>` 와 유사하게 작동하지만 소멸자가 없으므로 수동으로 정리해야합니다.
///    - 이것이 `Dying` 인 경우 `NodeRef` 는 여전히 대략 `Box<Node>` 와 비슷하게 작동하지만 트리를 조금씩 파괴하는 메서드가 있으며, 호출하기에 안전하지 않은 것으로 표시되지 않은 일반 메서드는 잘못 호출되면 UB를 호출 할 수 있습니다.
///
///   `NodeRef` 는 트리를 탐색 할 수 있으므로 `BorrowType` 는 노드 자체뿐만 아니라 전체 트리에 효과적으로 적용됩니다.
/// - `K` 및 `V`: 노드에 저장된 키 및 값의 유형입니다.
/// - `Type`: `Leaf`, `Internal` 또는 `LeafOrInternal` 일 수 있습니다.
/// 이것이 `Leaf` 이면 `NodeRef` 는 리프 노드를 가리키고, 이것이 `Internal` 이면 `NodeRef` 는 내부 노드를 가리키고, 이것이 `LeafOrInternal` 이면 `NodeRef` 는 두 유형의 노드를 가리킬 수 있습니다.
///   `Type` `NodeRef` 외부에서 사용할 경우 이름이 `NodeType` 입니다.
///
/// `BorrowType` 와 `NodeType` 는 정적 유형 안전성을 활용하기 위해 구현하는 방법을 제한합니다.이러한 제한을 적용 할 수있는 방법에는 제한이 있습니다.
/// - 각 유형 매개 변수에 대해 일반적으로 또는 하나의 특정 유형에 대해서만 메소드를 정의 할 수 있습니다.
/// 예를 들어 모든 `BorrowType` 에 대해 일반적으로 `into_kv` 와 같은 메서드를 정의 할 수 없으며, `&'a` 참조를 반환하기를 원하기 때문에 수명이있는 모든 유형에 대해 한 번 정의 할 수 없습니다.
///   따라서 가장 강력한 유형 인 `Immut<'a>` 에 대해서만 정의합니다.
/// - 우리는 `Mut<'a>` 에서 `Immut<'a>` 로의 암시 적 강제를 얻을 수 없습니다.
///   따라서 `into_kv` 와 같은 메서드에 도달하려면보다 강력한 `NodeRef` 에서 `reborrow` 를 명시 적으로 호출해야합니다.
///
/// 다음 중 하나의 참조를 반환하는 `NodeRef` 의 모든 메서드 :
/// - `self` 를 값으로 취하고 `BorrowType` 가 수행 한 수명을 반환합니다.
///   때때로 이러한 메서드를 호출하려면 `reborrow_mut` 를 호출해야합니다.
/// - `self` 를 참조로 가져 오면 (implicitly) 는 `BorrowType` 가 전달하는 수명 대신 해당 참조의 수명을 반환합니다.
/// 이러한 방식으로 차용 검사기는 반환 된 참조가 사용되는 한 `NodeRef` 가 차용 된 상태로 유지되도록 보장합니다.
///   삽입을 지원하는 메서드는 원시 포인터, 즉 수명이없는 참조를 반환하여이 규칙을 구부립니다.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// 노드와 잎의 수준이 떨어져있는 수준의 수, `Type` 에서 완전히 설명 할 수없는 노드의 상수이며 노드 자체가 저장하지 않습니다.
    /// 루트 노드의 높이 만 저장하고 여기에서 다른 모든 노드의 높이를 가져 오면됩니다.
    /// `Type` 가 `Leaf` 이면 0이고 `Type` 가 `Internal` 이면 0이 아니어야합니다.
    ///
    ///
    height: usize,
    /// 리프 또는 내부 노드에 대한 포인터입니다.
    /// `InternalNode` 의 정의는 포인터가 어느 쪽이든 유효한지 확인합니다.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` 로 압축 된 노드 참조의 압축을 풉니 다.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// 내부 노드의 데이터를 노출합니다.
    ///
    /// 이 노드에 대한 다른 참조를 무효화하지 않도록 원시 ptr을 반환합니다.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // 안전: 정적 노드 유형은 `Internal` 입니다.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// 내부 노드의 데이터에 대한 독점 액세스를 빌립니다.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// 노드의 길이를 찾습니다.이것은 키 또는 값의 수입니다.
    /// 모서리 수는 `len() + 1` 입니다.
    /// 안전 함에도 불구하고이 함수를 호출하면 안전하지 않은 코드가 생성 한 변경 가능한 참조를 무효화하는 부작용이 발생할 수 있습니다.
    ///
    pub fn len(&self) -> usize {
        // 결정적으로 우리는 여기서 `len` 필드에만 액세스합니다.
        // BorrowType이 marker::ValMut 이면 무효화해서는 안되는 값에 대한 뛰어난 변경 가능한 참조가있을 수 있습니다.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// 노드와 잎이 떨어져있는 수준 수를 반환합니다.
    /// 0 높이는 노드 자체가 리프임을 의미합니다.
    /// 루트가 위에있는 나무를 상상하면 숫자는 노드가 나타나는 고도를 나타냅니다.
    /// 잎이 위에있는 나무를 상상하면 숫자는 나무가 노드 위로 얼마나 높이 확장되는지를 나타냅니다.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// 일시적으로 동일한 노드에 대한 다른 불변 참조를 가져옵니다.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 리프 또는 내부 노드의 리프 부분을 노출합니다.
    ///
    /// 이 노드에 대한 다른 참조를 무효화하지 않도록 원시 ptr을 반환합니다.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // 노드는 최소한 LeafNode 부분에 대해 유효해야합니다.
        // 고유해야하는지 공유해야하는지 알 수 없기 때문에 NodeRef 유형의 참조가 아닙니다.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// 현재 노드의 부모를 찾습니다.
    /// 현재 노드에 실제로 부모가있는 경우 `Ok(handle)` 를 반환합니다. 여기서 `handle` 는 현재 노드를 가리키는 부모의 edge 를 가리 킵니다.
    ///
    /// 현재 노드에 부모가 없으면 `Err(self)` 를 반환하고 원래 `NodeRef` 를 반환합니다.
    ///
    /// 메서드 이름은 루트 노드가 맨 위에있는 트리를 그리는 것으로 가정합니다.
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` 는 성공하면 아무것도하지 않아야합니다.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // BorrowType이 marker::ValMut 이면 무효화해서는 안되는 값에 대한 뛰어난 가변 참조가있을 수 있기 때문에 노드에 대한 원시 포인터를 사용해야합니다.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` 는 비어 있지 않아야합니다.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` 는 비어 있지 않아야합니다.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// 변경 불가능한 트리에서 리프 또는 내부 노드의 리프 부분을 노출합니다.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // 안전: `Immut` 로 빌린이 트리에는 변경 가능한 참조가있을 수 없습니다.
        unsafe { &*ptr }
    }

    /// 노드에 저장된 키로 뷰를 빌립니다.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` 와 유사하게 노드의 상위 노드에 대한 참조를 가져 오지만 프로세스에서 현재 노드의 할당도 해제합니다.
    /// 현재 노드는 할당이 해제 되었음에도 여전히 액세스 할 수 있기 때문에 안전하지 않습니다.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 이 노드가 `Leaf` 라는 정적 정보를 컴파일러에 안전하지 않게 어설 션합니다.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 이 노드가 `Internal` 라는 정적 정보를 컴파일러에 안전하지 않게 어설 션합니다.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// 일시적으로 동일한 노드에 대한 다른 변경 가능한 참조를 가져옵니다.이 방법은 매우 위험하므로 즉시 위험 해 보이지 않을 수 있으므로 두 배로주의하십시오.
    ///
    /// 변경 가능한 포인터는 트리 주변 어디에서나 로밍 할 수 있기 때문에 반환 된 포인터를 사용하여 원래 포인터가 매달 리거나, 경계를 벗어 났거나, 스택 차용 규칙에 따라 유효하지 않게 만들 수 있습니다.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) 재차 용 된 포인터에 대한 탐색 메서드 사용을 제한하는 또 다른 형식 매개 변수를 `NodeRef` 에 추가하여 이러한 위험을 방지하는 것이 좋습니다.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 리프 또는 내부 노드의 리프 부분에 대한 독점 액세스 권한을 가져옵니다.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // 안전: 우리는 전체 노드에 독점적으로 액세스 할 수 있습니다.
        unsafe { &mut *ptr }
    }

    /// 리프 또는 내부 노드의 리프 부분에 대한 독점 액세스를 제공합니다.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // 안전: 우리는 전체 노드에 독점적으로 액세스 할 수 있습니다.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// 키 저장 영역의 요소에 대한 독점적 인 액세스를 차용합니다.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY 범위 내에 있습니다.
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // 안전: 호출자는 자신에 대해 추가 메서드를 호출 할 수 없습니다.
        // 키 슬라이스 참조가 삭제 될 때까지 차용 기간 동안 고유 한 액세스 권한을 갖습니다.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// 노드 값 저장 영역의 요소 또는 슬라이스에 대한 독점 액세스를 빌립니다.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY 범위 내에 있습니다.
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // 안전: 호출자는 자신에 대해 추가 메서드를 호출 할 수 없습니다.
        // 값 조각 참조가 삭제 될 때까지 차용 기간 동안 고유 한 액세스 권한이 있습니다.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge 콘텐츠에 대한 노드 저장 영역의 요소 또는 슬라이스에 대한 독점 액세스 권한을 빌립니다.
    ///
    /// # Safety
    /// `index` 범위는 0..CAPACITY + 1입니다.
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // 안전: 호출자는 자신에 대해 추가 메서드를 호출 할 수 없습니다.
        // 차용 기간 동안 고유 한 액세스 권한이 있으므로 edge 슬라이스 참조가 삭제 될 때까지
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - 노드에 `idx` 이상의 초기화 요소가 있습니다.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // 다른 요소, 특히 이전 반복에서 호출자에게 반환 된 요소에 대한 뛰어난 참조로 앨리어싱을 방지하기 위해 관심있는 한 요소에 대한 참조 만 만듭니다.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust 문제 #74679 때문에 크기가 지정되지 않은 배열 포인터로 강제 변환해야합니다.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// 노드 길이에 대한 독점 액세스를 빌립니다.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 노드에 대한 다른 참조를 무효화하지 않고 노드의 링크를 상위 edge 로 설정합니다.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// 부모 edge 에 대한 루트의 링크를 지 웁니다.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// 노드 끝에 키-값 쌍을 추가합니다.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` 가 반환하는 모든 항목은 노드에 대해 유효한 edge 인덱스입니다.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// 키-값 쌍과 edge 를 추가하여 해당 쌍의 오른쪽, 노드 끝에 이동합니다.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 노드가 `Internal` 노드인지 `Leaf` 노드인지 확인합니다.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// 노드 내에서 특정 키-값 쌍 또는 edge 에 대한 참조입니다.
/// `Node` 매개 변수는 `NodeRef` 여야하며 `Type` 는 `KV` (키-값 쌍의 핸들을 나타냄) 또는 `Edge` (edge 의 핸들을 나타냄) 일 수 있습니다.
///
/// `Leaf` 노드도 `Edge` 핸들을 가질 수 있습니다.
/// 자식 노드에 대한 포인터를 나타내는 대신 자식 포인터가 키-값 쌍 사이를 이동할 공간을 나타냅니다.
/// 예를 들어, 길이가 2 인 노드에는 가능한 edge 위치가 3 개 있습니다. 하나는 노드 왼쪽에, 하나는 두 쌍 사이에, 하나는 노드 오른쪽에 있습니다.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// `Node` 가 '복제'가능한 유일한 시간은 변경 불가능한 참조이므로 `Copy` 일 때이므로 `#[derive(Clone)]` 의 완전한 일반성이 필요하지 않습니다.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// 이 핸들이 가리키는 edge 또는 키-값 쌍을 포함하는 노드를 검색합니다.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// 노드에서이 핸들의 위치를 반환합니다.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` 에서 키-값 쌍에 대한 새 핸들을 만듭니다.
    /// 호출자가 `idx < node.len()` 를 확인해야하기 때문에 안전하지 않습니다.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq의 공개 구현 일 수 있지만이 모듈에서만 사용됩니다.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// 일시적으로 동일한 위치에서 변경 불가능한 다른 핸들을 가져옵니다.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // 유형을 모르기 때문에 Handle::new_kv 또는 Handle::new_edge 를 사용할 수 없습니다.
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// 핸들의 노드가 `Leaf` 라는 정적 정보를 컴파일러에 안전하지 않게 어설 션합니다.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// 일시적으로 같은 위치에서 다른 변경 가능한 핸들을 가져옵니다.
    /// 이 방법은 매우 위험하므로 즉시 위험 해 보이지 않을 수 있으므로 두 배로주의하십시오.
    ///
    ///
    /// 자세한 내용은 `NodeRef::reborrow_mut` 를 참조하십시오.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // 유형을 모르기 때문에 Handle::new_kv 또는 Handle::new_edge 를 사용할 수 없습니다.
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` 에서 edge 에 대한 새 핸들을 만듭니다.
    /// 호출자가 `idx <= node.len()` 를 확인해야하기 때문에 안전하지 않습니다.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// 용량이 채워진 노드에 삽입하려는 edge 인덱스가 주어지면 분할 지점과 삽입을 수행 할 위치의 합리적인 KV 인덱스를 계산합니다.
///
/// 분할 지점의 목표는 키와 값이 상위 노드에서 끝나는 것입니다.
/// 분리 점 왼쪽에있는 키, 값 및 가장자리는 왼쪽 자식이됩니다.
/// 분할 점 오른쪽에있는 키, 값 및 가장자리가 오른쪽 자식이됩니다.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust 문제 #74834 는 이러한 대칭 규칙을 설명하려고합니다.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 이 edge 의 오른쪽과 왼쪽에있는 키-값 쌍 사이에 새 키-값 쌍을 삽입합니다.
    /// 이 방법은 새 쌍을 맞출 수있는 충분한 공간이 노드에 있다고 가정합니다.
    ///
    /// 반환 된 포인터는 삽입 된 값을 가리 킵니다.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 이 edge 의 오른쪽과 왼쪽에있는 키-값 쌍 사이에 새 키-값 쌍을 삽입합니다.
    /// 이 방법은 공간이 충분하지 않은 경우 노드를 분할합니다.
    ///
    /// 반환 된 포인터는 삽입 된 값을 가리 킵니다.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// 이 edge 가 연결하는 자식 노드의 부모 포인터와 인덱스를 수정합니다.
    /// 이것은 모서리 순서가 변경되었을 때 유용합니다.
    fn correct_parent_link(self) {
        // 노드에 대한 다른 참조를 무효화하지 않고 백 포인터를 만듭니다.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// 이 edge 와이 edge 의 오른쪽에있는 키-값 쌍 사이에 새 키-값 쌍과 새 쌍의 오른쪽으로 이동할 edge 를 삽입합니다.
    /// 이 방법은 새 쌍을 맞출 수있는 충분한 공간이 노드에 있다고 가정합니다.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// 이 edge 와이 edge 의 오른쪽에있는 키-값 쌍 사이에 새 키-값 쌍과 새 쌍의 오른쪽으로 이동할 edge 를 삽입합니다.
    /// 이 방법은 공간이 충분하지 않은 경우 노드를 분할합니다.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// 이 edge 의 오른쪽과 왼쪽에있는 키-값 쌍 사이에 새 키-값 쌍을 삽입합니다.
    /// 이 메서드는 공간이 충분하지 않은 경우 노드를 분할하고 루트에 도달 할 때까지 분할 된 부분을 부모 노드에 반복적으로 삽입하려고합니다.
    ///
    ///
    /// 반환 된 결과가 `Fit` 이면 핸들의 노드는이 edge 의 노드 또는 조상일 수 있습니다.
    /// 반환 된 결과가 `Split` 이면 `left` 필드는 루트 노드가됩니다.
    /// 반환 된 포인터는 삽입 된 값을 가리 킵니다.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// 이 edge 가 가리키는 노드를 찾습니다.
    ///
    /// 메서드 이름은 루트 노드가 맨 위에있는 트리를 그리는 것으로 가정합니다.
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` 는 성공하면 아무것도하지 않아야합니다.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // BorrowType이 marker::ValMut 이면 무효화해서는 안되는 값에 대한 뛰어난 가변 참조가있을 수 있기 때문에 노드에 대한 원시 포인터를 사용해야합니다.
        // 해당 값이 복사되므로 높이 필드에 액세스 할 걱정이 없습니다.
        // 노드 포인터가 역 참조되면 참조 (Rust 문제 #73987)를 사용하여 가장자리 배열에 액세스하고 배열에 대한 또는 배열 내부의 다른 참조를 무효화합니다.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // 두 번째를 호출하면 첫 번째가 반환 한 참조가 무효화되므로 별도의 키 및 값 메서드를 호출 할 수 없습니다.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV 핸들이 참조하는 키와 값을 바꿉니다.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// 리프 데이터를 처리하여 특정 `NodeType` 에 대한 `split` 구현을 지원합니다.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// 기본 노드를 세 부분으로 분할합니다.
    ///
    /// - 노드는이 핸들의 왼쪽에있는 키-값 쌍만 포함하도록 잘립니다.
    /// - 이 핸들이 가리키는 키와 값이 추출됩니다.
    /// - 이 핸들의 오른쪽에있는 모든 키-값 쌍은 새로 할당 된 노드에 배치됩니다.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// 이 핸들이 가리키는 키-값 쌍을 제거하고 키-값 쌍이 축소 된 edge 와 함께 반환합니다.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// 기본 노드를 세 부분으로 분할합니다.
    ///
    /// - 노드는이 핸들의 왼쪽에있는 가장자리와 키-값 쌍만 포함하도록 잘립니다.
    /// - 이 핸들이 가리키는 키와 값이 추출됩니다.
    /// - 이 핸들의 오른쪽에있는 모든 가장자리와 키-값 쌍은 새로 할당 된 노드에 배치됩니다.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// 내부 키-값 쌍에 대한 균형 조정 작업을 평가하고 수행하기위한 세션을 나타냅니다.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 노드를 자식으로 포함하는 균형 조정 컨텍스트를 선택하므로 부모 노드에서 바로 왼쪽 또는 오른쪽에있는 KV 사이에 있습니다.
    /// 부모가없는 경우 `Err` 를 반환합니다.
    /// 부모가 비어있는 경우 Panics.
    ///
    /// 주어진 노드가 어떻게 든 부족한 경우 최적이되도록 왼쪽을 선호합니다. 즉, 여기서는 왼쪽 형제보다 요소가 더 적고 존재하는 경우 오른쪽 형제보다 요소가 적다는 것을 의미합니다.
    /// 이 경우 왼쪽 형제와 병합하는 것이 더 빠릅니다. 노드의 N 요소 만 오른쪽으로 이동하고 앞으로 N 개 이상의 요소를 이동하는 대신 이동하면되기 때문입니다.
    /// 왼쪽 형제에서 훔치는 것도 일반적으로 더 빠릅니다. 왜냐하면 우리는 형제 요소의 N 개 이상을 왼쪽으로 이동하는 대신 노드의 N 요소 만 오른쪽으로 이동하면되기 때문입니다.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// 병합이 가능한지 여부, 즉 노드에 중앙 KV를 인접한 두 자식 노드와 결합하기에 충분한 공간이 있는지 여부를 반환합니다.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// 병합을 수행하고 클로저가 반환 할 항목을 결정하도록합니다.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // 안전: 병합되는 노드의 높이가 높이보다 하나 낮습니다.
                // 이 edge 의 노드의 0보다 크므로 내부에 있습니다.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// 부모의 키-값 쌍과 인접한 두 자식 노드를 왼쪽 자식 노드에 병합하고 축소 된 부모 노드를 반환합니다.
    ///
    ///
    /// 우리가 `.can_merge()` 하지 않는 한 Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// 부모의 키-값 쌍과 인접한 두 자식 노드를 왼쪽 자식 노드로 병합하고 해당 자식 노드를 반환합니다.
    ///
    ///
    /// 우리가 `.can_merge()` 하지 않는 한 Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// 부모의 키-값 쌍과 두 인접 자식 노드를 왼쪽 자식 노드로 병합하고 추적 된 자식 edge 가 종료 된 자식 노드의 edge 핸들을 반환합니다.
    ///
    ///
    /// 우리가 `.can_merge()` 하지 않는 한 Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// 왼쪽 하위에서 키-값 쌍을 제거하고 상위의 키-값 저장소에 배치하는 동시에 이전 상위 키-값 쌍을 오른쪽 하위에 푸시합니다.
    ///
    /// `track_right_edge_idx` 에서 지정한 원래 edge 가 끝나는 위치에 해당하는 오른쪽 자식의 edge 에 대한 핸들을 반환합니다.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// 오른쪽 하위에서 키-값 쌍을 제거하고 상위의 키-값 저장소에 배치하는 동시에 이전 상위 키-값 쌍을 왼쪽 하위에 푸시합니다.
    ///
    /// `track_left_edge_idx` 에 의해 지정된 왼쪽 자식에서 움직이지 않은 edge 에 대한 핸들을 반환합니다.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// 이것은 `steal_left` 와 유사하게 훔치지 만 한 번에 여러 요소를 훔칩니다.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // 안전하게 훔칠 수 있는지 확인하십시오.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // 리프 데이터를 이동합니다.
            {
                // 오른쪽 아이에게 훔친 요소를위한 공간을 만드십시오.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // 왼쪽 자식에서 오른쪽 자식으로 요소를 이동합니다.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // 가장 왼쪽에있는 훔친 쌍을 부모에게 옮깁니다.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // 부모의 키-값 쌍을 오른쪽 자식으로 이동합니다.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // 훔친 가장자리를위한 공간을 만드십시오.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // 가장자리를 훔칩니다.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` 의 대칭 클론.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // 안전하게 훔칠 수 있는지 확인하십시오.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // 리프 데이터를 이동합니다.
            {
                // 가장 오른쪽에있는 훔친 쌍을 부모에게 옮깁니다.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // 부모의 키-값 쌍을 왼쪽 자식으로 이동합니다.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // 오른쪽 자식에서 왼쪽 자식으로 요소를 이동합니다.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // 훔친 요소가 있던 자리를 메우십시오.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // 가장자리를 훔칩니다.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // 훔친 모서리가 있던 부분을 채우십시오.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// 이 노드가 `Leaf` 노드임을 주장하는 모든 정적 정보를 제거합니다.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// 이 노드가 `Internal` 노드임을 주장하는 모든 정적 정보를 제거합니다.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// 기본 노드가 `Internal` 노드인지 `Leaf` 노드인지 확인합니다.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` 뒤의 접미사를 한 노드에서 다른 노드로 이동합니다.`right` 는 비어 있어야합니다.
    /// `right` 의 첫 번째 edge 는 변경되지 않습니다.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// 노드가 용량 이상으로 확장되어야하는 경우 삽입 결과입니다.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` 의 왼쪽에 속하는 요소와 모서리가있는 기존 트리의 노드를 변경했습니다.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // 일부 키와 값이 분리되어 다른 곳에 삽입됩니다.
    pub kv: (K, V),
    // `kv` 의 오른쪽에 속하는 요소와 모서리가있는 소유, 연결되지 않은 새 노드.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // 이 차용 유형의 노드 참조가 트리의 다른 노드로의 이동을 허용하는지 여부입니다.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // 순회가 필요하지 않습니다. `borrow_mut` 의 결과를 사용하여 발생합니다.
        // 순회를 비활성화하고 루트에 대한 새 참조 만 생성하면 `Owned` 유형의 모든 참조가 루트 노드에 대한 것임을 알 수 있습니다.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// 초기화되지 않은 요소가 뒤에 오는 초기화 된 요소 조각에 값을 삽입합니다.
///
/// # Safety
/// 슬라이스에 `idx` 이상의 요소가 있습니다.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// 초기화 된 모든 요소의 조각에서 값을 제거하고 반환하여 후행 초기화되지 않은 요소를 하나 남깁니다.
///
///
/// # Safety
/// 슬라이스에 `idx` 이상의 요소가 있습니다.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// 슬라이스 `distance` 의 요소를 왼쪽으로 이동합니다.
///
/// # Safety
/// 슬라이스에는 최소한 `distance` 요소가 있습니다.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// 슬라이스 `distance` 의 요소를 오른쪽으로 이동합니다.
///
/// # Safety
/// 슬라이스에는 최소한 `distance` 요소가 있습니다.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// 초기화 된 요소 조각에서 초기화되지 않은 요소 조각으로 모든 값을 이동하고 `src` 는 모두 초기화되지 않은 상태로 둡니다.
///
/// `dst.copy_from_slice(src)` 처럼 작동하지만 `T` 가 `Copy` 일 필요는 없습니다.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;