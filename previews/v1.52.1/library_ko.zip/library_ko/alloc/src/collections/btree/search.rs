use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` 와 같은 포괄적 인 바운드.
    Included(T),
    /// `Bound::Excluded(T)` 와 같이 독점적으로 찾을 수 있습니다.
    Excluded(T),
    /// `Bound::Unbounded` 와 같은 무조건 포함 경계.
    AllIncluded,
    /// 무조건적인 배타적 경계.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// 노드가 이끄는 (하위) 트리에서 주어진 키를 재귀 적으로 찾습니다.
    /// 일치하는 KV의 핸들이있는 경우 `Found` 를 반환합니다.
    /// 그렇지 않으면 키가 속한 리프 edge 의 핸들이있는 `GoDown` 를 반환합니다.
    ///
    /// 결과는 `BTreeMap` 의 트리와 같이 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// 범위의 하한과 일치하는 edge 가 상한과 일치하는 edge, 즉 범위에 포함 된 키가 하나 이상있는 가장 가까운 노드와 다른 가장 가까운 노드로 내려갑니다.
    ///
    ///
    /// 발견되면 해당 노드와 함께 `Ok`, 범위를 구분하는 edge 인덱스 쌍, 노드가 내부 노드 인 경우 하위 노드에서 검색을 계속하기위한 해당 경계 쌍을 반환합니다.
    ///
    /// 찾을 수없는 경우 리프 edge 가 전체 범위와 일치하는 `Err` 를 반환합니다.
    ///
    /// 결과는 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // 이러한 변수를 인라인하지 않아야합니다.
        // `range` 에 의해보고 된 경계는 동일하게 유지되지만 적대적 구현은 (#81138) 호출간에 변경 될 수 있습니다.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// 범위의 하한을 구분하는 노드에서 edge 를 찾습니다.
    /// 또한 `self` 가 내부 노드 인 경우 일치하는 자식 노드에서 검색을 계속하는 데 사용할 하한을 반환합니다.
    ///
    ///
    /// 결과는 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// 상한에 대한 `find_lower_bound_edge` 의 복제.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// 재귀없이 노드에서 주어진 키를 찾습니다.
    /// 일치하는 KV의 핸들이있는 경우 `Found` 를 반환합니다.
    /// 그렇지 않으면 키를 찾을 수 있거나 (노드가 내부 인 경우) 키를 삽입 할 수있는 edge 의 핸들과 함께 `GoDown` 를 반환합니다.
    ///
    ///
    /// 결과는 `BTreeMap` 의 트리와 같이 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// 키 (또는 동등한 항목)가있는 노드의 KV 인덱스 또는 키가 속한 edge 인덱스를 반환합니다.
    ///
    ///
    /// 결과는 `BTreeMap` 의 트리와 같이 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// 범위의 하한을 구분하는 노드에서 edge 인덱스를 찾습니다.
    /// 또한 `self` 가 내부 노드 인 경우 일치하는 자식 노드에서 검색을 계속하는 데 사용할 하한을 반환합니다.
    ///
    ///
    /// 결과는 트리가 키로 정렬 된 경우에만 의미가 있습니다.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// 상한에 대한 `find_lower_bound_index` 의 복제.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}