use core::marker::PhantomData;
use core::ptr::NonNull;

/// 재차 용 및 모든 하위 항목 (즉, 여기에서 파생 된 모든 포인터 및 참조)이 더 이상 사용되지 않는다는 것을 알고있는 경우 일부 고유 참조의 재차 용을 모델링 한 후 원래 고유 참조를 다시 사용하려는 경우 .
///
///
/// 일반적으로 차용 검사기는이 차용 스택을 처리하지만이 스택을 수행하는 일부 제어 흐름은 컴파일러가 따르기에는 너무 복잡합니다.
/// `DormantMutRef` 를 사용하면 스택 특성을 표현하고 정의되지 않은 동작없이이를 수행하는 데 필요한 원시 포인터 코드를 캡슐화하면서 자신을 빌리는 것을 확인할 수 있습니다.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// 고유 한 차용을 캡처하고 즉시 다시 차용하십시오.
    /// 컴파일러의 경우 새 참조의 수명은 원래 참조의 수명과 동일하지만 promise 는 더 짧은 기간 동안 사용하도록합니다.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // 안전: 우리는 `_marker` 를 통해 'a 전체에 걸쳐 차용을 보류하고
        // 이 참조 만 있으므로 고유합니다.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// 처음에 캡처 한 고유 한 차용으로 되돌립니다.
    ///
    /// # Safety
    ///
    /// 재차 용이 종료되어야합니다. 즉, `new` 에 의해 반환 된 참조와 여기에서 파생 된 모든 포인터 및 참조는 더 이상 사용되지 않아야합니다.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // 안전: 자체 안전 조건은이 참조가 다시 고유하다는 것을 의미합니다.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;