use core::intrinsics;
use core::mem;
use core::ptr;

/// 이것은 관련 함수를 호출하여 `v` 고유 참조 뒤에있는 값을 대체합니다.
///
///
/// `change` 클로저에서 panic 가 발생하면 전체 프로세스가 중단됩니다.
#[allow(dead_code)] // 그림으로 유지하고 future 용으로 사용
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// 이는 관련 함수를 호출하여 `v` 고유 참조 뒤에있는 값을 대체하고 그 과정에서 얻은 결과를 반환합니다.
///
///
/// `change` 클로저에서 panic 가 발생하면 전체 프로세스가 중단됩니다.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}