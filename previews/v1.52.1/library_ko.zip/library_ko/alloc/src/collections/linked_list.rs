//! 소유 노드가있는 이중 연결 목록입니다.
//!
//! `LinkedList` 는 일정한 시간에 양쪽 끝에서 요소를 밀고 터뜨릴 수 있습니다.
//!
//! NOTE: 배열 기반 컨테이너는 일반적으로 더 빠르고 메모리 효율성이 높으며 CPU 캐시를 더 잘 사용하기 때문에 [`Vec`] 또는 [`VecDeque`] 를 사용하는 것이 거의 항상 더 좋습니다.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// 소유 노드가있는 이중 연결 목록입니다.
///
/// `LinkedList` 는 일정한 시간에 양쪽 끝에서 요소를 밀고 터뜨릴 수 있습니다.
///
/// NOTE: 배열 기반 컨테이너는 일반적으로 더 빠르고 메모리 효율성이 높으며 CPU 캐시를 더 잘 사용하기 때문에 `Vec` 또는 `VecDeque` 를 사용하는 것이 거의 항상 더 좋습니다.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// `LinkedList` 의 요소에 대한 반복기입니다.
///
/// 이 `struct` 는 [`LinkedList::iter()`] 에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` 를 위해 제거
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// `LinkedList` 의 요소에 대한 변경 가능한 반복기입니다.
///
/// 이 `struct` 는 [`LinkedList::iter_mut()`] 에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // 우리는 여기에서 전체 목록을 독점적으로 소유하지 *않습니다*. 노드의 `element` 에 대한 참조는 반복자에 의해 전달되었습니다!따라서 이것을 사용할 때주의하십시오.호출 된 메소드는 `element` 에 대한 앨리어싱 포인터가있을 수 있음을 인식해야합니다.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// `LinkedList` 의 요소에 대한 소유 반복기입니다.
///
/// 이 `struct` 는 [`LinkedList`] (`IntoIterator` trait 에서 제공)의 [`into_iter`] 방법으로 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// 개인 방법
impl<T> LinkedList<T> {
    /// 주어진 노드를 목록의 맨 앞에 추가합니다.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // 이 메서드는 `element` 에 대한 앨리어싱 포인터의 유효성을 유지하기 위해 전체 노드에 대한 변경 가능한 참조를 만들지 않도록주의합니다.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // `element` 와 겹치는 새로운 가변 (unique!) 참조를 생성하지 않습니다.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// 목록 맨 앞에있는 노드를 제거하고 반환합니다.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // 이 메서드는 `element` 에 대한 앨리어싱 포인터의 유효성을 유지하기 위해 전체 노드에 대한 변경 가능한 참조를 만들지 않도록주의합니다.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // `element` 와 겹치는 새로운 가변 (unique!) 참조를 생성하지 않습니다.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// 목록 뒤에 주어진 노드를 추가합니다.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // 이 메서드는 `element` 에 대한 앨리어싱 포인터의 유효성을 유지하기 위해 전체 노드에 대한 변경 가능한 참조를 만들지 않도록주의합니다.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // `element` 와 겹치는 새로운 가변 (unique!) 참조를 생성하지 않습니다.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// 목록 뒤에있는 노드를 제거하고 반환합니다.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // 이 메서드는 `element` 에 대한 앨리어싱 포인터의 유효성을 유지하기 위해 전체 노드에 대한 변경 가능한 참조를 만들지 않도록주의합니다.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // `element` 와 겹치는 새로운 가변 (unique!) 참조를 생성하지 않습니다.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// 현재 목록에서 지정된 노드의 링크를 해제합니다.
    ///
    /// 경고: 제공된 노드가 현재 목록에 속하는지 확인하지 않습니다.
    ///
    /// 이 메서드는 앨리어싱 포인터의 유효성을 유지하기 위해 `element` 에 대한 변경 가능한 참조를 만들지 않도록주의합니다.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // 이것은 이제 우리 것입니다. 우리는 &mut 를 만들 수 있습니다.

        // `element` 와 겹치는 새로운 가변 (unique!) 참조를 생성하지 않습니다.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // 이 노드는 헤드 노드입니다.
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // 이 노드는 꼬리 노드입니다
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// 두 개의 기존 노드 사이에 일련의 노드를 연결합니다.
    ///
    /// 경고: 제공된 노드가 두 개의 기존 목록에 속하는지 확인하지 않습니다.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // 이 메서드는 `element` 에 대한 앨리어싱 포인터의 유효성을 유지하기 위해 전체 노드에 대한 여러 가변 참조를 동시에 만들지 않도록주의합니다.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// 연결된 목록에서 모든 노드를 일련의 노드로 분리합니다.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // 분할 노드는 두 번째 부분의 새 헤드 노드입니다.
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // 두 번째 부분의 머리 부분 수정
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // 분할 노드는 첫 번째 부분의 새 꼬리 노드이며 두 번째 부분의 머리를 소유합니다.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // 첫 번째 부분의 꼬리 ptr 수정
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// 빈 `LinkedList<T>` 를 만듭니다.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// 빈 `LinkedList` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// `other` 의 모든 요소를 목록의 끝으로 이동합니다.
    ///
    /// 이것은 `other` 의 모든 노드를 재사용하고 `self` 로 이동합니다.
    /// 이 작업 후 `other` 는 비워집니다.
    ///
    /// 이 연산은 *O*(1) 시간 및 *O*(1) 메모리에서 계산해야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` 두 목록 전체에 독점적으로 액세스 할 수 있기 때문에 여기서는 괜찮습니다.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// `other` 의 모든 요소를 목록의 시작 부분으로 이동합니다.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` 두 목록 전체에 독점적으로 액세스 할 수 있기 때문에 여기서는 괜찮습니다.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// 순방향 반복기를 제공합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// 변경 가능한 참조가있는 순방향 반복기를 제공합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// 앞 요소에 커서를 제공합니다.
    ///
    /// 목록이 비어 있으면 커서는 "ghost" 요소가 아닌 요소를 가리 킵니다.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// 전면 요소에서 편집 작업과 함께 커서를 제공합니다.
    ///
    /// 목록이 비어 있으면 커서는 "ghost" 요소가 아닌 요소를 가리 킵니다.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// 뒤쪽 요소에 커서를 제공합니다.
    ///
    /// 목록이 비어 있으면 커서는 "ghost" 요소가 아닌 요소를 가리 킵니다.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// 뒤쪽 요소에서 편집 작업과 함께 커서를 제공합니다.
    ///
    /// 목록이 비어 있으면 커서는 "ghost" 요소가 아닌 요소를 가리 킵니다.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// `LinkedList` 가 비어 있으면 `true` 를 반환합니다.
    ///
    /// 이 연산은 *O*(1) 시간에 계산되어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList` 의 길이를 반환합니다.
    ///
    /// 이 연산은 *O*(1) 시간에 계산되어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList` 에서 모든 요소를 제거합니다.
    ///
    /// 이 연산은 *O*(*n*) 시간에 계산되어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// `LinkedList` 에 주어진 값과 같은 요소가 포함 된 경우 `true` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// 전면 요소에 대한 참조를 제공하거나 목록이 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// 전면 요소에 대한 변경 가능한 참조를 제공하거나 목록이 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// back 요소에 대한 참조를 제공하거나 목록이 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// back 요소에 대한 변경 가능한 참조를 제공하거나 목록이 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// 목록에서 먼저 요소를 추가합니다.
    ///
    /// 이 연산은 *O*(1) 시간에 계산되어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// 첫 번째 요소를 제거하고 반환하거나 목록이 비어있는 경우 `None` 를 반환합니다.
    ///
    ///
    /// 이 연산은 *O*(1) 시간에 계산되어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// 목록 뒤에 요소를 추가합니다.
    ///
    /// 이 연산은 *O*(1) 시간에 계산되어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// 목록에서 마지막 요소를 제거하고 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    ///
    /// 이 연산은 *O*(1) 시간에 계산되어야합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// 주어진 색인에서 목록을 두 개로 분할합니다.
    /// 인덱스를 포함하여 주어진 인덱스 뒤의 모든 것을 반환합니다.
    ///
    /// 이 연산은 *O*(*n*) 시간에 계산되어야합니다.
    ///
    /// # Panics
    ///
    /// `at > len` 인 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // 아래에서 우리는 어느 쪽이 더 빠를 것인지에 따라 시작 또는 끝에서`i-1` 번째 노드를 향해 반복합니다.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() (새 구조체 생성)를 사용하여 건너 뛰는 대신 Skip의 구현 세부 정보에 의존하지 않고 헤드 필드에 액세스 할 수 있도록 수동으로 건너 뜁니다.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // 끝에서 시작하는 것이 좋습니다
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// 지정된 인덱스에서 요소를 제거하고 반환합니다.
    ///
    /// 이 연산은 *O*(*n*) 시간에 계산되어야합니다.
    ///
    /// # Panics
    /// Panics if at>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // 아래에서 우리는 어느 쪽이 더 빠를 지에 따라 시작 또는 끝에서 주어진 인덱스의 노드를 향해 반복합니다.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// 요소를 제거해야하는지 결정하기 위해 클로저를 사용하는 반복자를 만듭니다.
    ///
    /// 클로저가 true를 반환하면 요소가 제거되고 양보됩니다.
    /// 클로저가 false를 반환하면 요소는 목록에 남아 있고 반복기에 의해 생성되지 않습니다.
    ///
    /// `drain_filter` 를 사용하면 필터 클로저의 모든 요소를 유지하거나 제거할지 여부에 관계없이 변경할 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// 목록을 짝수와 확률로 분할하고 원래 목록을 재사용합니다.
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // 차용 문제를 피하십시오.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // 아래에서 수행하는 것과 동일한 루프를 계속하십시오.소멸자가 당황했을 때만 실행됩니다.
                // 다른 panics 가 있으면 중단됩니다.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'a를 얻으려면 언 바운드 평생이 필요
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'a를 얻으려면 언 바운드 평생이 필요
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'a를 얻으려면 언 바운드 평생이 필요
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'a를 얻으려면 언 바운드 평생이 필요
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// `LinkedList` 위에 커서가 있습니다.
///
/// `Cursor` 는 자유롭게 앞뒤로 검색 할 수 있다는 점을 제외하면 반복기와 같습니다.
///
/// 커서는 항상 목록의 두 요소 사이에 있으며 논리적으로 순환 방식으로 인덱싱됩니다.
/// 이를 수용하기 위해 목록의 머리와 꼬리 사이에 `None` 를 산출하는 "ghost" 비 요소가 있습니다.
///
///
/// 생성 될 때 커서는 목록의 맨 앞에서 시작하거나 목록이 비어있는 경우 "ghost" 비 요소에서 시작합니다.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// 편집 작업이있는 `LinkedList` 위에 커서가 있습니다.
///
/// `Cursor` 는 자유롭게 앞뒤로 검색 할 수 있고 반복 중에 목록을 안전하게 변경할 수 있다는 점을 제외하면 반복기와 비슷합니다.
/// 이는 생성 된 참조의 수명이 기본 목록이 아닌 자체 수명에 연결되어 있기 때문입니다.
/// 이는 커서가 한 번에 여러 요소를 생성 할 수 없음을 의미합니다.
///
/// 커서는 항상 목록의 두 요소 사이에 있으며 논리적으로 순환 방식으로 인덱싱됩니다.
/// 이를 수용하기 위해 목록의 머리와 꼬리 사이에 `None` 를 산출하는 "ghost" 비 요소가 있습니다.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList` 내의 커서 위치 인덱스를 반환합니다.
    ///
    /// 커서가 현재 "ghost" 비 요소를 가리키고있는 경우 `None` 를 반환합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` 의 다음 요소로 커서를 이동합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 커서가 `LinkedList` 의 첫 번째 요소로 이동합니다.
    /// `LinkedList` 의 마지막 요소를 가리키는 경우 "ghost" 비 요소로 이동합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // 현재 요소가 없었습니다.커서가 시작 위치에있었습니다. 다음 요소는 목록의 맨 위에 있어야합니다.
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // 이전 요소가 있었으므로 다음으로 이동하겠습니다.
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` 의 이전 요소로 커서를 이동합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 `LinkedList` 의 마지막 요소로 이동합니다.
    /// `LinkedList` 의 첫 번째 요소를 가리키는 경우 "ghost" 비 요소로 이동합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // 전류가 없습니다.우리는 목록의 시작 부분에 있습니다.없음을 양보하고 끝으로 점프합니다.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // prev.그것을 양보하고 이전 요소로 이동하십시오.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// 커서가 현재 가리키고있는 요소에 대한 참조를 반환합니다.
    ///
    /// 커서가 현재 "ghost" 비 요소를 가리키고있는 경우 `None` 를 반환합니다.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// 다음 요소에 대한 참조를 반환합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 `LinkedList` 의 첫 번째 요소를 반환합니다.
    /// `LinkedList` 의 마지막 요소를 가리키는 경우 `None` 를 반환합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// 이전 요소에 대한 참조를 반환합니다.
    ///
    /// 커서가 "ghost" 비 요소를 가리키면 `LinkedList` 의 마지막 요소를 반환합니다.
    /// `LinkedList` 의 첫 번째 요소를 가리키는 경우 `None` 를 반환합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList` 내의 커서 위치 인덱스를 반환합니다.
    ///
    /// 커서가 현재 "ghost" 비 요소를 가리키고있는 경우 `None` 를 반환합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList` 의 다음 요소로 커서를 이동합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 커서가 `LinkedList` 의 첫 번째 요소로 이동합니다.
    /// `LinkedList` 의 마지막 요소를 가리키는 경우 "ghost" 비 요소로 이동합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // 현재 요소가 없었습니다.커서가 시작 위치에있었습니다. 다음 요소는 목록의 맨 위에 있어야합니다.
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // 이전 요소가 있었으므로 다음으로 이동하겠습니다.
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList` 의 이전 요소로 커서를 이동합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 `LinkedList` 의 마지막 요소로 이동합니다.
    /// `LinkedList` 의 첫 번째 요소를 가리키는 경우 "ghost" 비 요소로 이동합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // 전류가 없습니다.우리는 목록의 시작 부분에 있습니다.없음을 양보하고 끝으로 점프합니다.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // prev.그것을 양보하고 이전 요소로 이동하십시오.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// 커서가 현재 가리키고있는 요소에 대한 참조를 반환합니다.
    ///
    /// 커서가 현재 "ghost" 비 요소를 가리키고있는 경우 `None` 를 반환합니다.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// 다음 요소에 대한 참조를 반환합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 `LinkedList` 의 첫 번째 요소를 반환합니다.
    /// `LinkedList` 의 마지막 요소를 가리키는 경우 `None` 를 반환합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// 이전 요소에 대한 참조를 반환합니다.
    ///
    /// 커서가 "ghost" 비 요소를 가리키면 `LinkedList` 의 마지막 요소를 반환합니다.
    /// `LinkedList` 의 첫 번째 요소를 가리키는 경우 `None` 를 반환합니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// 현재 요소를 가리키는 읽기 전용 커서를 반환합니다.
    ///
    /// 반환 된 `Cursor` 의 수명은 `CursorMut` 의 수명에 바인딩되어 있습니다. 즉, `CursorMut` 보다 오래 살 수 없으며 `Cursor` 의 수명 동안 `CursorMut` 가 고정됩니다.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// 이제 목록 편집 작업

impl<'a, T> CursorMut<'a, T> {
    /// 현재 요소 뒤에 새 요소를 `LinkedList` 에 삽입합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 새 요소가 `LinkedList` 앞에 삽입됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" 요소가 아닌 색인이 변경되었습니다.
                self.index = self.list.len;
            }
        }
    }

    /// 현재 요소 앞에 새 요소를 `LinkedList` 에 삽입합니다.
    ///
    /// 커서가 "ghost" 요소가 아닌 요소를 가리키면 새 요소가 `LinkedList` 끝에 삽입됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList` 에서 현재 요소를 제거합니다.
    ///
    /// 제거 된 요소가 반환되고 커서가 `LinkedList` 의 다음 요소를 가리 키도록 이동됩니다.
    ///
    ///
    /// 커서가 현재 "ghost" 요소가 아닌 요소를 가리키고있는 경우 요소가 제거되지 않고 `None` 가 반환됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// 목록 노드를 할당 해제하지 않고 `LinkedList` 에서 현재 요소를 제거합니다.
    ///
    /// 제거 된 노드는이 노드 만 포함하는 새 `LinkedList` 로 반환됩니다.
    /// 커서가 현재 `LinkedList` 의 다음 요소를 가리 키도록 이동합니다.
    ///
    /// 커서가 현재 "ghost" 요소가 아닌 요소를 가리키고있는 경우 요소가 제거되지 않고 `None` 가 반환됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// 주어진 `LinkedList` 의 요소를 현재 요소 뒤에 삽입합니다.
    ///
    /// 커서가 "ghost" 비 요소를 가리키면 새 요소가 `LinkedList` 의 시작 부분에 삽입됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" 요소가 아닌 색인이 변경되었습니다.
                self.index = self.list.len;
            }
        }
    }

    /// 주어진 `LinkedList` 의 요소를 현재 요소 앞에 삽입합니다.
    ///
    /// 커서가 "ghost" 비 요소를 가리키면 새 요소가 `LinkedList` 끝에 삽입됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// 현재 요소 뒤에서 목록을 두 개로 분할합니다.
    /// 이렇게하면 커서 뒤의 모든 항목으로 구성된 새 목록이 반환되며 원래 목록은 이전의 모든 항목을 유지합니다.
    ///
    ///
    /// 커서가 "ghost" 비 요소를 가리키면 `LinkedList` 의 전체 내용이 이동됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" 요소가 아닌 색인이 0으로 변경되었습니다.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// 현재 요소 앞에 목록을 두 개로 분할합니다.
    /// 그러면 커서 앞의 모든 항목으로 구성된 새 목록이 반환되며 원래 목록은 이후의 모든 항목을 유지합니다.
    ///
    ///
    /// 커서가 "ghost" 비 요소를 가리키면 `LinkedList` 의 전체 내용이 이동됩니다.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// LinkedList에서 `drain_filter` 를 호출하여 생성 된 반복기입니다.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` `element` 참조 앨리어싱은 괜찮습니다.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// 값으로 요소를 생성하는 반복기로 목록을 소비합니다.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// `LinkedList` 및 읽기 전용 반복기가 해당 유형 매개 변수에서 공변하는지 확인하십시오.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}