//! 확장 가능한 링 버퍼로 구현 된 양단 대기열.
//!
//! 이 대기열에는 컨테이너의 양쪽 끝에서 *O*(1) 분할 된 삽입 및 제거가 있습니다.
//! 또한 vector 와 같은 *O*(1) 인덱싱이 있습니다.
//! 포함 된 요소는 복사 가능할 필요가 없으며 포함 된 유형이 전송 가능한 경우 큐를 전송할 수 있습니다.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // 2의 최대 제곱

/// 확장 가능한 링 버퍼로 구현 된 양단 대기열.
///
/// 이 유형의 "default" 를 대기열로 사용하는 것은 [`push_back`] 를 사용하여 대기열에 추가하고 [`pop_front`] 를 사용하여 대기열에서 제거하는 것입니다.
///
/// [`extend`] [`append`] 는 이런 방식으로 뒤로 밀고 `VecDeque` 를 반복하면 앞뒤로 이동합니다.
///
/// `VecDeque` 는 링 버퍼이므로 해당 요소가 메모리에서 반드시 연속적인 것은 아닙니다.
/// 효율적인 정렬과 같이 단일 슬라이스로 요소에 액세스하려는 경우 [`make_contiguous`] 를 사용할 수 있습니다.
/// 요소가 래핑되지 않도록 `VecDeque` 를 회전하고 이제 인접한 요소 시퀀스에 가변 슬라이스를 반환합니다.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // 꼬리와 머리는 버퍼에 대한 포인터입니다.
    // Tail은 항상 읽을 수있는 첫 번째 요소를 가리키고 Head는 항상 데이터를 기록해야하는 위치를 가리 킵니다.
    //
    // tail==head이면 버퍼가 비어 있습니다.링 버퍼의 길이는 둘 사이의 거리로 정의됩니다.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// 슬라이스가 떨어질 때 (일반적으로 또는 해제하는 동안) 슬라이스의 모든 항목에 대해 소멸자를 실행합니다.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] 에 드롭 사용
            ptr::drop_in_place(front);
        }
        // RawVec은 할당 해제를 처리합니다.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// 빈 `VecDeque<T>` 를 만듭니다.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// 조금 더 편리함
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// 조금 더 편리함
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // 크기가 0 인 유형의 경우 항상 최대 용량에 있습니다.
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// ptr을 조각으로 바꾸기
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// ptr을 mut 슬라이스로 변환
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// 요소를 버퍼 밖으로 이동합니다.
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// 요소를 버퍼에 쓰고 이동합니다.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// 버퍼가 최대 용량이면 `true` 를 반환합니다.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// 주어진 논리적 요소 인덱스에 대한 기본 버퍼의 인덱스를 반환합니다.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// 주어진 논리 요소 인덱스 + 추가에 대한 기본 버퍼의 인덱스를 반환합니다.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// 주어진 논리적 요소 인덱스 subtrahend에 대한 기본 버퍼의 인덱스를 반환합니다.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src 에서 dst로 길이가 긴 메모리의 연속 블록을 복사합니다.
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src 에서 dst로 길이가 긴 메모리의 연속 블록을 복사합니다.
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// 잠재적으로 래핑 된 메모리 len long 블록을 src 에서 dest로 복사합니다.
    /// (abs(dst - src) + len)은 cap() 보다 크지 않아야합니다 (src 와 dest 사이에 하나의 연속 중첩 영역이 있어야 함).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src 는 래핑하지 않고 dst는 래핑하지 않습니다.
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src 이전의 dst, src 는 랩핑하지 않음, dst 랩핑
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // dst 이전의 src, src 는 랩핑하지 않음, dst 랩핑
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // src 전 dst, src 랩핑, dst 랩핑 안 함
                //
                //
                //    .. 에스.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // dst 전 src, src 랩핑, dst 랩핑 안 함
                //
                //
                //    .. 에스.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst, src, src 랩, dst 랩
                //
                //
                //    ... 에스.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // dst 이전 src, src 랩, dst 랩
                //
                //
                //    .. 에스..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... 디.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// 우리가 방금 재 할당했다는 사실을 처리하기 위해 머리와 꼬리 부분을 둘러 쌉니다.
    /// old_capacity를 신뢰하므로 안전하지 않습니다.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // 링 버퍼 TH의 가장 짧은 연속 섹션 이동
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // 아니
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// 빈 `VecDeque` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// 최소 `capacity` 요소를위한 공간이있는 빈 `VecDeque` 를 만듭니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // 링 버퍼는 항상 하나의 공간을 비워두기 때문에 +1
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// 지정된 인덱스의 요소에 대한 참조를 제공합니다.
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// 지정된 인덱스의 요소에 대한 변경 가능한 참조를 제공합니다.
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// 인덱스 `i` 및 `j` 에서 요소를 바꿉니다.
    ///
    /// `i` `j` 는 같을 수 있습니다.
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Panics
    ///
    /// 인덱스 중 하나가 범위를 벗어난 경우 Panics 입니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// 재할 당하지 않고 `VecDeque` 가 보유 할 수있는 요소 수를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// 지정된 `VecDeque` 에 삽입 할 요소를 정확히 `additional` 개 이상에 대한 최소 용량을 예약합니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// 할당자는 요청한 것보다 더 많은 공간을 컬렉션에 제공 할 수 있습니다.
    /// 따라서 용량을 정확하게 최소화 할 수 없습니다.
    /// future 삽입이 예상되는 경우 [`reserve`] 를 선호합니다.
    ///
    /// # Panics
    ///
    /// Panics 새 용량이 `usize` 를 초과하는 경우.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// 주어진 `VecDeque` 에 삽입 할 최소 `additional` 이상의 요소에 대한 용량을 예약합니다.
    /// 컬렉션은 빈번한 재 할당을 피하기 위해 더 많은 공간을 예약 할 수 있습니다.
    ///
    /// # Panics
    ///
    /// Panics 새 용량이 `usize` 를 초과하는 경우.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// 주어진 `VecDeque<T>` 에 정확히 `additional` 더 많은 요소가 삽입되도록 최소 용량을 예약하려고합니다.
    ///
    /// `try_reserve_exact` 를 호출하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// 할당자는 요청한 것보다 더 많은 공간을 컬렉션에 제공 할 수 있습니다.
    /// 따라서 용량을 정확하게 최소화 할 수 없습니다.
    /// future 삽입이 예상되는 경우 `reserve` 를 선호합니다.
    ///
    /// # Errors
    ///
    /// 용량이 `usize` 를 초과하거나 할당자가 오류를보고하면 오류가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // 메모리를 미리 예약하고, 할 수 없으면 종료합니다.
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // 이제 우리는 복잡한 작업 중에 OOM(Out-Of-Memory) 를 할 수 없다는 것을 알고 있습니다.
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // 매우 복잡한
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// 주어진 `VecDeque<T>` 에 삽입 할 최소 `additional` 이상의 요소에 대한 용량을 예약하려고합니다.
    /// 컬렉션은 빈번한 재 할당을 피하기 위해 더 많은 공간을 예약 할 수 있습니다.
    /// `try_reserve` 를 호출하면 용량이 `self.len() + additional` 보다 크거나 같습니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// # Errors
    ///
    /// 용량이 `usize` 를 초과하거나 할당자가 오류를보고하면 오류가 반환됩니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // 메모리를 미리 예약하고, 할 수 없으면 종료합니다.
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 이제 우리는 복잡한 작업 중에 이것이 OOM이 불가능하다는 것을 알고 있습니다.
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // 매우 복잡한
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` 의 용량을 최대한 줄입니다.
    ///
    /// 가능한 한 길이에 가깝게 드롭되지만 할당자는 여전히 몇 가지 요소를위한 공간이 있음을 `VecDeque` 에 알릴 수 있습니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// 하한으로 `VecDeque` 의 용량을 줄입니다.
    ///
    /// 용량은 최소한 길이와 제공된 값만큼 크게 유지됩니다.
    ///
    ///
    /// 현재 용량이 하한보다 작 으면 작동하지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // `self.len()` 도 `self.capacity()` 도 `usize::MAX` 가 될 수 없으므로 오버플로에 대해 걱정할 필요가 없습니다.
        // 링 버퍼가 항상 하나의 공간을 비워두기 때문에 +1.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // 세 가지 관심 사례가 있습니다.
            //   모든 요소가 원하는 범위를 벗어남 요소가 연속적이며 머리가 원하는 범위를 벗어남 요소가 불 연속적이며 꼬리가 원하는 범위를 벗어남
            //
            //
            // 다른 모든 경우에는 요소 위치가 영향을받지 않습니다.
            //
            // 헤드의 요소를 이동해야 함을 나타냅니다.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // 원하는 범위를 벗어난 요소 이동 (target_cap 뒤의 위치)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` 를 줄여 첫 번째 `len` 요소는 유지하고 나머지는 삭제합니다.
    ///
    ///
    /// `len` 가`VecDeque`의 현재 길이보다 크면 아무 효과가 없습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// 슬라이스가 떨어질 때 (일반적으로 또는 해제하는 동안) 슬라이스의 모든 항목에 대해 소멸자를 실행합니다.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // 안전한 이유 :
        //
        // * `drop_in_place` 에 전달 된 모든 슬라이스가 유효합니다.두 번째 케이스에는 `len <= front.len()` 가 있고 `len > self.len()` 로 돌아 가면 첫 번째 케이스에서 `begin <= back.len()` 가 보장됩니다.
        //
        // * VecDeque의 헤드는 `drop_in_place` 를 호출하기 전에 이동하므로 `drop_in_place` panics 인 경우 값이 두 번 삭제되지 않습니다.
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // 첫 번째 panics 의 소멸자가있는 경우에도 후반부가 삭제되었는지 확인합니다.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// 앞뒤 반복기를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// 가변 참조를 반환하는 앞뒤 반복기를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // 안전: 내부 `IterMut` 안전 불변이 설정됩니다.
        // `ring` 우리가 생성하는 것은 수명 '_'에 대한 역 참조 가능 슬라이스입니다.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` 의 내용을 순서대로 포함하는 슬라이스 쌍을 반환합니다.
    ///
    /// [`make_contiguous`] 가 이전에 호출 된 경우 `VecDeque` 의 모든 요소는 첫 번째 슬라이스에 있고 두 번째 슬라이스는 비어 있습니다.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque` 의 내용을 순서대로 포함하는 슬라이스 쌍을 반환합니다.
    ///
    /// [`make_contiguous`] 가 이전에 호출 된 경우 `VecDeque` 의 모든 요소는 첫 번째 슬라이스에 있고 두 번째 슬라이스는 비어 있습니다.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` 의 요소 수를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `VecDeque` 가 비어 있으면 `true` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque` 에서 지정된 범위를 포함하는 반복기를 만듭니다.
    ///
    /// # Panics
    ///
    /// 시작점이 끝점보다 크거나 끝 점이 vector 의 길이보다 큰 경우 Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // 전체 범위는 모든 내용을 포함합니다.
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self 에있는 공유 참조는 '_ of Iter'에서 유지됩니다.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque` 에서 지정된 변경 가능 범위를 포함하는 반복기를 만듭니다.
    ///
    /// # Panics
    ///
    /// 시작점이 끝점보다 크거나 끝 점이 vector 의 길이보다 큰 경우 Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // 전체 범위는 모든 내용을 포함합니다.
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // 안전: 내부 `IterMut` 안전 불변이 설정됩니다.
        // `ring` 우리가 생성하는 것은 수명 '_'에 대한 역 참조 가능 슬라이스입니다.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque` 에서 지정된 범위를 제거하고 제거 된 항목을 생성하는 드레 이닝 반복기를 만듭니다.
    ///
    /// 참고 1: 끝까지 반복기가 사용되지 않더라도 요소 범위는 제거됩니다.
    ///
    /// 참고 2: `Drain` 값이 삭제되지 않은 경우 데크에서 제거되는 요소의 수는 지정되지 않지만 보유한 차용이 만료됩니다 (예: `mem::forget` 로 인해).
    ///
    ///
    /// # Panics
    ///
    /// 시작점이 끝점보다 크거나 끝 점이 vector 의 길이보다 큰 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // 전체 범위는 모든 내용을 지 웁니다.
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // 메모리 안전성
        //
        // Drain 가 처음 생성 될 때 Drain 의 소멸자가 실행되지 않는 경우 초기화되지 않거나 이동 된 요소에 액세스 할 수 없도록 소스 데크가 단축됩니다.
        //
        //
        // Drain 는 제거 할 값을 ptr::read 합니다.
        // 완료되면 나머지 데이터가 다시 복사되어 구멍을 덮고 head/tail 값이 올바르게 복원됩니다.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // 데크의 요소는 세 부분으로 나뉩니다.
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // drain_tail 를 self.head 로 저장하고 drain_head 및 self.head 를 Drain 에서 각각 after_tail 및 after_head로 저장합니다.
        // 이것은 또한 Drain 가 누출 된 경우 drain 가 시작된 후 잠재적으로 이동 된 값에 대해 잊어 버리도록 유효 배열을 자릅니다.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain 시작 후 drain 가 완료되고 Drain 소멸자가 실행될 때까지의 값에 대한 정보입니다.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // 결정적으로, 우리는 여기서 `self` 에서 공유 참조를 만들고 읽습니다.
                // 우리는 `self` 에 쓰거나 변경 가능한 참조에 다시 빌리지 않습니다.
                // 따라서 `deque` 에 대해 위에서 만든 원시 포인터는 계속 유효합니다.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// `VecDeque` 를 지우고 모든 값을 제거합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// `VecDeque` 에 주어진 값과 같은 요소가 포함 된 경우 `true` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// 앞 요소에 대한 참조를 제공하거나 `VecDeque` 가 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// 앞 요소에 대한 변경 가능한 참조를 제공하거나 `VecDeque` 가 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// back 요소에 대한 참조를 제공하거나 `VecDeque` 가 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// back 요소에 대한 가변 참조를 제공하거나 `VecDeque` 가 비어있는 경우 `None` 를 제공합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// 첫 번째 요소를 제거하고 반환하거나 `VecDeque` 가 비어있는 경우 `None` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` 에서 마지막 요소를 제거하고 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` 앞에 요소를 추가합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` 뒷면에 요소를 추가합니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: `head == 0` 를
        // `self` 가 연속적입니까?
        self.tail <= self.head
    }

    /// `VecDeque` 의 모든 위치에서 요소를 제거하고 반환하여 첫 번째 요소로 바꿉니다.
    ///
    ///
    /// 이것은 순서를 유지하지 않지만 *O*(1)입니다.
    ///
    /// `index` 가 범위를 벗어난 경우 `None` 를 반환합니다.
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` 의 모든 위치에서 요소를 제거하고 반환하여 마지막 요소로 바꿉니다.
    ///
    ///
    /// 이것은 순서를 유지하지 않지만 *O*(1)입니다.
    ///
    /// `index` 가 범위를 벗어난 경우 `None` 를 반환합니다.
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` 내의 `index` 에 요소를 삽입하여 인덱스가 `index` 보다 크거나 같은 모든 요소를 뒤쪽으로 이동합니다.
    ///
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Panics
    ///
    /// `index` 가`VecDeque`의 길이보다 큰 경우 Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // 링 버퍼에서 가장 적은 수의 요소를 이동하고 주어진 객체를 삽입합니다.
        //
        // 최대 len/2, 1 개의 요소가 이동됩니다. O(min(n, n-i))
        //
        // 세 가지 주요 사례가 있습니다.
        //  요소는 연속적입니다.
        //      - 꼬리가 0 일 때 특수한 경우 요소가 불연속적이고 삽입물이 꼬리 부분에 있음 요소가 불연속적이고 삽입물이 머리 부분에 있음
        //
        //
        // 각각에 대해 두 가지 사례가 더 있습니다.
        //  인서트가 꼬리에 더 가깝습니다 인서트가 머리에 더 가깝습니다
        //
        // 키: H, self.head
        //      T, self.tail o, 유효한 요소 I, 삽입 요소 A, 삽입 지점 M 뒤에 있어야하는 요소, 요소가 이동되었음을 나타냅니다.
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [오우.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // 연속, 꼬리에 더 가깝게 삽입 :
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // 연속, 꼬리에 더 가깝게 삽입하고 꼬리는 0입니다.
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // 이미 꼬리를 이동 했으므로 `index - 1` 요소 만 복사합니다.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // 연속, 머리에 더 가깝게 삽입 :
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // 불연속, 꼬리에 더 가깝게 삽입, 꼬리 섹션 :
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // 불연속, 머리 가까이에 삽입, 꼬리 부분 :
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // 새 헤드까지 요소 복사
                    self.copy(1, 0, self.head);

                    // 마지막 요소를 버퍼 하단의 빈 자리에 복사
                    self.copy(0, self.cap() - 1, 1);

                    // ^ 요소를 포함하지 않고 요소를 idx에서 앞으로 끝으로 이동
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // 불연속, 삽입은 꼬리, 머리 부분에 더 가깝고 내부 버퍼의 인덱스 0에 있습니다.
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // 새 꼬리까지 요소 복사
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // 마지막 요소를 버퍼 하단의 빈 자리에 복사
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // 불연속, 꼬리에 더 가깝게 삽입, 머리 부분 :
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // 새 꼬리까지 요소 복사
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // 마지막 요소를 버퍼 하단의 빈 자리에 복사
                    self.copy(self.cap() - 1, 0, 1);

                    // ^ 요소를 포함하지 않고 idx-1 에서 앞으로 끝까지 요소 이동
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // 불연속, 머리 가까이 삽입, 머리 부분 :
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // 꼬리가 변경되었을 수 있으므로 다시 계산해야합니다.
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` 에서 `index` 의 요소를 제거하고 반환합니다.
    /// 제거 지점에 더 가까운 쪽이 공간을 확보하기 위해 이동되고 영향을받는 모든 요소가 새 위치로 이동됩니다.
    ///
    /// `index` 가 범위를 벗어난 경우 `None` 를 반환합니다.
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // 세 가지 주요 사례가 있습니다.
        //  요소는 연속적 요소는 불 연속적이며 제거는 꼬리 섹션에 있습니다. 요소는 불 연속적이며 제거는 헤드 섹션에 있습니다.
        //
        //      - 요소가 기술적으로 연속적이지만 self.head =0 인 특별한 경우
        //
        // 각각에 대해 두 가지 사례가 더 있습니다.
        //  인서트가 꼬리에 더 가깝습니다 인서트가 머리에 더 가깝습니다
        //
        // 키: H, self.head
        //      T, self.tail o, 유효한 요소 x, 제거하도록 표시된 요소 R, 제거중인 요소를 나타냅니다. M, 요소가 이동되었음을 나타냅니다.
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // 연속, 꼬리에 더 가깝게 제거 :
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // 연속, 머리 가까이에서 제거 :
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // 불연속, 꼬리 가까이에서 제거, 꼬리 부분 :
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // 불연속, 머리 가까이에서 제거, 머리 부분 :
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // 불연속, 머리, 꼬리 부분에 더 가깝게 제거 :
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // 또는 유사 불연속, 머리, 꼬리 섹션 옆 제거 :
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // 꼬리 부분에 요소 그리기
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // 언더 플로를 방지합니다.
                    if self.head != 0 {
                        // 첫 번째 요소를 빈 자리에 복사
                        self.copy(self.cap() - 1, 0, 1);

                        // 헤드 섹션의 요소를 뒤로 이동
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // 불연속, 꼬리 가까이 제거, 머리 부분 :
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // idx까지 요소 그리기
                    self.copy(1, 0, idx);

                    // 마지막 요소를 빈 자리에 복사
                    self.copy(0, self.cap() - 1, 1);

                    // 마지막 요소를 제외하고 요소를 꼬리에서 끝으로 앞으로 이동
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// 주어진 인덱스에서 `VecDeque` 를 두 개로 분할합니다.
    ///
    /// 새로 할당 된 `VecDeque` 를 반환합니다.
    /// `self` `[0, at)` 요소를 포함하고 반환 된 `VecDeque` 에는 `[at, len)` 요소가 포함됩니다.
    ///
    /// `self` 의 용량은 변경되지 않습니다.
    ///
    /// 인덱스 0의 요소는 대기열의 맨 앞에 있습니다.
    ///
    /// # Panics
    ///
    /// `at > len` 인 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` 상반기에 있습니다.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // 나머지 절반 만 가져 가세요.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` 후반부에 놓여 있고, 전반부에서 건너 뛴 요소를 고려해야합니다.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // 버퍼의 끝이있는 정리
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` 의 모든 요소를 `self` 로 이동하고 `other` 는 비워 둡니다.
    ///
    /// # Panics
    ///
    /// self의 새로운 요소 수가 `usize` 를 오버플로하는 경우 Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // 순진한 impl
        self.extend(other.drain(..));
    }

    /// 술어로 지정된 요소 만 보유합니다.
    ///
    /// 즉, `f(&e)` 가 false를 반환하도록 모든 요소 `e` 를 제거합니다.
    /// 이 메서드는 제자리에서 작동하여 각 요소를 원래 순서대로 정확히 한 번 방문하고 유지 된 요소의 순서를 유지합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// 정확한 순서는 인덱스와 같은 외부 상태를 추적하는 데 유용 할 수 있습니다.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // panic 또는 중단 할 수 있습니다.
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // 버퍼 크기를 두 배로 늘립니다.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// 뒷면에서 초과 요소를 제거하거나 `generator` 를 호출하여 생성 된 요소를 뒷면에 추가하여 `len()` 가 `new_len` 와 같도록 `VecDeque` 내부를 수정합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// 이 deque의 내부 저장소를 다시 정렬하여 하나의 연속 슬라이스가되도록 한 다음 반환됩니다.
    ///
    /// 이 메서드는 삽입 된 요소의 순서를 할당하거나 변경하지 않습니다.가변 슬라이스를 반환하므로 deque를 정렬하는 데 사용할 수 있습니다.
    ///
    /// 내부 저장소가 연속되면 [`as_slices`] 및 [`as_mut_slices`] 메서드는 `VecDeque` 의 전체 내용을 단일 슬라이스로 반환합니다.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// deque의 내용 정렬.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // 데크 정렬
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // 역순으로 정렬
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// 연속 슬라이스에 대한 변경 불가능한 액세스 권한 얻기.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // 이제 `slice` 에 데크의 모든 요소가 포함되어있는 동시에 `buf` 에 대한 변경 불가능한 액세스 권한이 있음을 확인할 수 있습니다.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // 한 번에 꼬리를 복사 할 수있는 충분한 여유 공간이 있습니다. 즉, 먼저 머리를 뒤로 이동 한 다음 꼬리를 올바른 위치로 복사합니다.
            //
            //
            // 보낸 사람: DEFGH .... ABC
            // 받는 사람: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: 우리는 현재 고려하지 않습니다 .... ABCDEFGH
            // 이 경우 `head` 는 `0` 이기 때문에 연속적입니다.
            // 우리가 이것을 변경하고 싶을 수도 있지만 `is_contiguous` 가 `buf[tail..head]` 를 사용하여 슬라이스 할 수 있음을 의미하는 `is_contiguous` 를 예상하기 때문에 사소한 것은 아닙니다.
            //
            //

            // 한 번에 머리를 복사 할 충분한 여유 공간이 있습니다. 즉, 먼저 꼬리를 앞으로 이동 한 다음 머리를 올바른 위치로 복사합니다.
            //
            //
            // 보낸 사람: FGH .... ABCDE
            // 받는 사람: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // free는 머리와 꼬리보다 작습니다. 즉, 꼬리와 머리를 천천히 "swap" 해야합니다.
            //
            //
            // 출처: EFGHI ... ABCD 또는 HIJK.ABCDEFG
            // to: ABCDEFGHI ... 또는 ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // 일반적인 문제는 다음과 같습니다. GHIJKLM ... ABCDEF, 모든 스왑 ABCDEFM ... GHIJKL, 스왑 1 회 통과 후 ABCDEFGHIJM ... KL, 왼쪽 edge 가 임시 저장소에 도달 할 때까지 스왑
                //                  - 그런 다음 새 (smaller) 저장소로 알고리즘을 다시 시작합니다. 때때로 올바른 edge 가 버퍼의 끝에있을 때 임시 저장소에 도달합니다. 이는 더 적은 스왑으로 올바른 순서에 도달했음을 의미합니다!
                //
                // E.g
                // EF..ABCD ABCDEF .., 네 번만 스왑을 마친 후
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// 이중 종료 대기열 `mid` 를 왼쪽으로 회전합니다.
    ///
    /// Equivalently,
    /// - 항목 `mid` 를 첫 번째 위치로 회전합니다.
    /// - 첫 번째 `mid` 항목을 팝하고 끝으로 밀어냅니다.
    /// - `len() - mid` 자리를 오른쪽으로 회전합니다.
    ///
    /// # Panics
    ///
    /// `mid` 가 `len()` 보다 큰 경우.
    /// `mid == len()` 는 _not_ panic 를 수행하며 작동하지 않는 회전입니다.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` 시간이 걸리고 추가 공간이 없습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// 이중 종료 대기열 `k` 를 오른쪽으로 회전합니다.
    ///
    /// Equivalently,
    /// - 첫 번째 항목을 `k` 위치로 회전합니다.
    /// - 마지막 `k` 항목을 팝하고 앞쪽으로 밉니다.
    /// - `len() - k` 자리를 왼쪽으로 회전합니다.
    ///
    /// # Panics
    ///
    /// `k` 가 `len()` 보다 큰 경우.
    /// `k == len()` 는 _not_ panic 를 수행하며 작동하지 않는 회전입니다.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` 시간이 걸리고 추가 공간이 없습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // 안전: 다음 두 가지 방법은 회전 량이 필요합니다.
    // 데크 길이의 절반 미만이어야합니다.
    //
    // `wrap_copy` `min(x, cap() - x) + copy_len <= cap()` 가 필요하지만 `min` 는 x에 관계없이 용량의 절반 이상이 아니기 때문에 여기에서 호출하는 것이 좋습니다. 길이의 절반 미만으로 전화를 걸기 때문입니다.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// 바이너리는이 정렬 된 `VecDeque` 에서 주어진 요소를 검색합니다.
    ///
    /// 값이 발견되면 일치하는 요소의 색인을 포함하는 [`Result::Ok`] 가 리턴됩니다.
    /// 일치하는 항목이 여러 개인 경우 일치 항목 중 하나가 반환 될 수 있습니다.
    /// 값이 없으면 정렬 된 순서를 유지하면서 일치하는 요소를 삽입 할 수있는 인덱스를 포함하는 [`Result::Err`] 가 반환됩니다.
    ///
    ///
    /// # Examples
    ///
    /// 일련의 네 가지 요소를 찾습니다.
    /// 첫 번째는 고유하게 결정된 위치로 발견됩니다.두 번째와 세 번째는 찾을 수 없습니다.네 번째는 `[1, 4]` 의 모든 위치와 일치 할 수 있습니다.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// 정렬 순서를 유지하면서 정렬 된 `VecDeque` 에 항목을 삽입하려는 경우 :
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// 바이너리는이 정렬 된 `VecDeque` 를 비교기 기능으로 검색합니다.
    ///
    /// 비교기 함수는 기본 `VecDeque` 의 정렬 순서와 일치하는 순서를 구현하여 인수가 원하는 대상보다 `Less`, `Equal` 또는 `Greater` 인지 여부를 나타내는 순서 코드를 반환해야합니다.
    ///
    ///
    /// 값이 발견되면 일치하는 요소의 색인을 포함하는 [`Result::Ok`] 가 리턴됩니다.일치하는 항목이 여러 개인 경우 일치 항목 중 하나가 반환 될 수 있습니다.
    /// 값이 없으면 정렬 된 순서를 유지하면서 일치하는 요소를 삽입 할 수있는 인덱스를 포함하는 [`Result::Err`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// 일련의 네 가지 요소를 찾습니다.첫 번째는 고유하게 결정된 위치로 발견됩니다.두 번째와 세 번째는 찾을 수 없습니다.네 번째는 `[1, 4]` 의 모든 위치와 일치 할 수 있습니다.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// 바이너리는 키 추출 기능을 사용하여이 정렬 된 `VecDeque` 를 검색합니다.
    ///
    /// 예를 들어 동일한 키 추출 기능을 사용하는 [`make_contiguous().sort_by_key()`](#method.make_contiguous) 와 같이 `VecDeque` 가 키별로 정렬되었다고 가정합니다.
    ///
    ///
    /// 값이 발견되면 일치하는 요소의 색인을 포함하는 [`Result::Ok`] 가 리턴됩니다.
    /// 일치하는 항목이 여러 개인 경우 일치 항목 중 하나가 반환 될 수 있습니다.
    /// 값이 없으면 정렬 된 순서를 유지하면서 일치하는 요소를 삽입 할 수있는 인덱스를 포함하는 [`Result::Err`] 가 반환됩니다.
    ///
    /// # Examples
    ///
    /// 두 번째 요소로 정렬 된 쌍 조각에서 일련의 네 요소를 찾습니다.
    /// 첫 번째는 고유하게 결정된 위치로 발견됩니다.두 번째와 세 번째는 찾을 수 없습니다.네 번째는 `[1, 4]` 의 모든 위치와 일치 할 수 있습니다.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// 뒷면에서 초과 요소를 제거하거나 뒷면에 `value` 의 복제본을 추가하여 `len()` 가 new_len과 같도록 `VecDeque` 내부를 수정합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// 주어진 논리적 요소 인덱스에 대한 기본 버퍼의 인덱스를 반환합니다.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // 크기는 항상 2의 거듭 제곱입니다.
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// 버퍼에서 읽을 남은 요소 수를 계산합니다.
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // 크기는 항상 2의 거듭 제곱입니다.
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // 항상 세 섹션으로 나눌 수 있습니다. 예: self: [a b c|d e f] 기타: [0 1 2 3|4 5] front=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // as_slices 메서드에 의해 반환 된 슬라이스에 Hash::hash_slice 를 사용할 수 없습니다. 다른 동일한 데크에서 길이가 다를 수 있기 때문입니다.
        //
        //
        // Hasher는 메서드에 대한 똑같은 호출 집합에 대해서만 동등성을 보장합니다.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque` 를 앞뒤 반복기로 소비하여 값별로 요소를 생성합니다.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // 이 기능은 다음과 같은 도덕적이어야합니다.
        //
        //      iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// [`Vec<T>`] 를 [`VecDeque<T>`] 로 전환합니다.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// 이것은 가능한 경우 재 할당을 피하지만, 그 조건은 엄격하고 변경 될 수 있으므로 `Vec<T>` 가 `From<VecDeque<T>>` 에서 왔고 재 할당되지 않은 경우가 아니면 의존해서는 안됩니다.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // 용량에 대해 걱정할 ZST에 대한 실제 할당은 없지만 `VecDeque` 는 `Vec` 만큼 많은 길이를 처리 할 수 없습니다.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // 용량이 2의 거듭 제곱이 아니거나 너무 작거나 여유 공간이 하나도없는 경우 크기를 조정해야합니다.
            // `Vec` 에있는 동안이 작업을 수행하므로 항목이 panic 에 떨어집니다.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// [`VecDeque<T>`] 를 [`Vec<T>`] 로 전환합니다.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// 이것은 다시 할당 할 필요가 없지만 순환 버퍼가 할당 시작 부분에 있지 않으면 *O*(*n*) 데이터 이동을 수행해야합니다.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // 이것은 *O*(1)입니다.
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // 이것은 데이터 재 배열이 필요합니다.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}