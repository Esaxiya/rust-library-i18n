use core::array;
use core::cmp::{self};
use core::mem::replace;

use super::VecDeque;

/// PairSlices는 두 데크의 동일한 길이 슬라이스 부분을 쌍으로 만듭니다.
///
/// 예를 들어, 다음과 같은 분할 영역이있는 데크 "A" 및 "B" 가 제공됩니다.
///
///
/// A: [0 1 2] [3 4 5]
/// B: [a b] [c d e]
///
/// 다음과 같은 일치하는 슬라이스 시퀀스를 생성합니다.
///
/// ([0 1], [a b])(\[2\],\[c\])([3 4], [d e])
///
/// A 또는 B의 고르지 않은 나머지는 건너 뜁니다.
///
pub struct PairSlices<'a, 'b, T> {
    pub(crate) a0: &'a mut [T],
    pub(crate) a1: &'a mut [T],
    pub(crate) b0: &'b [T],
    pub(crate) b1: &'b [T],
}

impl<'a, 'b, T> PairSlices<'a, 'b, T> {
    pub fn from(to: &'a mut VecDeque<T>, from: &'b VecDeque<T>) -> Self {
        let (a0, a1) = to.as_mut_slices();
        let (b0, b1) = from.as_slices();
        PairSlices { a0, a1, b0, b1 }
    }

    pub fn has_remainder(&self) -> bool {
        !self.b0.is_empty()
    }

    pub fn remainder(self) -> impl Iterator<Item = &'b [T]> {
        array::IntoIter::new([self.b0, self.b1])
    }
}

impl<'a, 'b, T> Iterator for PairSlices<'a, 'b, T> {
    type Item = (&'a mut [T], &'b [T]);
    fn next(&mut self) -> Option<Self::Item> {
        // 다음 부품 길이 얻기
        let part = cmp::min(self.a0.len(), self.b0.len());
        if part == 0 {
            return None;
        }
        let (p0, p1) = replace(&mut self.a0, &mut []).split_at_mut(part);
        let (q0, q1) = self.b0.split_at(part);

        // 비어있는 경우 a1 를 a0 로 이동합니다 (그리고 b1, b0 도 같은 방식).
        self.a0 = p1;
        self.b0 = q1;
        if self.a0.is_empty() {
            self.a0 = replace(&mut self.a1, &mut []);
        }
        if self.b0.is_empty() {
            self.b0 = replace(&mut self.b1, &[]);
        }
        Some((p0, q0))
    }
}