//! 바이너리 힙으로 구현 된 우선 순위 큐.
//!
//! 가장 큰 요소의 삽입 및 터지는 시간이 *O*(log(*n*)) 복잡합니다.
//! 가장 큰 요소를 확인하는 것은 *O*(1)입니다.vector 를 이진 힙으로 변환하는 것은 제자리에서 수행 할 수 있으며 *O*(*n*) 복잡성이 있습니다.
//! 바이너리 힙은 정렬 된 vector in-place로 변환되어 *O*(*n*\*log(* n*)) in-place heapsort에 사용할 수 있습니다.
//!
//! # Examples
//!
//! 이것은 [directed graph][dir_graph] 에서 [shortest path problem][sssp] 를 해결하기 위해 [Dijkstra's algorithm][dijkstra] 를 구현하는 더 큰 예입니다.
//!
//! 사용자 정의 유형과 함께 [`BinaryHeap`] 를 사용하는 방법을 보여줍니다.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // 우선 순위 대기열은 `Ord` 에 따라 다릅니다.
//! // 큐가 최대 힙 대신 최소 힙이되도록 trait 를 명시 적으로 구현합니다.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // 비용에 대한 순서를 뒤집습니다.
//!         // 위치를 비교하는 동점의 경우이 단계는 `PartialEq` 및 `Ord` 구현의 일관성을 유지하는 데 필요합니다.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` 구현해야합니다.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // 더 짧은 구현을 위해 각 노드는 `usize` 로 표시됩니다.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra의 최단 경로 알고리즘.
//!
//! // `start` 에서 시작하고 `dist` 를 사용하여 각 노드에 대한 현재 최단 거리를 추적합니다.이 구현은 대기열에 중복 노드를 남길 수 있으므로 메모리 효율적이지 않습니다.
//! //
//! // 또한보다 간단한 구현을 위해 `usize::MAX` 를 센티넬 값으로 사용합니다.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]= `start` 에서 `node` 까지 현재 최단 거리
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // 비용이 전혀 들지 않는 `start` 에 있습니다.
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // 저비용 노드로 먼저 (min-heap) 의 경계를 조사하십시오.
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // 또는 우리는 모든 최단 경로를 계속 찾을 수 있습니다.
//!         if position == goal { return Some(cost); }
//!
//!         // 이미 더 나은 방법을 찾았을 수 있으므로 중요합니다.
//!         if cost > dist[position] { continue; }
//!
//!         // 도달 할 수있는 각 노드에 대해이 노드를 통과하는 비용이 더 저렴한 방법을 찾을 수 있는지 확인합니다.
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // 그렇다면 국경에 추가하고 계속하십시오.
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // 휴식, 우리는 이제 더 나은 방법을 찾았습니다
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // 도달 할 수없는 목표
//!     None
//! }
//!
//! fn main() {
//!     // 이것이 우리가 사용할 방향성 그래프입니다.
//!     // 노드 번호는 다른 상태에 해당하며 edge 가중치는 한 노드에서 다른 노드로 이동하는 비용을 상징합니다.
//!     //
//!     // 모서리는 단방향입니다.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // 그래프는 노드 값에 해당하는 각 인덱스에 나가는 에지 목록이있는 인접 목록으로 표시됩니다.
//!     // 효율성을 위해 선택되었습니다.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // 노드 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // 노드 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // 노드 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // 노드 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // 노드 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// 바이너리 힙으로 구현 된 우선 순위 큐.
///
/// 이것은 최대 힙이 될 것입니다.
///
/// 항목이 힙에있는 동안 `Ord` trait 에 의해 결정된대로 다른 항목과 관련된 항목의 순서가 변경되는 방식으로 항목을 수정하는 것은 논리 오류입니다.
///
/// 일반적으로 `Cell`, `RefCell`, 전역 상태, I/O 또는 안전하지 않은 코드를 통해서만 가능합니다.
/// 이러한 논리 오류로 인한 동작은 지정되지 않지만 정의되지 않은 동작이 발생하지는 않습니다.
/// 여기에는 panics, 잘못된 결과, 중단, 메모리 누수 및 비 종료가 포함될 수 있습니다.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // 유형 추론을 사용하면 명시적인 유형 서명 (이 예에서는 `BinaryHeap<i32>`)을 생략 할 수 있습니다.
/////
/// let mut heap = BinaryHeap::new();
///
/// // peek를 사용하여 힙의 다음 항목을 볼 수 있습니다.
/// // 이 경우에는 아직 항목이 없으므로 None을 얻습니다.
/// assert_eq!(heap.peek(), None);
///
/// // 점수를 추가해 봅시다 ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // 이제 peek는 힙에서 가장 중요한 항목을 보여줍니다.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // 힙의 길이를 확인할 수 있습니다.
/// assert_eq!(heap.len(), 3);
///
/// // 무작위 순서로 반환되지만 힙의 항목을 반복 할 수 있습니다.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // 대신이 점수를 팝하면 순서대로 돌아와야합니다.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // 남은 항목의 힙을 지울 수 있습니다.
/// heap.clear();
///
/// // 이제 힙이 비어 있어야합니다.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `std::cmp::Reverse` 또는 사용자 지정 `Ord` 구현을 사용하여 `BinaryHeap` 를 최소 힙으로 만들 수 있습니다.
/// 따라서 `heap.pop()` 는 가장 큰 값 대신 가장 작은 값을 반환합니다.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse` 에서 값 줄 바꿈
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // 지금이 점수를 표시하면 역순으로 돌아와야합니다.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # 시간 복잡성
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push` 의 값은 예상 비용입니다.방법 문서는 더 자세한 분석을 제공합니다.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// `BinaryHeap` 에서 가장 큰 항목에 대한 변경 가능한 참조를 래핑하는 구조입니다.
///
///
/// 이 `struct` 는 [`BinaryHeap`] 에서 [`peek_mut`] 방법으로 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // 안전: PeekMut은 비어 있지 않은 힙에 대해서만 인스턴스화됩니다.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // 안전: PeekMut은 비어 있지 않은 힙에 대해서만 인스턴스화됩니다.
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // 안전: PeekMut은 비어 있지 않은 힙에 대해서만 인스턴스화됩니다.
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// 힙에서 피킹 된 값을 제거하고 반환합니다.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// 빈 `BinaryHeap<T>` 를 만듭니다.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// 빈 `BinaryHeap` 를 최대 힙으로 만듭니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// 특정 용량을 가진 빈 `BinaryHeap` 를 만듭니다.
    /// 이렇게하면 `capacity` 요소에 충분한 메모리가 미리 할당되므로 `BinaryHeap` 는 최소한 그 이상의 값을 포함 할 때까지 다시 할당 할 필요가 없습니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// 바이너리 힙에서 가장 큰 항목에 대한 가변 참조를 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// Note: `PeekMut` 값이 누출되면 힙이 일관성없는 상태 일 수 있습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # 시간 복잡성
    ///
    /// 항목이 수정 된 경우 최악의 시간 복잡도는 *O*(log(*n*)) 이고, 그렇지 않으면 *O*(1)입니다.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// 바이너리 힙에서 가장 큰 항목을 제거하고 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # 시간 복잡성
    ///
    /// *n* 요소를 포함하는 힙에서 `pop` 의 최악의 비용은 *O*(log(*n*)) 입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // 안전: !self.is_empty() 는 self.len()> 0을 의미합니다.
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// 항목을 바이너리 힙으로 푸시합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # 시간 복잡성
    ///
    /// 푸시되는 요소의 가능한 모든 순서와 충분히 많은 푸시 횟수에 대한 평균 `push` 의 예상 비용은 *O*(1)입니다.
    ///
    /// 이것은 정렬 된 패턴이 *아닌* 요소를 푸시 할 때 가장 의미있는 비용 지표입니다.
    ///
    /// 요소가 주로 오름차순으로 푸시되면 시간 복잡성이 저하됩니다.
    /// 최악의 경우 요소는 오름차순으로 푸시되고 푸시 당 상각 된 비용은 *n* 요소를 포함하는 힙에 대해 *O*(log(*n*)) 입니다.
    ///
    /// `push` 에 대한 *단일* 호출의 최악의 경우 비용은 *O*(*n*)입니다.최악의 경우는 용량이 소진되어 크기 조정이 필요할 때 발생합니다.
    /// 크기 조정 비용은 이전 수치에서 상각되었습니다.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // 안전: 새 항목을 푸시했기 때문에
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` 를 소비하고 정렬 된 (ascending) 순서로 vector 를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // 안전: `end` 는 `self.len() - 1` 에서 1 (둘 다 포함)로 이동합니다.
            //  따라서 항상 액세스 할 수있는 유효한 색인입니다.
            //  인덱스 0 (예: `ptr`)에 액세스하는 것이 안전합니다.
            //  1 <=end <self.len(), 즉 self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // 안전: `end` 는 `self.len() - 1` 에서 1 (둘 다 포함됨)로 이동하므로 다음을 수행합니다.
            //  0 <1 <=end <= self.len(), 1 <self.len() 0 <end and end <self.len() 를 의미합니다.
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // sift_up 및 sift_down의 구현은 vector 에서 요소를 이동하고 (구멍 뒤에 남겨 둡니다) 다른 요소를 따라 이동하고 제거 된 요소를 구멍의 최종 위치에있는 vector 로 다시 이동하기 위해 안전하지 않은 블록을 사용합니다.
    //
    // `Hole` 유형은이를 나타내는 데 사용되며 panic 에서도 범위의 끝에서 구멍이 다시 채워 졌는지 확인합니다.
    // 구멍을 사용하면 이동이 두 배로 많은 스왑을 사용하는 것에 비해 상수 요소가 줄어 듭니다.
    //
    //
    //
    //

    /// # Safety
    ///
    /// 호출자는 `pos < self.len()` 를 보장해야합니다.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos` 에서 값을 꺼내 구멍을 만듭니다.
        // 안전: 발신자는 pos <self.len() 를 보장합니다.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // 안전: hole.pos()> 시작>=0, 즉 hole.pos()> 0
            //  그래서 hole.pos(), 1은 언더 플로 할 수 없습니다.
            //  이것은 부모 <hole.pos() 를 보장하므로 유효한 인덱스이고!= hole.pos() 입니다.
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // 안전: 위와 동일
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos` 에서 요소를 가져 와서 힙 아래로 이동하고 하위 요소는 더 큽니다.
    ///
    ///
    /// # Safety
    ///
    /// 호출자는 `pos < end <= self.len()` 를 보장해야합니다.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // 안전: 발신자는 pos <end <= self.len() 를 보장합니다.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // 루프 불변: 자식==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // 두 하위 SAFETY 중 더 큰 값과 비교하십시오. child <end, 1 <self.len() 및 child + 1 <end <= self.len() 이므로 유효한 인덱스입니다.
            //
            //  자식==2 *hole.pos() + 1!= hole.pos() 및 자식 + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 또는 2* hole.pos() + 2는 T가 ZST 인 경우 오버플로 될 수 있습니다.
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // 우리가 이미 순서가 맞다면 그만하십시오.
            // 안전: 자녀는 이제 노인이거나 노인 +1입니다.
            //  우리는 이미 둘 다 <self.len() 및!= hole.pos() 임을 입증했습니다.
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // 안전: 위와 동일합니다.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // 안전: &&단락, 즉
        //  두 번째 조건은 자식==끝, 1 <self.len() 라는 것이 이미 사실입니다.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // 안전: 아동은 이미 유효한 색인으로 입증되었으며
            //  자식==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// 호출자는 `pos < self.len()` 를 보장해야합니다.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // 안전: pos <len은 호출자에 의해 보장되며
        //  분명히 len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos` 에서 요소를 가져 와서 힙 아래로 끝까지 이동 한 다음 해당 위치까지 체로 치십시오.
    ///
    ///
    /// Note: 이는 요소가 크거나 바닥에 더 가까워 야하는 것으로 알려진 경우 더 빠릅니다.
    ///
    /// # Safety
    ///
    /// 호출자는 `pos < self.len()` 를 보장해야합니다.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // 안전: 발신자는 pos <self.len() 를 보장합니다.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // 루프 불변: 자식==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // 안전: 자식 <끝, 1 <self.len() 및
            //  child + 1 <end <= self.len() 이므로 유효한 인덱스입니다.
            //  자식==2 *hole.pos() + 1!= hole.pos() 및 자식 + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 또는 2* hole.pos() + 2는 T가 ZST 인 경우 오버플로 될 수 있습니다.
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // 안전: 위와 동일
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // 안전: child==end, 1 <self.len() 이므로 유효한 색인입니다.
            //  그리고 자식==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // 안전: pos는 구멍의 위치이며 이미 입증되었습니다.
        //  유효한 색인이어야합니다.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // 안전: n은 self.len()/2에서 시작하여 0으로 내려갑니다.
            //  ! (n <self.len()) 인 경우는 self.len() ==0 인 경우이지만 루프 조건에 의해 배제됩니다.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other` 의 모든 요소를 `self` 로 이동하고 `other` 는 비워 둡니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) 작업과 최악의 경우 약 2 *(len1 + len2) 비교를 수행하는 반면 `extend` 는 O(len2* log(len1)) 작업을 수행하고 최악의 경우에는 약 1 *len2* log_2(len1) 비교를 수행합니다 (len1>= len2 가정).
        // 더 큰 힙의 경우 교차점은 더 이상이 추론을 따르지 않으며 경험적으로 결정되었습니다.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// 힙 순서로 요소를 검색하는 반복기를 리턴합니다.
    /// 검색된 요소는 원래 힙에서 제거됩니다.
    /// 나머지 요소는 힙 순서로 드롭시 제거됩니다.
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` 보다 훨씬 느립니다.
    ///   대부분의 경우 후자를 사용해야합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // 힙 순서로 모든 요소를 제거합니다.
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// 술어로 지정된 요소 만 보유합니다.
    ///
    /// 즉, `f(&e)` 가 `false` 를 반환하도록 모든 요소 `e` 를 제거합니다.
    /// 요소는 정렬되지 않은 (및 지정되지 않은) 순서로 방문됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // 짝수 만 유지
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// 기본 vector 의 모든 값을 임의의 순서로 방문하는 반복기를 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 임의의 순서로 1, 2, 3, 4 인쇄
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// 힙 순서로 요소를 검색하는 반복기를 리턴합니다.
    /// 이 메서드는 원래 힙을 사용합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// 바이너리 힙에서 가장 큰 항목을 반환하거나 비어있는 경우 `None` 를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # 시간 복잡성
    ///
    /// 최악의 경우 비용은 *O*(1)입니다.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// 이진 힙이 재할 당하지 않고 보유 할 수있는 요소 수를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// 지정된 `BinaryHeap` 에 삽입 할 요소를 정확히 `additional` 개 이상에 대한 최소 용량을 예약합니다.
    /// 용량이 이미 충분하면 아무것도하지 않습니다.
    ///
    /// 할당자는 요청한 것보다 더 많은 공간을 컬렉션에 제공 할 수 있습니다.
    /// 따라서 용량을 정확하게 최소화 할 수 없습니다.
    /// future 삽입이 예상되는 경우 [`reserve`] 를 선호합니다.
    ///
    /// # Panics
    ///
    /// Panics 새 용량이 `usize` 를 초과하는 경우.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap` 에 삽입 할 최소 `additional` 이상의 요소에 대한 용량을 예약합니다.
    /// 컬렉션은 빈번한 재 할당을 피하기 위해 더 많은 공간을 예약 할 수 있습니다.
    ///
    /// # Panics
    ///
    /// Panics 새 용량이 `usize` 를 초과하는 경우.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// 추가 용량을 가능한 한 많이 버립니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// 하한이있는 용량을 버립니다.
    ///
    /// 용량은 최소한 길이와 제공된 값만큼 크게 유지됩니다.
    ///
    ///
    /// 현재 용량이 하한보다 작 으면 작동하지 않습니다.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` 를 소비하고 기본 vector 를 임의의 순서로 반환합니다.
    ///
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // 어떤 순서로 인쇄됩니다
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// 바이너리 힙의 길이를 반환합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// 바이너리 힙이 비어 있는지 확인합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 이진 힙을 지우고 제거 된 요소에 대한 반복자를 반환합니다.
    ///
    /// 요소는 임의의 순서로 제거됩니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// 바이너리 힙에서 모든 항목을 삭제합니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// 구멍은 슬라이스의 구멍, 즉 유효한 값이없는 인덱스 (이동 또는 복제 되었기 때문에)를 나타냅니다.
///
/// 드롭에서 `Hole` 는 구멍 위치를 원래 제거 된 값으로 채워 슬라이스를 복원합니다.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// 인덱스 `pos` 에 새 `Hole` 를 만듭니다.
    ///
    /// pos는 데이터 조각 내에 있어야하므로 안전하지 않습니다.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // 안전: 위치는 슬라이스 안에 있어야합니다.
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// 제거 된 요소에 대한 참조를 반환합니다.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index` 의 요소에 대한 참조를 반환합니다.
    ///
    /// 인덱스는 데이터 조각 내에 있어야하고 pos와 같지 않아야하므로 안전하지 않습니다.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// 구멍을 새 위치로 이동
    ///
    /// 인덱스는 데이터 조각 내에 있어야하고 pos와 같지 않아야하므로 안전하지 않습니다.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // 다시 구멍을 채우다
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// `BinaryHeap` 의 요소에 대한 반복기입니다.
///
/// 이 `struct` 는 [`BinaryHeap::iter()`] 에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` 를 위해 제거
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// `BinaryHeap` 의 요소에 대한 소유 반복기입니다.
///
/// 이 `struct` 는 [`BinaryHeap::into_iter()`] (`IntoIterator` trait 에서 제공)에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// `BinaryHeap` 의 요소에 대한 배수 반복기입니다.
///
/// 이 `struct` 는 [`BinaryHeap::drain()`] 에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// `BinaryHeap` 의 요소에 대한 배수 반복기입니다.
///
/// 이 `struct` 는 [`BinaryHeap::drain_sorted()`] 에 의해 생성됩니다.
/// 자세한 내용은 설명서를 참조하십시오.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// 힙 순서대로 힙 요소를 제거합니다.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` 를 `BinaryHeap<T>` 로 변환합니다.
    ///
    /// 이 변환은 제자리에서 발생하며 *O*(*n*) 시간 복잡성이 있습니다.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` 를 `Vec<T>` 로 변환합니다.
    ///
    /// 이 변환은 데이터 이동이나 할당이 필요하지 않으며 일정한 시간 복잡성이 있습니다.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// 사용하는 반복기, 즉 임의의 순서로 이진 힙에서 각 값을 이동하는 반복기를 만듭니다.
    /// 이것을 호출 한 후에는 바이너리 힙을 사용할 수 없습니다.
    ///
    /// # Examples
    ///
    /// 기본 사용법 :
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 임의의 순서로 1, 2, 3, 4 인쇄
    /// for x in heap.into_iter() {
    ///     // x에는 &i32 가 아닌 i32 유형이 있습니다.
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}