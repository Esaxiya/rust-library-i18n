//! 할당 Prelude
//!
//! 이 모듈의 목적은 모듈 상단에 glob 가져 오기를 추가하여 `alloc` crate 의 일반적으로 사용되는 항목의 가져 오기를 완화하는 것입니다.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;