//! 通過流程中止實現 Rust panics
//!
//! 與通過展開實現相比，此 crate 簡直是 `簡單得多`! 話雖這麼說，它不是很通用，但是可以了!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" 將有效載荷和勻場墊填入相關平台上的相關中止位置。
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // 致電 std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // 在 Windows 上，使用特定於處理器的__fastfail 機制。在 Windows 8 和更高版本中，這將立即終止進程，而無需運行任何進程內異常處理程序。
            // 在 Windows 的早期版本中，此指令序列將被視為訪問衝突，從而終止進程，但不必繞過所有異常處理程序。
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: 這與 libstd `abort_internal` 中的實現相同
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// 這... 有點奇怪。tl; 博士; 是正確鏈接所必需的，下面將進行詳細說明。
//
// 現在，我們出廠的 libcore/libstd 二進製文件都已用 `-C panic=unwind` 編譯。這樣做是為了確保二進製文件最大程度地與盡可能多的情況兼容。
// 但是，對於使用 `-C panic=unwind` 編譯的所有功能，編譯器都需要 "personality function"。此個性功能被硬編碼到符號 `rust_eh_personality`，並由 `eh_personality` lang 項目定義。
//
// So...
// 為什麼不在這裡定義那個 lang 項目呢? 好問題! panic 運行時的鏈接方式實際上有點微妙，因為它們在編譯器的 crate 存儲區中是 "sort of"，但只有在另一個未鏈接時才實際鏈接。
//
// 結束意味著這 crate 和 panic_unwind crate 都可以出現在編譯器的 crate 存儲中，如果兩者都定義了 `eh_personality` lang 項，則將出錯。
//
// 要解決此問題，如果鏈接到的 panic 運行時是正在展開的運行時，則僅要求定義 `eh_personality`，否則不需要定義 (正確地如此)。
// 但是，在這種情況下，該庫僅定義了此符號，因此某處至少具有某些個性。
//
// 本質上，此符號只是為了連接到 libcore/libstd 二進製文件而定義的，但是絕對不要調用它，因為我們根本不會在展開運行時中進行鏈接。
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // 在 x86_64-pc-windows-gnu 上，我們使用自己的個性函數，當我們傳遞所有幀時，該函數需要返回 `ExceptionContinueSearch`。
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // 與上麵類似，這對應於當前僅在 Emscripten 上使用的 `eh_catch_typeinfo` lang 項。
    //
    // 由於 panics 不會生成異常，並且外部異常當前是 -C panic=abort 的 UB (儘管可能會更改)，所以任何 catch_unwind 調用將永遠不會使用此 typeinfo。
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // 我們的啟動對像在 i686-pc-windows-gnu 上調用了這兩個對象，但是它們不需要執行任何操作，因此它們的主體是點頭的。
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}