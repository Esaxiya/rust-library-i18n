# `rustc-std-workspace-core` crate

crate 是一個填充碼，空的 crate 僅依賴於 `libcore` 並重新導出其所有內容。
crate 是授權標準庫依賴 crates.io 的 crates 的關鍵

標準庫所依賴的 crates.io 上的 Crates 需要依賴於 crates.io 上的 `rustc-std-workspace-core` crate，它為空。

我們使用 `[patch]` 將其覆蓋到此存儲庫中的 crate。
結果，crates.io 上的 crates 會將依賴項 edge 繪製到 `libcore` (此存儲庫中定義的版本)。
這應該畫出所有依賴關係邊，以確保 Cargo 成功構建 crates!

請注意，crates.io 上的 crates 必須依賴於名稱為 `core` 的 crate 才能正常工作。為此，他們可以使用:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

通過使用 `package` 鍵，crate 重命名為 `core`，這意味著它看起來像

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

當 Cargo 調用編譯器時，滿足了編譯器注入的隱式 `extern crate core` 指令。




