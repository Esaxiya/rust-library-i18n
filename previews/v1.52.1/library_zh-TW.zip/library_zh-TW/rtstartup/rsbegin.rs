// rsbegin.o 和 rsend.o 是所謂的 "compiler runtime startup objects"。
// 它們包含正確初始化編譯器運行時所需的代碼。
//
// 鏈接可執行文件或 dylib 映像時，這兩個目標文件之間的所有用戶代碼和庫都是 "sandwiched"，因此，來自 rsbegin.o 的代碼或數據在映像的各個部分中排在首位，而來自 rsend.o 的代碼和數據成為最後一個。
// 此效果可用於將符號放置在節的開頭或結尾，以及插入任何所需的頁眉或頁腳。
//
// 請注意，實際的模塊入口點位於 C 運行時啟動對象 (通常稱為 `crtX.o`) 中，然後該對象調用其他運行時組件的初始化回調 (通過另一個特殊的映像部分註冊)。
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // 標記堆棧幀展開信息部分的開頭
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // 為開捲機的內部簿記留出空間。
    // 在 $ GCC/unwind-dw2-fde.h 中將其定義為 `struct object`。
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // 展開信息 registration/deregistration 例程。
    // 請參閱 libpanic_unwind 的文檔。
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // 在模塊啟動時註冊展開信息
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // 關機時註銷
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW 特定的 init/uninit 例行註冊
    pub mod mingw_init {
        // MinGW 的啟動對象 (crt0.o/dllcrt0.o) 將在啟動和退出時在 .ctors 和 .dtors 部分中調用全局構造函數。
        // 對於 DLL，這是在加載和卸載 DLL 時完成的。
        //
        // 鏈接器將對這些部分進行排序，以確保我們的回調位於列表的末尾。
        // 由於構造函數以相反的順序運行，因此可以確保我們的回調是執行的第一個和最後一個。
        //
        //

        #[link_section = ".ctors.65535"] // .ctors。*: C 初始化回調
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors。*: C 終止回調
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}