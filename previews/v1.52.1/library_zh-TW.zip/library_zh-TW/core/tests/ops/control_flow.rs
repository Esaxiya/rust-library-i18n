use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // 這不是穩定的表面積，但是即使 LLVM 現在不能總是利用它，也可以使 `?` 便宜。
    //
    // (可悲的是結果和選項不一致，因此 ControlFlow 不能同時匹配兩者。)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}