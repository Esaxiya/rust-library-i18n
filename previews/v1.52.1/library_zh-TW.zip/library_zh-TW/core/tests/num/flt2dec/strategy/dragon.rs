use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // 美里太慢了
fn exact_sanity_test() {
    // 該測試最終運行的是我只能假定的 `exp2` 庫函數的某種極端情況，該情況在我們使用的任何 C 運行時中都已定義。
    // 在 VS 2013 中，此功能顯然存在錯誤，因為該測試在鏈接時失敗，但是在 VS 2015 中，該錯誤似乎已修復，因為測試運行良好。
    //
    // 該錯誤似乎是 `exp2(-1057)` 返回值的差異，在 VS 2013 中，它返回帶有位模式 0x2 的雙精度值，而在 VS 2015 中，它返回 0x20000。
    //
    //
    // 現在，只需要在 MSVC 上完全忽略此測試，因為它無論如何都已在其他地方進行了測試，我們對測試每個平台的 exp2 實現並不十分感興趣。
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}