#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` 和 `str` 方法的 Unicode 部分所基於的 [Unicode](http://www.unicode.org/) 版本。
///
/// Unicode 的新版本會定期發布，隨後會更新標準庫中取決於 Unicode 的所有方法。
/// 因此，某些 `char` 和 `str` 方法的行為以及該常數的值會隨時間變化。
/// *這不是* 重大的改變。
///
/// 版本編號方案在 [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) 中進行了說明。
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// 供在 liballoc 中使用，而不在 libstd 中重新導出。
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;