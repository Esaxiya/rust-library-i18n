//! 展示字符 {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` 可以具有的最高有效代碼點。
    ///
    /// `char` 是 [Unicode Scalar Value]，這意味著它是 [Code Point]，但僅在一定範圍內。
    /// `MAX` 是有效 [Unicode Scalar Value] 的最高有效代碼點。
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () 在 Unicode 中用於表示解碼錯誤。
    ///
    /// 例如，當將格式錯誤的 UTF-8 字節提供給 [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) 時，可能會發生這種情況。
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` 和 `str` 方法的 Unicode 部分所基於的 [Unicode](http://www.unicode.org/) 版本。
    ///
    /// Unicode 的新版本會定期發布，隨後會更新標準庫中取決於 Unicode 的所有方法。
    /// 因此，某些 `char` 和 `str` 方法的行為以及該常數的值會隨時間變化。
    /// *這不是* 重大的改變。
    ///
    /// 版本編號方案在 [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) 中進行了說明。
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// 在 `iter` 中的 UTF-16 編碼的代碼點上創建一個迭代器，將不成對的代理返回為 `Err`s。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// 通過用替換字符替換 `Err` 結果，可以獲得有損解碼器:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// 將 `u32` 轉換為 `char`。
    ///
    /// 請注意，所有的 `char`s 都是有效的 [`u32`] s，並且可以使用以下命令將其強制轉換為 1
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// 但是，相反的情況並非如此: 並非所有有效的 [u32] 都是有效的 char。
    /// `from_u32()` 如果輸入的值不是 `char` 的有效值，則將返回 `None`。
    ///
    /// 有關忽略這些檢查的此函數的不安全版本，請參閱 [`from_u32_unchecked`]。
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// 當輸入不是有效的 `char` 時返回 `None`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// 將 `u32` 轉換為 `char`，而忽略有效性。
    ///
    /// 請注意，所有的 `char`s 都是有效的 [`u32`] s，並且可以使用以下命令將其強制轉換為 1
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// 但是，相反的情況並非如此: 並非所有有效的 [u32] 都是有效的 char。
    /// `from_u32_unchecked()` 會忽略這一點，並盲目地將其強制轉換為 `char`，從而可能創建無效的 `char`。
    ///
    ///
    /// # Safety
    ///
    /// 此功能不安全，因為它可能會構造無效的 `char` 值。
    ///
    /// 有關此功能的安全版本，請參見 [`from_u32`] 功能。
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // 安全: 调用者必須遵守安全合同。
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// 將給定基數中的數字轉換為 `char`。
    ///
    /// 這裡的 'radix' 有時也稱為 'base'。
    /// 基數 2 表示二進制數，以十進製表示的十進制，以十六進製表示十六進制的基數，以給出一些公共值。
    ///
    /// 支持任意半徑。
    ///
    /// `from_digit()` 如果輸入不是給定基數中的數字，則將返回 `None`。
    ///
    /// # Panics
    ///
    /// Panics (如果基數大於 36)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 十進制 11 是以 16 為底的一位數字
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// 當輸入不是數字時返回 `None`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// 傳遞較大的基數，導致 panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// 檢查 `char` 是否為給定基數中的數字。
    ///
    /// 這裡的 'radix' 有時也稱為 'base'。
    /// 基數 2 表示二進制數，以十進製表示的十進制，以十六進製表示十六進制的基數，以給出一些公共值。
    ///
    /// 支持任意半徑。
    ///
    /// 與 [`is_numeric()`] 相比，此功能僅識別字符 `0-9`，`a-z` 和 `A-Z`。
    ///
    /// 'Digit' 被定義為僅以下字符:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 要更全面地了解 'digit'，請參閱 [`is_numeric()`]。
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics (如果基數大於 36)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// 傳遞較大的基數，導致 panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// 將 `char` 轉換為給定基數的數字。
    ///
    /// 這裡的 'radix' 有時也稱為 'base'。
    /// 基數 2 表示二進制數，以十進製表示的十進制，以十六進製表示十六進制的基數，以給出一些公共值。
    ///
    /// 支持任意半徑。
    ///
    /// 'Digit' 被定義為僅以下字符:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// 如果 `char` 未引用給定基數中的數字，則返回 `None`。
    ///
    /// # Panics
    ///
    /// Panics (如果基數大於 36)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// 傳遞非數字會導致失敗:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// 傳遞較大的基數，導致 panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // 在 `radix` 為常數且小於等於 10 的情況下，在此處拆分代碼以提高執行速度
        //
        let val = if likely(radix <= 10) {
            // 如果不是數字，則將創建一個大於基數的數字。
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// 返回一個迭代器，該迭代器將字符的十六進制 Unicode 轉義生成為 `char`s。
    ///
    /// 這將使用 `\u{NNNNNN}` 格式的 Rust 語法對字符進行轉義，其中 `NNNNNN` 是十六進製表示形式。
    ///
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // 或 1 確保在 c==0 時代碼計算出應打印一位，並且 (相同) 避免 (31，32) 下溢
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // 最高有效十六進制數字的索引
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` 的擴展版本，可以選擇轉義擴展的 Grapheme 代碼點。
    /// 這樣一來，當我們在字符串的開頭時，就可以更好地設置非間距標記之類的字符格式。
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// 返回一個迭代器，該迭代器將字符的字面量轉義碼生成為 `char`s。
    ///
    /// 這將轉義類似於 `str` 或 `char` 的 `Debug` 實現的字符。
    ///
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// 返回一個迭代器，該迭代器將字符的字面量轉義碼生成為 `char`s。
    ///
    /// 選擇默認值時會偏向於生成使用多種語言 (包括 C++ 11 和類似的 C 系列語言) 都是合法的文字。
    /// 確切的規則是:
    ///
    /// * 製表符被轉義為 `\t`。
    /// * 回車符被轉義為 `\r`。
    /// * 換行符轉為 `\n`。
    /// * 單引號轉義為 `\'`。
    /// * 雙引號轉義為 `\"`。
    /// * 反斜杠轉義為 `\\`。
    /// * `可打印 ASCII` 範圍 `0x20` .. `0x7e` (含) 範圍內的任何字符都不會轉義。
    /// * 所有其他字符均使用十六進制 Unicode 轉義; 請參閱 [`escape_unicode`]。
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// 返回以 UTF-8 編碼時此 `char` 所需的字節數。
    ///
    /// 該字節數始終在 1 到 4 之間 (含 1 和 4)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` 類型保證其內容為 UTF-8，因此我們可以比較將每個代碼點表示為 `char` 相對於 `&str` 本身所花費的長度:
    ///
    ///
    /// ```
    /// // 作為字符
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // 兩者都可以表示為三個字節
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // 作為 &str，這兩個編碼為 UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // 我們可以看到它們總共佔用了六個字節...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // 就像 &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// 返回以 UTF-16 編碼時 `char` 所需的 16 位代碼單元的數量。
    ///
    ///
    /// 有關此概念的更多說明，請參見 [`len_utf8()`] 的文檔。
    /// 此功能是一個鏡像，但適用於 UTF-16 而不是 UTF-8。
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// 將此字符編碼為 UTF-8 到提供的字節緩衝區中，然後返回包含編碼字符的緩衝區的子片段。
    ///
    ///
    /// # Panics
    ///
    /// Panics (如果緩衝區不夠大)。
    /// 長度為四的緩衝區足夠大，可以對任何 `char` 進行編碼。
    ///
    /// # Examples
    ///
    /// 在這兩個示例中，'ß' 佔用兩個字節進行編碼。
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 緩衝區太小:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // 安全: `char` 不是替代品，因此這是有效的 UTF-8。
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// 將此字符編碼為 UTF-16 到提供的 `u16` 緩衝區中，然後返回包含編碼字符的緩衝區的子片段。
    ///
    ///
    /// # Panics
    ///
    /// Panics (如果緩衝區不夠大)。
    /// 長度為 2 的緩衝區足夠大，可以對任何 `char` 進行編碼。
    ///
    /// # Examples
    ///
    /// 在這兩個示例中，'𝕊' 都需要兩個 `u16` 進行編碼。
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 緩衝區太小:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// 如果此 `char` 具有 `Alphabetic` 屬性，則返回 `true`。
    ///
    /// `Alphabetic` 在 [Unicode Standard] 的第 4 章 (字符屬性) 中進行了說明，並在 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 中進行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // 愛是很多東西，但不是字母
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// 如果此 `char` 具有 `Lowercase` 屬性，則返回 `true`。
    ///
    /// `Lowercase` 在 [Unicode Standard] 的第 4 章 (字符屬性) 中進行了說明，並在 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 中進行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // 各種中文腳本和標點符號沒有大小寫，因此:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// 如果此 `char` 具有 `Uppercase` 屬性，則返回 `true`。
    ///
    /// `Uppercase` 在 [Unicode Standard] 的第 4 章 (字符屬性) 中進行了說明，並在 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 中進行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // 各種中文腳本和標點符號沒有大小寫，因此:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// 如果此 `char` 具有 `White_Space` 屬性，則返回 `true`。
    ///
    /// `White_Space` 在 [Unicode Character Database][ucd] [`PropList.txt`] 中指定。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // 一個不間斷的空間
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// 如果此 `char` 滿足 [`is_alphabetic()`] 或 [`is_numeric()`]，則返回 `true`。
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// 如果此 `char` 具有控制代碼的常規類別，則返回 `true`。
    ///
    /// [Unicode Standard] 的第 4 章 (字符屬性) 中描述了控制代碼 (具有 `Cc` 的常規類別的代碼點)，並在 [Unicode Character Database][ucd] [`UnicodeData.txt`] 中進行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // U + 009C，字符串終止符
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// 如果此 `char` 具有 `Grapheme_Extend` 屬性，則返回 `true`。
    ///
    /// `Grapheme_Extend` 在 [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] 中進行了說明，並在 [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] 中進行了指定。
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// 如果此 `char` 具有數字的常規類別之一，則返回 `true`。
    ///
    /// 在 [Unicode Character Database][ucd] [`UnicodeData.txt`] 中指定了數字的常規類別 (`Nd` 表示十進制數字，`Nl` 表示類似字母的數字字符，`No` 表示其他數字字符)。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// 返回一個迭代器，該迭代器將這個 `char` 的小寫字母映射為一個或多個
    /// `char`s.
    ///
    /// 如果此 `char` 沒有小寫映射，則迭代器將產生相同的 `char`。
    ///
    /// 如果此 `char` 具有 [Unicode Character Database][ucd] [`UnicodeData.txt`] 給出的一對一小寫映射，則迭代器將產生該 `char`。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// 如果此 `char` 需要特殊考慮 (例如，多個 char)，則迭代器將產生 [`SpecialCasing.txt`] 給定的 char。
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// 此操作無需裁剪即可執行無條件映射。即，轉換獨立於上下文和語言。
    ///
    /// 在 [Unicode Standard] 中，第 4 章 (字符屬性) 通常討論大小寫映射，而第 3 章 (Conformance) 討論大小寫轉換的默認算法。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // 有時結果是多個字符:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // 同時沒有大寫和小寫字母的字符會轉換成自己。
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// 返回一個迭代器，該迭代器將這個 `char` 的大寫映射生成為一個或多個
    /// `char`s.
    ///
    /// 如果此 `char` 沒有大寫映射，則迭代器將產生相同的 `char`。
    ///
    /// 如果此 `char` 具有 [Unicode Character Database][ucd] [`UnicodeData.txt`] 給出的一對一大寫映射，則迭代器將產生該 `char`。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// 如果此 `char` 需要特殊考慮 (例如，多個 char)，則迭代器將產生 [`SpecialCasing.txt`] 給定的 char。
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// 此操作無需裁剪即可執行無條件映射。即，轉換獨立於上下文和語言。
    ///
    /// 在 [Unicode Standard] 中，第 4 章 (字符屬性) 通常討論大小寫映射，而第 3 章 (Conformance) 討論大小寫轉換的默認算法。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // 有時結果是多個字符:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // 同時沒有大寫和小寫字母的字符會轉換成自己。
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # 關於語言環境的註釋
    ///
    /// 在土耳其語中，相當於 'i' 的拉丁語具有 5 種形式，而不是 2 種形式:
    ///
    /// * 'Dotless': 我 /ı，有時寫成 ï
    /// * 'Dotted': İ/i
    ///
    /// 注意，小寫的點綴 'i' 與拉丁字母相同。所以:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` 的值取決於文本的語言: 如果我們在 `en-US` 中，則應為 `"I"`，但如果我們在 `tr_TR` 中，則應為 `"İ"`。
    /// `to_uppercase()` 沒有考慮到這一點，因此:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// 適用於多種語言。
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// 檢查該值是否在 ASCII 範圍內。
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// 使值的副本等效於其 ASCII 大寫字母。
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不變。
    ///
    /// 要就地將值大寫，請使用 [`make_ascii_uppercase()`]。
    ///
    /// 要除非 ASCII 字符外還使用大寫 ASCII 字符，請使用 [`to_uppercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 以等效的 ASCII 小寫形式複制值。
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不變。
    ///
    /// 要就地小寫該值，請使用 [`make_ascii_lowercase()`]。
    ///
    /// 要除非 ASCII 字符外還使用小寫 ASCII 字符，請使用 [`to_lowercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 檢查兩個值是否為 ASCII 區分大小寫的匹配。
    ///
    /// 等效於 `to_ascii_lowercase(a) == to_ascii_lowercase(b)`。
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// 將此類型就地轉換為其 ASCII 大寫等效項。
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不變。
    ///
    /// 要返回新的大寫值而不修改現有值，請使用 [`to_ascii_uppercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// 將此類型就地轉換為其 ASCII 小寫等效項。
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不變。
    ///
    /// 要返回新的小寫值而不修改現有值，請使用 [`to_ascii_lowercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// 檢查值是否為 ASCII 字母字符:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z'，或
    /// - U + 0061 'a' ..=U + 007A 'z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// 檢查值是否為 ASCII 大寫字符:
    /// U + 0041 'A' ..=U + 005A 'Z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// 檢查值是否為 ASCII 小寫字符:
    /// U + 0061 'a' ..=U + 007A 'z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// 檢查值是否為 ASCII 字母數字字符:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z'，或
    /// - U + 0061 'a' ..=U + 007A 'z'，或
    /// - U + 0030 '0' ..=U + 0039 '9'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// 檢查值是否為 ASCII 十進制數字:
    /// U + 0030 '0' ..=U + 0039 '9'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// 檢查值是否為 ASCII 十六進制數字:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9'，或
    /// - U + 0041 'A' ..=U + 0046 'F'，或
    /// - U + 0061 'a' ..=U + 0066 'f'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// 檢查值是否為 ASCII 標點符號:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`，或
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`，或
    /// - U + 005B ..=U + 0060``[\] ^ _``，或
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// 檢查值是否為 ASCII 圖形字符:
    /// U + 0021 '!' ..=U + 007E '~'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// 檢查值是否為 ASCII 空格字符:
    /// U + 0020 空間，U + 0009 水平製表符，U + 000A 行進紙，U + 000C 表單進紙或 U + 000D 回車。
    ///
    /// Rust 使用 WhatWG Infra Standard 的 [definition of ASCII whitespace][infra-aw]。還有其他幾種廣泛使用的定義。
    /// 例如，[the POSIX locale][pct] 包括 U + 000B 垂直製表符以及上述所有字符，但是 - 從同樣的規格來看 -[Bourne shell 中 "field splitting" 的默認規則][bfs] 僅考慮 * 空格，水平製表符和 LINE FEED 為空格。
    ///
    ///
    /// 如果要編寫將處理現有文件格式的程序，請在使用此功能之前檢查該格式的空格定義。
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// 檢查值是否為 ASCII 控製字符:
    /// U + 0000 NUL ..=U + 001F 單位分隔符，或 U + 007F DELETE。
    /// 請注意，大多數 ASCII 空格字符是控製字符，而 SPACE 不是。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// 將原始 u32 值編碼為 UTF-8 到提供的字節緩衝區中，然後返回包含編碼字符的緩衝區的子片段。
///
///
/// 與 `char::encode_utf8` 不同，此方法還可以處理代理範圍內的代碼點。
/// (在代理範圍內創建 `char` 是 UB。) 結果是有效的 [generalized UTF-8]，但無效的 UTF-8。
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics (如果緩衝區不夠大)。
/// 長度為四的緩衝區足夠大，可以對任何 `char` 進行編碼。
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// 將原始 u32 值編碼為 UTF-16 到提供的 `u16` 緩衝區中，然後返回包含編碼字符的緩衝區的子片段。
///
///
/// 與 `char::encode_utf16` 不同，此方法還可以處理代理範圍內的代碼點。
/// (在代理範圍內創建 `char` 是 UB。)
///
/// # Panics
///
/// Panics (如果緩衝區不夠大)。
/// 長度為 2 的緩衝區足夠大，可以對任何 `char` 進行編碼。
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // 安全: 每個臂檢查是否有足夠的位可寫入
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP 掉隊了
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // 補充飛機分成代用品。
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}