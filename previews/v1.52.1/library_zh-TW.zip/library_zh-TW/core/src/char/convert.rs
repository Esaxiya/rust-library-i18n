//! 字符轉換。

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// 將 `u32` 轉換為 `char`。
///
/// 請注意，所有 [`char`] 都是有效的 [`u32`]，並且可以使用以下命令將其強制轉換為一個
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// 但是，事實並非如此: 並非所有有效的 [u32] 都是有效的 [char]。
/// `from_u32()` 如果輸入的值不是 [`char`] 的有效值，則將返回 `None`。
///
/// 有關忽略這些檢查的此函數的不安全版本，請參閱 [`from_u32_unchecked`]。
///
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// 當輸入不是有效的 [`char`] 時返回 `None`:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// 將 `u32` 轉換為 `char`，而忽略有效性。
///
/// 請注意，所有 [`char`] 都是有效的 [`u32`]，並且可以使用以下命令將其強制轉換為一個
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// 但是，事實並非如此: 並非所有有效的 [u32] 都是有效的 [char]。
/// `from_u32_unchecked()` 會忽略這一點，並盲目地將其強制轉換為 [`char`]，可能會創建一個無效的 [`char`]。
///
///
/// # Safety
///
/// 此功能不安全，因為它可能會構造無效的 `char` 值。
///
/// 有關此功能的安全版本，請參見 [`from_u32`] 功能。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // 安全: 調用者必須保證 `i` 是有效的 char 值。
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// 將 [`char`] 轉換為 [`u32`]。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// 將 [`char`] 轉換為 [`u64`]。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // 字符強制轉換為代碼點的值，然後零擴展為 64 位。
        // 見 [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// 將 [`char`] 轉換為 [`u128`]。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // 字符強制轉換為代碼點的值，然後零擴展為 128 位。
        // 見 [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// 將 0x00 ..=0xFF 中的字節映射到代碼點具有相同值的 `char` (U + 0000 ..=U + 00FF)。
///
/// Unicode 的設計使其可以使用 IANA 稱為 ISO-8859-1 的字符編碼有效地解碼字節。
/// 此編碼與 ASCII 兼容。
///
/// 請注意，這與 ISO/IEC 8859-1 又名不同
/// ISO 8859-1 (連字符少一個)，它留下了一些 "blanks" 字節值，這些值未分配給任何字符。
/// ISO-8859-1 (屬於 IANA) 將它們分配給 C0 和 C1 控制代碼。
///
/// 請注意，這也與 Windows-1252 也不同
/// 代碼頁 1252，它是 ISO/IEC 8859-1 的超集，它為標點符號和各種拉丁字符分配了一些 (不是全部! ) 空格。
///
/// 為了進一步混淆，[on the Web](https://encoding.spec.whatwg.org/) `ascii`，`iso-8859-1` 和 `windows-1252` 都是 Windows-1252 的超集的別名，該超集用相應的 C0 和 C1 控制代碼填充了其餘的空白。
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// 將 [`u8`] 轉換為 [`char`]。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// 解析 char 時可以返回的錯誤。
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // 安全: 檢查這是合法的 unicode 值
            Ok(unsafe { transmute(i) })
        }
    }
}

/// 從 u32 轉換為 char 失敗時返回的錯誤類型。
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// 將給定基數中的數字轉換為 `char`。
///
/// 這裡的 'radix' 有時也稱為 'base'。
/// 基數 2 表示二進制數，以十進製表示的十進制，以十六進製表示十六進制的基數，以給出一些公共值。
///
/// 支持任意半徑。
///
/// `from_digit()` 如果輸入不是給定基數中的數字，則將返回 `None`。
///
/// # Panics
///
/// Panics (如果基數大於 36)。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // 十進制 11 是以 16 為底的一位數字
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// 當輸入不是數字時返回 `None`:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// 傳遞較大的基數，導致 panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}