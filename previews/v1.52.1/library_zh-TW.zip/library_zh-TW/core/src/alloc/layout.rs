use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// 儘管此函數在一個地方使用並且可以內聯其實現，但是以前這樣做的嘗試使 rustc 變慢了:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// 一塊內存的佈局。
///
/// `Layout` 的實例描述了特定的內存佈局。
/// 您將 `Layout` 作為輸入分配給分配器。
///
/// 所有佈局都具有關聯的大小和 2 的冪次對齊。
///
/// (請注意，即使 `GlobalAlloc` 要求所有內存請求的大小均非零，也不需要 * 佈局具有非零的大小。
/// 調用方必須確保滿足這樣的條件，使用要求較寬鬆的特定分配器，或者使用更寬鬆的 `Allocator` 接口。)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // 請求的內存塊的大小，以字節為單位。
    size_: usize,

    // 請求的內存塊的對齊方式，以字節為單位。
    // 我們確保這始終是 2 的冪，因為像 `posix_memalign` 這樣的 API 都需要這樣做，並且強加給 Layout 構造函數是一個合理的約束。
    //
    //
    // (但是，我們類似地不要求 `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// 從給定的 `size` 和 `align` 構造 `Layout`，或者如果不滿足以下任何條件，則返回 `LayoutError`:
    ///
    /// * `align` 不能為零，
    ///
    /// * `align` 必須是 2 的冪
    ///
    /// * `size`, 當四捨五入到最接近的 `align` 倍數時，一定不能溢出 (即，四捨五入的值必須小於或等於 `usize::MAX`)。
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (2 的冪表示 align! =0。)

        // 舍入後的大小為:
        //   size_rounded_up= (大小 + 對齊，1)＆! (對齊，1) ;
        //
        // 從上面我們知道 align! =0。
        // 如果加法 (align，1) 沒有溢出，則四捨五入是可以的。
        //
        // 相反，用! (align，1) 進行＆掩碼將僅減去低位。
        // 因此，如果總和發生溢出，則＆-mask 不能減去足以抵消該溢出的值。
        //
        //
        // 以上暗示檢查總和溢出是否必要和充分。
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // 安全: `from_size_align_unchecked` 的條件是
        // 檢查以上。
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// 創建一個佈局，繞過所有檢查。
    ///
    /// # Safety
    ///
    /// 此功能不安全，因為它不驗證 [`Layout::from_size_align`] 的前提條件。
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // 安全: 调用者必須確保 `align` 大於零。
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// 此佈局的存儲塊的最小大小 (以字節為單位)。
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// 此佈局的存儲塊的最小字節對齊。
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// 構造一個適合保存 `T` 類型值的 `Layout`。
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // 安全: Rust 確保對齊方式是 2 的冪和
        // size + align 組合保證可以放入我們的地址空間。
        // 結果，如果未對 panics 進行最佳優化，請在此處使用未經檢查的構造函數，以免插入 panics 的代碼。
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// 生成描述記錄的佈局，該記錄可用於為 `T` 分配後備結構 (可以是 trait 或其他未分大小的類型，例如切片)。
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // 安全: 有關為什麼使用不安全變體的信息，請參見 `new` 中的基本原理
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// 生成描述記錄的佈局，該記錄可用於為 `T` 分配後備結構 (可以是 trait 或其他未分大小的類型，例如切片)。
    ///
    /// # Safety
    ///
    /// 僅在滿足以下條件時，才可以安全地調用此函數:
    ///
    /// - 如果 `T` 是 `Sized`，則始終可以安全地調用此函數。
    /// - 如果 `T` 的未調整大小的尾部為:
    ///     - [slice]，則切片尾部的長度必須是一個初始化整數，並且 *entire 值*(動態尾部長度 + 靜態大小的前綴) 的大小必須適合 `isize`。
    ///     - [trait object]，則指針的 vtable 部分必須指向通過未調整大小的強制獲取的 `T` 類型的有效 vtable，並且 *entire 值*(動態尾部長度 + 靜態大小的前綴) 的大小必須適合 `isize`。
    ///
    ///     - (unstable) [extern type]，則始終可以安全調用該函數，但可能會 panic 或以其他方式返回錯誤的值，因為外部類型的佈局未知。
    ///     這與對外部類型尾部的引用上的 [`Layout::for_value`] 相同。
    ///     - 否則，保守地不允許調用此函數。
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // 安全: 我們將這些功能的前提條件傳遞給調用者
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // 安全: 有關為什麼使用不安全變體的信息，請參見 `new` 中的基本原理
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// 創建一個懸空的 `NonNull`，但與此佈局完全匹配。
    ///
    /// 請注意，該指針值可能表示一個有效的指針，這意味著不得將其用作 "not yet initialized" 標記值。
    /// 延遲分配的類型必須通過其他某種方式來跟踪初始化。
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // 安全: 保證對齊不為零
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// 創建一個描述記錄的佈局，該記錄可以保留與 `self` 相同的佈局值，但也與對齊方式 `align` 對齊 (以字節為單位)。
    ///
    ///
    /// 如果 `self` 已經滿足規定的對齊方式，則返回 `self`。
    ///
    /// 請注意，無論返回的佈局是否具有不同的對齊方式，此方法都不會在整體大小上添加任何填充。
    /// 換句話說，如果 `K` 的大小為 16，則 `K.align_to(32)`*仍* 的大小為 16。
    ///
    /// 如果 `self.size()` 和給定的 `align` 的組合違反 [`Layout::from_size_align`] 中列出的條件，則返回錯誤。
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// 返回必須在 `self` 之後插入的填充量，以確保以下地址滿足 `align` (以字節為單位)。
    ///
    /// 例如，如果 `self.size()` 為 9，則 `self.padding_needed_for(4)` 返回 3，因為這是獲得 4 對齊地址所需的最小填充字節數 (假設相應的存儲塊從 4 對齊地址開始)。
    ///
    ///
    /// 如果 `align` 不是 2 的冪，則此函數的返回值沒有意義。
    ///
    /// 請注意，返回值的實用程序要求 `align` 小於或等於整個分配的內存塊的起始地址的對齊方式。滿足此約束的一種方法是確保 `align <= self.align()`。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // 四捨五入的值是:
        //   len_rounded_up= (len + align，1)＆! (align，1) ;
        // 然後返回填充差異: `len_rounded_up - len`.
        //
        // 我們在整個過程中都使用模塊化算法:
        //
        // 1. align 保證 > 0，因此 align 始終有效。
        //
        // 2.
        // `len + align - 1` 最多可以溢出 `align - 1`，因此 `!(align - 1)` 的＆掩碼將確保在發生溢出的情況下 `len_rounded_up` 本身將為 0。
        //
        //    因此，當返回的填充添加到 `len` 時，將產生 0，該填充簡單地滿足了 `align` 的對齊方式。
        //
        // (當然，嘗試以上述方式分配其大小和填充溢出的內存塊無論如何都會導致分配器產生錯誤。)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// 通過將佈局的大小四捨五入到佈局的對齊方式的倍數來創建佈局。
    ///
    ///
    /// 這等效於將 `padding_needed_for` 的結果添加到佈局的當前大小。
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // 這不會溢出。引用 Layout 的不變式:
        // > `size`, 當四捨五入到 `align` 的最接近倍數時，
        // > 不得溢出 (即，四捨五入的值必須小於
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// 創建一個佈局，以描述 `self` 的 `n` 實例的記錄，並在每個實例之間使用適當的填充量，以確保為每個實例提供其請求的大小和對齊方式。
    /// 成功後，返回 `(k, offs)`，其中 `k` 是數組的佈局，`offs` 是數組中每個元素的起點之間的距離。
    ///
    /// 算術溢出時，返回 `LayoutError`。
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // 這不會溢出。引用 Layout 的不變式:
        // > `size`, 當四捨五入到 `align` 的最接近倍數時，
        // > 不得溢出 (即，四捨五入的值必須小於
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // 安全: 已知 self.align 是有效的，並且 alloc_size 已被使用
        // 已經填充。
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// 創建一個佈局，描述 `self` 的記錄，後跟 `next` 的記錄，包括任何必要的填充，以確保 `next` 正確對齊，但是 *沒有尾隨填充*。
    ///
    /// 為了匹配 C 表示形式的佈局 `repr(C)`，應在擴展了所有字段的佈局後調用 `pad_to_align`。
    /// (無法匹配默認的 Rust 表示形式佈局 `repr(Rust)`, as it is unspecified.)
    ///
    /// 請注意，最終佈局的對齊方式將是 `self` 和 `next` 的最大對齊方式，以確保兩個部分的對齊方式。
    ///
    /// 返回 `Ok((k, offset))`，其中 `k` 是串聯記錄的佈局，`offset` 是嵌入在串聯記錄中的 `next` 起始位置的相對位置 (以字節為單位) (假定記錄本身從偏移量 0 開始)。
    ///
    ///
    /// 算術溢出時，返回 `LayoutError`。
    ///
    /// # Examples
    ///
    /// 要計算 `#[repr(C)]` 結構的佈局以及字段與其字段佈局的偏移量，請執行以下操作:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // 記得用 `pad_to_align` 來完成!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // 測試它是否有效
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// 創建一個佈局，該佈局描述 `self` 的 `n` 實例的記錄，每個實例之間沒有填充。
    ///
    /// 請注意，與 `repeat` 不同，即使給定的 `self` 實例正確對齊，`repeat_packed` 也不能保證 `self` 的重複實例將正確對齊。
    /// 換句話說，如果使用 `repeat_packed` 返回的佈局來分配數組，則不能保證數組中的所有元素都將正確對齊。
    ///
    /// 算術溢出時，返回 `LayoutError`。
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// 創建一個佈局，描述 `self` 和 `next` 的記錄，兩者之間沒有其他填充。
    /// 由於未插入任何填充，因此 `next` 的對齊方式是無關緊要的，並且根本不會將其併入最終的佈局中。
    ///
    ///
    /// 算術溢出時，返回 `LayoutError`。
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// 創建一個描述 `[T; n]` 記錄的佈局。
    ///
    /// 算術溢出時，返回 `LayoutError`。
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// 給 `Layout::from_size_align` 或其他 `Layout` 構造函數的參數不滿足其記錄的約束。
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (對於 trait 錯誤的下游隱含我們需要此功能)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}