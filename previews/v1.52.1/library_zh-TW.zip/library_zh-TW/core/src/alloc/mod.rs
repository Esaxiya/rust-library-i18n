//! 內存分配 API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` 錯誤表示分配失敗，這可能是由於資源耗盡或將給定的輸入參數與此分配器組合在一起時出錯所致。
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (對於 trait 錯誤的下游隱含我們需要此功能)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` 的實現可以分配，增長，收縮和取消分配通過 [`Layout`][] 描述的任意數據塊。
///
/// `Allocator` 之所以將其設計為在 ZST，引用或智能指針上實現，是因為不能移動像 `MyAlloc([u8; N])` 這樣的分配器，而不更新指向已分配內存的指針。
///
/// 與 [`GlobalAlloc`][] 不同，`Allocator` 允許零大小的分配。
/// 如果基礎分配器不支持此功能 (例如 jemalloc) 或返回空指針 (例如 `libc::malloc`)，則必須由實現捕獲。
///
/// ### 當前分配的內存
///
/// 一些方法要求通過分配器 *當前分配* 一個存儲塊。這意味著:
///
/// * 該內存塊的起始地址先前由 [`allocate`]，[`grow`] 或 [`shrink`] 返回，並且
///
/// * 內存塊隨後並未被釋放，其中的塊要么通過傳遞到 [`deallocate`] 直接釋放，要么通過傳遞到返回 `Ok` 的 [`grow`] 或 [`shrink`] 進行了更改。
///
/// 如果 `grow` 或 `shrink` 返回了 `Err`，則傳遞的指針保持有效。
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### 記憶體配件
///
/// 有些方法要求佈局 `適合` 內存塊。
/// 對於到 "fit" 的佈局，存儲塊意味著 (或者，對於到 "fit" 的存儲塊，佈局意味著) 必須滿足以下條件:
///
/// * 必須以與 [`layout.align()`] 相同的對齊方式分配該塊，並且
///
/// * 提供的 [`layout.size()`] 必須在 `min ..= max` 範圍內，其中:
///   - `min` 是最近用於分配塊的佈局的大小，並且
///   - `max` 是從 [`allocate`]，[`grow`] 或 [`shrink`] 返回的最新實際大小。
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * 從分配器返回的內存塊必須指向有效內存並保持其有效性，直到刪除實例及其所有克隆為止，
///
/// * 克隆或移動分配器不得使此分配器返回的內存塊無效。克隆的分配器的行為必須類似於相同的分配器，並且
///
/// * 指向 [*currently allocated*] 的存儲塊的任何指針都可以傳遞給分配器的任何其他方法。
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// 嘗試分配一塊內存。
    ///
    /// 成功後，返回滿足 `layout` 大小和對齊保證的 [`NonNull<[u8]>`][NonNull]。
    ///
    /// 返回的塊的大小可能大於 `layout.size()` 指定的大小，並且可能已初始化或未初始化其內容。
    ///
    /// # Errors
    ///
    /// 返回 `Err` 表示內存已耗盡，或者 `layout` 不滿足分配器的大小或對齊約束。
    ///
    /// 鼓勵實現在內存耗盡時返回 `Err`，而不是驚慌或中止，但是這不是嚴格的要求。
    /// (具體來說: 在一個底層的本機分配庫上實現此 trait 是 *合法的*，該本地分配庫在內存耗盡時中止。)
    ///
    /// 鼓勵希望因分配錯誤而中止計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// 行為類似於 `allocate`，但也確保返回的內存被零初始化。
    ///
    /// # Errors
    ///
    /// 返回 `Err` 表示內存已耗盡，或者 `layout` 不滿足分配器的大小或對齊約束。
    ///
    /// 鼓勵實現在內存耗盡時返回 `Err`，而不是驚慌或中止，但是這不是嚴格的要求。
    /// (具體來說: 在一個底層的本機分配庫上實現此 trait 是 *合法的*，該本地分配庫在內存耗盡時中止。)
    ///
    /// 鼓勵希望因分配錯誤而中止計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // 安全: `alloc` 返回有效的存儲塊
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// 取消分配 `ptr` 引用的內存。
    ///
    /// # Safety
    ///
    /// * `ptr` 必須通過此分配器表示一個內存塊 [*currently allocated*]，並且
    /// * `layout` 必須 [*fit*] 該內存塊。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// 嘗試擴展內存塊。
    ///
    /// 返回一個新的 [`NonNull<[u8]>`][NonNull]，其中包含一個指針和分配的內存的實際大小。該指針適用於保存 `new_layout` 描述的數據。
    /// 為此，分配器可以擴展 `ptr` 引用的分配以適合新的佈局。
    ///
    /// 如果返回 `Ok`，則 `ptr` 引用的內存塊的所有權已轉移到此分配器。
    /// 內存可能已釋放，也可能尚未釋放，除非已通過此方法的返回值再次將其轉移回調用方，否則應將其視為不可用。
    ///
    /// 如果此方法返回 `Err`，則該存儲塊的所有權尚未轉移到此分配器，並且該存儲塊的內容未更改。
    ///
    /// # Safety
    ///
    /// * `ptr` 必須通過此分配器表示一個內存塊 [*currently allocated*]。
    /// * `old_layout` 必須 [*fit*] 該內存塊 (`new_layout` 參數不需要適合它。)。
    /// * `new_layout.size()` 必須大於或等於 `old_layout.size()`。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 如果新佈局不符合分配器的大小和分配器的對齊約束，或者如果增長失敗，則返回 `Err`。
    ///
    /// 鼓勵實現在內存耗盡時返回 `Err`，而不是驚慌或中止，但是這不是嚴格的要求。
    /// (具體來說: 在一個底層的本機分配庫上實現此 trait 是 *合法的*，該本地分配庫在內存耗盡時中止。)
    ///
    /// 鼓勵希望因分配錯誤而中止計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // 安全: 因為 `new_layout.size()` 必須大於或等於
        // `old_layout.size()`, 舊的和新的內存分配都對 `old_layout.size()` 字節的讀取和寫入有效。
        // 另外，由於尚未分配舊分配，因此它不能與 `new_ptr` 重疊。
        // 因此，對 `copy_nonoverlapping` 的調用是安全的。
        // 调用者必須遵守 `dealloc` 的安全合同。
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// 行為類似於 `grow`，但也確保在返回新內容之前將其設置為零。
    ///
    /// 成功調用後，該存儲塊將包含以下內容
    /// `grow_zeroed`:
    ///   * 字節 `0..old_layout.size()` 從原始分配中保留。
    ///   * 字節 `old_layout.size()..old_size` 將保留還是清零，具體取決於分配器的實現。
    ///   `old_size` 引用 `grow_zeroed` 調用之前的內存塊大小，它可能大於分配時最初請求的大小。
    ///   * 字節 `old_size..new_size` 被清零。`new_size` 是指 `grow_zeroed` 調用返回的內存塊的大小。
    ///
    /// # Safety
    ///
    /// * `ptr` 必須通過此分配器表示一個內存塊 [*currently allocated*]。
    /// * `old_layout` 必須 [*fit*] 該內存塊 (`new_layout` 參數不需要適合它。)。
    /// * `new_layout.size()` 必須大於或等於 `old_layout.size()`。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 如果新佈局不符合分配器的大小和分配器的對齊約束，或者如果增長失敗，則返回 `Err`。
    ///
    /// 鼓勵實現在內存耗盡時返回 `Err`，而不是驚慌或中止，但是這不是嚴格的要求。
    /// (具體來說: 在一個底層的本機分配庫上實現此 trait 是 *合法的*，該本地分配庫在內存耗盡時中止。)
    ///
    /// 鼓勵希望因分配錯誤而中止計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // 安全: 因為 `new_layout.size()` 必須大於或等於
        // `old_layout.size()`, 舊的和新的內存分配都對 `old_layout.size()` 字節的讀取和寫入有效。
        // 另外，由於尚未分配舊分配，因此它不能與 `new_ptr` 重疊。
        // 因此，對 `copy_nonoverlapping` 的調用是安全的。
        // 调用者必須遵守 `dealloc` 的安全合同。
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// 嘗試縮小內存塊。
    ///
    /// 返回一個新的 [`NonNull<[u8]>`][NonNull]，其中包含一個指針和分配的內存的實際大小。該指針適用於保存 `new_layout` 描述的數據。
    /// 為此，分配器可以縮小 `ptr` 引用的分配以適合新的佈局。
    ///
    /// 如果返回 `Ok`，則 `ptr` 引用的內存塊的所有權已轉移到此分配器。
    /// 內存可能已釋放，也可能尚未釋放，除非已通過此方法的返回值再次將其轉移回調用方，否則應將其視為不可用。
    ///
    /// 如果此方法返回 `Err`，則該存儲塊的所有權尚未轉移到此分配器，並且該存儲塊的內容未更改。
    ///
    /// # Safety
    ///
    /// * `ptr` 必須通過此分配器表示一個內存塊 [*currently allocated*]。
    /// * `old_layout` 必須 [*fit*] 該內存塊 (`new_layout` 參數不需要適合它。)。
    /// * `new_layout.size()` 必須小於或等於 `old_layout.size()`。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 如果新的佈局不符合分配器的大小和分配器的對齊約束，或者縮小失敗，則返回 `Err`。
    ///
    /// 鼓勵實現在內存耗盡時返回 `Err`，而不是驚慌或中止，但是這不是嚴格的要求。
    /// (具體來說: 在一個底層的本機分配庫上實現此 trait 是 *合法的*，該本地分配庫在內存耗盡時中止。)
    ///
    /// 鼓勵希望因分配錯誤而中止計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // 安全: 因為 `new_layout.size()` 必須小於或等於
        // `old_layout.size()`, 舊的和新的內存分配都對 `new_layout.size()` 字節的讀取和寫入有效。
        // 另外，由於尚未分配舊分配，因此它不能與 `new_ptr` 重疊。
        // 因此，對 `copy_nonoverlapping` 的調用是安全的。
        // 调用者必須遵守 `dealloc` 的安全合同。
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// 為此 `Allocator` 實例創建 "by reference" 適配器。
    ///
    /// 返回的適配器也實現 `Allocator`，並且將簡單地借用它。
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // 安全: 调用者必須遵守安全合同
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全: 调用者必須遵守安全合同
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全: 调用者必須遵守安全合同
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全: 调用者必須遵守安全合同
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}