use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// 可以通過 `#[global_allocator]` 屬性將其分配為標準庫的默認內存分配器。
///
/// 一些方法要求通過分配器 *當前分配* 一個存儲塊。這意味著:
///
/// * 該存儲塊的起始地址先前是由先前對分配方法 (例如 `alloc`) 的調用返回的，並且
///
/// * 內存塊尚未隨後被釋放，而是通過傳遞給諸如 `dealloc` 的釋放方法或傳遞給返回非空指針的重新分配方法來對塊進行釋放。
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// 由於多種原因，`GlobalAlloc` trait 是 `unsafe` trait，實現者必須確保遵守以下合同:
///
/// * 如果全局分配器釋放，這是未定義的行為。可以在 future 中解除此限制，但是當前來自任何這些功能的 panic 都可能導致內存不安全。
///
/// * `Layout` 查詢和計算通常必須正確。允許 trait 的調用者依賴於每種方法所定義的協定，並且實現者必須確保此類協定保持正確。
///
/// * 即使源中存在顯式堆分配，您也可能不依賴實際發生的分配。
/// 優化器可能會檢測到未使用的分配，該分配器可以將其完全消除或移到堆棧，因此從不調用分配器。
/// 優化器可能進一步假設分配是無誤的，因此由於分配器故障而導致分配器失敗的代碼現在可能突然起作用，因為優化器解決了分配需求。
/// 更具體地說，無論您的自定義分配器是否允許計算發生了多少分配，下面的代碼示例都是不正確的。
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   請注意，上面提到的優化並不是唯一可以應用的優化。如果可以在不更改程序行為的情況下將其刪除，則通常可能不依賴於發生的堆分配。
///   分配的發生與否不是程序行為的一部分，即使可以通過分配器檢測到分配，該分配器通過打印或其他方式跟踪分配也會產生副作用。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// 按照給定的 `layout` 分配內存。
    ///
    /// 返回指向新分配的內存的指針，或者返回 null 以指示分配失敗。
    ///
    /// # Safety
    ///
    /// 此函數是不安全的，因為如果調用者不確保 `layout` 的大小為非零，則可能導致未定義的行為。
    ///
    /// (擴展子特性可能提供行為的更具體限制，例如，保證響應零大小分配請求的前哨地址或空指針。)
    ///
    /// 分配的內存塊可能會初始化也可能不會初始化。
    ///
    /// # Errors
    ///
    /// 返回空指針表示內存已耗盡，或者 `layout` 不滿足此分配器的大小或對齊約束。
    ///
    /// 鼓勵實現在內存耗盡時返回 null 而不是中止，但這不是嚴格的要求。
    /// (具體來說: 在一個底層的本機分配庫上實現此 trait 是 *合法的*，該本地分配庫在內存耗盡時中止。)
    ///
    /// 鼓勵希望因分配錯誤而中止計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// 使用給定的 `layout` 在給定的 `ptr` 指針處釋放內存塊。
    ///
    /// # Safety
    ///
    /// 此函數是不安全的，因為如果調用者不能確保滿足以下所有條件，則可能導致未定義的行為:
    ///
    ///
    /// * `ptr` 必須表示當前通過此分配器分配的一塊內存，
    ///
    /// * `layout` 必須與用於分配該內存塊的佈局相同。
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// 行為類似於 `alloc`，但也確保在返回之前將內容設置為零。
    ///
    /// # Safety
    ///
    /// 出於與 `alloc` 相同的原因，此功能不安全。
    /// 但是，保證已分配的內存塊將被初始化。
    ///
    /// # Errors
    ///
    /// 像 `alloc` 一樣，返回空指針表示內存已耗盡或 `layout` 不滿足分配器的大小或對齊約束。
    ///
    /// 鼓勵希望因分配錯誤而中止計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // 安全: 调用者必須遵守 `alloc` 的安全合同。
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // 安全: 分配成功後，從 `ptr` 開始的區域
            // 保證大小為 `size` 的數據對寫入有效。
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// 將內存塊縮小或增加到給定的 `new_size`。
    /// 該塊由給定的 `ptr` 指針和 `layout` 描述。
    ///
    /// 如果返回非空指針，則 `ptr` 引用的內存塊的所有權已轉移到此分配器。
    /// 內存可能已釋放，也可能尚未釋放，應將其視為不可用的 (除非當然已通過此方法的返回值再次將其轉移回調用方)。
    /// `layout` 分配了新的存儲塊，但 `size` 更新為 `new_size`。
    /// 當用 `dealloc` 釋放新的內存塊時，應使用這種新的佈局。
    /// 保證新存儲塊的範圍 `0..min(layout.size()，new_size) 具有與原始塊相同的值。
    ///
    /// 如果此方法返回 null，則該存儲塊的所有權尚未轉移到此分配器，並且該存儲塊的內容不會更改。
    ///
    /// # Safety
    ///
    /// 此函數是不安全的，因為如果調用者不能確保滿足以下所有條件，則可能導致未定義的行為:
    ///
    /// * `ptr` 當前必須通過此分配器分配，
    ///
    /// * `layout` 必須與用於分配該內存塊的佈局相同，
    ///
    /// * `new_size` 必須大於零。
    ///
    /// * `new_size`, 當四捨五入到最接近的 `layout.align()` 倍數時，一定不能溢出 (即，四捨五入的值必須小於 `usize::MAX`)。
    ///
    /// (擴展子特性可能提供行為的更具體限制，例如，保證響應零大小分配請求的前哨地址或空指針。)
    ///
    /// # Errors
    ///
    /// 如果新佈局不符合分配器的大小和對齊約束，或者重新分配失敗，則返回 null。
    ///
    /// 鼓勵實現在內存耗盡時返回 null，而不是驚慌或中止，但這不是嚴格的要求。
    /// (具體來說: 在一個底層的本機分配庫上實現此 trait 是 *合法的*，該本地分配庫在內存耗盡時中止。)
    ///
    /// 鼓勵希望中止響應重新分配錯誤的計算的客戶調用 [`handle_alloc_error`] 函數，而不是直接調用 `panic!` 或類似方法。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // 安全: 调用者必須確保 `new_size` 不會溢出。
        // `layout.align()` 來自 `Layout`，因此可以保證是有效的。
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // 安全: 调用者必須確保 `new_layout` 大於零。
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // 安全: 先前分配的塊不能與新分配的塊重疊。
            // 调用者必須遵守 `dealloc` 的安全合同。
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}