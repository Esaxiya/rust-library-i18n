//! 原始 traits 和類型表示類型的基本屬性。
//!
//! Rust 類型可以根據其固有屬性以各種有用的方式進行分類。
//! 這些分類表示為 traits。
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// 可以跨線程邊界傳輸的類型。
///
/// 當編譯器確定適當時，會自動實現此 trait。
///
/// 非 `發送` 類型的一個示例是引用計數指針 [`rc::Rc`][`Rc`]。
/// 如果兩個線程試圖克隆指向相同引用計數值的 [Rc]，則它們可能會嘗試同時更新引用計數，即 [undefined behavior][ub]，因為 [`Rc`] 不使用原子操作。
///
/// 它的表親 [`sync::Arc`][arc] 確實使用原子操作 (產生一些開銷)，因此它是 `Send`。
///
/// 有關更多詳細信息，請參見 [the Nomicon](../../nomicon/send-and-sync.html)。
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// 在編譯時已知大小恆定的類型。
///
/// 所有類型參數的隱含邊界均為 `Sized`。如果不合適，可以使用特殊語法 `?Sized` 刪除此邊界。
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // 結構 FooUse(Foo<[i32]>);// 錯誤: 未為 [i32] 實現大小調整
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// 一個例外是 trait 的隱式 `Self` 類型。
/// trait 沒有隱式 `Sized` 綁定，因為它與 [trait object] s 不兼容，根據定義，trait 需要與所有可能的實現者一起使用，因此可以為任意大小。
///
///
/// 儘管 Rust 允許您將 `Sized` 綁定到 trait，但是以後您將無法使用它來形成 trait 對象:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // 令 y: &dyn Bar= &Impl;// 錯誤: 無法將 trait `Bar` 製成對象
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // 例如，對於 `默認` 而言，它要求 `[T]: !Default` 必須是可評估的
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// 可以是 "unsized" 的類型也可以是動態大小的類型。
///
/// 例如，按大小排列的數組類型 `[i8; 2]` 實現 `Unsize<[i8]>` 和 `Unsize<dyn fmt::Debug>`。
///
/// `Unsize` 的所有實現均由編譯器自動提供。
///
/// `Unsize` 為以下目的實現:
///
/// - `[T; N]` 是 `Unsize<[T]>`
/// - `T` `T: Trait` 時為 `Unsize<dyn Trait>`
/// - `Foo<..., T, ...>` 如果是，則為 `Unsize<Foo<..., U, ...>>`:
///   - `T: Unsize<U>`
///   - Foo 是一個結構
///   - 僅 `Foo` 的最後一個字段具有涉及 `T` 的類型
///   - `T` 不屬於任何其他字段的類型
///   - `Bar<T>: Unsize<Bar<U>>`, 如果 `Foo` 的最後一個字段的類型為 `Bar<T>`
///
/// `Unsize` 與 [`ops::CoerceUnsized`] 一起使用可允許 "user-defined" 容器 (例如 [`Rc`]) 包含動態大小的類型。
/// 有關更多詳細信息，請參見 [DST coercion RFC][RFC982] 和 [the nomicon entry on coercion][nomicon-coerce]。
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// 模式匹配中使用的常數需要 trait。
///
/// 不管其類型參數是否實現 `Eq`，任何派生 `PartialEq` 的類型都會自動實現此 trait。
///
/// 如果 `const` 項包含某種未實現此 trait 的類型，則該類型要么 (1.) 不實現 `PartialEq` (這意味著該常量將不提供該比較方法 (代碼生成假定可用) )，要么 (2.) 它實現 *自己*`PartialEq` 版本 (我們假設它不符合結構相等性比較)。
///
///
/// 在以上兩種情況中的任何一種情況下，我們都拒絕在模式匹配中使用此類常量。
///
/// 另請參見 [structural match RFC][RFC1445] 和 [issue 63438]，它們促使從基於屬性的設計遷移到此 trait。
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// 模式匹配中使用的常數需要 trait。
///
/// 派生 `Eq` 的任何類型都會自動實現此 trait，無論其類型參數是否實現 `Eq`。
///
/// 這是一種解決我們類型系統限制的技巧。
///
/// # Background
///
/// 我們要要求模式匹配中使用的 const 類型具有屬性 `#[derive(PartialEq, Eq)]`。
///
/// 在更理想的世界中，我們可以通過僅檢查給定類型是否同時實現 `StructuralPartialEq` trait 和 `Eq` trait 來檢查該要求。
/// 但是，您可以使用 *do*`derive(PartialEq, Eq)` 的 ADT，這是我們希望編譯器接受的情況，但是常量的類型無法實現 `Eq`。
///
/// 即，這樣的情況:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (以上代碼中的問題是 `Wrap<fn(&())>` 既不實現 `PartialEq` 也不實現 `Eq`，因為 `for <'a> fn(&'a _)` does not implement those traits.)
///
/// 因此，我們不能僅僅依靠 `StructuralPartialEq` 和 `Eq` 的幼稚檢查。
///
/// 要解決此問題，我們使用兩個派生的 (`#[derive(PartialEq)]` 和 `#[derive(Eq)]`) 分別注入的兩個單獨的 traits，並檢查它們是否都作為結構匹配檢查的一部分出現。
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// 只需複制位即可複制其值的類型。
///
/// 默認情況下，變量綁定具有 `移動語義`。換句話說:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` 已移至 `y`，因此無法使用
///
/// // println! (`{: ?}`，x) ;// 錯誤: 使用移動值
/// ```
///
/// 但是，如果類型實現 `Copy`，則它具有 `複製語義`:
///
/// ```
/// // 我們可以派生一個 `Copy` 實現。
/// // `Clone` 也是必需的，因為它是 `Copy` 的特徵。
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` 是 `x` 的副本
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// 重要的是要注意，在這兩個示例中，唯一的區別是分配後是否允許您訪問 `x`。
/// 在後台，複製和移動都可能導致將位複製到內存中，儘管有時會對其進行優化。
///
/// ## 如何實現 `Copy`?
///
/// 有兩種方法可以在您的類型上實現 `Copy`。最簡單的是使用 `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// 您還可以手動實現 `Copy` 和 `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// 兩者之間的區別很小: `derive` 策略還將 `Copy` 綁定在類型參數上，這並不總是需要的。
///
/// ## `Copy` 和 `Clone` 有什麼區別?
///
/// 複製是隱式發生的，例如作為任務 `y = x` 的一部分。`Copy` 的行為不可重載; 它始終是簡單的按位複制。
///
/// 克隆是一個明確的動作 `x.clone()`。[`Clone`] 的實現可以提供安全地複制值所需的任何特定於類型的行為。
/// 例如，用於 [`String`] 的 [`Clone`] 的實現需要在堆中復制指向字符串的緩衝區。
/// [`String`] 值的簡單按位副本將僅複製指針，從而導致該行下的 double 釋放。
/// 因此，[`String`] 是 [`Clone`]，但不是 `Copy`。
///
/// [`Clone`] 是 `Copy` 的特徵，因此 `Copy` 的所有內容也必須實現 [`Clone`]。
/// 如果類型為 `Copy`，則其 [`Clone`] 實現僅需要返回 `*self` (請參見上面的示例)。
///
/// ## 什麼時候可以輸入 `Copy`?
///
/// 如果類型的所有組件都實現 `Copy`，則它可以實現 `Copy`。例如，此結構可以是 `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// 結構可以是 `Copy`，而 [`i32`] 是 `Copy`，因此 `Point` 有資格成為 `Copy`。
/// 相比之下，考慮
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// 結構 `PointList` 無法實現 `Copy`，因為 [`Vec<T>`] 不是 `Copy`。如果嘗試派生 `Copy` 實現，則會收到錯誤消息:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// 共享引用 (`&T`) 也是 `Copy`，因此類型也可以是 `Copy`，即使它包含 *04* 不是*`Copy` 類型的共享引用。
/// 考慮下面的結構，它可以實現 `Copy`，因為它從上面僅持有我們的非 Copy 類型 `PointList` 的 `共享引用`:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## 什麼時候我的類型不能為 `Copy`?
///
/// 某些類型無法安全複製。例如，複製 `&mut T` 將創建一個別名可變引用。
/// 複製 [`String`] 將重複管理 [`String`] 的緩衝區的責任，從而導致雙重釋放。
///
/// 概括後一種情況，任何實現 [`Drop`] 的類型都不能是 `Copy`，因為它除了管理自己的 [`size_of::<T>`] 字節外還管理一些資源。
///
/// 如果嘗試在包含非 `Copy` 數據的結構或枚舉上實現 `Copy`，則會收到錯誤 [E0204]。
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## 我的 *什麼時候* 應該是 `Copy`?
///
/// 一般來說，如果您的 _can_ 類型實現 `Copy`，則應該這樣做。
/// 但是請記住，實現 `Copy` 是您類型的公共 API 的一部分。
/// 如果在 future 中該類型可能變為非 `Copy`，則最好現在省略 `Copy` 實現，以避免 API 發生重大更改。
///
/// ## 其他實施者
///
/// 除 [implementors listed below][impls] 之外，以下類型還實現 `Copy`:
///
/// * 功能項目類型 (即，為每個功能定義的不同類型)
/// * 函數指針類型 (例如， `fn() -> i32`)
/// * 如果項目類型也實現 `Copy` (例如 `[i32; 123456]`)，則所有大小的數組類型
/// * 如果每個組件還實現 `Copy` (例如 `()`，`(i32, bool)`)，則為元組類型
/// * 閉包類型，如果它們沒有從環境中捕獲任何值，或者所有捕獲的值本身都實現了 `Copy`。
///   請注意，共享引用捕獲的變量始終實現 `Copy` (即使引用對像沒有實現)，而可變引用捕獲的變量則永遠不會實現 `Copy`。
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) 這允許複製由於不滿足生命週期限製而無法實現 `Copy` 的類型 (僅 `A<'static>: Copy` 和 `A<'_>: Clone` 時復制 `A<'_>`)。
// 我們現在在這裡具有此屬性的原因僅是因為標準庫中已經存在 `Copy` 上的許多現有專長，並且目前尚無辦法安全地具有此行為。
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// 派生宏，生成 trait `Copy` 的印象。
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// 可以在線程之間共享引用的類型。
///
/// 當編譯器確定適當時，會自動實現此 trait。
///
/// 精確的定義是: 當且僅當 `&T` 是 [`Send`] 時，類型 `T` 才是 [`Sync`]。
/// 換句話說，在線程之間傳遞 `&T` 引用時，如果沒有 [undefined behavior][ub] (包括數據競爭) 的可能性。
///
/// 正如人們所期望的那樣，原始類型 (如 [`u8`] 和 [`f64`]) 都是 [`Sync`]，包含它們的簡單聚合類型 (如元組，結構和枚舉) 也是如此。
/// 基本 [`Sync`] 類型的更多示例包括 "immutable" 類型 (例如 `&T`) 以及具有簡單繼承的可變性的那些，例如 [`Box<T>`][box]，[`Vec<T>`][vec] 和大多數其他集合類型。
///
/// (通用參數必須為 [`Sync`]，容器才能為 [`Sync`。)
///
/// 該定義的一個令人驚訝的結果是 `&mut T` 是 `Sync` (如果 `T` 是 `Sync`)，即使看起來可能提供了不同步的突變。
/// 訣竅是，共享引用 (即 `& &mut T`) 後面的可變引用將變為只讀，就像 `& &T` 一樣。
/// 因此，不存在數據爭用的風險。
///
/// 不是 `Sync` 的類型是具有非線程安全形式的 "interior mutability" 的類型，例如 [`Cell`][cell] 和 [`RefCell`][refcell]。
/// 這些類型甚至允許通過不可變的共享引用來更改其內容。
/// 例如，[`Cell<T>`][cell] 上的 `set` 方法採用 `&self`，因此它僅需要共享的引用 [`&Cell<T>`][cell]。
/// 該方法不執行同步，因此 [`Cell`][cell] 不能為 `Sync`。
///
/// 非 `同步` 類型的另一個示例是引用計數指針 [`Rc`][rc]。
/// 給定任何參考 [`&Rc<T>`][rc]，您可以克隆新的 [`Rc<T>`][rc]，以非原子方式修改參考計數。
///
/// 對於確實需要線程安全的內部可變性的情況，Rust 提供 [atomic data types] 以及通過 [`sync::Mutex`][mutex] 和 [`sync::RwLock`][rwlock] 的顯式鎖定。
/// 這些類型確保任何突變都不會引起數據爭用，因此類型為 `Sync`。
/// 同樣，[`sync::Arc`][arc] 提供了 [`Rc`][rc] 的線程安全模擬。
///
/// 具有內部可變性的任何類型還必須在 value(s) 周圍使用 [`cell::UnsafeCell`][unsafecell] 包裝器，該包裝器可以通過共享引用進行更改。
/// [undefined behavior][ub] 無法做到這一點。
/// 例如，從 `&T` 到 `&mut T` 的 [`transmute`][transmute] 無效。
///
/// 有關 `Sync` 的更多詳細信息，請參見 [the Nomicon][nomicon-send-and-sync]。
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): 一旦在 `rustc_on_unimplemented` 中支持在 `rustc_on_unimplemented` 中添加註釋，並且已經擴展到檢查需求鏈中是否存在閉包，則將其擴展為 (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// 零大小類型用於標記 "act like" 擁有 `T` 的事物。
///
/// 向您的類型添加 `PhantomData<T>` 字段將告訴編譯器，您的類型的行為就像它存儲了 `T` 類型的值一樣，即使實際上並非如此。
/// 在計算某些安全屬性時會使用此信息。
///
/// 有關如何使用 `PhantomData<T>` 的更深入的說明，請參閱 [the Nomicon](../../nomicon/phantom-data.html)。
///
/// # 可怕的 gh
///
/// 儘管它們都有可怕的名稱，但 `PhantomData` 和 `幻像類型` 是相關的，但並不完全相同。幻像類型參數只是從未使用過的類型參數。
/// 在 Rust 中，這通常會導致編譯器抱怨，而解決方案是通過 `PhantomData` 添加 "dummy" 用途。
///
/// # Examples
///
/// ## 未使用的壽命參數
///
/// 可能 `PhantomData` 的最常見用例是具有未使用的生存期參數的結構，通常將其作為某些不安全代碼的一部分。
/// 例如，這是一個結構 `Slice`，它具有兩個 `*const T` 類型的指針，大概指向某個地方的數組:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// 目的是基礎數據僅在生命週期 `'a` 內有效，因此 `Slice` 不應超過 `'a`。
/// 但是，此意圖未在代碼中表達，因為沒有使用生命週期 `'a`，因此尚不清楚它適用於什麼數據。
/// 我們可以通過告訴編譯器以 `好像` * `Slice` 結構包含一個引用 `&'a T` 的方式來糾正此問題:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// 這又需要註釋 `T: 'a`，指示 `T` 中的所有引用在整個生命週期 `'a` 內都是有效的。
///
/// 初始化 `Slice` 時，只需為字段 `phantom` 提供值 `PhantomData`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## 未使用的類型參數
///
/// 有時，您可能會使用未使用的類型參數，這些參數指示結構要 "tied" 轉換為哪種數據類型，即使該數據實際上不是在結構本身中找到的也是如此。
/// 這是 [FFI] 出現此情況的示例。
/// 外部接口使用 `*mut ()` 類型的句柄來引用不同類型的 Rust 值。
/// 我們使用包裝句柄的結構 `ExternalResource` 上的幻像類型參數來跟踪 Rust 類型。
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## 所有權和掉落支票
///
/// 添加 `PhantomData<T>` 類型的字段表示您的類型擁有 `T` 類型的數據。反過來，這意味著刪除您的類型時，它可能會刪除一個或多個 `T` 類型的實例。
/// 這與 Rust 編譯器的 [drop check] 分析有關。
///
/// 如果您的結構實際上不 `擁有` `T` 類型的數據，則最好使用引用類型，例如 `PhantomData<&'a T>` (ideally) 或 `PhantomData<*const T>` (如果沒有適用期限)，以免表示所有權。
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// 編譯器內部的 trait 用於指示枚舉判別式的類型。
///
/// trait 會自動為每種類型實現，並且不會為 [`mem::Discriminant`] 添加任何保證。
/// 在 `DiscriminantKind::Discriminant` 和 `mem::Discriminant` 之間轉換是 `未定義的行為`。
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// 判別類型，必須滿足 `mem::Discriminant` 要求的 trait bounds。
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// 編譯器內部的 trait 用於確定類型是否在內部包含任何 `UnsafeCell`，但不是通過間接尋址。
///
/// 例如，這會影響該類型的 `static` 是否放置在只讀靜態存儲器或可寫靜態存儲器中。
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// 固定後可以安全移動的類型。
///
/// Rust 本身沒有固定類型的概念，並認為移動 (例如，通過賦值或 [`mem::replace`]) 始終是安全的。
///
/// [`Pin`][Pin] 類型代替使用，以防止在類型系統中移動。[`Pin<P<T>>`][Pin] 包裝器中包裹的指針 `P<T>` 不能移出。
/// 有關固定的更多信息，請參見 [`pin` module] 文檔。
///
/// 為 `T` 實現 `Unpin` trait 消除了固定該類型的限制，然後允許使用諸如 [`mem::replace`] 之類的功能將 `T` 從 [`Pin<P<T>>`][Pin] 中移出。
///
///
/// `Unpin` 對於非固定數據完全沒有影響。
/// 特別是，[`mem::replace`] 可以愉快地移動 `!Unpin` 數據 (它適用於任何 `&mut T`，而不僅限於 `T: Unpin`)。
/// 但是，您不能在 [`Pin<P<T>>`][Pin] 內包裝的數據上使用 [`mem::replace`]，因為您無法獲得所需的 `&mut T`，並且 *that* 是使此系統正常工作的原因。
///
/// 因此，例如，這只能在實現 `Unpin` 的類型上完成:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // 我們需要一個可變的引用來調用 `mem::replace`。
/// // 我們可以通過 (implicitly) 調用 `Pin::deref_mut` 來獲得這樣的引用，但這僅是因為 `String` 實現了 `Unpin`。
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait 幾乎針對每種類型自動實現。
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// 沒有實現 `Unpin` 的標記類型。
///
/// 如果類型包含 `PhantomPinned`，則默認情況下將不實現 `Unpin`。
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy` 的基本類型的實現。
///
/// X0X 中的 `traits::SelectionContext::copy_clone_conditions()` 中實現了 Rust 中無法描述的實現。
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// 共享引用可以被複製，但是可變引用 *不能*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}