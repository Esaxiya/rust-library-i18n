use crate::iter::FromIterator;

/// 將所有單元項從一個迭代器折疊為一個。
///
/// 與更高級別的抽象結合使用時，此功能尤其有用，例如收集到僅關心錯誤的 `Result<(), E>` 上:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}