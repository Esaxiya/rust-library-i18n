//! 字符串 Pattern API。
//!
//! 模式 API 提供了一種通用機制，用於在搜索字符串時使用不同的模式類型。
//!
//! 有關更多詳細信息，請參見 traits [`Pattern`]，[`Searcher`]，[`ReverseSearcher`] 和 [`DoubleEndedSearcher`]。
//!
//! 儘管此 API 不穩定，但是它通過 [`str`] 類型的穩定 API 公開。
//!
//! # Examples
//!
//! [`Pattern`] 是 [implemented][pattern-impls]，[`char`] 的片段以及實現 `FnMut(char) -> bool` 的函數和閉包的穩定 API 中的 [implemented][pattern-impls]。
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // 字符模式
//! assert_eq!(s.find('n'), Some(2));
//! // 切片的字符模式
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // 封閉模式
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// 字符串模式。
///
/// `Pattern<'a>` 表示實現類型可以用作在 [`&'a str`][str] 中搜索的字符串模式。
///
/// 例如，`'a'` 和 `"aa"` 都是在字符串 `"baaaab"` 中的索引 `1` 處匹配的模式。
///
/// trait 本身充當關聯的 [`Searcher`] 類型的構建器，該類型實際執行查找字符串中模式出現的實際工作。
///
///
/// 根據模式的類型，諸如 [`str::find`] 和 [`str::contains`] 之類的方法的行為可能會改變。
/// 下表描述了其中一些行為。
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// 此模式的關聯搜索者
    type Searcher: Searcher<'a>;

    /// 從 `self` 和 `haystack` 構造關聯的搜索器以進行搜索。
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// 檢查模式是否與大海撈針中的任何位置匹配
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// 檢查圖案是否在乾草堆的前面匹配
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// 檢查圖案是否在乾草堆的背面匹配
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// 如果匹配，則從乾草堆的前部除去圖案。
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // 安全: 已知 `Searcher` 返回有效索引。
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// 如果匹配，則從乾草堆的背面刪除圖案。
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // 安全: 已知 `Searcher` 返回有效索引。
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// 調用 [`Searcher::next()`] 或 [`ReverseSearcher::next_back()`] 的結果。
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// 表示已在 `haystack[a..b]` 找到匹配的模式。
    ///
    Match(usize, usize),
    /// 表示已拒絕 `haystack[a..b]` 作為該模式的可能匹配。
    ///
    /// 注意，兩個 `Match` 之間可能有多個 `Reject`，不需要將它們組合為一個。
    ///
    ///
    Reject(usize, usize),
    /// 表示已經訪問了乾草堆的每個字節，從而結束了迭代。
    ///
    Done,
}

/// 字符串模式的搜索者。
///
/// trait 提供了從字符串的開頭 (left) 開始搜索模式的非重疊匹配的方法。
///
/// 將通過 [`Pattern`] trait 的關聯 `Searcher` 類型實現。
///
/// trait 被標記為不安全，因為需要 [`next()`][Searcher::next] 方法返回的索引位於乾草堆中的有效 utf8 邊界上。
/// 這使 trait 的使用者可以對乾草堆進行切片，而無需進行其他運行時檢查。
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter 查找要在其中搜索的基礎字符串
    ///
    /// 總是返回相同的 [`&str`][str]。
    fn haystack(&self) -> &'a str;

    /// 從頭開始執行下一個搜索步驟。
    ///
    /// - 如果 `haystack[a..b]` 與模式匹配，則返回 [`Match(a, b)`][SearchStep::Match]。
    /// - 如果 `haystack[a..b]` 甚至部分不匹配，則返回 [`Reject(a, b)`][SearchStep::Reject]。
    /// - 如果已經訪問過乾草堆的每個字節，則返回 [`Done`][SearchStep::Done]。
    ///
    /// 直到 [`Done`][SearchStep::Done] 的 [`Match`][SearchStep::Match] 和 [`Reject`][SearchStep::Reject] 值流將包含相鄰，不重疊，覆蓋整個乾草堆並位於 utf8 邊界上的索引範圍。
    ///
    ///
    /// [`Match`][SearchStep::Match] 結果需要包含整個匹配的模式，但是 [`Reject`][SearchStep::Reject] 結果可以分為任意多個相鄰的片段。兩個範圍的長度都可以為零。
    ///
    /// 例如，模式 `"aaa"` 和乾草堆 `"cbaaaaab"` 可能會產生流
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// 查找下一個 [`Match`][SearchStep::Match] 結果。請參閱 [`next()`][Searcher::next]。
    ///
    /// 與 [`next()`][Searcher::next] 不同，不能保證此和 [`next_reject`][Searcher::next_reject] 的返回範圍會重疊。
    /// 這將返回 `(start_match, end_match)`，其中 start_match 是比賽開始的索引，end_match 是比賽結束後的索引。
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// 查找下一個 [`Reject`][SearchStep::Reject] 結果。請參閱 [`next()`][Searcher::next] 和 [`next_match()`][Searcher::next_match]。
    ///
    /// 與 [`next()`][Searcher::next] 不同，不能保證此和 [`next_match`][Searcher::next_match] 的返回範圍會重疊。
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// 反向搜索字符串模式。
///
/// trait 提供了從字符串的後 (right) 開始搜索模式的非重疊匹配的方法。
///
/// 如果該模式支持從背面搜索它，則將通過 [`Pattern`] trait 的關聯 [`Searcher`] 類型實現。
///
///
/// trait 返回的索引範圍不需要與反向搜索的正向搜索完全匹配。
///
/// 由於該 trait 被標記為不安全的原因，請參見其父級 trait [`Searcher`]。
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// 從背面開始執行下一個搜索步驟。
    ///
    /// - 如果 `haystack[a..b]` 與模式匹配，則返回 [`Match(a, b)`][SearchStep::Match]。
    /// - 如果 `haystack[a..b]` 甚至部分不匹配，則返回 [`Reject(a, b)`][SearchStep::Reject]。
    /// - 如果已經訪問過乾草堆的每個字節，則返回 [`Done`][SearchStep::Done]
    ///
    /// 直到 [`Done`][SearchStep::Done] 的 [`Match`][SearchStep::Match] 和 [`Reject`][SearchStep::Reject] 值流將包含相鄰，不重疊，覆蓋整個乾草堆並位於 utf8 邊界上的索引範圍。
    ///
    ///
    /// [`Match`][SearchStep::Match] 結果需要包含整個匹配的模式，但是 [`Reject`][SearchStep::Reject] 結果可以分為任意多個相鄰的片段。兩個範圍的長度都可以為零。
    ///
    /// 例如，模式 `"aaa"` 和乾草堆 `"cbaaaaab"` 可能會產生流 `[Reject(7, 8)，Match(4, 7)，Reject(1, 4)， Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// 查找下一個 [`Match`][SearchStep::Match] 結果。
    /// 請參閱 [`next_back()`][ReverseSearcher::next_back]。
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// 查找下一個 [`Reject`][SearchStep::Reject] 結果。
    /// 請參閱 [`next_back()`][ReverseSearcher::next_back]。
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// 標記 trait 表示 [`ReverseSearcher`] 可用於 [`DoubleEndedIterator`] 實現。
///
/// 為此，[`Searcher`] 和 [`ReverseSearcher`] 的暗示需要遵循以下條件:
///
/// - `next()` 的所有結果必須與 `next_back()` 的結果相反 (順序相反)。
/// - `next()` 和 `next_back()` 需要表現為一個值範圍的兩端，也就是說它們不能 "walk past each other"。
///
/// # Examples
///
/// `char::Searcher` 是 `DoubleEndedSearcher`，因為搜索 [`char`] 只需要一次查看一次，因此兩端的行為相同。
///
/// `(&str)::Searcher` 不是 `DoubleEndedSearcher`，因為乾草堆 `"aaa"` 中的模式 `"aa"` 匹配為 `"[aa]a"` 或 `"a[aa]"`，具體取決於從哪一側搜索。
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// 字符的 Impl
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` 的關聯類型。
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // 安全不變量: `finger`/`finger_back` 必須是 `haystack` 的有效 utf8 字節索引。可以在 *next_match 和 next_match_back 之內* 破壞該不變量，但是它們必須在有效的代碼點邊界上用手指退出。
    //
    //
    /// `finger` 是正向搜索的當前字節索引。
    /// 想像一下，它存在於其索引的字節之前，即
    /// `haystack[finger]` 是在前向搜索期間必須檢查的片的第一個字節
    ///
    finger: usize,
    /// `finger_back` 是反向搜索的當前字節索引。
    /// 想像一下，它存在於其索引的字節之後，即
    /// haystack [finger_back，1] 是在前向搜索期間必須檢查的片的最後一個字節 (因此是調用 next_back()) 時要檢查的第一個字節)。
    ///
    finger_back: usize,
    /// 要搜索的字符
    needle: char,

    // 安全不變式: `utf8_size` 必須小於 5
    /// 當用 utf8 編碼時，`needle` 佔用的字節數。
    utf8_size: usize,
    /// `needle` 的 utf8 編碼副本
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // 安全: 1-4 保證 `get_unchecked` 的安全
        // 1. `self.finger` 和 `self.finger_back` 保持在 unicode 邊界上 (這是不變的)
        // 2. `self.finger >= 0` 因為它從 0 開始並且僅增加
        // 3. `self.finger < self.finger_back` 因為否則 char `iter` 將返回 `SearchStep::Done`
        // 4.
        // `self.finger` 在乾草堆結束之前出現，因為 `self.finger_back` 從結尾開始並且僅減少
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // 添加當前字符的字節偏移，而無需重新編碼為 utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // 找到最後一個字符後得到大海撈針
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 編碼的指針安全性的最後一個字節: `utf8_size < 5` 不變
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // 新手指是我們找到的字節的索引加一個，因為我們對字符的最後一個字節進行了記憶。
                //
                // 請注意，這並不總是使我們能夠了解 UTF8 的邊界。
                // 如果沒有找到我們的字符，我們可能已索引到 3 字節或 4 字節字符的非最後一個字節。
                // 我們不能只跳到下一個有效的起始字節，因為諸如ꁁ (U + A041 YI SYLLABLE PA)，utf-8 `EA 81 81` 之類的字符會在搜索第三個字節時始終使我們找到第二個字節。
                //
                //
                // 但是，這完全可以。
                // 儘管我們擁有 self.finger 在 UTF8 邊界上的不變性，但此方法不依賴此不變性 (在 CharSearcher::next()) 中是依賴不變的)。
                //
                // 僅當到達字符串末尾或找到某些內容時，才退出此方法。當我們發現某些東西時，`finger` 將被設置為 UTF8 邊界。
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // 一無所獲，退出
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // 讓 next_reject 使用搜索器 trait 的默認實現
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // 安全: 請參閱上面對 next() 的評論
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // 減去當前字符的字節偏移，而無需重新編碼為 utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // 使大海撈針達到但不包括搜索到的最後一個字符
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 編碼的指針安全性的最後一個字節: `utf8_size < 5` 不變
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // 我們搜索了一個被 self.finger 偏移的切片，添加 self.finger 以補償原始索引
                //
                let index = self.finger + index;
                // memrchr 將返回我們希望找到的字節的索引。
                // 如果是 ASCII 字符，這確實是我們希望的新手指 ("after" 是反向迭代範式中找到的 char)。
                //
                // 對於多字節字符，我們需要跳過的字節數比 ASCII 多
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // 將手指移到找到的字符之前 (即，在其起始索引處)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // 我們不能在這裡使用 finger_back=index，size + 1。
                // 如果找到不同大小字符的最後一個字符 (或不同字符的中間字節)，則需要將 finger_back 降低到 `index`。
                // 同樣，這使 `finger_back` 不再有可能位於邊界上，但這是可以的，因為我們僅在邊界上或在完全搜索完乾草堆後才退出此函數。
                //
                //
                // 與 next_match 不同，這不存在 utf-8 中重複字節的問題，因為我們正在搜索最後一個字節，並且僅當反向搜索時才可以找到最後一個字節。
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // 一無所獲，退出
                return None;
            }
        }
    }

    // 讓 next_reject_back 使用 Searcher trait 中的默認實現
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// 搜索等於給定 [`char`] 的字符。
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// 用於 MultiCharEq 包裝器的 Impl
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // 比較內部字節切片迭代器的長度以找到當前 char 的長度
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // 比較內部字節切片迭代器的長度以找到當前 char 的長度
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl 表示＆[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: 由於含糊不清，請更改 / 刪除。

/// `<&[char] as Pattern<'a>>::Searcher` 的關聯類型。
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// 搜索等於切片中任何 [`char`] s 的字符。
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F 的 Impl: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` 的關聯類型。
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// 搜索與給定謂詞匹配的 [`char`]。
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str 的 Impl
/////////////////////////////////////////////////////////////////////////////

/// 代表 `&str` impl。
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str 的 Impl
/////////////////////////////////////////////////////////////////////////////

/// 非分配子字符串搜索。
///
/// 將模式 `""` 處理為在每個字符邊界處返回空匹配項。
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// 檢查圖案是否在乾草堆的前面匹配。
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// 如果匹配，則從乾草堆的前部除去圖案。
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // 安全: 前綴已被驗證存在。
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// 檢查圖案是否在乾草堆的背面匹配。
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// 如果匹配，則從乾草堆的背面刪除圖案。
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // 安全: 後綴剛剛被驗證為存在。
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// 兩路子串搜索器
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` 的關聯類型。
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // 空針拒絕每個字符並匹配它們之間的每個空字符串
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher 會生成有效的 *Match* 索引，只要它能夠正確匹配並且在乾草邊界和乾草堆都是有效的 UTF-8 *Rejects* 可以落在任何索引上，但它們會在 char 邊界處分割，但是我們將手動將它們移至下一個字符邊界，以便它們是 utf-8 安全的。
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // 跳到下一個字符邊界
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // 寫出 `true` 和 `false` 的情況，以鼓勵編譯器分別專門處理這兩種情況。
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // 跳到下一個字符邊界
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // 寫出 `true` 和 `false`，例如 `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// 雙向子字符串搜索算法的內部狀態。
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// 臨界分解指數
    crit_pos: usize,
    /// 倒針的臨界分解指數
    crit_pos_back: usize,
    period: usize,
    /// `byteset` 是擴展 (不是雙向算法的一部分) ;
    /// 它是一個 64 位 "fingerprint"，其中每個設置位 `j` 對應於針中存在的 (字節＆63) ==j。
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// 索引到我們已經匹配過的針
    memory: usize,
    /// 索引到針之後，我們已經匹配了
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // 關於發生的事情的特別可讀的解釋可以在 Crochemore 和 Rytter 的書 "Text Algorithms"，第 13 章中找到。
        // 具體請參見第 40 頁的 "Algorithm CP" 的代碼。
        // 323.
        //
        // 這是怎麼回事，我們有一些關鍵的因數分解 (u，v)，我們想確定 u 是否為＆v [.. period] 的後綴。
        // 如果是這樣，我們使用 "Algorithm CP1"。
        // 否則，我們將使用 "Algorithm CP2"，這是針對針的周期較大而優化的。
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // 短期情況下-週期是精確的，需要為倒針 x=u'v' 計算一個單獨的臨界分解，其中 | v'|<period(x)。
            //
            // 這已經被已知的時期加快了。
            // 請注意，x= "acba" 之類的情況可以正好分解為因數 (crit_pos=1，期間 = 3)，而可以由近似的逆向因數 (crit_pos=2，期間 = 2) 進行分解。
            // 我們使用給定的逆因式分解，但要保留精確的周期。
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // 長期情況 - 我們近似於實際時間，請勿使用記憶。
            //
            //
            // 用下限 max(|u|, |v|) +1 估算週期。
            // 臨界分解有效地用於正向搜索和反向搜索。
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // 虛擬值表示週期長
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // `雙向` 的主要思想之一是，將針分解成兩半 (u，v)，並開始嘗試通過從左到右掃描在大海撈針中尋找 v。
    // 如果 v 匹配，我們嘗試通過從右到左掃描來匹配 u。
    // 當我們遇到不匹配時，我們可以跳多遠，這全都基於以下事實: (u，v) 是針的關鍵分解因數。
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` 使用 `self.position` 作為其光標
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // 如果我們假設切片以 isize 的範圍為邊界，請檢查我們在位置上是否有空間可以搜索 + needle_last 不會溢出。
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // 快速跳過與子字符串無關的大部分內容
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // 看看針的右邊是否匹配
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // 看看針頭的左部分是否匹配
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // 我們找到了一場比賽!
            let match_pos = self.position;

            // Note: 添加 self.period 而不是 needle.len() 以具有重疊的匹配項
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // 設置為 needle.len()，self.period 進行重疊匹配
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // 遵循 `next()` 中的思想。
    //
    // 這些定義是對稱的，其中 period(x) = period(reverse(x)) 且 local_period(u, v) = local_period(reverse(v)，reverse(u))，因此，如果 (u，v) 是關鍵分解，則 (reverse(v) 也是， reverse(u)).
    //
    //
    // 對於相反的情況，我們已經計算出臨界分解係數 x=u'v' (字段 `crit_pos_back`)。我們需要 | u |<period(x) 對於前移情況，因此 | v'|<period(x) 反之。
    //
    // 要反向搜索大海撈針，我們先搜索帶有反向針的反向大海撈針，首先匹配 u'，然後匹配 v'。
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` 使用 `self.end` 作為其光標 - `next()` 和 `next_back()` 是獨立的。
        //
        let old_end = self.end;
        'search: loop {
            // 檢查我們是否有足夠的搜索空間，如果沒有更多空間，needle.len() 將會環繞，但是由於切片長度的限制，它永遠無法一直纏繞到干草堆的長度中。
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // 快速跳過與子字符串無關的大部分內容
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // 看看針頭的左部分是否匹配
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // 看看針的右邊是否匹配
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // 我們找到了一場比賽!
            let match_pos = self.end - needle.len();
            // Note: 子 self.period 而不是 needle.len() 具有重疊的匹配項
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // 計算 `arr` 的最大後綴。
    //
    // 最大後綴是 `arr` 的可能的關鍵因式分解 (u，v)。
    //
    // 返回 (`i`，`p`) 其中 `i` 是 v 的起始索引，`p` 是 v 的周期。
    //
    // `order_greater` 確定詞法順序是 `<` 還是 `>`。
    // 必須計算兩個階數 - `i` 最大的階數給出了關鍵的因式分解。
    //
    //
    // 對於長時間的情況，結果週期不精確 (太短)。
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // 對應論文中的 i
        let mut right = 1; // 對應論文 j
        let mut offset = 0; // 對應於論文中的 k，但從 0 開始
        // 匹配基於 0 的索引。
        let mut period = 1; // 對應於論文中的 p

        while let Some(&a) = arr.get(right + offset) {
            // `left` 當 `right` 是時，將入站。
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // 後綴較小，到目前為止是整個前綴。
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // 通過重複當前期間前進。
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // 後綴較大，請從當前位置重新開始。
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // 計算 `arr` 倒數的最大後綴。
    //
    // 最大後綴是 `arr` 的可能的關鍵因式分解 (u'，v')。
    //
    // 從後面返回 `i`，其中 `i` 是 v' 的起始索引;
    // 到達 `known_period` 週期時立即返回。
    //
    // `order_greater` 確定詞法順序是 `<` 還是 `>`。
    // 必須計算兩個階數 - `i` 最大的階數給出了關鍵的因式分解。
    //
    //
    // 對於長時間的情況，結果週期不精確 (太短)。
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // 對應論文中的 i
        let mut right = 1; // 對應論文 j
        let mut offset = 0; // 對應於論文中的 k，但從 0 開始
        // 匹配基於 0 的索引。
        let mut period = 1; // 對應於論文中的 p
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // 後綴較小，到目前為止是整個前綴。
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // 通過重複當前期間前進。
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // 後綴較大，請從當前位置重新開始。
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy 允許該算法盡快跳過不匹配項，或者以相對較快地發出 `拒絕` 的模式工作。
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// 跳過以盡快匹配間隔
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// 定期發射拒絕
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}