//! 定義 utf8 錯誤類型。

use crate::fmt;

/// 嘗試將 [`u8`] 的序列解釋為字符串時可能發生的錯誤。
///
/// 這樣，例如 [`String`] 和 [`＆str`] 的 `from_utf8` 系列函數和方法都利用了此錯誤。
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// 此錯誤類型的方法可用於創建類似於 `String::from_utf8_lossy` 的功能，而無需分配堆內存:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// 返回給定字符串中的索引，直到對其進行有效 UTF-8 驗證為止。
    ///
    /// 它是使 `from_utf8(&input[..index])` 返回 `Ok(_)` 的最大索引。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector 中的一些無效字節
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 返回 Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // 第二個字節在這裡無效
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// 提供有關失敗的更多信息:
    ///
    /// * `None`: 輸入的末尾意外到達。
    ///   `self.valid_up_to()` 從輸入末尾開始是 1 到 3 個字節。
    ///   如果字節流 (例如文件或網絡套接字) 正在以增量方式進行解碼，則這可能是有效的 `char`，其 UTF-8 字節序列跨越了多個塊。
    ///
    ///
    /// * `Some(len)`: 遇到意外的字節。
    ///   提供的長度是從 `valid_up_to()` 給定的索引處開始的無效字節序列的長度。
    ///   如果有損解碼，則應在該序列之後 (插入 [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] 之後) 恢復解碼。
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// 使用 [`from_str`] 解析 `bool` 失敗時返回錯誤
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}