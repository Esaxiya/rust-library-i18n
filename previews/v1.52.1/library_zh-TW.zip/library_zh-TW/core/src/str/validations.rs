//! 與 UTF-8 驗證有關的操作。

use crate::mem;

use super::Utf8Error;

/// 返回第一個字節的初始代碼點累加器。
/// 第一個字節是特殊的，寬度 2 的最低 5 位，寬度 3 的 4 位，寬度 4 的 3 位。
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// 返回用連續字節 `byte` 更新的 `ch` 的值。
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// 檢查該字節是否是 UTF-8 連續字節 (即，從 `10` 位開始)。
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// 從字節迭代器中讀取下一個代碼點 (假定類似 UTF-8 的編碼)。
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // 解碼 UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // 從以下字節組合中解碼出多字節大小寫: [[[x y] z] w]
    //
    // NOTE: 性能對此處的確切公式很敏感
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] 情況
        // 0xE0 中的第 5 位.. 0xEF 總是清零的，因此 `init` 仍然有效
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] 情況下僅使用 `init` 的低 3 位
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// 從字節迭代器中讀取最後一個代碼點 (假定類似 UTF-8 的編碼)。
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // 解碼 UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // 從以下字節組合解碼出多字節大小寫: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// 使用截斷以使 u64 適應 usize
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// 如果單詞 `x` 中的任何字節為 nonascii (>=128)，則返回 `true`。
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// 遍歷 `v` 並檢查其是否為有效的 UTF-8 序列，在這種情況下返回 `Ok(())`，或者如果無效，則返回 `Ok(())` `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // 我們需要數據，但沒有數據: 錯誤!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2 字節編碼用於 \u {0080} 至 \u {07ff} 的代碼點，第一個 C2 80 最後一個 DF BF
            // 3 字節編碼適用於 \u {0800} 至 \u {ffff} 的代碼點，第一個 E0 A0 80 最後一個 EF BF BF，不包括替代代碼點 \u {d800} 至 \u {dfff} ED A0 80 到 ED BF BF
            // 4 字節編碼用於 \u {1000} 0 到 \u {10ff} ff 的代碼點首先 F0 90 80 80 最後 F4 8F BF BF
            //
            // 使用 RFC 中的 UTF-8 語法
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=％x00-7F UTF8-2=％xC2-DF UTF8 尾 UTF8-3= %xE0％xA0-BF UTF8 尾 /％xE1-EC 2( UTF8-tail )/%xED％x80-9F UTF8 尾 /％xEE-EF 2( UTF8-tail ) UTF8-4= %xF0％x90-BF 2( UTF8-tail )/％xF1-F3 3( UTF8-tail )/%xF4％x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // ASCII 的情況下，請嘗試快速跳過。
            // 當指針對齊時，每次迭代讀取 2 個字的數據，直到找到包含非 ASCII 字節的字。
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // 安全: 因為 `align - index` 和 `ascii_block_size` 是
                    // `block = ptr.add(index)` 的倍數始終與 `usize` 對齊，因此可以安全地取消引用 `block` 和 `block.offset(1)`。
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // 如果有一個非 ASCII 字節則中斷
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // 從逐字循環停止的位置開始
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// 給定第一個字節，確定此 UTF-8 字符中有多少個字節。
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// 連續字節的值位的掩碼。
const CONT_MASK: u8 = 0b0011_1111;
/// 連續字節的標記位 (標記掩碼為 !CONT_MASK) 的值。
const TAG_CONT_U8: u8 = 0b1000_0000;

// 將 `&str` 截斷為最大長度 (等於 `max`) (如果被截斷，則返回 `true`)，並返回新的 str。
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}