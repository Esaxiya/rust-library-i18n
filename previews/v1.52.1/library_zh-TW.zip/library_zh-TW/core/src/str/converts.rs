//! 從字節片創建 `str` 的方法。

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// 將字節片轉換為字符串片。
///
/// 字符串片 ([`&str`]) 由字節 ([`u8`]) 組成，字節片 ([`&[u8]`][byteslice]) 由字節組成，因此此函數在兩者之間進行轉換。
/// 並非所有的字節片都是有效的字符串片，但是: [`&str`] 要求它是有效的 UTF-8。
/// `from_utf8()` 檢查以確保字節有效 UTF-8，然後進行轉換。
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// 如果您確定字節片是有效的 UTF-8，並且不想招致有效性檢查的開銷，則此功能有一個不安全的版本 [`from_utf8_unchecked`]，它具有相同的行為，但是會跳過該檢查。
///
///
/// 如果需要 `String` 而不是 `&str`，請考慮使用 [`String::from_utf8`][string]。
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// 因為可以堆棧分配 `[u8; N]`，也可以採用 `[u8; N]`，所以此函數是具有堆棧分配的字符串的一種方法。在下面的示例部分中有一個示例。
///
/// [byteslice]: slice
///
/// # Errors
///
/// 如果切片不是 UTF-8，則返回 `Err`，並說明為什麼提供的切片不是 UTF-8。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::str;
///
/// // vector 中的一些字節
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // 我們知道這些字節是有效的，因此只需使用 `unwrap()`。
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// 字節不正確:
///
/// ```
/// use std::str;
///
/// // vector 中的一些無效字節
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// 有關可以返回的錯誤類型的更多詳細信息，請參閱 [`Utf8Error`] 文檔。
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // 堆棧分配的數組中的一些字節
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // 我們知道這些字節是有效的，因此只需使用 `unwrap()`。
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // 安全: 只需運行驗證即可。
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// 將可變的字節片轉換為可變的字符串片。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" 作為可變的 vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // 我們知道這些字節是有效的，因此我們可以使用 `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// 字節不正確:
///
/// ```
/// use std::str;
///
/// // 可變的 vector 中的一些無效字節
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// 有關可以返回的錯誤類型的更多詳細信息，請參閱 [`Utf8Error`] 文檔。
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // 安全: 只需運行驗證即可。
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// 將字節片轉換為字符串片，而無需檢查字符串是否包含有效的 UTF-8。
///
/// 有關更多信息，請參見安全版本 [`from_utf8`]。
///
/// # Safety
///
/// 此功能不安全，因為它不檢查傳遞給它的字節是否為有效的 UTF-8。
/// 如果違反了此約束，則將導致未定義的行為，因為 Rust 的其餘部分都假定 [`＆str`] 是有效的 UTF-8。
///
///
/// [`&str`]: str
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::str;
///
/// // vector 中的一些字節
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // 安全: 調用者必須保證字節 `v` 是有效的 UTF-8。
    // 還依賴於 `&str` 和 `&[u8]` 具有相同的佈局。
    unsafe { mem::transmute(v) }
}

/// 在不檢查字符串包含有效 UTF-8 的情況下將字節的片轉換為字符串片; 可變版本。
///
///
/// 有關更多信息，請參見不可變版本 [`from_utf8_unchecked()`]。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // 安全: 調用者必須保證字節 `v`
    // 是有效的 UTF-8，因此強制轉換為 `*mut str` 是安全的。
    // 而且，指針取消引用是安全的，因為該指針來自保證對寫有效的引用。
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}