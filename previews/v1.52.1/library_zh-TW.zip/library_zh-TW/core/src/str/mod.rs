//! 字符串操作。
//!
//! 有關更多詳細信息，請參見 [`std::str`] 模塊。
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. 越界
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. 開始 <= 結束
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. 角色邊界
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // 找到角色
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` 必須小於 len 和 char 邊界
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// 返回 `self` 的長度。
    ///
    /// 該長度以字節為單位，而不是 [`char`] 或字素。
    /// 換句話說，可能不是人們認為弦的長度。
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // 看中 f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// 如果 `self` 的長度為零字節，則返回 `true`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 檢查第 index 個字節是 UTF-8 代碼點序列中的第一個字節還是字符串的末尾。
    ///
    ///
    /// 字符串的開頭和結尾 (當 `index== self.len()`) 被視為邊界時。
    ///
    /// 如果 `index` 大於 `self.len()`，則返回 `false`。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` 的開始
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` 的第二個字節
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` 的第三個字節
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 和 len 總是可以的。
        // 顯式測試 0，以便可以輕鬆優化檢查，並在這種情況下跳過讀取字符串數據。
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // 這有點神奇，等於: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// 將字符串切片轉換為字節切片。
    /// 要將字節片轉換回字符串片，請使用 [`from_utf8`] 函數。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // 安全: const sound 是因為我們用相同的佈局轉換了兩種類型
        unsafe { mem::transmute(self) }
    }

    /// 將可變字符串片轉換為可變字節片。
    ///
    /// # Safety
    ///
    /// 調用方必須確保在藉用結束和使用基礎 `str` 之前，切片的內容是有效的 UTF-8。
    ///
    ///
    /// 使用內容無效的 `str` UTF-8 是未定義的行為。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // 安全: 由於 `str`，從 `&str` 到 `&[u8]` 的轉換是安全的
        // 與 `&[u8]` 具有相同的佈局 (只有 libstd 可以保證此保證)。
        // 指針取消引用是安全的，因為它來自可變引用，該引用保證對寫入有效。
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// 將字符串切片轉換為原始指針。
    ///
    /// 由於字符串片是字節的片，原始指針指向 [`u8`]。
    /// 該指針將指向字符串切片的第一個字節。
    ///
    /// 調用者必須確保返回的指針永遠不會被寫入。
    /// 如果需要更改字符串切片的內容，請使用 [`as_mut_ptr`]。
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// 將可變的字符串切片轉換為原始指針。
    ///
    /// 由於字符串片是字節的片，原始指針指向 [`u8`]。
    /// 該指針將指向字符串切片的第一個字節。
    ///
    /// 您有責任確保僅以保持有效 UTF-8 的方式修改字符串切片。
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// 返回 `str` 的子切片。
    ///
    /// 這是索引 `str` 的非緊急選擇。
    /// 只要等效的索引操作為 panic，就返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // 索引不在 UTF-8 序列邊界上
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // 越界
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// 返回 `str` 的可變子切片。
    ///
    /// 這是索引 `str` 的非緊急選擇。
    /// 只要等效的索引操作為 panic，就返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // 正確的長度
    /// assert!(v.get_mut(0..5).is_some());
    /// // 越界
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// 返回未經檢查的 `str` 子切片。
    ///
    /// 這是索引 `str` 的未經檢查的替代方法。
    ///
    /// # Safety
    ///
    /// 此函數的調用者有責任滿足以下先決條件:
    ///
    /// * 起始索引不得超過結束索引;
    /// * 索引必須在原始切片的範圍內;
    /// * 索引必須位於 UTF-8 序列邊界上。
    ///
    /// 失敗的是，返回的字符串片可能引用了無效的內存或違反了 `str` 類型傳達的不變式。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // 安全: 调用者必須遵守 `get_unchecked` 的安全合同;
        // 該切片是可取消引用的，因為 `self` 是安全的引用。
        // 返回的指針是安全的，因為 `SliceIndex` 的 impls 必須保證它是正確的。
        unsafe { &*i.get_unchecked(self) }
    }

    /// 返回 `str` 的可變，未經檢查的子切片。
    ///
    /// 這是索引 `str` 的未經檢查的替代方法。
    ///
    /// # Safety
    ///
    /// 此函數的調用者有責任滿足以下先決條件:
    ///
    /// * 起始索引不得超過結束索引;
    /// * 索引必須在原始切片的範圍內;
    /// * 索引必須位於 UTF-8 序列邊界上。
    ///
    /// 失敗的是，返回的字符串片可能引用了無效的內存或違反了 `str` 類型傳達的不變式。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // 安全: 调用者必須遵守 `get_unchecked_mut` 的安全合同;
        // 該切片是可取消引用的，因為 `self` 是安全的引用。
        // 返回的指針是安全的，因為 `SliceIndex` 的 impls 必須保證它是正確的。
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// 從另一個字符串切片創建一個字符串切片，繞過安全檢查。
    ///
    /// 通常不建議這樣做，請謹慎使用! 有關安全的替代方法，請參見 [`str`] 和 [`Index`]。
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// 這個新切片從 `begin` 到 `end`，包括 `begin` 但不包括 `end`。
    ///
    /// 要獲取可變的字符串切片，請參見 [`slice_mut_unchecked`] 方法。
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// 此函數的調用者有責任滿足三個先決條件:
    ///
    /// * `begin` 不得超過 `end`。
    /// * `begin` `end` 和 `end` 必須在字符串切片內的字節位置。
    /// * `begin` 和 `end` 必須位於 UTF-8 序列邊界上。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // 安全: 调用者必須遵守 `get_unchecked` 的安全合同;
        // 該切片是可取消引用的，因為 `self` 是安全的引用。
        // 返回的指針是安全的，因為 `SliceIndex` 的 impls 必須保證它是正確的。
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// 從另一個字符串切片創建一個字符串切片，繞過安全檢查。
    /// 通常不建議這樣做，請謹慎使用! 有關安全的替代方法，請參見 [`str`] 和 [`IndexMut`]。
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// 這個新切片從 `begin` 到 `end`，包括 `begin` 但不包括 `end`。
    ///
    /// 要獲取不可變的字符串切片，請參見 [`slice_unchecked`] 方法。
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// 此函數的調用者有責任滿足三個先決條件:
    ///
    /// * `begin` 不得超過 `end`。
    /// * `begin` `end` 和 `end` 必須在字符串切片內的字節位置。
    /// * `begin` 和 `end` 必須位於 UTF-8 序列邊界上。
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // 安全: 调用者必須遵守 `get_unchecked_mut` 的安全合同;
        // 該切片是可取消引用的，因為 `self` 是安全的引用。
        // 返回的指針是安全的，因為 `SliceIndex` 的 impls 必須保證它是正確的。
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// 在索引處將一個字符串切片分成兩個。
    ///
    /// 參數 `mid` 應該是字符串開頭的字節偏移量。
    /// 它也必須在 UTF-8 代碼點的邊界上。
    ///
    /// 返回的兩個片從字符串片的開頭到 `mid`，從 `mid` 到字符串片的結尾。
    ///
    /// 要獲取可變的字符串切片，請參見 [`split_at_mut`] 方法。
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics，如果 `mid` 不在 UTF-8 代碼點邊界上，或者超過字符串切片的最後一個代碼點的末尾。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary 檢查索引是否在 [0， .len()]
        if self.is_char_boundary(mid) {
            // 安全: 剛剛檢查 `mid` 是否在 char 邊界上。
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// 在索引處將一個可變的字符串切片分為兩個。
    ///
    /// 參數 `mid` 應該是字符串開頭的字節偏移量。
    /// 它也必須在 UTF-8 代碼點的邊界上。
    ///
    /// 返回的兩個片從字符串片的開頭到 `mid`，從 `mid` 到字符串片的結尾。
    ///
    /// 要獲取不可變的字符串切片，請參見 [`split_at`] 方法。
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics，如果 `mid` 不在 UTF-8 代碼點邊界上，或者超過字符串切片的最後一個代碼點的末尾。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary 檢查索引是否在 [0， .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // 安全: 剛剛檢查 `mid` 是否在 char 邊界上。
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// 返回字符串切片的 [`char`] 上的迭代器。
    ///
    /// 由於字符串切片由有效的 UTF-8 組成，因此我們可以通過 [`char`] 遍歷字符串切片。
    /// 此方法返回這樣的迭代器。
    ///
    /// 重要的是要記住，[`char`] 代表 Unicode 標量值，可能與您對 'character' 的想法不符。
    ///
    /// 字素簇的迭代可能是您真正想要的。
    /// Rust 的標準庫未提供此功能，請檢查 crates.io。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// 請記住，[`char`] 可能與您對字符的直覺不符:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // 不是 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// 返回一個在字符串切片的 ['char`] 上的迭代器及其位置。
    ///
    /// 由於字符串切片由有效的 UTF-8 組成，因此我們可以通過 [`char`] 遍歷字符串切片。
    /// 這個方法返回這兩個 [`char`] 以及它們的字節位置的迭代器。
    ///
    /// 迭代器產生元組。位置是第一，[`char`] 是第二。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// 請記住，[`char`] 可能與您對字符的直覺不符:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // 不是 (0，'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // 注意這裡的 3，最後一個字符佔用了兩個字節
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// 在字符串切片的字節上進行迭代的迭代器。
    ///
    /// 由於字符串切片由字節序列組成，因此我們可以逐字節遍歷字符串切片。
    /// 此方法返回這樣的迭代器。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// 按空格分割字符串切片。
    ///
    /// 返回的迭代器將返回作為原始字符串切片的子切片的字符串切片，並以任意數量的空格分隔。
    ///
    ///
    /// 'Whitespace' 根據 Unicode 派生核心屬性 `White_Space` 的術語定義。
    /// 如果只想在 ASCII 空格上分割，請使用 [`split_ascii_whitespace`]。
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// 考慮各種空白:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// 用 ASCII 空格分割字符串切片。
    ///
    /// 返回的迭代器將返回作為原始字符串切片的子切片的字符串切片，並以任意數量的 ASCII 空格分隔。
    ///
    ///
    /// 要改為按 Unicode `Whitespace` 進行拆分，請使用 [`split_whitespace`]。
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// 考慮各種 ASCII 空格:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// 在字符串的各行上進行迭代的迭代器，作為字符串切片。
    ///
    /// 行以換行符 (`\n`) 結束，或者以換行符 (`\r\n`) 返回回車符。
    ///
    /// 最後一行的結尾是可選的。
    /// 以最後一行結尾的字符串將返回與沒有其他最後一行結尾的相同字符串相同的行。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// 不需要最後一行:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// 字符串行上的迭代器。
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// 在編碼為 UTF-16 的字符串上返回 `u16` 的迭代器。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// 如果給定的模式與該字符串切片的子切片匹配，則返回 `true`。
    ///
    /// 如果不是，則返回 `false`。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// 如果給定的模式與此字符串切片的前綴匹配，則返回 `true`。
    ///
    /// 如果不是，則返回 `false`。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// 如果給定的模式與此字符串切片的後綴匹配，則返回 `true`。
    ///
    /// 如果不是，則返回 `false`。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// 返回與模式匹配的此字符串切片的第一個字符的字節索引。
    ///
    /// 如果模式不匹配，則返回 [`None`]。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// 使用無點樣式和閉包的更複雜的模式:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// 找不到模式:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// 返回此字符串片段中模式最右邊匹配的第一個字符的字節索引。
    ///
    /// 如果模式不匹配，則返回 [`None`]。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// 帶閉包的更複雜的模式:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// 找不到模式:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// 在此字符串片段的子字符串上的迭代器，該迭代器由與模式匹配的字符分隔。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 如果模式允許反向搜索且 forward/reverse 搜索產生相同的元素，則返回的迭代器將為 [`DoubleEndedIterator`]。
    /// 例如，對於 [`char`]，這是正確的，但對於 `&str`，則不是。
    ///
    /// 如果模式允許反向搜索，但其結果可能與正向搜索不同，則可以使用 [`rsplit`] 方法。
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// 如果模式是一小部分字符，則在每次出現任何字符時進行分割:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// 使用閉包的更複雜的模式:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// 如果一個字符串包含多個連續的分隔符，您將在輸出中最終得到空字符串:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// 連續的分隔符由空字符串分隔。
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// 字符串開頭或結尾的分隔符與空字符串相鄰。
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// 當空字符串用作分隔符時，它將字符串中的每個字符以及字符串的開頭和結尾分隔開。
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// 當使用空格作為分隔符時，連續的分隔符可能會導致令人驚訝的行為。這段代碼是正確的:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ 確實為您提供:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// 為此行為使用 [`split_whitespace`]。
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// 在此字符串片段的子字符串上的迭代器，該迭代器由與模式匹配的字符分隔。
    /// 與 `split` 產生的迭代器的不同之處在於 `split_inclusive` 將匹配的部分保留為子字符串的終止符。
    ///
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// 如果字符串的最後一個元素匹配，則該元素將被視為前一個子字符串的終止符。
    /// 該子字符串將是迭代器返回的最後一個項目。
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// 給定字符串切片的子字符串上的迭代器，該迭代器由與模式匹配的字符分隔並以相反的順序產生。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索產生相同的元素，則它將為 [`DoubleEndedIterator`]。
    ///
    ///
    /// 為了從正面進行迭代，可以使用 [`split`] 方法。
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// 使用閉包的更複雜的模式:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// 給定字符串切片的子字符串上的迭代器，該迭代器由與模式匹配的字符分隔。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// 等效於 [`split`]，不同之處在於尾隨的子字符串為空時將被跳過。
    ///
    /// [`split`]: str::split
    ///
    /// 此方法可用於 _terminated_ 的字符串數據，而不是用於模式的 _separated_ 的字符串數據。
    ///
    /// # 迭代器行為
    ///
    /// 如果模式允許反向搜索且 forward/reverse 搜索產生相同的元素，則返回的迭代器將為 [`DoubleEndedIterator`]。
    /// 例如，對於 [`char`]，這是正確的，但對於 `&str`，則不是。
    ///
    /// 如果模式允許反向搜索，但其結果可能與正向搜索不同，則可以使用 [`rsplit_terminator`] 方法。
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// `self` 子字符串上的迭代器，該迭代器由與模式匹配的字符分隔，並以相反的順序產生。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// 等效於 [`split`]，不同之處在於尾隨的子字符串為空時將被跳過。
    ///
    /// [`split`]: str::split
    ///
    /// 此方法可用於 _terminated_ 的字符串數據，而不是用於模式的 _separated_ 的字符串數據。
    ///
    /// # 迭代器行為
    ///
    /// 返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索產生相同的元素，則它將是雙頭模式。
    ///
    ///
    /// 為了從正面進行迭代，可以使用 [`split_terminator`] 方法。
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// 給定字符串切片的子字符串上的迭代器 (由模式分隔)，僅限於最多返回 `n` 項。
    ///
    /// 如果返回 `n` 子字符串，則最後一個子字符串 (第 n 個子字符串) 將包含字符串的其餘部分。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 返回的迭代器不會是雙頭的，因為支持效率不高。
    ///
    /// 如果模式允許反向搜索，則可以使用 [`rsplitn`] 方法。
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// 使用閉包的更複雜的模式:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// 從字符串的末尾開始，在此字符串切片的子字符串上進行迭代的迭代器，由模式分隔，僅限於最多返回 `n` 項。
    ///
    ///
    /// 如果返回 `n` 子字符串，則最後一個子字符串 (第 n 個子字符串) 將包含字符串的其餘部分。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 返回的迭代器不會是雙頭的，因為支持效率不高。
    ///
    /// 要從正面拆分，可以使用 [`splitn`] 方法。
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// 使用閉包的更複雜的模式:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// 在第一次出現指定分隔符時拆分字符串，並在分隔符之前返回前綴，在分隔符之後返回後綴。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// 在最後一次出現指定分隔符時分割字符串，並在分隔符之前返回前綴，在分隔符之後返回後綴。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// 給定字符串切片中某個模式的不相交匹配的迭代器。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 如果模式允許反向搜索且 forward/reverse 搜索產生相同的元素，則返回的迭代器將為 [`DoubleEndedIterator`]。
    /// 例如，對於 [`char`]，這是正確的，但對於 `&str`，則不是。
    ///
    /// 如果模式允許反向搜索，但其結果可能與正向搜索不同，則可以使用 [`rmatches`] 方法。
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// 在此字符串片段內某個模式的不相交匹配上進行迭代的迭代器，其生成順序相反。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索產生相同的元素，則它將為 [`DoubleEndedIterator`]。
    ///
    ///
    /// 為了從正面進行迭代，可以使用 [`matches`] 方法。
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// 對該字符串切片中某個模式的不相交匹配以及該匹配開始處的索引的迭代器。
    ///
    /// 對於 `self` 中 `pat` 重疊的匹配項，僅返回與第一個匹配項對應的索引。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 如果模式允許反向搜索且 forward/reverse 搜索產生相同的元素，則返回的迭代器將為 [`DoubleEndedIterator`]。
    /// 例如，對於 [`char`]，這是正確的，但對於 `&str`，則不是。
    ///
    /// 如果模式允許反向搜索，但其結果可能與正向搜索不同，則可以使用 [`rmatch_indices`] 方法。
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // 只有第一個 `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` 中某個模式的不相交匹配項上的迭代器，以與匹配項索引相反的順序產生。
    ///
    /// 對於 `self` 中的 `pat` 重疊的匹配項，僅返回與最後一個匹配項對應的索引。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 迭代器行為
    ///
    /// 返回的迭代器要求模式支持反向搜索，如果 forward/reverse 搜索產生相同的元素，則它將為 [`DoubleEndedIterator`]。
    ///
    ///
    /// 為了從正面進行迭代，可以使用 [`match_indices`] 方法。
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // 只有最後的 `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// 返回一個字符串切片，其中刪除了前導和尾隨空格。
    ///
    /// 'Whitespace' 根據 Unicode 派生核心屬性 `White_Space` 的術語定義。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// 返回刪除了前導空格的字符串切片。
    ///
    /// 'Whitespace' 根據 Unicode 派生核心屬性 `White_Space` 的術語定義。
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// `start` 在本文中，是指該字節字符串的第一個位置; 對於從左到右的語言 (例如英語或俄語)，這將是左側; 對於從右到左的語言 (例如阿拉伯語或希伯來語)，這將是右側。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// 返回除去尾隨空格的字符串切片。
    ///
    /// 'Whitespace' 根據 Unicode 派生核心屬性 `White_Space` 的術語定義。
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// `end` 在本文中，是指該字節字符串的最後一個位置; 對於從左到右的語言 (例如英語或俄語)，這將在右側; 對於從右到左的語言 (例如阿拉伯語或希伯來語)，將在左側。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// 返回刪除了前導空格的字符串切片。
    ///
    /// 'Whitespace' 根據 Unicode 派生核心屬性 `White_Space` 的術語定義。
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// 'Left' 在本文中，是指該字節字符串的第一個位置; 對於像阿拉伯語或希伯來語這樣的語言，`從右到左` 而不是 `從左到右`，這將是 _right_ 一側，而不是左側。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// 返回除去尾隨空格的字符串切片。
    ///
    /// 'Whitespace' 根據 Unicode 派生核心屬性 `White_Space` 的術語定義。
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// 'Right' 在本文中，是指該字節字符串的最後一個位置; 對於像阿拉伯語或希伯來語這樣的語言，`從右到左` 而不是 `從左到右`，這將是 _left_ 的一面，而不是右邊。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// 返回具有與重複刪除的模式匹配的所有前綴和後綴的字符串切片。
    ///
    /// [pattern] 可以是 [`char`]，可以是 [`char`] 的一部分，也可以是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// 使用閉包的更複雜的模式:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // 記住最早的已知比賽，如果出現以下情況，請更正
            // 最後一場比賽不一樣
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // 安全: 已知 `Searcher` 返回有效索引。
        unsafe { self.get_unchecked(i..j) }
    }

    /// 返回具有與重複刪除的模式匹配的所有前綴的字符串切片。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// `start` 在本文中，是指該字節字符串的第一個位置; 對於從左到右的語言 (例如英語或俄語)，這將是左側; 對於從右到左的語言 (例如阿拉伯語或希伯來語)，這將是右側。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // 安全: 已知 `Searcher` 返回有效索引。
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// 返回刪除了前綴的字符串切片。
    ///
    /// 如果字符串以模式 `prefix` 開頭，則返回前綴在 `Some` 中的子字符串。
    /// 與 `trim_start_matches` 不同，此方法只刪除一次前綴。
    ///
    /// 如果字符串不是以 `prefix` 開頭，則返回 `None`。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// 返回刪除了後綴的字符串切片。
    ///
    /// 如果字符串以模式 `suffix` 結尾，則返回用 `Some` 包裝的後綴之前的子字符串。
    /// 與 `trim_end_matches` 不同，此方法僅將後綴刪除一次。
    ///
    /// 如果字符串不以 `suffix` 結尾，則返回 `None`。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// 返回具有與模式重複刪除的所有後綴的字符串切片。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// `end` 在本文中，是指該字節字符串的最後一個位置; 對於從左到右的語言 (例如英語或俄語)，這將在右側; 對於從右到左的語言 (例如阿拉伯語或希伯來語)，將在左側。
    ///
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// 使用閉包的更複雜的模式:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // 安全: 已知 `Searcher` 返回有效索引。
        unsafe { self.get_unchecked(0..j) }
    }

    /// 返回具有與重複刪除的模式匹配的所有前綴的字符串切片。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// 'Left' 在本文中，是指該字節字符串的第一個位置; 對於像阿拉伯語或希伯來語這樣的語言，`從右到左` 而不是 `從左到右`，這將是 _right_ 一側，而不是左側。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// 返回具有與模式重複刪除的所有後綴的字符串切片。
    ///
    /// [pattern] 可以是 `&str`，[`char`]，[`char`] 的一部分，或者是確定字符是否匹配的函數或閉包。
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # 文字方向性
    ///
    /// 字符串是字節序列。
    /// 'Right' 在本文中，是指該字節字符串的最後一個位置; 對於像阿拉伯語或希伯來語這樣的語言，`從右到左` 而不是 `從左到右`，這將是 _left_ 的一面，而不是右邊。
    ///
    ///
    /// # Examples
    ///
    /// 簡單模式:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// 使用閉包的更複雜的模式:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// 將此字符串切片解析為另一種類型。
    ///
    /// 由於 `parse` 非常通用，因此可能導致類型推斷問題。
    /// 因此，`parse` 是為數不多的被親切地稱為 'turbofish' 的語法之一: `::<>`.
    ///
    /// 這可以幫助推理算法特別了解您要解析為哪種類型。
    ///
    /// `parse` 可以解析為實現 [`FromStr`] trait 的任何類型。
    ///

    /// # Errors
    ///
    /// 如果無法將此字符串切片解析為所需的類型，則將返回 [`Err`]。
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// 基本用法
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// 使用 'turbofish' 而不是註釋 `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// 無法解析:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// 檢查此字符串中的所有字符是否都在 ASCII 範圍內。
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // 我們可以在這裡將每個字節視為字符: 所有多字節字符都以一個不在 ascii 範圍內的字節開頭，因此我們將在此停止。
        //
        //
        self.as_bytes().is_ascii()
    }

    /// 檢查兩個字符串是否為 ASCII 不區分大小寫的匹配項。
    ///
    /// 與 `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 相同，但不分配和復制臨時文件。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// 將此字符串就地轉換為其 ASCII 大寫等效項。
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不變。
    ///
    /// 要返回新的大寫值而不修改現有值，請使用 [`to_ascii_uppercase()`]。
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // 安全: 安全，因為我們轉換了兩種具有相同佈局的類型。
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// 將此字符串就地轉換為其 ASCII 小寫等效項。
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不變。
    ///
    /// 要返回新的小寫值而不修改現有值，請使用 [`to_ascii_lowercase()`]。
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // 安全: 安全，因為我們轉換了兩種具有相同佈局的類型。
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// 返回一個迭代器，該迭代器使用 [`char::escape_debug`] 對 `self` 中的每個字符進行轉義。
    ///
    ///
    /// Note: 只有以字符串開頭的擴展字素代碼點將被轉義。
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// 返回一個迭代器，該迭代器使用 [`char::escape_default`] 對 `self` 中的每個字符進行轉義。
    ///
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// 返回一個迭代器，該迭代器使用 [`char::escape_unicode`] 對 `self` 中的每個字符進行轉義。
    ///
    ///
    /// # Examples
    ///
    /// 作為迭代器:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// 兩者都等同於:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// 使用 `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// 創建一個空的 str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// 創建一個空的可變 str
    #[inline]
    fn default() -> Self {
        // 安全: 空字符串是有效的 UTF-8。
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// 可命名，可克隆的 fn 類型
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // 安全: 不安全
        unsafe { from_utf8_unchecked(bytes) }
    };
}