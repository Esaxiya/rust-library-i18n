use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait 在以下情況下提供對 Interator-adapter 管道中源階段的傳遞訪問:
/// * 迭代器源 `S` 本身實現 `SourceIter<Source = S>`
/// * 在源和管道使用者之間的管道中，每個適配器都有 trait 的委派實現。
///
/// 當源是擁有的迭代器結構 (通常稱為 `IntoIter`) 時，這對於專門化 [`FromIterator`] 實現或在部分耗盡迭代器後恢復其餘元素很有用。
///
///
/// 注意，實現不一定必須提供對管道最內層源的訪問。有狀態的中間適配器可能會急切地評估管道的一部分，並將其內部存儲公開為源。
///
/// trait 是不安全的，因為實施者必須維護其他安全屬性。
/// 有關詳細信息，請參見 [`as_inner`]。
///
/// # Examples
///
/// 檢索部分消耗的源:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// 迭代器管道中的源階段。
    type Source: Iterator;

    /// 檢索迭代器管道的源。
    ///
    /// # Safety
    ///
    /// 的實現必須在其生存期內返回相同的可變引用，除非被調用者替換。
    /// 調用者只有在停止迭代並在提取源之後刪除迭代器管道時才可以替換引用。
    ///
    /// 這意味著迭代器適配器可以依賴在迭代過程中未更改的源，但不能在其 Drop 實現中依賴它。
    ///
    /// 實現此方法意味著適配器放棄對它們的源的僅私有訪問，並且只能依賴基於方法接收者類型做出的保證。
    /// 缺少受限制的訪問還要求適配器即使在訪問其內部時也必須維護源的公共 API。
    ///
    /// 依次，調用者必須期望源處於與其公共 API 一致的任何狀態，因為位於源和源之間的適配器具有相同的訪問權限。
    /// 特別是適配器可能消耗了比嚴格需要更多的元素。
    ///
    /// 這些要求的總體目標是讓管道的使用者使用
    /// * 迭代停止後保留在源中的所有內容
    /// * 推進消費迭代器而變得未使用的內存
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// 只要基礎迭代器產生 `Result::Ok` 值，迭代器適配器就產生輸出。
///
///
/// 如果遇到錯誤，則迭代器將停止並存儲錯誤。
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// 處理給定的迭代器，就像產生 `T` 而不是 `Result<T, _>` 一樣。
/// 任何錯誤都將停止內部迭代器，並且總體結果將是一個錯誤。
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}