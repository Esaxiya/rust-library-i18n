use crate::iter::{FusedIterator, TrustedLen};

/// 創建一個迭代器，該迭代器通過調用提供的閉包來延遲一次精確地生成一個值。
///
/// 這通常用於使單個值生成器適應其他類型的迭代的 [`chain()`]。
/// 也許您有一個涵蓋幾乎所有內容的迭代器，但是您需要一個額外的特殊情況。
/// 也許您有一個適用於迭代器的函數，但只需要處理一個值即可。
///
/// 與 [`once()`] 不同，此函數將根據要求延遲生成值。
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::iter;
///
/// // 一個是最孤獨的數字
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // 只是一個，這就是我們得到的
/// assert_eq!(None, one.next());
/// ```
///
/// 與另一個迭代器鏈接在一起。
/// 假設我們要遍歷 `.foo` 目錄的每個文件，還要遍歷一個配置文件，
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // 我們需要將 DirEntry-s 的迭代器轉換為 PathBufs 的迭代器，因此我們使用 map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // 現在，我們的迭代器僅用於我們的配置文件
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // 將兩個迭代器鏈接到一個大迭代器中
/// let files = dirs.chain(config);
///
/// // 這將為我們提供 .foo 和 .foorc 中的所有文件
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// 通過應用提供的閉包 `F: FnOnce() -> A` 產生 `A` 類型的單個元素的迭代器。
///
///
/// 該 `struct` 由 [`once_with()`] 函數創建。
/// 有關更多信息，請參見其文檔。
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}