use crate::iter::{FusedIterator, TrustedLen};

/// 創建一個迭代器，該迭代器只生成一次元素。
///
/// 這通常用於將單個值適配到其他類型的迭代的 [`chain()`] 中。
/// 也許您有一個涵蓋幾乎所有內容的迭代器，但是您需要一個額外的特殊情況。
/// 也許您有一個適用於迭代器的函數，但只需要處理一個值即可。
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::iter;
///
/// // 一個是最孤獨的數字
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // 只是一個，這就是我們得到的
/// assert_eq!(None, one.next());
/// ```
///
/// 與另一個迭代器鏈接在一起。
/// 假設我們要遍歷 `.foo` 目錄的每個文件，還要遍歷一個配置文件，
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // 我們需要將 DirEntry-s 的迭代器轉換為 PathBufs 的迭代器，因此我們使用 map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // 現在，我們的迭代器僅用於我們的配置文件
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // 將兩個迭代器鏈接到一個大迭代器中
/// let files = dirs.chain(config);
///
/// // 這將為我們提供 .foo 和 .foorc 中的所有文件
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// 一個僅產生一次元素的迭代器。
///
/// 該 `struct` 由 [`once()`] 函數創建。有關更多信息，請參見其文檔。
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}