use crate::fmt;

/// 創建一個新的迭代器，每次迭代都調用提供的閉包 `F: FnMut() -> Option<T>`。
///
/// 這允許創建具有任何行為的自定義迭代器，而無需使用更冗長的語法來創建專用類型並為其實現 [`Iterator`] trait。
///
/// 請注意，`FromFn` 迭代器不對閉包的行為進行假設，因此保守地不會實現 [`FusedIterator`]，也不會從默認 `(0, None)` 覆蓋 [`Iterator::size_hint()`]。
///
///
/// 閉包可以使用捕獲及其環境來跟踪迭代之間的狀態。根據使用迭代器的方式，這可能需要在閉包上指定 [`move`] 關鍵字。
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// 讓我們從 [module-level documentation] 重新實現計數器迭代器:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // 增加我們的數量。這就是為什麼我們從零開始。
///     count += 1;
///
///     // 檢查我們是否已經完成計數。
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// 一個迭代器，每次迭代調用提供的閉包 `F: FnMut() -> Option<T>`。
///
/// 該 `struct` 由 [`iter::from_fn()`] 函數創建。
/// 有關更多信息，請參見其文檔。
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}