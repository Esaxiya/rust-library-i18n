use crate::iter::{FusedIterator, TrustedLen};

/// 創建一個新的迭代器，通過應用提供的閉包，重複器，不斷地重複 `A` 類型的元素， `F: FnMut() -> A`.
///
/// `repeat_with()` 函數反複調用中繼器。
///
/// 無限迭代器 (如 `repeat_with()`) 通常與適配器 (如 [`Iterator::take()`]) 一起使用，以使其具有有限性。
///
/// 如果您需要的迭代器的元素類型實現 [`Clone`]，並且可以將源元素保留在內存中，則應該使用 [`repeat()`] 函數。
///
///
/// `repeat_with()` 產生的迭代器不是 [`DoubleEndedIterator`]。
/// 如果您需要 `repeat_with()` 來返回 [`DoubleEndedIterator`]，請打開 GitHub 問題，說明您的用例。
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::iter;
///
/// // 讓我們假設我們有一些不是 `Clone` 的值，或者因為它很昂貴而現在還不想在內存中:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // 永遠具有特定的價值:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// 使用變異和有限化:
///
/// ```rust
/// use std::iter;
///
/// // 從兩個的零次冪到三次冪:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... 現在我們完成了
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// 一個迭代器，通過應用提供的閉包 `F: FnMut() -> A` 來無限地重複 `A` 類型的元素。
///
///
/// 該 `struct` 由 [`repeat_with()`] 函數創建。
/// 有關更多信息，請參見其文檔。
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}