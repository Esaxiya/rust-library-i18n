use crate::iter::{FusedIterator, TrustedLen};

/// 創建一個新的迭代器，該迭代器不斷重複單個元素。
///
/// `repeat()` 函數一次又一次地重複單個值。
///
/// 無限迭代器 (如 `repeat()`) 通常與適配器 (如 [`Iterator::take()`]) 一起使用，以使其具有有限性。
///
/// 如果所需的迭代器元素類型未實現 `Clone`，或者不想將重複的元素保留在內存中，則可以使用 [`repeat_with()`] 函數。
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::iter;
///
/// // 第四個 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // 是的，還是四個
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// 用 [`Iterator::take()`] 進行有限化:
///
/// ```
/// use std::iter;
///
/// // 最後一個例子太多了。我們只有四個四。
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... 現在我們完成了
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// 一個無限重複元素的迭代器。
///
/// 該 `struct` 由 [`repeat()`] 函數創建。有關更多信息，請參見其文檔。
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}