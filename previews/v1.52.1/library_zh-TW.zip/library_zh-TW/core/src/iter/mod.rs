//! 可組合的外部迭代。
//!
//! 如果發現自己有某種類型的集合，並且需要對所述集合的元素執行操作，那麼您會很快遇到 'iterators'。
//! 迭代器在慣用的 Rust 代碼中大量使用，因此值得對它們熟悉。
//!
//! 在解釋更多內容之前，讓我們討論一下該模塊的結構:
//!
//! # Organization
//!
//! 該模塊主要按類型組織:
//!
//! * [Traits] 是核心部分: 這些 traits 定義了存在哪種迭代器以及可以使用它們進行哪些操作。這些 traits 的方法值得投入一些額外的學習時間。
//! * [Functions] 提供了一些有用的方法來創建一些基本的迭代器。
//! * [Structs] 通常是模塊 traits 上各種方法的返回類型。通常，您將需要查看創建 `struct` 的方法，而不是 `struct` 本身。
//! 有關原因的更多詳細信息，請參見 `[實現迭代器] (#implementing-iterator) `。
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! 就是這樣! 讓我們深入研究迭代器。
//!
//! # Iterator
//!
//! 該模塊的核心和靈魂是 [`Iterator`] trait。[`Iterator`] 的核心如下所示:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! 迭代器具有 [`next`] 方法，該方法在調用時將返回 [`Option`]<Item>`。
//! [`next`] 只要有元素，它們將返回 [`Some(Item)`]，一旦所有元素用盡，將返回 `None` 表示迭代已完成。
//! 各個迭代器可能選擇恢復迭代，因此再次調用 [`next`] 可能會或可能不會最終在某個時候再次開始返回 [`Some(Item)`] (例如，請參見 [`TryIter`])。
//!
//!
//! [`Iterator`] 的完整定義還包括許多其他方法，但是它們是默認方法，基於 [`next`] 構建，因此您可以免費獲得它們。
//!
//! 迭代器也是可組合的，通常將它們鏈接在一起以進行更複雜的處理形式。有關更多詳細信息，請參見下面的 [Adapters](#adapters) 部分。
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # 三種迭代形式
//!
//! 可以從集合中創建迭代器的三種常見方法:
//!
//! * `iter()`, 在 `&T` 上迭代。
//! * `iter_mut()`, 在 `&mut T` 上迭代。
//! * `into_iter()`, 在 `T` 上迭代。
//!
//! 在適當的情況下，標準庫中的各種內容都可以實現這三個中的一個或多個。
//!
//! # 實現迭代器
//!
//! 創建自己的迭代器涉及兩個步驟: 創建一個 `struct` 來保存迭代器的狀態，然後為該 `struct` 實現 [`Iterator`]。
//! 這就是為什麼此模塊中有這麼多 `struct` 的原因: 每個迭代器和迭代器適配器都有一個。
//!
//! 讓我們創建一個名為 `Counter` 的迭代器，該迭代器的範圍從 `1` 到 `5`:
//!
//! ```
//! // 首先，該結構:
//!
//! /// 從 1 到 5 計數的迭代器
//! struct Counter {
//!     count: usize,
//! }
//!
//! // 我們希望計數從一開始，所以讓我們添加一個 new() 方法來提供幫助。
//! // 這不是嚴格必要的，但很方便。
//! // 請注意，我們將 `count` 從零開始，我們將在下面的 `next()`'s 實現中看到原因。
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // 然後，我們為 `Counter` 實現 `Iterator`:
//!
//! impl Iterator for Counter {
//!     // 我們將使用 usize 進行計數
//!     type Item = usize;
//!
//!     // next() 是唯一需要的方法
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // 增加我們的數量。這就是為什麼我們從零開始。
//!         self.count += 1;
//!
//!         // 檢查我們是否已經完成計數。
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // 現在我們可以使用它了!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! 以這種方式調用 [`next`] 會重複。Rust 具有可以在迭代器上調用 [`next`] 的構造，直到到達 `None`。讓我們接下來再說。
//!
//! 還要注意，`Iterator` 提供了 `nth` 和 `fold` 之類的方法的默認實現，這些方法在內部調用 `next`。
//! 但是，如果迭代器可以在不調用 `next` 的情況下更有效地計算它們，則還可以編寫方法的自定義實現，例如 `nth` 和 `fold`。
//!
//! # `for` 循環和 `IntoIterator`
//!
//! Rust 的 `for` 循環語法實際上是迭代器的糖。這是 `for` 的基本示例:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! 這將打印數字 1 到 5，每個數字都在各自的行上。但是您會在這裡註意到: 我們從未在 vector 上調用任何東西來產生迭代器。是什麼賦予了?
//!
//! 標準庫中有一個 trait，用於將某些內容轉換為迭代器: [`IntoIterator`].
//! trait 具有一個方法 [`into_iter`]，該方法將實現 [`IntoIterator`] 的事物轉換為迭代器。
//! 讓我們再次看看該 `for` 循環，以及編譯器將其轉換為以下內容的內容:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust 將其反糖化為:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! 首先，我們在值上調用 `into_iter()`。然後，我們在返回的迭代器上進行匹配，一遍又一遍地調用 [`next`]，直到看到 `None`。
//! 到那時，我們 `break` 退出了循環，我們已經完成了迭代。
//!
//! 這裡還有一點微妙之處: 標準庫包含一個有趣的 [`IntoIterator`] 實現:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! 換句話說，所有 [`Iterator`] 都通過返回自身來實現 [`IntoIterator`]。這意味著兩件事:
//!
//! 1. 如果要編寫 [`Iterator`]，則可以將其與 `for` 循環一起使用。
//! 2. 如果要創建集合，則為其實現 [`IntoIterator`] 將使您的集合可以與 `for` 循環一起使用。
//!
//! # 通過引用進行迭代
//!
//! 由於 [`into_iter()`] 將 `self` 作為值，因此使用 `for` 循環遍歷集合將消耗該集合。通常，您可能想遍歷一個集合而不使用它。
//! 許多集合提供了在引用上提供迭代器的方法，通常分別稱為 `iter()` 和 `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` 仍歸此功能所有。
//! ```
//!
//! 如果集合類型 `C` 提供了 `iter()`，則它通常還為 `&C` 實現 `IntoIterator`，並且該實現只調用 `iter()`。
//! 同樣，提供 `iter_mut()` 的集合 `C` 通常通過委派給 `iter_mut()` 來為 `&mut C` 實現 `IntoIterator`。這樣可以方便快捷地實現以下目的:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // 與 `values.iter_mut()` 相同
//!     *x += 1;
//! }
//! for x in &values { // 與 `values.iter()` 相同
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! 儘管許多集合提供 `iter()`，但並非所有集合都提供 `iter_mut()`。
//! 例如，如果鍵哈希值發生更改，則對 [`HashSet<T>`] 或 [`HashMap<K, V>`] 的鍵進行突變可能會使集合處於不一致狀態，因此這些集合僅提供 `iter()`。
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! 帶有 [`Iterator`] 並返回另一個 [`Iterator`] 的函數通常稱為 `迭代器適配器`，因為它們是 `適配器` 的一種形式
//! pattern'.
//!
//! 常見的迭代器適配器包括 [`map`]，[`take`] 和 [`filter`]。
//! 有關更多信息，請參見其文檔。
//!
//! 如果迭代器適配器為 panics，則迭代器將處於未指定 (但內存安全) 狀態。
//! 也不能保證此狀態在 Rust 的各個版本中都保持不變，因此您應避免依賴慌亂的迭代器返回的確切值。
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! 迭代器 (和 [adapters](#adapters)) 迭代器是 `懶惰的`。這意味著僅創建迭代器並不能滿足 _do_ 的全部需求。在調用 [`next`] 之前，什麼都不會發生。
//! 當創建僅出於其副作用的迭代器時，這有時會引起混亂。
//! 例如，[`map`] 方法在其迭代的每個元素上調用一個閉包:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! 這將不會打印任何值，因為我們只是創建了一個迭代器，而不是使用它。編譯器將警告我們這種行為:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! 編寫 [`map`] 的副作用的慣用方式是使用 `for` 循環或調用 [`for_each`] 方法:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! 評估迭代器的另一種常用方法是使用 [`collect`] 方法生成一個新的集合。
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! 迭代器不必一定是有限的。例如，開放式範圍是一個無限迭代器:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! 通常使用 [`take`] 迭代器適配器將無限迭代器轉換為有限迭代器:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! 這將在各自的行上打印數字 `0` 至 `4`。
//!
//! 請記住，無限迭代器上的方法，即使可以在有限時間內數學確定結果的方法，也可能不會終止。
//! 具體來說，通常需要遍歷迭代器中每個元素的方法 (如 [`min`]) 對於任何無限迭代器都可能無法成功返回。
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // 不好了! 無限循環!
//! // `ones.min()` 導致無限循環，所以我們不會達到這一點!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;