/// 知道其確切長度的迭代器。
///
/// 許多 [`Iterator`] 不知道它們將迭代多少次，但是有些迭代器知道。
/// 如果迭代器知道可以迭代多少次，則提供對該信息的訪問將很有用。
/// 例如，如果要向後迭代，一個好的開始就是知道終點在哪裡。
///
/// 實施 `ExactSizeIterator` 時，還必須實施 [`Iterator`]。
/// 這樣做時，[`Iterator::size_hint`] 的實現 *必須* 返回迭代器的確切大小。
///
/// [`len`] 方法具有默認實現，因此通常不應該實現它。
/// 但是，您可能能夠提供比默認設置更有效的實現，因此在這種情況下將其覆蓋是有道理的。
///
///
/// 請注意，此 trait 是安全的 trait，因此 *not* 和 *cannot* 不能保證返回的長度正確。
/// 這意味著 `unsafe` 代碼 ** 一定不要依賴 [`Iterator::size_hint`] 的正確性。
/// 不穩定且不安全的 [`TrustedLen`](super::marker::TrustedLen) trait 提供了此額外的保證。
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// // 一個有限的範圍確切地知道它將迭代多少次
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// 在 [module-level docs] 中，我們實現了 [`Iterator`]， `Counter`.
/// 讓我們也為其實現 `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // 我們可以輕鬆計算剩餘的迭代次數。
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // 現在我們可以使用它了!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// 返回迭代器的確切長度。
    ///
    /// 該實現可確保迭代器在返回 [`None`] 之前，將返回 [`Some(T)`] 值的次數正好多於 `len()`。
    ///
    /// 此方法具有默認實現，因此通常不應直接實現它。
    /// 但是，如果您可以提供更有效的實現，則可以這樣做。
    /// 有關示例，請參見 [trait-level] 文檔。
    ///
    /// 此功能與 [`Iterator::size_hint`] 功能具有相同的安全保證。
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 一個有限的範圍確切地知道它將迭代多少次
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: 該斷言過分防禦，但它檢查了不變性
        // 由 trait 保證。
        // 如果此 trait 是內部的 rust，則可以使用 debug_assert! ;。assert_eq! 還將檢查所有 Rust 用戶實現。
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// 如果迭代器為空，則返回 `true`。
    ///
    /// 此方法具有使用 [`ExactSizeIterator::len()`] 的默認實現，因此您無需自己實現。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}