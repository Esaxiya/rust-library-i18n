// ignore-tidy-filelength 此文件幾乎完全由 `Iterator` 的定義組成。
// 我們不能將其拆分為多個文件。
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// 用於處理迭代器的接口。
///
/// 這是主要的迭代器 trait。
/// 有關一般迭代器概念的更多信息，請參見 [module-level documentation]。
/// 特別是，您可能想知道如何 [implement `Iterator`][impl]。
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// 被迭代的元素的類型。
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// 推進迭代器並返回下一個值。
    ///
    /// 迭代完成後返回 [`None`]。
    /// 各個迭代器的實現可能選擇恢復迭代，因此再次調用 `next()` 可能會或可能不會最終在某個時候開始再次返回 [`Some(Item)`]。
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // 調用 next() 返回下一個值...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... 然後一旦結束，就沒有提示。
    /// assert_eq!(None, iter.next());
    ///
    /// // 更多调用可能會也可能不會返回 `None`。在這裡，他們總是會的。
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// 返回迭代器剩余長度的界限。
    ///
    /// 具體來說，`size_hint()` 返回一個元組，其中第一個元素是下界，第二個元素是上界。
    ///
    /// 返回的元組的後半部分是 [`Option`]`<`[`usize`]`>`。
    /// 這裡的 [`None`] 表示沒有已知的上限，或者該上限大於 [`usize`]。
    ///
    /// # 實施說明
    ///
    /// 沒有強制要求迭代器實現產生聲明數量的元素。越野車迭代器的結果可能小於元素的下限，也可能大於元素的上限。
    ///
    /// `size_hint()` 主要用於優化，例如為迭代器的元素保留空間，但不得信任，例如可以省略不安全代碼中的邊界檢查。
    /// `size_hint()` 的不正確實現不應導致違反內存安全性。
    ///
    /// 也就是說，該實現應提供正確的估計，因為否則將違反 trait 的協議。
    ///
    /// 默認實現返回對任何迭代器都是正確的 ` (0，`[`None`]`) ) `。
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// 一個更複雜的示例:
    ///
    /// ```
    /// // 偶數從零到十。
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // 我們可以從零迭代到十次。
    /// // 不執行 filter() 就不可能知道它是 5。
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // 讓我們用 chain() 再添加五個數字
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // 現在兩個界限都增加了五個
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// 返回 `None` 作為上限:
    ///
    /// ```
    /// // 無限迭代器沒有上限，最大可能下限
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// 使用迭代器，計算迭代次數並返回它。
    ///
    /// 此方法將重複調用 [`next`]，直到遇到 [`None`]，並返回它看到 [`Some`] 的次數。
    /// 請注意，即使迭代器沒有任何元素，也必須至少調用一次 [`next`]。
    ///
    /// [`next`]: Iterator::next
    ///
    /// # 溢出行為
    ///
    /// 該方法無法防止溢出，因此對具有超過 [`usize::MAX`] 個元素的迭代器的元素進行計數會產生錯誤的結果或 panics。
    ///
    /// 如果啟用了調試斷言，則將保證 panic。
    ///
    /// # Panics
    ///
    /// 如果迭代器具有多個 [`usize::MAX`] 元素，則此函數可能為 panic。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// 使用迭代器，返回最後一個元素。
    ///
    /// 此方法將評估迭代器，直到返回 [`None`]。
    /// 這樣做時，它會跟踪當前元素。
    /// 返回 [`None`] 之後，`last()` 將返回它看到的最後一個元素。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// 通過 `n` 元素使迭代器前進。
    ///
    /// 該方法將通過最多 `n` 次調用 [`next`] 來急切地跳過 `n` 元素，直到遇到 [`None`]。
    ///
    /// `advance_by(n)` 如果迭代器成功地將 `n` 元素推進，則返回 [`Ok(())`][Ok]; 如果遇到 [`None`]，則返回 [`Err(k)`][Err]，其中 `k` 是迭代器在元素用盡之前被推進的元素數 (即
    /// 迭代器的長度)。
    /// 請注意，`k` 始終小於 `n`。
    ///
    /// 調用 `advance_by(0)` 不會消耗任何元素，並且始終返回 [`Ok(())`][Ok]。
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // 僅跳過 `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// 返回迭代器的第 n 個元素。
    ///
    /// 像大多數索引操作一樣，計數從零開始，因此 `nth(0)` 返回第一個值，`nth(1)` 返回第二個值，依此類推。
    ///
    /// 請注意，所有先前的元素以及返回的元素都將從迭代器中使用。
    /// 這意味著前面的元素將被丟棄，並且在同一迭代器上多次調用 `nth(0)` 將返回不同的元素。
    ///
    ///
    /// `nth()` 如果 `n` 大於或等於迭代器的長度，則將返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// 多次調用 `nth()` 不會回退迭代器:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// 如果少於 `n + 1` 個元素，則返回 `None`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// 創建一個從同一點開始的迭代器，但在每次迭代時以給定的數量逐步執行。
    ///
    /// 注意 1: 無論給出的步驟如何，總是會返回迭代器的第一個元素。
    ///
    /// 注 2: 被忽略的元素被拉出的時間不是固定的。
    /// `StepBy` 表現得像序列 `next(), nth(step-1), nth(step-1),…`，但也可以像序列一樣自由地表現
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// 由於性能原因，某些迭代器可能會更改使用哪種方式。
    /// 第二種方法將使迭代器更早地進行，並可能消耗更多的項。
    ///
    /// `advance_n_and_return_first` 等價於:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// 如果給定步驟為 `0`，則該方法將為 panic。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// 接受兩個迭代器，並依次在兩個迭代器上創建一個新的迭代器。
    ///
    /// `chain()` 將返回一個新的迭代器，該迭代器將首先對第一個迭代器的值進行迭代，然後對第二個迭代器的值進行迭代。
    ///
    /// 換句話說，它將兩個迭代器鏈接在一起。🔗
    ///
    /// [`once`] 通常用於將單個值調整為其他類型的迭代鏈。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 由於 `chain()` 的參數使用 [`IntoIterator`]，因此我們可以傳遞任何可以轉換為 [`Iterator`] 的東西，而不僅僅是 [`Iterator`] 本身。
    /// 例如，切片 (`&[T]`) 實現 [`IntoIterator`]，因此可以直接傳遞給 `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 如果使用 Windows API，則可能希望將 [`OsStr`] 轉換為 `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 將兩個迭代器 `壓縮` 為成對的單個迭代器。
    ///
    /// `zip()` 返回一個新的迭代器，該迭代器將在其他兩個迭代器上進行迭代，返回一個元組，其中第一個元素來自第一個迭代器，第二個元素來自第二個迭代器。
    ///
    ///
    /// 換句話說，它將兩個迭代器壓縮在一起，形成一個單一的迭代器。
    ///
    /// 如果任一迭代器返回 [`None`]，則壓縮的迭代器中的 [`next`] 將返回 [`None`]。
    /// 如果第一個迭代器返回 [`None`]，則 `zip` 將短路，第二個迭代器將不會調用 `next`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 由於 `zip()` 的參數使用 [`IntoIterator`]，因此我們可以傳遞任何可以轉換為 [`Iterator`] 的東西，而不僅僅是 [`Iterator`] 本身。
    /// 例如，切片 (`&[T]`) 實現 [`IntoIterator`]，因此可以直接傳遞給 `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` 通常用於將無限迭代器壓縮為有限迭代器。
    /// 這是可行的，因為有限迭代器最終將返回 [`None`]，從而結束拉鍊。使用 `(0..)` 壓縮看起來很像 [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// 創建一個新的迭代器，該迭代器將 `separator` 的副本放置在原始迭代器的相鄰項目之間。
    ///
    /// 如果 `separator` 未實現 [`Clone`] 或每次都需要計算，請使用 [`intersperse_with`]。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` 中的第一個元素。
    /// assert_eq!(a.next(), Some(&100)); // 分隔符。
    /// assert_eq!(a.next(), Some(&1));   // `a` 中的下一個元素。
    /// assert_eq!(a.next(), Some(&100)); // 分隔符。
    /// assert_eq!(a.next(), Some(&2));   // `a` 中的最後一個元素。
    /// assert_eq!(a.next(), None);       // 迭代器完成。
    /// ```
    ///
    /// `intersperse` 使用公共元素來連接迭代器的項可能非常有用:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// 創建一個新的迭代器，該迭代器將 `separator` 生成的項目放置在原始迭代器的相鄰項目之間。
    ///
    /// 每次將一個項目放置在底層迭代器的兩個相鄰項目之間時，閉包將被精確地調用一次;
    /// 具體來說，如果基礎迭代器產生的項目少於兩個且在產生最後一個項目之後，則不調用閉包。
    ///
    ///
    /// 如果迭代器的項目實現 [`Clone`]，則使用 [`intersperse`] 可能會更容易。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` 中的第一個元素。
    /// assert_eq!(it.next(), Some(NotClone(99))); // 分隔符。
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` 中的下一個元素。
    /// assert_eq!(it.next(), Some(NotClone(99))); // 分隔符。
    /// assert_eq!(it.next(), Some(NotClone(2)));  // 來自 `v` 的最後一個元素。
    /// assert_eq!(it.next(), None);               // 迭代器完成。
    /// ```
    ///
    /// `intersperse_with` 可以在需要計算分隔符的情況下使用:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // 閉包可變地借用其上下文來生成項目。
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// 採用閉包並創建一個迭代器，該迭代器在每個元素上調用該閉包。
    ///
    /// `map()` 通過其參數將一個迭代器轉換為另一個迭代器:
    /// 實現 [`FnMut`] 的東西。它產生一個新的迭代器，該迭代器在原始迭代器的每個元素上調用此閉包。
    ///
    /// 如果您善於思考類型，則可以這樣考慮 `map()`:
    /// 如果您有一個迭代器為您提供某種 `A` 類型的元素，並且您想要某種其他類型的 `B` 迭代器，則可以使用 `map()`，並傳遞一個接受 `A` 並返回 `B` 的閉包。
    ///
    ///
    /// `map()` 從概念上講，它類似於 [`for`] 循環。但是，由於 `map()` 是惰性的，因此最好在已經使用其他迭代器的情況下使用。
    /// 如果您要進行某種循環的副作用，則認為使用 [`for`] 比使用 `map()` 更慣用。
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 如果您正在做某種副作用，請首選 [`for`] 而不是 `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // 不要這樣做:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // 它甚至不會執行，因為它很懶。Rust 會就此警告您。
    ///
    /// // 而是用於:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// 在迭代器的每個元素上調用閉包。
    ///
    /// 這等效於在迭代器上使用 [`for`] 循環，儘管 `break` 和 `continue` 無法從閉包中獲取。
    /// 使用 `for` 循環通常更慣用，但是在較長的迭代器鏈末尾處理項目時，`for_each` 可能更清晰易懂。
    ///
    /// 在某些情況下，`for_each` 可能比循環還要快，因為它會在 `Chain` 之類的適配器上使用內部迭代。
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// 對於這麼小的示例，`for` 循環可能更乾淨，但是 `for_each` 可能更適合於保留具有較長迭代器的功能樣式:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// 創建一個迭代器，該迭代器使用閉包確定是否應產生元素。
    ///
    /// 給定一個元素，閉包必須返回 `true` 或 `false`。返回的迭代器將僅產生閉包為其返回 true 的元素。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 因為傳遞給 `filter()` 的閉包需要一個引用，並且許多迭代器都在引用上進行迭代，所以這可能導致混亂的情況，其中閉包的類型是雙重引用:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // 需要兩個 * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 通常在參數上使用解構來去除其中一個是很常見的:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ＆和 *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 或兩者:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // 兩個 &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 這些層。
    ///
    /// 請注意，`iter.filter(f).next()` 等效於 `iter.find(f)`。
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// 創建一個同時過濾和映射的迭代器。
    ///
    /// 返回的迭代器僅產生提供的閉包為其返回 `Some(value)` 的 `值`。
    ///
    /// `filter_map` 可用於使 [`filter`] 和 [`map`] 的鏈更簡潔。
    /// 下面的示例顯示瞭如何將 `map().filter().map()` 縮短為對 `filter_map` 的單個調用。
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 這是相同的示例，但使用 [`filter`] 和 [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// 創建一個迭代器，該迭代器給出當前迭代次數以及下一個值。
    ///
    /// 返回的迭代器產生對 `(i, val)`，其中 `i` 是當前迭代索引，`val` 是迭代器返回的值。
    ///
    ///
    /// `enumerate()` 保持其計數為 [`usize`]。
    /// 如果要用不同大小的整數進行計數，則 [`zip`] 函數提供了類似的功能。
    ///
    /// # 溢出行為
    ///
    /// 該方法無法防止溢出，因此枚舉多個 [`usize::MAX`] 元素會產生錯誤的結果或 panics。
    /// 如果啟用了調試斷言，則將保證 panic。
    ///
    /// # Panics
    ///
    /// 如果要返回的索引將溢出 [`usize`]，則返回的迭代器可能為 panic。
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// 創建一個迭代器，該迭代器可以使用 [`peek`] 來查看迭代器的下一個元素，而無需使用它。
    ///
    /// 將 [`peek`] 方法添加到迭代器。有關更多信息，請參見其文檔。
    ///
    /// 請注意，首次調用 [`peek`] 時，基礎迭代器仍處於高級狀態: 為了檢索下一個元素，在基礎迭代器上調用 [`next`]，因此會產生任何副作用 (即，
    ///
    /// 除了獲取 [`next`] 方法的下一個值之外，其他所有操作都將發生。
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() 讓我們看看 future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // 我們可以多次 peek()，迭代器不會前進
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // 迭代器完成後，peek() 也是如此
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// 創建一個迭代器，該迭代器基於謂詞 [`skip`] s 個元素。
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` 將閉包作為參數。它將在迭代器的每個元素上調用此閉包，並忽略元素，直到返回 `false`。
    ///
    /// 返回 `false` 之後，`skip_while()`'s 作業結束，並產生其餘元素。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 因為傳遞給 `skip_while()` 的閉包需要一個引用，並且許多迭代器都在引用上進行迭代，所以這可能會導致混淆，閉包參數的類型是一個雙引用:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // 需要兩個 * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 在初始 `false` 之後停止:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // 雖然這本來是錯誤的，但是由於我們已經得到了錯誤，所以不再使用 skip_while()
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// 創建一個迭代器，該迭代器根據謂詞產生元素。
    ///
    /// `take_while()` 將閉包作為參數。它將在迭代器的每個元素上調用此閉包，並在返回 `true` 時產生 yield 元素。
    ///
    /// 返回 `false` 之後，`take_while()`'s 作業結束，其餘元素將被忽略。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 因為傳遞給 `take_while()` 的閉包需要一個引用，並且許多迭代器都在引用上進行迭代，所以這可能導致混亂的情況，其中閉包的類型是雙重引用:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // 需要兩個 * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 在初始 `false` 之後停止:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // 我們有更多小於零的元素，但是由於我們已經得到了錯誤，因此不再使用 take_while()
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 因為 `take_while()` 需要查看該值以查看是否應包含它，所以使用迭代器的人將看到它已被刪除:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` 不再存在，因為它已被消耗以查看迭代是否應該停止，但並未放回到迭代器中。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// 創建一個迭代器，該迭代器均基於謂詞生成元素並映射。
    ///
    /// `map_while()` 將閉包作為參數。
    /// 它將在迭代器的每個元素上調用此閉包，並在返回 [`Some(_)`][`Some`] 時產生 yield 元素。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 這是相同的示例，但使用 [`take_while`] 和 [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 在初始 [`None`] 之後停止:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // 我們還有更多可能適合 u32 (4，5) 的元素，但是 `map_while` 為 `-3` 返回了 `None` (因為 `predicate` 返回了 `None`)，而 `collect` 在遇到的第一個 `None` 處停止。
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// 因為 `map_while()` 需要查看該值以查看是否應包含它，所以使用迭代器的人將看到它已被刪除:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` 不再存在，因為它已被消耗以查看迭代是否應該停止，但並未放回到迭代器中。
    ///
    /// 請注意，與 [`take_while`] 不同，此迭代器是 `不融合` 的。
    /// 還沒有指定返回第一個 [`None`] 之後此迭代器返回的內容。
    /// 如果需要融合迭代器，請使用 [`fuse`]。
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// 創建一個跳過前 `n` 個元素的迭代器。
    ///
    /// 消耗掉它們之後，剩下的元素就會產生。
    /// 而不是直接覆蓋此方法，而是覆蓋 `nth` 方法。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// 創建一個迭代器，該迭代器產生其第一個 `n` 元素。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` 通常與無限迭代器配合使用，以使其變得有限:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 如果少於 `n` 個元素可用，則 `take` 會將其自身限制為基礎迭代器的大小:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// 與 [`fold`] 相似的迭代器適配器，它保持內部狀態並生成新的迭代器。
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` 接受兩個參數: 一個初始值，該初始值填充內部狀態; 一個帶有兩個參數的閉包，第一個是對內部狀態的可變引用，第二個是迭代器元素。
    ///
    /// 閉包可以分配給內部狀態，以在迭代之間共享狀態。
    ///
    /// 迭代時，閉包將應用於迭代器的每個元素，並且閉包的返回值 [`Option`] 由迭代器產生。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // 每次迭代，我們將狀態乘以元素
    ///     *state = *state * x;
    ///
    ///     // 然後，我們將得出國家的否定
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// 創建一個類似於地圖的迭代器，但將嵌套結構展平。
    ///
    /// [`map`] 適配器非常有用，但僅當閉包參數產生值時才有用。
    /// 如果它產生一個迭代器，則存在一個額外的間接層。
    /// `flat_map()` 會自行刪除此額外的圖層。
    ///
    /// 您可以將 `flat_map(f)` 視為 [`map`] ping，然後像 [0000] 中進行 [`flatten`] 的語義等效。
    ///
    /// 關於 `flat_map()` 的另一種思考方式: [`map`] 的閉包為每個元素返回一個項目，而 `flat_map()`'s 閉包為每個元素返回一個迭代器。
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() 返回一個迭代器
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// 創建一個可簡化嵌套結構的迭代器。
    ///
    /// 當您具有迭代器的迭代器或可以轉換為迭代器的事物的迭代器並且要刪除一個間接級別時，這很有用。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// 映射然後展平:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() 返回一個迭代器
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// 您也可以用 [`flat_map()`] 來重寫它，在這種情況下最好使用 [`flat_map()`]，因為它可以更清楚地傳達意圖:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() 返回一個迭代器
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// 展平一次只能刪除一層嵌套:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// 在這裡，我們看到 `flatten()` 不執行 "deep" 展平。
    /// 取而代之的是，僅刪除了一層嵌套。也就是說，如果您用 `flatten()` 三維數組，則結果將是二維而不是一維的。
    /// 要獲得一維結構，您必須再次 `flatten()`。
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// 創建一個迭代器，該迭代器在第一個 [`None`] 之後結束。
    ///
    /// 迭代器返回 [`None`] 之後，future 調用可能會或可能不會再次產生 [`Some(T)`]。
    /// `fuse()` 調整迭代器，以確保在給出 [`None`] 之後，它將始終永遠返回 [`None`]。
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 一個在 Some 和 None 之間交替的迭代器
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // 如果是偶數，則為 Some(i32)，否則為 None
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // 我們可以看到我們的迭代器來回走動
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // 但是，一旦我們融合了...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // 第一次之後它將始終返回 `None`。
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// 對迭代器的每個元素執行某些操作，將值傳遞給它。
    ///
    /// 使用迭代器時，通常會將其中的幾個鏈接在一起。
    /// 在處理此類代碼時，您可能想檢查一下管道中各個部分的情況。為此，請插入對 `inspect()` 的調用。
    ///
    /// `inspect()` 用作調試工具要比最終代碼中存在的更為普遍，但是在某些情況下，如果需要先記錄錯誤然後丟棄，應用程序可能會發現它很有用。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // 該迭代器序列很複雜。
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // 讓我們添加一些 inspect() 調用以調查正在發生的事情
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// 這將打印:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// 在丟棄錯誤之前記錄錯誤:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// 這將打印:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// 借用一個迭代器，而不是使用它。
    ///
    /// 這在允許應用迭代器適配器的同時仍保留原始迭代器的所有權很有用。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // 如果我們嘗試再次使用 iter，它將無法正常工作。
    /// // 下面的行給出了 ` 錯誤: 移動值的使用: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // 讓我們再試一次
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // 相反，我們添加一個 .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // 現在這很好:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// 將迭代器轉換為集合。
    ///
    /// `collect()` 可以處理任何可迭代的內容，並將其轉換為相關的集合。
    /// 這是在各種上下文中使用的標準庫中功能更強大的方法之一。
    ///
    /// 使用 `collect()` 的最基本模式是將一個集合轉換為另一個集合。
    /// 您獲取一個集合，對其進行調用 [`iter`]，進行一系列轉換，最後執行 `collect()`。
    ///
    /// `collect()` 還可以創建非典型集合類型的實例。
    /// 例如，可以從 [`char`s] 構建 [`String`]，並將 [`Result<T, E>`][`Result`] 項的迭代器收集到 `Result<Collection<T>, E>` 中。
    ///
    /// 有關更多信息，請參見下面的示例。
    ///
    /// 由於 `collect()` 非常通用，因此可能導致類型推斷問題。
    /// 因此，`collect()` 是為數不多的被親切地稱為 'turbofish' 的語法之一: `::<>`.
    /// 這有助於推理算法特別了解您要收集到的集合。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// 請注意，我們需要在左側使用 `: Vec<i32>`。這是因為我們可以代替收集到例如 [`VecDeque<T>`] 中:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// 使用 'turbofish' 而不是註釋 `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// 因為 `collect()` 只關心您要收集的內容，所以您仍然可以將局部類型提示 `_` 與 turbfish 一起使用:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// 使用 `collect()` 製作 [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// 如果您有 [`結果列表 < T, E>`][`Result`] s，您可以使用 `collect()` 來查看它們是否失敗:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // 給我們第一個錯誤
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // 給我們答案列表
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// 使用一個迭代器，從中創建兩個集合。
    ///
    /// 傳遞給 `partition()` 的謂詞可以返回 `true` 或 `false`。
    /// `partition()` 返回一對，返回的所有元素都為 `true`，返回的所有元素都為 `false`。
    ///
    ///
    /// 另請參見 [`is_partitioned()`] 和 [`partition_in_place()`]。
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// 根據給定的謂詞，對迭代器的元素進行 `就地` 重新排序，以使所有返回 `true` 的元素都在所有返回 `false` 的元素之前。
    ///
    /// 返回找到的 `true` 元素的數量。
    ///
    /// 分區項目的相對順序未得到維護。
    ///
    /// 另請參見 [`is_partitioned()`] 和 [`partition()`]。
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // 在偶數和賠率之間進行適當的分區
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: 我們應該擔心計數溢出嗎? 擁有超過
        // `usize::MAX` 可變引用與 ZST 一起使用，對分區沒有用...

        // 存在這些閉包 "factory" 函數是為了避免 `Self` 中的通用性。

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // 重複查找第一個 `false` 並將其與最後一個 `true` 交換。
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// 檢查此迭代器的元素是否根據給定的謂詞進行了分區，以便所有返回 `true` 的元素都在所有返回 `false` 的元素之前。
    ///
    ///
    /// 另請參見 [`partition()`] 和 [`partition_in_place()`]。
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // 所有項目都測試 `true`，或者第一個子句停在 `false` 處，然後我們檢查之後沒有更多的 `true` 項目。
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// 一個迭代器方法，它只要成功返回就應用函數，並產生單個最終值。
    ///
    /// `try_fold()` 接受兩個參數: 一個初始值，以及一個帶有兩個參數的閉包: 一個 'accumulator' 和一個元素。
    /// 該閉包或者成功返回，並帶有累加器在下一次迭代中應具有的值; 或者，它返回失敗，並返回具有錯誤值的錯誤值，該值立即傳播回調用方 (short-circuiting)。
    ///
    ///
    /// 初始值是累加器在第一次調用時將具有的值。如果對迭代器的每個元素成功應用閉包，則 `try_fold()` 將最終的累加器作為成功返回。
    ///
    /// 每當您有東西集合併且想要從中產生單個值時，折疊就會很有用。
    ///
    /// # 實施者註意
    ///
    /// 就此而言，其他幾種 (forward) 方法都具有默認實現，因此，如果它可以做得比默認 `for` 循環實現更好，請嘗試顯式實現此方法。
    ///
    /// 特別是，請嘗試在組成此迭代器的內部部件上使用此調用 `try_fold()`。
    /// 如果需要多次調用，則 `?` 運算符可能會很方便地將累加器值鏈接在一起，但是要提防在這些早期返回之前需要保留的所有不變式。
    /// 這是一種 `&mut self` 方法，因此在此處遇到錯誤後需要重新開始迭代。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // 數組所有元素的校驗和
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 加 100 元素時，此總和溢出
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // 由於發生短路，因此其餘元素仍可通過迭代器使用。
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// 一種迭代器方法，該方法將易錯函數應用於迭代器中的每個項目，在第一個錯誤處停止並返回該錯誤。
    ///
    ///
    /// 也可以將其視為 [`for_each()`] 的錯誤形式或 [`try_fold()`] 的無狀態版本。
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // 它短路了，所以其餘項目仍在迭代器中:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// 通過應用操作將每個元素折疊到一個累加器中，返回最終結果。
    ///
    /// `fold()` 接受兩個參數: 一個初始值，以及一個帶有兩個參數的閉包: 一個 'accumulator' 和一個元素。
    /// 該閉包返回累加器在下一次迭代中應具有的值。
    ///
    /// 初始值是累加器在第一次調用時將具有的值。
    ///
    /// 在將此閉包應用於迭代器的每個元素之後，`fold()` 返回累加器。
    ///
    /// 該操作有時稱為 'reduce' 或 'inject'。
    ///
    /// 每當您有東西集合併且想要從中產生單個值時，折疊就會很有用。
    ///
    /// Note: `fold()` 和遍歷整個迭代器的類似方法對於無限迭代器可能不會終止，即使在 traits 上也可以在有限時間內確定結果。
    ///
    /// Note: 如果累加器類型和項目類型相同，則可以使用 [`reduce()`] 將第一個元素用作初始值。
    ///
    /// # 實施者註意
    ///
    /// 就此而言，其他幾種 (forward) 方法都具有默認實現，因此，如果它可以做得比默認 `for` 循環實現更好，請嘗試顯式實現此方法。
    ///
    ///
    /// 特別是，請嘗試在組成此迭代器的內部部件上使用此調用 `fold()`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // 數組所有元素的總和
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// 讓我們在這裡遍歷迭代的每個步驟:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// 因此，我們的最終結果是 `6`.
    ///
    /// 對於那些不經常使用迭代器的人來說，通常會使用 `for` 循環和一系列東西來建立結果。那些可以變成 `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for 循環:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // 他們是一樣的
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// 通過重複應用歸約運算，將元素縮減為一個。
    ///
    /// 如果迭代器為空，則返回 [`None`]; 否則，返回 [`None`]。否則，返回減少的結果。
    ///
    /// 對於具有至少一個元素的迭代器，這與將迭代器的第一個元素作為初始值的 [`fold()`] 相同，將每個後續元素折疊到其中。
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// 找出最大值:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// 測試迭代器的每個元素是否與謂詞匹配。
    ///
    /// `all()` 接受返回 `true` 或 `false` 的閉包。它將此閉包應用於迭代器的每個元素，如果它們都返回 `true`，則 `all()` 也是如此。
    /// 如果它們中的任何一個返回 `false`，則返回 `false`。
    ///
    /// `all()` 短路; 換句話說，一旦發現 `false`，它將立即停止處理，因為無論發生什麼其他情況，結果也將是 `false`。
    ///
    ///
    /// 空的迭代器將返回 `true`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// 在第一個 `false` 處停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // 我們仍然可以使用 `iter`，因為還有更多元素。
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// 測試迭代器的任何元素是否與謂詞匹配。
    ///
    /// `any()` 接受返回 `true` 或 `false` 的閉包。它將此閉包應用於迭代器的每個元素，如果其中任何一個返回 `true`，則 `any()` 也是如此。
    /// 如果它們都返回 `false`，則返回 `false`。
    ///
    /// `any()` 短路; 換句話說，一旦發現 `true`，它將立即停止處理，因為無論發生什麼其他情況，結果也將是 `true`。
    ///
    ///
    /// 空的迭代器將返回 `false`。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// 在第一個 `true` 處停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // 我們仍然可以使用 `iter`，因為還有更多元素。
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// 搜索滿足謂詞的迭代器的元素。
    ///
    /// `find()` 接受返回 `true` 或 `false` 的閉包。
    /// 它將此閉包應用於迭代器的每個元素，如果其中任何一個返回 `true`，則 `find()` 返回 [`Some(element)`]。
    /// 如果它們都返回 `false`，則返回 [`None`]。
    ///
    /// `find()` 短路; 換句話說，一旦閉包返回 `true`，它將立即停止處理。
    ///
    /// 因為 `find()` 接受引用，並且許多迭代器遍歷引用，所以這導致參數可能是雙重引用的情況可能令人困惑。
    ///
    /// 使用 `&&x`，您可以在下面的示例中看到這種效果。
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// 在第一個 `true` 處停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // 我們仍然可以使用 `iter`，因為還有更多元素。
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// 請注意，`iter.find(f)` 等效於 `iter.filter(f).next()`。
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// 將函數應用於迭代器的元素，並返回第一個非無結果。
    ///
    ///
    /// `iter.find_map(f)` 等同於 `iter.filter_map(f).next()`。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// 將函數應用於迭代器的元素，並返回第一個真結果或第一個錯誤。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// 在迭代器中搜索元素，並返回其索引。
    ///
    /// `position()` 接受返回 `true` 或 `false` 的閉包。
    /// 它將此閉包應用於迭代器的每個元素，如果其中一個返回 `true`，則 `position()` 返回 [`Some(index)`]。
    /// 如果它們全部返回 `false`，則返回 [`None`]。
    ///
    /// `position()` 短路; 換句話說，一旦找到 `true`，它將立即停止處理。
    ///
    /// # 溢出行為
    ///
    /// 該方法無法防止溢出，因此，如果存在多個不匹配的 [`usize::MAX`] 元素，則會產生錯誤的結果或 panics。
    ///
    /// 如果啟用了調試斷言，則將保證 panic。
    ///
    /// # Panics
    ///
    /// 如果迭代器具有多個 `usize::MAX` 不匹配元素，則此函數可能為 panic。
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// 在第一個 `true` 處停止:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // 我們仍然可以使用 `iter`，因為還有更多元素。
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // 返回的索引取決於迭代器狀態
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// 從右側搜索迭代器中的元素，並返回其索引。
    ///
    /// `rposition()` 接受返回 `true` 或 `false` 的閉包。
    /// 將從結尾開始將此閉包應用於迭代器的每個元素，如果其中一個返回 `true`，則 `rposition()` 返回 [`Some(index)`]。
    ///
    /// 如果它們全部返回 `false`，則返回 [`None`]。
    ///
    /// `rposition()` 短路; 換句話說，一旦找到 `true`，它將立即停止處理。
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// 在第一個 `true` 處停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // 我們仍然可以使用 `iter`，因為還有更多元素。
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // 這裡不需要進行溢出檢查，因為 `ExactSizeIterator` 表示元素數量適合 `usize`。
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// 返回迭代器的最大元素。
    ///
    /// 如果幾個元素最大相等，則返回最後一個元素。
    /// 如果迭代器為空，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// 返回迭代器的最小元素。
    ///
    /// 如果幾個元素相等地最小，則返回第一個元素。
    /// 如果迭代器為空，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// 返回給出指定函數最大值的元素。
    ///
    ///
    /// 如果幾個元素最大相等，則返回最後一個元素。
    /// 如果迭代器為空，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// 返回相對於指定比較函數給出最大值的元素。
    ///
    ///
    /// 如果幾個元素最大相等，則返回最後一個元素。
    /// 如果迭代器為空，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// 返回給出指定函數最小值的元素。
    ///
    ///
    /// 如果幾個元素相等地最小，則返回第一個元素。
    /// 如果迭代器為空，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// 返回給出相對於指定比較函數的最小值的元素。
    ///
    ///
    /// 如果幾個元素相等地最小，則返回第一個元素。
    /// 如果迭代器為空，則返回 [`None`]。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// 反轉迭代器的方向。
    ///
    /// 通常，迭代器從左到右進行迭代。
    /// 使用 `rev()` 之後，迭代器將改為從右向左進行迭代。
    ///
    /// 僅在迭代器具有結束符的情況下才有可能，因此 `rev()` 僅適用於 [`DoubleEndedIterator`] s。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// 將成對的迭代器轉換為一對容器。
    ///
    /// `unzip()` 使用整個對的迭代器，產生兩個集合: 一個來自對的左側元素，另一個來自右側的元素。
    ///
    ///
    /// 從某種意義上說，該功能與 [`zip`] 相反。
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// 創建一個迭代器，該迭代器將復制其所有元素。
    ///
    /// 當在 `&T` 上具有迭代器，但在 `T` 上需要迭代器時，此功能很有用。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // 複製的與 .map(|&x| x) 相同
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// 創建一個迭代器，該迭代器將克隆所有元素。
    ///
    /// 當在 `&T` 上具有迭代器，但在 `T` 上需要迭代器時，此功能很有用。
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // 對於整數，cloneed 與 .map(|&x| x) 相同
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// 不斷重複迭代器。
    ///
    /// 迭代器不會在 [`None`] 處停止，而是會從頭開始重新啟動。再次迭代後，它將再次從頭開始。然後再次。
    /// 然後再次。
    /// Forever.
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// 對迭代器的元素求和。
    ///
    /// 獲取每個元素，將它們添加在一起，然後返回結果。
    ///
    /// 空的迭代器將返回該類型的零值。
    ///
    /// # Panics
    ///
    /// 當調用 `sum()` 並返回原始整數類型時，如果計算溢出並且啟用了調試斷言，則此方法將為 panic。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// 遍歷整個迭代器，將所有元素相乘
    ///
    /// 空的迭代器將返回類型的一個值。
    ///
    /// # Panics
    ///
    /// 當調用 `product()` 並返回原始整數類型時，如果計算溢出並且啟用了調試斷言，則方法將為 panic。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 將此 [`Iterator`] 的元素與另一個元素進行比較。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 就指定的比較功能而言，將此 [`Iterator`] 的元素與另一個元素進行比較。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 將此 [`Iterator`] 的元素與另一個元素進行比較。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 就指定的比較功能而言，將此 [`Iterator`] 的元素與另一個元素進行比較。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// 確定此 [`Iterator`] 的元素是否與另一個元素相同。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// 對於指定的相等性函數，確定此 [`Iterator`] 的元素是否與另一個元素相等。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// 確定此 [`Iterator`] 的元素是否與另一個元素不相等。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// 確定此 [`Iterator`] 的元素是否比另一個元素少 [lexicographically](Ord#lexicographical-comparison)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// 確定此 [`Iterator`] 的元素是否小於或等於另一個元素。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// 確定此 [`Iterator`] 的元素是否大於另一個元素的 [lexicographically](Ord#lexicographical-comparison)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// 確定此 [`Iterator`] 的元素是否大於或等於另一個元素的 [lexicographically](Ord#lexicographical-comparison)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// 檢查此迭代器的元素是否已排序。
    ///
    /// 也就是說，對於每個元素 `a` 及其後續元素 `b`，`a <= b` 必須成立。如果迭代器的結果恰好為零或一個元素，則返回 `true`。
    ///
    /// 請注意，如果 `Self::Item` 僅是 `PartialOrd`，而不是 `Ord`，則上述定義意味著，如果任意兩個連續的項都不具有可比性，則此函數將返回 `false`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// 檢查此迭代器的元素是否使用給定的比較器函數排序。
    ///
    /// 代替使用 `PartialOrd::partial_cmp`，此函數使用給定的 `compare` 函數來確定兩個元素的順序。
    /// 除此之外，它等效於 [`is_sorted`]。有關更多信息，請參見其文檔。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// 檢查此迭代器的元素是否使用給定的鍵提取函數進行排序。
    ///
    /// 該功能不是直接比較迭代器的元素，而是比較元素的鍵 (由 `f` 確定)。
    /// 除此之外，它等效於 [`is_sorted`]。有關更多信息，請參見其文檔。
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// 見 [TrustedRandomAccess]
    // 不尋常的名稱是為了避免方法解析中的名稱衝突，請參閱 #76479。
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}