/// 從 [`Iterator`] 轉換。
///
/// 通過為類型實現 `FromIterator`，可以定義如何從迭代器創建 `FromIterator`。
/// 這對於描述某種類型的集合的類型很常見。
///
/// [`FromIterator::from_iter()`] 很少顯式調用，而是通過 [`Iterator::collect()`] 方法使用。
///
/// 有關更多示例，請參見 [`Iterator::collect()`]'s 文檔。
///
/// 也可以看看: [`IntoIterator`].
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// 使用 [`Iterator::collect()`] 隱式使用 `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// 為您的類型實現 `FromIterator`:
///
/// ```
/// use std::iter::FromIterator;
///
/// // 一個樣本集合，這只是 Vec 的包裝 <T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 讓我們給它一些方法，以便我們可以創建一個方法並向其中添加一些東西。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 我們將實現 FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // 現在我們可以創建一個新的迭代器...
/// let iter = (0..5).into_iter();
///
/// // ... 然後用它製作一個 MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // 也收集作品!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// 從迭代器創建一個值。
    ///
    /// 有關更多信息，請參見 [module-level documentation]。
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// 轉換為 [`Iterator`]。
///
/// 通過為類型實現 `IntoIterator`，可以定義如何將其轉換為迭代器。
/// 這對於描述某種類型的集合的類型很常見。
///
/// 實現 `IntoIterator` 的好處之一是您的類型將為 [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator)。
///
///
/// 也可以看看: [`FromIterator`].
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// 為您的類型實現 `IntoIterator`:
///
/// ```
/// // 一個樣本集合，這只是 Vec 的包裝 <T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 讓我們給它一些方法，以便我們可以創建一個方法並向其中添加一些東西。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 我們將實現 IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // 現在我們可以收集一個新的收藏了...
/// let mut c = MyCollection::new();
///
/// // ... 添加一些東西 ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... 然後將其轉換為迭代器:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// 通常將 `IntoIterator` 用作 trait bound。只要輸入集合類型仍然是迭代器，它就可以更改。
/// 可以通過限制限制來指定其他範圍
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// 被迭代的元素的類型。
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// 我們將其變成哪種迭代器?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// 從一個值創建一個迭代器。
    ///
    /// 有關更多信息，請參見 [module-level documentation]。
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// 用迭代器的內容擴展集合。
///
/// 迭代器產生一系列值，並且集合也可以被視為一系列值。
/// `Extend` trait 彌補了這一空白，使您可以通過包含該迭代器的內容來擴展集合。
/// 使用現有鍵擴展集合時，將更新該條目; 如果集合允許使用相同鍵的多個條目，則將插入該條目。
///
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// // 您可以使用一些字符擴展 String:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// 實施 `Extend`:
///
/// ```
/// // 一個樣本集合，這只是 Vec 的包裝 <T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // 讓我們給它一些方法，以便我們可以創建一個方法並向其中添加一些東西。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 由於 MyCollection 包含 i32 的列表，因此我們為 i32 實現 Extend
/// impl Extend<i32> for MyCollection {
///
///     // 使用具體的類型簽名，這要簡單一些: 我們可以在可以轉化為 Iterator 的任何東西上調用 extend，從而為我們提供 i32。
///     // 因為我們需要將 i32 放入 MyCollection 中。
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // 實現非常簡單: 遍歷迭代器，然後將每個元素 add() 傳遞給我們自己。
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // 讓我們用三個數字擴展我們的收藏
/// c.extend(vec![1, 2, 3]);
///
/// // 我們已經將這些元素添加到最後
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// 用迭代器的內容擴展集合。
    ///
    /// 由於這是此 trait 唯一需要的方法，因此 [trait-level] 文檔包含更多詳細信息。
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 您可以使用一些字符擴展 String:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// 用一個元素擴展一個集合。
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// 在集合中為給定數量的其他元素保留容量。
    ///
    /// 默認實現不執行任何操作。
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}