/// 一個迭代器，用完後總是繼續產生 `None`。
///
/// 確保一次返回 `None` 的融合迭代器上的 next 調用保證再次返回 [`None`]。
/// 該 trait 應該由以此方式運行的所有迭代器實現，因為它允許優化 [`Iterator::fuse()`]。
///
///
/// Note: 通常，如果需要融合的迭代器，則不應在通用範圍內使用 `FusedIterator`。
/// 相反，您應該只在迭代器上調用 [`Iterator::fuse()`]。
/// 如果迭代器已經融合，則額外的 [`Fuse`] 包裝器將是無操作的，並且不會降低性能。
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// 一個使用 size_hint 報告準確長度的迭代器。
///
/// 迭代器報告一個大小提示，該提示是精確的 (下限等於上限)，或者上限是 [`None`]。
///
/// 如果實際的迭代器長度大於 [`usize::MAX`]，則上限必須為 [`None`]。
/// 在這種情況下，下限必須為 [`usize::MAX`]，從而導致 [`Iterator::size_hint()`] 為 `(usize::MAX, None)`。
///
/// 迭代器必須精確地生成它所報告或發散的元素數量，然後才能結束。
///
/// # Safety
///
/// trait 必須僅在遵守合同的情況下實施。
/// trait 的使用者必須檢查 [`Iterator::size_hint()`]’s 上限。
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// 一個迭代器，當生成一個項目時，它將從其基礎 [`SourceIter`] 中獲取至少一個元素。
///
/// 調用任何推進迭代器的方法，例如
/// [`next()`] [`try_fold()`] 或 [`try_fold()`]，確保在每一步驟中，迭代器的基礎源的至少一個值已移出，並且迭代器鏈的結果可以插入其位置，前提是源的結構約束允許這種插入。
///
/// 換句話說，此 trait 表示可以在適當位置收集迭代器管道。
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}