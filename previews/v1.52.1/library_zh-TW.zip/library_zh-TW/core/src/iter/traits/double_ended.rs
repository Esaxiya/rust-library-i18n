use crate::ops::{ControlFlow, Try};

/// 一個能夠從兩端產生元素的迭代器。
///
/// 實現 `DoubleEndedIterator` 的東西比實現 [`Iterator`] 的東西具有一項額外的功能: 既可以從背面也可以從正面獲取 Item 的能力。
///
///
/// 重要的是要注意，來回運動都在相同的範圍內，並且不會交叉: 當它們在中間相遇時，迭代就結束了。
///
/// 以與 [`Iterator`] 協議類似的方式，一旦 `DoubleEndedIterator` 從 [`next_back()`] 返回 [`None`]，再次調用它可能會也可能不會再返回 [`Some`]。
/// [`next()`] [`next_back()`] 和 [`next_back()`] 可以互換使用。
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// 從迭代器的末尾刪除並返回一個元素。
    ///
    /// 沒有更多元素時返回 `None`。
    ///
    /// [trait-level] 文檔包含更多詳細信息。
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// DoubleEndedIterator 方法產生的元素可能與 [Iterator`] 方法產生的元素不同:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// 通過 `n` 元素從後向前推進迭代器。
    ///
    /// `advance_back_by` 是 [`advance_by`] 的反向版本。該方法將急切地從後面開始跳過 `n` 元素，方法是調用 [`next_back`] 最多 `n` 次，直到遇到 [`None`]。
    ///
    /// `advance_back_by(n)` 如果迭代器成功地將 `n` 元素推進，則返回 [`Ok(())`]; 如果遇到 [`None`]，則返回 [`Err(k)`]，其中 `k` 是迭代器在元素用盡之前被推進的元素數 (即
    /// 迭代器的長度)。
    /// 請注意，`k` 始終小於 `n`。
    ///
    /// 調用 `advance_back_by(0)` 不會消耗任何元素，並且始終返回 [`Ok(())`]。
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // 僅跳過 `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// 從迭代器的末尾返回第 n 個元素。
    ///
    /// 這實際上是 [`Iterator::nth()`] 的反向版本。
    /// 儘管像大多數索引操作一樣，計數從零開始，所以 `nth_back(0)` 從末尾返回第一個值，`nth_back(1)` 從第二個開始返回，依此類推。
    ///
    ///
    /// 請注意，將使用 end 和返回元素之間的所有元素，包括返回元素。
    /// 這也意味著在同一迭代器上多次調用 `nth_back(0)` 將返回不同的元素。
    ///
    /// `nth_back()` 如果 `n` 大於或等於迭代器的長度，則將返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// 多次調用 `nth_back()` 不會回退迭代器:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// 如果少於 `n + 1` 個元素，則返回 `None`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// 這是 [`Iterator::try_fold()`] 的反向版本: 它從迭代器的背面開始接收元素。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // 由於發生短路，因此其餘元素仍可通過迭代器使用。
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// 一種迭代器方法，從背面開始，將迭代器的元素減少為單個最終值。
    ///
    /// 這是 [`Iterator::fold()`] 的反向版本: 它從迭代器的背面開始接收元素。
    ///
    /// `rfold()` 接受兩個參數: 一個初始值，以及一個帶有兩個參數的閉包: 一個 'accumulator' 和一個元素。
    /// 該閉包返回累加器在下一次迭代中應具有的值。
    ///
    /// 初始值是累加器在第一次調用時將具有的值。
    ///
    /// 在將此閉包應用於迭代器的每個元素之後，`rfold()` 返回累加器。
    ///
    /// 該操作有時稱為 'reduce' 或 'inject'。
    ///
    /// 每當您有東西集合併且想要從中產生單個值時，折疊就會很有用。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a 的所有元素的總和
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// 本示例構建一個字符串，該字符串從初始值開始，並從後到前從每個元素開始:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// 從背面搜索滿足謂詞的迭代器的元素。
    ///
    /// `rfind()` 接受返回 `true` 或 `false` 的閉包。
    /// 將從結尾處開始將此閉包應用於迭代器的每個元素，如果其中任何一個返回 `true`，則 `rfind()` 返回 [`Some(element)`]。
    /// 如果它們都返回 `false`，則返回 [`None`]。
    ///
    /// `rfind()` 短路; 換句話說，一旦閉包返回 `true`，它將立即停止處理。
    ///
    /// 因為 `rfind()` 接受引用，並且許多迭代器遍歷引用，所以這導致參數可能是雙重引用的情況可能令人困惑。
    ///
    /// 使用 `&&x`，您可以在下面的示例中看到這種效果。
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// 在第一個 `true` 處停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // 我們仍然可以使用 `iter`，因為還有更多元素。
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}