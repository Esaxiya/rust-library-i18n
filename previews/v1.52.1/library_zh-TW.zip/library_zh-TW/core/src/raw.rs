#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! 包含用於編譯器內置類型的佈局的結構定義。
//!
//! 它們可以用作不安全代碼中的變形目標，以直接操作原始表示。
//!
//!
//! 它們的定義應始終與 `rustc_middle::ty::layout` 中定義的 ABI 相匹配。
//!

/// trait 對象 (如 `&dyn SomeTrait`) 的表示形式。
///
/// 該結構與 `&dyn SomeTrait` 和 `Box<dyn AnotherTrait>` 等類型具有相同的佈局。
///
/// `TraitObject` 保證匹配佈局，但這不是 trait 對象的類型 (例如，不能在 `&dyn SomeTrait` 上直接訪問字段)，也不是控制佈局 (更改定義不會更改 `&dyn SomeTrait` 的佈局)。
///
/// 它僅設計用於需要操縱低級細節的不安全代碼。
///
/// 無法通用地引用所有 trait 對象，因此創建此類型的值的唯一方法是使用 [`std::mem::transmute`][transmute] 之類的函數。
/// 同樣，從 `TraitObject` 值創建真正的 trait 對象的唯一方法是使用 `transmute`。
///
/// [transmute]: crate::intrinsics::transmute
///
/// 合成具有不匹配類型的 trait 對象 (其中 vtable 不對應於數據指針指向的值的類型) 很可能導致未定義的行為。
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // 示例 trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // 讓編譯器製作一個 trait 對象
/// let object: &dyn Foo = &value;
///
/// // 看原始表示
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // 數據指針是 `value` 的地址
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // 構造一個指向另一個 `i32` 的新對象，請小心使用 `object` 的 `i32` vtable
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // 它應該就像我們直接從 `other_value` 構造了一個 trait 對像一樣工作
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}