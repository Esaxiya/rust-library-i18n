//! 共享的可變容器。
//!
//! Rust 內存安全性基於以下規則: 給定對象 `T`，則只能具有以下之一:
//!
//! - 對該對象具有多個不可變的引用 (`&T`) (也稱為 `別名`)。
//! - 對對像有一個可變的引用 (`＆mut T`) (也稱為 `可變性`)。
//!
//! 這由 Rust 編譯器強制執行。但是，在某些情況下，此規則不夠靈活。有時需要對一個對像有多個引用並對其進行突變。
//!
//! 存在共享的可變容器以允許以受控的方式進行可變性，即使存在混疊也是如此。[`Cell<T>`] 和 [`RefCell<T>`] 都允許以單線程方式執行此操作。
//! 但是，`Cell<T>` 和 `RefCell<T>` 都不是線程安全的 (它們不實現 [`Sync`])。
//! 如果需要在多個線程之間進行別名和突變，則可以使用 [`Mutex<T>`]，[`RwLock<T>`] 或 [`atomic`] 類型。
//!
//! `Cell<T>` 和 `RefCell<T>` 類型的值可以通過共享引用進行突變 (即
//! 通常是 `&T` 類型)，而大多數 Rust 類型只能通過唯一的 (`＆mut T`) 引用進行突變。
//! 我們說 `Cell<T>` 和 `RefCell<T>` 提供了 `內部可變性`，而典型的 Rust 類型卻表現出 `繼承的可變性`。
//!
//! 單元格類型有兩種: `Cell<T>` 和 `RefCell<T>`。`Cell<T>` 通過將值移入和移出 `Cell<T>` 來實現內部可變性。
//! 要使用引用而不是值，必須使用 `RefCell<T>` 類型，並在進行更改之前獲取寫鎖定。`Cell<T>` 提供了檢索和更改當前內部值的方法:
//!
//!  - 對於實現 [`Copy`] 的類型，[`get`](Cell::get) 方法檢索當前內部值。
//!  - 對於實現 [`Default`] 的類型，[`take`](Cell::take) 方法將當前內部值替換為 [`Default::default()`]，然後返回替換後的值。
//!  - 對於所有類型，[`replace`](Cell::replace) 方法將替換當前內部值並返回替換後的值，而 [`into_inner`](Cell::into_inner) 方法將使用 `Cell<T>` 並返回內部值。
//!  此外，[`set`](Cell::set) 方法替換內部值，刪除替換後的值。
//!
//! `RefCell<T>` 使用 Rust 的生命週期來實現 `動態借用`，這一過程使人們可以要求臨時，排他，可變地訪問內部值。
//! 借用 'RefCell<T>s 是在 `運行時` 被跟踪的，這與 Rust 的本機引用類型不同，後者在編譯時被完全靜態地跟踪。
//! 因為 `RefCell<T>` 借位是動態的，所以可以嘗試借用已經可變借值的值; 發生這種情況時，將導致線程 panic。
//!
//! # 何時選擇內部可變性
//!
//! 更常見的繼承變異性 (必須具有對變量的唯一訪問權) 是使 Rust 能夠強烈考慮指針別名的關鍵語言元素之一，從而可以靜態地防止崩潰錯誤。
//! 因此，首選繼承的可變性，而內部可變性是不得已的方法。
//! 由於細胞類型可以實現原本不允許的突變，因此有時內部變異性可能是適當的，甚至必須 *必須* 使用，例如
//!
//! * 介紹不可變項的可變性 'inside'
//! * 邏輯不變方法的實現細節。
//! * 更改 [`Clone`] 的實現。
//!
//! ## 介紹不可變項的可變性 'inside'
//!
//! 許多共享的智能指針類型，包括 [`Rc<T>`] 和 [`Arc<T>`]，都提供了可以在多方之間克隆和共享的容器。
//! 由於所包含的值可能會被乘以別名，因此只能通過 `&` 借用，而不能通過 `&mut` 借用。
//! 沒有單元，根本不可能在這些智能指針中對數據進行突變。
//!
//! 然後將 `RefCell<T>` 放在共享指針類型中以重新引入可變性是很常見的:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // 創建一個新塊以限制動態借閱的範圍
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // 請注意，如果我們不讓緩存的先前借用超出範圍，那麼後續借用將導致動態線程 panic。
//!     //
//!     // 這是使用 `RefCell` 的主要危險。
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! 請注意，此示例使用 `Rc<T>`，而不使用 `Arc<T>`。`RefCell<T>`s 用於單線程方案。如果在多線程情況下需要共享可變性，請考慮使用 [`RwLock<T>`] 或 [`Mutex<T>`]。
//!
//! ## 邏輯不變方法的實現細節
//!
//! 有時可能希望不要在 API 中公開 "under the hood" 發生了突變。
//! 這可能是因為該操作在邏輯上是不可變的，但是例如，緩存會強制實現執行突變; 或因為必須使用變異來實現最初定義為採用 `&self` 的 trait 方法。
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // 昂貴的計算在這裡
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## 改變 `Clone` 的實現
//!
//! 這只是前一種情況的一種特殊但常見的情況: 為看起來是不變的操作隱藏了可變性。
//! 預期 [`clone`](Clone::clone) 方法不會更改源值，並聲明採用 `&self`，而不是 `&mut self`。
//! 因此，在 `clone` 方法中發生的任何突變都必須使用細胞類型。
//! 例如，[`Rc<T>`] 在 `Cell<T>` 內保持其引用計數。
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// 可變的內存位置。
///
/// # Examples
///
/// 在此示例中，您可以看到 `Cell<T>` 啟用了不可變結構內的突變。
/// 換句話說，它啟用 "interior mutability"。
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // 錯誤: `my_struct` 是不可變的
/// // my_struct.regular_field =new_value;
///
/// // 作品: 儘管 `my_struct` 是不可變的，但 `special_field` 是 `Cell`，
/// // 總是可以變異的
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// 有關更多信息，請參見 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// 創建一個 `Cell<T>`，其 T 值為 `Default`。
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// 創建一個包含給定值的新 `Cell`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// 設置包含的值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// 交換兩個單元格的值。
    /// 與 `std::mem::swap` 的區別在於此功能不需要 `&mut` 引用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // 安全: 如果從單獨的線程中調用，可能會有風險，但是 `Cell`
        // 是 `!Sync`，因此不會發生。
        // 這也不會使任何指針無效，因為 `Cell` 確保沒有其他指針指向這些 `單元` 中的任何一個。
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// 用 `val` 替換包含的值，並返回舊的包含值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // 安全: 如果從單獨的線程中調用，這可能導致數據爭用，
        // 但是 `Cell` 是 `!Sync`，因此不會發生。
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// 取消包裝值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// 返回所包含值的副本。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // 安全: 如果從單獨的線程中調用，這可能導致數據爭用，
        // 但是 `Cell` 是 `!Sync`，因此不會發生。
        unsafe { *self.value.get() }
    }

    /// 使用函數更新包含的值並返回新值。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// 返回指向此單元格中基礎數據的原始指針。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 返回對基礎數據的可變引用。
    ///
    /// 此調用可變地借用 `Cell` (在編譯時)，這保證了我們擁有唯一的引用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// 從 `&mut T` 返回 `&Cell<T>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // 安全: `&mut` 確保唯一的訪問權限。
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// 取單元格的值，將 `Default::default()` 保留在其位置。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// 從 `&Cell<[T]>` 返回 `&[Cell<T>]`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // 安全: `Cell<T>` 與 `T` 具有相同的內存佈局。
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// 具有動態檢查借位規則的可變內存位置
///
/// 有關更多信息，請參見 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] 返回的錯誤。
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] 返回的錯誤。
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// 正值表示 `Ref` 有效的數量。負值表示活動的 `RefMut` 的數量。
// 如果多個 `RefMut` 引用 `RefCell` 的不同，不重疊的組件 (例如，切片的不同範圍)，則一次只能處於活動狀態。
//
// `Ref` 和 `RefMut` 都是兩個字，因此可能不會有足夠的 `Ref` 或 `RefMut` 來溢出 `usize` 範圍的一半。
// 因此，`BorrowFlag` 可能永遠不會上溢或下溢。
// 但是，這不是保證，因為病理程序可以反复創建，然後 mem::forget Ref`s 或 `RefMut`s。
// 因此，所有代碼都必須顯式檢查上溢和下溢，以避免不安全，或者至少在發生上溢或下溢的情況下正確運行 (例如，參見 BorrowRef::new)。
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// 創建一個包含 `value` 的新 `RefCell`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// 消耗 `RefCell`，返回包裝後的值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // 由於此函數按值取 `self` (`RefCell`)，因此編譯器將靜態驗證當前未借用它。
        //
        self.value.into_inner()
    }

    /// 將包裝的值替換為新的值，並返回舊值，而無需對其中一個進行初始化。
    ///
    ///
    /// 該功能對應於 [`std::mem::replace`](../mem/fn.replace.html)。
    ///
    /// # Panics
    ///
    /// Panics (如果當前借用了該值)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// 用從 `f` 計算出的新值替換包裝後的值，並返回舊值，而無需對這兩個值進行任何初始化。
    ///
    ///
    /// # Panics
    ///
    /// Panics (如果當前借用了該值)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// 將 `self` 的包裝值與 `other` 的包裝值交換，而無需對其中之一進行初始化。
    ///
    ///
    /// 該功能對應於 [`std::mem::swap`](../mem/fn.swap.html)。
    ///
    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// 一成不變地借用包裝後的價值。
    ///
    /// 借用一直持續到返回的 `Ref` 退出作用域為止。
    /// 可以同時提取多個不可變的借項。
    ///
    /// # Panics
    ///
    /// Panics (如果該值當前是可變借用的)。
    /// 對於非驚慌的變體，請使用 [`try_borrow`](#method.try_borrow)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic 的示例:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// 不可變地借用包裝的值，如果當前是可變地借用的值，則返回錯誤。
    ///
    ///
    /// 借用一直持續到返回的 `Ref` 退出作用域為止。
    /// 可以同時提取多個不可變的借項。
    ///
    /// 這是 [`borrow`](#method.borrow) 的非緊急變體。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // 安全: `BorrowRef` 確保只有不變的訪問權限
            // 借入時的價值。
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// 可變地借用包裝的價值。
    ///
    /// 借用一直持續到返回的 `RefMut` 或從其出口範圍派生的所有 `RefMut` 為止。
    ///
    /// 該借用處於活動狀態時，不能藉入該值。
    ///
    /// # Panics
    ///
    /// Panics (如果當前借用了該值)。
    /// 對於非驚慌的變體，請使用 [`try_borrow_mut`](#method.try_borrow_mut)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic 的示例:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// 可變地借用包裝的值，如果當前借用的值則返回錯誤。
    ///
    ///
    /// 借用一直持續到返回的 `RefMut` 或從其出口範圍派生的所有 `RefMut` 為止。
    /// 該借用處於活動狀態時，不能藉入該值。
    ///
    /// 這是 [`borrow_mut`](#method.borrow_mut) 的非緊急變體。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // 安全: `BorrowRef` 保證唯一訪問。
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// 返回指向此單元格中基礎數據的原始指針。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 返回對基礎數據的可變引用。
    ///
    /// 該調用可變地借用 `RefCell` (在編譯時)，因此不需要動態檢查。
    ///
    /// 但是要小心: 此方法期望 `self` 是可變的，通常在使用 `RefCell` 時不是這種情況。
    ///
    /// 如果 `self` 不可變，請看看 [`borrow_mut`] 方法。
    ///
    /// 另外，請注意，此方法僅適用於特殊情況，通常不是您想要的。
    /// 如有疑問，請改用 [`borrow_mut`]。
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// 撤消洩漏的防護對 `RefCell` 借入狀態的影響。
    ///
    /// 該調用類似於 [`get_mut`]，但更加專業。
    /// 它可變地借用 `RefCell` 以確保不存在藉用，然後重置狀態跟踪共享借用。
    /// 如果某些 `Ref` 或 `RefMut` 借用已洩漏，則這是相關的。
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// 不可變地借用包裝的值，如果當前是可變地借用的值，則返回錯誤。
    ///
    /// # Safety
    ///
    /// 與 `RefCell::borrow` 不同，此方法是不安全的，因為它不返回 `Ref`，從而使借位標誌保持不變。
    /// 在此方法返回的引用有效時，可藉用 `RefCell` 是未定義的行為。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // 安全: 我們檢查現在沒有人在積極寫作，但這是
            // 調用者有責任確保在返回的引用不再使用之前沒有人寫。
            // 同樣，`self.value.get()` 指的是 `self` 擁有的值，因此可以保證在 `self` 的生命週期內有效。
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// 取包裝值，將 `Default::default()` 留在其位置。
    ///
    /// # Panics
    ///
    /// Panics (如果當前借用了該值)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics (如果該值當前是可變借用的)。
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// 創建一個 `RefCell<T>`，其 T 值為 `Default`。
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics (如果當前借用了 `RefCell` 中的值)。
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // 在以下情況下，增加借位可能會導致未讀值 (<=0) :
            // 1. 它小於 0，即存在寫借用，因此由於 Rust 的參考別名規則，我們不允許讀取借用
            // 2.
            // 它是 isize::MAX (最大讀取借閱量)，並且溢出到 isize::MIN (最大寫入借閱量)，因此我們不允許額外的讀取借閱，因為 isize 不能表示這麼多的讀取借閱 (僅當發生以下情況時才發生) 您的 mem::forget 超過了少量恆定的 `Ref`，這不是一個好習慣)
            //
            //
            //
            //
            None
        } else {
            // 在以下情況下，增加借位可能會導致讀取值 (> 0) :
            // 1. =0，即未借用，而我們正在進行第一次讀取借用
            // 2. 它是 > 0 且 < isize::MAX，即
            // 有讀取借閱，並且 isize 足夠大，可以表示又有一個讀取借閱
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // 由於該 Ref 存在，因此我們知道該借位標誌為閱讀借位。
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // 防止借閱計數器溢出到書面借閱中。
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// 在 `RefCell` 框中包裝對值的借用引用。
/// 從 `RefCell<T>` 不變借來的值的包裝器類型。
///
/// 有關更多信息，請參見 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// 複製 `Ref`。
    ///
    /// `RefCell` 已經被一成不變地借用了，因此這不會失敗。
    ///
    /// 這是一個相關功能，需要用作 `Ref::clone(...)`。
    /// `Clone` 的實現或方法將乾擾 `r.borrow().clone()` 的廣泛使用，以克隆 `RefCell` 的內容。
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// 為藉入數據的一部分製作新的 `Ref`。
    ///
    /// `RefCell` 已經被一成不變地借用了，因此這不會失敗。
    ///
    /// 這是一個相關功能，需要用作 `Ref::map(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// 為藉入數據的可選組件製作新的 `Ref`。
    /// 如果閉包返回 `None`，則原始防護作為 `Err(..)` 返回。
    ///
    /// `RefCell` 已經被一成不變地借用了，因此這不會失敗。
    ///
    /// 這是一個相關功能，需要用作 `Ref::filter_map(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// 將 `Ref` 拆分為多個 `Ref`，以用於借入數據的不同組成部分。
    ///
    /// `RefCell` 已經被一成不變地借用了，因此這不會失敗。
    ///
    /// 這是一個相關功能，需要用作 `Ref::map_split(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// 轉換為對基礎數據的引用。
    ///
    /// 底層的 `RefCell` 永遠不會再被可變借用，並且總是看起來已經是不可更改的借用。
    ///
    /// 洩漏過多的引用不是一個好主意。
    /// 如果總共只發生了少量的洩漏，則可以再次借用 `RefCell`。
    ///
    /// 這是一個相關功能，需要用作 `Ref::leak(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // 通過忘記該 Ref，我們可以確保 RefCell 中的借用計數器在生命週期 `'b` 內不會返回到 UNUSED。
        // 重置參考跟踪狀態將需要對借用的 RefCell 的唯一參考。
        // 無法從原始單元格創建其他可變引用。
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// 為藉用數據的一部分 (例如，枚舉變量) 創建新的 `RefMut`。
    ///
    /// `RefCell` 已經是可變借用的，因此這不會失敗。
    ///
    /// 這是一個相關功能，需要用作 `RefMut::map(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): 修復借閱支票
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// 為藉入數據的可選組件製作新的 `RefMut`。
    /// 如果閉包返回 `None`，則原始防護作為 `Err(..)` 返回。
    ///
    /// `RefCell` 已經是可變借用的，因此這不會失敗。
    ///
    /// 這是一個相關功能，需要用作 `RefMut::filter_map(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): 修復借閱支票
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // 安全: 該功能在整個持續時間內都保留為專有參考
        // 它通過 `orig` 進行調用，並且僅在函數調用內部取消對指針的引用，從不允許獨占引用轉義。
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // 安全: 與上述相同。
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// 將 `RefMut` 拆分為多個 `RefMut`，以用於借入數據的不同組成部分。
    ///
    /// 底層的 `RefCell` 將保持可變借用狀態，直到兩個返回的 RefMut 都超出範圍為止。
    ///
    /// `RefCell` 已經是可變借用的，因此這不會失敗。
    ///
    /// 這是一個相關功能，需要用作 `RefMut::map_split(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// 轉換為對基礎數據的可變引用。
    ///
    /// 基礎 `RefCell` 不能再次借用，並且總是看起來已經可變地借用了，從而使返回的引用成為內部的唯一引用。
    ///
    ///
    /// 這是一個相關功能，需要用作 `RefMut::leak(...)`。
    /// 方法會干擾通過 `Deref` 使用的 `RefCell` 內容中的同名方法。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // 通過忘記此 BorrowRefMut，我們確保 RefCell 中的借用計數器在生命週期 `'b` 內不會返回到 UNUSED。
        // 重置參考跟踪狀態將需要對借用的 RefCell 的唯一參考。
        // 在該生命週期內無法從原始單元創建更多引用，從而使當前借閱項成為剩餘生命週期的唯一參考。
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: 與 BorrowRefMut::clone 不同，將調用 new 來創建初始
        // 可變參考，因此當前必須沒有現有參考。
        // 因此，儘管克隆增加了可變引用計數，但在這裡我們明確只允許從 UNUSED 轉到 UNUSED，1。
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // 克隆 `BorrowRefMut`。
    //
    // 僅當每個 `BorrowRefMut` 用於跟踪對原始對像不同的，不重疊範圍的可變引用時，這才有效。
    //
    // 這不在 Clone 隱含中，因此代碼不會隱式調用此函數。
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // 防止借出計數器下溢。
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// 從 `RefCell<T>` 可變借來的值的包裝器類型。
///
/// 有關更多信息，請參見 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust 中內部可變性的核心原語。
///
/// 如果您有參考 `&T`，則通常在 Rust 中，編譯器將基於 `&T` 指向不可變數據的知識來執行優化。例如通過別名或通過將 `&T` 轉換為 `&mut T` 來對該數據進行突變，被認為是未定義的行為。
/// `UnsafeCell<T>` 退出 `&T` 的不變性保證: 共享引用 `&UnsafeCell<T>` 可能指向正在突變的數據。這稱為 "interior mutability"。
///
/// 所有其他允許內部可變性的類型 (例如 `Cell<T>` 和 `RefCell<T>`) 在內部都使用 `UnsafeCell` 來包裝其數據。
///
/// 請注意，`UnsafeCell` 僅影響共享引用的不變性保證。可變引用的唯一性保證不受影響。沒有 *合法* 的方法來獲得 `&mut` 的別名，即使使用 `UnsafeCell<T>` 也沒有。
///
/// `UnsafeCell` API 本身在技術上非常簡單: [`.get()`] 為您提供了指向其內容的原始指針 `*mut T`。_you_ 作為抽象設計者，必須正確使用該原始指針。
///
/// [`.get()`]: `UnsafeCell::get`
///
/// 精確的 Rust 混疊規則有些變化，但是要點並不存在爭議:
///
/// - 如果創建的生命週期為 `'a` 的安全引用 (`&T` 或 `&mut T` 引用) 可以通過安全代碼訪問 (例如，因為返回了它)，那麼您不得以任何與該引用衝突的方式訪問數據 `'a`。
/// 例如，這意味著如果您從 `UnsafeCell<T>` 中取出 `*mut T` 並將其轉換為 `&T`，則 `T` 中的數據必須保持不變 (當然，對 `T` 中找到的任何 `UnsafeCell` 數據進行模運算)，直到該引用的生存期到期為止。
/// 同樣，如果您創建了發布給安全代碼的 `&mut T` 引用，則在該引用過期之前，您不得訪問 `UnsafeCell` 中的數據。
///
/// - 在任何時候，您都必須避免數據爭用。如果多個線程可以訪問同一個 `UnsafeCell`，那麼任何寫操作都必須在與所有其他訪問 (或使用原子) 相關之前發生正確的事件。
///
/// 為了幫助進行正確的設計，以下情況明確聲明為單線程代碼合法:
///
/// 1. 可以將 `&T` 參考發佈為安全代碼，並且可以與其他 `&T` 參考共存，但不能與 `&mut T` 共存。
///
/// 2. 如果 `&mut T` 參考沒有與其他 `&mut T` 和 `&T` 共存，則可以將其發佈為安全代碼。`&mut T` 必須始終是唯一的。
///
/// 請注意，雖然可以更改 `&UnsafeCell<T>` 的內容 (即使其他 `&UnsafeCell<T>` 引用為單元格加上別名) 也可以 (只要以其他方式實施上述不變式即可)，但是具有多個 `&mut UnsafeCell<T>` 別名仍然是未定義的行為。
/// 也就是說，`UnsafeCell` 是一種包裝，旨在通過 `&UnsafeCell<_>` 參考與 _shared_ accesses (_i.e._ 進行特殊交互) ; 通過 `&mut UnsafeCell<_>` 處理 _exclusive_ accesses (_e.g._ 時，沒有任何魔術: 在 `&mut` 借用期間，單元格和包裝值都不能被別名。
///
/// [`.get_mut()`] 訪問器展示了這一點，該訪問器是產生 `&mut T` 的 _safe_ getter。
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// 這是一個示例，展示瞭如何合理改變 `UnsafeCell<_>` 的內容，儘管有多個引用使單元格出現別名:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // 獲取對同一 `x` 的多個 / 並發 / 共享引用。
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // 安全: 在此範圍內，沒有其他引用 `x` 的內容，
///     // 所以我們的實際上是獨一無二的。
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- 借 -+
///     *p1_exclusive += 27; // |
/// } // <---------- 不能超出這一點 -------------------+
///
/// unsafe {
///     // 安全: 在此範圍內，沒有人期望擁有對 x 內容的獨占訪問權，
///     // 因此我們可以同時進行多個共享訪問。
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// 以下示例展示了對 `UnsafeCell<T>` 的獨占訪問意味著對其 `T` 的獨占訪問的事實:
///
/// ```rust
/// #![forbid(unsafe_code)] // 具有獨占訪問權，
///                         // `UnsafeCell` 是透明的無操作包裝器，因此這裡不需要 `unsafe`。
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // 獲得對 `x` 進行編譯時檢查的唯一引用。
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // 有了獨家參考，我們可以免費更改內容。
/// *p_unique.get_mut() = 0;
/// // 或者，等效地:
/// x = UnsafeCell::new(0);
///
/// // 當我們擁有該值時，我們可以免費提取內容。
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// 構造 `UnsafeCell` 的新實例，該實例將包裝指定的值。
    ///
    ///
    /// 通過方法對內部值的所有訪問都是 `unsafe`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// 取消包裝值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// 獲取指向包裝值的可變指針。
    ///
    /// 可以將其強制轉換為任何類型的指針。
    /// 強制轉換為 `&mut T` 時，訪問是唯一的 (無活動引用，是否可變)，並確保轉換為 `&T` 時不存在任何突變或可變別名。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // 由於 #[repr(transparent)]，我們只能將指針從 `UnsafeCell<T>` 投射到 `T`。
        // 這利用了 libstd 的特殊狀態，無法保證用戶代碼可以在 future 版本的編譯器中正常工作!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// 返回對基礎數據的可變引用。
    ///
    /// 該調用可變地借用了 `UnsafeCell` (在編譯時)，這保證了我們擁有唯一的引用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// 獲取指向包裝值的可變指針。
    /// 與 [`get`] 的區別在於此函數接受原始指針，這對於避免創建臨時引用很有用。
    ///
    /// 結果可以轉換為任何類型的指針。
    /// 強制轉換為 `&mut T` 時，訪問是唯一的 (無活動引用，是否可變)，並確保轉換為 `&T` 時沒有發生任何突變或可變別名。
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` 的逐步初始化需要 `raw_get`，因為調用 `get` 需要創建對未初始化數據的引用:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // 由於 #[repr(transparent)]，我們只能將指針從 `UnsafeCell<T>` 投射到 `T`。
        // 這利用了 libstd 的特殊狀態，無法保證用戶代碼可以在 future 版本的編譯器中正常工作!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// 創建一個 `UnsafeCell`，其 T 值為 `Default`。
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}