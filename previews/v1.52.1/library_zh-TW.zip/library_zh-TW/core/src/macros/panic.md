Panics 當前線程。

這允許程序立即終止並向程序的調用者提供反饋。
`panic!` 當程序達到不可恢復的狀態時應使用。

該宏是在示例代碼和測試中聲明條件的理想方式。
`panic!` 與 [`Option`][ounwrap] 和 [`Result`][runwrap] 枚舉的 `unwrap` 方法緊密相關。
當兩個實現都設置為 [`None`] 或 [`Err`] 變體時，它們都將調用 `panic!`。

使用 `panic!()` 時，可以指定使用 [`format!`] 語法構建的字符串有效負載。
當將 panic 注入到調用的 Rust 線程中時，將使用該有效負載，從而導致該線程完全變為 panic。

默認 `std` hook 的行為，即
調用 panic 之後直接運行的代碼是將消息有效負載以及 `panic!()` 調用的 file/line/column 信息打印到 `stderr`。

您可以使用 [`std::panic::set_hook()`] 覆蓋 panic hook。
在 hook 內部，可以將 X0panic0Z 作為 `&dyn Any + Send` 進行訪問，其中包含用於常規 `panic!()` 調用的 `&str` 或 `String`。
對於具有其他類型值的 panic，可以使用 [`panic_any`]。

[`Result`] 與使用 `panic!` 宏相比，枚舉通常是從錯誤中恢復的更好的解決方案。
應該使用此宏來避免繼續使用不正確的值，例如來自外部源的值。
有關錯誤處理的詳細信息，請參見 [book]。

另請參見宏 [`compile_error!`]，以獲取編譯期間的錯誤。

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# 當前實施

如果主線程為 panics，它將終止您的所有線程並以代碼 `101` 結束您的程序。

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





