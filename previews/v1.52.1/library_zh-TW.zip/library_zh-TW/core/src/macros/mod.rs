#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // 根據調用者的版本擴展為 `$crate::panic::panic_2015` 或 `$crate::panic::panic_2021`。
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// 斷言兩個表達式彼此相等 (使用 [`PartialEq`])。
///
/// 在 panic 上，此宏將打印表達式的值及其調試表示。
///
///
/// 像 [`assert!`] 一樣，此宏具有第二種形式，可以在其中提供自定義 panic 消息。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 下面的重新借閱是有意的。
                    // 如果沒有它們，則即使在比較值之前也會初始化借用的堆棧插槽，從而導致速度明顯下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 下面的重新借閱是有意的。
                    // 如果沒有它們，則即使在比較值之前也會初始化借用的堆棧插槽，從而導致速度明顯下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 斷言兩個表達式彼此不相等 (使用 [`PartialEq`])。
///
/// 在 panic 上，此宏將打印表達式的值及其調試表示。
///
///
/// 像 [`assert!`] 一樣，此宏具有第二種形式，可以在其中提供自定義 panic 消息。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 下面的重新借閱是有意的。
                    // 如果沒有它們，則即使在比較值之前也會初始化借用的堆棧插槽，從而導致速度明顯下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 下面的重新借閱是有意的。
                    // 如果沒有它們，則即使在比較值之前也會初始化借用的堆棧插槽，從而導致速度明顯下降。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 聲明在運行時布爾表達式為 `true`。
///
/// 如果提供的表達式在運行時無法評估為 `true`，則它將調用 [`panic!`] 宏。
///
/// 與 [`assert!`] 一樣，此宏也具有第二個版本，可以在其中提供自定義 panic 消息。
///
/// # Uses
///
/// 與 [`assert!`] 不同，默認情況下，僅在未經優化的內部版本中啟用 `debug_assert!` 語句。
/// 除非將 `-C debug-assertions` 傳遞給編譯器，否則優化的構建將不執行 `debug_assert!` 語句。
/// 這使得 `debug_assert!` 對於檢查成本很高，以至於無法在發行版本中進行檢查，但在開發過程中可能會有所幫助。
/// 擴展 `debug_assert!` 的結果始終是類型檢查的。
///
/// 未檢查的斷言允許處於不一致狀態的程序繼續運行，這可能會帶來意想不到的後果，但不會引入不安全性，只要這種不安全性僅在安全代碼中發生即可。
///
/// 但是，斷言的性能成本通常無法衡量。
/// 因此，僅在經過全面分析後才鼓勵使用 `debug_assert!` 替換 [`assert!`]，更重要的是，僅使用安全代碼!
///
/// # Examples
///
/// ```
/// // 這些斷言的 panic 消息是給定表達式的字符串化值。
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // 一個非常簡單的功能
/// debug_assert!(some_expensive_computation());
///
/// // 使用自定義消息進行斷言
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// 斷言兩個表達式彼此相等。
///
/// 在 panic 上，此宏將打印表達式的值及其調試表示。
///
/// 與 [`assert_eq!`] 不同，默認情況下，僅在未經優化的內部版本中啟用 `debug_assert_eq!` 語句。
/// 除非將 `-C debug-assertions` 傳遞給編譯器，否則優化的構建將不執行 `debug_assert_eq!` 語句。
/// 這使 `debug_assert_eq!` 對於檢查成本太高而無法在發行版本中進行檢查，但在開發過程中可能很有用。
///
/// 擴展 `debug_assert_eq!` 的結果始終是類型檢查的。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// 斷言兩個表達式彼此不相等。
///
/// 在 panic 上，此宏將打印表達式的值及其調試表示。
///
/// 與 [`assert_ne!`] 不同，默認情況下，僅在未經優化的內部版本中啟用 `debug_assert_ne!` 語句。
/// 除非將 `-C debug-assertions` 傳遞給編譯器，否則優化的構建將不執行 `debug_assert_ne!` 語句。
/// 這使得 `debug_assert_ne!` 對於檢查成本很高，以至於無法在發行版本中進行檢查，但在開發過程中可能會有所幫助。
///
/// 擴展 `debug_assert_ne!` 的結果始終是類型檢查的。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// 返回給定表達式是否與任何給定模式匹配。
///
/// 像在 `match` 表達式中一樣，可以在模式後跟 `if` 和可以訪問由模式綁定的名稱的保護表達式。
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// 解開結果或傳播其錯誤。
///
/// 添加了 `?` 運算符以替換 `try!`，應使用它代替。
/// 此外，`try` 是 Rust 2018 中的保留字，因此如果必須使用它，則需要使用 [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` 匹配給定的 [`Result`]。如果是 `Ok` 變體，則表達式具有包裝值的值。
///
/// 如果是 `Err` 變體，它將檢索內部錯誤。`try!` 然後使用 `From` 執行轉換。
/// 這樣可以在特殊錯誤和更常見錯誤之間進行自動轉換。
/// 然後立即返回產生的錯誤。
///
/// 由於提前返回，因此 `try!` 僅可用於返回 [`Result`] 的函數中。
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // 快速返回錯誤的首選方法
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // 快速返回錯誤的先前方法
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // 這等效於:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// 將格式化的數據寫入緩衝區。
///
/// 該宏接受 'writer'，格式字符串和參數列表。
/// 參數將根據指定的格式字符串進行格式化，並將結果傳遞給編寫器。
/// `write_fmt` 方法中的 writer 可以是任何值; 通常，這來自 [`fmt::Write`] 或 [`io::Write`] trait 的實現。
/// 宏返回 `write_fmt` 方法返回的任何內容; 通常是 [`fmt::Result`] 或 [`io::Result`]。
///
/// 有關格式字符串語法的更多信息，請參見 [`std::fmt`]。
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// 模塊可以同時導入 `std::fmt::Write` 和 `std::io::Write`，並且可以在實現兩者的對像上調用 `write!`，因為對象通常不會同時實現兩者。
///
/// 但是，該模塊必須導入合格的 traits，以便其名稱不會衝突:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // 使用 fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // 使用 io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: 該宏也可以在 `no_std` 設置中使用。
/// 在 `no_std` 設置中，您負責組件的實現細節。
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// 將格式化的數據寫入緩衝區，並附加換行符。
///
/// 在所有平台上，換行符僅是 LINE FEED 字符 (`\n`/`U+000A`) (沒有其他的 CARRIAGE RETURN (`\r`/`U+000D`)。
///
/// 有關更多信息，請參見 [`write!`]。有關格式字符串語法的信息，請參見 [`std::fmt`]。
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// 模塊可以同時導入 `std::fmt::Write` 和 `std::io::Write`，並且可以在實現兩者的對像上調用 `write!`，因為對象通常不會同時實現兩者。
/// 但是，該模塊必須導入合格的 traits，以便其名稱不會衝突:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // 使用 fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // 使用 io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// 表示無法訪問的代碼。
///
/// 每當編譯器無法確定某些代碼不可訪問時，此功能就很有用。例如:
///
/// * 使武器與警衛條件匹配。
/// * 動態終止的循環。
/// * 動態終止的迭代器。
///
/// 如果確定代碼不可訪問不正確，則程序立即以 [`panic!`] 終止。
///
/// 該宏的不安全對應項是 [`unreachable_unchecked`] 函數，如果到達代碼，它將導致未定義的行為。
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// 這將始終為 [`panic!`]。
///
/// # Examples
///
/// 比賽武器:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // 如果註釋掉，則編譯錯誤
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 最差的實現之一
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// 通過恐慌並帶有 "not implemented" 消息來指示未實現的代碼。
///
/// 這使您的代碼可以進行類型檢查，這在原型或實現 trait 且需要多種方法而您不打算使用全部方法的情況下非常有用。
///
/// `unimplemented!` 和 [`todo!`] 之間的區別在於，儘管 `todo!` 傳達了稍後實現該功能的意圖，並且消息為 "not yet implemented"，但 `unimplemented!` 並未提出任何此類聲明。
/// 它的消息是 "not implemented"。
/// 還有一些 IDE 會標記 `todo! `s。
///
/// # Panics
///
/// 這將始終是 [`panic!`]，因為 `unimplemented!` 只是 `panic!` 的簡寫，帶有固定的特定消息。
///
/// 像 `panic!` 一樣，此宏具有用於顯示自定義值的第二種形式。
///
/// # Examples
///
/// 假設我們有一個 trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 我們想為 'MyStruct' 實現 `Foo`，但是由於某些原因，只有實現 `bar()` 功能才有意義。
/// `baz()` 在我們的 `Foo` 實現中仍然需要定義 `qux()`，但是我們可以在其定義中使用 `unimplemented!` 來編譯我們的代碼。
///
/// 如果達到未實現的方法，我們仍然希望程序停止運行。
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` 和 `MyStruct` 沒有任何意義，因此我們完全沒有邏輯。
/////
///         // 這將顯示 "thread 'main' panicked at 'not implemented'"。
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // 我們這裡有一些邏輯，我們可以向未實現中添加一條消息! 顯示我們的遺漏。
///         // 這將顯示: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// 表示未完成的代碼。
///
/// 如果您要進行原型設計並且只是在檢查代碼類型，這可能會很有用。
///
/// [`unimplemented!`] 和 `todo!` 之間的區別在於，儘管 `todo!` 傳達了稍後實現該功能的意圖，並且消息為 "not yet implemented"，但 `unimplemented!` 並未提出此類聲明。
/// 它的消息是 "not implemented"。
/// 還有一些 IDE 會標記 `todo! `s。
///
/// # Panics
///
/// 這將始終為 [`panic!`]。
///
/// # Examples
///
/// 這是一些正在進行的代碼的示例。我們有一個 trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// 我們想在其中一種類型上實現 `Foo`，但我們也想先僅在 `bar()` 上工作。為了編譯我們的代碼，我們需要實現 `baz()`，因此我們可以使用 `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // 實施在這裡
///     }
///
///     fn baz(&self) {
///         // 讓我們現在不必擔心實現 baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // 我們甚至沒有使用 baz()，所以很好。
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// 內置宏的定義。
///
/// 大多數宏屬性 (穩定性，可見性等) 均從此處的源代碼中獲取，除了將宏輸入轉換為輸出的擴展功能外，這些功能均由編譯器提供。
///
///
pub(crate) mod builtin {

    /// 導致編譯失敗，並遇到給定的錯誤消息。
    ///
    /// 當 crate 使用條件編譯策略為錯誤條件提供更好的錯誤消息時，應使用此宏。
    ///
    /// 它是 [`panic!`] 的編譯器級別的形式，但是在 *compilation* 而不是 *runtime* 時發出錯誤。
    ///
    /// # Examples
    ///
    /// 宏和 `#[cfg]` 環境就是兩個這樣的示例。
    ///
    /// 如果將無效值傳遞給宏，則發出更好的編譯器錯誤。
    /// 沒有最終的 branch，編譯器仍會發出錯誤，但錯誤消息中不會提及兩個有效值。
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// 如果許多功能之一不可用，則發出編譯器錯誤。
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 構造其他字符串格式宏的參數。
    ///
    /// 此宏通過為每個傳遞的其他參數採用包含 `{}` 的格式字符串文字來運行。
    /// `format_args!` 準備其他參數，以確保輸出可以解釋為字符串，並將參數規範化為單個類型。
    /// 可以將實現 [`Display`] trait 的任何值傳遞給 `format_args!`，也可以將任何 [`Debug`] 實現的形式傳遞給格式化字符串中的 `{:?}`。
    ///
    ///
    /// 該宏產生 [`fmt::Arguments`] 類型的值。可以將該值傳遞到 [`std::fmt`] 內的宏，以執行有用的重定向。
    /// 所有其他格式化宏 ([`format! `]，[`write!`]，[`println!`] 等) 都通過此代理。
    /// `format_args!`, 與它的派生宏不同，它避免了堆分配。
    ///
    /// 您可以使用 `format_args!` 在 `Debug` 和 `Display` 上下文中返回的 [`fmt::Arguments`] 值，如下所示。
    /// 該示例還顯示 `Debug` 和 `Display` 的格式相同: `format_args!` 中的插值格式字符串。
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// 有關更多信息，請參見 [`std::fmt`] 中的文檔。
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// 與 `format_args` 相同，但最後添加一個換行符。
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// 在編譯時檢查環境變量。
    ///
    /// 該宏將在編譯時擴展為指定環境變量的值，從而產生 `&'static str` 類型的表達式。
    ///
    ///
    /// 如果未定義環境變量，則將發出編譯錯誤。
    /// 若要不產生編譯錯誤，請改用 [`option_env!`] 宏。
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// 您可以通過傳遞字符串作為第二個參數來自定義錯誤消息:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// 如果未定義 `documentation` 環境變量，則會出現以下錯誤:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// (可選) 在編譯時檢查環境變量。
    ///
    /// 如果在編譯時存在指定的環境變量，它將擴展為 `Option<&'static str>` 類型的表達式，其值是環境變量的值的 `Some`。
    /// 如果不存在環境變量，則它將擴展為 `None`。
    /// 有關此類型的更多信息，請參見 [`Option<T>`][Option]。
    ///
    /// 使用此宏時，無論是否存在環境變量，都不會發出編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 將標識符串聯爲一個標識符。
    ///
    /// 該宏採用任意數量的逗號分隔的標識符，並將它們全部連接為一個，從而產生一個表達式，它是一個新的標識符。
    /// 請注意，衛生使該宏無法捕獲局部變量。
    /// 同樣，作為一般規則，只允許在項目，語句或表達式位置使用宏。
    /// 這意味著儘管您可以使用此宏來引用現有的變量，函數或模塊等，但是您無法使用它定義新的宏。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (新的，有趣的，名字) { }// 無法以這種方式使用!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 將文字連接到靜態字符串切片中。
    ///
    /// 該宏採用任意數量的逗號分隔的文字，產生 `&'static str` 類型的表達式，該表達式表示從左到右串聯的所有文字。
    ///
    ///
    /// 整數和浮點文字被字符串化以便被連接。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 擴展為在其上被調用的行號。
    ///
    /// 對於 [`column!`] 和 [`file!`]，這些宏為開發人員提供了有關源中位置的調試信息。
    ///
    /// 擴展表達式的類型為 `u32`，基於 1，因此每個文件的第一行求值為 1，第二行求值為 2，依此類推。
    /// 這與常見編譯器或常用編輯器的錯誤消息一致。
    /// 返回的行 (不一定是 `line!` 調用本身的行)，而是導致 `line!` 宏調用的第一個宏調用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// 擴展到調用它的列號。
    ///
    /// 對於 [`line!`] 和 [`file!`]，這些宏為開發人員提供了有關源中位置的調試信息。
    ///
    /// 擴展表達式的類型為 `u32`，從 1 開始，因此每行的第一列的值為 1，第二列的值為 2，依此類推。
    /// 這與常見編譯器或常用編輯器的錯誤消息一致。
    /// 返回的列 (不一定是 `column!` 調用本身的行)，而是導致 `column!` 宏調用的第一個宏調用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// 擴展為調用該文件的文件名。
    ///
    /// 對於 [`line!`] 和 [`column!`]，這些宏為開發人員提供了有關源中位置的調試信息。
    ///
    /// 擴展表達式的類型為 `&'static str`，返回的文件不是 `file!` 宏本身的調用，而是導致 `file!` 宏調用的第一個宏調用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// 對其參數進行字符串化。
    ///
    /// 該宏將產生類型為 `&'static str` 的表達式，該表達式是傳遞給該宏的所有 tokens 的字符串化。
    /// 宏調用本身的語法沒有任何限制。
    ///
    /// 請注意，輸入 tokens 的擴展結果可能會在 future 中發生變化。如果您依賴輸出，則應格外小心。
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 包含 UTF-8 編碼的文件作為字符串。
    ///
    /// 該文件相對於當前文件位於 (類似於如何找到模塊)。
    /// 提供的路徑在編譯時以特定於平台的方式進行解釋。
    /// 因此，例如，使用 Windows 路徑包含反斜杠 `\` 的調用將無法在 Unix 上正確編譯。
    ///
    ///
    /// 該宏將產生一個 `&'static str` 類型的表達式，它是文件的內容。
    ///
    /// # Examples
    ///
    /// 假設在同一目錄中有兩個文件，其內容如下:
    ///
    /// 文件 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 文件 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 編譯 'main.rs' 並運行生成的二進製文件將打印 "adiós"。
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 包括一個文件，作為對字節數組的引用。
    ///
    /// 該文件相對於當前文件位於 (類似於如何找到模塊)。
    /// 提供的路徑在編譯時以特定於平台的方式進行解釋。
    /// 因此，例如，使用 Windows 路徑包含反斜杠 `\` 的調用將無法在 Unix 上正確編譯。
    ///
    ///
    /// 該宏將產生一個 `&'static [u8; N]` 類型的表達式，它是文件的內容。
    ///
    /// # Examples
    ///
    /// 假設在同一目錄中有兩個文件，其內容如下:
    ///
    /// 文件 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 文件 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 編譯 'main.rs' 並運行生成的二進製文件將打印 "adiós"。
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 擴展為代表當前模塊路徑的字符串。
    ///
    /// 當前模塊路徑可以被認為是引回到 crate root 的模塊層次結構。
    /// 返迴路徑的第一部分是當前正在編譯的 crate 的名稱。
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// 在編譯時評估配置標誌的布爾組合。
    ///
    /// 除了 `#[cfg]` 屬性之外，還提供了此宏以允許對配置標誌進行布爾表達式評估。
    /// 這經常導致重複代碼更少。
    ///
    /// 賦予該宏的語法與 [`cfg`] 屬性的語法相同。
    ///
    /// `cfg!`, 與 `#[cfg]` 不同，它不會刪除任何代碼，只會計算為 true 或 false。
    /// 例如，將 `cfg!` 用作條件時，無論 `cfg!` 正在評估什麼，if/else 表達式中的所有塊都必須有效。
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 根據上下文將文件解析為表達式或項目。
    ///
    /// 該文件相對於當前文件位於 (類似於查找模塊的方式)。提供的路徑在編譯時以特定於平台的方式進行解釋。
    /// 因此，例如，使用 Windows 路徑包含反斜杠 `\` 的調用將無法在 Unix 上正確編譯。
    ///
    /// 使用此宏通常是個壞主意，因為如果將文件解析為表達式，則將不衛生地將其放置在周圍的代碼中。
    /// 如果在當前文件中存在具有相同名稱的變量或函數，則這可能導致變量或函數與文件預期的不同。
    ///
    ///
    /// # Examples
    ///
    /// 假設在同一目錄中有兩個文件，其內容如下:
    ///
    /// 文件 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 文件 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 編譯 'main.rs' 並運行生成的二進製文件將打印 "🙈🙊🙉🙈🙊🙉"。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 聲明在運行時布爾表達式為 `true`。
    ///
    /// 如果提供的表達式在運行時無法評估為 `true`，則它將調用 [`panic!`] 宏。
    ///
    /// # Uses
    ///
    /// 斷言始終在調試和發行版本中進行檢查，並且不能禁用。
    /// 有關默認情況下未在發行版中啟用的聲明，請參見 [`debug_assert!`]。
    ///
    /// 不安全的代碼可能依賴 `assert!` 來強制執行運行時不變式，如果違反該規定，可能會導致不安全。
    ///
    /// `assert!` 的其他用例包括在安全代碼中測試和強制執行運行時不變量 (違規不會導致不安全)。
    ///
    ///
    /// # 自定義消息
    ///
    /// 該宏具有第二種形式，其中可以提供自定義 panic 消息，該消息可以帶有或不帶有用於格式化的參數。
    /// 有關此格式的語法，請參見 [`std::fmt`]。
    /// 僅當斷言失敗時，才對用作格式參數的表達式進行求值。
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // 這些斷言的 panic 消息是給定表達式的字符串化值。
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // 一個非常簡單的功能
    ///
    /// assert!(some_computation());
    ///
    /// // 使用自定義消息進行斷言
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// 內聯彙編。
    ///
    /// 請閱讀 [unstable book] 的用法。
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM 樣式的內聯彙編。
    ///
    /// 請閱讀 [unstable book] 的用法。
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// 模塊級內聯彙編。
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// 將傳遞的 tokens 打印到標準輸出中。
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 啟用或禁用用於調試其他宏的跟踪功能。
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// 用於應用派生宏的屬性宏。
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// 屬性宏應用於函數以將其轉換為單元測試。
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// 應用到函數的屬性宏將其轉換為基準測試。
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` 和 `#[bench]` 宏的實現細節。
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// 將屬性宏應用於靜態以將其註冊為全局分配器。
    ///
    /// 另請參見 [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html)。
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// 如果可以訪問傳遞的路徑，則保留適用於該項目的項目，否則將其刪除。
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// 擴展其所應用的代碼片段中的所有 `#[cfg]` 和 `#[cfg_attr]` 屬性。
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` 編譯器的不穩定實現細節，請勿使用。
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` 編譯器的不穩定實現細節，請勿使用。
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}