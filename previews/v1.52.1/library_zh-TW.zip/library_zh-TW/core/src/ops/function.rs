/// 接受不可變接收者的调用運營商的版本。
///
/// `Fn` 的實例可以重複調用而不改變狀態。
///
/// *請勿將此 trait (`Fn`) 與 [function pointers] (`fn`) 混淆。*
///
/// `Fn` X 閉包和 (safe) [function pointers] (僅包含一些注意事項，請參見其文檔以獲取更多詳細信息) 由閉包自動實現，閉包僅對捕獲的變量進行不可變的引用或根本不捕獲任何內容。
///
/// 另外，對於任何實現 `Fn` 的 `F` 類型，`&F` 也實現 `Fn`。
///
/// 由於 [`FnMut`] 和 [`FnOnce`] 都是 `Fn` 的特徵，因此 `Fn` 的任何實例都可以用作預期使用 [`FnMut`] 或 [`FnOnce`] 的參數。
///
/// 當您要接受類似函數的類型的參數並且需要重複調用且不改變狀態 (例如，同時調用它) 時，請使用 `Fn` 作為綁定。
/// 如果不需要嚴格的要求，請使用 [`FnMut`] 或 [`FnOnce`] 作為界限。
///
/// 有關此主題的更多信息，請參見 [chapter on closures in *The Rust Programming Language*][book]。
///
/// 還要注意的是 `Fn` traits 的特殊語法 (例如
/// `Fn(usize, bool) -> 使用)。對此技術細節感興趣的人可以參考 [the relevant section in the *Rustonomicon*][nomicon]。
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## 調用閉包
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## 使用 `Fn` 參數
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // 這樣 regex 可以依靠 `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// 執行调用操作。
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// 帶有可變接收者的调用運營商的版本。
///
/// `FnMut` 的實例可以重複調用，並且可以改變狀態。
///
/// `FnMut` 由閉包自動實現，閉包採用可變引用捕獲的變量，以及實現 [`Fn`] 的所有類型，例如 (safe) [function pointers] (因為 `FnMut` 是 [`Fn`] 的特徵)。
/// 另外，對於任何實現 `FnMut` 的 `F` 類型，`&mut F` 也實現 `FnMut`。
///
/// 由於 [`FnOnce`] 是 `FnMut` 的 super trait，因此可以在期望 [`FnOnce`] 的地方使用 `FnMut` 的任何實例，並且由於 [`Fn`] 是 `FnMut` 的子特性，因此可以在預期 `FnMut` 的地方使用 [`Fn`] 的任何實例。
///
/// 當您要接受類似函數的類型的參數並需要反複調用它，同時允許其改變狀態時，請使用 `FnMut` 作為綁定。
/// 如果您不希望參數改變狀態，請使用 [`Fn`] 作為綁定; 如果不需要重複調用，請使用 [`FnOnce`]。
///
/// 有關此主題的更多信息，請參見 [chapter on closures in *The Rust Programming Language*][book]。
///
/// 還要注意的是 `Fn` traits 的特殊語法 (例如
/// `Fn(usize, bool) -> 使用)。對此技術細節感興趣的人可以參考 [the relevant section in the *Rustonomicon*][nomicon]。
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## 調用可變捕獲的閉包
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## 使用 `FnMut` 參數
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // 這樣 regex 可以依靠 `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// 執行调用操作。
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// 帶有按值接收方的调用操作符的版本。
///
/// 可以調用 `FnOnce` 的實例，但可能無法多次調用。因此，如果唯一知道類型的是它實現 `FnOnce`，則只能調用一次。
///
/// `FnOnce` 通過可能消耗捕獲變量的閉包以及實現 [`FnMut`] 的所有類型 (例如 (safe) [function pointers] (因為 `FnOnce` 是 [`FnMut`] 的特徵) ) 自動實現閉包。
///
///
/// 由於 [`Fn`] 和 [`FnMut`] 都是 `FnOnce` 的子特性，因此可以在期望使用 `FnOnce` 的情況下使用 [`Fn`] 或 [`FnMut`] 的任何實例。
///
/// 當您想接受類似函數的類型的參數並且只需要調用一次時，可以使用 `FnOnce` 作為綁定。
/// 如果需要重複調用該參數，請使用 [`FnMut`] 作為綁定; 如果還需要它不改變狀態，請使用 [`Fn`]。
///
/// 有關此主題的更多信息，請參見 [chapter on closures in *The Rust Programming Language*][book]。
///
/// 還要注意的是 `Fn` traits 的特殊語法 (例如
/// `Fn(usize, bool) -> 使用)。對此技術細節感興趣的人可以參考 [the relevant section in the *Rustonomicon*][nomicon]。
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## 使用 `FnOnce` 參數
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` 使用其捕獲的變量，因此不能多次運行。
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // 再次嘗試調用 `func()` 將為 `func` 引發 `use of moved value` 錯誤。
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` 現在不能再被調用
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // 這樣 regex 可以依靠 `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// 使用調用運算符後返回的類型。
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// 執行调用操作。
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}