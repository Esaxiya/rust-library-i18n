use crate::marker::Unpin;
use crate::pin::Pin;

/// 恢復生成器的結果。
///
/// 該枚舉從 `Generator::resume` 方法返回，並指示生成器的可能返回值。
/// 當前，這對應於懸掛點 (`Yielded`) 或終止點 (`Complete`)。
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// 生成器掛起了一個值。
    ///
    /// 此狀態表明生成器已被掛起，並且通常對應於 `yield` 語句。
    /// 此變量中提供的值與傳遞給 `yield` 的表達式相對應，並允許生成器在每次產生時提供一個值。
    ///
    ///
    Yielded(Y),

    /// 生成器完成並返回一個值。
    ///
    /// 此狀態表明生成器已使用提供的值完成了執行。
    /// 生成器返回 `Complete` 後，再次調用 `resume` 被視為程序員錯誤。
    ///
    Complete(R),
}

/// 由內置生成器類型實現的 trait。
///
/// 生成器 (通常也稱為協程) 是 Rust 中的一種實驗語言功能。
/// [RFC 2033] 中添加的生成器目前主要用於為 async/await 語法提供構建塊，但可能會擴展為還為迭代器和其他原語提供符合人體工程學的定義。
///
///
/// 生成器的語法和語義不穩定，將需要進一步的 RFC 來穩定。但是，此時的語法類似於閉包:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// 在不穩定的書中可以找到有關發電機的更多文檔。
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// 此生成器產生的值的類型。
    ///
    /// 此關聯的類型對應於 `yield` 表達式以及每次生成器產生時都允許返回的值。
    ///
    /// 例如，作為一個迭代器的迭代器可能將這種類型作為 `T` 進行迭代。
    ///
    type Yield;

    /// 此生成器返回的值的類型。
    ///
    /// 這對應於使用 `return` 語句從生成器返回的類型，或隱式作為生成器文字的最後一個表達式。
    /// 例如，futures 將其用作 `Result<T, E>`，因為它代表完整的 future。
    ///
    ///
    type Return;

    /// 恢復此生成器的執行。
    ///
    /// 此函數將恢復生成器的執行，如果尚未執行，則開始執行。
    /// 該調用將返回到生成器的最後一個掛起點，從最新的 `yield` 恢復執行。
    /// 生成器將繼續執行，直到它屈服或返回為止，這時該函數將返回。
    ///
    /// # 返回值
    ///
    /// 從該函數返回的 `GeneratorState` 枚舉指示生成器在返回時處於什麼狀態。
    /// 如果返回 `Yielded` 變型，則發生器已達到暫停點，並且已產生一個值。
    /// 此狀態下的生成器可在以後恢復。
    ///
    /// 如果返回 `Complete`，則生成器將完全完成所提供的值。再次恢復生成器是無效的。
    ///
    /// # Panics
    ///
    /// 如果先前已返回 `Complete` 變體後調用此函數，則該函數可能為 panic。
    /// 儘管在 `Complete` 之後恢復使用該語言的生成器文字可以保證為 panic，但對於 `Generator` trait 的所有實現均不能保證。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}