//! 可重載的運算符。
//!
//! 實現這些 traits 可使您重載某些運算符。
//!
//! 其中的某些 traits 由 prelude 導入，因此在每個 Rust 程序中都可用。只有由 traits 支持的運算符可以重載。
//! 例如，可以通過 [`Add`] trait 重載加法運算符 (`+`)，但是由於賦值運算符 (`=`) 沒有後備 trait，因此無法重載其語義。
//! 此外，此模塊不提供任何機制來創建新的運算符。
//! 如果需要無特徵的重載或自定義運算符，則應使用宏或編譯器插件來擴展 Rust 的語法。
//!
//! 考慮到它們的通常含義和 [operator precedence]，運算符 traits 的實現在它們各自的上下文中應該不足為奇。
//! 例如，當實現 [`Mul`] 時，該操作應與乘法有些相似 (並共享期望的屬性，如關聯性)。
//!
//! 請注意，`&&` 和 `||` 運算符發生短路，即，它們僅在第二操作數有助於結果的情況下才對其求值。由於 traits 無法強制執行此行為，因此不支持 `&&` 和 `||` 作為可重載運算符。
//!
//! 許多運算符按值取其操作數。在涉及內置類型的非泛型上下文中，這通常不是問題。
//! 但是，在通用代碼中使用這些運算符時，如果必須重用值而不是讓運算符使用它們，則需要引起注意。一種選擇是偶爾使用 [`clone`]。
//! 另一個選擇是依靠所涉及的類型來提供其他操作員實現以供參考。
//! 例如，對於應該支持加法的用戶定義類型 `T`，將 `T` 和 `&T` 都實現 traits [`Add<T>`][`Add`] 和 [`Add<&T>`][`Add`] 可能是一個好主意，這樣就可以編寫通用代碼而無需進行不必要的克隆。
//!
//!
//! # Examples
//!
//! 本示例創建一個實現 [`Add`] 和 [`Sub`] 的 `Point` 結構，然後演示加減兩個 Point。
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! 有關示例實現，請參見每個 trait 的文檔。
//!
//! [`Fn`]，[`FnMut`] 和 [`FnOnce`] traits 由可以像函數一樣調用的類型實現。請注意，[`Fn`] 佔用 `&self`，[`FnMut`] 佔用 `&mut self`，[`FnOnce`] 佔用 `self`。
//! 這些對應於可以在實例上調用的三種方法: 按引用調用，按可變引用調用和按值調用。
//! 這些 traits 的最常見用法是充當以函數或閉包為參數的高級函數的邊界。
//!
//! 以 [`Fn`] 作為參數:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! 以 [`FnMut`] 作為參數:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! 以 [`FnOnce`] 作為參數:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` 使用其捕獲的變量，因此不能多次運行
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // 再次嘗試調用 `func()` 將為 `func` 引發 `use of moved value` 錯誤
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` 現在不能再被調用
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;