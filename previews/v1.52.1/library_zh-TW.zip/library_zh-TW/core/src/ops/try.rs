/// trait，用於自定義 `?` 運算符的行為。
///
/// 實現 `Try` 的類型是一種具有規範性的 success/failure 二分法來查看它的類型。
/// trait 允許從現有實例中提取成功或失敗值，也可以從成功或失敗值創建新實例。
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// 視為成功時，此值的類型。
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// 視為失敗時，此值的類型。
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// 應用 "?" 運算符。返回 `Ok(t)` 意味著執行應正常繼續，並且 `?` 的結果為值 `t`。
    /// 返回 `Err(e)` 意味著應該將 branch 執行到最裡面的 `catch`，或者從函數返回。
    ///
    /// 如果返回 `Err(e)` 結果，則在封閉範圍的返回類型中，值 `e` 將為 "wrapped" (它本身必須實現 `Try`)。
    ///
    /// 具體來說，返回值 `X::from_error(From::from(e))`，其中 `X` 是封閉函數的返回類型。
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// 包裝錯誤值以構造複合結果。
    /// 例如，`Result::Err(x)` 和 `Result::from_error(x)` 是等效的。
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// 包裝一個 OK 值以構造複合結果。
    /// 例如，`Result::Ok(x)` 和 `Result::from_ok(x)` 是等效的。
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}