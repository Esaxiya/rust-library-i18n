/// 用於不可變的取消引用操作，例如 `*v`。
///
/// `Deref` 除了在不可變上下文中用於 (unary) `*` 運算符的顯式取消引用操作外，還被編譯器在許多情況下隱式使用。
/// 該機制稱為 ['`Deref` coercion'][more]。
/// 在可變上下文中，使用 [`DerefMut`]。
///
/// 為智能指針實現 `Deref` 使得訪問它們背後的數據變得方便，這就是為什麼它們實現 `Deref` 的原因。
/// 另一方面，有關 `Deref` 和 [`DerefMut`] 的規則是專門為容納智能指針而設計的。
/// 因此，**`Deref` 只應為智能指針實現**，以避免混淆。
///
/// 出於類似的原因，**此 trait 永遠不會失敗**。當隱式調用 `Deref` 時，取消引用過程中的失敗會造成極大的混亂。
///
/// # 有關 `Deref` 強制的更多信息
///
/// 如果 `T` 實現 `Deref<Target = U>`，並且 `x` 是 `T` 類型的值，則:
///
/// * 在不可變的上下文中，`*x` (其中 `T` 既不是引用也不是原始指針) 等效於 `* Deref::deref(&x)`。
/// * `&T` 類型的值被強制為 `&U` 類型的值
/// * `T` 隱式實現 `U` 類型的所有 (immutable) 方法。
///
/// 有關更多詳細信息，請訪問 [the chapter in *The Rust Programming Language*][book] 以及 [the dereference operator][ref-deref-op]，[method resolution] 和 [type coercions] 的參考部分。
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 具有單個字段的結構，可通過取消引用該結構來訪問。
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// 解引用後的結果類型。
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// 取消引用值。
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// 用於可變的解除引用操作，例如在 `*v = 1;` 中。
///
/// `DerefMut` 除了在可變上下文中與 (unary) `*` 運算符一起用於顯式解引用操作外，在許多情況下還被編譯器隱式使用。
/// 該機制稱為 ['`Deref` coercion'][more]。
/// 在不可變的上下文中，使用 [`Deref`]。
///
/// 為智能指針實現 `DerefMut` 可以方便地對其背後的數據進行突變，這就是為什麼它們實現 `DerefMut` 的原因。
/// 另一方面，有關 [`Deref`] 和 `DerefMut` 的規則是專門為容納智能指針而設計的。
/// 因此，**DerefMut` 僅應為智能指針實現**，以免造成混淆。
///
/// 出於類似的原因，**此 trait 永遠不會失敗**。當隱式調用 `DerefMut` 時，取消引用過程中的失敗會造成極大的混亂。
///
/// # 有關 `Deref` 強制的更多信息
///
/// 如果 `T` 實現 `DerefMut<Target = U>`，並且 `x` 是 `T` 類型的值，則:
///
/// * 在可變上下文中，`*x` (其中 `T` 既不是引用也不是原始指針) 等效於 `* DerefMut::deref_mut(&mut x)`。
/// * `&mut T` 類型的值被強制為 `&mut U` 類型的值
/// * `T` 隱式實現 `U` 類型的所有 (mutable) 方法。
///
/// 有關更多詳細信息，請訪問 [the chapter in *The Rust Programming Language*][book] 以及 [the dereference operator][ref-deref-op]，[method resolution] 和 [type coercions] 的參考部分。
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 具有單個字段的結構，可以通過取消引用該結構進行修改。
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// 可變地取消引用該值。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// 指示可以將結構用作方法接收器，而無需使用 `arbitrary_self_types` 功能。
///
/// 這是由 stdlib 指針類型 (例如 `Box<T>`，`Rc<T>`，`&T` 和 `Pin<P>`) 實現的。
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}