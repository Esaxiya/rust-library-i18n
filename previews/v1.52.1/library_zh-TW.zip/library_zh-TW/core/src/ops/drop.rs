/// 析構函數中的自定義代碼。
///
/// 當不再需要某個值時，Rust 將對該值運行 "destructor"。
/// 不再需要某個值的最常見方法是超出範圍。析構函數可能仍在其他情況下運行，但是在這裡我們將重點關注示例的範圍。
/// 要了解其他一些情況，請參閱析構函數的 [the reference] 部分。
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// 此析構函數由兩個組件組成:
/// - 如果為此類型實現了特殊的 `Drop` trait，則對該值的調用 `Drop::drop`。
/// - 自動生成的 "drop glue" 遞歸調用此值所有字段的析構函數。
///
/// 由於 Rust 自動調用所有包含字段的析構函數，因此在大多數情況下，您無需實現 `Drop`。
/// 但是在某些情況下它很有用，例如對於直接管理資源的類型。
/// 該資源可能是內存，可能是文件描述符，可能是網絡套接字。
/// 一旦不再使用該類型的值，則應通過釋放內存或關閉文件或套接字 "clean up" 資源。
/// 這是析構函數的工作，因此也是 `Drop::drop` 的工作。
///
/// ## Examples
///
/// 要查看析構函數的作用，讓我們看一下以下程序:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust 將首先為 `_x` 調用 `Drop::drop`，然後為 `_x.one` 和 `_x.two` 調用，這意味著運行該命令將打印
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// 即使我們刪除了針對 `HasTwoDrop` 的 `Drop` 的實現，其字段的析構函數仍然會被調用。
/// 這將導致
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## 您不能自己打電話給 `Drop::drop`
///
/// 由於使用 `Drop::drop` 清除值，因此在調用方法後使用該值可能很危險。
/// 由於 `Drop::drop` 不擁有其輸入的所有權，因此 Rust 通過不允許您直接調用 `Drop::drop` 來防止濫用。
///
/// 換句話說，如果您在上面的示例中嘗試顯式調用 `Drop::drop`，則會出現編譯器錯誤。
///
/// 如果要顯式調用值的析構函數，則可以改用 [`mem::drop`]。
///
/// [`mem::drop`]: drop
///
/// ## 放下訂單
///
/// 但是，我們的兩個 `HasDrop` 哪個先掉線? 對於結構體，其聲明順序相同: 首先是 `one`，然後是 `two`。
/// 如果您想自己嘗試，可以修改上面的 `HasDrop` 以包含一些數據 (例如整數)，然後在 `Drop` 內部的 `println!` 中使用它。
/// 此行為由語言保證。
///
/// 與 for 結構不同，局部變量以相反的順序刪除:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// 這將打印
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// 有關完整規則，請參見 [the reference]。
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` 和 `Drop` 是互斥的
///
/// 您不能在同一類型上同時實現 [`Copy`] 和 `Drop`。`Copy` 類型被編譯器隱式複制，這使得很難預測何時以及將執行析構函數的頻率。
///
/// 因此，這些類型不能具有析構函數。
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// 執行此類型的析構函數。
    ///
    /// 當值超出範圍時，將隱式調用此方法，並且無法顯式調用此方法 (這是編譯器錯誤 [E0040])。
    /// 但是，可以使用 prelude 中的 [`mem::drop`] 函數來調用參數的 `Drop` 實現。
    ///
    /// 調用此方法後，尚未釋放 `self`。
    /// 只有在方法結束後才會發生這種情況。
    /// 如果不是這種情況，則 `self` 將成為懸掛的參考。
    ///
    /// # Panics
    ///
    /// 假設 [`panic!`] 展開時將調用 `drop`，則 `drop` 實現中的任何 [`panic!`] 都可能中止。
    ///
    /// 請注意，即使此 panics，該值也被視為已刪除;
    /// 您不得使 `drop` 再次被調用。
    /// 這通常由編譯器自動處理，但是在使用不安全的代碼時，有時可能會無意間發生，尤其是在使用 [`ptr::drop_in_place`] 時。
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}