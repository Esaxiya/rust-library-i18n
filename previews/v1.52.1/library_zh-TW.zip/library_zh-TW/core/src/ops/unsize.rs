use crate::marker::Unsize;

/// Trait，指示這是一個指針或一個包裝器，其中可以在指針上執行大小調整。
///
/// 有關更多詳細信息，請參見 [DST coercion RFC][dst-coerce] 和 [the nomicon entry on coercion][nomicon-coerce]。
///
/// 對於內置指針類型，如果 `T: Unsize<U>` 通過從精簡指針轉換為胖指針，則指向 `T` 的指針將強制指向指向 `U` 的指針。
///
/// 對於自定義類型，這裡的強制通過將 `Foo<T>` 強制為 `Foo<U>` 來工作 (如果存在 `CoerceUnsized<Foo<U>> for Foo<T>` 的實現)。
/// 僅當 `Foo<T>` 僅具有涉及 `T` 的單個非虛擬數據字段時，才可以寫這樣的 impl。
/// 如果該字段的類型為 `Bar<T>`，則必須存在 `CoerceUnsized<Bar<U>> for Bar<T>` 的實現。
/// 強制將通過將 `Bar<T>` 字段強制轉換為 `Bar<U>` 並填充 `Foo<T>` 的其餘字段以創建 `Foo<U>` 來起作用。
/// 這將有效地向下鑽取指針字段並將其強制。
///
/// 通常，對於智能指針，您將實現 `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`，並在 `T` 本身上綁定了可選的 `?Sized`。
/// 對於直接嵌入 `T` 的包裝器類型 (例如 `Cell<T>` 和 `RefCell<T>`)，您可以直接實現 `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`。
///
/// 這將使像 `Cell<Box<T>>` 這樣的強制類型起作用。
///
/// [`Unsize`][unsize] 用於標記在指針後面可以強制轉換為 DST 的類型。它由編譯器自動實現。
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// 這用於對象安全，以檢查是否可以分派方法的接收者類型。
///
/// trait 的示例實現:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}