#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// 提供任何指向類型的指針元數據類型。
///
/// # 指針元數據
///
/// Rust 中的原始指針類型和引用類型可以認為是由兩部分組成:
/// 包含該值的內存地址和一些元數據的數據指針。
///
/// 對於靜態大小的類型 (實現 `Sized` traits) 以及 `extern` 類型，指針被稱為 `瘦`: 元數據的大小為零，其類型為 `()`。
///
///
/// 指向 [dynamically-sized types][dst] 的指針被稱為 `寬` 或 `胖`，它們具有非零大小的元數據:
///
/// * 對於最後一個字段是 DST 的結構，元數據是最後一個字段的元數據
/// * 對於 `str` 類型，元數據是 `usize` 的長度 (以字節為單位)
/// * 對於像 `[T]` 這樣的切片類型，元數據是項目中的長度，如 `usize`
/// * 對於 X0X 之類的 trait 對象，元數據為 [`DynMetadata<Self>`][DynMetadata] (例如 `DynMetadata<dyn SomeTrait>`)
///
/// 在 future 中，Rust 語言可能會獲得具有不同指針元數據的新型類型。
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// trait 的點是其 `Metadata` 關聯類型，如上所述，它是 `()` 或 `usize` 或 `DynMetadata<_>`。
/// 它會針對每種類型自動實現。
/// 即使沒有相應的限制，也可以假定它是在通用上下文中實現的。
///
/// # Usage
///
/// 原始指針可以通過其 [`to_raw_parts`] 方法分解為數據地址和元數據組件。
///
/// 或者，可以使用 [`metadata`] 函數單獨提取元數據。
/// 引用可以傳遞給 [`metadata`] 並隱式強制。
///
/// 可以使用 [`from_raw_parts`] 或 [`from_raw_parts_mut`] 將 (possibly-wide) 指針從其地址和元數據放回原處。
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// 指向 `Self` 的指針和引用中的元數據的類型。
    #[lang = "metadata_type"]
    // NOTE: 在 `static_assert_expected_bounds_for_metadata` 中保持 trait bounds
    //
    // 在 `library/core/src/ptr/metadata.rs` 中與此處的同步:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// 實現此 trait 別名的類型的指針為 `thin`。
///
/// 這包括靜態 `大小` 類型和 `extern` 類型。
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: 在 trait 別名在語言中穩定之前難道不能穩定它嗎?
pub trait Thin = Pointee<Metadata = ()>;

/// 提取指針的元數據組件。
///
/// `*mut T`，`&T` 或 `&mut T` 類型的值可以隱式強制轉換為 `* const T`，因此可以直接傳遞給此函數。
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // 安全: 由於 * const T，從 `PtrRepr` 聯合訪問值很安全。
    // 和 PtrComponents<T> 具有相同的內存佈局。
    // 只有 std 可以做出此保證。
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// 根據數據地址和元數據形成 (possibly-wide) 原始指針。
///
/// 此函數是安全的，但返回的指針不一定可以安全地取消引用。
/// 對於切片，請參閱 [`slice::from_raw_parts`] 的文檔以了解安全要求。
/// 對於 trait 對象，元數據必須來自指向相同基礎增加類型的指針。
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // 安全: 由於 * const T，從 `PtrRepr` 聯合訪問值很安全。
    // 和 PtrComponents<T> 具有相同的內存佈局。
    // 只有 std 可以做出此保證。
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// 執行與 [`from_raw_parts`] 相同的功能，除了返回原始 `*mut` 指針 (與原始 `* const` 指針相反) 之外。
///
///
/// 有關更多詳細信息，請參見 [`from_raw_parts`] 的文檔。
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // 安全: 由於 * const T，從 `PtrRepr` 聯合訪問值很安全。
    // 和 PtrComponents<T> 具有相同的內存佈局。
    // 只有 std 可以做出此保證。
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// 需要避免 `T: Copy` 綁定的手動提示。
impl<T: ?Sized> Copy for PtrComponents<T> {}

// 需要避免 `T: Clone` 綁定的手動提示。
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait 對像類型的元數據。
///
/// 它是指向 vtable (虛擬調用表) 的指針，該表表示操作存儲在 trait 對象內部的具體類型的所有必要信息。
/// 該 vtable 尤其包含:
///
/// * 字號
/// * 類型對齊
/// * 指向該類型的 `drop_in_place` impl 的指針 (對於純舊數據，它可能是 no-op)
/// * 指向 trait 類型實現的所有方法的指針
///
/// 請注意，前三個是特殊的，因為它們是分配，刪除和取消分配任何 trait 對象所必需的。
///
/// 可以使用不是 `dyn` trait 對象 (例如 `DynMetadata<u64>`) 的類型參數來命名此結構，但不能獲得該結構的有意義的值。
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// 所有 vtable 的通用前綴。其後是 trait 方法的函數指針。
///
/// `DynMetadata::size_of` 等的私有實現詳細信息
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// 返回與此 vtable 關聯的類型的大小。
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// 返回與此 vtable 關聯的類型的對齊方式。
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// 將尺寸和對齊方式一起返回為 `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // 安全: 編譯器針對特定的 Rust 類型發出了此 vtable，該類型
        // 已知具有有效的佈局。與 `Layout::for_value` 中的原理相同。
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// 避免 `Dyn: $Trait` 邊界所需的手動提示。

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}