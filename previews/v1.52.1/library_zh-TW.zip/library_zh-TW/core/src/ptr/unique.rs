use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// 原始非空 `*mut T` 周圍的包裝器，指示該包裝器的擁有者擁有引用對象。
/// 對於構建 `Box<T>`，`Vec<T>`，`String` 和 `HashMap<K, V>` 等抽像很有用。
///
/// 與 `*mut T` 不同，`Unique<T>` 的行為與 "as if" 相同，它是 `T` 的實例。
/// 如果 `T` 為 `Send`/`Sync`，則實現 `Send`/`Sync`。
/// 這也暗示了 `T` 實例可以期望的那種強別名保證:
/// 如果沒有指向其所屬 `唯一` 的唯一路徑，則不應修改指針的引用對象。
///
/// 如果不確定使用 `Unique` 是否正確，請考慮使用語義較弱的 `NonNull`。
///
///
/// 與 `*mut T` 不同，即使從未取消引用指針，指針也必須始終為非 null。
/// 這樣一來，枚舉就可以將此禁止值用作判別式 - `Option<Unique<T>>` 與 `Unique<T>` 具有相同的大小。
/// 但是，如果指針未取消引用，它可能仍會懸垂。
///
/// 與 `*mut T` 不同，`Unique<T>` 在 `T` 上是協變的。
/// 對於任何符合 `唯一` 別名要求的類型，這應該總是正確的。
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: 該標記不會對方差產生影響，但有必要
    // 讓 dropck 了解我們在邏輯上擁有 `T`。
    //
    // 有關詳細信息，請參見:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` 如果 `T` 為 `Send`，則指針為 `Send`，因為它們所引用的數據是未混疊的。
/// 請注意，類型系統不強制使用此別名不變式。使用 `Unique` 的抽象必須強制使用它。
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` 如果 `T` 為 `Sync`，則指針為 `Sync`，因為它們所引用的數據是未混疊的。
/// 請注意，類型系統不強制使用此別名不變式。使用 `Unique` 的抽象必須強制使用它。
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// 創建一個懸空但對齊良好的新 `Unique`。
    ///
    /// 與 `Vec::new` 一樣，這對於初始化延遲分配的類型很有用。
    ///
    /// 請注意，該指針值可能表示一個指向 `T` 的有效指針，這意味著不得將其用作 "not yet initialized" 標記值。
    /// 延遲分配的類型必須通過其他某種方式來跟踪初始化。
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // 安全: mem::align_of() 返回有效的非 null 指針。這
        // 因此，可以滿足調用 new_unchecked() 的條件。
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// 創建一個新的 `Unique`。
    ///
    /// # Safety
    ///
    /// `ptr` 必須為非 null。
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // 安全: 调用者必須保證 `ptr` 不為空。
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// 如果 `ptr` 不為空，則創建一個新的 `Unique`。
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // 安全: 指針已被檢查並且不為空。
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// 獲取基礎的 `*mut` 指針。
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// 取消引用內容。
    ///
    /// 最終的生命週期與自身綁定，因此它的行為為 "as if"，它實際上是被借用的 T 的實例。
    /// 如果需要更長的 (unbound) 壽命，請使用 `&*my_ptr.as_ptr()`。
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // 安全: 调用者必須保證 `self` 符合所有
        // 供參考的要求。
        unsafe { &*self.as_ptr() }
    }

    /// 相互取消引用內容。
    ///
    /// 最終的生命週期與自身綁定，因此它的行為為 "as if"，它實際上是被借用的 T 的實例。
    /// 如果需要更長的 (unbound) 壽命，請使用 `&mut *my_ptr.as_ptr()`。
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // 安全: 调用者必須保證 `self` 符合所有
        // 可變參考的要求。
        unsafe { &mut *self.as_ptr() }
    }

    /// 強制轉換為另一種類型的指針。
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // 安全: Unique::new_unchecked() 創造了新的獨特性和需求
        // 給定的指針不為 null。
        // 由於我們將 self 作為指針傳遞，因此它不能為 null。
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // 安全: 可變引用不能為空
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}