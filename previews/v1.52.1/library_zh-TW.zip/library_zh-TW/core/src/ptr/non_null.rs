use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` 但非零且協變。
///
/// 在使用原始指針構建數據結構時，這通常是正確的選擇，但由於其附加屬性，最終使用起來更加危險。如果不確定是否應使用 `NonNull<T>`，請使用 `*mut T`!
///
/// 與 `*mut T` 不同，即使從未取消引用指針，指針也必須始終為非 null。這樣一來，枚舉就可以將此禁止值用作判別式 - `Option<NonNull<T>>` 與 `* mut T` 具有相同的大小。
/// 但是，如果指針未取消引用，它可能仍會懸垂。
///
/// 與 `*mut T` 不同，選擇 `NonNull<T>` 作為 `T` 的協變量。這樣就可以在構建協變類型時使用 `NonNull<T>`，但是如果在實際上不應該協變的類型中使用，則會帶來不健全的風險。
/// (儘管從技術上講，聲音不健全只能由調用不安全的功能引起，但對於 `*mut T` 卻做出了相反的選擇。)
///
/// 對於大多數安全抽象，例如 `Box`，`Rc`，`Arc`，`Vec` 和 `LinkedList`，協方差是正確的。之所以如此，是因為它們提供了遵循 Rust 的常規共享 XOR 可變規則的公共 API。
///
/// 如果您的類型不能安全地協變，則必須確保它包含一些附加字段以提供不變性。通常，此字段是 [`PhantomData`] 類型，例如 `PhantomData<Cell<T>>` 或 `PhantomData<&'a mut T>`。
///
/// 請注意，`NonNull<T>` 具有 `&T` 的 `From` 實例。但是，這不會改變以下事實: 通過共享引用 (從 a 派生的指針) 進行的突變是未定義的行為，除非該突變發生在 [`UnsafeCell<T>`] 內部。從共享引用創建可變引用也是如此。
///
/// 當使用不帶 `UnsafeCell<T>` 的 `From` 實例時，您有責任確保從不調用 `as_mut`，並且從不使用 `as_ptr` 進行突變。
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` 指針不是 `Send`，因為它們引用的數據可能是別名的。
// 注意，此暗示不是必需的，但應提供更好的錯誤消息。
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` 指針不是 `Sync`，因為它們引用的數據可能是別名的。
// 注意，此暗示不是必需的，但應提供更好的錯誤消息。
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// 創建一個懸空但對齊良好的新 `NonNull`。
    ///
    /// 與 `Vec::new` 一樣，這對於初始化延遲分配的類型很有用。
    ///
    /// 請注意，該指針值可能表示一個指向 `T` 的有效指針，這意味著不得將其用作 "not yet initialized" 標記值。
    /// 延遲分配的類型必須通過其他某種方式來跟踪初始化。
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // 安全: mem::align_of() 返回一個非零的 usize，然後將其強制轉換
        // 到 * mutT。
        // 因此，`ptr` 不為空，並且遵守了調用 new_unchecked() 的條件。
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// 返回對該值的共享引用。與 [`as_ref`] 相比，這不需要將該值初始化。
    ///
    /// 有關可變的副本，請參見 [`as_uninit_mut`]。
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保滿足以下所有條件:
    ///
    /// * 指針必須正確對齊。
    ///
    /// * 在 [the module documentation] 中定義的意義上，它必須是 "dereferencable"。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///
    ///   特別是，在此生命週期內，指針所指向的內存一定不能發生突變 (`UnsafeCell` 內部除外)。
    ///
    /// 即使未使用此方法的結果也是如此!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // 安全: 调用者必須保證 `self` 符合所有
        // 供參考的要求。
        unsafe { &*self.cast().as_ptr() }
    }

    /// 返回對該值的唯一引用。與 [`as_mut`] 相比，這不需要將該值初始化。
    ///
    /// 有關共享副本，請參見 [`as_uninit_ref`]。
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保滿足以下所有條件:
    ///
    /// * 指針必須正確對齊。
    ///
    /// * 在 [the module documentation] 中定義的意義上，它必須是 "dereferencable"。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///
    ///   特別是，在此生命週期內，指針所指向的內存一定不能通過任何其他指針訪問 (讀取或寫入)。
    ///
    /// 即使未使用此方法的結果也是如此!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // 安全: 调用者必須保證 `self` 符合所有
        // 供參考的要求。
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// 創建一個新的 `NonNull`。
    ///
    /// # Safety
    ///
    /// `ptr` 必須為非 null。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // 安全: 调用者必須保證 `ptr` 不為空。
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// 如果 `ptr` 不為空，則創建一個新的 `NonNull`。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // 安全: 指針已被檢查並且不為空
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// 執行與 [`std::ptr::from_raw_parts`] 相同的功能，除了返回 `NonNull` 指針 (與原始 `*const` 指針相反)。
    ///
    ///
    /// 有關更多詳細信息，請參見 [`std::ptr::from_raw_parts`] 的文檔。
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // 安全: `ptr::from::raw_parts_mut` 的結果非空，因為 `data_address` 是。
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// 將 (可能是很寬的) 指針分解為地址和元數據組件。
    ///
    /// 以後可以使用 [`NonNull::from_raw_parts`] 重建指針。
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// 獲取基礎的 `*mut` 指針。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// 返回對該值的共享引用。如果該值可能未初始化，則必須改用 [`as_uninit_ref`]。
    ///
    /// 有關可變的副本，請參見 [`as_mut`]。
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保滿足以下所有條件:
    ///
    /// * 指針必須正確對齊。
    ///
    /// * 在 [the module documentation] 中定義的意義上，它必須是 "dereferencable"。
    ///
    /// * 指針必須指向 `T` 的初始化實例。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///
    ///   特別是，在此生命週期內，指針所指向的內存一定不能發生突變 (`UnsafeCell` 內部除外)。
    ///
    /// 即使未使用此方法的結果也是如此!
    /// (關於初始化的部分尚未完全決定，但是直到確定之前，唯一安全的方法是確保它們確實被初始化。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // 安全: 调用者必須保證 `self` 符合所有
        // 供參考的要求。
        unsafe { &*self.as_ptr() }
    }

    /// 返回對該值的唯一引用。如果該值可能未初始化，則必須改用 [`as_uninit_mut`]。
    ///
    /// 有關共享副本，請參見 [`as_ref`]。
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保滿足以下所有條件:
    ///
    /// * 指針必須正確對齊。
    ///
    /// * 在 [the module documentation] 中定義的意義上，它必須是 "dereferencable"。
    ///
    /// * 指針必須指向 `T` 的初始化實例。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///
    ///   特別是，在此生命週期內，指針所指向的內存一定不能通過任何其他指針訪問 (讀取或寫入)。
    ///
    /// 即使未使用此方法的結果也是如此!
    /// (關於初始化的部分尚未完全決定，但是直到確定之前，唯一安全的方法是確保它們確實被初始化。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // 安全: 调用者必須保證 `self` 符合所有
        // 可變參考的要求。
        unsafe { &mut *self.as_ptr() }
    }

    /// 強制轉換為另一種類型的指針。
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // 安全: `self` 是 `NonNull` 指針，該指針必須非空
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// 根據細指針和長度創建非空的原始切片。
    ///
    /// `len` 參數是 **元素** 的數量，而不是字節數。
    ///
    /// 此函數是安全的，但是取消引用返回值是不安全的。
    /// 有關切片安全性要求，請參見 [`slice::from_raw_parts`] 的文檔。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // 從指向第一個元素的指針開始創建切片指針
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (請注意，該示例人為地演示了此方法的用法，但是 `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // 安全: `data` 是 `NonNull` 指針，該指針必須非空
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// 返回非空原始切片的長度。
    ///
    /// 返回的值是 **elements** 的數量，而不是字節數。
    ///
    /// 該功能是安全的，即使由於指針沒有有效地址而無法將非空原始切片重新引用到切片時也是如此。
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// 返回指向切片緩衝區的非 null 指針。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // 安全: 我們知道 `self` 不為空。
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// 返回指向切片緩衝區的原始指針。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// 返回對可能未初始化的值的切片的共享引用。與 [`as_ref`] 相比，這不需要將該值初始化。
    ///
    /// 有關可變的副本，請參見 [`as_uninit_slice_mut`]。
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保滿足以下所有條件:
    ///
    /// * 指針必須為 [valid]，才能讀取許多字節的 `ptr.len() * mem::size_of::<T>()`，並且必須正確對齊。這尤其意味著:
    ///
    ///     * 此片的整個內存範圍必須包含在一個分配的對像中!
    ///       切片永遠不能跨越多個分配的對象。
    ///
    ///     * 即使對於零長度的切片，指針也必須對齊。
    ///     這樣做的一個原因是，枚舉佈局優化可能依賴於對齊的引用 (包括任何長度的切片) 並且不為空，以將其與其他數據區分開。
    ///
    ///     您可以使用 [`NonNull::dangling()`] 獲得可用作零長度切片的 `data` 的指針。
    ///
    /// * 切片的總大小 `ptr.len() * mem::size_of::<T>()` 必須不大於 `isize::MAX`。
    ///   請參閱 [`pointer::offset`] 的安全文檔。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///   特別是，在此生命週期內，指針所指向的內存一定不能發生突變 (`UnsafeCell` 內部除外)。
    ///
    /// 即使未使用此方法的結果也是如此!
    ///
    /// 另請參見 [`slice::from_raw_parts`]。
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // 安全: 调用者必須遵守 `as_uninit_slice` 的安全合同。
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// 返回對可能未初始化的值的切片的唯一引用。與 [`as_mut`] 相比，這不需要將該值初始化。
    ///
    /// 有關共享副本，請參見 [`as_uninit_slice`]。
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保滿足以下所有條件:
    ///
    /// * 指針必須為 [valid] 才能進行 `ptr.len() * mem::size_of::<T>()` 多個字節的讀取和寫入，並且必須正確對齊。這尤其意味著:
    ///
    ///     * 此片的整個內存範圍必須包含在一個分配的對像中!
    ///       切片永遠不能跨越多個分配的對象。
    ///
    ///     * 即使對於零長度的切片，指針也必須對齊。
    ///     這樣做的一個原因是，枚舉佈局優化可能依賴於對齊的引用 (包括任何長度的切片) 並且不為空，以將其與其他數據區分開。
    ///
    ///     您可以使用 [`NonNull::dangling()`] 獲得可用作零長度切片的 `data` 的指針。
    ///
    /// * 切片的總大小 `ptr.len() * mem::size_of::<T>()` 必須不大於 `isize::MAX`。
    ///   請參閱 [`pointer::offset`] 的安全文檔。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///   特別是，在此生命週期內，指針所指向的內存一定不能通過任何其他指針訪問 (讀取或寫入)。
    ///
    /// 即使未使用此方法的結果也是如此!
    ///
    /// 另請參見 [`slice::from_raw_parts_mut`]。
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // 這是安全的，因為 `memory` 對於許多字節的 `memory.len()` 讀和寫有效。
    /// // 請注意，此處不允許調用 `memory.as_mut()`，因為內容可能未初始化。
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // 安全: 调用者必須遵守 `as_uninit_slice_mut` 的安全合同。
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// 返回指向元素或子切片的原始指針，而不進行邊界檢查。
    ///
    /// 即使沒有使用結果指針，使用越界索引或在 `self` 不可引用時調用此方法也是 *[undefined behavior]*。
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // 安全: 調用者確保 `self` 是可取消引用的，並且 `index` 是入站的。
        // 因此，結果指針不能為 NULL。
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // 安全: 唯一指針不能為空，因此用於
        // new_unchecked() 被尊重。
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // 安全: 可變引用不能為空。
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // 安全: 引用不能為空，因此用於
        // new_unchecked() 被尊重。
        unsafe { NonNull { pointer: reference as *const T } }
    }
}