//! 通過原始指針手動管理內存。
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! 該模塊中的許多函數都將原始指針作為參數，並從中讀取或寫入它們。為了安全起見，這些指針必須是 *valid*。
//! 指針是否有效取決於指針用於 (讀或寫) 的操作以及所訪問的內存範圍 (即 read/written 多少個字節)。
//! 大多數函數使用 `*mut T` 和 `* const T` 來訪問單個值，在這種情況下，文檔將忽略該大小，並隱式地假定它為 `size_of::<T>()` 字節。
//!
//! 有效性的確切規則尚未確定。此時提供的保證非常小:
//!
//! * [null] 指針 `永不` 有效，即使對於 [size zero][zst] 的訪問也不有效。
//! * 為了使指針有效，有必要 (但並不總是足夠) 使指針 *可引用*: 從指針開始的給定大小的內存範圍必須全部在單個已分配對象的範圍內。
//!
//! 請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
//! * 即使對於 [size zero][zst] 的操作，指針也不得指向已釋放的內存，即，即使對於大小為零的操作，釋放也會使指針無效。
//! 但是，將任何非零整數 *literal* 強制轉換為指針對於零大小的訪問都是有效的，即使該地址恰好存在一些內存並被釋放了。
//! 這相當於編寫自己的分配器: 分配零大小的對像不是很困難。
//! 獲得對零大小訪問有效的指針的規範方法是 [`NonNull::dangling`]。
//! * 在 [atomic operations] 的意義上，此模塊中功能執行的所有訪問都是非原子的，用於在線程之間進行同步。
//! 這意味著從兩個不同的線程對同一位置執行兩次並發訪問是不確定的行為，除非兩個訪問都僅從內存中讀取。
//! 請注意，這明確包含 [`read_volatile`] 和 [`write_volatile`]: 易失性訪問不能用於線程間同步。
//! * 只要基礎對象處於活動狀態，並且不使用引用 (僅原始指針) 來訪問同一內存，則對指針進行強制轉換的結果是有效的。
//!
//! 這些公理，以及仔細地使用 [`offset`] 進行指針算術，足以在不安全的代碼中正確實現許多有用的東西。
//! 隨著 [aliasing] 規則的確定，最終將提供更強有力的保證。
//! 有關更多信息，請參見 [book] 以及參考文獻中專門針對 [undefined behavior][ub] 的部分。
//!
//! ## Alignment
//!
//! 上面定義的有效原始指針不一定正確對齊 (其中 "proper" 對齊由 pointee 類型定義，即 `*const T` 必須與 `mem::align_of::<T>()` 對齊)。
//! 但是，大多數函數要求其參數正確對齊，並將在其文檔中明確說明此要求。
//! [`read_unaligned`] 和 [`write_unaligned`] 除外。
//!
//! 當一個功能需要正確的對齊時，即使訪問的大小為 0，即即使實際上沒有觸及內存，也需要進行正確的對齊。在這種情況下，請考慮使用 [`NonNull::dangling`]。
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// 執行指向值的析構函數 (如果有)。
///
/// 從語義上講，這等效於調用 [`ptr::read`] 並丟棄結果，但是具有以下優點:
///
/// * 強制要求使用 `drop_in_place` 刪除未縮放的類型 (例如 trait 對象)，因為它們無法被讀取到堆棧上並且無法正常刪除。
///
/// * 當刪除手動分配的內存時 (例如，在 `Box`/`Rc`/`Vec` 的實現中)，通過 [`ptr::read`] 進行此操作對優化器來說更友好，因為編譯器不需要證明刪除副本是合理的。
///
///
/// * 當 `T` 不是 `repr(packed)` 時，可用於刪除 [pinned] 數據 (在刪除固定的數據之前，不得移動固定的數據)。
///
/// 未對齊的值不能放在適當的位置，必須先使用 [`ptr::read_unaligned`] 將它們複製到對齊的位置。對於打包的結構，此移動由編譯器自動完成。
/// 這意味著打包結構的字段不會就地放置。
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `to_drop` 對於讀寫，必須為 [valid]。
///
/// * `to_drop` 必須正確對齊。
///
/// * `to_drop` 指向的值必須對刪除有效，這可能意味著它必須支持其他不變式，這與類型有關。
///
/// 此外，如果 `T` 不是 [`Copy`]，則在調用 `drop_in_place` 之後使用指向的值可能會導致未定義的行為。請注意，`*to_drop = foo` 被視為有用，因為它將導致該值再次下降。
/// [`write()`] 可用於覆蓋數據而不會導致數據被丟棄。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL 並正確對齊。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 從 vector 手動刪除最後一項:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // 獲取指向 `v` 中最後一個元素的原始指針。
///     let ptr = &mut v[1] as *mut _;
///     // 縮短 `v` 以防止最後一項掉落。
///     // 我們首先這樣做是為了防止 `drop_in_place` 低於 panics。
///     v.set_len(1);
///     // 如果沒有调用 `drop_in_place`，則最後一個項目將永遠不會被丟棄，並且它管理的內存也會洩漏。
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // 確保已刪除最後一個項目。
/// assert!(weak.upgrade().is_none());
/// ```
///
/// 請注意，編譯器在刪除打包的結構時會自動執行此副本，即，除非您手動調用 `drop_in_place`，否則通常不必擔心此類問題。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // 此處的代碼無關緊要，編譯器將其替換為真正的滴膠。
    //

    // 安全: 請參閱上面的評論
    unsafe { drop_in_place(to_drop) }
}

/// 創建一個空的原始指針。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// 創建一個空的可變原始指針。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// 需要避免 `T: Clone` 綁定的手動提示。
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// 需要避免 `T: Copy` 綁定的手動提示。
impl<T> Copy for FatPtr<T> {}

/// 根據指針和長度形成原始切片。
///
/// `len` 參數是 **元素** 的數量，而不是字節數。
///
/// 此函數是安全的，但實際上使用返回值是不安全的。
/// 有關切片安全性要求，請參見 [`slice::from_raw_parts`] 的文檔。
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // 從指向第一個元素的指針開始創建切片指針
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // 安全: 從 `Repr` 聯合訪問值很安全，因為 * const [T]
        //
        // 和 FatPtr 具有相同的內存佈局。只有 std 可以做出此保證。
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// 執行與 [`slice_from_raw_parts`] 相同的功能，但返回的是原始可變切片，而不是不可變的原始切片。
///
///
/// 有關更多詳細信息，請參見 [`slice_from_raw_parts`] 的文檔。
///
/// 此函數是安全的，但實際上使用返回值是不安全的。
/// 有關切片安全性要求，請參見 [`slice::from_raw_parts_mut`] 的文檔。
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // 在切片中的索引處分配一個值
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // 安全: 由於 * mut [T]，從 `Repr` 聯合訪問值是安全的
        // 和 FatPtr 具有相同的內存佈局
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// 在相同類型的兩個可變位置交換值，而不用對它們進行初始化。
///
/// 但是對於以下兩個例外，此函數在語義上等效於 [`mem::swap`]:
///
///
/// * 它對原始指針 (而不是引用) 進行操作。
/// 如果有可用的引用，則應首選 [`mem::swap`]。
///
/// * 兩個指向的值可能會重疊。
/// 如果值確實重疊，則將使用 `x` 的內存重疊區域。
/// 在下面的第二個示例中對此進行了演示。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * 對於讀取和寫入，`x` 和 `y` 都必須為 [valid]。
///
/// * `x` 和 `y` 必須正確對齊。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL 並正確對齊。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 交換兩個不重疊的區域:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // 這是 `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // 這是 `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// 交換兩個重疊的區域:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // 這是 `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // 這是 `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // 切片的索引 `1..3` 在 `x` 和 `y` 之間重疊。
///     // 合理的結果將是 `[2, 3]`，因此索引 `0..3` 為 `[1, 2, 3]` (與 `swap` 匹配的 `y`) ; 或將它們設為 `[0, 1]`，以使索引 `1..4` 為 `[0, 1, 2]` (與 `swap` 之前的 `x` 匹配)。
/////
///     // 定義此實現是為了做出後一種選擇。
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // 給自己一些工作的空間。
    // 我們不必擔心掉線: 掉線時 `MaybeUninit` 不會執行任何操作。
    let mut tmp = MaybeUninit::<T>::uninit();

    // 執行交換安全性: 調用者必須保證 `x` 和 `y` 對於寫入有效並且正確對齊。
    // `tmp` 不能與 `x` 或 `y` 重疊，因為 `tmp` 只是作為單獨的已分配對像在堆棧上分配的。
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` 和 `y` 可能重疊
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// 從 `x` 和 `y` 開始在兩個內存區域之間交換 `count * size_of::<T>()` 字節。
/// 這兩個區域必須 *不能* 重疊。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `x` 和 `y` 都必須為 [valid] 才能讀取和寫入 `count *
///   size_of: :<T> () ` 個字節。
///
/// * `x` 和 `y` 必須正確對齊。
///
/// * 從 `x` 開始的內存區域，大小為 `count *
///   size_of: :<T> () ` 字節不得與以 `y` 開始且大小相同的內存區域重疊。
///
/// 請注意，即使有效複製的大小 (`count * size_of: :: <T> () `) 為 `0`，則指針必須為非 NULL 並正確對齊。
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // 安全: 调用者必須保證 `x` 和 `y`
    // 對寫入有效，並且已正確對齊。
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // 對於小於下面的塊優化的類型，只需直接交換就可以避免對代碼源造成不必要的影響。
    //
    if mem::size_of::<T>() < 32 {
        // 安全: 调用者必須保證 `x` 和 `y` 有效
        // 適用於寫入，正確對齊且不重疊。
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // 安全: 调用者必須遵守 `swap_nonoverlapping` 的安全合同。
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // 這裡的方法是利用 simd 有效地交換 x 和 y。
    // 測試表明，一次交換 32 字節或 64 字節對於 Intel Haswell E 處理器是最有效的。
    // 如果我們不給 #[repr(simd)] 結構一個 LLVM，即使我們實際上並沒有直接使用這個結構，它也有能力進行優化。
    //
    //
    // FIXME repr(simd) 在腳本和氧化還原上損壞
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // 遍歷 x 和 y，一次復制 `Block` 優化器應針對大多數類型的 NB 完全展開循環
    // 我們不能使用 for 循環，因為 `range` impl 遞歸調用 `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // 創建一些未初始化的內存作為暫存空間在此聲明 `t` 可以避免在未使用此循環時對齊堆棧
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // 安全: 作為 `i < len`，並且作為调用者，必須保證 `x` 和 `y` 有效
        // 對於 `len` 字節，`x + i` 和 `y + i` 必須是有效地址，符合 `add` 的安全約定。
        //
        // 同樣，調用者必須保證 `x` 和 `y` 對於寫入有效，正確對齊且不重疊，從而滿足 `copy_nonoverlapping` 的安全性要求。
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // 將 t 用作臨時緩衝區交換 x＆y 字節的字節塊。應將其優化為有效的 SIMD 操作 (如果可用)
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // 交換所有剩餘字節
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // 安全: 請參閱以前的安全註釋。
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// 將 `src` 移至指定的 `dst`，返回先前的 `dst` 值。
///
/// 這兩個值都不會下降。
///
/// 此函數在語義上等效於 [`mem::replace`]，除了它對原始指針 (而不是引用) 進行操作。
/// 如果有可用的引用，則應首選 [`mem::replace`]。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `dst` 對於讀寫，必須為 [valid]。
///
/// * `dst` 必須正確對齊。
///
/// * `dst` 必須指向類型為 `T` 的正確初始化的值。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL 並正確對齊。
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` 不需要 unsafe 塊將具有相同的效果。
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // 安全: 调用者必須保證 `dst` 有效
    // 強制轉換為可變引用 (對寫入，對齊，初始化有效)，並且不能與 `src` 重疊，因為 `dst` 必須指向不同的分配對象。
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // 不能重疊
    }
    src
}

/// 從 `src` 讀取值而不移動它。這使 `src` 中的內存保持不變。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `src` 必須為 [valid] 才能讀取。
///
/// * `src` 必須正確對齊。如果不是這種情況，請使用 [`read_unaligned`]。
///
/// * `src` 必須指向類型為 `T` 的正確初始化的值。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL 並正確對齊。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// 手動實施 [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // 在 `tmp` 中的 `a` 處創建值的按位副本。
///         let tmp = ptr::read(a);
///
///         // 此時退出 (通過顯式返回或調用 panics 函數) 將導致 `tmp` 中的值被刪除，而 `a` 仍引用相同的值。
///         // 如果 `T` 不是 `Copy`，則可能觸發未定義的行為。
/////
/////
///
///         // 在 `a` 中的 `b` 處創建值的按位副本。
///         // 這是安全的，因為可變引用不能別名。
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 如上所述，由於 `a` 和 `b` 引用了相同的值，因此退出此處可能會觸發未定義的行為。
/////
///
///         // 將 `tmp` 移至 `b`。
///         ptr::write(b, tmp);
///
///         // `tmp` 已被移動 (`write` 擁有其第二個參數的所有權)，因此此處未隱式刪除任何內容。
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## 歸還價值的所有權
///
/// `read` 不管 `T` 是否為 [`Copy`]，都會創建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，則同時使用返回的值和 `*src` 的值可能會違反內存安全性。
/// 請注意，將分配給 `*src` 視為一種用途，因為它將嘗試刪除 `* src` 處的值。
///
/// [`write()`] 可用於覆蓋數據而不會導致數據被丟棄。
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` 現在指向與 `s` 相同的基礎內存。
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // 分配給 `s2` 會導致其原始值被丟棄。
///     // 除此之外，由於已釋放基礎內存，因此不能再使用 `s`。
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // 分配給 `s` 將導致舊值再次被丟棄，從而導致未定義的行為。
/////
///     // s= String::from("bar");// 錯誤
///
///     // `ptr::write` 可用於覆蓋一個值而不刪除它。
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // 安全: 調用者必須保證 `src` 對於讀取有效。
    // `src` 不能與 `tmp` 重疊，因為 `tmp` 只是作為單獨的分配對像在堆棧上分配的。
    //
    //
    // 另外，由於我們只是將有效值寫入 `tmp`，因此可以確保正確初始化它。
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// 從 `src` 讀取值而不移動它。這使 `src` 中的內存保持不變。
///
/// 與 [`read`] 不同，`read_unaligned` 使用未對齊的指針。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `src` 必須為 [valid] 才能讀取。
///
/// * `src` 必須指向類型為 `T` 的正確初始化的值。
///
/// 與 [`read`] 一樣，無論 `T` 是否為 [`Copy`]，`read_unaligned` 都會創建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，則同時使用返回值和 `*src` 處的值都可以 [violate memory safety][read-ownership]。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL。
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## 在 `packed` 結構上
///
/// 當前無法創建指向打包結構的未對齊字段的原始指針。
///
/// 嘗試使用諸如 `&packed.unaligned as *const FieldType` 之類的表達式創建指向 `unaligned` 結構域的原始指針，然後再將其轉換為原始指針，從而創建一個中間未對齊的引用。
///
/// 該引用是臨時的，並且立即強制轉換是無關緊要的，因為編譯器始終希望引用能夠正確對齊。
/// 結果，使用 `&packed.unaligned as *const FieldType` 會在程序中立即導致 `未定義的行為`。
///
/// 一個不執行的操作以及它與 `read_unaligned` 的關係的示例是:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // 在這裡，我們嘗試獲取未對齊的 32 位整數的地址。
///     let unaligned =
///         // 此處將創建一個臨時的未對齊參考，無論是否使用該參考，都會導致未定義的行為。
/////
///         &packed.unaligned
///         // 強制轉換為原始指針沒有幫助; 錯誤已經發生。
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// 但是，例如使用 `packed.unaligned` 直接訪問未對齊的字段是安全的。
///
///
///
///
///
///
// FIXME: 根據 RFC #2582 和朋友的結果更新文檔。
/// # Examples
///
/// 從字節緩衝區讀取 usize 值:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // 安全: 調用者必須保證 `src` 對於讀取有效。
    // `src` 不能與 `tmp` 重疊，因為 `tmp` 只是作為單獨的分配對像在堆棧上分配的。
    //
    //
    // 另外，由於我們只是將有效值寫入 `tmp`，因此可以確保正確初始化它。
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// 用給定值覆蓋存儲位置，而無需讀取或刪除舊值。
///
/// `write` 不會刪除 `dst` 的內容。
/// 這是安全的，但可能會洩漏分配或資源，因此應注意不要覆蓋應刪除的對象。
///
///
/// 此外，它不會刪除 `src`。在語義上，`src` 被移到 `dst` 指向的位置。
///
/// 這適用於初始化未初始化的內存，或覆蓋以前是 [`read`] 的內存。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `dst` 必須為 [valid] 進行寫入。
///
/// * `dst` 必須正確對齊。如果不是這種情況，請使用 [`write_unaligned`]。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL 並正確對齊。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// 手動實施 [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // 在 `tmp` 中的 `a` 處創建值的按位副本。
///         let tmp = ptr::read(a);
///
///         // 此時退出 (通過顯式返回或調用 panics 函數) 將導致 `tmp` 中的值被刪除，而 `a` 仍引用相同的值。
///         // 如果 `T` 不是 `Copy`，則可能觸發未定義的行為。
/////
/////
///
///         // 在 `a` 中的 `b` 處創建值的按位副本。
///         // 這是安全的，因為可變引用不能別名。
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 如上所述，由於 `a` 和 `b` 引用了相同的值，因此退出此處可能會觸發未定義的行為。
/////
///
///         // 將 `tmp` 移至 `b`。
///         ptr::write(b, tmp);
///
///         // `tmp` 已被移動 (`write` 擁有其第二個參數的所有權)，因此此處未隱式刪除任何內容。
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // 我們直接調用內部函數是為了避免在生成的代碼中調用函數，因為 `intrinsics::copy_nonoverlapping` 是包裝函數。
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // 安全: 調用者必須保證 `dst` 對於寫入有效。
    // `dst` `src` 不能與 `src` 重疊，因為當此功能擁有 `src` 時，調用方可以對 `dst` 進行可變訪問。
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// 用給定值覆蓋存儲位置，而無需讀取或刪除舊值。
///
/// 與 [`write()`] 不同，指針可能未對齊。
///
/// `write_unaligned` 不會刪除 `dst` 的內容。這是安全的，但可能會洩漏分配或資源，因此應注意不要覆蓋應刪除的對象。
///
/// 此外，它不會刪除 `src`。在語義上，`src` 被移到 `dst` 指向的位置。
///
/// 這適用於初始化未初始化的內存，或覆蓋以前用 [`read_unaligned`] 讀取的內存。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `dst` 必須為 [valid] 進行寫入。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL。
///
/// [valid]: self#safety
///
/// ## 在 `packed` 結構上
///
/// 當前無法創建指向打包結構的未對齊字段的原始指針。
///
/// 嘗試使用諸如 `&packed.unaligned as *const FieldType` 之類的表達式創建指向 `unaligned` 結構域的原始指針，然後再將其轉換為原始指針，從而創建一個中間未對齊的引用。
///
/// 該引用是臨時的，並且立即強制轉換是無關緊要的，因為編譯器始終希望引用能夠正確對齊。
/// 結果，使用 `&packed.unaligned as *const FieldType` 會在程序中立即導致 `未定義的行為`。
///
/// 一個不執行的操作以及它與 `write_unaligned` 的關係的示例是:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // 在這裡，我們嘗試獲取未對齊的 32 位整數的地址。
///     let unaligned =
///         // 此處將創建一個臨時的未對齊參考，無論是否使用該參考，都會導致未定義的行為。
/////
///         &mut packed.unaligned
///         // 強制轉換為原始指針沒有幫助; 錯誤已經發生。
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// 但是，例如使用 `packed.unaligned` 直接訪問未對齊的字段是安全的。
///
///
///
///
///
///
///
///
///
// FIXME: 根據 RFC #2582 和朋友的結果更新文檔。
/// # Examples
///
/// 將 usize 值寫入字節緩衝區:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // 安全: 調用者必須保證 `dst` 對於寫入有效。
    // `dst` `src` 不能與 `src` 重疊，因為當此功能擁有 `src` 時，調用方可以對 `dst` 進行可變訪問。
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // 我們直接調用內部函數以避免在生成的代碼中調用函數。
        intrinsics::forget(src);
    }
}

/// 對 `src` 的值進行易失性讀取，而無需移動它。這使 `src` 中的內存保持不變。
///
/// 易失性操作旨在作用於 I/O 存儲器，並保證編譯器不會在其他易失性操作中對易失性操作進行清除或重新排序。
///
/// # Notes
///
/// Rust 當前沒有嚴格和正式定義的內存模型，因此 "volatile" 此處所指的確切語義會隨時間而變化。
/// 話雖如此，其語義幾乎總是以與 [C11's definition of volatile][c11] 相似的方式結束。
///
/// 編譯器不應更改易失性存儲器操作的相對順序或數量。
/// 但是，零大小類型 (例如，如果將零大小類型傳遞給 `read_volatile`) 上的易失性存儲器操作為無操作，可以忽略。
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `src` 必須為 [valid] 才能讀取。
///
/// * `src` 必須正確對齊。
///
/// * `src` 必須指向類型為 `T` 的正確初始化的值。
///
/// 與 [`read`] 一樣，無論 `T` 是否為 [`Copy`]，`read_volatile` 都會創建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，則同時使用返回值和 `*src` 處的值都可以 [violate memory safety][read-ownership]。
/// 但是，幾乎可以肯定地將非 [`Copy`] 類型存儲在易失性存儲器中。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL 並正確對齊。
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// 就像在 C 語言中一樣，操作是否易失性與涉及從多個線程進行並發訪問的問題無關。在這方面，易失性訪問的行為與非原子訪問完全相同。
///
/// 特別是，`read_volatile` 與任何對同一位置的寫操作之間的爭奪是未定義的行為。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // 不要驚慌，以保持代碼生成的影響較小。
        abort();
    }
    // 安全: 调用者必須遵守 `volatile_load` 的安全合同。
    unsafe { intrinsics::volatile_load(src) }
}

/// 使用給定值對存儲單元執行易失性寫操作，而無需讀取或刪除舊值。
///
/// 易失性操作旨在作用於 I/O 存儲器，並保證編譯器不會在其他易失性操作中對易失性操作進行清除或重新排序。
///
/// `write_volatile` 不會刪除 `dst` 的內容。這是安全的，但可能會洩漏分配或資源，因此應注意不要覆蓋應刪除的對象。
///
/// 此外，它不會刪除 `src`。在語義上，`src` 被移到 `dst` 指向的位置。
///
/// # Notes
///
/// Rust 當前沒有嚴格和正式定義的內存模型，因此 "volatile" 此處所指的確切語義會隨時間而變化。
/// 話雖如此，其語義幾乎總是以與 [C11's definition of volatile][c11] 相似的方式結束。
///
/// 編譯器不應更改易失性存儲器操作的相對順序或數量。
/// 但是，零大小類型 (例如，如果將零大小類型傳遞給 `write_volatile`) 上的易失性存儲器操作為無操作，可以忽略。
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `dst` 必須為 [valid] 進行寫入。
///
/// * `dst` 必須正確對齊。
///
/// 請注意，即使 `T` 的大小為 `0`，指針也必須為非 NULL 並正確對齊。
///
/// [valid]: self#safety
///
/// 就像在 C 語言中一樣，操作是否易失性與涉及從多個線程進行並發訪問的問題無關。在這方面，易失性訪問的行為與非原子訪問完全相同。
///
/// 特別是，`write_volatile` 與同一位置上的任何其他操作 (讀取或寫入) 之間的爭奪是未定義的行為。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // 不要驚慌，以保持代碼生成的影響較小。
        abort();
    }
    // 安全: 调用者必須遵守 `volatile_store` 的安全合同。
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// 對齊指針 `p`。
///
/// 計算必須應用於指針 `p` 的偏移量 (根據 `stride` 步幅)，以便指針 `p` 與 `a` 對齊。
///
/// Note: 此實現已精心設計為非 panic。到 panic 是 UB。
/// 此處唯一可以進行的更改是 `INV_TABLE_MOD_16` 及其關聯常量的更改。
///
/// 如果我們決定允許使用非 2 的冪的 `a` 來調用內部函數，那麼將其更改為一個簡單的實現而不是嘗試對其進行調整以適應該更改可能會更為謹慎。
///
///
/// 如有任何疑問，請聯繫 @nagisa。
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): 在 opt 級別 <= 上，直接使用這些內在函數可顯著改善代碼生成
    // 1，其中未內聯這些操作的方法版本。
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// 計算 `x` 模 `m` 的乘法模逆。
    ///
    /// 此實現是針對 `align_offset` 量身定制的，並具有以下先決條件:
    ///
    /// * `m` 是二的冪;
    /// * `x < m`; (如果使用 `x ≥ m`，請改為傳入 `x % m`)
    ///
    /// 該功能的實現不得為 panic。曾經。
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// 乘模逆矩陣模 2⁴=16。
        ///
        /// 注意，該表不包含不存在反值的值 (例如，對於 `0⁻¹ mod 16`，`2⁻¹ mod 16` 等)。
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` 的模數。
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // 安全: `m` 必須為 2 的冪，因此不能為零。
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // 我們使用以下公式迭代 "up":
            //
            // $$ xy≡1 (mod2ⁿ) →xy (2，xy) ≡1 (mod2²ⁿ) $$
            //
            // 直到 2²ⁿ≥m。然後，我們可以通過取結果 `mod m` 減少到所需的 `m`。
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2，xy) mod n
                //
                // 注意，這裡我們有意使用包裝操作-原始公式使用減法 `mod n`。
                // 改用 `mod usize::MAX` 完全可以，因為無論如何我們將結果 `mod n` 放在最後。
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // 安全: `a` 為 2 的冪，因此非零。
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` 通過 `-p (mod a)` 可以更簡單地計算大小寫，但是這樣做會限制 LLVM 選擇 `lea` 之類的指令的能力。相反，我們計算
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // 它圍繞承重來分配操作，但是對 `and` 進行了充分的模擬，以使 LLVM 能夠利用它所了解的各種優化。
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // 已經對齊。耶!
        return 0;
    } else if stride == 0 {
        // 如果指針未對齊，並且元素大小為零，則將沒有任何元素可以對齊指針。
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // 安全: a 為 2 的冪，因此非零。步幅 ==0 情況已在上面處理。
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // 安全性: gcdpow 的上限最多是 usize 中的位數。
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // 安全性: gcd 始終大於或等於 1。
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch 求解以下線性同餘方程:
        //
        // ` p + so = 0 mod a `
        //
        // `p` 這是指針值 `s`，`T` 的步幅，`o` 在 `T` 中的偏移量以及 `a` (所請求的對齊方式)。
        //
        // 使用 `g = gcd(a, s)`，並且上面的條件斷言 `p` 也可以被 `g` 整除，我們可以表示 `a' = a/g`，`s' = s/g`，`p' = p/g`，那麼它等效於:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // 第一項是 "the relative alignment of `p` to `a`" (除以 `g`)，第二項是 "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (再次除以 `g`)。
        //
        // 如果 `a` 和 `s` 不是互質的，則 `g` 的除法對於使逆結構良好是必要的。
        //
        // 此外，此解決方案產生的結果不是 "minimal"，因此必須獲取結果 `o mod lcm(s, a)`。我們可以只用 `a'` 代替 `lcm(s, a)`。
        //
        //
        //
        //
        //

        // 安全: `gcdpow` 的上限不大於 `a` 的尾隨 0 位的數量。
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // 安全: `a2` 不為零。將 `a` 移位 `gcdpow` 不能移出任何設置的位
        // 在 `a` 中 (它只有一個)。
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // 安全: `gcdpow` 的上限不大於 `a` 的尾隨 0 位的數量。
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // 安全性: `gcdpow` 的上限不大於以下內容中的尾隨 0 位的數量
        // `a`.
        // 此外，減法不會溢出，因為 `a2 = a >> gcdpow` 將始終嚴格大於 `(p % a) >> gcdpow`。
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // 安全: 如上所述，`a2` 是 2 的冪。`s2` 嚴格小於 `a2`
        // 因為 `(s % a) >> gcdpow` 嚴格小於 `a >> gcdpow`。
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // 根本無法對齊。
    usize::MAX
}

/// 比較原始指針是否相等。
///
/// 這與使用 `==` 運算符相同，但通用性較低:
/// 參數必須是 `*const T` 原始指針，而不是任何實現 `PartialEq` 的東西。
///
/// 這可以用來按地址比較 `&T` 引用 (隱式強制為 `*const T`)，而不是比較它們指向的值 (`PartialEq for &T` 實現的作用)。
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// 切片還通過其長度 (胖指針) 進行比較:
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits 的實現方式也進行了比較:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // 指針具有相等的地址。
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // 對象具有相等的地址，但是 `Trait` 具有不同的實現。
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // 將引用轉換為 `*const u8` 時，將按地址進行比較。
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// 散列原始指針。
///
/// 這可以用來按其地址而不是它所指向的值 (`Hash for &T` 實現的作用) 對 `&T` 引用 (隱式強制為 `*const T`) 進行哈希處理。
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// 函數指針的暗示
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR 需要使用中間轉換
                // 這樣，源函數指針的地址空間將保留在最終函數指針中。
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR 需要使用中間轉換
                // 這樣，源函數指針的地址空間將保留在最終函數指針中。
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 沒有參數為 0 的可變參數函數
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// 創建一個 `const` 原始指針到一個位置，而無需創建中間引用。
///
/// 僅當指針正確對齊並指向初始化數據時，才允許使用 `&`/`&mut` 創建引用。
/// 對於那些要求不成立的情況，應使用原始指針代替。
/// 但是，`&expr as *const _` 在將其強制轉換為原始指針之前會創建一個引用，並且該引用與所有其他引用都遵循相同的規則。
///
/// 該宏可以創建原始指針，而無需先創建引用。
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` 會創建未對齊的引用，因此是未定義的行為!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// 創建一個 `mut` 原始指針到一個位置，而無需創建中間引用。
///
/// 僅當指針正確對齊並指向初始化數據時，才允許使用 `&`/`&mut` 創建引用。
/// 對於那些要求不成立的情況，應使用原始指針代替。
/// 但是，`&mut expr as *mut _` 在將其強制轉換為原始指針之前會創建一個引用，並且該引用與所有其他引用都遵循相同的規則。
///
/// 該宏可以創建原始指針，而無需先創建引用。
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` 會創建未對齊的引用，因此是未定義的行為!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` 強制複製字段而不是創建引用。
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}