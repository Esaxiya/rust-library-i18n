use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// 如果指針為空，則返回 `true`。
    ///
    /// 請注意，未調整大小的類型具有許多可能的空指針，因為僅考慮原始數據指針，而不考慮其長度，vtable 等。
    /// 因此，兩個為空的指針可能仍不能相互比較相等。
    ///
    /// ## 常量評估期間的行為
    ///
    /// 在 const 評估期間使用此函數時，對於在運行時結果為空的指針，它可能返回 `false`。
    /// 具體來說，當指向某個內存的指針超出其範圍的偏移量 (使結果指針為空) 時，該函數仍將返回 `false`。
    ///
    /// CTFE 無法知道該內存的絕對位置，因此我們無法確定指針是否為空。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // 通過轉換與精簡指針進行比較，因此胖指針僅考慮其 "data" 部分是否為空。
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// 強制轉換為另一種類型的指針。
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// 將 (可能是很寬的) 指針分解為地址和元數據組件。
    ///
    /// 以後可以使用 [`from_raw_parts`] 重建指針。
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// 如果指針為空，則返回 `None`; 否則，返回對包裝在 `Some` 中的值的共享引用。如果該值可能未初始化，則必須改用 [`as_uninit_ref`]。
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保指針要么為 NULL，要么所有以下條件為真:
    ///
    /// * 指針必須正確對齊。
    ///
    /// * 在 [the module documentation] 中定義的意義上，它必須是 "dereferencable"。
    ///
    /// * 指針必須指向 `T` 的初始化實例。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///   特別是，在此生命週期內，指針所指向的內存一定不能發生突變 (`UnsafeCell` 內部除外)。
    ///
    /// 即使未使用此方法的結果也是如此!
    /// (關於初始化的部分尚未完全決定，但是直到確定之前，唯一安全的方法是確保它們確實被初始化。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # 空未經檢查的版本
    ///
    /// 如果您確定指針永遠不能為空，並且正在尋找某種返回 `&T` 而不是 `Option<&T>` 的 `as_ref_unchecked`，請知道您可以直接取消引用該指針。
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // 安全: 调用者必須保證 `self` 有效
        // 供參考，如果它不為 null。
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// 如果指針為空，則返回 `None`; 否則，返回對包裝在 `Some` 中的值的共享引用。
    /// 與 [`as_ref`] 相比，這不需要將該值初始化。
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保指針要么為 NULL，要么所有以下條件為真:
    ///
    /// * 指針必須正確對齊。
    ///
    /// * 在 [the module documentation] 中定義的意義上，它必須是 "dereferencable"。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///
    ///   特別是，在此生命週期內，指針所指向的內存一定不能發生突變 (`UnsafeCell` 內部除外)。
    ///
    /// 即使未使用此方法的結果也是如此!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // 安全: 调用者必須保證 `self` 符合所有
        // 供參考的要求。
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// 計算與指針的偏移量。
    ///
    /// `count` 以 T 為單位; 例如，`count` 為 3 表示 `3 * size_of::<T>()` 字節的指針偏移量。
    ///
    /// # Safety
    ///
    /// 如果違反以下任一條件，則結果為 `不確定行為`:
    ///
    /// * 起始指針和結果指針都必須在同一分配對象末尾的範圍之內或一個字節之內。
    /// 請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
    ///
    /// * 計算的偏移量 (以字節為單位 **) 不會使 `isize` 溢出。
    ///
    /// * 偏移量不能依賴 "wrapping around" 地址空間。也就是說，無限精度總和 (以字節為單位) 必須適合於 usize。
    ///
    /// 編譯器和標準庫通常會嘗試確保分配永遠不會達到需要考慮偏移量的大小。
    /// 例如，`Vec` 和 `Box` 確保它們分配的字節數永遠不會超過 `isize::MAX` 字節，因此 `vec.as_ptr().add(vec.len())` 始終是安全的。
    ///
    /// 從根本上說，大多數平台甚至都無法構造這樣的分配。
    /// 例如，由於頁表的限製或地址空間的分割，沒有已知的 64 位平台可以滿足 2 <sup>63</sup> 字節的請求。
    /// 但是，某些 32 位和 16 位平台可能通過物理地址擴展之類的東西成功地為超過 `isize::MAX` 字節的請求提供服務。
    ///
    /// 因此，直接從分配器獲取的內存或內存映射文件 *可能* 太大而無法使用此功能處理。
    ///
    /// 如果這些約束難以滿足，請考慮使用 [`wrapping_offset`]。
    /// 此方法的唯一優點是，它可以實現更積極的編譯器優化。
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `offset` 的安全合同。
        unsafe { intrinsics::offset(self, count) }
    }

    /// 使用換行算法計算與指針的偏移量。
    ///
    /// `count` 以 T 為單位; 例如，`count` 為 3 表示 `3 * size_of::<T>()` 字節的指針偏移量。
    ///
    /// # Safety
    ///
    /// 此操作本身始終是安全的，但使用結果指針則不安全。
    ///
    /// 結果指針仍然附加到 `self` 指向的同一分配對象。
    /// 它可能 *不能* 用於訪問其他分配的對象。請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
    ///
    /// 換句話說，即使我們假設 `T` 的大小為 `1` 並且沒有溢出，`let z = x.wrapping_offset((y as isize) - (x as isize))` 並不會使 `z` 與 `y` 相同: `z` 仍附加到對象 `x` 所附加的對像上，並且取消引用它是未定義行為，除非 `x` 和 `y` 指向相同的分配對象。
    ///
    /// 與 [`offset`] 相比，此方法從根本上延遲了留在同一分配對象內的需求: [`offset`] 是跨越對象邊界時的立即未定義行為; `wrapping_offset` 產生一個指針，但是如果指針超出其附加對象的範圍而被取消引用，則仍會導致未定義行為。
    /// [`offset`] 可以更好地進行優化，因此在對性能敏感的代碼中更可取。
    ///
    /// 延遲檢查僅考慮取消引用的指針的值，而不考慮最終結果計算期間使用的中間值。
    /// 例如，`x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` 始終與 `x` 相同。換句話說，允許離開分配的對象，然後在以後重新輸入它。
    ///
    /// 如果您需要越過對象邊界，請將指針轉換為整數，然後在該處進行算術運算。
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 使用原始指針以兩個元素為增量進行迭代
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // 此循環打印 "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // 安全: `arith_offset` 內部函數沒有先決條件。
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// 計算兩個指針之間的距離。返回的值以 T 為單位: 以字節為單位的距離除以 `mem::size_of::<T>()`。
    ///
    /// 該功能與 [`offset`] 相反。
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// 如果違反以下任一條件，則結果為 `不確定行為`:
    ///
    /// * 起始指針和其他指針都必須在同一分配對象末尾的範圍之內或一個字節之內。
    /// 請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
    ///
    /// * 這兩個指針都必須來自指向同一對象的指針。
    ///   (請參見下面的示例。)
    ///
    /// * 指針之間的距離 (以字節為單位) 必須是 `T` 大小的精確倍數。
    ///
    /// * 指針之間的距離 (以字節為單位 **) 不會溢出 `isize`。
    ///
    /// * 該距離不能依賴於 "wrapping around" 地址空間。
    ///
    /// Rust 類型從不大於 `isize::MAX`，並且 Rust 分配從不環繞地址空間，因此，任何 Rust 類型 `T` 的某個值內的兩個指針將始終滿足最後兩個條件。
    ///
    /// 標準庫通常還確保分配永遠不會達到需要考慮偏移量的大小。
    /// 例如，`Vec` 和 `Box` 確保它們分配的字節數永遠不超過 `isize::MAX` 字節，因此 `ptr_into_vec.offset_from(vec.as_ptr())` 始終滿足最後兩個條件。
    ///
    /// 從根本上說，大多數平台甚至都無法構建如此大的分配。
    /// 例如，由於頁表的限製或地址空間的分割，沒有已知的 64 位平台可以滿足 2 <sup>63</sup> 字節的請求。
    /// 但是，某些 32 位和 16 位平台可能通過物理地址擴展之類的東西成功地為超過 `isize::MAX` 字節的請求提供服務。
    /// 因此，直接從分配器獲取的內存或內存映射文件 *可能* 太大而無法使用此功能處理。
    /// (請注意，[`offset`] 和 [`add`] 也具有類似的限制，因此也不能在如此大的分配上使用。)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// 如果 `T` 是零尺寸類型 ("ZST")，則此功能 panics。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *不正確* 用法:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // 將 ptr2_other 設置為 ptr2 的 "alias"，但從 ptr1 派生。
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // 由於 ptr2_other 和 ptr2 是從指向不同對象的指針派生的，因此即使它們指向相同的地址，計算其偏移量也是未定義的行為!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // 未定義的行為
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // 安全: 调用者必須遵守 `ptr_offset_from` 的安全合同。
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// 返回兩個指針是否保證相等。
    ///
    /// 在運行時，此功能的行為類似於 `self == other`。
    /// 但是，在某些情況下 (例如，編譯時評估)，並非總是能夠確定兩個指針的相等性，因此此函數可能會虛假地返回 `false` 來表示後來實際上等於的指針。
    ///
    /// 但是，當它返回 `true` 時，保證指針是相等的。
    ///
    /// 此功能是 [`guaranteed_ne`] 的鏡像，但不是其反函數。有兩個函數都返回 `false` 的指針比較。
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// 返回值可能會有所不同，具體取決於編譯器版本，並且不安全的代碼可能不依賴於此函數的結果是否健全。
    /// 建議僅將此函數用於性能優化，在該性能優化中，此函數的偽 `false` 返回值不影響結果，而僅影響性能。
    /// 尚未探討使用此方法使運行時和編譯時代碼表現不同的後果。
    /// 不應使用這種方法來引入這種差異，並且在我們對這個問題有更好的理解之前，也不應使其穩定。
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// 返回兩個指針是否保證不相等。
    ///
    /// 在運行時，此功能的行為類似於 `self != other`。
    /// 但是，在某些情況下 (例如，編譯時評估)，並非總是能夠確定兩個指針的不相等性，因此此函數可能會虛假地返回 `false` 來表示後來實際上不相等的指針。
    ///
    /// 但是，當它返回 `true` 時，保證指針是不相等的。
    ///
    /// 此功能是 [`guaranteed_eq`] 的鏡像，但不是其反函數。有兩個函數都返回 `false` 的指針比較。
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// 返回值可能會有所不同，具體取決於編譯器版本，並且不安全的代碼可能不依賴於此函數的結果是否健全。
    /// 建議僅將此函數用於性能優化，在該性能優化中，此函數的偽 `false` 返回值不影響結果，而僅影響性能。
    /// 尚未探討使用此方法使運行時和編譯時代碼表現不同的後果。
    /// 不應使用這種方法來引入這種差異，並且在我們對這個問題有更好的理解之前，也不應使其穩定。
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// 計算與指針的偏移量 (`.offset(count as isize)`) 的便利)。
    ///
    /// `count` 以 T 為單位; 例如，`count` 為 3 表示 `3 * size_of::<T>()` 字節的指針偏移量。
    ///
    /// # Safety
    ///
    /// 如果違反以下任一條件，則結果為 `不確定行為`:
    ///
    /// * 起始指針和結果指針都必須在同一分配對象末尾的範圍之內或一個字節之內。
    /// 請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
    ///
    /// * 計算的偏移量 (以字節為單位 **) 不會使 `isize` 溢出。
    ///
    /// * 偏移量不能依賴 "wrapping around" 的地址空間。即，無限精度總和必須適合 `usize`。
    ///
    /// 編譯器和標準庫通常會嘗試確保分配永遠不會達到需要考慮偏移量的大小。
    /// 例如，`Vec` 和 `Box` 確保它們分配的字節數永遠不會超過 `isize::MAX` 字節，因此 `vec.as_ptr().add(vec.len())` 始終是安全的。
    ///
    /// 從根本上說，大多數平台甚至都無法構造這樣的分配。
    /// 例如，由於頁表的限製或地址空間的分割，沒有已知的 64 位平台可以滿足 2 <sup>63</sup> 字節的請求。
    /// 但是，某些 32 位和 16 位平台可能通過物理地址擴展之類的東西成功地為超過 `isize::MAX` 字節的請求提供服務。
    ///
    /// 因此，直接從分配器獲取的內存或內存映射文件 *可能* 太大而無法使用此功能處理。
    ///
    /// 如果這些約束難以滿足，請考慮使用 [`wrapping_add`]。
    /// 此方法的唯一優點是，它可以實現更積極的編譯器優化。
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `offset` 的安全合同。
        unsafe { self.offset(count as isize) }
    }

    /// 計算距指針的偏移量 (為 `.offset ( (計為 isize).wrapping_neg())`)。
    ///
    /// `count` 以 T 為單位; 例如，`count` 為 3 表示 `3 * size_of::<T>()` 字節的指針偏移量。
    ///
    /// # Safety
    ///
    /// 如果違反以下任一條件，則結果為 `不確定行為`:
    ///
    /// * 起始指針和結果指針都必須在同一分配對象末尾的範圍之內或一個字節之內。
    /// 請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
    ///
    /// * 計算的偏移量不能超過 `isize::MAX` 個 **字節**。
    ///
    /// * 偏移量不能依賴 "wrapping around" 地址空間。也就是說，無窮大的和必須適合 usize。
    ///
    /// 編譯器和標準庫通常會嘗試確保分配永遠不會達到需要考慮偏移量的大小。
    /// 例如，`Vec` 和 `Box` 確保它們分配的字節數永遠不會超過 `isize::MAX` 字節，因此 `vec.as_ptr().add(vec.len()).sub(vec.len())` 始終是安全的。
    ///
    /// 從根本上說，大多數平台甚至都無法構造這樣的分配。
    /// 例如，由於頁表的限製或地址空間的分割，沒有已知的 64 位平台可以滿足 2 <sup>63</sup> 字節的請求。
    /// 但是，某些 32 位和 16 位平台可能通過物理地址擴展之類的東西成功地為超過 `isize::MAX` 字節的請求提供服務。
    ///
    /// 因此，直接從分配器獲取的內存或內存映射文件 *可能* 太大而無法使用此功能處理。
    ///
    /// 如果這些約束難以滿足，請考慮使用 [`wrapping_sub`]。
    /// 此方法的唯一優點是，它可以實現更積極的編譯器優化。
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `offset` 的安全合同。
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// 使用換行算法計算與指針的偏移量。
    /// (為 `.wrapping_offset(count as isize)`) 帶來的便利
    ///
    /// `count` 以 T 為單位; 例如，`count` 為 3 表示 `3 * size_of::<T>()` 字節的指針偏移量。
    ///
    /// # Safety
    ///
    /// 此操作本身始終是安全的，但使用結果指針則不安全。
    ///
    /// 結果指針仍然附加到 `self` 指向的同一分配對象。
    /// 它可能 *不能* 用於訪問其他分配的對象。請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
    ///
    /// 換句話說，即使我們假設 `T` 的大小為 `1` 且沒有溢出，`let z = x.wrapping_add((y as usize) - (x as usize))` 也不會使 `z` 與 `y` 相同: `z` 仍附加到對象 `x` 所附加的對像上，並且取消引用它是未定義行為，除非 `x` 和 `y` 指向相同的分配對象。
    ///
    /// 與 [`add`] 相比，此方法從根本上延遲了留在同一分配對象內的要求: [`add`] 是跨越對象邊界時的立即未定義行為; `wrapping_add` 產生一個指針，但是如果指針超出其附加對象的範圍而被取消引用，則仍會導致未定義行為。
    /// [`add`] 可以更好地進行優化，因此在對性能敏感的代碼中更可取。
    ///
    /// 延遲檢查僅考慮取消引用的指針的值，而不考慮最終結果計算期間使用的中間值。
    /// 例如，`x.wrapping_add(o).wrapping_sub(o)` 始終與 `x` 相同。換句話說，允許離開分配的對象，然後在以後重新輸入它。
    ///
    /// 如果您需要越過對象邊界，請將指針轉換為整數，然後在該處進行算術運算。
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 使用原始指針以兩個元素為增量進行迭代
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // 此循環打印 "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// 使用換行算法計算與指針的偏移量。
    /// (為 `.wrapping_offset ( (計為 isize).wrapping_neg())`)
    ///
    /// `count` 以 T 為單位; 例如，`count` 為 3 表示 `3 * size_of::<T>()` 字節的指針偏移量。
    ///
    /// # Safety
    ///
    /// 此操作本身始終是安全的，但使用結果指針則不安全。
    ///
    /// 結果指針仍然附加到 `self` 指向的同一分配對象。
    /// 它可能 *不能* 用於訪問其他分配的對象。請注意，在 Rust 中，每個 (stack-allocated) 變量都被視為一個單獨的分配對象。
    ///
    /// 換句話說，即使我們假設 `T` 的大小為 `1` 且沒有溢出，`let z = x.wrapping_sub((x as usize) - (y as usize))` 也不會使 `z` 與 `y` 相同: `z` 仍附加到對象 `x` 所附加的對像上，並且取消引用它是未定義行為，除非 `x` 和 `y` 指向相同的分配對象。
    ///
    /// 與 [`sub`] 相比，此方法從根本上延遲了留在同一分配對象內的要求: [`sub`] 是跨越對象邊界時的立即未定義行為; `wrapping_sub` 產生一個指針，但是如果指針超出其附加對象的範圍而被取消引用，則仍會導致未定義行為。
    /// [`sub`] 可以更好地進行優化，因此在對性能敏感的代碼中更可取。
    ///
    /// 延遲檢查僅考慮取消引用的指針的值，而不考慮最終結果計算期間使用的中間值。
    /// 例如，`x.wrapping_add(o).wrapping_sub(o)` 始終與 `x` 相同。換句話說，允許離開分配的對象，然後在以後重新輸入它。
    ///
    /// 如果您需要越過對象邊界，請將指針轉換為整數，然後在該處進行算術運算。
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // 使用原始指針以兩個元素 (backwards) 為增量進行迭代
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // 此循環打印 "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// 將指針值設置為 `ptr`。
    ///
    /// 如果 `self` 是指向未確定大小類型的 (fat) 指針，則此操作將僅影響指針部分，而對於指向已確定大小類型的 (thin) 指針，其作用與簡單分配相同。
    ///
    /// 所得的指針將具有 `val` 的出處，即對於胖指針，此操作在語義上與使用 `val` 的數據指針值但 `self` 的元數據創建新的胖指針相同。
    ///
    ///
    /// # Examples
    ///
    /// 此函數主要用於允許對潛在的胖指針進行按字節指針算術運算:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // 將打印 "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // 安全: 對於細指針，此操作是相同的
        // 一個簡單的任務。
        // 對於胖指針，在當前胖指針佈局實現中，此類指針的第一個字段始終是數據指針，該指針同樣被分配。
        //
        unsafe { *thin = val };
        self
    }

    /// 從 `self` 讀取值而不移動它。
    /// 這將使 `self` 中的內存保持不變。
    ///
    /// 有關安全性問題和示例，請參見 [`ptr::read`]。
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `read` 的安全合同。
        unsafe { read(self) }
    }

    /// 對 `self` 值進行易失性讀取，而無需移動它。這使 `self` 中的內存保持不變。
    ///
    /// 易失性操作旨在作用於 I/O 存儲器，並保證編譯器不會在其他易失性操作中對易失性操作進行清除或重新排序。
    ///
    ///
    /// 有關安全性問題和示例，請參見 [`ptr::read_volatile`]。
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `read_volatile` 的安全合同。
        unsafe { read_volatile(self) }
    }

    /// 從 `self` 讀取值而不移動它。
    /// 這將使 `self` 中的內存保持不變。
    ///
    /// 與 `read` 不同，指針可能未對齊。
    ///
    /// 有關安全性問題和示例，請參見 [`ptr::read_unaligned`]。
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `read_unaligned` 的安全合同。
        unsafe { read_unaligned(self) }
    }

    /// 將 `count * size_of<T>` 字節從 `self` 複製到 `dest`。
    /// 源和目標可能會重疊。
    ///
    /// NOTE: 它的參數順序與 [`ptr::copy`] 相同。
    ///
    /// 有關安全性問題和示例，請參見 [`ptr::copy`]。
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `copy` 的安全合同。
        unsafe { copy(self, dest, count) }
    }

    /// 將 `count * size_of<T>` 字節從 `self` 複製到 `dest`。
    /// 源和目標可能 *不* 重疊。
    ///
    /// NOTE: 它的參數順序與 [`ptr::copy_nonoverlapping`] 相同。
    ///
    /// 有關安全性問題和示例，請參見 [`ptr::copy_nonoverlapping`]。
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // 安全: 调用者必須遵守 `copy_nonoverlapping` 的安全合同。
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// 計算為使其與 `align` 對齊而需要應用到指針的偏移量。
    ///
    /// 如果無法對齊指針，則實現將返回 `usize::MAX`。
    /// 允許實現 *始終* 返回 `usize::MAX`。
    /// 只有算法的性能可以取決於此處是否可獲得可用的偏移量，而不取決於其正確性。
    ///
    /// 偏移量以 `T` 元素的數量表示，而不是以字節表示。返回的值可以與 `wrapping_add` 方法一起使用。
    ///
    /// 不能保證偏移指針不會溢出或超出指針所指向的分配範圍。
    ///
    /// 調用者應確保返回的偏移量在對齊方式以外的所有方面都是正確的。
    ///
    /// # Panics
    ///
    /// 如果 `align` 不是 2 的冪，則函數 panics。
    ///
    /// # Examples
    ///
    /// 將相鄰的 `u8` 作為 `u16` 進行訪問
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // 雖然指針可以通過 `offset` 對齊，但它會指向分配之外
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // 安全: `align` 已被檢查為 2 以上的冪
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// 返回原始切片的長度。
    ///
    /// 返回的值是 **elements** 的數量，而不是字節數。
    ///
    /// 即使原始切片由於指針為空或未對齊而無法轉換為切片參考，此功能也是安全的。
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // 安全: 這是安全的，因為 `*const [T]` 和 `FatPtr<T>` 具有相同的佈局。
            // 只有 `std` 可以做出此保證。
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// 返回指向切片緩衝區的原始指針。
    ///
    /// 這等效於將 `self` 強制轉換為 `*const T`，但類型安全性更高。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// 返回指向元素或子切片的原始指針，而不進行邊界檢查。
    ///
    /// 即使沒有使用結果指針，使用越界索引或在 `self` 不可引用時調用此方法也是 *[undefined behavior]*。
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // 安全: 調用者確保 `self` 是可取消引用的，並且 `index` 是入站的。
        unsafe { index.get_unchecked(self) }
    }

    /// 如果指針為空，則返回 `None`; 否則，將共享切片返回到包裝在 `Some` 中的值。
    /// 與 [`as_ref`] 相比，這不需要將該值初始化。
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// 調用此方法時，必須確保指針要么為 NULL，要么所有以下條件為真:
    ///
    /// * 指針必須為 [valid]，才能讀取許多字節的 `ptr.len() * mem::size_of::<T>()`，並且必須正確對齊。這尤其意味著:
    ///
    ///     * 此片的整個內存範圍必須包含在一個分配的對像中!
    ///       切片永遠不能跨越多個分配的對象。
    ///
    ///     * 即使對於零長度的切片，指針也必須對齊。
    ///     這樣做的一個原因是，枚舉佈局優化可能依賴於對齊的引用 (包括任何長度的切片) 並且不為空，以將其與其他數據區分開。
    ///
    ///     您可以使用 [`NonNull::dangling()`] 獲得可用作零長度切片的 `data` 的指針。
    ///
    /// * 切片的總大小 `ptr.len() * mem::size_of::<T>()` 必須不大於 `isize::MAX`。
    ///   請參閱 [`pointer::offset`] 的安全文檔。
    ///
    /// * 您必須執行 Rust 的別名規則，因為返回的生存期 `'a` 是任意選擇的，不一定反映數據的實際生存期。
    ///   特別是，在此生命週期內，指針所指向的內存一定不能發生突變 (`UnsafeCell` 內部除外)。
    ///
    /// 即使未使用此方法的結果也是如此!
    ///
    /// 另請參見 [`slice::from_raw_parts`][]。
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // 安全: 调用者必須遵守 `as_uninit_slice` 的安全合同。
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// 指針相等
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// 指針比較
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}