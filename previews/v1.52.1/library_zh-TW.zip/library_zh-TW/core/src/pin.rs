//! 鍵入將數據固定到其在內存中的位置的類型。
//!
//! 從對像在內存中的位置不變的意義上講，保證對像不移動有時很有用。
//! 這種情況的一個主要示例是構建自引用結構，因為移動帶有指向自身的指針的對象會使它們無效，這可能導致未定義的行為。
//!
//! 在較高的層次上，[`Pin<P>`] 確保任何指針類型 `P` 的指針都在內存中具有穩定的位置，這意味著它不能被移動到其他地方，並且直到被刪除之前，它的內存都不能被釋放。我們說該對像是 "pinned"。當討論將固定數據與非固定數據結合在一起的類型時，事情變得更加微妙。[see below](#projections-and-structural-pinning) 了解更多詳細信息。
//!
//! 默認情況下，Rust 中的所有類型都是可移動的。
//! Rust 允許按值傳遞所有類型，而普通的智能指針類型 (如 [`Box<T>`] 和 `&mut T`) 允許替換和移動它們包含的值: 您可以移出 [`Box<T>`]，也可以使用 [`mem::swap`]。
//! [`Pin<P>`] 包裝一個指針類型 `P`，因此 [`Pin`]`<`[`Box`]`<T>>` 功能很像常規
//!
//! [`Box<T>`]: when 一個 [`Pin`]`<`[`Box`]`<T>>` 被刪除，其內容也被刪除，內存被刪除
//!
//! 釋放。同樣，[`Pin`]`<＆mut T>` 很像 `&mut T`。但是，[`Pin<P>`] 不允許客戶端實際獲得 [`Box<T>`] 或 `&mut T` 來固定數據，這意味著您不能使用 [`mem::swap`] 之類的操作:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` 需要 `&mut T`，但我們無法獲取它。
//!     // 我們被困住了，我們不能交換這些引用的內容。
//!     // 我們可以使用 `Pin::get_unchecked_mut`，但這是不安全的，原因如下:
//!     // 我們不允許將其用於將物品移出 `Pin`。
//! }
//! ```
//!
//! 值得重申的是，[`Pin<P>`] 不會 *不會改變 Rust 編譯器認為所有類型都是可移動的這一事實。[`mem::swap`] 仍然可用於任何 `T`。相反，[`Pin<P>`] 使無法調用需要 `&mut T` 的方法 (例如 [`mem::swap`]) 來防止某些* 值 * (由 [`Pin<P>`] 中包裝的指針指向) 移動。
//!
//! [`Pin<P>`] 可用於包裝任何指針類型 `P`，並因此與 [`Deref`] 和 [`DerefMut`] 交互。[`Pin<P>`]，其中 `P: Deref` 應該被視為固定 `P::Target` 的 "`P`-style pointer"，因此 [`Pin`]`<`[`Box`]`<T>>` 是指向固定 `T` 和 [[Pin`]`<`[`Rc`]` 的專有指針。<T>>` 是指向固定 `T` 的引用計數指針。
//! 為了正確起見，[`Pin<P>`] 依賴 [`Deref`] 和 [`DerefMut`] 的實現不移出其 `self` 參數，並且僅當在固定指針上調用它們時才返回指向固定數據的指針。
//!
//! # `Unpin`
//!
//! 即使不固定，許多類型也始終可以自由移動，因為它們不依賴於具有穩定的地址。這包括所有基本類型 (如 [`bool`]，[`i32`] 和引用) 以及僅由這些類型組成的類型。不需要固定的類型將實現 [`Unpin`] auto-trait，從而取消 [`Pin<P>`] 的作用。
//! 對於 `T: Unpin`，[`Pin`]`<`[`Box`]`<T>>` 和 [`Box<T>`] 的功能相同，[[Pin`]`<＆mut T>` 和 `&mut T` 的功能也相同。
//!
//! 請注意，固定和 [`Unpin`] 僅影響指向類型 `P::Target`，而不影響包裹在 [`Pin<P>`] 中的指針類型 `P` 本身。例如，[`Box<T>`] 是否為 [`Unpin`] 對 [`Pin`]`<`[`Box`] 的行為沒有影響。<T>>` (這裡 `T` 是指向類型)。
//!
//! # 示例: 自引用結構
//!
//! 在我們進一步解釋 `Pin<T>` 相關的保證和選擇之前，我們先討論一些如何使用 `Pin<T>` 的示例。
//! 隨時使用 [skip to where the theoretical discussion continues](#drop-guarantee)。
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // 這是一個自引用結構，因為切片字段指向數據字段。
//! // 我們無法使用正常參考來告知編譯器，因為無法使用通常的借用規則來描述此模式。
//! //
//! // 取而代之的是，我們使用一個原始指針，儘管我們知道原始指針指向的是一個不為 null 的指針。
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // 為了確保函數返回時數據不會移動，我們將其放置在堆中，直到對象的生命週期為止，並且訪問它的唯一方法是通過指向它的指針。
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // 我們僅在數據到位後創建指針，否則數據將在我們開始之前就已經移動
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // 我們知道這是安全的，因為修改字段不會移動整個結構
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // 只要該結構沒有移動，指針就應指向正確的位置。
//! //
//! // 同時，我們可以隨意移動指針。
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // 由於我們的類型未實現 Unpin，因此無法編譯:
//! // 讓 mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # 示例: 侵入式雙鍊錶
//!
//! 在侵入式雙向鏈接列表中，集合實際上並未為元素本身分配內存。
//! 分配由客戶端控制，元素可以駐留在比集合短的堆棧框架上。
//!
//! 為了使此工作有效，列表中的每個元素都有指向其前任和後任的指針。元素只能在固定時添加，因為四處移動元素會使指針無效。而且，鍊錶元素的 [`Drop`] 實現將修補其前任和後繼的指針，以將其從列表中刪除。
//!
//! 至關重要的是，我們必須能夠依靠被調用的 [`drop`]。如果可以在不調用 [`drop`] 的情況下取消分配元素或使元素無效，則從其相鄰元素指向該元素的指針將變為無效，這將破壞數據結構。
//!
//! 因此，固定還會附帶 [drop] 相關的保證。
//!
//! # `Drop` guarantee
//!
//! 固定的目的是能夠依靠某些數據在內存中的放置。
//! 為了使這項工作有效，不僅限制了移動數據; 限制用於存儲數據的內存的重新分配，重新分配用途或以其他方式使之無效。
//! 具體來說，對於固定數據，您必須保持不變，即從固定到調用 [`drop`] 時，其內存都不會失效或被重新利用。只有 [`drop`] 返回或 panics，才可以重用該內存。
//!
//! 內存可以通過釋放來成為 "invalidated"，也可以通過用 [`None`] 替換 [`Some(v)`] 或將 [`Vec::set_len`] 調用到 "kill" 來實現 vector 的某些元素。可以通過使用 [`ptr::write`] 覆蓋它來重新利用它，而無需先調用析構函數。在不調用 [`drop`] 的情況下，不允許對固定數據進行任何此操作。
//!
//! 這正是上一節中的侵入式鏈接列表需要正確運行的保證。
//!
//! 請注意，此保證不 `*`* 表示內存不會洩漏! 永遠不要在固定元素上調用 [`drop`] (例如，您仍然可以在 [`Pin`]`<`[`Box`] 上調用 [`mem::forget`]) <T>>`)。在雙向鏈接列表的示例中，該元素將僅保留在列表中。但是，如果不調用 [`drop`]*，您可能無法釋放或重複使用存儲。
//!
//! # `Drop` implementation
//!
//! 如果您的類型使用固定 (例如上面的兩個示例)，則在實現 [`Drop`] 時必須小心。[`drop`] 函數採用 `&mut self`，但這被稱為 *即使您的類型先前已固定*! 好像編譯器自動調用了 [`Pin::get_unchecked_mut`]。
//!
//! 這永遠不會在安全代碼中引起問題，因為實現依賴於固定的類型需要不安全的代碼，但是請注意，決定在您的類型中使用固定 (例如，通過對 [`Pin`]`<＆Self 進行一些操作) >` 或 [`Pin`]`<＆mut Self>`) 也會對 [`Drop`] 實現產生影響: 如果可以固定您類型的元素，則必須將 [`Drop`] 視為隱式地使用 [`Pin`]`<＆mut 自我>。
//!
//!
//! 例如，您可以按以下方式實現 `Drop`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` 可以，因為我們知道此值在刪除後再也不會使用了。
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // 實際的放置代碼在此處。
//!         }
//!     }
//! }
//! ```
//!
//! 函數 `inner_drop` 具有 *應該* 具有 [`drop`] 的類型，因此可以確保您不會以與固定衝突的方式意外使用 `self`/`this`。
//!
//! 此外，如果您的類型是 `#[repr(packed)]`，則編譯器將自動移動字段以將其刪除。它甚至可以對恰好足夠對齊的字段執行此操作。因此，您不能使用 `#[repr(packed)]` 類型的固定。
//!
//! # 投影和結構固定
//!
//! 當使用固定結構時，就會出現一個問題，即如何可以僅採用 [`Pin`]`<＆mut Struct>` 的方法訪問該結構的字段。
//! 通常的方法是編寫將 [[Pin`]`<＆mut Struct>`轉換為對該字段的引用的輔助方法 (所謂的 *projections*)，但是該引用應具有哪種類型? 是 [`Pin`]`<＆mut Field>` 還是 `&mut Field`?
//! 對於 `enum` 的字段，以及在考慮 container/wrapper 類型 (例如 [`Vec<T>`]，[`Box<T>`] 或 [`RefCell<T>`]) 時，也會出現相同的問題。
//! (此問題適用於可變引用和共享引用，我們僅在此處使用可變引用的更常見情況進行說明。)
//!
//! 事實證明，實際上是由數據結構的作者來決定特定字段的固定投影是將 [`Pin`]`<＆mut Struct> 變成 [`Pin`]`<＆mut Field> 還是 `&mut Field`。儘管有一些約束，但是最重要的約束是 *consistency*:
//! 每個字段都可以 *或者* 投影到固定參考，或者 * 可以刪除固定作為投影的一部分。
//! 如果兩者都在同一個領域完成，那將是不正確的!
//!
//! 作為數據結構的作者，您需要為每個字段決定是否將 "propagates" 固定到該字段。
//! 傳播的固定也稱為 "structural"，因為它遵循該類型的結構。
//! 在以下小節中，我們描述了兩種選擇都必須考慮的因素。
//!
//! ## `field` 的固定 *不是* 結構
//!
//! 固定的結構的字段可能沒有固定，這似乎是違反直覺的，但這實際上是最簡單的選擇: 如果從不創建 [`Pin`]`<＆mut Field>`，則不會出錯! 因此，如果您確定某個字段沒有結構固定，則只需確保您從未創建對該字段的固定引用即可。
//!
//! 沒有結構固定的字段可能具有一種將 [`Pin`]`<＆mut Struct>` 轉換為 `&mut Field` 的投影方法:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // 可以，因為 `field` 從未被視為固定。
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! 即使 `field` 的類型不是 [`Unpin`]，您也可以 `impl Unpin for Struct`。當沒有創建 [`Pin`]`<＆mut Field>` 時，該類型所考慮的固定無關緊要。
//!
//! ## `field` 的固定 *是* 結構
//!
//! 另一個選擇是確定釘住 `field` 還是 `field`，這意味著如果釘住結構，則字段也釘住。
//!
//! 這允許編寫一個創建 [`Pin`]`<＆mut Field>` 的投影，從而見證該字段已固定:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // 可以，因為 `self` 固定在 `field` 上。
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! 但是，結構固定需要一些額外的要求:
//!
//! 1. 如果所有結構字段均為 [`Unpin`]，則該結構只能為 [`Unpin`]。這是默認設置，但是 [`Unpin`] 是安全的 trait，因此，作為結構的作者，您不負責添加 `impl<T> Unpin for Struct<T>` 這樣的內容。
//! (請注意，添加投影操作需要不安全的代碼，因此 [`Unpin`] 是安全的 trait 的事實並沒有違反以下原則: 僅當使用 `unsafe` 時，您才需要擔心其中的任何一個。)
//! 2. 結構的析構函數不得將結構域移出其參數。這是在 [previous section][drop-impl] 中提出的確切點: `drop` 採用 `&mut self`，但是該結構 (及其字段) 可能之前已被固定。
//!     您必須保證不要在 [`Drop`] 實現中移動字段。
//!     特別是，如前所述，這意味著您的結構 *不能* 為 `#[repr(packed)]`。
//!     有關如何編寫 [`drop`] 的方法，請參見該部分，以使編譯器可以幫助您避免意外破壞固定。
//! 3. 您必須確保您堅持使用 [`Drop` guarantee][drop-guarantee]:
//!     一旦將結構固定，包含內容的內存就不會被覆蓋或釋放，而無需調用內容的析構函數。
//!     如 [`VecDeque<T>`] 所示，這可能很棘手: 如果析構函數 panics 之一，則 [`VecDeque<T>`] 的析構函數可能無法在所有元素上調用 [`drop`]。這違反了 [`Drop`] 保證，因為它可能導致元素被釋放而沒有調用其析構函數。([`VecDeque<T>`] 沒有固定突起，因此不會引起不穩健。)
//! 4. 固定類型時，不得提供可能導致數據移出結構字段的任何其他操作。例如，如果結構包含 [`Option<T>`]，並且具有類似 `fn(Pin<&mut Struct<T>>) -> Option<T>` 的 `take` 操作，則該操作可用於將 `T` 從固定的 `Struct<T>` 中移出 - 這意味著固定該字段的結構不能固定數據。
//!
//!     對於將數據移出固定類型的更複雜的示例，請想像 [`RefCell<T>`] 是否具有方法 `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`。
//!     然後，我們可以執行以下操作:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     這是災難性的，這意味著我們可以先固定 [`RefCell<T>`] 的內容 (使用 `RefCell::get_pin_mut`)，然後使用稍後獲得的可變引用移動該內容。
//!
//! ## Examples
//!
//! 對於 [`Vec<T>`] 這樣的類型，兩種可能性 (無論是否為結構固定) 都是有意義的。
//! 具有結構固定的 [`Vec<T>`] 可以具有 `get_pin`/`get_pin_mut` 方法來獲取對元素的固定引用。但是，它可能 *不允許* 在固定的 [`Vec<T>`] 上調用 [`pop`][Vec::pop]，因為那樣會移動 (結構上固定的) 內容! 它也不允許 [`push`][Vec::push]，它可能會重新分配並因此也移動內容。
//!
//! 沒有結構固定的 [`Vec<T>`] 可能是 `impl<T> Unpin for Vec<T>`，因為內容永遠不會固定，並且 [`Vec<T>`] 本身也可以移動。
//! 那時，固定對 vector 完全沒有影響。
//!
//! 在標準庫中，指針類型通常不具有結構固定，因此它們不提供固定投影。這就是 `Box<T>: Unpin` 適用於所有 `T` 的原因。
//! 對於指針類型，這樣做是有意義的，因為移動 `Box<T>` 實際上並不移動 `T`: 即使 `T` 不能移動，[`Box<T>`] 也可以自由移動 (也稱為 `Unpin`)。實際上，即使 [`Pin`]`<`[`Box`]`<T> 出於相同的原因，>` 和 [`Pin`]`<＆mut T>` 本身始終是 [`Unpin`]: 它們的內容 (`T`) 是固定的，但是指針本身可以移動而無需移動固定的數據。
//! 對於 [`Box<T>`] 和 [`Pin`]`<`[`Box`]`<T>>`，是否固定內容完全與指針是否固定無關，這意味著固定是 `非` 結構性的。
//!
//! 實現 [`Future`] 組合器時，通常需要對嵌套 futures 進行結構固定，因為需要獲取對其的固定引用以調用 [`poll`]。
//! 但是，如果您的組合器包含任何其他不需要固定的數據，則可以使這些字段不具有結構性，因此即使您只具有 [`Pin`]`<＆mut Self> (例如，就像在您自己的 [`poll`] 實現中一樣)。
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// 固定的指針。
///
/// 這是一種指針的包裝，該指針使該指針 "pin" 的值就位，除非該指針實現 [`Unpin`]，否則防止該指針引用的值被移動。
///
///
/// *有關固定的說明，請參見 [`pin` module] 文檔。*
///
/// [`pin` module]: self
///
// Note: 下面的 `Clone` 派生導致不健全，因為有可能實現
// `Clone` 以獲得可變的參考。
// 有關更多詳細信息，請參見 <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>。
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// 為了避免出現健全性問題，沒有實現以下實現。
// `&self.pointer` 不受信任的 trait 實現不應訪問。
//
// 有關更多詳細信息，請參見 <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>。
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// 圍繞一個指向實現 [`Unpin`] 類型的數據的指針，構造一個新的 `Pin<P>`。
    ///
    /// 與 `Pin::new_unchecked` 不同，此方法是安全的，因為指針 `P` 取消引用了 [`Unpin`] 類型，從而取消了固定保證。
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // 安全: 指向的值為 `Unpin`，因此沒有要求
        // 圍繞固定。
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// 解包此 `Pin<P>`，返回基礎指針。
    ///
    /// 這要求該 `Pin` 內部的數據為 [`Unpin`]，以便我們在展開包裝時可以忽略固定不變式。
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// 圍繞對可能實現或未實現 `Unpin` 的某些類型的數據的引用構造一個新的 `Pin<P>`。
    ///
    /// 如果 `pointer` 取消引用 `Unpin` 類型，則應改用 `Pin::new`。
    ///
    /// # Safety
    ///
    /// 此構造函數是不安全的，因為我們不能保證 `pointer` 指向的數據是固定的，這意味著在刪除數據之前，數據將不會移動或存儲空間無效。
    /// 如果構造的 `Pin<P>` 不能保證數據 `P` 指向固定的，則違反了 API 約定，並可能在以後的 (safe) 操作中導致未定義的行為。
    ///
    /// 通過使用此方法，您正在製作有關 `P::Deref` 和 `P::DerefMut` 實現的 promise (如果存在)。
    /// 最重要的是，它們一定不能移出 `self` 參數: `Pin::as_mut` 和 `Pin::as_ref` 將在固定指針上調用 `DerefMut::deref_mut` 和 `Deref::deref`，並期望這些方法支持固定不變性。
    /// 此外，通過調用此方法，引用 `P` 取消引用的 promise 不會再次移出; 否則，不會再移出該引用。特別是，必須不可能獲得 `&mut P::Target`，然後再移出該引用 (例如，使用 [`mem::swap`])。
    ///
    ///
    /// 例如，在 `&'a mut T` 上調用 `Pin::new_unchecked` 是不安全的，因為雖然可以在給定的生命週期 `'a` 內固定 `Pin::new_unchecked`，但是您無法控制 `'a` 結束後是否保持固定狀態:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // 這應該意味著指針 `a` 再也無法移動了。
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a` 的地址更改為 `b` 的堆棧插槽，因此即使我們先前已將其固定，`a` 還是被移動了! 我們違反了固定 API 合同。
    /////
    /// }
    /// ```
    ///
    /// 固定後的值必須永遠固定 (除非其類型實現 `Unpin`)。
    ///
    /// 同樣，在 `Rc<T>` 上調用 `Pin::new_unchecked` 是不安全的，因為相同數據的別名可能不受固定限制的限制:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // 這應該意味著指向者永遠不能再移動。
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // 現在，如果 `x` 是唯一的引用，我們將對上面固定的數據有一個可變的引用，就像在上一個示例中看到的那樣，我們可以使用它來移動它。
    ///     // 我們違反了固定 API 合同。
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// 從此固定指針獲取固定共享引用。
    ///
    /// 這是從 `&Pin<Pointer<T>>` 到 `Pin<&T>` 的通用方法。
    /// 這是安全的，因為作為 `Pin::new_unchecked` 合同的一部分，在創建 `Pin<Pointer<T>>` 之後，指針無法移動。
    ///
    /// "Malicious" `Pointer::Deref` 的實現同樣被 `Pin::new_unchecked` 的合同所排除。
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // 安全性: 請參閱有關此功能的文檔
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// 解包此 `Pin<P>`，返回基礎指針。
    ///
    /// # Safety
    ///
    /// 此功能不安全。您必須保證調用此函數後，將繼續將指針 `P` 視為固定指針，以便可以保留 `Pin` 類型的不變量。
    /// 如果使用生成的 `P` 的代碼不能繼續維護違反 API 約定的固定不變式，則可能會在以後的 (safe) 操作中導致未定義的行為。
    ///
    ///
    /// 如果基礎數據是 [`Unpin`]，則應改用 [`Pin::into_inner`]。
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// 從此固定指針獲取固定可變參考。
    ///
    /// 這是從 `&mut Pin<Pointer<T>>` 到 `Pin<&mut T>` 的通用方法。
    /// 這是安全的，因為作為 `Pin::new_unchecked` 合同的一部分，在創建 `Pin<Pointer<T>>` 之後，指針無法移動。
    ///
    /// "Malicious" `Pointer::DerefMut` 的實現同樣被 `Pin::new_unchecked` 的合同所排除。
    ///
    /// 當多次調用使用固定類型的函數時，此方法很有用。
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // 做一點事
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` 消耗 `self`，因此通過 `as_mut` 重新借用 `Pin<&mut Self>`。
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // 安全性: 請參閱有關此功能的文檔
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// 為固定參考後面的存儲器分配一個新值。
    ///
    /// 這會覆蓋固定的數據，但是沒關係: 它的析構函數在被覆蓋之前就已運行，因此不會違反固定保證。
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// 通過映射內部值構造一個新的引腳。
    ///
    /// 例如，如果要獲取某字段的 `Pin`，則可以使用它在一行代碼中訪問該字段。
    /// 但是，這些 "pinning projections" 有一些陷阱。
    /// 有關該主題的更多詳細信息，請參見 [`pin` module] 文檔。
    ///
    /// # Safety
    ///
    /// 此功能不安全。
    /// 您必須保證只要參數值不移動，返回的數據就不會移動 (例如，因為它是該值的字段之一)，並且還必須確保不會從接收到的參數中移出內部功能。
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // 安全: `new_unchecked` 的安全合同必須
        // 被调用者堅持。
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// 從引腳獲取共享參考。
    ///
    /// 這是安全的，因為不可能移出共享參考。
    /// 內部可變性似乎存在問題: 實際上，可以將 `T` 從 `&RefCell<T>` 中移出。
    /// 但是，只要不存在指向相同數據的 `Pin<&T>`，並且 `RefCell<T>` 不允許您創建對其內容的固定引用，這也不成問題。
    ///
    /// 有關更多詳細信息，請參見 ["pinning projections"] 上的討論。
    ///
    /// Note: `Pin` 還對目標實現 `Deref`，可用於訪問內部值。
    /// 但是，`Deref` 僅提供一個可以使用到 `Pin` 的引用，而不能提供 `Pin` 本身的使用壽命。
    /// 這種方法可以將 `Pin` 轉換為與原始 `Pin` 相同壽命的參考。
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// 將此 `Pin<&mut T>` 轉換為具有相同壽命的 `Pin<&T>`。
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// 獲取對此 `Pin` 內部數據的可變引用。
    ///
    /// 這要求該 `Pin` 內部的數據為 `Unpin`。
    ///
    /// Note: `Pin` 還對數據實現 `DerefMut`，可用於訪問內部值。
    /// 但是，`DerefMut` 僅提供一個可以使用到 `Pin` 的引用，而不能提供 `Pin` 本身的使用壽命。
    ///
    /// 這種方法可以將 `Pin` 轉換為與原始 `Pin` 相同壽命的參考。
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// 獲取對此 `Pin` 內部數據的可變引用。
    ///
    /// # Safety
    ///
    /// 此功能不安全。
    /// 您必須保證在調用此函數時，永遠不會將數據移出接收到的可變引用，以便可以保留 `Pin` 類型的不變量。
    ///
    ///
    /// 如果基礎數據是 `Unpin`，則應改用 `Pin::get_mut`。
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// 通過映射內部值構造一個新的引腳。
    ///
    /// 例如，如果要獲取某字段的 `Pin`，則可以使用它在一行代碼中訪問該字段。
    /// 但是，這些 "pinning projections" 有一些陷阱。
    /// 有關該主題的更多詳細信息，請參見 [`pin` module] 文檔。
    ///
    /// # Safety
    ///
    /// 此功能不安全。
    /// 您必須保證只要參數值不移動，返回的數據就不會移動 (例如，因為它是該值的字段之一)，並且還必須確保不會從接收到的參數中移出內部功能。
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // 安全: 來電者有責任不移動電話。
        // 從此參考中獲得價值。
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // 安全: 由於保證 `this` 的值不具有
        // 被移出後，對 `new_unchecked` 的此調用是安全的。
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// 從靜態參考中獲取固定參考。
    ///
    /// 這是安全的，因為在 `'static` 的生命週期中一直借用 `T`，該生命週期永遠不會結束。
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // 安全: ` 靜態借用保證數據不會被刪除
        // moved/invalidated 直到它被丟棄 (從來沒有)。
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// 從靜態可變引用獲取固定的可變引用。
    ///
    /// 這是安全的，因為在 `'static` 的生命週期中一直借用 `T`，該生命週期永遠不會結束。
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // 安全: ` 靜態借用保證數據不會被刪除
        // moved/invalidated 直到它被丟棄 (從來沒有)。
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: 這意味著 `CoerceUnsized` 的任何隱式允許
// 表示 `Deref<Target=impl !Unpin>` 的類型不正確。
// 但是，由於其他原因，任何這樣的提示可能都不合理，因此我們只需要注意不要讓這樣的提示降落在 std 中。
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}