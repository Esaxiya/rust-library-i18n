//! 不能 `隱式複制` 的類型的 `Clone` trait。
//!
//! 在 Rust 中，一些簡單類型是 "implicitly copyable"，當您分配它們或將它們作為參數傳遞時，接收者將獲得一個副本，並將原始值保留在原位。
//! 這些類型不需要分配就可以復制並且沒有終結器 (即，它們不包含擁有的框或實現 [`Drop`])，因此編譯器認為它們便宜且安全地進行複制。
//!
//! 對於其他類型，必須通過實現 [`Clone`] trait 並調用 [`clone`] 方法的方式顯式地進行複制。
//!
//! [`clone`]: Clone::clone
//!
//! 基本用法示例:
//!
//! ```
//! let s = String::new(); // 字符串類型實現克隆
//! let copy = s.clone(); // 所以我們可以克隆它
//! ```
//!
//! 要輕鬆實現 Clone trait，還可以使用 `#[derive(Clone)]`。例子:
//!
//! ```
//! #[derive(Clone)] // 我們將克隆 trait 添加到 Morpheus 結構中
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // 現在我們可以克隆它了!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// 常見的 trait，用於顯式複制對象。
///
/// 與 [`Copy`] 的不同之處在於，[`Copy`] 是隱式的並且非常便宜，而 `Clone` 始終是顯式的，可能昂貴也可能不昂貴。
/// 為了強制執行這些特性，Rust 不允許您重新實現 [`Copy`]，但是您可以重新實現 `Clone` 並運行任意代碼。
///
/// 由於 `Clone` 比 [`Copy`] 更通用，因此您可以自動將 [`Copy`] 設為 `Clone`。
///
/// ## Derivable
///
/// 如果所有字段均為 `Clone`，則此 trait 可以與 `#[derive]` 一起使用。[`Clone`] 的 `derive`d 實現在每個字段上調用 [`clone`]。
///
/// [`clone`]: Clone::clone
///
/// 對於通用結構，`#[derive]` 通過在通用參數上添加綁定的 `Clone` 有條件地實現 `Clone`。
///
/// ```
/// // `derive` 實現讀取克隆 <T> 當 T 為 Clone 時。
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## 如何實現 `Clone`?
///
/// [`Copy`] 類型應該實現 `Clone` 的簡單實現。更正式地:
/// 如果 `T: Copy`，`x: T` 和 `y: &T`，則 `let x = y.clone();` 等效於 `let x = *y;`。
/// 手動執行時應小心保持不變。但是，不安全的代碼一定不能依靠它來確保內存安全。
///
/// 一個示例是包含函數指針的通用結構。在這種情況下，不能對 `Clone` 的實現進行 `派生` 操作，而可以將其實現為:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## 其他實施者
///
/// 除 [implementors listed below][impls] 之外，以下類型還實現 `Clone`:
///
/// * 功能項目類型 (即，為每個功能定義的不同類型)
/// * 函數指針類型 (例如， `fn() -> i32`)
/// * 如果項目類型也實現 `Clone` (例如 `[i32; 123456]`)，則所有大小的數組類型
/// * 如果每個組件還實現 `Clone` (例如 `()`，`(i32, bool)`)，則為元組類型
/// * 閉包類型，如果它們沒有從環境中捕獲任何值，或者所有此類捕獲的值本身都實現了 `Clone`。
///   請注意，共享引用捕獲的變量始終實現 `Clone` (即使引用對像沒有實現)，而可變引用捕獲的變量則永遠不會實現 `Clone`。
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// 返回值的副本。
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str 實現克隆
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// 從 `source` 執行複制分配。
    ///
    /// `a.clone_from(&b)` 在功能上等效於 `a = b.clone()`，但是可以重寫以重用 `a` 的資源，以避免不必要的分配。
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// 派生宏，生成 trait `Clone` 的印象。
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): 這些結構僅由#[derive] 用來斷言類型的每個組件都實現 Clone 或 Copy。
//
//
// 這些結構永遠都不會出現在用戶代碼中。
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone` 的基本類型的實現。
///
/// X0X 中的 `traits::SelectionContext::copy_clone_conditions()` 中實現了 Rust 中無法描述的實現。
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// 可以克隆共享的引用，但是可變引用 *不能*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// 可以克隆共享的引用，但是可變引用 *不能*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}