#![stable(feature = "core_hint", since = "1.27.0")]

//! 對編譯器的提示，該提示會影響應如何發出或優化代碼。
//! 提示可能是編譯時或運行時。

use crate::intrinsics;

/// 通知編譯器代碼中的這一點不可訪問，從而可以進行進一步的優化。
///
/// # Safety
///
/// 達到此功能是完全 *未定義的行為*(UB)。特別是，編譯器假定所有 UB 都絕不會發生，因此將消除到達 `unreachable_unchecked()` 調用的所有分支。
///
/// 與 UB 的所有實例一樣，如果這種假設被證明是錯誤的，即 `unreachable_unchecked()` 調用實際上在所有可能的控制流中都是可到達的，則編譯器將應用錯誤的優化策略，有時甚至可能破壞看似無關的代碼，從而導致難以解決的問題 - 調試問題。
///
///
/// 僅在可以證明代碼永遠不會調用它時，才使用此函數。
/// 否則，請考慮使用 [`unreachable!`] 宏，該宏不允許進行優化，但是在執行時將為 panic。
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` 始終為正 (不為零)，因此 `checked_div` 將永遠不會返回 `None`。
/////
///     // 因此，else branch 是不可訪問的。
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // 安全: `intrinsics::unreachable` 的安全合同必須
    // 被调用者堅持。
    unsafe { intrinsics::unreachable() }
}

/// 發出一條機器指令，以向處理器發送信號，指示其正在忙於等待的自旋循環 (`自旋鎖定`) 中運行。
///
/// 在接收到自旋環信號後，處理器可以通過例如節省功率或切換 hyper 線程來優化其行為。
///
/// 此功能不同於 [`thread::yield_now`]，後者直接產生系統的調度程序，而 `spin_loop` 不與操作系統交互。
///
/// `spin_loop` 的一個常見用例是在同步原語的 CAS 循環中實現有界樂觀旋轉。
/// 為避免優先級倒置之類的問題，強烈建議在有限次數的迭代後終止旋轉循環，並進行適當的阻塞系統調用。
///
///
/// **注意**: 在不支持接收自旋循環提示的平台上，此功能根本不執行任何操作。
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // 線程將用於協調的共享原子值
/// let live = Arc::new(AtomicBool::new(false));
///
/// // 在後台線程中，我們最終將設置該值
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // 做一些工作，然後創造價值
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // 回到我們當前的線程，我們等待該值被設置
/// while !live.load(Ordering::Acquire) {
///     // 自旋循環是對我們正在等待的 CPU 的提示，但可能不會持續很長時間
/////
///     hint::spin_loop();
/// }
///
/// // 現在設置該值
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // 安全: `cfg` 屬性確保我們僅在 x86 目標上執行此操作。
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // 安全: `cfg` 屬性確保我們僅在 x86_64 目標上執行此操作。
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // 安全: `cfg` 屬性確保我們僅在 aarch64 目標上執行此操作。
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // 安全: `cfg` 屬性確保我們僅在手臂目標上執行此操作
            // 支持 v6 功能。
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// *__提示__* 到編譯器的身份函數，對於 `black_box` 可以做什麼最大程度地悲觀。
///
/// 與 [`std::convert::identity`] 不同，鼓勵 Rust 編譯器假定 `black_box` 可以以允許 Rust 代碼使用的任何可能有效方式使用 `dummy`，而不會在調用代碼中引入未定義的行為。
///
/// 此屬性使 `black_box` 可用於編寫不需要進行某些優化 (例如基準測試) 的代碼。
///
/// 但是請注意，`black_box` 僅 (並且只能) 以 "best-effort" 為基礎提供。它可以阻止優化的程度可能會有所不同，具體取決於所使用的平台和代碼源後端。
/// 程序不能以任何方式依靠 `black_box` 的 `正確性`。
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // 我們需要以某種方式使 XVM 成為 LLVM 無法自省的參數，並且在支持它的目標上，我們通常可以利用內聯彙編來執行此操作。
    // LLVM 對內聯彙編的解釋是，它是一個黑匣子。
    // 這不是最好的實現，因為它可能對優化進行的優化超出了我們的期望，但到目前為止已經足夠好了。
    //
    //

    #[cfg(not(miri))] // 這只是一個提示，因此可以跳過 Miri。
    // 安全: 內聯組件是無人值守的。
    unsafe {
        // FIXME: 無法使用 `asm!`，因為它不支持 MIPS 和其他體系結構。
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}