//! 原子類型
//!
//! 原子類型提供線程之間的原始共享內存通信，並且是其他並發類型的構建塊。
//!
//! 該模塊定義了一些基本類型的原子版本，包括 [`AtomicBool`]，[`AtomicIsize`]，[`AtomicUsize`]，[`AtomicI8`]，[`AtomicU16`] 等。
//! 原子類型表示可正確使用的操作，這些操作可在線程之間同步更新。
//!
//! 每種方法都使用一個 [`Ordering`]，該 [`Ordering`] 表示該操作的內存屏障的強度。這些順序與 [C++20 atomic orderings][1] 相同。有關更多信息，請參見 [nomicon][2]。
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! 原子變量可以安全地在線程之間共享 (它們實現 [`Sync`])，但它們本身並不提供共享機制並遵循 Rust 的 [threading model](../../../std/thread/index.html#the-threading-model)。
//!
//! 共享原子變量的最常見方法是將其放入 [`Arc`][arc] (原子引用計數的共享指針)。
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! 原子類型可以存儲在靜態變量中，可以使用常量初始化程序 (如 [`AtomicBool::new`]) 進行初始化。原子靜態常用於惰性全局初始化。
//!
//! # Portability
//!
//! 如果可用，則保證該模塊中的所有原子類型均為 [lock-free]。這意味著他們沒有內部獲取全局互斥量。不能保證原子類型和操作無需等待。
//! 這意味著可以使用比較和交換循環來實現類似 `fetch_or` 的操作。
//!
//! 原子操作可以在指令層使用更大尺寸的原子來實現。例如，某些平台使用 4 字節原子指令來實現 `AtomicI8`。
//! 請注意，此仿真不應影響代碼的正確性，這只是需要注意的事情。
//!
//! 此模塊中的原子類型可能並非在所有平台上都可用。但是，這裡的原子類型都是廣泛可用的，並且通常可以依賴現有原子類型。一些值得注意的例外是:
//!
//! * PowerPC 具有 32 位指針的 MIPS 和 MIPS 平台不具有 `AtomicU64` 或 `AtomicI64` 類型。
//! * ARM 不適用於 Linux 的 `armv5te` 之類的平台僅提供 `load` 和 `store` 操作，並且不支持 Compare and Swap (CAS) 操作，例如 `swap`，`fetch_add` 等。
//! 此外，在 Linux 上，這些 CAS 操作是通過 [operating system support] 實施的，這可能會降低性能。
//! * ARM 使用 `thumbv6m` 的目標僅提供 `load` 和 `store` 操作，不支持比較和交換 (CAS) 操作，例如 `swap`，`fetch_add` 等。
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! 請注意，可能會添加 future 平台，這些平台也不支持某些原子操作。最大程度的可移植代碼將要小心使用哪種原子類型。
//! `AtomicUsize` 和 `AtomicIsize` 通常是最便攜的，但是即使到了那時，它們也並非隨處可用。
//! 作為參考，`std` 庫需要指針大小的原子，儘管 `core` 不需要。
//!
//! 當前，您主要需要使用 `#[cfg(target_arch)]` 來有條件地用原子編譯代碼。還有一個不穩定的 `#[cfg(target_has_atomic)]`，可以在 future 中將其穩定下來。
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! 一個簡單的自旋鎖:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // 等待另一個線程釋放鎖
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! 保持活動線程的全局計數:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// 可以在線程之間安全共享的布爾類型。
///
/// 此類型與 [`bool`] 具有相同的內存表示形式。
///
/// **注意**: 此類型僅在支持 `u8` 的原子加載和存儲的平台上可用。
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// 創建一個初始化為 `false` 的 `AtomicBool`。
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send 是為 AtomicBool 隱式實現的。
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// 可以在線程之間安全共享的原始指針類型。
///
/// 此類型與 `*mut T` 具有相同的內存表示形式。
///
/// **注意**: 此類型僅在支持原子加載和指針存儲的平台上可用。
/// 它的大小取決於目標指針的大小。
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// 創建一個空 `AtomicPtr<T>`。
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// 原子內存順序
///
/// 內存順序指定原子操作同步內存的方式。
/// 在最弱的 [`Ordering::Relaxed`] 中，僅同步操作直接觸摸的內存。
/// 另一方面，[`Ordering::SeqCst`] 操作的存儲 - 加載對使其他內存同步，同時還保留了所有線程中此類操作的總順序。
///
///
/// Rust 的內存順序為 [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order)。
///
/// 有關更多信息，請參見 [nomicon]。
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// 沒有排序約束，只有原子操作。
    ///
    /// 對應於 C++ 20 中的 [`memory_order_relaxed`]。
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// 當與存儲耦合時，所有先前的操作都將在使用 [`Acquire`] (或更高級) 排序加載此值之前進行排序。
    ///
    /// 特別是，所有以前的寫入操作對執行此值 [`Acquire`] (或更強) 的所有線程均可見。
    ///
    /// 請注意，對合併加載和存儲的操作使用此順序將導致 [`Relaxed`] 加載操作!
    ///
    /// 此排序僅適用於可以執行存儲的操作。
    ///
    /// 對應於 C++ 20 中的 [`memory_order_release`]。
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// 與加載耦合時，如果加載的值是由具有 [`Release`] (或更高級) 排序的存儲操作寫入的，則所有後續操作在該存儲之後都將被排序。
    /// 特別是，所有後續加載將看到在存儲之前寫入的數據。
    ///
    /// 請注意，對組合加載和存儲的操作使用此順序將導致 [`Relaxed`] 存儲操作!
    ///
    /// 此排序僅適用於可以執行加載的操作。
    ///
    /// 對應於 C++ 20 中的 [`memory_order_acquire`]。
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// 同時具有 [`Acquire`] 和 [`Release`] 的效果:
    /// 對於負載，它使用 [`Acquire`] 排序。對於商店，它使用 [`Release`] 排序。
    ///
    /// 請注意，在 `compare_and_swap` 的情況下，該操作可能最終不執行任何存儲而因此僅具有 [`Acquire`] 排序。
    ///
    /// 但是，`AcqRel` 將永遠不會執行 [`Relaxed`] 訪問。
    ///
    /// 此排序僅適用於將加載和存儲結合在一起的操作。
    ///
    /// 對應於 C++ 20 中的 [`memory_order_acq_rel`]。
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// 類似於 [`Acquire`]/[`Release`]/[`AcqRel`] (分別用於加載，存儲和隨存儲加載操作)，並額外保證所有線程以相同的順序看到所有順序一致的操作。
    ///
    ///
    /// 對應於 C++ 20 中的 [`memory_order_seq_cst`]。
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] 初始化為 `false`。
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// 創建一個新的 `AtomicBool`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// 返回對基礎 [`bool`] 的可變引用。
    ///
    /// 這是安全的，因為可變引用可確保沒有其他線程同時訪問原子數據。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // 安全: 可變的參考保證唯一的所有權。
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// 獲得對 `&mut bool` 的原子訪問。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // 安全: 可變的參考保證唯一的所有權，並且
        // `bool` 和 `Self` 的對齊方式是 1。
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// 消耗原子並返回包含的值。
    ///
    /// 這是安全的，因為按值傳遞 `self` 可以確保沒有其他線程同時訪問原子數據。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// 從 bool 加載一個值。
    ///
    /// `load` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
    /// 可能的值為 [`SeqCst`]，[`Acquire`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Release`] 或 [`AcqRel`]，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // 安全: 原子內在函數和原始函數可防止任何數據爭用
        // 傳入的指針是有效的，因為我們是從引用中獲得的。
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// 將值存儲到 bool 中。
    ///
    /// `store` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
    /// 可能的值為 [`SeqCst`]，[`Release`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Acquire`] 或 [`AcqRel`]，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // 安全: 原子內在函數和原始函數可防止任何數據爭用
        // 傳入的指針是有效的，因為我們是從引用中獲得的。
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// 將值存儲到 bool 中，返回前一個值。
    ///
    /// `swap` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
    /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // 安全: 原子內在防止數據爭用。
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// 如果當前值與 `current` 值相同，則將值存儲到 [`bool`] 中。
    ///
    /// 返回值始終是前一個值。如果等於 `current`，則該值已更新。
    ///
    /// `compare_and_swap` 還接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
    /// 請注意，即使使用 [`AcqRel`]，該操作也可能失敗，因此僅執行 `Acquire` 加載，但沒有 `Release` 語義。
    /// 如果發生此操作，則使用 [`Acquire`] 使其成為該操作 [`Relaxed`] 的存儲部分，而使用 [`Release`] 使該操作成為存儲部分 [`Relaxed`]。
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # 遷移到 `compare_exchange` 和 `compare_exchange_weak`
    ///
    /// `compare_and_swap` 與 `compare_exchange` 等效，具有以下有關內存順序的映射:
    ///
    /// 原創 | 成功 | 失敗
    /// -------- | ------- | -------
    /// 放鬆 | 放鬆 | 輕鬆獲取 | 取得 | 獲取發布 | 發布 | 輕鬆的 AcqRel |AcqRel | 採集 SeqCst |SeqCst | 序列號
    ///
    /// `compare_exchange_weak` 即使比較成功，也允許錯誤地失敗，這允許在循環中使用 compare 和 swap 時編譯器生成更好的彙編代碼。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 如果當前值與 `current` 值相同，則將值存儲到 [`bool`] 中。
    ///
    /// 返回值是指示是否寫入了新值並包含先前值的結果。
    /// 成功後，此值保證等於 `current`。
    ///
    /// `compare_exchange` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
    /// `success` 描述瞭如果與 `current` 的比較成功，則進行讀 - 修改 - 寫操作所需的順序。
    /// `failure` 描述比較失敗時發生的加載操作所需的順序。
    /// 使用 [`Acquire`] 作為成功排序，使存儲成為操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使裝載成功 [`Relaxed`]。
    ///
    /// 失敗排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或弱於成功排序。
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // 安全: 原子內在防止數據爭用。
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// 如果當前值與 `current` 值相同，則將值存儲到 [`bool`] 中。
    ///
    /// 與 [`AtomicBool::compare_exchange`] 不同，即使比較成功，此功能也可能會虛假失敗，這可能導致某些平台上的代碼效率更高。
    ///
    /// 返回值是指示是否寫入了新值並包含先前值的結果。
    ///
    /// `compare_exchange_weak` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
    /// `success` 描述瞭如果與 `current` 的比較成功，則進行讀 - 修改 - 寫操作所需的順序。
    /// `failure` 描述比較失敗時發生的加載操作所需的順序。
    /// 使用 [`Acquire`] 作為成功排序，使存儲成為操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使裝載成功 [`Relaxed`]。
    /// 失敗排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或弱於成功排序。
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // 安全: 原子內在防止數據爭用。
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// 具有布爾值的邏輯 "and"。
    ///
    /// 對當前值和參數 `val` 執行邏輯 "and" 運算，並將新值設置為結果。
    ///
    /// 返回前一個值。
    ///
    /// `fetch_and` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
    /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // 安全: 原子內在防止數據爭用。
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// 具有布爾值的邏輯 "nand"。
    ///
    /// 對當前值和參數 `val` 執行邏輯 "nand" 運算，並將新值設置為結果。
    ///
    /// 返回前一個值。
    ///
    /// `fetch_nand` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
    /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // 我們在這裡不能使用 atomic_nand，因為它可能導致 bool 的值無效。
        // 發生這種情況是因為原子操作內部是使用 8 位整數完成的，這將設置高 7 位。
        //
        // 因此，我們只使用 fetch_xor 或 swap 即可。
        if val {
            // ! (x＆true) == !x 我們必須反轉 bool。
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x＆false) ==true 我們必須將 bool 設置為 true。
            //
            self.swap(true, order)
        }
    }

    /// 具有布爾值的邏輯 "or"。
    ///
    /// 對當前值和參數 `val` 執行邏輯 "or" 運算，並將新值設置為結果。
    ///
    /// 返回前一個值。
    ///
    /// `fetch_or` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
    /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // 安全: 原子內在防止數據爭用。
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// 具有布爾值的邏輯 "xor"。
    ///
    /// 對當前值和參數 `val` 執行邏輯 "xor" 運算，並將新值設置為結果。
    ///
    /// 返回前一個值。
    ///
    /// `fetch_xor` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
    /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // 安全: 原子內在防止數據爭用。
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// 返回指向基礎 [`bool`] 的可變指針。
    ///
    /// 對結果整數進行非原子讀寫可能是數據競爭。
    /// 此方法對於 FFI 最為有用，在 FFI 中，函數簽名可以使用 `*mut bool` 代替 `&AtomicBool`。
    ///
    /// 從共享引用到該原子的 `*mut` 指針返回是安全的，因為原子類型具有內部可變性。
    /// 原子的所有修改都通過共享引用來更改值，並且只要它們使用原子操作就可以安全地進行更改。
    /// 對返回的原始指針的任何使用都需要一個 `unsafe` 塊，並且仍然必須遵守相同的限制: 對其進行的操作必須是原子的。
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// 獲取該值，並對其應用一個函數，該函數返回一個可選的新值。如果函數返回 `Some(_)`，則返回 `Ok(previous_value)` 的 `Result`，否則返回 `Err(previous_value)`。
    ///
    /// Note: 如果同時已從其他線程更改了值，則此函數可以多次調用該函數，只要該函數返回 `Some(_)`，但該函數僅對存儲的值應用一次。
    ///
    ///
    /// `fetch_update` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
    /// 第一個描述了操作最終成功時所需的順序，第二個描述了負載所需的順序。
    /// 這些分別對應於 [`AtomicBool::compare_exchange`] 的成功和失敗順序。
    ///
    /// 使用 [`Acquire`] 作為成功排序，使存儲成為該操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使最終成功加載 [`Relaxed`]。
    /// (failed) 負載排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或小於成功排序。
    ///
    /// **Note:** 此方法僅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// 創建一個新的 `AtomicPtr`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// 返回對基礎指針的可變引用。
    ///
    /// 這是安全的，因為可變引用可確保沒有其他線程同時訪問原子數據。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// 獲得對指針的原子訪問。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - 可變的引用保證了唯一的所有權。
        //  - 如上所述，在 rust 支持的所有平台上，`*mut T` 和 `Self` 的對齊方式均相同。
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// 消耗原子並返回包含的值。
    ///
    /// 這是安全的，因為按值傳遞 `self` 可以確保沒有其他線程同時訪問原子數據。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// 從指針加載一個值。
    ///
    /// `load` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
    /// 可能的值為 [`SeqCst`]，[`Acquire`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Release`] 或 [`AcqRel`]，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // 安全: 原子內在防止數據爭用。
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// 將值存儲到指針中。
    ///
    /// `store` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
    /// 可能的值為 [`SeqCst`]，[`Release`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Acquire`] 或 [`AcqRel`]，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // 安全: 原子內在防止數據爭用。
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// 將一個值存儲到指針中，返回前一個值。
    ///
    /// `swap` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
    /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法僅在支持對指針進行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // 安全: 原子內在防止數據爭用。
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// 如果當前值與 `current` 值相同，則將一個值存儲到指針中。
    ///
    /// 返回值始終是前一個值。如果等於 `current`，則該值已更新。
    ///
    /// `compare_and_swap` 還接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
    /// 請注意，即使使用 [`AcqRel`]，該操作也可能失敗，因此僅執行 `Acquire` 加載，但沒有 `Release` 語義。
    /// 如果發生此操作，則使用 [`Acquire`] 使其成為該操作 [`Relaxed`] 的存儲部分，而使用 [`Release`] 使該操作成為存儲部分 [`Relaxed`]。
    ///
    /// **Note:** 此方法僅在支持對指針進行原子操作的平台上可用。
    ///
    /// # 遷移到 `compare_exchange` 和 `compare_exchange_weak`
    ///
    /// `compare_and_swap` 與 `compare_exchange` 等效，具有以下有關內存順序的映射:
    ///
    /// 原創 | 成功 | 失敗
    /// -------- | ------- | -------
    /// 放鬆 | 放鬆 | 輕鬆獲取 | 取得 | 獲取發布 | 發布 | 輕鬆的 AcqRel |AcqRel | 採集 SeqCst |SeqCst | 序列號
    ///
    /// `compare_exchange_weak` 即使比較成功，也允許錯誤地失敗，這允許在循環中使用 compare 和 swap 時編譯器生成更好的彙編代碼。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 如果當前值與 `current` 值相同，則將一個值存儲到指針中。
    ///
    /// 返回值是指示是否寫入了新值並包含先前值的結果。
    /// 成功後，此值保證等於 `current`。
    ///
    /// `compare_exchange` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
    /// `success` 描述瞭如果與 `current` 的比較成功，則進行讀 - 修改 - 寫操作所需的順序。
    /// `failure` 描述比較失敗時發生的加載操作所需的順序。
    /// 使用 [`Acquire`] 作為成功排序，使存儲成為操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使裝載成功 [`Relaxed`]。
    ///
    /// 失敗排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或弱於成功排序。
    ///
    /// **Note:** 此方法僅在支持對指針進行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // 安全: 原子內在防止數據爭用。
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// 如果當前值與 `current` 值相同，則將一個值存儲到指針中。
    ///
    /// 與 [`AtomicPtr::compare_exchange`] 不同，即使比較成功，此功能也可能會虛假失敗，這可能導致某些平台上的代碼效率更高。
    ///
    /// 返回值是指示是否寫入了新值並包含先前值的結果。
    ///
    /// `compare_exchange_weak` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
    /// `success` 描述瞭如果與 `current` 的比較成功，則進行讀 - 修改 - 寫操作所需的順序。
    /// `failure` 描述比較失敗時發生的加載操作所需的順序。
    /// 使用 [`Acquire`] 作為成功排序，使存儲成為操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使裝載成功 [`Relaxed`]。
    /// 失敗排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或弱於成功排序。
    ///
    /// **Note:** 此方法僅在支持對指針進行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // 安全: 此內在函數不安全，因為它對原始指針進行操作
        // 但是我們可以肯定地知道指針是有效的 (我們只是通過引用獲得了 `UnsafeCell` 的指針)，並且原子操作本身允許我們安全地更改 `UnsafeCell` 的內容。
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// 獲取該值，並對其應用一個函數，該函數返回一個可選的新值。如果函數返回 `Some(_)`，則返回 `Ok(previous_value)` 的 `Result`，否則返回 `Err(previous_value)`。
    ///
    /// Note: 如果同時已從其他線程更改了值，則此函數可以多次調用該函數，只要該函數返回 `Some(_)`，但該函數僅對存儲的值應用一次。
    ///
    ///
    /// `fetch_update` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
    /// 第一個描述了操作最終成功時所需的順序，第二個描述了負載所需的順序。
    /// 這些分別對應於 [`AtomicPtr::compare_exchange`] 的成功和失敗順序。
    ///
    /// 使用 [`Acquire`] 作為成功排序，使存儲成為該操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使最終成功加載 [`Relaxed`]。
    /// (failed) 負載排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或小於成功排序。
    ///
    /// **Note:** 此方法僅在支持對指針進行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// 將 `bool` 轉換為 `AtomicBool`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // 該宏最終在某些體系結構上未使用。
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// 可以在線程之間安全共享的整數類型。
        ///
        /// 此類型與基本整數類型 [` 具有相同的內存表示形式
        ///
        #[doc = $s_int_type]
        /// `].
        /// 有關原子類型和非原子類型之間的區別以及有關此類型的可移植性的更多信息，請參見 [module-level documentation]。
        ///
        ///
        /// **Note:** 此類型僅在支持原子負載和 [` 的存儲的平台上可用
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// 初始化為 `0` 的原子整數。
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // 發送是隱式實現的。
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// 創建一個新的原子整數。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// 返回對基礎整數的可變引用。
            ///
            /// 這是安全的，因為可變引用可確保沒有其他線程同時訪問原子數據。
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// 讓 mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int，100) ;
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - 可變的引用保證了唯一的所有權。
                //  - `$int_type` 和 `Self` 的對齊方式相同，如 $cfg_align 所承諾並已在上面進行了驗證。
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// 消耗原子並返回包含的值。
            ///
            /// 這是安全的，因為按值傳遞 `self` 可以確保沒有其他線程同時訪問原子數據。
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// 從原子整數加載值。
            ///
            /// `load` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
            /// 可能的值為 [`SeqCst`]，[`Acquire`] 和 [`Relaxed`]。
            ///
            /// # Panics
            ///
            /// 如果 `order` 是 [`Release`] 或 [`AcqRel`]，則為 Panics。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// 將值存儲到原子整數中。
            ///
            /// `store` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
            ///  可能的值為 [`SeqCst`]，[`Release`] 和 [`Relaxed`]。
            ///
            /// # Panics
            ///
            /// 如果 `order` 是 [`Acquire`] 或 [`AcqRel`]，則為 Panics。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// 將值存儲到原子整數中，返回前一個值。
            ///
            /// `swap` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// 如果當前值與 `current` 值相同，則將值存儲到原子整數中。
            ///
            /// 返回值始終是前一個值。如果等於 `current`，則該值已更新。
            ///
            /// `compare_and_swap` 還接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。
            /// 請注意，即使使用 [`AcqRel`]，該操作也可能失敗，因此僅執行 `Acquire` 加載，但沒有 `Release` 語義。
            ///
            /// 如果發生此操作，則使用 [`Acquire`] 使其成為該操作 [`Relaxed`] 的存儲部分，而使用 [`Release`] 使該操作成為存儲部分 [`Relaxed`]。
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # 遷移到 `compare_exchange` 和 `compare_exchange_weak`
            ///
            /// `compare_and_swap` 與 `compare_exchange` 等效，具有以下有關內存順序的映射:
            ///
            /// 原創 | 成功 | 失敗
            /// -------- | ------- | -------
            /// 放鬆 | 放鬆 | 輕鬆獲取 | 取得 | 獲取發布 | 發布 | 輕鬆的 AcqRel |AcqRel | 採集 SeqCst |SeqCst | 序列號
            ///
            /// `compare_exchange_weak` 即使比較成功，也允許錯誤地失敗，這允許在循環中使用 compare 和 swap 時編譯器生成更好的彙編代碼。
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// 如果當前值與 `current` 值相同，則將值存儲到原子整數中。
            ///
            /// 返回值是指示是否寫入了新值並包含先前值的結果。
            /// 成功後，此值保證等於 `current`。
            ///
            /// `compare_exchange` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
            /// `success` 描述瞭如果與 `current` 的比較成功，則進行讀 - 修改 - 寫操作所需的順序。
            /// `failure` 描述比較失敗時發生的加載操作所需的順序。
            /// 使用 [`Acquire`] 作為成功排序，使存儲成為操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使裝載成功 [`Relaxed`]。
            ///
            /// 失敗排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或弱於成功排序。
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// 如果當前值與 `current` 值相同，則將值存儲到原子整數中。
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// 即使比較成功，此功能也可能會虛假地失敗，這可能導致某些平台上的代碼效率更高。
            /// 返回值是指示是否寫入了新值並包含先前值的結果。
            ///
            /// `compare_exchange_weak` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
            /// `success` 描述瞭如果與 `current` 的比較成功，則進行讀 - 修改 - 寫操作所需的順序。
            /// `failure` 描述比較失敗時發生的加載操作所需的順序。
            /// 使用 [`Acquire`] 作為成功排序，使存儲成為操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使裝載成功 [`Relaxed`]。
            ///
            /// 失敗排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或弱於成功排序。
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// 讓 mut old= val.load(Ordering::Relaxed);
            /// 循環 {讓新 = 舊 * 2;
            ///     匹配 val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // 安全: 原子內在防止數據爭用。
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// 加到當前值，返回前一個值。
            ///
            /// 此操作在溢出時迴繞。
            ///
            /// `fetch_add` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// 從當前值減去，返回前一個值。
            ///
            /// 此操作在溢出時迴繞。
            ///
            /// `fetch_sub` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// "and" 按位與當前值。
            ///
            /// 對當前值和參數 `val` 執行按位 "and" 運算，並將新值設置為結果。
            ///
            /// 返回前一個值。
            ///
            /// `fetch_and` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// "nand" 按位與當前值。
            ///
            /// 對當前值和參數 `val` 執行按位 "nand" 運算，並將新值設置為結果。
            ///
            /// 返回前一個值。
            ///
            /// `fetch_nand` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13＆0x31) ) ;
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// "or" 按位與當前值。
            ///
            /// 對當前值和參數 `val` 執行按位 "or" 運算，並將新值設置為結果。
            ///
            /// 返回前一個值。
            ///
            /// `fetch_or` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// "xor" 按位與當前值。
            ///
            /// 對當前值和參數 `val` 執行按位 "xor" 運算，並將新值設置為結果。
            ///
            /// 返回前一個值。
            ///
            /// `fetch_xor` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// 獲取該值，並對其應用一個函數，該函數返回一個可選的新值。如果函數返回 `Some(_)`，則返回 `Ok(previous_value)` 的 `Result`，否則返回 `Err(previous_value)`。
            ///
            /// Note: 如果同時已從其他線程更改了值，則此函數可以多次調用該函數，只要該函數返回 `Some(_)`，但該函數僅對存儲的值應用一次。
            ///
            ///
            /// `fetch_update` 使用兩個 [`Ordering`] 參數來描述此操作的內存順序。
            /// 第一個描述了操作最終成功時所需的順序，第二個描述了負載所需的順序。這些對應於成功和失敗的順序
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// 使用 [`Acquire`] 作為成功排序，使存儲成為該操作 [`Relaxed`] 的一部分，而使用 [`Release`]，則使最終成功加載 [`Relaxed`]。
            /// (failed) 負載排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，並且必須等於或小於成功排序。
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst，Ordering::SeqCst，| x | Some(x + 1))， Ok(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst，Ordering::SeqCst，| x | Some(x + 1))， Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// 當前值的最大值。
            ///
            /// 查找當前值和參數 `val` 的最大值，並將新值設置為結果。
            ///
            /// 返回前一個值。
            ///
            /// `fetch_max` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// 設 bar=42;
            /// 讓 max_foo=foo.fetch_max (bar， Ordering::SeqCst).max(bar);
            /// 斷言! (max_foo==42) ;
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// 當前值的最小值。
            ///
            /// 查找當前值和參數 `val` 的最小值，並將新值設置為結果。
            ///
            /// 返回前一個值。
            ///
            /// `fetch_min` 接受一個 [`Ordering`] 參數，該參數描述此操作的內存順序。所有訂購模式都是可能的。
            /// 請注意，使用 [`Acquire`] 會使該操作成為存儲部分 [`Relaxed`]，而使用 [`Release`] 會使裝入部分成為 [`Relaxed`]。
            ///
            ///
            /// **注意**: 此方法僅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// 令 bar=12;
            /// 讓 min_foo=foo.fetch_min (bar， Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo，12) ;
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全: 原子內在防止數據爭用。
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// 返回指向基礎整數的可變指針。
            ///
            /// 對結果整數進行非原子讀寫可能是數據競爭。
            /// 此方法對 FFI 最有用，在 FFI 中可能使用功能簽名
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// 從共享引用到該原子的 `*mut` 指針返回是安全的，因為原子類型具有內部可變性。
            /// 原子的所有修改都通過共享引用來更改值，並且只要它們使用原子操作就可以安全地進行更改。
            /// 對返回的原始指針的任何使用都需要一個 `unsafe` 塊，並且仍然必須遵守相同的限制: 對其進行的操作必須是原子的。
            ///
            ///
            /// # Examples
            ///
            /// 忽略 (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// 外部 "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // 安全: 只要 `my_atomic_op` 是原子的，它都是安全的。
            /// 不安全 {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // 安全: 调用者必須遵守 `atomic_store` 的安全合同。
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_load` 的安全合同。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_swap` 的安全合同。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// 返回前一個值 (如__sync_fetch_and_add)。
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_add` 的安全合同。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// 返回前一個值 (如__sync_fetch_and_sub)。
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_sub` 的安全合同。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // 安全: 调用者必須遵守 `atomic_compare_exchange` 的安全合同。
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // 安全: 调用者必須遵守 `atomic_compare_exchange_weak` 的安全合同。
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_and` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_nand` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_or` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_xor` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// 返回最大值 (有符號比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_max` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// 返回最小值 (帶符號的比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_min` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// 返回最大值 (無符號比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_umax` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// 返回最小值 (無符號比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全: 调用者必須遵守 `atomic_umin` 的安全合同
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// 原子圍欄。
///
/// 根據指定的順序，圍欄會阻止編譯器和 CPU 重新排序圍繞其進行的某些類型的內存操作。
/// 這會在它與其他線程中的原子操作或籬笆之間創建同步關係。
///
/// 具有 (至少) [`Release`] 排序語義的 Fence 'A' 與具有 (至少) [`Acquire`] 語義的 Fence 'B' 同步，當且僅當存在對原子對象 'M' 進行操作的 X 和 Y 都操作，使得 A 先於 X，Y 在 B 和 Y 觀察到對 M 的更改之前已同步。
/// 這提供了 A 和 B 之間的依存關係。
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// 具有 [`Release`] 或 [`Acquire`] 語義的原子操作也可以與圍柵同步。
///
/// 除了具有 [`Acquire`] 和 [`Release`] 語義外，具有 [`SeqCst`] 順序的籬笆還參與其他 [`SeqCst`] 操作或者籬笆的全局程序順序。
///
/// 接受 [`Acquire`]，[`Release`]，[`AcqRel`] 和 [`SeqCst`] 訂購。
///
/// # Panics
///
/// 如果 `order` 為 [`Relaxed`]，則為 Panics。
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // 基於自旋鎖的互斥原語。
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // 等待直到舊值為 `false`。
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // 此防護欄與 `unlock` 中的存儲同步。
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // 安全: 使用原子柵欄是安全的。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// 編譯器內存防護欄。
///
/// `compiler_fence` 不會發出任何機器代碼，但會限制允許編譯器重新排序的內存類型。具體而言，根據給定的 [`Ordering`] 語義，可能不允許編譯器將調用之前或之後的讀取或寫入移動到對 `compiler_fence` 的調用的另一側。請注意，它確實不會阻止 *硬件* 進行此類重新排序。
///
/// 在單線程執行上下文中這不是問題，但是當其他線程可以同時修改內存時，則需要更強大的同步原語，例如 [`fence`]。
///
/// 通過不同的排序語義防止的重新排序是:
///
///  - 對於 [`SeqCst`]，不允許在這一點上對讀取和寫入進行重新排序。
///  - 對於 [`Release`]，不能將先前的讀取和寫入移至後續的寫入之後。
///  - 如果使用 [`Acquire`]，則後續的讀取和寫入操作不能移至先前的讀取操作之前。
///  - 對於 [`AcqRel`]，將同時執行以上兩個規則。
///
/// `compiler_fence` 通常僅用於防止線程與自身競爭 *。也就是說，如果給定線程正在執行一段代碼，然後被中斷，並開始在其他位置執行代碼 (雖然仍在同一線程中，並且從概念上講仍在同一內核上)。在傳統程序中，只有在註冊信號處理程序時才會發生這種情況。
/// 在更底層的代碼中，當處理中斷，以搶占方式實現綠色線程等時，也會出現這種情況。
/// 鼓勵好奇的讀者閱讀 Linux 內核對 [memory barriers] 的討論。
///
/// # Panics
///
/// 如果 `order` 為 [`Relaxed`]，則為 Panics。
///
/// # Examples
///
/// 如果沒有 `compiler_fence`，則儘管所有內容都在單個線程中發生，但 * 不能保證以下代碼中的 `assert_eq!` 成功。
/// 要了解原因，請記住編譯器可以自由地將存儲交換到 `IMPORTANT_VARIABLE` 和 `IS_READ`，因為它們都是 `Ordering::Relaxed`。如果是這樣，並且在更新 `IS_READY` 之後立即調用信號處理程序，則信號處理程序將看到 `IS_READY=1`，但是看到 `IMPORTANT_VARIABLE=0`。
/// 使用 `compiler_fence` 可以解決這種情況。
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // 防止將較早的寫入移至此點之外
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // 安全: 使用原子柵欄是安全的。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// 向處理器發出信號，通知它處於忙於等待的自旋循環 (`自旋鎖定`) 中。
///
/// 不推薦使用此功能，而推薦使用 [`hint::spin_loop`]。
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}