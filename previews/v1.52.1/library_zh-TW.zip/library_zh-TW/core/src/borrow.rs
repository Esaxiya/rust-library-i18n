//! 用於處理借入數據的模塊。

#![stable(feature = "rust1", since = "1.0.0")]

/// trait 用於借用數據。
///
/// 在 Rust 中，通常為不同的用例提供類型的不同表示形式。
/// 例如，可以通過指針類型 (例如 [`Box<T>`] 或 [`Rc<T>`]) 為特定用途適當地選擇值的存儲位置和管理。
/// 除了這些可以與任何類型一起使用的通用包裝器之外，某些類型還提供了可選的構面，從而提供了可能昂貴的功能。
/// 這種類型的一個示例是 [`String`]，它增加了將字符串擴展到基本 [`str`] 的功能。
/// 這要求保持簡單的，不變的字符串不需要的附加信息。
///
/// 這些類型通過對數據類型的引用來提供對基礎數據的訪問。據說它們是 `借來的` 那種類型的。
/// 例如，可以將 [`Box<T>`] 作為 `T` 借用，而可以將 [`String`] 作為 `str` 借用。
///
/// 類型表示可以通過實現 `Borrow<T>` 來借用它們作為某種類型的 `T`，並在 trait 的 [`borrow`] 方法中提供對 `T` 的引用。一種類型可以自由借用幾種不同的類型。
/// 如果希望以可變方式借用該類型 - 允許修改基礎數據，則可以另外實現 [`BorrowMut<T>`]。
///
/// 此外，在為其他 traits 提供實現時，需要考慮由於充當該基礎類型的表示而導致它們的行為是否與基礎類型的行為相同。
/// 當通用代碼依賴於這些其他 trait 實現的相同行為時，通常會使用 `Borrow<T>`。
/// 這些 traits 可能會顯示為其他 trait bounds。
///
/// 特別是對於借入和擁有的值，`Eq`，`Ord` 和 `Hash` 必須等效: `x.borrow() == y.borrow()` 的結果應與 `x == y` 相同。
///
/// 如果通用代碼僅需要為可以提供對相關類型 `T` 的引用的所有類型工作，則通常最好使用 [`AsRef<T>`]，因為更多類型可以安全地實現它。
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// 作為數據收集，[`HashMap<K, V>`] 同時擁有鍵和值。但是，如果將密鑰的實際數據包裝在某種管理類型中，則仍然應該可以使用對密鑰數據的引用來搜索值。
/// 例如，如果鍵是一個字符串，則它很可能與哈希圖一起存儲為 [`String`]，而應該可以使用 [`&str`][`str`] 進行搜索。
/// 因此，`insert` 需要在 `String` 上運行，而 `get` 需要能夠使用 `&str`。
///
/// 略有簡化，`HashMap<K, V>` 的相關部分如下所示:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // 字段省略
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// 整個 HashMap 在鍵類型 `K` 上是通用的。由於這些密鑰與 HashMap 一起存儲，因此此類型必須擁有密鑰的數據。
/// 插入鍵值對時，會給映射表指定 `K`，並且需要找到正確的哈希值存儲區，並根據該 `K` 檢查鍵是否已存在。因此，它需要 `K: Hash + Eq`。
///
/// 但是，在映射中搜索值時，必須提供對 `K` 的引用作為搜索鍵，這要求始終創建此類擁有的值。
/// 對於字符串鍵，這意味著僅在搜索僅 `str` 可用的情況下，才需要創建 `String` 值。
///
/// 相反，`get` 方法在基礎密鑰數據的類型上是通用的，在上面的方法簽名中稱為 `Q`。它聲明 `K` 通過要求 `K: Borrow<Q>` 作為 `Q` 借用。
/// 通過額外要求 `Q: Hash + Eq`，它表示要求 `K` 和 `Q` 具有 `Hash` 和 `Eq` traits 的實現，它們會產生相同的結果。
///
/// `get` 的實現尤其依賴於 `Hash` 的相同實現，即通過基於 `Q` 值計算出的哈希值插入密鑰，通過在 `Q` 值上調用 `Hash::hash` 來確定密鑰的哈希存儲桶。
///
///
/// 結果，如果包裝了 `Q` 值的 `K` 產生的散列與 `Q` 不同，則散列圖將中斷。例如，假設您有一個包裹字符串但比較 ASCII 字母而忽略大小寫的類型:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// 因為兩個相等的值需要產生相同的哈希值，所以 `Hash` 的實現也需要忽略 ASCII 大小寫:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` 可以實現 `Borrow<str>` 嗎? 它當然可以通過其包含的擁有的字符串提供對字符串切片的引用。
/// 但是由於 `Hash` 的實現方式不同，所以它的行為與 `str` 不同，因此，實際上，一定不能實現 `Borrow<str>`。
/// 如果它希望允許其他人訪問基礎 `str`，則可以通過 `AsRef<str>` 來實現，而 `AsRef<str>` 則沒有任何額外的要求。
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// 從擁有的價值中一成不變地借錢。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait 用於可變地借用數據。
///
/// 作為 [`Borrow<T>`] 的伴侶，此 trait 通過提供可變引用允許類型借用作為基礎類型。
/// 有關其他類型借用的更多信息，請參見 [`Borrow<T>`]。
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// 從擁有的價值中相互借用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}