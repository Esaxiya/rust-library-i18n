use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// 包裝器類型，用於構造 `T` 的未初始化實例。
///
/// # 初始化不變式
///
/// 通常，編譯器假定已根據變量類型的要求正確初始化了變量。例如，引用類型的變量必須對齊並且不能為 NULL。
/// 即使在不安全的代碼中，這也必須始終保持不變。
/// 結果，對引用類型的變量進行零初始化會導致瞬時 [undefined behavior][ub]，無論該引用是否曾經用於訪問內存:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // 未定義的行為! ⚠️
/// // 與 `MaybeUninit<&i32>` 等效的代碼:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // 未定義的行為! ⚠️
/// ```
///
/// 編譯器將其用於各種優化，例如取消運行時檢查和優化 `enum` 佈局。
///
/// 同樣，完全未初始化的存儲器可以包含任何內容，而 `bool` 必須始終為 `true` 或 `false`。因此，創建未初始化的 `bool` 是未定義的行為:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // 未定義的行為! ⚠️
/// // 與 `MaybeUninit<bool>` 等效的代碼:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // 未定義的行為! ⚠️
/// ```
///
/// 此外，未初始化的存儲器的特殊之處在於它沒有固定的值 ("fixed" 表示 "it won't change without being written to")。多次讀取相同的未初始化字節會產生不同的結果。
/// 這使得在變量中具有未初始化的數據成為不確定的行為，即使該變量具有整數類型也可以保留任何 *fixed* 位模式:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // 未定義的行為! ⚠️
/// // 與 `MaybeUninit<i32>` 等效的代碼:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // 未定義的行為! ⚠️
/// ```
/// (請注意，有關尚未初始化的整數的規則尚未最終確定，但是除非被確定，否則建議避免使用它們。)
///
/// 最重要的是，請記住，大多數類型具有其他不變式，而不僅僅是在類型級別被初始化。
/// 例如，將 `1` 初始化的 [`Vec<T>`] 視為已初始化 (在當前實現下; 這並不構成穩定的保證)，因為編譯器知道的唯一要求是數據指針必須為非空值。
/// 創建這樣的 `Vec<T>` 不會立即導致未定義的行為，但是在大多數安全操作 (包括刪除操作) 中都將導致未定義的行為。
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` 用於使不安全的代碼能夠處理未初始化的數據。
/// 這是向編譯器發出的信號，指示此處的數據可能 *不* 被初始化:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // 創建一個顯式未初始化的引用。
/// // 編譯器知道 `MaybeUninit<T>` 內部的數據可能無效，因此不是 UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // 將其設置為有效值。
/// unsafe { x.as_mut_ptr().write(&0); }
/// // 提取已初始化的數據 - 僅在正確初始化 `x` 之後 * 才允許這樣做!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// 然後，編譯器知道不會對此代碼進行任何錯誤的假設或優化。
///
/// 您可以認為 `MaybeUninit<T>` 有點像 `Option<T>`，但是沒有任何運行時跟踪且沒有任何安全檢查。
///
/// ## out-pointers
///
/// 您可以使用 `MaybeUninit<T>` 來實現 "out-pointers": 與其從函數中返回數據，還不如將其傳遞給某個 (uninitialized) 存儲器的指針以將結果放入其中。
/// 當對調用方來說，控制結果存儲在內存中的分配方式很重要並且您希望避免不必要的移動時，這很有用。
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` 不會刪除舊內容，這一點很重要。
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // 現在我們知道 `v` 已初始化! 這也可以確保正確刪除 vector。
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## 逐元素初始化數組
///
/// `MaybeUninit<T>` 可用於按元素初始化大型數組:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // 創建一個未初始化的 `MaybeUninit` 數組。
///     // `assume_init` 是安全的，因為我們聲稱這裡已經初始化的類型是一堆 `MaybeUninit`，不需要初始化。
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // 刪除 `MaybeUninit` 不會執行任何操作。
///     // 因此，使用原始指針分配而不是 `ptr::write` 不會導致舊的未初始化值被丟棄。
/////
///     // 同樣，如果在此循環期間存在 panic，則說明內存洩漏，但是沒有內存安全問題。
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // 一切都已初始化。
///     // 將數組轉換為初始化的類型。
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// 您還可以使用部分初始化的數組，這些數組可以在低級數據結構中找到。
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // 創建一個未初始化的 `MaybeUninit` 數組。
/// // `assume_init` 是安全的，因為我們聲稱這裡已經初始化的類型是一堆 `MaybeUninit`，不需要初始化。
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // 計算我們分配的元素數。
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // 對於數組中的每個項目，如果我們分配了它，則刪除。
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## 逐字段初始化結構
///
/// 您可以使用 `MaybeUninit<T>` 和 [`std::ptr::addr_of_mut`] 宏來逐字段初始化結構:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // 初始化 `name` 字段
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // 初始化 `list` 字段如果此處存在 panic，則 `name` 字段中的 `String` 洩漏。
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // 所有字段都已初始化，因此我們調用 `assume_init` 來獲取已初始化的 Foo。
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` 保證具有與 `T` 相同的大小，對齊方式和 ABI:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// 但是請記住，*包含*`MaybeUninit<T>` 的類型不一定是相同的佈局。Rust 通常不保證 `Foo<T>` 的字段具有與 `Foo<U>` 相同的順序，即使 `T` 和 `U` 具有相同的大小和對齊方式。
///
/// 此外，由於任何位值對於 `MaybeUninit<T>` 都是有效的，因此編譯器無法應用 non-zero/niche-filling 優化，從而可能導致更大的尺寸:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// 如果 `T` 是 FFI 安全的，則 `MaybeUninit<T>` 也是如此。
///
/// 雖然 `MaybeUninit` 是 `#[repr(transparent)]` (表示它保證與 `T` 相同的大小，對齊方式和 ABI)，但是這 *不會* 更改任何先前的警告。
/// `Option<T>` 和 `Option<MaybeUninit<T>>` 可能仍具有不同的大小，並且包含 `T` 類型的字段的類型的佈局 (和大小) 可能與該字段為 `MaybeUninit<T>` 的情況不同。
/// `MaybeUninit` 是聯合類型，聯合上的 `#[repr(transparent)]` 不穩定 (請參閱 [the tracking issue](https://github.com/rust-lang/rust/issues/60405))。
/// 隨著時間的流逝，對聯合的 `#[repr(transparent)]` 的確切保證可能會演變，並且 `MaybeUninit` 可能會或可能不會保留 `#[repr(transparent)]`。
/// 就是說，`MaybeUninit<T>` 將始終保證其尺寸，對齊方式和 ABI 與 `T` 相同; 只是 `MaybeUninit` 實施保證的方式可能會演變。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang 項目，因此我們可以在其中包裝其他類型。這對於發電機很有用。
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // 不調用 `T::clone()`，我們不知道我們是否已足夠初始化。
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// 創建一個使用給定值初始化的新 `MaybeUninit<T>`。
    /// 在此函數的返回值上調用 [`assume_init`] 是安全的。
    ///
    /// 請注意，刪除 `MaybeUninit<T>` 絕不會調用 T 的刪除代碼。
    /// 確保 `T` 在初始化時被刪除是您的責任。
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// 以未初始化的狀態創建一個新的 `MaybeUninit<T>`。
    ///
    /// 請注意，刪除 `MaybeUninit<T>` 絕不會調用 T 的刪除代碼。
    /// 確保 `T` 在初始化時被刪除是您的責任。
    ///
    /// 有關某些示例，請參見 [type-level documentation][MaybeUninit]。
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// 在未初始化狀態下創建 `MaybeUninit<T>` 項目的新數組。
    ///
    /// Note: 在 future Rust 版本中，當數組文字語法允許 [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) 時，此方法可能變得不必要。
    ///
    /// 然後，下面的示例可以使用 `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`。
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// 返回實際讀取的 (可能較小的) 數據切片
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // 安全: 未初始化的 `[MaybeUninit<_>; LEN]` 有效。
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// 在未初始化狀態下創建新的 `MaybeUninit<T>`，並用 `0` 字節填充內存。取決於 `T` 是否已經進行了正確的初始化。
    ///
    /// 例如，初始化 `MaybeUninit<usize>::zeroed()`，但不初始化 `MaybeUninit<&'static i32>::zeroed()`，因為引用不能為空。
    ///
    /// 請注意，刪除 `MaybeUninit<T>` 絕不會調用 T 的刪除代碼。
    /// 確保 `T` 在初始化時被刪除是您的責任。
    ///
    /// # Example
    ///
    /// 正確使用此功能: 用零初始化結構，其中該結構的所有字段都可以將位模式 0 保留為有效值。
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// 該函數的 *錯誤* 用法: 當 `0` 不是該類型的有效位模式時，調用 `x.zeroed().assume_init()`:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // 在一個對中，我們創建一個沒有有效判別式的 `NotZero`。
    /// // 這是未定義的行為。⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // 安全: `u.as_mut_ptr()` 指向分配的內存。
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// 設置 `MaybeUninit<T>` 的值。
    /// 這將覆蓋任何先前的值而不將其刪除，因此請注意不要重複使用此兩次，除非您要跳過運行析構函數。
    ///
    /// 為方便起見，這還會返回對 `self` (現已安全初始化) 內容的可變引用。
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // 安全: 我們剛剛初始化了該值。
        unsafe { self.assume_init_mut() }
    }

    /// 獲取指向包含值的指針。
    /// 除非初始化 `MaybeUninit<T>`，否則從該指針讀取或將其轉換為引用是未定義的行為。
    /// 寫入該指針 (non-transitively) 指向的內存是未定義的行為 (`UnsafeCell<T>` 內部除外)。
    ///
    /// # Examples
    ///
    /// 正確使用此方法:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // 在 `MaybeUninit<T>` 中創建引用。可以，因為我們已將其初始化。
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// 這種方法的 *不正確* 用法:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // 我們創建了對未初始化的 vector 的引用! 這是未定義的行為。⚠️
    /// ```
    ///
    /// (請注意，關於未初始化數據的引用的規則尚未最終確定，但是除非被確定，否則建議避免使用它們。)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` 和 `ManuallyDrop` 都是 `repr(transparent)`，因此我們可以強制轉換指針。
        self as *const _ as *const T
    }

    /// 獲取指向包含值的可變指針。
    /// 除非初始化 `MaybeUninit<T>`，否則從該指針讀取或將其轉換為引用是未定義的行為。
    ///
    /// # Examples
    ///
    /// 正確使用此方法:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // 在 `MaybeUninit<Vec<u32>>` 中創建引用。
    /// // 可以，因為我們已將其初始化。
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// 這種方法的 *不正確* 用法:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // 我們創建了對未初始化的 vector 的引用! 這是未定義的行為。⚠️
    /// ```
    ///
    /// (請注意，關於未初始化數據的引用的規則尚未最終確定，但是除非被確定，否則建議避免使用它們。)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` 和 `ManuallyDrop` 都是 `repr(transparent)`，因此我們可以強制轉換指針。
        self as *mut _ as *mut T
    }

    /// 從 `MaybeUninit<T>` 容器中提取值。這是確保數據將被刪除的好方法，因為生成的 `T` 受到通常的刪除處理。
    ///
    /// # Safety
    ///
    /// 取決於調用方，以確保 `MaybeUninit<T>` 確實處於初始化狀態。在內容尚未完全初始化時調用此方法會立即導致未定義的行為。
    /// [type-level documentation][inv] 包含有關此初始化不變量的更多信息。
    ///
    /// [inv]: #initialization-invariant
    ///
    /// 最重要的是，請記住，大多數類型具有其他不變式，而不僅僅是在類型級別被初始化。
    /// 例如，將 `1` 初始化的 [`Vec<T>`] 視為已初始化 (在當前實現下; 這並不構成穩定的保證)，因為編譯器知道的唯一要求是數據指針必須為非空值。
    ///
    /// 創建這樣的 `Vec<T>` 不會立即導致未定義的行為，但是在大多數安全操作 (包括刪除操作) 中都將導致未定義的行為。
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// 正確使用此方法:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// 這種方法的 *不正確* 用法:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` 尚未初始化，因此這最後一行導致未定義的行為。⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // 安全: 調用者必須保證 `self` 已初始化。
        // 這也意味著 `self` 必須是 `value` 的變體。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// 從 `MaybeUninit<T>` 容器中讀取值。所得的 `T` 受通常的墨滴處理。
    ///
    /// 只要有可能，最好改用 [`assume_init`]，這樣可以防止重複 `MaybeUninit<T>` 的內容。
    ///
    /// # Safety
    ///
    /// 取決於調用方，以確保 `MaybeUninit<T>` 確實處於初始化狀態。在內容尚未完全初始化時調用此方法將導致未定義的行為。
    /// [type-level documentation][inv] 包含有關此初始化不變量的更多信息。
    ///
    /// 而且，這會將相同數據的副本留在 `MaybeUninit<T>` 中。
    /// 使用數據的多個副本時 (通過多次調用 `assume_init_read`，或先調用 `assume_init_read`，然後再調用 [`assume_init`])，您有責任確保確實可以復制數據。
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// 正確使用此方法:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` 是 `Copy`，因此我們可能會多次閱讀。
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // 複製 `None` 值是可以的，因此我們可能會多次讀取。
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// 這種方法的 *不正確* 用法:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // 現在，我們創建了同一 vector 的兩個副本，當它們都掉落時，將導致雙自由 free️!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // 安全: 調用者必須保證 `self` 已初始化。
        // 從 `self.as_ptr()` 讀取數據是安全的，因為應該初始化 `self`。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// 將包含的值放到適當的位置。
    ///
    /// 如果您擁有 `MaybeUninit` 的所有權，則可以改用 [`assume_init`]。
    ///
    /// # Safety
    ///
    /// 取決於調用方，以確保 `MaybeUninit<T>` 確實處於初始化狀態。在內容尚未完全初始化時調用此方法將導致未定義的行為。
    ///
    /// 最重要的是，必須滿足類型 `T` 的所有其他不變量，因為 `T` (或其成員) 的 `Drop` 實現可能依賴於此。
    /// 例如，將 `1` 初始化的 [`Vec<T>`] 視為已初始化 (在當前實現下; 這並不構成穩定的保證)，因為編譯器知道的唯一要求是數據指針必須為非空值。
    ///
    /// 但是，丟棄這樣的 `Vec<T>` 會導致不確定的行為。
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // 安全: 調用者必須保證 `self` 已初始化並且
        // 滿足 `T` 的所有不變量。
        // 在這種情況下，將值放到適當的位置是安全的。
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// 獲取對包含值的共享引用。
    ///
    /// 當我們要訪問已初始化但沒有 `MaybeUninit` 所有權的 `MaybeUninit` (防止使用 `.assume_init()`)) 時，這很有用。
    ///
    /// # Safety
    ///
    /// 在內容尚未完全初始化時調用此方法會導致未定義的行為: 取決於調用方，以確保 `MaybeUninit<T>` 確實處於初始化狀態。
    ///
    ///
    /// # Examples
    ///
    /// ### 正確使用此方法:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // 初始化 `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // 現在已知我們的 `MaybeUninit<_>` 已初始化，可以創建對其的共享引用:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // 安全: `x` 已初始化。
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### 這種方法的 *不正確* 用法:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // 我們創建了對未初始化的 vector 的引用! 這是未定義的行為。⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // 使用 `Cell::set` 初始化 `MaybeUninit`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // 引用未初始化的 `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // 安全: 調用者必須保證 `self` 已初始化。
        // 這也意味著 `self` 必須是 `value` 的變體。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// 獲取對包含值的可變 (unique) 引用。
    ///
    /// 當我們要訪問已初始化但沒有 `MaybeUninit` 所有權的 `MaybeUninit` (防止使用 `.assume_init()`)) 時，這很有用。
    ///
    /// # Safety
    ///
    /// 在內容尚未完全初始化時調用此方法會導致未定義的行為: 取決於調用方，以確保 `MaybeUninit<T>` 確實處於初始化狀態。
    /// 例如，`.assume_init_mut()` 不能用於初始化 `MaybeUninit`。
    ///
    /// # Examples
    ///
    /// ### 正確使用此方法:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// 初始化所有輸入緩衝區的字節。
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // 初始化 `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // 現在我們知道 `buf` 已被初始化，因此我們可以對其進行 `.assume_init()`。
    /// // 但是，使用 `.assume_init()` 可能會觸發 2048 字節的 `memcpy`。
    /// // 要斷言我們的緩衝區已被初始化而不復制它，我們將 `&mut MaybeUninit<[u8; 2048]>` 升級到 `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // 安全: `buf` 已初始化。
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // 現在我們可以將 `buf` 用作普通切片:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### 這種方法的 *不正確* 用法:
    ///
    /// 您不能使用 `.assume_init_mut()` 初始化值:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // 我們已經創建了對未初始化 `bool` 的 (mutable) 引用!
    ///     // 這是未定義的行為。⚠️
    /// }
    /// ```
    ///
    /// 例如，您不能 [`Read`] 進入未初始化的緩衝區:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) 引用未初始化的內存!
    ///                             // 這是未定義的行為。
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// 您也不能使用直接字段訪問來進行逐字段逐步初始化:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) 引用未初始化的內存!
    ///                  // 這是未定義的行為。
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) 引用未初始化的內存!
    ///                  // 這是未定義的行為。
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): 當前，我們依賴於上述錯誤信息，即，我們引用了未初始化的數據 (例如，在 `libcore/fmt/float.rs` 中)。
    // 在穩定之前，我們應該對規則做出最後決定。
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // 安全: 調用者必須保證 `self` 已初始化。
        // 這也意味著 `self` 必須是 `value` 的變體。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// 從 `MaybeUninit` 容器數組中提取值。
    ///
    /// # Safety
    ///
    /// 調用方有責任保證數組的所有元素都處於初始化狀態。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // 安全: 初始化所有元素後，現在安全
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * 調用者保證數組的所有元素都已初始化
        // * `MaybeUninit<T>` 和 T 保證具有相同的佈局
        // * 也許 Unint 不會下降，所以沒有 double-frees，因此轉換是安全的
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// 假設所有元素都已初始化，請對其進行切片。
    ///
    /// # Safety
    ///
    /// 取決於調用方，以確保 `MaybeUninit<T>` 元素確實處於初始化狀態。
    ///
    /// 在內容尚未完全初始化時調用此方法將導致未定義的行為。
    ///
    /// 有關更多詳細信息和示例，請參見 [`assume_init_ref`]。
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // 安全: 將切片投射到 `*const [T]` 是安全的，因為调用者保證
        // `slice` 初始化，並保證 MaybeUninit 具有與 `T` 相同的佈局。
        // 所獲得的指針是有效的，因為它引用 `slice` 擁有的內存，該內存是一個引用，因此可以保證對讀取有效。
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// 假設所有元素都已初始化，則對它們進行可變切片。
    ///
    /// # Safety
    ///
    /// 取決於調用方，以確保 `MaybeUninit<T>` 元素確實處於初始化狀態。
    ///
    /// 在內容尚未完全初始化時調用此方法將導致未定義的行為。
    ///
    /// 有關更多詳細信息和示例，請參見 [`assume_init_mut`]。
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // 安全: 類似於 `slice_get_ref` 的安全說明，但我們有一個
        // 可變引用，它也保證對寫入有效。
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// 獲取指向數組第一個元素的指針。
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// 獲取指向數組第一個元素的可變指針。
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// 將元素從 `src` 複製到 `this`，返回對 `this` 現已初始化的內容的可變引用。
    ///
    /// 如果 `T` 未實現 `Copy`，請使用 [`write_slice_cloned`]
    ///
    /// 這類似於 [`slice::copy_from_slice`]。
    ///
    /// # Panics
    ///
    /// 如果兩個切片的長度不同，則此功能將為 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // 安全: 我們剛剛將 len 的所有元素複製到了備用容量中
    /// // vec 的前 src.len() 個元素現在有效。
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // 安全:＆[T] 和＆[MaybeUninit<T>] 具有相同的佈局
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // 安全性: 有效元素剛剛被複製到 `this` 中，因此被初始化
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// 將元素從 `src` 克隆到 `this`，返回對 `this` 現已初始化的內容的可變引用。
    /// 任何已經初始化的元素都不會被刪除。
    ///
    /// 如果 `T` 實現 `Copy`，請使用 [`write_slice`]
    ///
    /// 這類似於 [`slice::clone_from_slice`]，但不會刪除現有元素。
    ///
    /// # Panics
    ///
    /// 如果兩個切片的長度不同，或者 `Clone` panics 的實現，則此函數將為 panic。
    ///
    /// 如果存在 panic，將刪除已經克隆的元素。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // 安全: 我們剛剛將 len 的所有元素克隆到了備用容量中
    /// // vec 的前 src.len() 個元素現在有效。
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // 與 copy_from_slice 不同，此操作不會在片上調用 clone_from_slice，這是因為 `MaybeUninit<T: Clone>` 未實現克隆。
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // 安全: 此原始切片將僅包含初始化的對象
                // 這就是為什麼允許將其刪除。
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: 我們需要明確地將它們切成相同的長度
        // 以便取消邊界檢查，優化器將為簡單情況 (例如 T= u8) 生成 memcpy。
        //
        let len = this.len();
        let src = &src[..len];

        // 克隆期間可能需要 b/c panic 保護
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // 安全: 有效元素剛剛被寫入 `this`，所以它是初始化的
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}