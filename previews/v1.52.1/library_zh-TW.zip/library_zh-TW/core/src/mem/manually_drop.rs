use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// 包裝器，用於禁止編譯器自動調用 T 的析構函數。
/// 該包裝器的成本為 0。
///
/// `ManuallyDrop<T>` 與 `T` 進行相同的佈局優化。
/// 結果，它對編譯器對其內容所做的假設沒有影響。
/// 例如，用 [`mem::zeroed`] 初始化 `ManuallyDrop<&mut T>` 是未定義的行為。
/// 如果需要處理未初始化的數據，請改用 [`MaybeUninit<T>`]。
///
/// 請注意，訪問 `ManuallyDrop<T>` 內部的值是安全的。
/// 這意味著其內容已刪除的 `ManuallyDrop<T>` 一定不能通過公共安全 API 公開。
/// 相應地，`ManuallyDrop::drop` 是不安全的。
///
/// # `ManuallyDrop` 並下達訂單。
///
/// Rust 具有定義明確的 [drop order] 值。
/// 為確保按特定順序刪除字段或局部變量，請對聲明重新排序，以使隱式刪除順序正確。
///
/// 可以使用 `ManuallyDrop` 控制放置順序，但這需要不安全的代碼，並且在展開時很難正確執行。
///
///
/// 例如，如果要確保將特定字段放在其他字段之後，則將其作為結構的最後一個字段:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` 之後將被刪除。
///     // Rust 保證按聲明順序刪除字段。
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// 包裝一個要手動刪除的值。
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // 您仍然可以安全地操作價值
    /// assert_eq!(*x, "Hello");
    /// // 但是 `Drop` 不會在這裡運行
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// 從 `ManuallyDrop` 容器中提取值。
    ///
    /// 這樣可以再次刪除該值。
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // 這將使 `Box` 掉落。
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// 從 `ManuallyDrop<T>` 容器中取出值。
    ///
    /// 此方法主要用於移出液滴中的值。
    /// 您可以使用此方法獲取值並根據需要使用它，而不是使用 [`ManuallyDrop::drop`] 手動刪除該值。
    ///
    /// 只要有可能，最好改用 [`into_inner`][`ManuallyDrop::into_inner`]，這樣可以防止重複 `ManuallyDrop<T>` 的內容。
    ///
    ///
    /// # Safety
    ///
    /// 該函數從語義上移出所包含的值，而不會阻止進一步使用，從而使該容器的狀態保持不變。
    /// 您有責任確保不再使用此 `ManuallyDrop`。
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // 安全: 我們正在閱讀參考資料，這是有保證的
        // 對讀取有效。
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// 手動刪除包含的值。這完全等同於使用指向所包含值的指針來調用 [`ptr::drop_in_place`]。
    /// 這樣，除非所包含的值是打包的結構，否則析構函數將在不移動值的情況下就地調用，因此可用於安全地刪除 [pinned] 數據。
    ///
    /// 如果您擁有該值的所有權，則可以改用 [`ManuallyDrop::into_inner`]。
    ///
    /// # Safety
    ///
    /// 此函數運行包含值的析構函數。
    /// 除了析構函數本身所做的更改外，內存保持不變，因此就編譯器而言，仍然保留一種對於 `T` 類型有效的位模式。
    ///
    ///
    /// 但是，此 "zombie" 值不應暴露給安全代碼，並且不應多次調用此函數。
    /// 在刪除值或多次刪除值後使用該值可能會導致未定義行為 (取決於 `drop` 的作用)。
    /// 類型系統通常會阻止這種情況，但是 `ManuallyDrop` 的用戶必須堅持這些保證，而無需編譯器的幫助。
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // 安全: 我們正在刪除可變引用所指向的值
        // 保證對寫入有效。
        // 取決於調用方，以確保不會再次丟棄 `slot`。
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}