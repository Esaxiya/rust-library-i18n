//! 處理內存的基本功能。
//!
//! 該模塊包含用於查詢類型的大小和對齊，初始化和操作內存的函數。
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// 在不運行其析構函數 **的情況下，獲取所有權和 "forgets" 值**。
///
/// 該值管理的任何資源 (例如堆內存或文件句柄) 將永遠處於無法訪問的狀態。但是，它不能保證指向該內存的指針將保持有效。
///
/// * 如果要洩漏內存，請參閱 [`Box::leak`]。
/// * 如果要獲取指向內存的原始指針，請參見 [`Box::into_raw`]。
/// * 如果要正確處理某個值，請運行其析構函數，請參閱 [`mem::drop`]。
///
/// # Safety
///
/// `forget` 未將其標記為 `unsafe`，因為 Rust 的安全保證不包括析構函數將始終運行的保證。
/// 例如，程序可以使用 [`Rc`][rc] 創建參考循環，或調用 [`process::exit`][exit] 退出而不運行析構函數。
/// 因此，從安全代碼允許 `mem::forget` 不會從根本上改變 Rust 的安全保證。
///
/// 也就是說，通常不希望洩漏諸如內存或 I/O 對象之類的資源。
/// 在某些特殊的用例中，對於 FFI 或不安全代碼提出了需求，但即使這樣，通常還是首選 [`ManuallyDrop`]。
///
/// 因為允許忘記一個值，所以您編寫的任何 `unsafe` 代碼都必須允許這種可能性。您不能返回值，並且期望調用者一定會運行該值的析構函數。
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` 的規範安全使用是為了規避 `Drop` trait 實現的值的析構函數。例如，這將洩漏 `File`，即
/// 回收變量佔用的空間，但不要關閉基礎系統資源:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// 當基礎資源的所有權先前已轉移到 Rust 之外的代碼時 (例如，通過將原始文件描述符傳輸到 C 代碼)，這很有用。
///
/// # 與 `ManuallyDrop` 的關係
///
/// 雖然 `mem::forget` 也可以用於轉移 *內存* 所有權，但是這樣做很容易出錯。
/// [`ManuallyDrop`] 應該改為使用。例如，考慮以下代碼:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // 使用 `v` 的內容構建 `String`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` 洩漏，因為它的內存現在由 `s` 管理
/// mem::forget(v);  // 錯誤，v 無效，不能傳遞給函數
/// assert_eq!(s, "Az");
/// // `s` 被隱式刪除，並且其內存被釋放。
/// ```
///
/// 上面的示例有兩個問題:
///
/// * 如果在 `String` 的構造和 `mem::forget()` 的調用之間添加了更多代碼，則其中的 panic 將導致雙倍的空閒，因為 `v` 和 `s` 都處理相同的內存。
/// * 調用 `v.as_mut_ptr()` 並將數據所有權傳輸到 `s` 之後，`v` 值無效。
/// 即使將值僅移動到 `mem::forget` (不會檢查它)，某些類型對其值也有嚴格的要求，以使它們在懸空或不再擁有時無效。
/// 以任何方式使用無效值 (包括將它們傳遞給函數或從函數返回值) 會構成未定義的行為，並且可能會破壞編譯器所做的假設。
///
/// 切換到 `ManuallyDrop` 可以避免兩個問題:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // 在將 `v` 拆解為原始零件之前，請確保它不會掉落!
/////
/// let mut v = ManuallyDrop::new(v);
/// // 現在拆卸 `v`。這些操作不能 panic，因此不能有洩漏。
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // 最後，構建一個 `String`。
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` 被隱式刪除，並且其內存被釋放。
/// ```
///
/// `ManuallyDrop` 強有力地防止了雙重釋放，因為在執行其他任何操作之前，我們先禁用了 `v` 的析構函數。
/// `mem::forget()` 不允許這樣做，因為它消耗了它的參數，僅在從 `v` 中提取了我們需要的所有內容後，才迫使我們調用它。
/// 即使在 `ManuallyDrop` 的構建和字符串的構建之間引入了 panic (這在所示的代碼中不能發生)，也將導致洩漏，而不是雙重釋放。
/// 換句話說，`ManuallyDrop` 在洩漏側發生錯誤，而不是在 (兩次) 丟棄側發生錯誤。
///
/// 同樣，`ManuallyDrop` 避免了在將所有權轉讓給 `s` 之後必須使用 "touch" `v` 的情況-完全避免了與 `v` 交互以處置它而不運行其析構函數的最後一步。
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// 與 [`forget`] 一樣，但也接受大小不一的值。
///
/// `unsized_locals` 功能穩定後，此功能僅是要刪除的墊片。
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// 返回類型的大小 (以字節為單位)。
///
/// 更具體地說，這是具有該項目類型 (包括對齊填充) 的數組中連續元素之間的字節偏移量。
///
/// 因此，對於任何類型的 `T` 和長度 `n`，`[T; n]` 的大小都是 `n * size_of::<T>()`。
///
/// 通常，類型的大小在整個編譯過程中不穩定，但是特定類型 (例如基元) 是穩定的。
///
/// 下表提供了基元的大小。
///
/// 類型 | size_of: :\<Type> ()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 個 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 個 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 個字符 | 4
///
/// 此外，`usize` 和 `isize` 具有相同的大小。
///
/// `*const T`，`&T`，`Box<T>`，`Option<&T>` 和 `Option<Box<T>>` 類型均具有相同的大小。
/// 如果將 `T` 調整為大小，則所有這些類型的大小均與 `usize` 相同。
///
/// 指針的可變性不會改變其大小。這樣，`&T` 和 `&mut T` 具有相同的大小。
/// 對於 `*const T` 和 `* mut T` 同樣。
///
/// # `#[repr(C)]` 物品的大小
///
/// 項目的 `C` 表示具有已定義的佈局。
/// 使用此佈局，只要所有字段的大小都穩定，則項目的大小也將保持穩定。
///
/// ## 結構尺寸
///
/// 對於 `structs`，大小由以下算法確定。
///
/// 對於結構中按聲明順序排序的每個字段:
///
/// 1. 添加字段的大小。
/// 2. 將當前大小四捨五入到下一個字段的 [alignment] 的最接近倍數。
///
/// 最後，將結構的大小四捨五入到其 [alignment] 的最接近倍數。
/// 結構的對齊方式通常是其所有字段中最大的對齊方式; 這可以通過使用 `repr(align(N))` 進行更改。
///
/// 與 `C` 不同，零大小的結構不會四捨五入為一個字節。
///
/// ## 枚舉的大小
///
/// 除判別式外不包含任何數據的枚舉的大小與為其編譯的平台上的 C 枚舉的大小相同。
///
/// ## 工會規模
///
/// 工會的規模就是其最大領域的規模。
///
/// 與 `C` 不同，零大小的並集不捨入到一個字節的大小。
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // 一些原語
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // 一些數組
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // 指針大小相等
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// 使用 `#[repr(C)]`。
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // 第一個字段的大小為 1，因此請在大小上加 1。大小為 1。
/// // 第二個字段的對齊方式為 2，因此在填充尺寸上加 1。大小為 2。
/// // 第二個字段的大小為 2，因此將大小加 2。大小為 4。
/// // 第三個字段的對齊方式為 1，因此請在填充大小上加上 0。大小為 4。
/// // 第三個字段的大小為 1，因此請在大小上加 1。大小為 5。
/// // 最後，該結構的對齊方式為 2 (因為其字段之間的最大對齊方式為 2)，因此將其大小加 1 以進行填充。
/// // 大小為 6。
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // 元組結構遵循相同的規則。
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // 請注意，對字段重新排序可以減小大小。
/// // 我們可以通過將 `third` 放在 `second` 之前刪除兩個填充字節。
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // 聯合大小是最大字段的大小。
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// 返回所指向的值的大小 (以字節為單位)。
///
/// 這通常與 `size_of::<T>()` 相同。
/// 但是，當 `T` 沒有靜態已知的大小 (例如，切片 [`[T]`][slice] 或 [trait object]) 時，可以使用 `size_of_val` 獲得動態已知的大小。
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // 安全: `val` 是一個引用，因此它是有效的原始指針
    unsafe { intrinsics::size_of_val(val) }
}

/// 返回所指向的值的大小 (以字節為單位)。
///
/// 這通常與 `size_of::<T>()` 相同。但是，當 `T` 沒有靜態已知的大小 (例如，切片 [`[T]`][slice] 或 [trait object]) 時，可以使用 `size_of_val_raw` 獲得動態已知的大小。
///
/// # Safety
///
/// 僅在滿足以下條件時，才可以安全地調用此函數:
///
/// - 如果 `T` 是 `Sized`，則始終可以安全地調用此函數。
/// - 如果 `T` 的未調整大小的尾部為:
///     - [slice]，則切片尾部的長度必須是初始化的整數，並且 *entire 值*(動態尾部長度 + 靜態大小的前綴) 的大小必須適合 `isize`。
///     - [trait object]，則指針的 vtable 部分必須指向通過大小調整強制獲取的有效 vtable，並且 *entire 值*(動態尾部長度 + 靜態大小的前綴) 的大小必須適合 `isize`。
///
///     - (unstable) [extern type]，則始終可以安全調用該函數，但可能會 panic 或以其他方式返回錯誤的值，因為外部類型的佈局未知。
///     這與對帶有外部類型尾部的類型的引用上的 [`size_of_val`] 相同。
///     - 否則，保守地不允許調用此函數。
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // 安全: 調用者必須提供有效的原始指針
    unsafe { intrinsics::size_of_val(val) }
}

/// 返回 [ABI] 要求的類型的最小對齊方式。
///
/// 對 `T` 類型值的每個引用都必須是該數字的倍數。
///
/// 這是用於結構字段的對齊方式。它可能小於首選的對齊方式。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// 返回 [ABI] 所需的 `val` 指向的值的類型的最小對齊方式。
///
/// 對 `T` 類型值的每個引用都必須是該數字的倍數。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // 安全: val 是一個引用，因此它是有效的原始指針
    unsafe { intrinsics::min_align_of_val(val) }
}

/// 返回 [ABI] 要求的類型的最小對齊方式。
///
/// 對 `T` 類型值的每個引用都必須是該數字的倍數。
///
/// 這是用於結構字段的對齊方式。它可能小於首選的對齊方式。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// 返回 [ABI] 所需的 `val` 指向的值的類型的最小對齊方式。
///
/// 對 `T` 類型值的每個引用都必須是該數字的倍數。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // 安全: val 是一個引用，因此它是有效的原始指針
    unsafe { intrinsics::min_align_of_val(val) }
}

/// 返回 [ABI] 所需的 `val` 指向的值的類型的最小對齊方式。
///
/// 對 `T` 類型值的每個引用都必須是該數字的倍數。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// 僅在滿足以下條件時，才可以安全地調用此函數:
///
/// - 如果 `T` 是 `Sized`，則始終可以安全地調用此函數。
/// - 如果 `T` 的未調整大小的尾部為:
///     - [slice]，則切片尾部的長度必須是初始化的整數，並且 *entire 值*(動態尾部長度 + 靜態大小的前綴) 的大小必須適合 `isize`。
///     - [trait object]，則指針的 vtable 部分必須指向通過大小調整強制獲取的有效 vtable，並且 *entire 值*(動態尾部長度 + 靜態大小的前綴) 的大小必須適合 `isize`。
///
///     - (unstable) [extern type]，則始終可以安全調用該函數，但可能會 panic 或以其他方式返回錯誤的值，因為外部類型的佈局未知。
///     這與對帶有外部類型尾部的類型的引用上的 [`align_of_val`] 相同。
///     - 否則，保守地不允許調用此函數。
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // 安全: 調用者必須提供有效的原始指針
    unsafe { intrinsics::min_align_of_val(val) }
}

/// 如果刪除類型為 `T` 的值很重要，則返回 `true`。
///
/// 這純粹是一個優化提示，可以保守地實現:
/// 對於實際上不需要刪除的類型，它可能返回 `true`。
/// 因此，始終返回 `true` 將是此功能的有效實現。但是，如果此函數實際返回 `false`，則可以確定刪除 `T` 沒有副作用。
///
/// 需要手動刪除其數據的類似集合之類的低級實現，應使用此功能，以避免在銷毀它們的所有內容時不必要地嘗試刪除它們的所有內容。
///
/// 這可能不會對發行版本產生影響 (可以輕鬆檢測並消除沒有副作用的循環)，但是對於調試版本而言，這通常是一個大勝利。
///
/// 請注意，[`drop_in_place`] 已經執行了此檢查，因此，如果您的工作量可以減少到少量的 [`drop_in_place`] 調用，則無需使用此功能。
/// 特別要注意的是，您可以 [`drop_in_place`] 切片，這將對所有值進行一次 needs_drop 檢查。
///
/// 因此，像 Vec 這樣的類型只是 `drop_in_place(&mut self[..])`，而沒有顯式使用 `needs_drop`。
/// 另一方面，諸如 [`HashMap`] 之類的類型必須一次刪除一個值，並且應使用此 API。
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// 這是一個有關如何使用 `needs_drop` 的示例:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // 刪除數據
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// 返回由全零字節模式表示的 `T` 類型的值。
///
/// 這意味著，例如，`(u8, u16)` 中的填充字節不必為零。
///
/// 不能保證全零字節模式代表某種 `T` 類型的有效值。
/// 例如，全零字節模式對於引用類型 (`＆T`，`&mut T`) 和函數指針不是有效值。
/// 在此類類型上使用 `zeroed` 會立即導致 [undefined behavior][ub]，因為 [the Rust compiler assumes][inv] 在它認為已初始化的變量中始終存在有效值。
///
///
/// 與 [`MaybeUninit::zeroed().assume_init()`][zeroed] 具有相同的作用。
/// 有時對 FFI 很有用，但通常應避免使用。
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// 正確使用此函數: 用 0 初始化一個整數。
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// 該函數的 *錯誤* 用法: 用零初始化引用。
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // 未定義的行為!
/// let _y: fn() = unsafe { mem::zeroed() }; // 然後再次!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // 安全: 調用者必須保證 `T` 的全零值有效。
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// 假裝生成 `T` 類型的值，而什麼也不做，從而繞過 Rust 的常規內存初始化檢查。
///
/// **不推薦使用此功能。** 請改用 [`MaybeUninit<T>`]。
///
/// 棄用的原因是該功能基本上無法正確使用: 其作用與 [`MaybeUninit::uninit().assume_init()`][uninit] 相同。
///
/// 正如 [`assume_init` documentation][assume_init] 解釋的那樣，[the Rust compiler assumes][inv] 值已正確初始化。
/// 結果，調用例如
/// `mem::uninitialized::<bool>()` 導致立即產生不確定的行為，以返回絕對不是 `true` 或 `false` 的 `bool`。
/// 更糟糕的是，真正的未初始化內存 (如此處返回的內存) 的特殊之處在於，編譯器知道它沒有固定的值。
/// 這使得在變量中具有未初始化的數據成為不確定的行為，即使該變量具有整數類型也是如此。
/// (請注意，有關尚未初始化的整數的規則尚未最終確定，但是除非被確定，否則建議避免使用它們。)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // 安全: 調用者必須保證一個統一的值對於 `T` 有效。
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// 在兩個可變位置交換值，而無需對其中一個進行初始化。
///
/// * 如果要交換默認值或虛擬值，請參見 [`take`]。
/// * 如果要與傳遞的值交換，返回舊值，請參見 [`replace`]。
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // 安全: 原始指針是根據滿足所有條件的安全可變引用創建的
    // `ptr::swap_nonoverlapping_one` 上的約束
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// 用默認值 `T` 替換 `dest`，並返回以前的 `dest` 值。
///
/// * 如果要替換兩個變量的值，請參見 [`swap`]。
/// * 如果要替換為傳遞的值而不是默認值，請參見 [`replace`]。
///
/// # Examples
///
/// 一個簡單的例子:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` 允許通過將結構域替換為 "empty" 值來獲取結構域的所有權。
/// 沒有 `take`，您可能會遇到以下問題:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// 請注意，`T` 不一定實現 [`Clone`]，因此它甚至無法克隆和重置 `self.buf`。
/// 但是 `take` 可以用於取消 `self.buf` 的原始值與 `self` 的關聯，從而可以將其返回:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// 將 `src` 移至引用的 `dest`，返回先前的 `dest` 值。
///
/// 這兩個值都不會下降。
///
/// * 如果要替換兩個變量的值，請參見 [`swap`]。
/// * 如果要替換為默認值，請參見 [`take`]。
///
/// # Examples
///
/// 一個簡單的例子:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` 允許通過用另一個值替換 struct 字段來使用它。
/// 沒有 `replace`，您可能會遇到以下問題:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// 請注意，`T` 不一定實現 [`Clone`]，因此我們甚至無法克隆 `self.buf[i]` 以避免此舉。
/// 但是 `replace` 可以用於取消該索引處的原始值與 `self` 的關聯，從而可以將其返回:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // 安全: 我們從 `dest` 讀取數據，但之後直接將 `src` 寫入其中，
    // 這樣就不會復制舊值。
    // panic 不會丟失任何內容。
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// 處理一個值。
///
/// 通過調用參數的 [`Drop`][drop] 實現來實現。
///
/// 這對於實現 `Copy` 的類型實際上不起作用，例如
/// integers.
/// 這樣的值將被複製並將 _then_ 移入該函數，因此該值在此函數調用之後仍然存在。
///
///
/// 這個功能不是魔術。它的字面定義為
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// 由於 `_x` 已移入函數中，因此它會在函數返回之前自動刪除。
///
/// [drop]: Drop
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // 顯式刪除 vector
/// ```
///
/// 由於 [`RefCell`] 在運行時強制執行借用規則，因此 `drop` 可以釋放 [`RefCell`] 借用:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // 放棄此插槽上的可變借位
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// 實現 [`Copy`] 的整數和其他類型不受 `drop` 的影響。
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` 的副本已移動並刪除
/// drop(y); // `y` 的副本已移動並刪除
///
/// println!("x: {}, y: {}", x, y.0); // 仍然可用
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// 將 `src` 解釋為具有 `&U` 類型，然後在不移動所包含的值的情況下讀取 `src`。
///
/// 通過將 `&T` 轉換為 `&U` 然後讀取 `&U`，此函數將不安全地假定指針 `src` 對 [`size_of::<U>`][size_of] 字節有效 (除非這樣做的正確方式是即使 `&U` 要求比 `&T` 嚴格的對齊方式)。
/// 它還將不安全地創建所包含值的副本，而不是移出 `src`。
///
/// 如果 `T` 和 `U` 具有不同的大小，這不是編譯時錯誤，但是強烈建議僅在 `T` 和 `U` 具有相同的大小時調用此函數。如果 `U` 大於 `T`，則此功能將觸發 [undefined behavior][ub]。
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 從 'foo_array' 複製數據並將其視為 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // 修改複製的數據
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' 的內容不應更改
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // 如果 U 具有更高的對齊要求，則 src 可能無法適當對齊。
    if align_of::<U>() > align_of::<T>() {
        // 安全: `src` 是一個參考，保證對讀取有效。
        // 調用者必須保證實際的轉換是安全的。
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // 安全: `src` 是一個參考，保證對讀取有效。
        // 我們只是檢查 `src as *const U` 是否正確對齊。
        // 調用者必須保證實際的轉換是安全的。
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// 代表枚舉的不透明類型。
///
/// 有關更多信息，請參見本模塊中的 [`discriminant`] 功能。
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. 無法導出這些 trait 實現，因為我們不需要 T 的任何界限。

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// 返回唯一標識 `v` 中的 enum 變體的值。
///
/// 如果 `T` 不是枚舉，則調用此函數不會導致未定義的行為，但是返回值是未指定的。
///
///
/// # Stability
///
/// 如果枚舉定義更改，則枚舉變量的判別式可能會更改。
/// 在使用相同編譯器的編譯之間，某些變體的判別式不會改變。
///
/// # Examples
///
/// 這可以用來比較攜帶數據的枚舉，而忽略實際數據:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// 返回枚舉類型 `T` 中的變體數。
///
/// 如果 `T` 不是枚舉，則調用此函數不會導致未定義的行為，但是返回值是未指定的。
/// 同樣，如果 `T` 是具有比 `usize::MAX` 更多的變體的枚舉，則未指定返回值。
/// 無人居住的變種將被計算在內。
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}