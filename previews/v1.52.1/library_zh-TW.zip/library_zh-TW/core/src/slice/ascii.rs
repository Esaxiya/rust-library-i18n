//! 在 ASCII `[u8]` 上的操作。

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// 檢查此片中的所有字節是否都在 ASCII 範圍內。
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// 檢查兩個片是否是 ASCII 大小寫不敏感的匹配項。
    ///
    /// 與 `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 相同，但不分配和復制臨時文件。
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// 將此切片原位轉換為其 ASCII 大寫形式。
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不變。
    ///
    /// 要返回新的大寫值而不修改現有值，請使用 [`to_ascii_uppercase`]。
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// 將此切片原位轉換為其 ASCII 小寫等效項。
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不變。
    ///
    /// 要返回新的小寫值而不修改現有值，請使用 [`to_ascii_lowercase`]。
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// 如果單詞 `v` 中的任何字節為 nonascii (>=128)，則返回 `true`。
/// 來自 `../str/mod.rs`，它對 utf8 驗證執行類似的操作。
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// 優化的 ASCII 測試，將使用每次使用一次的操作，而不是一次使用字節的操作 (如果可能)。
///
/// 我們在這裡使用的算法非常簡單。如果 `s` 太短，我們只檢查每個字節並完成它。除此以外:
///
/// - 閱讀未對齊的單詞的第一個單詞。
/// - 對齊指針，讀取後續單詞，直到對齊負載結束。
/// - 從 `s` 讀取未裝載的最後一個 `usize`。
///
/// 如果這些負載中的任何一個產生了 `contains_nonascii` (above) 返回 true 的值，則我們知道答案為 false。
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // 如果我們不能從一次單詞的實現中獲得任何收益，請回到標量循環。
    //
    // 我們還針對 `size_of::<usize>()` 不足以與 `usize` 對齊的體系結構執行此操作，因為這是一種奇怪的 edge 情況。
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // 我們總是讀第一個單詞 unaligned，這意味著 `align_offset` 是
    // 0，對於對齊的讀取，我們將再次讀取相同的值。
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // 安全: 我們驗證上面的 `len < USIZE_SIZE`。
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // 我們在上面對此進行了某種程度的隱式檢查。
    // 請注意，`offset_to_aligned` 是 `align_offset` 或 `USIZE_SIZE`，兩者均在上面進行了明確檢查。
    //
    debug_assert!(offset_to_aligned <= len);

    // 安全: word_ptr 是我們用來讀取
    // 切片的中間塊。
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` 是 `word_ptr` 的字節索引，用於循環結束檢查。
    let mut byte_pos = offset_to_aligned;

    // 偏執狂會檢查對齊情況，因為我們將要進行一堆未對齊的負載。
    // 在實踐中，除非存在 `align_offset` 中的錯誤，否則這應該是不可能的。
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // 讀取後續單詞，直到最後一個對齊的單詞 (不包括最後一個對齊的單詞本身) 要在以後的尾部檢查中進行，以確保尾部始終最多為一個 `usize`，以額外的 branch `byte_pos == len`。
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // 完好無損的檢查，以確保讀取的範圍
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // 並且我們關於 `byte_pos` 的假設成立。
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // 安全: 我們知道 `word_ptr` 正確對齊 (因為
        // `align_offset`)，我們知道 `word_ptr` 和末尾之間有足夠的字節
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // 安全: 我們知道 `byte_pos <= len - USIZE_SIZE`，這意味著
        // 在此 `add` 之後，`word_ptr` 最多只能是最後一個。
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // 進行健全性檢查，確保僅剩 `usize` 個。
    // 這應該由我們的循環條件來保證。
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // 安全: 這取決於 `len >= USIZE_SIZE`，我們將在開始時對其進行檢查。
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}