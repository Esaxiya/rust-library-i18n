//! slice 的迭代器使用的宏。

// 內聯 is_empty 和 len 會產生巨大的性能差異
macro_rules! is_empty {
    // 我們對 ZST 迭代器的長度進行編碼的方式，這對 ZST 和非 ZST 均有效。
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// 為了擺脫某些邊界檢查 (請參閱 `position`)，我們以某種出乎意料的方式來計算長度。
// (通過 `codegen/slice-position-bounds-check` 測試。)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // 我們有時會在不安全的區域內使用

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // 該 _cannot_ 使用 `unchecked_sub`，因為我們依靠包裝來表示長 ZST 切片迭代器的長度。
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // 我們知道 `start <= end` 可以比需要簽名處理的 `offset_from` 做得更好。
            // 通過在此處設置適當的標誌，我們可以告訴 LLVM，這有助於消除邊界檢查。
            // 安全: 通過類型不變， `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // 通過還告訴 LLVM 指針相隔一個類型大小的精確倍數，它可以將 `len() == 0` 優化到 `start == end`，而不是 `(end - start) < size`。
            //
            // 安全: 通過類型不變，指針是對齊的，因此
            //         它們之間的距離必須是指針大小的倍數
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` 和 `IterMut` 迭代器的共享定義
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // 返回第一個元素，並將迭代器的開始向前移動 1。
        // 與內聯函數相比，極大地提高了性能。
        // 迭代器不能為空。
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // 返回最後一個元素，並將迭代器的末尾向後移動 1。
        // 與內聯函數相比，極大地提高了性能。
        // 迭代器不能為空。
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // 當 T 為 ZST 時，通過將迭代器的末尾向後移動 `n` 來縮小迭代器。
        // `n` 不得超過 `self.len()`。
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // 用於從迭代器創建切片的 Helper 函數。
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // 安全: 迭代器是從帶指針的切片創建的
                // `self.ptr` 和長度 `len!(self)`。
                // 這樣可以保證滿足 `from_raw_parts` 的所有先決條件。
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Helper 函數，用於通過 `offset` 元素向前移動迭代器的開始，並返回舊的開始。
            //
            // 不安全，因為偏移不得超過 `self.len()`。
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // 安全: 调用者保證 `offset` 不超過 `self.len()`，
                    // 因此此新指針位於 `self` 內，因此保證為非空。
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Helper 函數，用於通過 `offset` 元素向後移動迭代器的末尾，並返回新的末尾。
            //
            // 不安全，因為偏移不得超過 `self.len()`。
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // 安全: 调用者保證 `offset` 不超過 `self.len()`，
                    // 保證不會溢出 `isize`。
                    // 同樣，結果指針位於 `slice` 的範圍內，這滿足了 `offset` 的其他要求。
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // 可以用切片實現，但這避免了邊界檢查

                // 安全性: `assume` 調用是安全的，因為切片的開始指針
                // 必須為非 null，並且非 ZST 上的切片還必須具有非 null 結束指針。
                // 調用 `next_unchecked!` 是安全的，因為我們先檢查迭代器是否為空。
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // 該迭代器現在為空。
                    if mem::size_of::<T>() == 0 {
                        // 我們必須這樣做，因為 `ptr` 可能永遠不會為 0，但 `end` 可能是 (由於包裝)。
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // 安全: 如果 T 不是 ZST，則 end 不能為 0，因為 ptr 不為 0 並且 end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // 安全: 我們無可厚非。`post_inc_start` 甚至對 ZST 來說都是正確的。
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // 我們覆蓋了使用 `try_fold` 的默認實現，因為此簡單實現生成的 LLVM IR 更少，並且編譯速度更快。
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // 我們覆蓋了使用 `try_fold` 的默認實現，因為此簡單實現生成的 LLVM IR 更少，並且編譯速度更快。
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // 我們覆蓋了使用 `try_fold` 的默認實現，因為此簡單實現生成的 LLVM IR 更少，並且編譯速度更快。
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // 我們覆蓋了使用 `try_fold` 的默認實現，因為此簡單實現生成的 LLVM IR 更少，並且編譯速度更快。
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // 我們覆蓋了使用 `try_fold` 的默認實現，因為此簡單實現生成的 LLVM IR 更少，並且編譯速度更快。
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // 我們覆蓋了使用 `try_fold` 的默認實現，因為此簡單實現生成的 LLVM IR 更少，並且編譯速度更快。
            // 另外，`assume` 避免了邊界檢查。
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // 安全: 我們保證不受循環不變的約束:
                        // 當 `i >= n` 時，`self.next()` 返回 `None`，循環中斷。
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // 我們覆蓋了使用 `try_fold` 的默認實現，因為此簡單實現生成的 LLVM IR 更少，並且編譯速度更快。
            // 另外，`assume` 避免了邊界檢查。
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // 安全: `i` 必須低於 `n`，因為它始於 `n`
                        // 並且僅在減少。
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // 安全: 调用者必須保證 `i` 在以下範圍內
                // 基礎切片，因此 `i` 不會溢出 `isize`，並且保證返回的引用引用切片的元素，從而保證有效。
                //
                // 還要注意，調用者還保證不會再使用相同的索引調用我們，並且不會調用將訪問此子片段的其他方法，因此對於以下情況，返回的引用可變是有效的:
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // 可以用切片實現，但這避免了邊界檢查

                // 安全性: `assume` 調用是安全的，因為切片的開始指針必須為非空，
                // 非 ZST 上的分片也必須具有非空的結束指針。
                // 調用 `next_back_unchecked!` 是安全的，因為我們先檢查迭代器是否為空。
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // 該迭代器現在為空。
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // 安全: 我們無可厚非。`pre_dec_end` 甚至對 ZST 來說也做對了。
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}