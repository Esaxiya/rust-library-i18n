// ignore-tidy-filelength

//! 切片管理和操作。
//!
//! 有關更多詳細信息，請參見 [`std::slice`]。
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// 純粹的 rust memchr 實現，取自 rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// 此功能僅是公開的，因為沒有其他方法可以對堆排序進行單元測試。
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// 返回切片中的元素數。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // 安全: const 聲音是因為我們將長度字段轉換為 usize (必須是它)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // 安全: 這是安全的，因為 `&[T]` 和 `FatPtr<T>` 具有相同的佈局。
            // 只有 `std` 可以做出此保證。
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: 當 `crate::ptr::metadata(self)` 穩定時，替換為 `crate::ptr::metadata(self)`。
            // 在撰寫本文時，這將導致 "Const-stable functions can only call other const-stable functions" 錯誤。
            //

            // 安全: 由於 * const T，從 `PtrRepr` 聯合訪問值很安全。
            // 和 PtrComponents<T> 具有相同的內存佈局。
            // 只有 std 可以做出此保證。
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// 如果切片的長度為 0，則返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 返回切片的第一個元素; 如果為空，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// 返回指向切片的第一個元素的可變指針; 如果為空，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// 返回切片的第一個和所有其他元素，如果為空，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// 返回切片的第一個和所有其他元素，如果為空，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// 返回切片的最後一個元素和所有其餘元素; 如果為空，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// 返回切片的最後一個元素和所有其餘元素; 如果為空，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// 返回切片的最後一個元素; 如果為空，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// 返回指向切片中最後一項的可變指針。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// 根據索引類型返回對元素或子切片的引用。
    ///
    /// - 如果給定位置，則返回對該位置處元素的引用; 如果超出範圍，則返回 `None`。
    ///
    /// - 如果給定範圍，則返回對應於該範圍的子切片; 如果超出範圍，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// 根據索引的類型 (請參閱 [`get`]) 或 `None` (如果索引超出範圍)，返回對元素或子切片的可變引用。
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// 返回對元素或子切片的引用，而不進行邊界檢查。
    ///
    /// 有關安全的選擇，請參閱 [`get`]。
    ///
    /// # Safety
    ///
    /// 即使未使用生成的引用，使用越界索引調用此方法也是 *[undefined behavior]*。
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // 安全: 调用者必須遵守 `get_unchecked` 的大多數安全要求;
        // 該切片是可取消引用的，因為 `self` 是安全的引用。
        // 返回的指針是安全的，因為 `SliceIndex` 的 impls 必須保證它是正確的。
        unsafe { &*index.get_unchecked(self) }
    }

    /// 返回對元素或子切片的可變引用，而不進行邊界檢查。
    ///
    /// 有關安全的選擇，請參閱 [`get_mut`]。
    ///
    /// # Safety
    ///
    /// 即使未使用生成的引用，使用越界索引調用此方法也是 *[undefined behavior]*。
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // 安全: 调用者必須遵守 `get_unchecked_mut` 的安全要求;
        // 該切片是可取消引用的，因為 `self` 是安全的引用。
        // 返回的指針是安全的，因為 `SliceIndex` 的 impls 必須保證它是正確的。
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// 返回指向切片緩衝區的原始指針。
    ///
    /// 調用者必須確保該切片比該函數返回的指針還有效，否則它將最終指向垃圾。
    ///
    /// 調用者還必須確保指針 (non-transitively) 所指向的內存 (從 `UnsafeCell` 內部除外) 永遠不會使用此指針或從其派生的任何指針寫入。
    /// 如果需要突變切片的內容，請使用 [`as_mut_ptr`]。
    ///
    /// 修改此片所引用的容器可能導致其緩衝區被重新分配，這也將使指向它的任何指針無效。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// 返回指向切片緩衝區的不安全的可變指針。
    ///
    /// 調用者必須確保該切片比該函數返回的指針還有效，否則它將最終指向垃圾。
    ///
    /// 修改此片所引用的容器可能導致其緩衝區被重新分配，這也將使指向它的任何指針無效。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// 返回跨越切片的兩個原始指針。
    ///
    /// 返回的範圍是半開的，這意味著結束指針指向片的最後一個元素 *一個*。
    /// 這樣，空切片由兩個相等的指針表示，兩個指針之間的差表示切片的大小。
    ///
    /// 有關使用這些指針的警告，請參見 [`as_ptr`]。結束指針需要格外小心，因為它沒有指向切片中的有效元素。
    ///
    /// 此功能對於與外部接口進行交互很有用，該外部接口使用兩個指針來引用內存中的一系列元素，這在 C++ 中很常見。
    ///
    ///
    /// 檢查指向元素的指針是否引用了此 slice 的元素，這也可能很有用:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // 安全: 這裡的 `add` 是安全的，因為:
        //
        //   - 兩個指針都是同一對象的一部分，因為直接指向該對象的指針也很重要。
        //
        //   - 切片的大小永遠不會大於 isize::MAX 字節，如下所示:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - 沒有切片環繞，因為切片不會環繞地址空間的末尾。
        //
        // 請參閱 pointer::add 的文檔。
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// 返回跨越切片的兩個不安全的可變指針。
    ///
    /// 返回的範圍是半開的，這意味著結束指針指向片的最後一個元素 *一個*。
    /// 這樣，空切片由兩個相等的指針表示，兩個指針之間的差表示切片的大小。
    ///
    /// 有關使用這些指針的警告，請參見 [`as_mut_ptr`]。
    /// 結束指針需要格外小心，因為它沒有指向切片中的有效元素。
    ///
    /// 此功能對於與外部接口進行交互很有用，該外部接口使用兩個指針來引用內存中的一系列元素，這在 C++ 中很常見。
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // 安全: 有關此處 `add` 為何安全的信息，請參見上面的 as_ptr_range()。
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// 交換切片中的兩個元素。
    ///
    /// # Arguments
    ///
    /// * a，第一個元素的索引
    /// * b，第二個元素的索引
    ///
    /// # Panics
    ///
    /// 如果 `a` 或 `b` 超出範圍，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // 不能從一個 vector 借兩筆可變貸款，因此請使用原始指針。
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // 安全: `pa` 和 `pb` 是根據安全的可變引用創建的，
        // 到切片中的元素，因此保證是有效且對齊的。
        // 請注意，將檢查訪問 `a` 和 `b` 後面的元素，並且超出範圍時將訪問 panic。
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// 適當地反轉切片中元素的順序。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // 對於非常小的類型，正常路徑中的所有單個讀取均表現不佳。
        // 給定有效的未對齊 load/store，我們可以通過加載更大的塊並反轉寄存器來做得更好。
        //

        // 理想情況下，LLVM 會為我們做到這一點，因為它比我們更了解未對齊的讀取是否有效 (例如，由於不同 ARM 版本之間的變化) 以及最佳塊大小是什麼。
        // 不幸的是，從 LLVM 4.0 (2017-05) 開始，它僅展開循環，因此我們需要自己做。
        // (假設: 反向是麻煩的，因為當長度為奇數時，邊的對齊方式可能會有所不同 - 因此，無法在中間使用完全對齊的 SIMD 發出前奏和後奏的方式。)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // 使用 llvm.bswap 內在函數在 usize 中反轉 u8
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // 安全: 這裡有幾件事要檢查:
                //
                // - 請注意，由於上述 cfg 檢查，`chunk` 為 4 或 8。因此，`chunk - 1` 為正。
                // - 使用索引 `i` 進行索引可以很好地進行循環檢查
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`。
                // - 索引為 `ln - i - chunk = ln - (i + chunk)` 的索引很好:
                //   - `i + chunk > 0` 確實是對的。
                //   - 循環檢查保證:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`，因此減法不會下溢。
                // - `read_unaligned` 和 `write_unaligned` 調用很好:
                //   - `pa` 指向索引 `i`，其中 `i < ln / 2 - (chunk - 1)` (參見上文) 和 `pb` 指向索引 `ln - i - chunk`，因此兩者都至少相距 `self` 末尾多個字節 `chunk`。
                //
                //   - 任何初始化的內存都是有效的 `usize`。
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // 使用 X16 旋轉以反轉 u32 中的 u16
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // 安全: 如果 `i + 1 < ln` 可以從 `i` 讀取未對齊的 u32
                // (顯然是 `i < ln`)，因為每個元素都是 2 個字節，我們正在讀取 4。
                //
                // `i + chunk - 1 < ln / 2` # 條件
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // 由於它小於長度除以 2 的長度，因此它必須是有界的。
                //
                // 這也意味著始終要遵守條件 `0 < i + chunk <= ln`，以確保可以安全地使用 `pb` 指針。
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // 安全: `i` 不及切片長度的一半，因此
            // 安全地訪問 `i` 和 `ln - i - 1` (`i` 從 0 開始並且不會比 `ln / 2 - 1` 更遠)。
            // 因此，生成的指針 `pa` 和 `pb` 是有效的並且已對齊，並且可以從中讀取和寫入。
            //
            //
            unsafe {
                // 不安全交換以避免邊界檢查安全交換。
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// 返回切片上的迭代器。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// 返回允許修改每個值的迭代器。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// 返回長度為 `size` 的所有連續 windows 上的迭代器。
    /// windows 重疊。
    /// 如果切片比 `size` 短，則迭代器不返回任何值。
    ///
    /// # Panics
    ///
    /// 如果 `size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果切片比 `size` 短:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// 從分片的開頭開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是切片，並且不重疊。如果 `chunk_size` 未劃分切片的長度，則最後一塊的長度將不為 `chunk_size`。
    ///
    /// 有關此迭代器的變體，請參見 [`chunks_exact`]，該變體始終返回完全相同的 `chunk_size` 元素的塊，而對於相同的迭代器，則從切片的末尾開始返回 [`rchunks`]。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// 從分片的開頭開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是可變切片，並且不重疊。如果 `chunk_size` 未劃分切片的長度，則最後一塊的長度將不為 `chunk_size`。
    ///
    /// 有關此迭代器的變體，請參見 [`chunks_exact_mut`]，該變體始終返回完全相同的 `chunk_size` 元素的塊，而對於相同的迭代器，則從切片的末尾開始返回 [`rchunks_mut`]。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// 從分片的開頭開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是切片，並且不重疊。
    /// 如果 `chunk_size` 不分割切片的長度，則最後 `chunk_size-1` 個元素將被省略，並可從迭代器的 `remainder` 函數中檢索。
    ///
    ///
    /// 由於每個塊都具有完全 `chunk_size` 元素，因此與 [`chunks`] 相比，編譯器通常可以更好地優化結果代碼。
    ///
    /// 有關此迭代器的變體，請參見 [`chunks`]，它也將其餘部分作為較小的塊返回，而對於相同的迭代器，請從 [`rchunks_exact`] 返回，但從切片的末尾開始。
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// 從分片的開頭開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是可變切片，並且不重疊。
    /// 如果 `chunk_size` 不分割切片的長度，則最後 `chunk_size-1` 個元素將被省略，並可從迭代器的 `into_remainder` 函數中檢索。
    ///
    ///
    /// 由於每個塊都具有完全 `chunk_size` 元素，因此與 [`chunks_mut`] 相比，編譯器通常可以更好地優化結果代碼。
    ///
    /// 有關此迭代器的變體，請參見 [`chunks_mut`]，它也將其餘部分作為較小的塊返回，而對於相同的迭代器，請從 [`rchunks_exact_mut`] 返回，但從切片的末尾開始。
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// 假定沒有餘數，將切片拆分為 N 個元素數組的切片。
    ///
    ///
    /// # Safety
    ///
    /// 只能在以下情況下調用
    /// - 切片精確地分為 `N` 個元素塊 (也稱為 `self.len() % N == 0`)。
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // 安全: 1 個元素塊永遠不會剩餘
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // 安全: 切片長度 (6) 是 3 的倍數
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // 這些是不合理的:
    /// // 讓大塊:＆[[_;5]]= slice.as_chunks_unchecked()// 切片長度不是 5 個 let 塊的倍數:＆[[_;0]]= slice.as_chunks_unchecked()// 永遠不允許零長度的塊
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // 安全: 我們的先決條件就是稱呼它的必要條件
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // 安全: 我們將 `new_len * N` 元素切片放入
        // `new_len` 的一部分，包含許多 `N` 元素塊。
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// 從分片的開頭開始，將分片拆分為 N 個元素數組的分片，其餘分片的長度嚴格小於 `N`。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 為 0，則為 Panics。在此方法穩定之前，此檢查很可能會更改為編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // 安全: 我們已經為零感到恐慌，並通過施工確保了這一點
        // 子片的長度是 N 的倍數。
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// 從分片的末尾開始，將分片拆分為一個 N 個元素數組的分片，然後將其長度嚴格小於 `N` 的其餘分片。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 為 0，則為 Panics。在此方法穩定之前，此檢查很可能會更改為編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // 安全: 我們已經為零感到恐慌，並通過施工確保了這一點
        // 子片的長度是 N 的倍數。
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// 從分片的開頭開始，一次返回對分片的 `N` 元素的迭代器。
    ///
    /// 塊是數組引用，並且不重疊。
    /// 如果 `N` 不分割切片的長度，則最後 `N-1` 個元素將被省略，並可從迭代器的 `remainder` 函數中檢索。
    ///
    ///
    /// 此方法是 [`chunks_exact`] 的 const 泛型等效項。
    ///
    /// # Panics
    ///
    /// 如果 `N` 為 0，則為 Panics。在此方法穩定之前，此檢查很可能會更改為編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// 假定沒有餘數，將切片拆分為 N 個元素數組的切片。
    ///
    ///
    /// # Safety
    ///
    /// 只能在以下情況下調用
    /// - 切片精確地分為 `N` 個元素塊 (也稱為 `self.len() % N == 0`)。
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // 安全: 1 個元素塊永遠不會剩餘
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // 安全: 切片長度 (6) 是 3 的倍數
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // 這些是不合理的:
    /// // 讓大塊:＆[[_;5]]= slice.as_chunks_unchecked_mut()// 切片長度不是 5 個 let 塊的倍數:＆[[_;0]]= slice.as_chunks_unchecked_mut()// 永遠不允許零長度的塊
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // 安全: 我們的先決條件就是稱呼它的必要條件
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // 安全: 我們將 `new_len * N` 元素切片放入
        // `new_len` 的一部分，包含許多 `N` 元素塊。
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// 從分片的開頭開始，將分片拆分為 N 個元素數組的分片，其餘分片的長度嚴格小於 `N`。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 為 0，則為 Panics。在此方法穩定之前，此檢查很可能會更改為編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // 安全: 我們已經為零感到恐慌，並通過施工確保了這一點
        // 子片的長度是 N 的倍數。
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// 從分片的末尾開始，將分片拆分為一個 N 個元素數組的分片，然後將其長度嚴格小於 `N` 的其餘分片。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `N` 為 0，則為 Panics。在此方法穩定之前，此檢查很可能會更改為編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // 安全: 我們已經為零感到恐慌，並通過施工確保了這一點
        // 子片的長度是 N 的倍數。
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// 從分片的開頭開始，一次返回對分片的 `N` 元素的迭代器。
    ///
    /// 塊是可變數組引用，並且不重疊。
    /// 如果 `N` 不分割切片的長度，則最後 `N-1` 個元素將被省略，並可從迭代器的 `into_remainder` 函數中檢索。
    ///
    ///
    /// 此方法是 [`chunks_exact_mut`] 的 const 泛型等效項。
    ///
    /// # Panics
    ///
    /// 如果 `N` 為 0，則為 Panics。在此方法穩定之前，此檢查很可能會更改為編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// 從切片的開頭開始，在切片的 `N` 元素的重疊 windows 上返回迭代器。
    ///
    ///
    /// 這是 [`windows`] 的 const 泛型等效項。
    ///
    /// 如果 `N` 大於切片的大小，它將不返回 windows。
    ///
    /// # Panics
    ///
    /// 如果 `N` 為 0，則為 Panics。
    /// 在此方法穩定之前，此檢查很可能會更改為編譯時錯誤。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// 從分片的末尾開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是切片，並且不重疊。如果 `chunk_size` 未劃分切片的長度，則最後一塊的長度將不為 `chunk_size`。
    ///
    /// 有關此迭代器的變體，請參見 [`rchunks_exact`]，該變體始終返回完全相同的 `chunk_size` 元素的塊，而對於相同的迭代器，則從切片的開頭開始返回 [`chunks`]。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// 從分片的末尾開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是可變切片，並且不重疊。如果 `chunk_size` 未劃分切片的長度，則最後一塊的長度將不為 `chunk_size`。
    ///
    /// 有關此迭代器的變體，請參見 [`rchunks_exact_mut`]，該變體始終返回完全相同的 `chunk_size` 元素的塊，而對於相同的迭代器，則從切片的開頭開始返回 [`chunks_mut`]。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// 從分片的末尾開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是切片，並且不重疊。
    /// 如果 `chunk_size` 不分割切片的長度，則最後 `chunk_size-1` 個元素將被省略，並可從迭代器的 `remainder` 函數中檢索。
    ///
    /// 由於每個塊都具有完全 `chunk_size` 元素，因此與 [`chunks`] 相比，編譯器通常可以更好地優化結果代碼。
    ///
    /// 有關此迭代器的變體，請參見 [`rchunks`]，它也將其餘部分作為較小的塊返回，而對於相同的迭代器，請從 [`chunks_exact`] 返回，但從切片的開頭開始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// 從分片的末尾開始，一次返回對分片的 `chunk_size` 元素的迭代器。
    ///
    /// 塊是可變切片，並且不重疊。
    /// 如果 `chunk_size` 不分割切片的長度，則最後 `chunk_size-1` 個元素將被省略，並可從迭代器的 `into_remainder` 函數中檢索。
    ///
    /// 由於每個塊都具有完全 `chunk_size` 元素，因此與 [`chunks_mut`] 相比，編譯器通常可以更好地優化結果代碼。
    ///
    /// 有關此迭代器的變體，請參見 [`rchunks_mut`]，它也將其餘部分作為較小的塊返回，而對於相同的迭代器，請從 [`chunks_exact_mut`] 返回，但從切片的開頭開始。
    ///
    ///
    /// # Panics
    ///
    /// 如果 `chunk_size` 為 0，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// 在切片上返回一個迭代器，該迭代器使用謂詞將元素分隔開，從而生成元素的不重疊遊程。
    ///
    /// 謂詞在緊隨其後的兩個元素上調用，這意味著謂詞在 `slice[0]` 和 `slice[1]` 上調用，然後在 `slice[1]` 和 `slice[2]` 上調用，依此類推。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 此方法可用於提取排序的子切片:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// 在切片上返回一個迭代器，使用謂詞將元素分開，從而生成不重疊的可變元素遊程。
    ///
    /// 謂詞在緊隨其後的兩個元素上調用，這意味著謂詞在 `slice[0]` 和 `slice[1]` 上調用，然後在 `slice[1]` 和 `slice[2]` 上調用，依此類推。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 此方法可用於提取排序的子切片:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// 將一個索引一分為二。
    ///
    /// 第一個將包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二個將包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// # Panics
    ///
    /// 如果為 `mid > len`，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // 安全性: `[ptr; mid]` 和 `[mid; len]` 在 `self` 內部，
        // 滿足 `from_raw_parts_mut` 的要求。
        unsafe { self.split_at_unchecked(mid) }
    }

    /// 在一個索引處將一個可變切片分為兩部分。
    ///
    /// 第一個將包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二個將包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// # Panics
    ///
    /// 如果為 `mid > len`，則為 Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // 安全性: `[ptr; mid]` 和 `[mid; len]` 在 `self` 內部，
        // 滿足 `from_raw_parts_mut` 的要求。
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// 在索引處將一個切片分為兩部分，而無需進行邊界檢查。
    ///
    /// 第一個將包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二個將包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// 有關安全的選擇，請參閱 [`split_at`]。
    ///
    /// # Safety
    ///
    /// 即使未使用生成的引用，使用越界索引調用此方法也是 *[undefined behavior]*。调用者必須確保 `0 <= mid <= self.len()`。
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // 安全: 调用者必須檢查 `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// 在一個索引處將一個可變切片分為兩個，而無需進行邊界檢查。
    ///
    /// 第一個將包含 `[0, mid)` 的所有索引 (不包括索引 `mid` 本身)，第二個將包含 `[mid, len)` 的所有索引 (不包括索引 `len` 本身)。
    ///
    ///
    /// 有關安全的選擇，請參閱 [`split_at_mut`]。
    ///
    /// # Safety
    ///
    /// 即使未使用生成的引用，使用越界索引調用此方法也是 *[undefined behavior]*。调用者必須確保 `0 <= mid <= self.len()`。
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // 安全: 调用者必須檢查 `0 <= mid <= self.len()`。
        //
        // `[ptr; mid]` 和 `[mid; len]` 不重疊，因此返回可變引用是可以的。
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// 返回由與 `pred` 匹配的元素分隔的子切片上的迭代器。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果第一個元素匹配，則空切片將是迭代器返回的第一項。
    /// 同樣，如果切片中的最後一個元素匹配，則空切片將是迭代器返回的最後一個項目:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果兩個匹配的元素直接相鄰，則它們之間將出現一個空切片:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// 返回一個可變變量的迭代器，該可變變量由與 `pred` 匹配的元素分隔。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// 返回由與 `pred` 匹配的元素分隔的子切片上的迭代器。
    /// 匹配的元素包含在上一個子切片的末尾作為終止符。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// 如果切片的最後一個元素匹配，則該元素將被視為前一個切片的終止符。
    ///
    /// 該切片將是迭代器返回的最後一個項目。
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// 返回一個可變變量的迭代器，該可變變量由與 `pred` 匹配的元素分隔。
    /// 匹配的元素作為終止符包含在先前的子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// 在子切片上返回迭代器，該子切片由與 `pred` 匹配的元素分隔，從切片的末尾開始並向後工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 與 `split()` 一樣，如果第一個或最後一個元素匹配，則空切片將是迭代器返回的第一個 (或最後一個) 項目。
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// 在可變子切片上返回一個迭代器，該子切片由與 `pred` 匹配的元素分隔，從切片的末尾開始並向後工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// 在子切片上返回一個迭代器，該子切片由與 `pred` 匹配的元素分隔，限於最多返回 `n` 項。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最後一個元素 (如果有) 將包含切片的其餘部分。
    ///
    /// # Examples
    ///
    /// 按除以 3 的數字 (即 `[10, 40]`，`[20, 60, 50]`) 打印一次分割的切片:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// 在子切片上返回一個迭代器，該子切片由與 `pred` 匹配的元素分隔，限於最多返回 `n` 項。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最後一個元素 (如果有) 將包含切片的其餘部分。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// 在子切片上返回一個迭代器，該子切片由與 `pred` 匹配的元素分隔，最多只能返回 `n` 項。
    /// 這從切片的末尾開始，然後向後工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最後一個元素 (如果有) 將包含切片的其餘部分。
    ///
    /// # Examples
    ///
    /// 從末尾開始，將切片分割打印一次，分割為 3 的數字 (即 `[50]`，`[10, 40, 30, 20]`) :
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// 在子切片上返回一個迭代器，該子切片由與 `pred` 匹配的元素分隔，最多只能返回 `n` 項。
    /// 這從切片的末尾開始，然後向後工作。
    /// 匹配的元素不包含在子切片中。
    ///
    /// 返回的最後一個元素 (如果有) 將包含切片的其餘部分。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// 如果切片包含具有給定值的元素，則返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// 如果您沒有 `&T`，而只有 `&U` 這樣的 `T: Borrow<U>` (例如
    /// `String: 借用 <str>`)，則可以使用 `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` 的切片
    /// assert!(v.iter().any(|e| e == "hello")); // 用 `&str` 搜索
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// 如果 `needle` 是切片的前綴，則返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// 如果 `needle` 為空片，則始終返回 `true`:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// 如果 `needle` 是切片的後綴，則返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// 如果 `needle` 為空片，則始終返回 `true`:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// 返回帶有刪除的前綴的子切片。
    ///
    /// 如果切片以 `prefix` 開頭，則返回前綴在 `Some` 中的子切片。
    /// 如果 `prefix` 為空，則僅返回原始切片。
    ///
    /// 如果切片不是以 `prefix` 開頭，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // 如果 SlicePattern 變得更加複雜，則此函數將需要重寫。
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// 返回刪除後綴的子分片。
    ///
    /// 如果切片以 `suffix` 結尾，則返回後綴在 `Some` 中的子切片。
    /// 如果 `suffix` 為空，則僅返回原始切片。
    ///
    /// 如果切片不以 `suffix` 結尾，則返回 `None`。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // 如果 SlicePattern 變得更加複雜，則此函數將需要重寫。
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// 二進制在此排序的切片上搜索給定的元素。
    ///
    /// 如果找到該值，則返回 [`Result::Ok`]，其中包含匹配元素的索引。
    /// 如果有多個匹配項，則可以返回任何一個匹配項。
    /// 如果找不到該值，則返回 [`Result::Err`]，其中包含在保留排序順序的同時可以在其中插入匹配元素的索引。
    ///
    ///
    /// 另請參見 [`binary_search_by`]，[`binary_search_by_key`] 和 [`partition_point`]。
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 查找一系列四個元素。
    /// 找到第一個，具有唯一確定的位置; 找不到第二和第三個; 第四個可以匹配 `[1, 4]` 中的任何位置。
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// 如果要在排序順序為 vector 的情況下插入項目，同時保持排序順序，請執行以下操作:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// 二進制使用比較器功能搜索此排序的片。
    ///
    /// 比較器函數應實現與基礎切片的排序順序一致的順序，並返回指示其參數是所需目標的 `Less`，`Equal` 還是 `Greater` 的順序代碼。
    ///
    ///
    /// 如果找到該值，則返回 [`Result::Ok`]，其中包含匹配元素的索引。如果有多個匹配項，則可以返回任何一個匹配項。
    /// 如果找不到該值，則返回 [`Result::Err`]，其中包含在保留排序順序的同時可以在其中插入匹配元素的索引。
    ///
    /// 另請參見 [`binary_search`]，[`binary_search_by_key`] 和 [`partition_point`]。
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 查找一系列四個元素。找到第一個，具有唯一確定的位置; 找不到第二和第三個; 第四個可以匹配 `[1, 4]` 中的任何位置。
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // 安全: 通過以下不變式可以確保通話安全:
            // - `mid >= 0`
            // - `mid < size`: `mid` 受 `[left; right)` 限制。
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // 我們之所以使用 if/else 控制流而不是 match 的原因是因為 match 對性能比較敏感的比較操作進行重新排序。
            //
            // 這是 u8 的 x86 ASM: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary 使用密鑰提取功能搜索此排序的切片。
    ///
    /// 假定按鍵對切片進行排序，例如使用相同的鍵提取功能對 [`sort_by_key`] 進行排序。
    ///
    /// 如果找到該值，則返回 [`Result::Ok`]，其中包含匹配元素的索引。
    /// 如果有多個匹配項，則可以返回任何一個匹配項。
    /// 如果找不到該值，則返回 [`Result::Err`]，其中包含在保留排序順序的同時可以在其中插入匹配元素的索引。
    ///
    ///
    /// 另請參見 [`binary_search`]，[`binary_search_by`] 和 [`partition_point`]。
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// 在成對的切片中按其第二個元素排序的一系列四個元素中查找。
    /// 找到第一個，具有唯一確定的位置; 找不到第二和第三個; 第四個可以匹配 `[1, 4]` 中的任何位置。
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // 允許使用 Lint rustdoc::broken_intra_doc_links，因為 `slice::sort_by_key` 在 crate `alloc` 中，因此在構建 `core` 時尚不存在。
    //
    // 鏈接到下游 crate: #74481。由於原語僅在 libstd (#73423) 中記錄，因此在實踐中絕不會導致鏈接斷開。
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// 對切片進行排序，但可能不保留相等元素的順序。
    ///
    /// 這種排序是不穩定的 (即可能重新排序相等的元素)，就地 (即不分配) 和 *O*(*n*\*log(* n*)) 最壞的情況)。
    ///
    /// # 當前實施
    ///
    /// 當前算法基於 Orson Peters 的 [pattern-defeating quicksort][pdqsort]，該算法將隨機快速排序的快速平均情況與堆排序的快速最壞情況相結合，同時在具有特定模式的切片上實現了線性時間。
    /// 它使用一些隨機化來避免退化的情況，但是使用固定的 seed 來始終提供確定性的行為。
    ///
    /// 除了在一些特殊情況下 (例如，當切片由幾個串聯的排序序列組成時)，它通常比穩定排序快。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// 使用比較器函數對切片進行排序，但可能不會保留相等元素的順序。
    ///
    /// 這種排序是不穩定的 (即可能重新排序相等的元素)，就地 (即不分配) 和 *O*(*n*\*log(* n*)) 最壞的情況)。
    ///
    /// 比較器功能必須定義切片中元素的總順序。如果順序不是總計，則未指定元素的順序。如果訂單是訂單 (對於所有 `a`，`b` 和 `c`)，則為總訂單:
    ///
    /// * 完全和反對稱的: `a < b`，`a == b` 或 `a > b` 之一正確，並且
    /// * 可傳遞的，`a < b` 和 `b < c` 表示 `a < c`。`==` 和 `>` 必須保持相同。
    ///
    /// 例如，雖然 [`f64`] 由於 `NaN != NaN` 而不實現 [`Ord`]，但是當我們知道切片不包含 `NaN` 時，可以將 `partial_cmp` 用作我們的排序函數。
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # 當前實施
    ///
    /// 當前算法基於 Orson Peters 的 [pattern-defeating quicksort][pdqsort]，該算法將隨機快速排序的快速平均情況與堆排序的快速最壞情況相結合，同時在具有特定模式的切片上實現了線性時間。
    /// 它使用一些隨機化來避免退化的情況，但是使用固定的 seed 來始終提供確定性的行為。
    ///
    /// 除了在一些特殊情況下 (例如，當切片由幾個串聯的排序序列組成時)，它通常比穩定排序快。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // 反向排序
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// 使用鍵提取功能對切片進行排序，但可能不會保留相等元素的順序。
    ///
    /// 這種排序是不穩定的 (即可能重新排序相等的元素)，就地 (即不分配) 和 *O*(m\* * n *\* log(*n*)) 最壞的情況，其中鍵函數為 *O*(*m*)。
    ///
    /// # 當前實施
    ///
    /// 當前算法基於 Orson Peters 的 [pattern-defeating quicksort][pdqsort]，該算法將隨機快速排序的快速平均情況與堆排序的快速最壞情況相結合，同時在具有特定模式的切片上實現了線性時間。
    /// 它使用一些隨機化來避免退化的情況，但是使用固定的 seed 來始終提供確定性的行為。
    ///
    /// 由於其鍵調用策略，在鍵功能昂貴的情況下，[`sort_unstable_by_key`](#method.sort_unstable_by_key) 可能比 [`sort_by_cached_key`](#method.sort_by_cached_key) 慢。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// 重新排列切片，使 `index` 處的元素處於其最終排序位置。
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// 使用比較器功能對切片進行重新排序，以使 `index` 處的元素處於其最終排序位置。
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// 使用鍵提取功能對切片進行重新排序，以使 `index` 處的元素處於其最終排序位置。
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// 重新排列切片，使 `index` 處的元素處於其最終排序位置。
    ///
    /// 此重新排序具有附加屬性，即位置 `i < index` 處的任何值將小於或等於位置 `j > index` 處的任何值。
    /// 此外，這種重新排序是不穩定的 (即
    /// 任何數量的相等元素都可以在位置 `index` 處就位 (即
    /// 不分配)，以及 *O*(*n*) 最壞的情況。
    /// 在其他庫中，此功能也被稱為 "kth element"。
    /// 它返回以下值的三元組: 所有元素在給定索引處小於一個，在給定索引處的值，以及所有在給定索引處大於一個的元素。
    ///
    ///
    /// # 當前實施
    ///
    /// 當前算法基於用於 [`sort_unstable`] 的相同 quicksort 算法的 quickselect 部分。
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 時為 Panics，這意味著在空片上始終為 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 求中位數
    /// v.select_nth_unstable(2);
    ///
    /// // 根據我們對指定索引的排序方式，我們僅保證切片將是以下內容之一。
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// 使用比較器功能對切片進行重新排序，以使 `index` 處的元素處於其最終排序位置。
    ///
    /// 此重新排序具有附加屬性，即使用比較器功能，位置 `i < index` 處的任何值將小於或等於位置 `j > index` 處的任何值。
    /// 另外，這種重新排序是不穩定的 (即，任意數量的相等元素可能會在位置 `index` 處結束)，就地 (即，未分配) 和 *O*(*n*) 最壞的情況。
    /// 此功能在其他庫中也稱為 "kth element"。
    /// 它使用提供的比較器函數返回以下值的三元組: 所有元素小於給定索引處的元素，給定索引處的值以及所有元素大於給定索引處的元素。
    ///
    ///
    /// # 當前實施
    ///
    /// 當前算法基於用於 [`sort_unstable`] 的相同 quicksort 算法的 quickselect 部分。
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 時為 Panics，這意味著在空片上始終為 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 查找中位數，就好像切片按降序排序一樣。
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // 根據我們對指定索引的排序方式，我們僅保證切片將是以下內容之一。
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// 使用鍵提取功能對切片進行重新排序，以使 `index` 處的元素處於其最終排序位置。
    ///
    /// 此重新排序具有附加屬性，即使用密鑰提取功能，位置 `i < index` 處的任何值都將小於或等於位置 `j > index` 處的任何值。
    /// 另外，這種重新排序是不穩定的 (即，任意數量的相等元素可能會在位置 `index` 處結束)，就地 (即，未分配) 和 *O*(*n*) 最壞的情況。
    /// 此功能在其他庫中也稱為 "kth element"。
    /// 它使用提供的鍵提取函數返回以下值的三元組: 所有元素都小於給定索引處的元素，給定索引處的值以及所有元素都大於給定索引處的元素。
    ///
    ///
    /// # 當前實施
    ///
    /// 當前算法基於用於 [`sort_unstable`] 的相同 quicksort 算法的 quickselect 部分。
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` 時為 Panics，這意味著在空片上始終為 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // 返回中值，就好像數組是根據絕對值排序的一樣。
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // 根據我們對指定索引的排序方式，我們僅保證切片將是以下內容之一。
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// 根據 [`PartialEq`] trait 實現，將所有連續的重複元素移動到切片的末尾。
    ///
    ///
    /// 返回兩個切片。第一個不包含連續的重複元素。
    /// 第二個包含沒有指定順序的所有重複項。
    ///
    /// 如果對切片進行了排序，則第一個返回的切片將不包含重複項。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// 將除第一個連續元素之外的所有元素移動到滿足給定相等關係的切片的末尾。
    ///
    /// 返回兩個切片。第一個不包含連續的重複元素。
    /// 第二個包含沒有指定順序的所有重複項。
    ///
    /// `same_bucket` 函數傳遞對切片中兩個元素的引用，並且必須確定這些元素比較是否相等。
    /// 元素以與切片中的順序相反的順序傳遞，因此，如果 `same_bucket(a, b)` 返回 `true`，則 `a` 將在切片的末尾移動。
    ///
    ///
    /// 如果對切片進行了排序，則第一個返回的切片將不包含重複項。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // 儘管我們對 `self` 有可變的引用，但是我們無法進行 *任意* 的更改。`same_bucket` 調用可能為 panic，因此我們必須確保切片始終處於有效狀態。
        //
        // 我們處理此問題的方法是使用交換。我們遍歷所有元素，並隨即交換，以使最後我們希望保留的元素在最前面，而我們希望拒絕的元素在後面。
        // 然後我們可以分割切片。
        // 此操作仍為 `O(n)`。
        //
        // 示例: 我們從這種狀態開始，其中 `r` 代表 `next`
        // 讀取 `，`w` 表示` next_write`。
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // 將 self[r] 與 self [w-1] 進行比較，這不是重複項，因此我們交換 self[r] 和 self[w] (因為 r==w 無效)，然後將 r 和 w 都遞增，所以我們得到:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // 將 self[r] 與 self [w-1] 進行比較，該值是重複的，因此我們增加 `r`，但其他所有內容保持不變:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // 比較 self[r] 與 self [w-1]，這不是重複項，因此交換 self[r] 和 self[w] 並前進 r 和 w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // 不能重複，請重複:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // 重複，切片的 advance r. End。在 w 處分割。
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // 安全: `while` 條件保證 `next_read` 和 `next_write`
        // 小於 `len`，因此位於 `self` 內部。
        // `prev_ptr_write` 指向 `ptr_write` 之前的一個元素，但是 `next_write` 從 1 開始，因此 `prev_ptr_write` 永遠不會小於 0 且位於切片內。
        // 這滿足了取消引用 `ptr_read`，`prev_ptr_write` 和 `ptr_write` 以及使用 `ptr.add(next_read)`，`ptr.add(next_write - 1)` 和 `prev_ptr_write.offset(1)` 的要求。
        //
        //
        // `next_write` 每個循環最多也增加一次，這意味著在可能需要交換元素時不會跳過任何元素。
        //
        // `ptr_read` `prev_ptr_write` 和 `prev_ptr_write` 永遠不要指向同一元素。為了確保 `&mut *ptr_read`，`&mut* prev_ptr_write` 的安全，這是必需的。
        // 簡單的解釋是 `next_read >= next_write` 始終為真，因此 `next_read > next_write - 1` 也是如此。
        //
        //
        //
        //
        //
        unsafe {
            // 通過使用原始指針避免邊界檢查。
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// 將除第一個連續元素之外的所有元素移動到解析為同一鍵的切片的末尾。
    ///
    ///
    /// 返回兩個切片。第一個不包含連續的重複元素。
    /// 第二個包含沒有指定順序的所有重複項。
    ///
    /// 如果對切片進行了排序，則第一個返回的切片將不包含重複項。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// 就地旋轉切片，以使切片的第一個 `mid` 元素移至末尾，而最後一個 `self.len() - mid` 元素移至前端。
    /// 調用 `rotate_left` 之後，先前在索引 `mid` 處的元素將成為切片中的第一個元素。
    ///
    /// # Panics
    ///
    /// 如果 `mid` 大於切片的長度，則此函數將為 panic。請注意，`mid == self.len()` 執行 _not_ panic，並且是無操作旋轉。
    ///
    /// # Complexity
    ///
    /// 採取線性 (以 `self.len()`) 時間。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// 旋轉子切片:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // 安全: `[p.add(mid) - mid, p.add(mid) + k)` 範圍很小
        // 根據 `ptr_rotate` 的要求，對讀和寫有效。
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// 就地旋轉切片，以使切片的第一個 `self.len() - k` 元素移至末尾，而最後一個 `k` 元素移至前端。
    /// 調用 `rotate_right` 之後，先前在索引 `self.len() - k` 處的元素將成為切片中的第一個元素。
    ///
    /// # Panics
    ///
    /// 如果 `k` 大於切片的長度，則此函數將為 panic。請注意，`k == self.len()` 執行 _not_ panic，並且是無操作旋轉。
    ///
    /// # Complexity
    ///
    /// 採取線性 (以 `self.len()`) 時間。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// 旋轉子切片:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // 安全: `[p.add(mid) - mid, p.add(mid) + k)` 範圍很小
        // 根據 `ptr_rotate` 的要求，對讀和寫有效。
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// 通過克隆 `value`，用元素填充 `self`。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// 用重複調用閉包返回的元素填充 `self`。
    ///
    /// 此方法使用閉包創建新值。如果您希望給定值 [`Clone`]，請使用 [`fill`]。
    /// 如果要使用 [`Default`] trait 生成值，則可以傳遞 [`Default::default`] 作為參數。
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// 將元素從 `src` 複製到 `self`。
    ///
    /// `src` 的長度必須與 `self` 相同。
    ///
    /// 如果 `T` 實現 `Copy`，則使用 [`copy_from_slice`] 的性能可能更高。
    ///
    /// # Panics
    ///
    /// 如果兩個切片的長度不同，則此功能將為 panic。
    ///
    /// # Examples
    ///
    /// 將切片中的兩個元素克隆到另一個中:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // 由於切片必須具有相同的長度，因此我們將源切片從四個元素切成兩個。
    /// // 如果不這樣做，它將為 panic。
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust 強制要求只有一個可變引用，而對特定範圍內的特定數據沒有不變的引用。
    /// 因此，嘗試在單個片上使用 `clone_from_slice` 將導致編譯失敗:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// 要解決此問題，我們可以使用 [`split_at_mut`] 從切片創建兩個不同的子切片:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// 使用 memcpy 將所有元素從 `src` 複製到 `self`。
    ///
    /// `src` 的長度必須與 `self` 相同。
    ///
    /// 如果 `T` 未實現 `Copy`，請使用 [`clone_from_slice`]。
    ///
    /// # Panics
    ///
    /// 如果兩個切片的長度不同，則此功能將為 panic。
    ///
    /// # Examples
    ///
    /// 將切片中的兩個元素複製到另一個中:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // 由於切片必須具有相同的長度，因此我們將源切片從四個元素切成兩個。
    /// // 如果不這樣做，它將為 panic。
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust 強制要求只有一個可變引用，而對特定範圍內的特定數據沒有不變的引用。
    /// 因此，嘗試在單個片上使用 `copy_from_slice` 將導致編譯失敗:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// 要解決此問題，我們可以使用 [`split_at_mut`] 從切片創建兩個不同的子切片:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic 代碼路徑已放入冷函數中，以免使調用站點膨脹。
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // 安全: 根據定義，`self` 對 `self.len()` 元素有效，而 `src` 為
        // 檢查長度是否相同。
        // 切片不能重疊，因為可變引用是互斥的。
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// 使用記憶膜將元素從切片的一部分複製到自身的另一部分。
    ///
    /// `src` 是 `self` 內要復制的範圍。
    /// `dest` 是要復製到的 `self` 內範圍的起始索引，該長度將與 `src` 相同。
    /// 這兩個範圍可能會重疊。
    /// 兩個範圍的末端必須小於或等於 `self.len()`。
    ///
    /// # Panics
    ///
    /// 如果任一範圍超出切片的末尾，或者 `src` 的末尾在開始之前，則此函數將為 panic。
    ///
    ///
    /// # Examples
    ///
    /// 在片內復制四個字節:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // 安全: `ptr::copy` 的條件已經在上面進行了檢查，
        // 和 `ptr::add` 一樣。
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// 交換 `self` 中的所有元素和 `other` 中的所有元素。
    ///
    /// `other` 的長度必須與 `self` 相同。
    ///
    /// # Panics
    ///
    /// 如果兩個切片的長度不同，則此功能將為 panic。
    ///
    /// # Example
    ///
    /// 在切片之間交換兩個元素:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust 強制要求在一個特定範圍內對一個特定的數據只能有一個可變的引用。
    ///
    /// 因此，嘗試在單個片上使用 `swap_with_slice` 將導致編譯失敗:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// 要解決此問題，我們可以使用 [`split_at_mut`] 從切片創建兩個不同的可變子切片:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // 安全: 根據定義，`self` 對 `self.len()` 元素有效，而 `src` 為
        // 檢查長度是否相同。
        // 切片不能重疊，因為可變引用是互斥的。
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// 用於計算 `align_to{,_mut}` 的中間和尾隨切片的長度的函數。
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // 我們要對 `rest` 採取的措施是弄清楚我們可以在最低數量的 T 中放入 U 的倍數。
        //
        // 對於每個這樣的 "multiple"，我們需要多少個 T。
        //
        // 考慮例如 T＝u8 U＝u16。然後我們可以在 2 Ts 中放入 1U。簡單的。
        // 現在，考慮一個例子，其中 size_of: :<T>=16，size_of::<U>=24。</u>
        // 我們可以在 `rest` Slice 中的每 3 個 Ts 中放置 2 個 Us。
        // 有點複雜。
        //
        // 計算公式為:
        //
        // 我們 = lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // 擴展和簡化:
        //
        // 我們 = size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // 幸運的是，由於所有這些都是不斷評估的，因此這裡的性能無關緊要!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // 迭代施泰因算法我們仍然應該使這個 `const fn` (如果這樣做的話，請返回到遞歸算法)，因為依靠 llvm 來約束所有這些都是……好吧，這讓我感到不舒服。
            //
            //

            // 安全: `a` 和 `b` 被檢查為非零值。
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // 從 b 刪除 2 的所有因子
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // 安全: `b` 被檢查為非零。
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // 有了這些知識，我們就能找到可以容納多少個 `U`s!
        let us_len = self.len() / ts * us;
        // 以及後面的切片中將有多少個 T`s!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// 將切片轉換為其他類型的切片，以確保保持類型的對齊。
    ///
    /// 此方法將切片分為三個不同的切片: 前綴，正確對齊的新類型的中間切片和後綴切片。
    /// 對於給定的類型和輸入片段，該方法可以使中間片段的最大長度盡可能長，但是僅算法的性能應取決於此，而不取決於其正確性。
    ///
    /// 允許所有輸入數據作為前綴或後綴片返回。
    ///
    /// 當輸入元素 `T` 或輸出元素 `U` 的大小為零時，此方法無用，並且將返回原始切片而不拆分任何內容。
    ///
    /// # Safety
    ///
    /// 對於返回的中間片中的元素，此方法本質上是 `transmute`，因此，與 `transmute::<T, U>` 有關的所有常見警告也適用於此。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // 請注意，此函數的大部分將為常量求值，
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // 專門處理 ZST，這是-根本不處理它們。
            return (self, &[], &[]);
        }

        // 首先，找出我們在第一片和第二片之間分割的時間。
        // ptr.align_offset 輕鬆實現。
        let ptr = self.as_ptr();
        // 安全: 有關詳細的安全說明，請參閱 `align_to_mut` 方法。
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // 安全: 現在 `rest` 肯定對齊了，所以下面的 `from_raw_parts` 可以，
            // 因為調用方保證我們可以安全地將 `T` 轉換為 `U`。
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// 將切片轉換為其他類型的切片，以確保保持類型的對齊。
    ///
    /// 此方法將切片分為三個不同的切片: 前綴，正確對齊的新類型的中間切片和後綴切片。
    /// 對於給定的類型和輸入片段，該方法可以使中間片段的最大長度盡可能長，但是僅算法的性能應取決於此，而不取決於其正確性。
    ///
    /// 允許所有輸入數據作為前綴或後綴片返回。
    ///
    /// 當輸入元素 `T` 或輸出元素 `U` 的大小為零時，此方法無用，並且將返回原始切片而不拆分任何內容。
    ///
    /// # Safety
    ///
    /// 對於返回的中間片中的元素，此方法本質上是 `transmute`，因此，與 `transmute::<T, U>` 有關的所有常見警告也適用於此。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // 請注意，此函數的大部分將為常量求值，
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // 專門處理 ZST，這是-根本不處理它們。
            return (self, &mut [], &mut []);
        }

        // 首先，找出我們在第一片和第二片之間分割的時間。
        // ptr.align_offset 輕鬆實現。
        let ptr = self.as_ptr();
        // 安全: 在這裡，我們確保將 U 的對齊指針用於
        // 其餘的方法。這是通過傳遞指向＆[T] 的指針以及針對 U 的對齊方式來完成的。
        // `crate::ptr::align_offset` 使用正確對齊且有效的指針 `ptr` (它來自對 `self` 的引用) 調用該指針，並且其大小為 2 的冪 (因為它來自 U 的對齊)，從而滿足其安全性約束。
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // 此後我們將無法再次使用 `rest`，這將使其別名 `mut_ptr` 失效! 安全: 請參閱 `align_to` 的註釋。
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// 檢查此切片的元素是否已排序。
    ///
    /// 也就是說，對於每個元素 `a` 及其後續元素 `b`，`a <= b` 必須成立。如果切片精確地產生零個或一個元素，則返回 `true`。
    ///
    /// 請注意，如果 `Self::Item` 僅是 `PartialOrd`，而不是 `Ord`，則上述定義意味著，如果任意兩個連續的項都不具有可比性，則此函數將返回 `false`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// 檢查是否使用給定的比較器功能對該切片的元素進行排序。
    ///
    /// 代替使用 `PartialOrd::partial_cmp`，此函數使用給定的 `compare` 函數來確定兩個元素的順序。
    /// 除此之外，它等效於 [`is_sorted`]。有關更多信息，請參見其文檔。
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// 檢查此切片的元素是否使用給定的鍵提取功能排序。
    ///
    /// 此功能不是直接比較切片的元素，而是比較元素的鍵 (由 `f` 確定)。
    /// 除此之外，它等效於 [`is_sorted`]。有關更多信息，請參見其文檔。
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// 根據給定的謂詞返回分區點的索引 (第二個分區的第一個元素的索引)。
    ///
    /// 假定該切片根據給定的謂詞進行了分區。
    /// 這意味著謂詞返回 true 的所有元素都在切片的開頭，謂詞返回 false 的所有元素都在切片的結尾。
    ///
    /// 例如，[7, 15, 3, 5, 4, 12, 6] 在謂詞 x％2! =0 下進行了分區 (所有的奇數都在開頭，所有的偶數都在結尾)。
    ///
    /// 如果未對該片進行分區，則返回的結果是不確定的，並且沒有意義，因為此方法執行一種二進制搜索。
    ///
    /// 另請參見 [`binary_search`]，[`binary_search_by`] 和 [`binary_search_by_key`]。
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // 安全: 當使用 `left < right` 時， `left <= mid < right`.
            // 因此，`left` 總是增加而 `right` 總是減少，並且都選擇了其中一個。在兩種情況下，都滿足 `left <= right`。因此，如果在一個步驟中使用 `left < right`，則在下一步中滿足 `left <= right`。
            //
            // 因此，只要滿足 `left != right`，`0 <= left < right <= len`，並且如果滿足這種情況，也滿足 `0 <= mid < len`。
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: 我們需要明確地將它們切成相同的長度
        // 使優化程序更容易取消邊界檢查。
        // 但是由於不能依靠它，我們還對 T: Copy 有一個明確的專長。
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// 創建一個空切片。
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// 創建一個可變的空切片。
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// 目前，切片中的模式僅由 `strip_prefix` 和 `strip_suffix` 使用。
/// 在 future 點，我們希望將 `core::str::Pattern` (在撰寫本文時僅限於 `str`) 推廣到切片，然後將替換或廢除此 trait。
///
pub trait SlicePattern {
    /// 匹配的切片的元素類型。
    type Item;

    /// 當前，`SlicePattern` 的消費者需要分一杯 slice。
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}