//! 切片分類
//!
//! 此模塊包含基於 Orson Peters 的模式失敗快速排序的排序算法，該算法發佈於: <https://github.com/orlp/pdqsort>
//!
//!
//! 不穩定排序與 libcore 兼容，因為它不分配內存，這與我們穩定的排序實現不同。
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// 放下後，從 `src` 複製到 `dest`。
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // 安全: 這是一個幫助程序類。
        //          請參考其用法以確保正確性。
        //          即，必須確保 `src` 和 `dst` 不會按照 `ptr::copy_nonoverlapping` 的要求重疊。
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// 將第一個元素向右移動，直到遇到一個更大或相等的元素。
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // 安全: 以下不安全操作涉及索引而沒有綁定檢查 (`get_unchecked` 和 `get_unchecked_mut`)
    // 並複制內存 (`ptr::copy_nonoverlapping`)。
    //
    // 一種。索引:
    //  1. 我們將數組的大小檢查為 >=2。
    //  2. 我們將要進行的所有索引編制最多始終在 {0 <= index < len} 之間。
    //
    // b。記憶複製
    //  1. 我們正在獲得指向引用的指針，這些指針被保證是有效的。
    //  2. 它們不能重疊，因為我們獲得了指向切片的不同索引的指針。
    //     即 `i` 和 `i-1`。
    //  3. 如果切片正確對齊，則元素正確對齊。
    //     確保切片正確對齊是調用者的責任。
    //
    // 有關更多詳細信息，請參見下面的評論。
    unsafe {
        // 如果前兩個元素亂序...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // 將第一個元素讀取到堆棧分配的變量中。
            // 如果執行以下比較操作 panics，則 `hole` 將被刪除並自動將元素寫回到切片中。
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // 將第 i 個元素向左移動一個位置，從而將孔向右移動。
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` 被掉落，從而將 `tmp` 複製到 `v` 的剩餘孔中。
        }
    }
}

/// 將最後一個元素向左移動，直到遇到一個較小或相等的元素。
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // 安全: 以下不安全操作涉及索引而沒有綁定檢查 (`get_unchecked` 和 `get_unchecked_mut`)
    // 並複制內存 (`ptr::copy_nonoverlapping`)。
    //
    // 一種。索引:
    //  1. 我們將數組的大小檢查為 >=2。
    //  2. 我們將要進行的所有索引編制最多始終在 `0 <= index < len-1` 之間。
    //
    // b。記憶複製
    //  1. 我們正在獲得指向引用的指針，這些指針被保證是有效的。
    //  2. 它們不能重疊，因為我們獲得了指向切片的不同索引的指針。
    //     即 `i` 和 `i+1`。
    //  3. 如果切片正確對齊，則元素正確對齊。
    //     確保切片正確對齊是調用者的責任。
    //
    // 有關更多詳細信息，請參見下面的評論。
    unsafe {
        // 如果最後兩個元素亂序...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // 將最後一個元素讀取到堆棧分配的變量中。
            // 如果執行以下比較操作 panics，則 `hole` 將被刪除並自動將元素寫回到切片中。
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // 將第 i 個元素向右移動一個位置，從而將孔向左移動。
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` 被掉落，從而將 `tmp` 複製到 `v` 的剩餘孔中。
        }
    }
}

/// 通過移動幾個亂序元素對片段進行部分排序。
///
/// 如果切片末尾排序，則返回 `true`。此函數是 *O*(*n*) 最壞的情況。
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // 將移位的相鄰無序對的最大數量。
    const MAX_STEPS: usize = 5;
    // 如果切片比這短，請不要移動任何元素。
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // 安全: 我們已經明確地使用 `i < len` 進行了邊界檢查。
        // 我們所有的後續索引僅在 `0 <= index < len` 範圍內
        unsafe {
            // 查找下一對相鄰的亂序元素。
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // 我們完了嗎?
        if i == len {
            return true;
        }

        // 不要在短數組上移動元素，這會降低性能。
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // 交換找到的一對元素。這使它們處於正確的順序。
        v.swap(i - 1, i);

        // 將較小的元素向左移動。
        shift_tail(&mut v[..i], is_less);
        // 將較大的元素向右移動。
        shift_head(&mut v[i..], is_less);
    }

    // 未能在有限的步驟中對切片進行排序。
    false
}

/// 使用插入排序對切片進行排序，這是 *O*(*n*^ 2) 最壞的情況。
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// 使用堆排序對 `v` 進行排序，這保證了 *O*(*n*\*log(* n*)) 最壞的情況。
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // 該二進制堆遵守不變式 `parent >= child`。
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` 的子代:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // 選擇更大的子节点。
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // 如果不變量位於 `node`，則停止。
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // 與更大的子节点交換 `node`，向下移動一步，然後繼續篩分。
            v.swap(node, greater);
            node = greater;
        }
    };

    // 在線性時間內構建堆。
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // 從堆中彈出最大元素。
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// 將 `v` 劃分為小於 `pivot` 的元素，然後劃分為大於或等於 `pivot` 的元素。
///
///
/// 返回小於 `pivot` 的元素數。
///
/// 為了最小化分支操作的成本，逐塊執行分區。
/// [BlockQuicksort][pdf] 論文中提出了這個想法。
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // 典型塊中的元素數。
    const BLOCK: usize = 128;

    // 分區算法重複以下步驟，直到完成:
    //
    // 1. 從左側跟踪一個塊，以識別大於或等於樞軸的元素。
    // 2. 從右側跟踪一個塊，以識別小於樞軸的元素。
    // 3. 在左側和右側之間交換已標識的元素。
    //
    // 我們為一塊元素保留以下變量:
    //
    // 1. `block` - 塊中元素的數量。
    // 2. `start` - 將指針啟動到 `offsets` 數組中。
    // 3. `end` - 將指針指向 `offsets` 數組。
    // 4. 偏移量，塊內亂序的索引。

    // 左側的當前塊 (從 `l` 到 `l.add(block_l)`)。
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // 右側的當前塊 (從 `r.sub(block_r)` to `r`) 開始)。
    // 安全: .add() 的文檔特別提到 `vec.as_ptr().add(vec.len())` 始終是安全的。
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: 當我們得到 VLA 時，嘗試創建一個長度為 `min(v.len()，2 * BLOCK) 的數組，而不是
    // 而不是兩個長度為 `BLOCK` 的固定大小的數組。VLA 可能會提高緩存效率。

    // 返回指針 `l` (inclusive) 和 `r` (exclusive) 之間的元素數。
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // 當 `l` 和 `r` 非常接近時，我們將逐塊進行分區。
        // 然後，我們進行一些修補工作，以便在其餘元素之間進行劃分。
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // 剩餘元素數 (仍未與樞軸進行比較)。
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // 調整塊大小，以使左右塊不重疊，但要完全對齊以覆蓋整個剩餘間隙。
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // 從左側跟踪 `block_l` 元素。
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // 安全: 以下不安全操作涉及 `offset` 的使用。
                //         根據函數所需的條件，我們滿足它們，因為:
                //         1. `offsets_l` 是堆棧分配的，因此被認為是單獨分配的對象。
                //         2. 函數 `is_less` 返回 `bool`。
                //            投射 `bool` 不會使 `isize` 溢出。
                //         3. 我們保證 `block_l` 將是 `<= BLOCK`。
                //            另外，`end_l` 最初設置為在堆棧上聲明的 `offsets_` 的開始指針。
                //            因此，我們知道，即使在最壞的情況下 (`is_less` 的所有調用都返回 false)，我們最多只能有 1 個字節通過結尾。
                //        這裡的另一個不安全操作是取消引用 `elem`。
                //        但是，`elem` 最初是指向始終有效的切片的開始指針。
                unsafe {
                    // 無分支比較。
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // 從右側跟踪 `block_r` 元素。
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // 安全: 以下不安全操作涉及 `offset` 的使用。
                //         根據函數所需的條件，我們滿足它們，因為:
                //         1. `offsets_r` 是堆棧分配的，因此被認為是單獨分配的對象。
                //         2. 函數 `is_less` 返回 `bool`。
                //            投射 `bool` 不會使 `isize` 溢出。
                //         3. 我們保證 `block_r` 將是 `<= BLOCK`。
                //            另外，`end_r` 最初設置為在堆棧上聲明的 `offsets_` 的開始指針。
                //            因此，我們知道即使在最壞的情況下 (`is_less` 的所有調用都返回 true)，我們最多也只能將 1 個字節傳遞給結尾。
                //        這裡的另一個不安全操作是取消引用 `elem`。
                //        但是，`elem` 最初是末尾的 `1 *sizeof(T)`，在訪問它之前，我們先將其遞減 `1* sizeof(T)`。
                //        另外，斷言 `block_r` 小於 `BLOCK`，因此 `elem` 最多將指向切片的開頭。
                unsafe {
                    // 無分支比較。
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // 要在左側和右側之間交換的亂序元素的數量。
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // 與一次交換一對相比，執行循環置換更為有效。
            // 這並不嚴格等同於交換，但是使用較少的內存操作即可產生類似的結果。
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // 左側塊中的所有亂序元素均已移動。移至下一個塊。
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // 右側塊中的所有亂序元素均已移動。移至上一個塊。
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // 現在剩下的全部是至多一個塊 (左側或右側)，其中需要移動的亂序元素。
    // 這些剩餘的元素可以簡單地移到其塊內的末尾。
    //

    if start_l < end_l {
        // 剩下的方塊仍然保留。
        // 將其剩餘的亂序元素移到最右邊。
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // 右邊的塊仍然存在。
        // 將其剩餘的亂序元素移到最左邊。
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // 沒什麼可做的，我們已經完成。
        width(v.as_mut_ptr(), l)
    }
}

/// 將 `v` 劃分為小於 `v[pivot]` 的元素，然後劃分為大於或等於 `v[pivot]` 的元素。
///
///
/// 返回一個元組:
///
/// 1. 小於 `v[pivot]` 的元素數。
/// 2. 如果 `v` 已經分區，則為 True。
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // 將樞軸放置在切片的開頭。
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // 將樞軸讀取到堆棧分配的變量中以提高效率。
        // 如果執行以下比較操作 panics，則樞軸將自動寫回到切片中。
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // 查找第一對亂序元素。
        let mut l = 0;
        let mut r = v.len();

        // 安全: 以下不安全之處涉及對數組進行索引。
        // 對於第一個: 我們已經在這裡使用 `l < r` 進行了邊界檢查。
        // 對於第二個: 我們最初有 `l == 0` 和 `r == v.len()`，我們在每次索引操作中都檢查了 `l < r`。
        //                     從這裡我們知道 `r` 必須至少是 `r == l`，這從第一個開始就被證明是有效的。
        unsafe {
            // 找到大於或等於樞軸的第一個元素。
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // 找到比樞軸更小的最後一個元素。
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` 超出範圍，然後將數據透視表 (這是一個堆棧分配的變量) 寫回到它原來所在的切片中。
        // 這一步對於確保安全至關重要!
        //
    };

    // 將樞軸放置在兩個分區之間。
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// 將 `v` 劃分為等於 `v[pivot]` 的元素，後跟大於 `v[pivot]` 的元素。
///
/// 返回等於樞軸的元素數。
/// 假定 `v` 不包含小於樞軸的元素。
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // 將樞軸放置在切片的開頭。
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // 將樞軸讀取到堆棧分配的變量中以提高效率。
    // 如果執行以下比較操作 panics，則樞軸將自動寫回到切片中。
    // 安全性: 此處的指針有效，因為它是從對切片的引用中獲得的。
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // 現在對切片進行分區。
    let mut l = 0;
    let mut r = v.len();
    loop {
        // 安全: 以下不安全之處涉及對數組進行索引。
        // 對於第一個: 我們已經在這裡使用 `l < r` 進行了邊界檢查。
        // 對於第二個: 我們最初有 `l == 0` 和 `r == v.len()`，我們在每次索引操作中都檢查了 `l < r`。
        //                     從這裡我們知道 `r` 必須至少是 `r == l`，這從第一個開始就被證明是有效的。
        unsafe {
            // 找到第一個大於樞軸的元素。
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // 找到等於樞軸的最後一個元素。
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // 我們完了嗎?
            if l >= r {
                break;
            }

            // 交換找到的一對亂序元素。
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // 我們發現 `l` 元素等於樞軸。為樞軸本身加 1。
    l + 1

    // `_pivot_guard` 超出範圍，然後將數據透視表 (這是一個堆棧分配的變量) 寫回到它原來所在的切片中。
    // 這一步對於確保安全至關重要!
}

/// 散佈一些元素，以嘗試破壞可能導致快速排序中的分區不平衡的模式。
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George Marsaglia 撰寫的 "Xorshift RNGs" 論文中的偽隨機數生成器。
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // 取該數字取模的隨機數。
        // 該數字適合 `usize`，因為 `len` 不大於 `isize::MAX`。
        let modulus = len.next_power_of_two();

        // 一些關鍵候選人將在該指數附近。讓我們隨機化它們。
        let pos = len / 4 * 2;

        for i in 0..3 {
            // 生成一個以 `len` 為模的隨機數。
            // 但是，為了避免昂貴的操作，我們首先將其取模為 2 的冪，然後減小 `len` 直到它適合 `[0, len - 1]` 範圍。
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` 保證小於 `2 * len`。
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// 在 `v` 中選擇一個樞軸，如果切片可能已經排序，則返回索引和 `true`。
///
/// `v` 中的元素可能會在此過程中重新排序。
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // 選擇中位數中位數方法的最小長度。
    // 較短的切片使用簡單的三位數中位數方法。
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // 此功能可以執行的最大交換次數。
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // 我們將在附近選擇一個樞軸的三個指數。
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // 計算在對索引進行排序時我們將要執行的交換總數。
    let mut swaps = 0;

    if len >= 8 {
        // 交換索引，以便 `v[a] <= v[b]`。
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // 交換索引，以便 `v[a] <= v[b] <= v[c]`。
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // 查找 `v[a - 1], v[a], v[a + 1]` 的中位數，並將索引存儲到 `a` 中。
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // 查找 `a`，`b` 和 `c` 附近的中位數。
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // 在 `a`，`b` 和 `c` 中找到中位數。
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // 已執行最大交換次數。
        // 切片可能是降序的，或者大部分是降序的，因此反轉可能有助於更快地對其進行排序。
        v.reverse();
        (len - 1 - b, true)
    }
}

/// 遞歸排序 `v`。
///
/// 如果切片在原始數組中具有前任，則將其指定為 `pred`。
///
/// `limit` 是切換到 `heapsort` 之前允許的不平衡分區的數量。
/// 如果為零，此函數將立即切換到堆排序。
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // 長度不超過此長度的切片將使用插入排序進行排序。
    const MAX_INSERTION: usize = 20;

    // 如果最後一個分區合理平衡，則為 true。
    let mut was_balanced = true;
    // 如果最後一個分區沒有隨機播放元素 (切片已分區)，則為 true。
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // 非常短的切片使用插入排序進行排序。
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // 如果做出了太多錯誤的樞軸選擇，則只需退回到 heapsort 以確保 `O(n * log(n))` 最壞的情況。
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // 如果最後一個分區不平衡，請嘗試通過拖曳一些元素來破壞切片中的模式。
        // 希望這次我們選擇一個更好的支點。
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // 選擇一個樞軸，然後嘗試猜測切片是否已排序。
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // 如果最後一個分區達到了合理的平衡並且沒有對元素進行混洗，並且如果樞軸選擇預測到該切片可能已經排序，則...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // 嘗試識別幾個亂序的元素，然後將它們移到正確的位置。
            // 如果切片最終被完全排序，那麼我們就完成了。
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // 如果選擇的樞軸等於前一個樞軸，則它是切片中的最小元素。
        // 將切片劃分為等於和大於樞軸的元素。
        // 當切片包含許多重複元素時，通常會遇到這種情況。
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // 繼續對大於樞軸的元素進行排序。
                v = &mut { v }[mid..];
                continue;
            }
        }

        // 對切片進行分區。
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // 將切片拆分為 `left`，`pivot` 和 `right`。
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // 遞歸到較短的一側只是為了最大程度地減少遞歸調用的總數並佔用較少的堆棧空間。
        // 然後只是繼續較長的一側 (這類似於尾部遞歸)。
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// 使用模式破壞快速排序對 `v` 進行排序，這是 *O*(*n*\*log(* n*)) 最壞的情況。
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // 零大小類型的排序沒有有意義的行為。
    if mem::size_of::<T>() == 0 {
        return;
    }

    // 將不平衡分區的數量限制為 `floor(log2(len)) + 1`。
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // 對於不超過此長度的切片，將其簡單排序可能會更快。
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // 選擇一個樞軸
        let (pivot, _) = choose_pivot(v, is_less);

        // 如果選擇的樞軸等於前一個樞軸，則它是切片中的最小元素。
        // 將切片劃分為等於和大於樞軸的元素。
        // 當切片包含許多重複元素時，通常會遇到這種情況。
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // 如果我們通過了索引，那麼我們就很好。
                if mid > index {
                    return;
                }

                // 否則，繼續對大於樞軸的元素進行排序。
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // 將切片拆分為 `left`，`pivot` 和 `right`。
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // 如果 mid==index，那麼我們就完成了，因為 partition() 保證 mid 之後的所有元素都大於或等於 mid。
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // 零大小類型的排序沒有有意義的行為。沒做什麼。
    } else if index == v.len() - 1 {
        // 查找最大元素並將其放置在數組的最後一個位置。
        // 我們可以在這裡自由使用 `unwrap()`，因為我們知道 v 不能為空。
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // 查找 min 元素並將其放置在數組的第一個位置。
        // 我們可以在這裡自由使用 `unwrap()`，因為我們知道 v 不能為空。
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}