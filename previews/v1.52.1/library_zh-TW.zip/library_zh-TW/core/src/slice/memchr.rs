// 原始實現來自 rust-memchr。
// 版權所有 2015 Andrew Gallant，bluss 和 Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// 使用截斷。
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// 如果 `x` 包含任何零字節，則返回 `true`。
///
/// 摘自 *Matters Computational*，J。Arndt:
///
/// ` 這個想法是從每個字節中減去一個，然後尋找借位一直傳播到最高有效位的字節。
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// 返回與 `text` 中的字節 `x` 匹配的第一個索引。
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // 小切片的快速路徑
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // 通過一次讀取兩個 `usize` 字來掃描單個字節值。
    //
    // 將 `text` 分為三部分
    // - 未對齊的初始部分，在文本中第一個單詞對齊的地址之前
    // - 身體，一次掃描 2 個字
    // - 最後剩下的部分，<2 字大小

    // 搜索到對齊的邊界
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // 搜索正文
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // 安全: while 謂詞可確保至少 2 * usize_bytes 的距離
        // 在偏移量和切片的末尾之間。
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // 如果有匹配的字節則中斷
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // 在主體循環停止的點之後找到字節。
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// 返回與 `text` 中的字節 `x` 匹配的最後一個索引。
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // 通過一次讀取兩個 `usize` 字來掃描單個字節值。
    //
    // 將 `text` 分為三個部分:
    // - 未對齊的尾部，在文本中最後一個單詞的對齊地址之後，
    // - 身體，一次掃描 2 個字，
    // - 剩餘的前一個字節，<2 個字長。
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // 我們稱此為獲取前綴和後綴的長度。
        // 在中間，我們總是一次處理兩個塊。
        // 安全: 將 `[u8]` 轉換為 `[usize]` 是安全的，但 `align_to` 處理的尺寸差異除外。
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // 搜索文本的正文，確保我們不跨越 min_aligned_offset。
    // 偏移量始終對齊，因此僅測試 `>` 就足夠了，並避免了可能的溢出。
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // 安全: 偏移量從 len suffix.len() 開始，只要大於
        // min_aligned_offset (prefix.len()) 剩餘距離至少為 2 * chunk_bytes。
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // 如果有匹配的字節，則中斷。
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // 在主體循環停止的點之前找到字節。
    text[..offset].iter().rposition(|elt| *elt == x)
}