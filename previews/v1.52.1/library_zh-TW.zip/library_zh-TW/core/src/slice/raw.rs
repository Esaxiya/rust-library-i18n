//! 免費功能來創建 `&[T]` 和 `&mut [T]`。

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// 根據指針和長度形成一個切片。
///
/// `len` 參數是 **元素** 的數量，而不是字節數。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `data` 必須為 [valid]，才能讀取許多字節的 `len * mem::size_of::<T>()`，並且必須正確對齊。這尤其意味著:
///
///     * 此片的整個內存範圍必須包含在一個分配的對像中!
///       切片永遠不能跨越多個分配的對象。請參見 [below](#incorrect-usage)，以獲取一個示例，錯誤地將其不考慮在內。
///     * `data` 必須為非 null，並且即使對於零長度的切片也必須對齊。
///     這樣做的一個原因是，枚舉佈局優化可能依賴於對齊的引用 (包括任何長度的切片) 並且不為空，以將其與其他數據區分開。
///     您可以使用 [`NonNull::dangling()`] 獲得可用作零長度切片的 `data` 的指針。
///
/// * `data` 必須指向 `len` 類型正確的連續 `T` 初始化值。
///
/// * 在 `'a` 的生存期內，除非 `UnsafeCell` 內，否則返回的 slice 所引用的內存一定不能被更改。
///
/// * 切片的總大小 `len * mem::size_of::<T>()` 必須不大於 `isize::MAX`。
///   請參閱 [`pointer::offset`] 的安全文檔。
///
/// # Caveat
///
/// 從其使用情況可以推斷出返回切片的生命週期。
/// 為防止意外濫用，建議將生存期與上下文中安全的源生存期聯繫起來，例如通過提供一個輔助函數來獲取切片主機值的生存期，或通過顯式批註。
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // 顯示單個元素的切片
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### 用法不正確
///
/// 以下 `join_slices` 功能是 **不可靠的**
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // 上面的斷言確保 `fst` 和 `snd` 是連續的，但它們仍可能包含在 _different allocated objects_ 中，在這種情況下，創建此切片是未定義的行為。
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` 和 `b` 是不同的分配對象...
///     let a = 42;
///     let b = 27;
///     // ...，但是可能會在內存中連續放置它們: 一個 | b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // 安全: 调用者必須遵守 `from_raw_parts` 的安全合同。
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// 執行與 [`from_raw_parts`] 相同的功能，除了返回可變切片。
///
/// # Safety
///
/// 如果違反以下任一條件，則行為是未定義的:
///
/// * `data` `len * mem::size_of::<T>()` 的多個字節的讀取和寫入必須為 [valid]，並且必須正確對齊。這尤其意味著:
///
///     * 此片的整個內存範圍必須包含在一個分配的對像中!
///       切片永遠不能跨越多個分配的對象。
///     * `data` 必須為非 null，並且即使對於零長度的切片也必須對齊。
///     這樣做的一個原因是，枚舉佈局優化可能依賴於對齊的引用 (包括任何長度的切片) 並且不為空，以將其與其他數據區分開。
///
///     您可以使用 [`NonNull::dangling()`] 獲得可用作零長度切片的 `data` 的指針。
///
/// * `data` 必須指向 `len` 類型正確的連續 `T` 初始化值。
///
/// * 在生命週期 `'a` 期間，不得通過任何其他指針 (不是從返回值派生) 訪問返回的切片所引用的內存。
///   讀取和寫入訪問均被禁止。
///
/// * 切片的總大小 `len * mem::size_of::<T>()` 必須不大於 `isize::MAX`。
///   請參閱 [`pointer::offset`] 的安全文檔。
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // 安全: 调用者必須遵守 `from_raw_parts_mut` 的安全合同。
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// 將對 T 的引用轉換為長度為 1 的切片 (不進行複制)。
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// 將對 T 的引用轉換為長度為 1 的切片 (不進行複制)。
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}