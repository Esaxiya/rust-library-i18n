// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// 旋轉範圍 `[mid-left, mid+right)`，以使 `mid` 處的元素成為第一個元素。等效地，將範圍 `left` 元素向左旋轉或將 `right` 元素向右旋轉。
///
/// # Safety
///
/// 指定的範圍必須對讀寫有效。
///
/// # Algorithm
///
/// 算法 1 用於較小的 `left + right` 或較大的 `T`。
/// 元素從 `mid - left` 開始一次移動到它們的最終位置，並以 `left + right` 為模以 `right` 步長前進，因此只需要一個臨時位置。
/// 最終，我們回到 `mid - left`。
/// 但是，如果 `gcd(left + right, right)` 不為 1，則上述步驟將跳過元素。
/// 例如:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// 幸運的是，最終元素之間被跳過的元素數量始終相等，因此我們可以偏移起始位置並進行更多的回合 (總回合數為 `gcd(left + right, right)` value)。
///
/// 最終結果是所有元素只能一次完成。
///
/// 如果 `left + right` 大但 `min(left, right)` 小到足以適合堆棧緩衝區，則使用算法 2。
/// `min(left, right)` 元素被複製到緩衝區中，`memmove` 應用於其他元素，並且緩衝區中的那些元素被移回到它們起源的另一側的孔中。
///
/// 一旦 `left + right` 變得足夠大，可進行矢量化處理的算法將超越上述性能。
/// 可以通過分塊並一次執行多個回合來對算法 1 進行矢量化處理，但是在 `left + right` 變得巨大之前，平均回合數量太少，而且單回合的最壞情況總是存在。
/// 相反，算法 3 利用 `min(left, right)` 元素的重複交換，直到剩下較小的旋轉問題為止。
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` 時，交換發生在左側。
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. 如果不檢查這些情況，以下算法可能會失敗
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // 算法 1 的微基準測試表明，直到 `left + right == 32` 左右，隨機移位的平均性能一直都比較好，但是最壞的情況甚至會達到 16。
            // 24 被選為中間立場。
            // 如果 `T` 的大小大於 4 個 `使用`，則該算法也會優於其他算法。
            //
            //
            let x = unsafe { mid.sub(left) };
            // 第一輪開始
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` 可以通過計算 `gcd(left + right, right)` 預先找到，但是執行一次循環將 gcd 計算為副作用的速度更快，然後執行其餘的塊
            //
            //
            let mut gcd = right;
            // 基準測試表明，與一遍交換臨時文件相比，一次讀取一個臨時文件，向後復制，然後在最後寫入該臨時文件要快得多。
            // 這可能是由於以下事實: 交換或替換臨時節點在循環中僅使用一個內存地址，而不需要管理兩個。
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // 而不是遞增 `i`，然後檢查它是否在範圍之內，我們檢查 `i` 是否在下一次遞增時超出範圍。
                // 這樣可以防止指針或 `usize` 的任何換行。
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // 第一輪結束
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // 如果 `left + right >= 15`，則此條件必須在此處
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // 用更多的回合完成大塊
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` 不是零大小的類型，因此可以將其除以大小。
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // 算法 2 這裡的 `[T; 0]` 是為了確保它與 T 正確對齊
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // 算法 3 有另一種交換方式，該方式涉及找到該算法的最後交換位置，然後使用該最後一個塊進行交換，而不是像該算法那樣交換相鄰的塊，但是這種方式仍然更快。
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // 算法 3， `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}