//! 可組合的異步迭代。
//!
//! 如果 futures 是異步值，則流是異步迭代器。
//! 如果您發現自己擁有某種異步集合，並且需要對所述集合的元素執行操作，那麼您會很快遇到 'streams'。
//! 流在慣用的異步 Rust 代碼中大量使用，因此值得熟悉它們。
//!
//! 在解釋更多內容之前，讓我們討論一下該模塊的結構:
//!
//! # Organization
//!
//! 該模塊主要按類型組織:
//!
//! * [Traits] 是核心部分: 這些 traits 定義了存在哪種流以及您可以使用它們做什麼。這些 traits 的方法值得投入一些額外的學習時間。
//! * 函數提供了一些有用的方式來創建一些基本流。
//! * 結構通常是模塊 traits 上各種方法的返回類型。通常，您將需要查看創建 `struct` 的方法，而不是 `struct` 本身。
//! 有關原因的更多詳細信息，請參見 `[實現流] (#implementing-stream) `。
//!
//! [Traits]: #traits
//!
//! 就是這樣! 讓我們深入研究流。
//!
//! # Stream
//!
//! 該模塊的核心和靈魂是 [`Stream`] trait。[`Stream`] 的核心如下所示:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! 與 `Iterator` 不同，`Stream` 區分了實現 `Stream` 時使用的 [`poll_next`] 方法和使用流時使用的 (to-be-implemented) `next` 方法。
//!
//! `Stream` 的使用者只需要考慮 `next`，當調用 `next` 時，它會返回產生 `Option<Stream::Item>` 的 future。
//!
//! 只要有元素，`next` 返回的 future 就會產生 `Some(Item)`，一旦所有元素用盡，就會產生 `None` 來指示迭代已完成。
//! 如果我們正在等待異步處理，則 future 將等待，直到流準備再次屈服。
//!
//! 各個流可能選擇恢復迭代，因此再次調用 `next` 可能會或可能最終不會在某個時候再次產生 `Some(Item)`。
//!
//! [`Stream`] 的完整定義還包括許多其他方法，但是它們是默認方法，基於 [`poll_next`] 構建，因此您可以免費獲得它們。
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # 實施流
//!
//! 創建自己的流涉及兩個步驟: 創建一個 `struct` 來保存流的狀態，然後為該 `struct` 實現 [`Stream`]。
//!
//! 讓我們創建一個名為 `Counter` 的流，它從 `1` 到 `5` 計數:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // 首先，該結構:
//!
//! /// 從一數到五的流
//! struct Counter {
//!     count: usize,
//! }
//!
//! // 我們希望計數從一開始，所以讓我們添加一個 new() 方法來提供幫助。
//! // 這不是嚴格必要的，但很方便。
//! // 請注意，我們將 `count` 從零開始，我們將在下面的 `poll_next()`'s 實現中看到原因。
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // 然後，我們為 `Counter` 實現 `Stream`:
//!
//! impl Stream for Counter {
//!     // 我們將使用 usize 進行計數
//!     type Item = usize;
//!
//!     // poll_next() 是唯一需要的方法
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // 增加我們的數量。這就是為什麼我們從零開始。
//!         self.count += 1;
//!
//!         // 檢查我們是否已經完成計數。
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! 流是 `懶惰的`。這意味著僅僅創建一個流並不能滿足 _do_ 的全部需求。除非您致電 `next`，否則什麼都不會發生。
//! 當僅出於其副作用創建流時，這有時會引起混亂。
//! 編譯器將警告我們這種行為:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;