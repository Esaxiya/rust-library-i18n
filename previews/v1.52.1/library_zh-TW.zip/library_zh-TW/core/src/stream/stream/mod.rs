use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// 用於處理異步迭代器的接口。
///
/// 這是主流 trait。
/// 有關一般的流概念的更多信息，請參見 [module-level documentation]。
/// 特別是，您可能想知道如何 [implement `Stream`][impl]。
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// 流產生的項目類型。
    type Item;

    /// 嘗試拉出該流的下一個值，如果該值尚不可用，則註冊當前任務以進行喚醒，如果流已用盡，則返回 `None`。
    ///
    /// # 返回值
    ///
    /// 有幾個可能的返回值，每個返回值指示不同的流狀態:
    ///
    /// - `Poll::Pending` 表示該流的下一個值尚未準備好。實現將確保在準備好下一個值時將通知當前任務。
    ///
    /// - `Poll::Ready(Some(val))` 表示流已成功產生值 `val`，並可能在隨後的 `poll_next` 調用中產生進一步的值。
    ///
    /// - `Poll::Ready(None)` 表示流已終止，並且不應再次調用 `poll_next`。
    ///
    /// # Panics
    ///
    /// 流完成後 (返回 `Ready(None)` from `poll_next`)，再次調用其 `poll_next` 方法可能會 panic，永遠阻塞或引起其他類型的問題; `Stream` trait 對此類調用的效果沒有任何要求。
    ///
    /// 但是，由於 `poll_next` 方法未標記為 `unsafe`，因此適用 Rust 的通常規則: 調用決不能引起未定義的行為 (內存損壞，對 `unsafe` 函數的錯誤使用等)，而與流的狀態無關。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// 返回流剩余長度上的邊界。
    ///
    /// 具體來說，`size_hint()` 返回一個元組，其中第一個元素是下界，第二個元素是上界。
    ///
    /// 返回的元組的後半部分是 [`Option`]`<`[`usize`]`>`。
    /// 這裡的 [`None`] 表示沒有已知的上限，或者該上限大於 [`usize`]。
    ///
    /// # 實施說明
    ///
    /// 流實施不會產生聲明數量的元素，這不是強制性的。越野車流的產生可能小於元素的下限或大於元素的上限。
    ///
    /// `size_hint()` 主要用於優化，例如為流的元素保留空間，但不得信任，例如可以省略不安全代碼中的邊界檢查。
    /// `size_hint()` 的不正確實現不應導致違反內存安全性。
    ///
    /// 也就是說，該實現應提供正確的估計，因為否則將違反 trait 的協議。
    ///
    /// 默認實現返回對任何流都是正確的 ` (0，`[`None`]`) ) `。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}