//! 這是 ifmt 使用的內部模塊! 運行。這些結構會被發送到靜態數組以提前預編譯格式字符串。
//!
//! 這些定義與它們的 `ct` 等效項相似，但不同之處在於它們可以靜態分配，並針對運行時進行了略微優化。
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// 可以作為格式設置指令的一部分請求的可能的對齊方式。
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// 指示內容應左對齊。
    Left,
    /// 指示內容應右對齊。
    Right,
    /// 指示內容應居中對齊。
    Center,
    /// 沒有要求對齊。
    Unknown,
}

/// 由 [width](https://doc.rust-lang.org/std/fmt/#width) 和 [precision](https://doc.rust-lang.org/std/fmt/#precision) 說明符使用。
#[derive(Copy, Clone)]
pub enum Count {
    /// 用文字數字指定，存儲值
    Is(usize),
    /// 使用 `$` 和 `*` 語法指定，將索引存儲到 `args`
    Param(usize),
    /// 未標明
    Implied,
}