macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// 此整數類型可以表示的最小值。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// 此整數類型可以表示的最大值。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// 此整數類型的大小 (以位為單位)。
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// 將給定基數中的字符串切片轉換為整數。
        ///
        /// 該字符串應為可選的 `+` 或 `-` 符號，後跟數字。
        /// 前導和尾隨空格表示錯誤。
        /// 根據 `radix`，數字是這些字符的子集:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// 如果 `radix` 不在 2 到 36 範圍內，則此功能 panics。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// 返回 `self` 二進製表示形式中的位數。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// 返回 `self` 二進製表示形式中的零數。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// 返回 `self` 二進製表示形式中前導零的數目。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// 返回 `self` 二進製表示形式中的尾隨零數。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// 返回 `self` 二進製表示形式中前導數字。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// 返回 `self` 二進製表示形式中的尾隨數字。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// 將位左移指定的量 `n`，將截斷的位包裝到結果整數的末尾。
        ///
        ///
        /// 請注意，此操作與 `<<` 移位運算符不同!
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// 將位右移指定的量 `n`，將截斷的位包裝到結果整數的開頭。
        ///
        ///
        /// 請注意，此操作與 `>>` 移位運算符不同!
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// 反轉整數的字節順序。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// 令 m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// 反轉整數中的位順序。
        /// 最低有效位變為最高有效位，第二最低有效位變為第二最高有效位，依此類推。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// 令 m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// 將整數從 big endian 轉換為目標的 endianness。
        ///
        /// 在大字節序上，這是個禁忌。在 little endian 上，字節被交換。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// 如果 cfg! (target_endian= "big") {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } 別的 {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// 將整數從 little endian 轉換為目標的 endianness。
        ///
        /// 在小端上，這是個禁忌。在大字節序中，字節被交換。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// 如果 cfg! (target_endian= "little") {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } 別的 {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// 將 `self` 從目標的字節序轉換為大字節序。
        ///
        /// 在大字節序上，這是個禁忌。在 little endian 上，字節被交換。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// 如果 cfg! (target_endian= "big") {
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // 還是不是?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// 將 `self` 從目標的字節序轉換為 Little Endian。
        ///
        /// 在小端上，這是個禁忌。在大字節序中，字節被交換。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// 如果 cfg! (target_endian= "little") {
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// 檢查整數加法。
        /// 計算 `self + rhs`，如果發生溢出則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未經檢查的整數加法。假設不會發生溢出，則計算 `self + rhs`。
        /// 當以下情況時，這導致未定義的行為
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // 安全: 调用者必須遵守 `unchecked_add` 的安全合同。
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// 檢查整數減法。
        /// 計算 `self - rhs`，如果發生溢出則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未經檢查的整數減法。假設不會發生溢出，則計算 `self - rhs`。
        /// 當以下情況時，這導致未定義的行為
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // 安全: 调用者必須遵守 `unchecked_sub` 的安全合同。
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// 檢查整數乘法。
        /// 計算 `self * rhs`，如果發生溢出則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 未經檢查的整數乘法。假設不會發生溢出，則計算 `self * rhs`。
        /// 當以下情況時，這導致未定義的行為
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // 安全: 调用者必須遵守 `unchecked_mul` 的安全合同。
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// 檢查整數除法。
        /// 計算 `self / rhs`，如果 `rhs == 0` 或除法導致溢出，則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // 安全: 上面已經檢查了 div 和 0 以及 INT_MIN 的情況
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// 檢查歐幾里得分裂。
        /// 計算 `self.div_euclid(rhs)`，如果 `rhs == 0` 或除法導致溢出，則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// 檢查整數餘數。
        /// 計算 `self % rhs`，如果 `rhs == 0` 或除法導致溢出，則返回 `None`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // 安全: 上面已經檢查了 div 和 0 以及 INT_MIN 的情況
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// 檢查歐幾里得的餘數。
        /// 計算 `self.rem_euclid(rhs)`，如果 `rhs == 0` 或除法導致溢出，則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// 檢查否定。
        /// 計算 `-self`，如果為 `self == MIN`，則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 檢查左移。
        /// 計算 `self << rhs`，如果 `rhs` 大於或等於 `self` 中的位數，則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 檢查右移。
        /// 計算 `self >> rhs`，如果 `rhs` 大於或等於 `self` 中的位數，則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// 檢查的絕對值。
        /// 計算 `self.abs()`，如果為 `self == MIN`，則返回 `None`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// 檢查取冪。
        /// 計算 `self.pow(exp)`，如果發生溢出則返回 `None`。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // 由於 exp! =0，最終 exp 必須為 1。
            // 分開處理指數的最後一位，因為在此之後對底數進行平方是不必要的，並且可能導致不必要的溢出。
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// 飽和整數加法。
        /// 計算 `self + rhs`，在數字範圍內飽和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// 飽和整數減法。
        /// 計算 `self - rhs`，在數字範圍內飽和，而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// 飽和整數求反。
        /// 計算 `-self`，如果 `self == MIN` 則返回 `MAX` 而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// 飽和絕對值。
        /// 計算 `self.abs()`，如果 `self == MIN` 則返回 `MAX` 而不是溢出。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// 飽和整數乘法。
        /// 計算 `self * rhs`，在數字範圍內飽和，而不是溢出。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// 飽和整數冪。
        /// 計算 `self.pow(exp)`，在數字範圍內飽和，而不是溢出。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// 包裝 (modular) 添加。
        /// 計算 `self + rhs`，在類型的邊界處迴繞。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// 包裝 (modular) 減法。
        /// 計算 `self - rhs`，在類型的邊界處迴繞。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// 包裝 (modular) 乘法。
        /// 計算 `self * rhs`，在類型的邊界處迴繞。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// 包裝 (modular) 部門。計算 `self / rhs`，在類型的邊界處迴繞。
        ///
        /// 可能發生這種換行的唯一情況是將 `MIN / -1` 除以有符號類型 (其中 `MIN` 是該類型的負最小值) ; 否則，可能會發生這種換行。這等效於 `-MIN`，它是一個太大的正值，無法在類型中表示。
        /// 在這種情況下，此函數將返回 `MIN` 本身。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// 包裝歐幾里得分部。
        /// 計算 `self.div_euclid(rhs)`，在類型的邊界處迴繞。
        ///
        /// 包裝只會在 `MIN / -1` 上的帶符號類型 (其中 `MIN` 是該類型的負最小值) 上發生。
        /// 這等效於 `-MIN`，它是一個太大的正值，無法在類型中表示。
        /// 在這種情況下，此方法將返回 `MIN` 本身。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// 包裝 (modular) 剩餘物。計算 `self % rhs`，在類型的邊界處迴繞。
        ///
        /// 這種折回實際上在數學上從來沒有發生過。實現工件會導致 `x % y` 對於帶符號類型的 `MIN / -1` 無效 (其中 `MIN` 為負最小值)。
        ///
        /// 在這種情況下，此函數返回 `0`。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// 包裝歐幾里得的餘數。計算 `self.rem_euclid(rhs)`，在類型的邊界處迴繞。
        ///
        /// 包裝只會在 `MIN % -1` 上的帶符號類型 (其中 `MIN` 是該類型的負最小值) 上發生。
        /// 在這種情況下，此方法返回 0。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// 包裝 (modular) 取反。計算 `-self`，在類型的邊界處迴繞。
        ///
        /// 可能發生這種換行的唯一情況是對有符號類型的 `MIN` 求反 (其中 `MIN` 是該類型的負最小值) ; 否則，可能會發生這種纏繞。這是一個太大的正值，無法在類型中表示。
        /// 在這種情況下，此函數將返回 `MIN` 本身。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic - 無按位左移; 產生 `self << mask(rhs)`，其中 `mask` 刪除 `rhs` 的任何高位，這些高位將導致移位超過該類型的位寬。
        ///
        /// 注意，這與 `向左旋轉` 不同; 環繞左移的 RHS 限於該類型的範圍，而不是從 LHS 移出的位返回到另一端。
        ///
        /// 所有原始整數類型均實現 [`rotate_left`](Self::rotate_left) 函數，而您可能想要的就是該函數。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // 安全: 通過類型的位大小進行掩蓋可確保我們不會移位
            // 越界
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic - 無按位右移; 產生 `self >> mask(rhs)`，其中 `mask` 刪除 `rhs` 的任何高位，這些高位將導致移位超過該類型的位寬。
        ///
        /// 注意，這與右旋轉不同。換行右移的 RHS 限於類型的範圍，而不是從 LHS 移出的位返回到另一端。
        ///
        /// 所有原始整數類型均實現 [`rotate_right`](Self::rotate_right) 函數，而您可能想要的就是該函數。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // 安全: 通過類型的位大小進行掩蓋可確保我們不會移位
            // 越界
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// 包裝 (modular) 絕對值。計算 `self.abs()`，在類型的邊界處迴繞。
        ///
        /// 可能發生這種換行的唯一情況是，當類型取負的最小值的絕對值時; 這是一個太大的正值，無法在類型中表示。
        /// 在這種情況下，此函數將返回 `MIN` 本身。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// 計算 `self` 的絕對值，而不會引起任何包裹或驚慌。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// 包裝 (modular) 指數。
        /// 計算 `self.pow(exp)`，在類型的邊界處迴繞。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // 由於 exp! =0，最終 exp 必須為 1。
            // 分開處理指數的最後一位，因為在此之後對底數進行平方是不必要的，並且可能導致不必要的溢出。
            //
            //
            acc.wrapping_mul(base)
        }

        /// 計算 `self` + `rhs`
        ///
        /// 返回一個加法元組以及一個布爾值，該布爾值指示是否會發生算術溢出。
        /// 如果將發生溢出，則返回包裝的值。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// 計算 `self`，`rhs`
        ///
        /// 返回一個減法的元組以及一個布爾值，該布爾值指示是否會發生算術溢出。
        /// 如果將發生溢出，則返回包裝的值。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// 計算 `self` 和 `rhs` 的乘法。
        ///
        /// 返回乘法的元組以及一個布爾值，該布爾值指示是否會發生算術溢出。
        /// 如果將發生溢出，則返回包裝的值。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408，正確) ) ;
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` 除以 `rhs` 時計算除數。
        ///
        /// 返回除數的元組以及指示是否將發生算術溢出的布爾值。
        /// 如果將發生溢出，則返回 self。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// 計算歐幾里得除法 `self.div_euclid(rhs)` 的商。
        ///
        /// 返回除數的元組以及指示是否將發生算術溢出的布爾值。
        /// 如果將發生溢出，則返回 `self`。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// `self` 除以 `rhs` 時計算餘數。
        ///
        /// 返回除法運算後的餘數元組和一個布爾值，該布爾值指示是否會發生算術溢出。
        /// 如果將發生溢出，則返回 0。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// 剩餘的歐幾里得數溢出。計算 `self.rem_euclid(rhs)`。
        ///
        /// 返回除法運算後的餘數元組和一個布爾值，該布爾值指示是否會發生算術溢出。
        /// 如果將發生溢出，則返回 0。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0，則此功能將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// 求反，如果等於最小值，則溢出。
        ///
        /// 返回否定形式 self 的元組以及一個布爾值，該布爾值指示是否發生了溢出。
        /// 如果 `self` 是最小值 (例如，對於類型 `i32` 的值，則為 `i32::MIN`)，則將再次返回該最小值，並且將發生溢出時返回 `true`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// 將自身左移 `rhs` 位。
        ///
        /// 返回 self 的移位版本的元組以及一個布爾值，該布爾值指示 shift 值是否大於或等於位數。
        /// 如果移位值太大，則將值屏蔽 (N-1)，其中 N 是位數，然後使用該值執行移位。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10，true) ) ;
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// 將自身右移 `rhs` 位。
        ///
        /// 返回 self 的移位版本的元組以及一個布爾值，該布爾值指示 shift 值是否大於或等於位數。
        /// 如果移位值太大，則將值屏蔽 (N-1)，其中 N 是位數，然後使用該值執行移位。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1，true) ) ;
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// 計算 `self` 的絕對值。
        ///
        /// 返回 self 的絕對版本的元組以及一個布爾值，該布爾值指示是否發生了溢出。
        /// 如果自我是最小值
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// 然後將再次返回最小值，並在發生溢出時返回 true。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// 通過平方運算，將自己提升到 `exp` 的功效。
        ///
        /// 返回一個指數的元組以及一個 bool，指示是否發生了溢出。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13，是) ) ;
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // 臨時空間，用於存儲 overflowing_mul 的結果。
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // 由於 exp! =0，最終 exp 必須為 1。
            // 分開處理指數的最後一位，因為在此之後對底數進行平方是不必要的，並且可能導致不必要的溢出。
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// 通過平方運算，將自己提升到 `exp` 的功效。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // 由於 exp! =0，最終 exp 必須為 1。
            // 分開處理指數的最後一位，因為在此之後對底數進行平方是不必要的，並且可能導致不必要的溢出。
            //
            //
            acc * base
        }

        /// 計算 `self` 的歐幾里得除以 `rhs` 的商。
        ///
        /// 這將計算整數 `n`，例如 `self = n * rhs + self.rem_euclid(rhs)` 和 `0 <= self.rem_euclid(rhs) < rhs`。
        ///
        ///
        /// 換句話說，結果是將 `self / rhs` 舍入為 `n` 的整數 `n`。
        /// 如果為 `self > 0`，則等於朝零取整 (Rust 中的默認值) ; 否則，取整。
        /// 如果為 `self < 0`，則等於朝 +/- 無限取整。
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0 或除法導致溢出，則此函數將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// 令 b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b)，-1) ;//7>= -4*-1 assert_eq!((-a).div_euclid(b)，-2) ;//-7>=4 *-2 assert_eq!((-a).div_euclid(-b)，2) ;//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// 計算 `self (mod rhs)` 的最小非負餘數。
        ///
        /// 就像通過歐幾里得除法算法一樣 - 給定 `r = self.rem_euclid(rhs)`，`self = rhs * self.div_euclid(rhs) + r` 和 `0 <= r < abs(rhs)`。
        ///
        ///
        /// # Panics
        ///
        /// 如果 `rhs` 為 0 或除法導致溢出，則此函數將為 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// 令 b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// 計算 `self` 的絕對值。
        ///
        /// # 溢出行為
        ///
        /// 的絕對值
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// 不能表示為
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// 並嘗試計算它會導致溢出。
        /// 這意味著在這種情況下，處於調試模式的代碼將觸發 panic，並且優化後的代碼將返回
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// 沒有 panic。
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // 請注意，上面的#[inline] 表示減法的溢出語義取決於我們要內聯的 crate。
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// 返回一個表示 `self` 的符號的數字。
        ///
        ///  - `0` 如果數字為零
        ///  - `1` 如果數字為正
        ///  - `-1` 如果數字為負
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// 如果 `self` 為正數，則返回 `true`; 如果數字為零或負數，則返回 `false`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// 如果 `self` 為負，則返回 `true`; 如果數字為零或正，則返回 `false`。
        ///
        ///
        /// # Examples
        ///
        /// 基本用法:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// 以大字節序 (network) 字節順序將這個整數的內存表示形式作為字節數組返回。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// 以 little-endian 字節順序將這個整數的內存表示形式返回為字節數組。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// 以本地字節順序將這個整數的內存表示形式返回為字節數組。
        ///
        /// 由於使用了目標平台的本機字節序，因此，可移植代碼應酌情使用 [`to_be_bytes`] 或 [`to_le_bytes`]。
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     字節，如果 cfg! (target_endian= "big") {
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } 別的 {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // 安全: const 聽起來很合理，因為整數是普通的舊數據類型，因此我們可以始終
        // 將它們轉換為字節數組
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // 安全: 整數是普通的舊數據類型，因此我們可以隨時將它們轉換為
            // 字節數組
            unsafe { mem::transmute(self) }
        }

        /// 以本地字節順序將這個整數的內存表示形式返回為字節數組。
        ///
        ///
        /// [`to_ne_bytes`] 應盡可能優先於此。
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// 讓字節 = num.as_ne_bytes();
        /// assert_eq!(
        ///     字節，如果 cfg! (target_endian= "big") {
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } 別的 {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // 安全: 整數是普通的舊數據類型，因此我們可以隨時將它們轉換為
            // 字節數組
            unsafe { &*(self as *const Self as *const _) }
        }

        /// 從其表示形式以 big endian 的字節數組形式創建一個整數值。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// 使用 std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * 輸入 = 休息;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// 從它的表示形式以 little endian 的字節數組形式創建一個整數值。
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// 使用 std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * 輸入 = 休息;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// 從其內存表示形式創建一個整數值，以本機字節序表示為字節數組。
        ///
        /// 由於使用了目標平台的本機字節序，因此可移植代碼可能希望酌情使用 [`from_be_bytes`] 或 [`from_le_bytes`]。
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } 別的 {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// 使用 std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * 輸入 = 休息;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // 安全: const 聽起來很合理，因為整數是普通的舊數據類型，因此我們可以始終
        // 向他們轉變
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // 安全: 整數是普通的舊數據類型，因此我們可以隨時將其轉換為整數
            unsafe { mem::transmute(bytes) }
        }

        /// 新代碼應優先使用
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// 返回此整數類型可以表示的最小值。
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// 新代碼應優先使用
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// 返回此整數類型可以表示的最大值。
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}