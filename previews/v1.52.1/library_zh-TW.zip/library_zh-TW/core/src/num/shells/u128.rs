//! 128 位無符號整數類型的常量。
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! 新代碼應直接在原始類型上使用關聯的常量。

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }