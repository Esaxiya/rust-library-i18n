//! 64 位無符號整數類型的常量。
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! 新代碼應直接在原始類型上使用關聯的常量。

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }