//! 將浮點值解碼為單獨的部分和錯誤範圍。

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// 解碼後的無符號有限值，例如:
///
/// - 原始值等於 `mant * 2^exp`。
///
/// - 從 `(mant - minus)*2^exp` 到 `(mant + plus)* 2^exp` 的任何數字都將四捨五入為原始值。
/// 僅當 `inclusive` 為 `true` 時，範圍才包括在內。
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// 縮放的尾數。
    pub mant: u64,
    /// 較低的誤差範圍。
    pub minus: u64,
    /// 上限誤差範圍。
    pub plus: u64,
    /// 以 2 為底的共享指數。
    pub exp: i16,
    /// 當錯誤範圍包括在內時為真。
    ///
    /// 在 IEEE 754 中，當原始尾數為偶數時，這是正確的。
    pub inclusive: bool,
}

/// 解碼後的無符號值。
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// 無窮大，正數或負數。
    Infinite,
    /// 零，正數或負數。
    Zero,
    /// 具有進一步解碼字段的有限數字。
    Finite(Decoded),
}

/// 可以被解碼的浮點類型。
pub trait DecodableFloat: RawFloat + Copy {
    /// 最小正歸一化值。
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// 從給定的浮點數返回一個符號 (當為負數時為 true) 和 `FullDecoded` 值。
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // 鄰居: (mant，2，exp) - (mant，exp) - (mant + 2，exp)
            // Float::integer_decode 始終保留指數，因此尾數按次法線縮放。
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // 鄰居: (maxmant，exp，1) - (minnormmant，exp) - (minnormmant + 1，exp)
                // 其中 maxmant=minnormmant * 2，1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // 鄰居: (mant，1，exp) - (mant，exp) - (mant + 1，exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}