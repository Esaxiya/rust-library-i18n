//! Grisu3 算法的 Rust 適應性，在 `使用整數快速而準確地打印浮點數` [^ 1] 中進行了介紹。
//! 它使用大約 1KB 的預先計算表，因此，對於大多數輸入而言，它非常快。
//!
//! [^1]: Florian 洛伊奇。2010。快速打印浮點數並
//!   準確地使用整數。SIGPLAN 不是。45，6 (2010 年 6 月)，233-243。
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// 有關原理，請參見 `format_shortest_opt` 中的註釋。
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i，80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f，e，k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// 給定 `x > 0`，則返回 `(k, 10^k)`，如 `10^k <= x < 10^(k+1)`。
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Grisu 的最短模式實現。
///
/// 否則，它將返回不精確的表示形式時返回 `None`。
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // 我們至少需要三位額外的精度

    // 從具有共享指數的歸一化值開始
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // 找到任何 `cached = 10^minusk` 這樣的 `ALPHA <= minusk + plus.e + 64 <= GAMMA`。
    // 由於 `plus` 已標準化，因此表示 `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // 考慮到我們選擇的 `ALPHA` 和 `GAMMA`，這會將 `plus * cached` 放入 `[4, 2^32)`。
    //
    // 顯然，最大化 `GAMMA - ALPHA` 是可取的，這樣我們就不需要很多 10 的緩存冪，但是有一些注意事項:
    //
    //
    // 1. 我們希望將 `floor(plus * cached)` 保留在 `u32` 之內，因為它需要進行昂貴的劃分。
    //    (這實際上是無法避免的，需要剩餘的部分來進行準確性估算。)
    // 2.
    // `floor(plus * cached)` 的其餘部分反复乘以 10，並且不應溢出。
    //
    // 第一個給出 `64 + GAMMA <= 32`，第二個給出 `10 * 2^-ALPHA <= 2^64`;
    // -60 -32 是具有此約束的最大範圍，V8 也使用它們。
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // 縮放 fps。這給出了 1 ulp 的最大誤差 (由定理 5.1 證明)。
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +- 負的實際範圍
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus` 之上的 `v` 和 `plus` 被 `量化` 為近似值 (誤差 < 1 ulp)。
    // 因為我們不知道誤差是正還是負，所以我們使用兩個等距分佈的近似值，並且最大誤差為 2 ulps。
    //
    // "unsafe region" 是我們最初生成的自由區間。
    // "safe region" 是我們僅接受的保守區間。
    // 我們從不安全區域內的正確 repr 開始，然後嘗試找到也在安全區域內與 `v` 最接近的 repr。
    // 如果不能，我們就放棄。
    //
    let plus1 = plus.f + 1;
    // 令 plus0 = plus.f，1;// 僅用於說明，讓 minus0 = minus.f +1;// 僅用於說明
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // 共享指數

    // 將 `plus1` 分為整數部分和小數部分。
    // 由於精度要求，緩存的功率保證了 `plus < 2^32`，歸一化的 `plus.f` 始終小於 `2^64 - 2^4`，因此保證了集成部件可以裝入 u32。
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // 計算最大的 `10^max_kappa` 不超過 `plus1` (因此 `plus1 < 10^(max_kappa+1)`)。
    // 這是下面的 `kappa` 的上限。
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 定理 6.2: 如果 `k` 是最大整數 st
    // `0 <= y mod 10^k <= y - x`,              那麼 `V = floor(y / 10^k) * 10^k` 在 `[x, y]` 中，並且是該範圍內最短的表示形式之一 (有效位數最少)。
    //
    //
    // 根據定理 6.2，找到 `(minus1, plus1)` 之間的數字長度 `kappa`。
    // 定理 6.2 可以通過要求 `y mod 10^k < y - x` 來排除 `x`。
    // (例如，`x` =32000，`y` =32777; `kappa` =2，因為 `y mod 10 ^ 3=777 <y，x=777`。) 該算法依賴於以後的驗證階段來排除 `y`。
    //
    let delta1 = plus1 - minus1;
    // 令 delta1int= (delta1 >> e) 為 usize;// 僅用於說明
    let delta1frac = delta1 & ((1 << e) - 1);

    // 渲染整體零件，同時檢查每一步的準確性。
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // 尚未渲染的數字
    loop {
        // 我們總是有至少一位要呈現，因為 `plus1 >= 10^kappa` 不變式:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (緊隨其後的是 `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // 將 `remainder` 除以 `10^kappa`。兩者均由 `2^-e` 縮放。
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // == (plus1％10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; 我們找到了正確的 `kappa`。
            let ten_kappa = (ten_kappa as u64) << e; // 將 10 ^ kappa 縮放回共享指數
            return round_and_weed(
                // 安全: 我們在上面初始化了該內存。
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // 繪製所有整數後，請中斷循環。
        // 確切的位數是 `max_kappa + 1` 和 `plus1 < 10^(max_kappa+1)`。
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // 恢復不變式
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // 渲染小數部分，同時檢查每個步驟的準確性。
    // 這次我們依靠重複的乘法，因為除法將失去精度。
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // 下一個數字應該是有效的，因為我們已經在分解不變量之前進行了測試，其中 `m = max_kappa + 1` (整數部分的數字) :
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // 不會溢出 `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // 將 `remainder` 除以 `10^kappa`。
        // 兩者都按 `2^e / 10^kappa` 縮放，因此後者在這裡是隱式的。
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // 隱式除數
            return round_and_weed(
                // 安全: 我們在上面初始化了該內存。
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // 恢復不變式
        kappa -= 1;
        remainder = r;
    }

    // 我們已經生成了 `plus1` 的所有有效數字，但不確定是否是最佳數字。
    // 例如，如果 `minus1` 為 3.14153 ...，而 `plus1` 為 3.14158 ...，則從 3.14154 到 3.14158 有 5 種不同的最短表示形式，但我們只有最大的一種。
    // 我們必須連續減少最後一位並檢查這是否是最佳代表。
    // 最多有 9 個候選人 (..1 到..9)，所以這相當快。("rounding" 階段)
    //
    // 該函數檢查此 "optimal" repr 是否實際上在 ulp 範圍內，並且由於舍入誤差，"second-to-optimal" repr 可能實際上是最佳的。
    // 在這兩種情況下，都將返回 `None`。
    // ("weeding" 階段)
    //
    // 此處的所有參數均按公共 (但隱式) 值 `k` 進行縮放，以便:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (還有 `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (以及先前不變量的 `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 在 1.5 ulps 內對 `v` (實際上是 `plus1 - v`) 產生兩個近似值。
        // 結果表示應為兩者最接近的表示。
        //
        // 這裡使用 `plus1 - v` 是因為針對 `plus1` 進行了計算，以避免使用 overflow/underflow (因此，似乎交換了名稱)。
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v，1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v +1 ulp)

        // 減少最後一位，並停在最接近 `v + 1 ulp` 的位置。
        let mut plus1w = remainder; // plus1w(n) = plus1，w(n)
        {
            let last = buf.last_mut().unwrap();

            // 我們使用的近似數字 `w(n)` 最初等於 `plus1 - plus1 % 10^kappa`。將循環體運行 `n` 次之後， `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // 我們將 `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` 設置為 (因此 `remainder= plus1w(0)`) 以簡化檢查。
            // 請注意，`plus1w(n)` 一直在增加。
            //
            // 我們有三個條件可以終止。它們中的任何一個都將使循環無法繼續進行，但是我們至少知道了一個至少與 `v + 1 ulp` 最接近的有效表示形式。
            // 為了簡便起見，我們將它們表示為 TC1 至 TC3。
            //
            // TC1: `w(n) <= v + 1 ulp`，即這是最接近的代表。
            // 這等效於 `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`。
            // 與 TC2 結合使用 (後者檢查 `w(n+1)` is valid)，這可以防止 `plus1w(n)` 的計算可能出現溢出)。
            //
            // TC2: `w(n+1) < minus1`，即下一個代表肯定不會舍入到 `v`。
            // 這等效於 `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`。
            // 左側可能會溢出，但是我們知道 `threshold > plus1v`，所以如果 TC1 為假，則 `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp`，我們可以安全地測試 `threshold - plus1w(n) < 10^kappa`。
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`，即下一個代表是
            // 距離 `v + 1 ulp` 最近的代表不近。
            // 給定 `z(n) = plus1v_up - plus1w(n)`，則變為 `abs(z(n)) <= abs(z(n+1))`。再次假設 TC1 為假，我們得到 `z(n) > 0`。我們有兩種情況要考慮:
            //
            // - 當 `z(n+1) >= 0`: TC3 變為 `z(n) <= z(n+1)`。
            // 隨著 `plus1w(n)` 的增加，`z(n)` 應該減少，這顯然是錯誤的。
            // - 當 `z(n+1) < 0`:
            //   - TC3a: 前提是 `plus1v_up < plus1w(n) + 10^kappa`。假設 TC2 為假，則為 `threshold >= plus1w(n) + 10^kappa`，因此它不會溢出。
            //   - TC3b: TC3 變為 `z(n) <= -z(n+1)`，即 `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   取反的 TC1 給出 `plus1v_up > plus1w(n)`，因此與 TC3a 結合使用時不會溢出或下溢。
            //
            // 因此，我們應該在 `TC1 || TC2 || (TC3a && TC3b)` 時停止。以下等價於它的逆， `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // 最短的代表不能以 `0` 結尾
                plus1w += ten_kappa;
            }
        }

        // 檢查此表示形式是否也是最接近 `v - 1 ulp` 的表示形式。
        //
        // 這與 `v + 1 ulp` 的終止條件完全相同，所有 `plus1v_up` 都替換為 `plus1v_down`。
        // 溢出分析同樣成立。
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // 現在，我們在 `plus1` 和 `minus1` 之間具有最接近 `v` 的表示形式。
        // 但是，這太寬鬆了，因此我們拒絕 `plus0` 和 `minus0` 之間的任何 `w(n)`，即 `plus1 - plus1w(n) <= minus0` 或 `plus1 - plus1w(n) >= plus0`。
        // 我們利用 `threshold = plus1 - minus1` 和 `plus1 - plus0 = minus0 - minus1 = 2 ulp` 的事實。
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// 具有 Dragon 後備功能的 Grisu 的最短模式實現。
///
/// 在大多數情況下都應使用此方法。
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // 安全: 借閱檢查器不夠智能，無法讓我們使用 `buf`
    // 在第二個 branch 中，因此我們在此處進行生存期的清洗。
    // 但是，只有在 `format_shortest_opt` 返回 `None` 的情況下，我們才重新使用 `buf`，所以可以。
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Grisu 的確切和固定模式實現。
///
/// 否則，它將返回不精確的表示形式時返回 `None`。
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // 我們至少需要三位額外的精度
    assert!(!buf.is_empty());

    // 歸一化和縮放 `v`。
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // 將 `v` 分為整數部分和小數部分。
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // 舊 `v` 和新 `v` (由 `10^-k` 縮放) 的誤差均小於 1 ulp (定理 5.1)。
    // 因為我們不知道誤差是正還是負，所以我們使用兩個等距的近似值，並且最大誤差為 2 ulps (與最短的情況相同)。
    //
    //
    // 目的是找到 `v - 1 ulp` 和 `v + 1 ulp` 共有的精確四捨五入的數字序列，以便我們有最大的信心。
    // 如果無法做到這一點，我們不知道哪一個是 `v` 的正確輸出，因此我們放棄並退回。
    //
    // `err` 在這裡定義為 `1 ulp * 2^e` (與 `vfrac` 中的 ulp 相同)，只要 `v` 得到縮放，我們就會對其進行縮放。
    //
    //
    //
    let mut err = 1;

    // 計算最大的 `10^max_kappa` 不超過 `v` (因此 `v < 10^(max_kappa+1)`)。
    // 這是下面的 `kappa` 的上限。
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 如果使用的是最後一位數字的限制，則需要在實際渲染之前縮短緩衝區，以避免雙舍入。
    //
    // 請注意，在進行舍入操作時，我們必須再次擴大緩衝區!
    let len = if exp <= limit {
        // 糟糕，我們甚至無法產生 *一位* 數字。
        // 例如，當我們有類似 9.5 的值並將其四捨五入時，這是可能的。
        //
        // 原則上，我們可以立即使用空緩衝區調用 `possibly_round`，但是將 `max_ten_kappa << e` 縮放 10 會導致溢出。
        //
        // 因此我們在這裡很草率，錯誤範圍擴大了 10 倍。
        // 這會增加假陰性率，但只會非常非常輕微地提高假陰性率;
        // 僅當尾數大於 60 位時才有意義。
        //
        // 安全: `len=0`，因此初始化此內存的義務微不足道。
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // 渲染不可分割的部分。
    // 該錯誤完全是零星的，因此我們無需在此部分中進行檢查。
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // 尚未渲染的數字
    loop {
        // 我們總是至少有一位數字來表示不變式:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (緊隨其後的是 `remainder = vint % 10^(kappa+1)`)
        //
        //

        // 將 `remainder` 除以 `10^kappa`。兩者均由 `2^-e` 縮放。
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // 緩衝區是否已滿? 用餘數運行舍入通行證。
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // == (v％10 ^ kappa) * 2 ^ e
            // 安全: 我們已經將 `len` 初始化了很多字節。
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // 繪製所有整數後，請中斷循環。
        // 確切的位數是 `max_kappa + 1` 和 `plus1 < 10^(max_kappa+1)`。
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // 恢復不變式
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // 渲染小數部分。
    //
    // 原則上，我們可以繼續到最後一個可用數字並檢查準確性。
    // 不幸的是，我們正在使用有限大小的整數，因此我們需要一些標準來檢測溢出。
    // V8 使用 `remainder > err`，當 `v - 1 ulp` 和 `v` 的前 `i` 有效數字不同時，此錯誤。
    // 但是，這會拒絕太多否則有效的輸入。
    //
    // 由於後面的階段具有正確的溢出檢測功能，因此我們使用更嚴格的標準:
    // 我們繼續直到 `err` 超過 `10^kappa / 2`，以便 `v - 1 ulp` 和 `v + 1 ulp` 之間的範圍肯定包含兩個或多個舍入表示形式。
    //
    // 這與 `possibly_round` 的前兩次比較相同，僅供參考。
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // 不變量，其中 `m = max_kappa + 1` (整數部分的數字) :
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // 不會溢出 `2^e * 10 < 2^64`
        err *= 10; // 不會溢出 `err * 10 < 2^e * 5 < 2^64`

        // 將 `remainder` 除以 `10^kappa`。
        // 兩者都按 `2^e / 10^kappa` 縮放，因此後者在這裡是隱式的。
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // 緩衝區是否已滿? 用餘數運行舍入通行證。
        if i == len {
            // 安全: 我們已經將 `len` 初始化了很多字節。
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // 恢復不變式
        remainder = r;
    }

    // 進一步的計算是沒有用的 (`possibly_round` 肯定會失敗)，所以我們放棄了。
    return None;

    // 我們已經生成了所有要求的 `v` 數字，這些數字也應該與 `v - 1 ulp` 的相應數字相同。
    // 現在，我們檢查 `v - 1 ulp` 和 `v + 1 ulp` 是否共享唯一的表示形式; 這可以與生成的數字相同，也可以與這些數字的四捨五入形式相同。
    //
    // 如果範圍包含相同長度的多個表示形式，則不能確定，應返回 `None`。
    //
    // 此處的所有參數均按公共 (但隱式) 值 `k` 進行縮放，以便:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // 安全: `buf` 的前 `len` 字節必須初始化。
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (供參考，虛線以給定的位數表示可能的表示形式的準確值。)
        //
        //
        // 錯誤太大，以至於 `v - 1 ulp` 和 `v + 1 ulp` 之間至少存在三種可能的表示形式。
        // 我們無法確定哪一個是正確的。
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // 實際上，1/2 ulp 足以引入兩種可能的表示形式。
        // (請記住，對於 `v - 1 ulp` 和 `v + 1 ulp`，我們都需要一個唯一的表示形式。) 這不會溢出，因為從第一次檢查起就是 `ulp < ten_kappa`。
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // 如果 `v + 1 ulp` 更接近四捨五入的表示形式 (已經存在於 `buf` 中)，那麼我們可以安全地返回。
        // 請注意，`v - 1 ulp` 可以小於當前表示形式，但是作為 `1 ulp < 10^kappa / 2`，此條件就足夠了:
        // `v - 1 ulp` 和當前表示之間的距離不能超過 `10^kappa / 2`。
        //
        // 條件等於 `remainder + ulp < 10^kappa / 2`。
        // 由於這很容易溢出，因此請首先檢查 `remainder < 10^kappa / 2`。
        // 我們已經驗證了 `ulp < 10^kappa / 2`，因此只要 `10^kappa` 畢竟沒有溢出，第二次檢查就可以了。
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // 安全: 我們的调用者初始化了該內存。
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <------- 餘數 --- ---> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // 另一方面，如果 `v - 1 ulp` 更接近於四捨五入的表示形式，我們應該四捨五入並返回。
        // 出於同樣的原因，我們不需要檢查 `v + 1 ulp`。
        //
        // 條件等於 `remainder - ulp >= 10^kappa / 2`。
        // 再次，我們首先檢查是否為 `remainder > ulp` (請注意，這不是 `remainder >= ulp`，因為 `10^kappa` 永遠不會為零)。
        //
        // 還請注意 `remainder - ulp <= 10^kappa`，因此第二次檢查不會溢出。
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // 安全: 我們的調用者必須已初始化該內存。
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // 僅在要求我們提供固定精度時才添加一個額外的數字。
                // 我們還需要檢查一下，如果原始緩衝區為空，則只能在 `exp == limit` (edge 情況) 下添加附加數字。
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // 安全: 我們和調用者初始化了該內存。
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // 否則，我們注定要失敗 (即，`v - 1 ulp` 和 `v + 1 ulp` 之間的一些值四捨五入，而其他值則四捨五入) 並放棄。
        //
        None
    }
}

/// 具有 Dragon 後備功能的 Grisu 的精確和固定模式實現。
///
/// 在大多數情況下都應使用此方法。
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // 安全: 借閱檢查器不夠智能，無法讓我們使用 `buf`
    // 在第二個 branch 中，因此我們在此處進行生存期的清洗。
    // 但是，只有在 `format_exact_opt` 返回 `None` 的情況下，我們才重新使用 `buf`，所以可以。
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}