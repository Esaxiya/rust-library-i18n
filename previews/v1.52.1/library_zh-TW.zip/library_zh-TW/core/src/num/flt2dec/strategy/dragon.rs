//! [快速，準確地打印浮點數][^ 1] 圖 3 的幾乎直接 (但略有優化) 的 Rust 轉換。
//!
//!
//! [^1]: Burger, RG and Dybvig，RK1996。打印浮點數
//!   快速準確。SIGPLAN 不是。31，5 (1996 年 5 月)，108-116。

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 為 10 ^ (2 ^ n) 預先計算的 `Digit` 數組
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// 僅在 `x < 16 * scale` 時可用; `scaleN` 應該是 `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Dragon 的最短模式實現。
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // 已知要格式化的數字 `v` 為:
    // - 等於 `mant * 2^exp`;
    // - 原始類型前面帶有 `(mant - 2 *minus)* 2^exp`; 和
    // - 後面是原始類型的 `(mant + 2 *plus)* 2^exp`。
    //
    // 顯然，`minus` 和 `plus` 不能為零。(對於無窮大，我們使用超出範圍的值。) 我們還假定至少生成一個數字，即 `mant` 也不能為零。
    //
    // 這也意味著 `low = (mant - minus)*2^exp` 和 `high = (mant + plus)* 2^exp` 之間的任何數字都將映射到該確切的浮點數，並且在原始尾數為偶數 (即 `!mant_was_odd`) 時也包括邊界。
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` 是 `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // 從滿足 `10^(k_0-1) < high <= 10^(k_0+1)` 的原始輸入中估算 `k_0`。
    // 滿足 `10^(k-1) < high <= 10^k` 的緊定 `k` 稍後計算。
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // 將 `{mant, plus, minus} * 2^exp` 轉換為小數形式，以便:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // 將 `mant` 除以 `10^k`。現在是 `scale / 10 < mant + plus <= scale * 10`。
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (或 `>=`) 時進行修正。
    // 我們實際上並沒有修改 `scale`，因為我們可以跳過初始乘法。
    // 現在 `scale < mant + plus <= scale * 10`，我們準備生成數字。
    //
    // 請注意，當 `scale - plus < mant < scale` 時，`d[0]`*可以* 為零。
    // 在這種情況下，將立即觸發舍入條件 (下面的 `up`)。
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // 相當於將 `scale` 縮放 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // 緩存 `(2, 4, 8) * scale` 用於數字生成。
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // 不變量，其中 `d[0..n-1]` 是到目前為止生成的數字:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (因此 `mant / scale < 10`)，其中 `d[i..j]` 是 `d [i] * 10 ^ (ji) + ... 的簡寫
        // + d [j-1] * 10 + d[j]`。

        // 產生一位數字: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // 這是對修改後的 Dragon 算法的簡化描述。
        // 為了方便起見，省略了許多中間派生和完整性參數。
        //
        // 從修改的不變量開始，因為我們更新了 `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // 假定 `d[0..n-1]` 是 `low` 和 `high` 之間的最短表示形式，即 `d[0..n-1]` 滿足以下兩個條件，但 `d[0..n-2]` 不滿足:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (雙射性: 數字四捨五入為 `v`) ; 和
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (最後一位數字正確)。
        //
        // 第二個條件簡化為 `2 * mant <= scale`。
        // 根據 `mant`，`low` 和 `high` 求解不變量產生第一個條件的簡單版本: `-plus < mant < minus`.
        // 自 `-plus < 0 <= mant` 以來，我們擁有正確的最短表示形式 `mant < minus` 和 `2 * mant <= scale`。
        // (當原始尾數為偶數時，前者變為 `mant <= minus`。)
        //
        // 當第二個不成立時 ('2 * mant> scale')，我們需要增加最後一位。
        // 這足以恢復該條件: 我們已經知道數字生成可以保證 `0 <= v / 10^(k-n) - d[0..n-1] < 1`。
        // 在這種情況下，第一個條件變為 `-plus < mant - scale < minus`。
        // 自從 `mant < scale` 產生以來，我們有了 `scale < mant + plus`。
        // (同樣，當原始尾數為偶數時，它變為 `scale <= mant + plus`。)
        //
        // 簡而言之:
        // - `mant < minus` (或 `<=`) 時，停止並四捨五入 `down` (保持數字不變)。
        // - `scale < mant + plus` (或 `<=`) 時，停止並四捨五入 `up` (增加最後一位)。
        // - 否則繼續生成。
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // 我們具有最短的表示，請繼續進行四捨五入

        // 恢復不變式。
        // 這使得算法總是終止: `minus` 和 `plus` 總是增加，但是 `mant` 被裁剪為 `scale` 模，並且 `scale` 是固定的。
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // 當 i) 僅觸發了舍入條件，或者 ii) 兩個條件都被觸發並且平局打破更傾向於舍入時，發生舍入。
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // 如果四捨五入改變了長度，則指數也應改變。
        // 似乎很難滿足這個條件 (可能是不可能的)，但是我們在這裡只是安全和一致的。
        //
        // 安全: 我們在上面初始化了該內存。
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // 安全: 我們在上面初始化了該內存。
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Dragon 的確切和固定模式實現。
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // 從滿足 `10^(k_0-1) < v <= 10^(k_0+1)` 的原始輸入中估算 `k_0`。
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // 將 `mant` 除以 `10^k`。現在是 `scale / 10 < mant <= scale * 10`。
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` 時的修正，`plus / scale = 10^-buf.len() / 2` 時的修正。
    // 為了保留固定大小的 bignum，我們實際上使用 `mant + floor(plus) >= scale`。
    // 我們實際上並沒有修改 `scale`，因為我們可以跳過初始乘法。
    // 再次使用最短算法，`d[0]` 可以為零，但最終會四捨五入。
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // 相當於將 `scale` 縮放 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // 如果使用的是最後一位數字的限制，則需要在實際渲染之前縮短緩衝區，以避免雙舍入。
    //
    // 請注意，在進行舍入操作時，我們必須再次擴大緩衝區!
    let mut len = if k < limit {
        // 糟糕，我們甚至無法產生 *一位* 數字。
        // 例如，當我們有類似 9.5 的值並將其四捨五入時，這是可能的。
        // 我們返回一個空緩衝區，但以後的向上舍入情況例外，該情況在 `k == limit` 且必須產生一位數字時發生。
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // 緩存 `(2, 4, 8) * scale` 用於數字生成。
        // (這可能很昂貴，因此在緩衝區為空時不要計算它們。)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // 以下數字全為零，我們在這裡停止 *不要* 嘗試進行舍入! 而是填寫剩餘的數字。
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // 安全: 我們在上面初始化了該內存。
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // 如果以下幾位恰好是 5000，則四捨五入，如果我們停在數字的中間，請檢查前一位並嘗試四捨五入為偶數 (即，避免在前一位為偶數時四捨五入)。
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // 安全: `buf[len-1]` 已初始化。
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // 如果四捨五入改變了長度，則指數也應改變。
        // 但是我們被要求提供固定數量的數字，所以請不要更改緩衝區...
        // 安全: 我們在上面初始化了該內存。
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... 除非我們被要求使用固定精度。
            // 我們還需要檢查一下，如果原始緩衝區為空，則只能在 `k == limit` (edge 情況) 下添加附加數字。
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // 安全: 我們在上面初始化了該內存。
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}