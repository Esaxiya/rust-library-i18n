//! 將十進製字符串轉換為 IEEE 754 二進制浮點數。
//!
//! # 問題陳述
//!
//! 我們給了一個十進製字符串，例如 `12.34e56`。
//! 該字符串由整數 (`12`)，小數 (`34`) 和指數 (`56`) 組成。所有部分都是可選的，缺少則解釋為零。
//!
//! 我們尋求最接近十進製字符串確切值的 IEEE 754 浮點數。
//! 眾所周知，許多十進製字符串在基數 2 中都沒有終止表示，因此我們將 0.5 單位最後舍入 (換句話說，盡可能)。
//! 領帶 (精確到兩個連續浮點之間的中間的十進制值) 通過半對偶策略 (也稱為銀行家舍入) 來解決。
//!
//! 不用說，這在實現複雜性和所用的 CPU 週期方面都相當困難。
//!
//! # Implementation
//!
//! 首先，我們忽略跡象。或者更確切地說，我們在轉換過程的開始就將其刪除，然後在結束時將其重新應用。
//! 這在所有 edge 情況下都是正確的，因為 IEEE 浮點數對稱於零左右，取反則僅翻轉第一位。
//!
//! 然後，我們通過調整指數來刪除小數點: 從概念上講，`12.34e56` 變為 `1234e54`，我們用正整數 `f = 1234` 和整數 `e = 54` 對其進行描述。
//! 在解析階段之後，幾乎所有代碼都使用 `(f, e)` 表示形式。
//!
//! 然後，我們嘗試使用機器大小的整數和較小的，固定大小的浮點數 (首先是 `f32`/`f64`，然後是具有 64 位有效數字的類型 `Fp`)，一長串逐漸增加的普通和昂貴的特殊情況。
//!
//! 如果所有這些方法都失敗了，我們會硬著頭皮，求助於一個簡單但非常緩慢的算法，該算法需要完全計算 `f * 10^e`，然後進行迭代搜索以求出最佳近似值。
//!
//! 首先，此模塊及其子級實現以下算法:
//! "How to Read Floating Point Numbers Accurately" 威廉・D。
//! 克林格 (Clinger)，在線可用: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! 此外，本文中使用了許多輔助功能，但 Rust (或至少在內核中) 不可用。
//! 我們的版本由於需要處理上溢和下溢以及處理次正規數的需求而變得更加複雜。
//! Bellerophon 和算法 R 在上溢，子正常和下溢方面存在問題。
//! 在輸入進入關鍵區域之前，我們會保守地切換到算法 M (具有本文第 8 節中描述的修改)。
//!
//! 另一個需要注意的方面是 `RawFloat` trait，幾乎所有函數都通過該參數設置。有人可能認為解析為 `f64` 並將結果轉換為 `f32` 就足夠了。
//! 不幸的是，這不是我們生活的世界，這與使用基數二進位或半數甚至四捨五入法無關。
//!
//! 例如，考慮兩種類型的 `d2` 和 `d4`，它們代表具有兩個十進制數字和四個十進制數字的十進制類型，並以 "0.01499" 作為輸入。讓我們使用上半舍入。
//! 直接轉到兩位小數即為 `0.01`，但是如果首先四捨五入為 `0.0150`，則得到 `0.0150`，然後將其四捨五入為 `0.02`。
//! 相同的原理也適用於其他操作，如果要獲得 0.5 ULP 精度，則需要以全精度進行所有操作，並在末尾精確地舍入一次，方法是一次考慮所有截斷的位。
//!
//! FIXME: 儘管某些代碼重複是必要的，但也許可以對部分代碼進行混洗，以便減少重複的代碼。
//! 算法的大部分不依賴於 float 類型來輸出，或者僅需要訪問一些常量即可作為參數傳遞。
//!
//! # Other
//!
//! 轉換應 *從不* panic。
//! 在代碼中有斷言和顯式的 panics，但是它們絕不應該被觸發，而僅用作內部的健全性檢查。任何 panics 都應視為錯誤。
//!
//! 雖然有單元測試，但是它們在確保正確性方面嚴重不足，它們僅覆蓋了很小一部分可能的錯誤。
//! 更廣泛的測試作為 Python 腳本位於目錄 `src/etc/test-float-parse` 中。
//!
//! 關於整數溢出的說明: 該文件的許多部分都使用十進制指數 `e` 進行算術運算。
//! 首先，我們將小數點移到以下位置: 第一個十進制數字之前，最後一個十進制數字之後，依此類推。如果不小心這樣做可能會溢出。
//! 我們依靠解析子模塊僅分發足夠小的指數，其中 "sufficient" 表示 "such that the exponent +/- the number of decimal digits fits into a 64 bit integer"。
//! 較大的指數被接受，但是我們不對它們進行算術運算，它們立即變成 {positive,negative} {zero,infinity}。
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// 這兩個有自己的測試。
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// 將以 10 為底的字符串轉換為浮點數。
            /// 接受可選的十進制指數。
            ///
            /// 此函數接受諸如以下的字符串
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', 或等效地， '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', 或者，等效地， '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// 前導和尾隨空格表示錯誤。
            ///
            /// # Grammar
            ///
            /// 遵循以下 [EBNF] 語法的所有字符串都將導致返回 [`Ok`]:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # 已知錯誤
            ///
            /// 在某些情況下，應該創建有效浮點數的某些字符串會返回錯誤。
            /// 有關詳細信息，請參見 [issue #31407]。
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src，一個字符串
            ///
            /// # 返回值
            ///
            /// `Err(ParseFloatError)` 如果字符串不代表有效數字。
            /// 否則，為 `Ok(n)`，其中 `n` 是 `src` 表示的浮點數。
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// 解析浮點數時可以返回的錯誤。
///
/// 該錯誤用作 [`f32`] 和 [`f64`] 的 [`FromStr`] 實現的錯誤類型。
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// 將十進製字符串拆分為符號和其餘部分，而無需檢查或驗證其餘部分。
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // 如果字符串無效，則我們永遠不會使用符號，因此我們無需在此處進行驗證。
        _ => (Sign::Positive, s),
    }
}

/// 將十進製字符串轉換為浮點數。
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// 十進製到浮點轉換的主要動力: 統籌所有預處理並確定哪種算法應進行實際轉換。
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift 掉小數點
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 限制為 1280 位，即大約 385 個十進制數字。
    // 如果超過此值，我們將崩潰，因此我們會在距離太近 (在 10 ^ 10 以內) 之前出錯。
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // 現在，指數肯定適合 16 位，整個主要算法都使用該位。
    let e = e as i16;
    // FIXME 這些界限相當保守。
    // 如果對 Bellerophon 的故障模式進行更仔細的分析，則可以在更多情況下使用它以大幅度提高速度。
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// 如所寫，這會導致優化效果不佳 (請參閱 #27130，儘管它引用的是舊版本的代碼)。
// `inline(always)` 是一種解決方法。
// 總體上只有兩個调用站點，並且不會使代碼大小變糟。

/// 即使可能需要去除指數，也應盡可能去除零
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // 修剪這些零不會改變任何內容，但可以啟用快速路徑 (<15 位數字)。
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // 簡化形式為 0.0 ... x 和 x ... 0.0 的數字，並相應地調整指數。
    // 這可能並不總是一個勝利 (可能會將一些數字排除在快速路徑之外)，但會顯著簡化其他部分 (尤其是近似值的大小)。
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// 返回算法 R 和算法 M 在處理給定小數時將計算的最大值的大小 (log10) 的快速臟上限。
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // 由於 trivial_cases() 和解析器為我們篩選出了最極端的輸入，因此我們不必擔心這裡的溢出。
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // 在 e>=0 的情況下，兩種算法都計算大約 `f * 10^e`。
        // 算法 R 對此進行了一些複雜的計算，但是對於上限，我們可以忽略它，因為它還會預先減小分數，因此我們在那裡有很多緩衝區。
        //
        f_len + (e as u64)
    } else {
        // 如果 e <0，則算法 R 做大致相同的事情，但是算法 M 不同:
        // 它試圖找到一個正數 k，以使 `f << k / 10^e` 是有效範圍內的有效數字。
        // 這將導致大約 `2^53 *f* 10^e` <`10^17 *f* 10^e`。
        // 觸發此操作的一個輸入為 0.33 ... 33 (375 x 3)。
        f_len + e.unsigned_abs() + 17
    }
}

/// 無需查看十進制數字即可檢測到明顯的上溢和下溢。
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // 有零，但它們被 simplify() 剝離
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // 這是 ceil(log10(the real value)) 的粗略近似值。
    // 我們在這裡不必擔心溢出，因為輸入長度很小 (至少與 2 ^ 64 相比) 並且解析器已經處理了絕對值大於 10 ^ 18 (仍然短 10 ^ 19 的指數) 2 ^ 64)。
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}