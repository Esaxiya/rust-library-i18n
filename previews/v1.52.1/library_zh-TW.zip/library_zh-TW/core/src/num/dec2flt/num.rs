//! bignum 的實用程序函數不必過多地轉變為方法。

// FIXME 這個模塊的名稱有點不幸，因為其他模塊也導入 `core::num`。

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// 測試是否將所有不重要於 `ones_place` 的位截斷是否引入了小於，等於或大於 0.5 ULP 的相對誤差。
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // 如果所有剩餘位均為零，則為 = 0.5 ULP，否則 > 0.5 如果沒有更多位 (half_bit==0)，則以下內容也將正確返回 Equal。
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// 將僅包含十進制數字的 ASCII 字符串轉換為 `u64`。
///
/// 不檢查溢出或無效字符，因此，如果調用者不小心，結果將是虛假的，並且可能為 panic (儘管不會是 `unsafe`)。
/// 此外，空字符串被視為零。
/// 存在此功能是因為
///
/// 1. 在 `&[u8]` 上使用 `FromStr` 需要 `from_utf8_unchecked`，這很糟糕，並且
/// 2. 將 `integral.parse()` 和 `fractional.parse()` 的結果放在一起比整個功能要復雜得多。
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// 將 ASCII 數字字符串轉換為 bignum。
///
/// 像 `from_str_unchecked` 一樣，此功能依賴於解析器來清除非數字。
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// 將 bignum 解包為 64 位整數。Panics 如果數字太大。
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// 提取一定範圍的位。

/// 索引 0 是最低有效位，範圍照常半開。
/// Panics，如果要求提取超出返回類型的位數。
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}