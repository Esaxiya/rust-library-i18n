//! 正向 IEEE 754 浮點數的擺弄。負數不是，也不需要處理。
//! 普通浮點數的規範表示為 (frac，exp)，因此值是 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>))，其中 N 是位數。
//!
//! 次普通法則略有不同和怪異，但適用相同的原理。
//!
//! 但是，在這裡，我們將它們表示為 (sig，k)，且 f 為正，因此值為 f *
//! 2 <sup>e</sup>。除了使 "hidden bit" 顯式顯示之外，這還通過所謂的尾數轉換來更改指數。
//!
//! 換句話說，通常將浮點數寫為 (1)，但在這裡將它們寫為 (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! 我們將 (1) 稱為 `分數表示`，將 (2) 稱為 `積分錶示`。
//!
//! 該模塊中的許多功能僅處理普通數字。對於非常小的數字和非常大的數字，dec2flt 例程保守地採用通用正確的慢路徑 (算法 M)。
//! 該算法僅需要 next_float()，即可處理次態和零。
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// 一個幫助程序 trait，可以避免基本上複製 `f32` 和 `f64` 的所有轉換代碼。
///
/// 有關為什麼這樣做的必要信息，請參見父模塊的文檔註釋。
///
/// **永遠不要** 為其他類型實現或在 dec2flt 模塊外部使用。
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` 和 `from_bits` 使用的類型。
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// 執行原始轉換為整數。
    fn to_bits(self) -> Self::Bits;

    /// 從整數執行原始轉換。
    fn from_bits(v: Self::Bits) -> Self;

    /// 返回此數字所屬的類別。
    fn classify(self) -> FpCategory;

    /// 以整數形式返回尾數，指數和符號。
    fn integer_decode(self) -> (u64, i16, i8);

    /// 解碼浮點數。
    fn unpack(self) -> Unpacked;

    /// 從可以精確表示的小整數進行轉換。
    /// Panic 如果無法表示整數，則此模塊中的其他代碼確保永不讓這種情況發生。
    fn from_int(x: u64) -> Self;

    /// 從預先計算的表中獲取值 10 <sup>e</sup>。
    /// `e >= CEIL_LOG5_OF_MAX_SIG` 的 Panics。
    fn short_fast_pow10(e: usize) -> Self;

    /// 名字怎麼說。
    /// 硬編碼比雜湊內部函數和希望 LLVM 常量將其折疊起來容易。
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // 輸入的小數位數的保守界限，不會產生溢出或零或
    /// 次正常。可能是最大值的十進制指數，因此得名。
    const MAX_NORMAL_DIGITS: usize;

    /// 當最高有效十進制數字的位數大於該數值時，該數字肯定會四捨五入為無窮大。
    ///
    const INF_CUTOFF: i64;

    /// 當最高有效十進制數字的位數小於該位數時，該數字肯定會四捨五入為零。
    ///
    const ZERO_CUTOFF: i64;

    /// 指數中的位數。
    const EXP_BITS: u8;

    /// 有效位數的位數，*包括* 隱藏位數。
    const SIG_BITS: u8;

    /// 有效位數的位數，*不包括* 隱藏位。
    const EXPLICIT_SIG_BITS: u8;

    /// 小數表示形式中的最大合法指數。
    const MAX_EXP: i16;

    /// 分數表示形式中的最小合法指數，不包括次正規數。
    const MIN_EXP: i16;

    /// `MAX_EXP` 用於積分錶示，即應用了移位。
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` 編碼 (即具有偏移偏置)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` 用於積分錶示，即應用了移位。
    const MIN_EXP_INT: i16;

    /// 整數表示形式中的最大歸一化有效位數。
    const MAX_SIG: u64;

    /// 整數表示形式中的最小歸一化有效位數。
    const MIN_SIG: u64;
}

// 通常是 #34344 的解決方法。
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// 以整數形式返回尾數，指數和符號。
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // 指數偏差 + 尾數偏移
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe 不確定 `as` 是否在所有平台上都能正確取整。
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// 以整數形式返回尾數，指數和符號。
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // 指數偏差 + 尾數偏移
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe 不確定 `as` 是否在所有平台上都能正確取整。
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// 將 `Fp` 轉換為最接近的機器浮點類型。
/// 不處理不正常的結果。
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 是 64 位，因此 xe 的尾數偏移為 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 將 64 位有效位數四捨五入為 T::SIG_BITS 位。
/// 不處理指數溢出。
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // 調整尾數偏移
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// `RawFloat::unpack()` 的倒數，用於歸一化數。
/// Panics (如果有效位數或指數對於標準化數字無效)。
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // 刪除隱藏的位
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // 調整指數以實現指數偏差和尾數偏移
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 在 0 ("+") 處保留符號位，我們的數字均為正
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// 構造一個次正規的。允許尾數為 0 並構造零。
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // 編碼指數為 0，符號位為 0，因此我們只需要重新解釋這些位即可。
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// 大約有 Fp 的 bignum。在 0.5 ULP 中四捨五入至半數。
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // 我們將索引 `start` 之前的所有位都切除，也就是說，我們實際上右移了 `start`，因此這也是我們需要的指數。
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // 根據截斷的位舍入 (half-to-even)。
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// 查找嚴格小於參數的最大浮點數。
/// 不處理次正規量，零或指數下溢。
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// 找到嚴格大於參數的最小浮點數。
// 此操作飽和，即 next_float(inf) ==inf。
// 與該模塊中的大多數代碼不同，此函數確實處理零，次正規數和無窮大。
// 但是，像這裡的所有其他代碼一樣，它不處理 NaN 和負數。
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // 這似乎太好了，難以置信，但它確實有效。
        // 0.0 被編碼為全零字。次規範為 0x000m ... m，其中 m 為尾數。
        // 特別是，最小的次正規值為 0x0 ... 01，最大的為 0x000F ... F。
        // 最小的標準數是 0x0010 ... 0，因此此特殊情況也適用。
        // 如果增量使尾數溢出，則進位將根據需要遞增指數，並且尾數位變為零。
        // 由於隱藏的位約定，這正是我們想要的!
        // 最後，f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY。
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}