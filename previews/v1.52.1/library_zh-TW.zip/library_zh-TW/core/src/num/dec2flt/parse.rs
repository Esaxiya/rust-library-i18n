//! 驗證並分解以下形式的十進製字符串:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! 換句話說，是標準的浮點語法，但有兩個例外: 無符號，並且不對 "inf" 和 "NaN" 進行任何處理。這些由驅動程序功能 (super::dec2flt) 處理。
//!
//! 儘管識別有效輸入相對容易，但該模塊還必須拒絕無數無效變量，從不拒絕 panic，並執行其他模塊不依賴於 panic 的大量檢查 (或溢出)。
//!
//! 更糟的是，所有這些都在輸入上一次完成。
//! 因此，修改任何內容時都要小心，並仔細檢查其他模塊。
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// 十進製字符串的有趣部分。
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// 十進制指數，保證少於 18 個十進制數字。
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// 檢查輸入字符串是否為有效的浮點數，如果是，則在其中找到整數部分，小數部分和指數。
/// 不處理標誌。
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' 之前沒有數字
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // 在該點之前或之後，我們至少需要一位數字。
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // 小數部分後的尾隨垃圾
            }
        }
        _ => Invalid, // 第一個數字字符串後的結尾垃圾
    }
}

/// 分割十進制數字，直到第一個非數字字符。
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// 指數提取和錯誤檢查。
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // 指數後的尾隨垃圾
    }
    if number.is_empty() {
        return Invalid; // 空指數
    }
    // 在這一點上，我們當然有一個有效的數字字符串。放入 `i64` 可能太長了，但如果太大，則輸入肯定為零或無窮大。
    // 由於十進制數字中的每個零僅將指數調整 +/-1，因此在 exp=10 ^ 18 時，輸入必須為 17 exabyte (!) 零，才能幾乎接近於有限值。
    //
    // 這不是我們需要迎合的用例。
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}