//! 本文中的各種算法。

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp 中的有效位數
const P: u32 = 64;

// 我們僅存儲 *all* 指數的最佳近似值，因此可以省略變量 "h" 和相關條件。
// 這將性能換成幾千字節的空間。

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// 在大多數體系結構中，浮點運算具有顯式的位大小，因此，計算精度取決於每個運算。
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// 在 x86 上，如果 SSE/SSE2 擴展不可用，則將 x87 FPU 用於浮動操作。
// x87 FPU 默認情況下以 80 位精度運行，這意味著運算將舍入到 80 位，從而在最終將值表示為時將發生雙舍入
//
// 32/64 位浮點值。為了克服這個問題，可以設置 FPU 控製字，以便以所需的精度執行計算。
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// 一種用於保留 FPU 控製字的原始值的結構，以便在刪除該結構時可以將其恢復。
    ///
    ///
    /// x87 FPU 是一個 16 位寄存器，其字段如下:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// IA-32 體系結構軟件開發人員手冊 (第 1 卷) 中提供了所有字段的文檔。
    ///
    /// 與以下代碼相關的唯一字段是 PC，Precision Control。
    /// 該字段確定 FPU 執行的操作的精度。
    /// 可以設置為:
    ///  - 0b00，單精度，即 32 位
    ///  - 0b10，雙精度，即 64 位
    ///  - 0b11，雙精度擴展精度，即 80 位 (默認狀態) 0b01 值是保留的，不應使用。
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // 安全: `fldcw` 指令已通過審核，可以正常工作。
        // 任何 `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: 我們正在使用 ATT 語法來支持 LLVM 8 和 LLVM 9。
                options(att_syntax, nostack),
            )
        }
    }

    /// 將 FPU 的 precision 字段設置為 `T` 並返回 `FPUControlWord`。
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // 計算適用於 `T` 的 Precision Control 字段的值。
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 位
            8 => 0x0200, // 64 位
            _ => 0x0300, // 默認為 80 位
        };

        // 獲得控製字的原始值，以便在以後刪除 `FPUControlWord` 結構時將其還原。安全性: `fnstcw` 指令已通過審核，可以與任何 `u16` 一起正常使用
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: 我們正在使用 ATT 語法來支持 LLVM 8 和 LLVM 9。
                options(att_syntax, nostack),
            )
        }

        // 將控製字設置為所需的精度。
        // 這可以通過掩蓋舊的精度 (位 8 和 9，0x300) 並將其替換為上面計算的精度標誌來實現。
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Bellerophon 使用機器大小的整數和浮點數的快速路徑。
///
/// 它被提取到一個單獨的函數中，以便可以在構造 bignum 之前嘗試使用它。
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) 〜15.95。
    // 我們將精確值與末尾的 MAX_SIG 進行比較，這只是一個快速，廉價的拒絕方法 (並且使其餘代碼免於擔心下溢的麻煩)。
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // 快速路徑至關重要地取決於將算術四捨五入到正確的位數，而無需任何中間舍入。
    // 在 x86 (不帶 SSE 或 SSE2) 上，這需要更改 x87 FPU 堆棧的精度，以便直接將其舍入為 64/32 位。
    // `set_precision` 功能負責在需要通過更改全局狀態 (例如 x87 FPU 的控製字) 進行設置的體系結構上設置精度。
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // e <0 的情況不能折疊到另一個 branch 中。
    // 負冪會導致二進制中重複的小數部分四捨五入，這會在最終結果中引起實際的 (有時是相當大的! ) 錯誤。
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// 算法 Bellerophon 是通過非平凡數值分析證明的平凡代碼。
///
/// 它將 `f` 四捨五入為有效位數為 64 位的浮點數，並將其乘以 `10^e` 的最佳近似值 (以相同的浮點格式)。通常這足以獲得正確的結果。
/// 但是，當結果接近兩個相鄰 (ordinary) 浮點數之間的一半時，乘以兩個近似值會產生復合舍入誤差，這意味著結果可能會偏離幾位。
/// 發生這種情況時，迭代算法 R 會解決問題。
///
/// 通過本文中的數值分析，可以使手工波浪 "close to halfway" 變得精確。
/// 用克林格的話來說:
///
/// > 以最低有效位為單位表示的斜率是錯誤的包含範圍
/// > 在對 f * 10 ^ e 進行近似的浮點計算過程中累積。(斜率是
/// > 不是真正誤差的界限，而是將近似值 z 與
/// > 使用 p 個有效位數的最佳近似值。)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) 的情況在 fast_path() 中
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // 舍入到 n 位時，斜率是否足夠大以產生影響?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// 一種改進 `f * 10^e` 浮點近似的迭代算法。
///
/// 每次迭代都會在最後一個位置獲得一個單位，如果 `z0` 稍微偏離，則收斂當然會花費非常長的時間。
/// 幸運的是，當用作 Bellerophon 的後備時，起始近似值最多可以有一個 ULP。
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // 找到正整數 `x`，`y`，使 `x / y` 恰好是 `(f *10^e) / (m* 2^k)`。
        // 這不僅避免了處理 `e` 和 `k` 的符號，而且還消除了 `10^e` 和 `2^k` 的兩個共同之處，以使數字更小。
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // 這樣做有點尷尬，因為我們的 bignum 不支持負數，因此我們使用絕對值 + 符號信息。
        // 與 m_digits 的乘法不會溢出。
        // 如果 `x` 或 `y` 足夠大，我們需要擔心溢出，那麼它們也足夠大，以至於 `make_ratio` 將分數減少了 2 ^ 64 或更多。
        //
        //
        let (d2, d_negative) = if x >= y {
            // 不再需要 x，保存 clone()。
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // 仍然需要 y，進行複制。
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// 給定 `x = f` 和 `y = m`，其中 `f` 照常表示輸入的十進制數字，`m` 是浮點近似值的有效數字，請使比率 `x / y` 等於 `(f *10^e) / (m* 2^k)`，可能會減少兩者的冪。
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e，y=m* 2 ^ k，不同之處在於我們將分數減小了 2 的冪。
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k)，y=m 這不會溢出，因為它需要正 `e` 和負 `k`，這僅在值非常接近 1 時才會發生，這意味著 `e` 和 `k` 將相對較小。
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f，y=m *10^abs(e)* 2 ^ k 這也不會溢出，請參見上文。
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k)，y=m* 10^abs(e)，再次減小了兩個的冪。
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// 從概念上講，算法 M 是將小數轉換為浮點數的最簡單方法。
///
/// 我們形成一個等於 `f * 10^e` 的比率，然後將其乘以 2，直到給出有效的有效浮點數為止。
/// 二進制指數 `k` 是分子或分母乘以 2 的次數，即 `f *10^e` 始終等於 `(u / v)* 2^k`。
/// 當我們發現有效位數時，我們只需要檢查除法的其餘部分就可以進行舍入，這將在下面的輔助函數中完成。
///
///
/// 即使使用 `quick_start()` 中描述的優化方法，該算法也非常慢。
/// 但是，它是最適合於上溢，下溢和次正規結果的算法。
/// 當 Bellerophon 和 Algorithm R 不堪重負時，此實現將接手。
/// 檢測下溢和上溢很容易: 該比率仍然不是有效範圍，但已達到 minimum/maximum 指數。
/// 在溢出的情況下，我們只是返回無窮大。
///
/// 處理下溢和次常態異常比較棘手。
/// 一個大問題是，如果使用最小指數，則該比率可能仍然太大而無法實現。
/// 有關詳細信息，請參見 underflow()。
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME 可能的優化: 泛化 big_to_fp，以便我們可以在這裡執行 fp_to_float(big_to_fp(u)) 的等效功能，而無需進行雙取整。
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // 我們必須在最小指數處停止，如果我們等到 `k < T::MIN_EXP_INT`，那麼我們將相差 2 倍。
            // 不幸的是，這意味著我們必須對具有最小指數的正態數進行特殊處理。
            // FIXME 找到了一個更優雅的公式，但是運行 `tiny-pow10` 測試以確保它實際上是正確的!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// 通過檢查位長跳過大多數算法 M 迭代。
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // 位長是以 2 為底的對數的估計值，並且 log(u / v) = log(u)，log(v)。
    // 估計最多偏移 1，但始終被低估，因此 log(u) 和 log(v) 上的錯誤具有相同的符號並被抵消 (如果兩者都很大)。
    // 因此，log(u / v) 的錯誤最多也為 1。
    // 目標比率是 u/v 在有效範圍內的比率。因此，我們的終止條件是 log2(u / v) 為有效位，plus/minus 為 1。
    // FIXME 查看第二位可以改善估計並避免更多劃分。
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // 下溢或低於正常水平。留給主要功能。
            break;
        }
        if *k == T::MAX_EXP_INT {
            // 溢出。留給主要功能。
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // 比率不是最小指數的有效範圍，因此我們需要捨入多餘的位並相應地調整指數。
    // 現在，實際價值如下所示:
    //
    //        l
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q 截斷 (由 rem 代表)
    //
    // 因此，當舍入位為! = 0.5 ULP 時，它們將自行決定舍入。
    // 當它們相等且餘數不為零時，該值仍需要四捨五入。
    // 只有當四捨五入的位是 1/2 且其餘部分為零時，我們才有一半到偶數的情況。
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// 普通的取整到偶數，由於必須除以除法的餘數而取整。
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}