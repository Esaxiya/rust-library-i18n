//! 轉換為整數類型的錯誤類型。

use crate::convert::Infallible;
use crate::fmt;

/// 當檢查的整數類型轉換失敗時，返回錯誤類型。
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // 匹配而不是強制，以確保當 `Infallible` 成為 `!` 的別名時，上述 `From<Infallible> for TryFromIntError` 這樣的代碼將繼續起作用。
        //
        //
        match never {}
    }
}

/// 解析整數時可以返回的錯誤。
///
/// 此錯誤用作原始整數類型 (例如 [`i8::from_str_radix`]) 上 `from_str_radix()` 函數的錯誤類型。
///
/// # 潛在原因
///
/// 除其他原因外，例如，當從標準輸入中獲取 `ParseIntError` 時，可能會由於字符串中的前導或尾隨空格而拋出 `ParseIntError`。
///
/// 使用 [`str::trim()`] 方法可確保在解析之前不留空格。
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// 枚舉存儲各種類型的錯誤，這些錯誤可能導致解析整數失敗。
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// 解析的值是空的。
    ///
    /// 除其他原因外，在解析空字符串時將構造此變體。
    Empty,
    /// 在其上下文中包含無效數字。
    ///
    /// 除其他原因外，當解析包含非 ASCII 字符的字符串時，將構造此變體。
    ///
    /// 當 `+` 或 `-` 單獨放置或放置在數字中間時，也將構造此變體。
    ///
    ///
    InvalidDigit,
    /// 整數太大，無法存儲為目標整數類型。
    PosOverflow,
    /// 整數太小，無法存儲為目標整數類型。
    NegOverflow,
    /// 價值為零
    ///
    /// 當解析字符串的值為零時，將發出此變體，這對於非零類型是非法的。
    ///
    Zero,
}

impl ParseIntError {
    /// 輸出解析整數失敗的詳細原因。
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}