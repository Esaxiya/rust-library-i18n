//! Panic 對 libcore 的支持
//!
//! 核心庫無法定義恐慌，但可以 *聲明* 恐慌。
//! 這意味著可以將 panic 允許使用 libcore 內部的函數，但是要使上游 crate 有用，必須定義恐慌以供 libcore 使用。
//! 當前的恐慌界面是:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! 此定義允許對任何常規消息進行恐慌，但不允許 `Box<Any>` 值失敗。
//! (`PanicInfo` 僅包含一個 `&(dyn Any + Send)`，我們在其中將其填充為 `PanicInfo: : internal_constructor` 中的虛擬值。) 其原因是不允許 libcore 進行分配。
//!
//!
//! 該模塊還包含其他一些緊急功能，但這只是編譯器必需的 lang 項。所有 panics 都通過此功能進行了合併。
//! 實際符號通過 `#[panic_handler]` 屬性聲明。
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// 不使用格式時，libcore 的 `panic!` 宏的基礎實現。
#[cold]
// 從不內聯，除非 panic_immediate_abort 盡可能避免調用站點上的代碼膨脹
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // 溢出和其他 `Assert` MIR 終結器時 panic 的代碼生成所需的
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // 使用 Arguments::new_v1 代替 format_args! (`{}`，expr) 可能會減少大小開銷。
    // format_args! 宏使用 str 的 Display trait 編寫 expr，該調用調用 Formatter::pad，該 Formatter::pad 必須容納字符串截斷和填充 (即使此處未使用)。
    //
    // 使用 Arguments::new_v1 可使編譯器從輸出二進製文件中省略 Formatter::pad，從而節省多達幾千字節的空間。
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // 常量評估的 panics 所需
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOO array/slice 訪問上 panic 的代碼生成所需的
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// 使用格式化時，libcore 的 `panic!` 宏的基礎實現。
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // 注意此功能永遠不會越過 FFI 邊界; 這是 Rust 到 Rust 的調用，已解析為 `#[panic_handler]` 函數。
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // 安全: `panic_impl` 是在安全的 Rust 代碼中定義的，因此可以安全調用。
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` 和 `assert_ne!` 宏的內部功能
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}