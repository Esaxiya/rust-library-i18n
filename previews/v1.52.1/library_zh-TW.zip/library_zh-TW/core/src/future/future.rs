#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future 表示異步計算。
///
/// future 是一個可能尚未完成計算的值。
/// 這種 "asynchronous value" 使得線程在等待值變為可用時可以繼續執行有用的工作。
///
///
/// # `poll` 方法
///
/// future 的核心方法 `poll` 嘗試 * 將 future 解析為最終值。
/// 如果值未準備好，則此方法不會阻塞。
/// 取而代之的是，如果有可能通過再次輪詢來取得進一步的進展，則計劃將當前任務喚醒。
/// 傳遞給 `poll` 方法的 `context` 可以提供 [`Waker`]，它是喚醒當前任務的句柄。
///
/// 當使用 future 時，通常不會直接調用 `poll`，而是 `.await` 該值。
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// 完成時產生的價值類型。
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// 嘗試將 future 解析為最終值，如果該值尚不可用，請註冊當前任務以進行喚醒。
    ///
    /// # 返回值
    ///
    /// 該函數返回:
    ///
    /// - [`Poll::Pending`] 如果 future 還沒有準備好
    /// - [`Poll::Ready(val)`] 如果成功完成，則返回 future 的結果 `val`。
    ///
    /// future 完成後，客戶端不應再次對其進行 `poll`。
    ///
    /// 當 future 尚未準備好時，`poll` 返回 `Poll::Pending` 並存儲從當前 [`Context`] 複製的 [`Waker`] 的副本。
    /// future 可以取得進展後，將喚醒該 [`Waker`]。
    /// 例如，等待套接字變得可讀的 future 將在 [`Waker`] 上調用 `.clone()` 並將其存儲。
    /// 當信號到達其他地方指示套接字可讀時，將調用 [`Waker::wake`]，並且喚醒套接字 future 的任務。
    /// 一旦任務被喚醒，它應該嘗試再次 `poll` future，這可能會或可能不會產生最終值。
    ///
    /// 請注意，在多次調用 `poll` 時，只有將 [`Context`] 中傳遞給最近調用的 [`Waker`] 安排為可以喚醒。
    ///
    /// # 運行時特徵
    ///
    /// Futures 單獨是 `惰性`; 必須對它們進行 `主動` 輪詢以取得進展，這意味著每次喚醒當前任務時，它都應主動重新輪詢，以等待仍然感興趣的 futures。
    ///
    /// `poll` 函數不會在緊密循環中重複調用 - 而是僅在 future 指示已準備好進行調用時 (通過調用 `wake()`)) 才應調用它。
    /// 如果您熟悉 Unix 上的 `poll(2)` 或 `select(2)` 系統調用，則值得注意的是 futures 通常 *不會* 遭受與 "all wakeups must poll all events" 相同的問題。他們更像 `epoll(4)`。
    ///
    /// `poll` 的實現應努力迅速返回，並且不應阻塞。快速返回可防止不必要地阻塞線程或事件循環。
    /// 如果提前得知對 `poll` 的調用可能需要一段時間才能結束，則應將工作分流到線程池 (或類似的線程) 中，以確保 `poll` 可以快速返回。
    ///
    /// # Panics
    ///
    /// future 完成 (從 `poll` 返回 `Ready`) 後，再次調用其 `poll` 方法可能會 panic 永久阻塞或引起其他類型的問題。`Future` trait 對此類調用的效果沒有任何要求。
    /// 但是，由於未將 `poll` 方法標記為 `unsafe`，因此適用 Rust 的通常規則: 調用絕對不能導致未定義的行為 (內存損壞，`unsafe` 函數的錯誤使用等)，無論 future 的狀態如何。
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}