#![stable(feature = "futures_api", since = "1.36.0")]

//! 異步值。

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// 之所以需要這種類型，是因為:
///
/// a) 生成器無法實現 `for<'a, 'b> Generator<&'a mut Context<'b>>`，因此我們需要傳遞原始指針 (請參閱 <https://github.com/rust-lang/rust/issues/68923>)。
///
/// b) 原始指針和 `NonNull` 都不是 `Send` 或 `Sync`，因此也將使每個 future non-Send/Sync 也是如此，我們不希望這樣。
///
/// 它還簡化了 `.await` 的 HIR 降低。
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// 將生成器包裝在 future 中。
///
/// 此函數在下面返回 `GenFuture`，但將其隱藏在 `impl Trait` 中以提供更好的錯誤消息 (`impl Future` 而不是 `GenFuture<[closure.....]>`)。
///
// 這是 `const`，以避免在我們從 `const async fn` 恢復後出現額外的錯誤
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // 我們依靠這樣的事實，即 async/await futures 是不動的，以便在基礎生成器中創建自引用借用。
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // 安全: 安全，因為我們是 !Unpin + !Drop，這只是現場投影。
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // 恢復生成器，將 `&mut Context` 轉換為 `NonNull` 原始指針。
            // 降低 `.await` 會將其安全地投射回 `&mut Context`。
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // 安全: 調用者必須保證 `cx.0` 是有效的指針
    // 滿足了可變參考的所有要求。
    unsafe { &mut *cx.0.as_ptr().cast() }
}