#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` 允許任務執行器的實現者創建 [`Waker`]，該 [`Waker`] 提供自定義的喚醒行為。
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// 它由一個數據指針和一個自定義 `RawWaker` 行為的 [virtual function pointer table (vtable)][vtable] 組成。
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// 數據指針，可用於根據執行程序的要求存儲任意數據。
    /// 這可能是例如
    /// 指向與任務關聯的 `Arc` 的類型擦除的指針。
    /// 該字段的值作為第一個參數傳遞給 vtable 一部分的所有函數。
    ///
    data: *const (),
    /// 虛擬函數指針表，可自定義此喚醒程序的行為。
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// 根據提供的 `data` 指針和 `vtable` 創建新的 `RawWaker`。
    ///
    /// `data` 指針可用於存儲執行程序所需的任意數據。這可能是例如
    /// 指向與任務關聯的 `Arc` 的類型擦除的指針。
    /// 該指針的值將作為第一個參數傳遞給 `vtable` 一部分的所有函數。
    ///
    /// `vtable` 自定義從 `RawWaker` 創建的 `Waker` 的行為。
    /// 對於 `Waker` 上的每個操作，將調用基礎 `RawWaker` 的 `vtable` 中的關聯功能。
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// 虛擬函數指針表 (vtable)，用於指定 [`RawWaker`] 的行為。
///
/// 傳遞給 vtable 內部所有函數的指針是來自封閉的 [`RawWaker`] 對象的 `data` 指針。
///
/// 僅應在 [`RawWaker`] 實現內部從正確構造的 [`RawWaker`] 對象的 `data` 指針上調用此結構內部的函數。
/// 使用任何其他 `data` 指針調用其中一個包含的函數將導致未定義的行為。
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// 克隆 [`RawWaker`] 時，例如克隆存儲 [`RawWaker`] 的 [`Waker`] 時，將調用此函數。
    ///
    /// 此功能的實現必須保留 [`RawWaker`] 和關聯任務的此附加實例所需的所有資源。
    /// 在生成的 [`RawWaker`] 上調用 `wake` 應該會喚醒原 [`RawWaker`] 會喚醒的相同任務。
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// 在 [`Waker`] 上調用 `wake` 時將調用此函數。
    /// 它必須喚醒與此 [`RawWaker`] 相關的任務。
    ///
    /// 此功能的實現必須確保釋放與該 [`RawWaker`] 實例和關聯任務相關聯的所有資源。
    ///
    ///
    wake: unsafe fn(*const ()),

    /// 在 [`Waker`] 上調用 `wake_by_ref` 時將調用此函數。
    /// 它必須喚醒與此 [`RawWaker`] 相關的任務。
    ///
    /// 此功能類似於 `wake`，但一定不能使用提供的數據指針。
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// 刪除 [`RawWaker`] 時將調用此函數。
    ///
    /// 此功能的實現必須確保釋放與該 [`RawWaker`] 實例和關聯任務相關聯的所有資源。
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// 從提供的 `clone`，`wake`，`wake_by_ref` 和 `drop` 函數創建新的 `RawWakerVTable`。
    ///
    /// # `clone`
    ///
    /// 克隆 [`RawWaker`] 時，例如克隆存儲 [`RawWaker`] 的 [`Waker`] 時，將調用此函數。
    ///
    /// 此功能的實現必須保留 [`RawWaker`] 和關聯任務的此附加實例所需的所有資源。
    /// 在生成的 [`RawWaker`] 上調用 `wake` 應該會喚醒原 [`RawWaker`] 會喚醒的相同任務。
    ///
    /// # `wake`
    ///
    /// 在 [`Waker`] 上調用 `wake` 時將調用此函數。
    /// 它必須喚醒與此 [`RawWaker`] 相關的任務。
    ///
    /// 此功能的實現必須確保釋放與該 [`RawWaker`] 實例和關聯任務相關聯的所有資源。
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// 在 [`Waker`] 上調用 `wake_by_ref` 時將調用此函數。
    /// 它必須喚醒與此 [`RawWaker`] 相關的任務。
    ///
    /// 此功能類似於 `wake`，但一定不能使用提供的數據指針。
    ///
    /// # `drop`
    ///
    /// 刪除 [`RawWaker`] 時將調用此函數。
    ///
    /// 此功能的實現必須確保釋放與該 [`RawWaker`] 實例和關聯任務相關聯的所有資源。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// 異步任務的 `Context`。
///
/// 當前，`Context` 僅用於提供對可用於喚醒當前任務的 `&Waker` 的訪問。
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // 通過強制生命週期不變來確保我們 future 抵禦方差變化 (參數位置生命週期是互斥的，而返回位置生命週期是協變的)。
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// 從 `&Waker` 創建一個新的 `Context`。
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// 返回對當前任務的 `Waker` 的引用。
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` 是通過通知執行程序可以運行來喚醒任務的句柄。
///
/// 該句柄封裝了 [`RawWaker`] 實例，該實例定義了特定於執行者的喚醒行為。
///
///
/// 實現 [`Clone`]，[`Send`] 和 [`Sync`]。
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// 喚醒與此 `Waker` 相關的任務。
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // 實際的喚醒調用是通過虛擬函數調用委託給執行者定義的實現的。
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // 請勿致電 `drop`-`wake` 將消耗喚醒器。
        crate::mem::forget(self);

        // 安全: 這是安全的，因為 `Waker::from_raw` 是唯一的方法
        // 初始化 `wake` 和 `data`，要求用戶確認已遵守 `RawWaker` 的合同。
        //
        unsafe { (wake)(data) };
    }

    /// 喚醒與此 `Waker` 相關的任務，而不消耗 `Waker`。
    ///
    /// 這與 `wake` 相似，但是在擁有 `Waker` 的情況下效率可能稍低。
    /// 此方法應該比調用 `waker.clone().wake()` 更可取。
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // 實際的喚醒調用是通過虛擬函數調用委託給執行者定義的實現的。
        //

        // 安全性: 請參閱 `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// 如果此 `Waker` 和另一個 `Waker` 喚醒了同一任務，則返回 `true`。
    ///
    /// 該函數盡力而為，即使 Waker 喚醒了相同的任務，它也可能返回 false。
    /// 但是，如果此函數返回 `true`，則可以確保 `Waker` 喚醒相同的任務。
    ///
    /// 此功能主要用於優化目的。
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// 從 [`RawWaker`] 創建一個新的 `Waker`。
    ///
    /// 如果未遵守 [RawWaker`] 和 [`RawWakerVTable`] 文檔中定義的合同，則返回的 `Waker` 的行為是不確定的。
    ///
    /// 因此，此方法是不安全的。
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // 安全: 這是安全的，因為 `Waker::from_raw` 是唯一的方法
            // 初始化 `clone` 和 `data`，要求用戶確認已遵守 [`RawWaker`] 的合同。
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // 安全: 這是安全的，因為 `Waker::from_raw` 是唯一的方法
        // 初始化 `drop` 和 `data`，要求用戶確認已遵守 `RawWaker` 的合同。
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}