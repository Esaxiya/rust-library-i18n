//! 為數組定義 `IntoIter` 擁有的迭代器。

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// 一個按值的 [array] 迭代器。
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// 這是我們要遍歷的數組。
    ///
    /// 索引為 `i` 的元素 (尚未生成 `alive.start <= i < alive.end`) 是有效的數組條目。
    /// 索引為 `i < alive.start` 或 `i >= alive.end` 的元素已經產生，不能再訪問了! 那些死元素甚至可能處於完全未初始化的狀態!
    ///
    ///
    /// 因此，不變式為:
    /// - `data[alive]` 還活著 (即包含有效元素)
    /// - `data[..alive.start]` 和 `data[alive.end..]` 已死 (即，元素已被讀取，不能再觸摸! )
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` 中尚未產生的元素。
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// 在給定的 `array` 上創建一個新的迭代器。
    ///
    /// *注意*: [`IntoIterator` is implemented for arrays][array-into-iter] 之後，future 中可能不贊成使用此方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` 的類型在這裡是 `i32`，而不是 `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // 安全: 這裡的轉換實際上是安全的。`MaybeUninit` 的文檔
        // promise:
        //
        // > `MaybeUninit<T>` 保證具有相同的尺寸和對齊方式
        // > 作為 `T`。
        //
        // 該文檔甚至顯示了從 `MaybeUninit<T>` 數組到 `T` 數組的轉換。
        //
        //
        // 這樣，該初始化就滿足了不變性。

        // FIXME(LukasKalbertodt): 一旦與 const 泛型一起使用，就可以在這裡實際使用 `mem::transmute`:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // 在此之前，我們可以使用 `mem::transmute_copy` 創建不同類型的按位副本，然後忘記 `array` 以便不刪除它。
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// 返回尚未產生的所有元素的不可變切片。
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // 安全: 我們知道 `alive` 中的所有元素都已正確初始化。
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// 返回尚未產生的所有元素的可變切片。
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // 安全: 我們知道 `alive` 中的所有元素都已正確初始化。
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // 從前面獲取下一個索引。
        //
        // `alive.start` 增加 1 將保持 `alive` 的不變性。
        // 但是，由於此更改，在短時間內，活動區域不再是 `data[alive]`，而是 `data[idx..alive.end]`。
        //
        self.alive.next().map(|idx| {
            // 從數組中讀取元素。
            // 安全: `idx` 是前一個 "alive" 區域的索引
            // 大批。讀取該元素意味著現在 `data[idx]` 被視為已失效 (即不要觸摸)。
            // 由於 `idx` 是活動區域的開始，因此活動區域現在又是 `data[alive]`，恢復了所有不變量。
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // 從背面獲取下一個索引。
        //
        // `alive.end` 減 1 保持 `alive` 不變。
        // 但是，由於此更改，在短時間內，活動區域不再是 `data[alive]`，而是 `data[alive.start..=idx]`。
        //
        self.alive.next_back().map(|idx| {
            // 從數組中讀取元素。
            // 安全: `idx` 是前一個 "alive" 區域的索引
            // 大批。讀取該元素意味著現在 `data[idx]` 被視為已失效 (即不要觸摸)。
            // 由於 `idx` 是活動區域的結尾，因此活動區域現在又是 `data[alive]`，還原了所有不變量。
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // 安全: 這很安全: `as_mut_slice` 完全返回子切片
        // 尚未移出但仍要刪除的元素。
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // 永遠不會因 alive.start <= 不變而下溢
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// 迭代器確實報告了正確的長度。
// "alive" 元素的數量 (仍將產生) 是 `alive` 範圍的長度。
// 在 `next` 或 `next_back` 中，此範圍的長度減小。
// 在這些方法中，它總是減 1，但前提是要返回 `Some(_)`。
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // 注意，我們實際上並不需要完全匹配相同的有效範圍，因此無論 `self` 在哪裡，我們都可以克隆到偏移量 0 中。
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // 克隆所有活動元素。
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // 將克隆寫入新陣列，然後更新其有效範圍。
            // 如果克隆 panics，我們將正確刪除前面的項目。
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // 只打印尚未屈服的元素: 我們無法再訪問屈服的元素。
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}