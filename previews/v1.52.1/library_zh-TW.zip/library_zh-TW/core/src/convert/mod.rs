//! Traits 用於類型之間的轉換。
//!
//! 此模塊中的 traits 提供了一種從一種類型轉換為另一種類型的方法。
//! 每個 trait 都有不同的用途:
//!
//! - 實現 [`AsRef`] trait 以實現廉價的引用到引用的轉換
//! - 實現 [`AsMut`] trait 進行廉價的可變突變
//! - 實現 [`From`] trait 以進行值到值的轉換
//! - 實現 [`Into`] trait，以便將值轉換為當前 crate 之外的類型
//! - [`TryFrom`] 和 [`TryInto`] traits 的行為類似於 [`From`] 和 [`Into`]，但應在轉換失敗時實現。
//!
//! 該模塊中的 traits 通常用作通用函數的 trait bounds，從而支持多種類型的參數。有關示例，請參見每個 trait 的文檔。
//!
//! 作為庫作者，您應該總是更喜歡實現 [`From<T>`][`From`] 或 [`TryFrom<T>`][`TryFrom`]，而不是 [`Into<U>`][`Into`] 或 [`TryInto<U>`][`TryInto`]，因為 [`From`] 和 [`TryFrom`] 提供了更大的靈活性，並免費提供了等效的 [`Into`] 或 [`TryInto`] 實現，這要歸功於標準庫中的全面實現。
//! 當針對 Rust 1.41 之前的版本時，當轉換為當前 crate 之外的類型時，可能有必要直接實現 [`Into`] 或 [`TryInto`]。
//!
//! # 通用實現
//!
//! - [`AsRef`] 如果內部類型是引用，則 [`AsMut`] 自動取消引用
//! - T 的 [`From`]`<U>表示 [`Into`]`</u><T><U>為 U`</u>
//! - T 的 [`TryFrom`]`<U>表示 [`TryInto`]`</u><T><U>為 U`</u>
//! - [`From`] 和 [`Into`] 是自反的，這意味著所有類型都可以 `into` 自己和 `from` 自己
//!
//! 有關用法示例，請參見每個 trait。
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// 身份功能。
///
/// 關於此功能，有兩點需要注意:
///
/// - 它並不總是等同於 `|x| x` 之類的閉包，因為閉包可能會將 `x` 強制轉換為其他類型。
///
/// - 它將傳遞給功能的輸入 `x` 移動。
///
/// 雖然有一個只返回輸入的函數似乎很奇怪，但還是有一些有趣的用途。
///
///
/// # Examples
///
/// 使用 `identity` 在其他有趣的功能序列中什麼也不做:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // 讓我們假設添加一個是一個有趣的函數。
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// 在條件中將 `identity` 用作 "do nothing" 基本案例:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // 做更多有趣的事情...
///
/// let _results = do_stuff(42);
/// ```
///
/// 使用 `identity` 保留 `Option<T>` 迭代器的 `Some` 變體:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// 用於執行廉價的參考到參考的轉換。
///
/// trait 類似於 [`AsMut`]，用於在可變引用之間進行轉換。
/// 如果需要進行昂貴的轉換，最好用 `&T` 類型實現 [`From`] 或編寫一個自定義函數。
///
/// `AsRef` 具有與 [`Borrow`] 相同的簽名，但是 [`Borrow`] 在幾個方面有所不同:
///
/// - 與 `AsRef` 不同，[`Borrow`] 對任何 `T` 都有一個毯子暗示，可以用來接受引用或值。
/// - [`Borrow`] 還要求借入價值的 [`Hash`]，[`Eq`] 和 [`Ord`] 等於擁有價值的 [`Hash`]，[`Eq`] 和 [`Ord`]。
/// 因此，如果只想藉用結構的單個字段，則可以實現 `AsRef`，而不能實現 [`Borrow`]。
///
/// **Note: trait 一定不能失敗 **。如果轉換失敗，請使用專用方法返回 [`Option<T>`] 或 [`Result<T, E>`]。
///
/// # 通用實現
///
/// - `AsRef` 如果內部類型是引用或可變引用 (例如: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// 通過使用 trait bounds，我們可以接受不同類型的參數，只要它們可以轉換為指定的 `T` 類型即可。
///
/// 例如: 通過創建一個採用 `AsRef<str>` 的泛型函數，我們表示我們希望接受所有可以轉換為 [`&str`] 的引用作為參數。
/// 由於 [`String`] 和 [`&str`] 都實現了 `AsRef<str>`，因此我們可以接受兩者作為輸入參數。
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// 執行轉換。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// 用於執行廉價的可變到可變引用轉換。
///
/// trait 與 [`AsRef`] 相似，但用於在可變引用之間進行轉換。
/// 如果需要進行昂貴的轉換，最好用 `&mut T` 類型實現 [`From`] 或編寫一個自定義函數。
///
/// **Note: trait 一定不能失敗 **。如果轉換失敗，請使用專用方法返回 [`Option<T>`] 或 [`Result<T, E>`]。
///
/// # 通用實現
///
/// - `AsMut` 如果內部類型是可變引用，則自動取消引用 (例如: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// 使用 `AsMut` 作為泛型函數的 trait bound，我們可以接受所有可以轉換為 `&mut T` 類型的可變引用。
/// 因為 [`Box<T>`] 實現了 `AsMut<T>`，所以我們可以編寫一個函數 `add_one`，該函數接受所有可以轉換為 `&mut u64` 的參數。
/// 因為 [`Box<T>`] 實現 `AsMut<T>`，所以 `add_one` 也接受 `&mut Box<u64>` 類型的參數:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// 執行轉換。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// 消耗輸入值的值到值轉換。與 [`From`] 相反。
///
/// 應該避免實施 [`Into`]，而改為實施 [`From`]。
/// 由於標準庫中的全面實現，因此 [`From`] 的自動實現為 [`Into`] 的實現提供了一個實現。
///
/// 在通用函數上指定 trait bounds 時，最好使用 [`Into`]，而不是 [`From`]，以確保也可以使用僅實現 [`Into`] 的類型。
///
/// **Note: trait 一定不能失敗 **。如果轉換失敗，請使用 [`TryInto`]。
///
/// # 通用實現
///
/// - [`來自`]`<T> 因為 U` 表示 `Into<U> for T`
/// - [`Into`] 是自反的，這意味著 `Into<T> for T` 已實現
///
/// # 在舊版本的 Rust 中實現 [`Into`] 轉換為外部類型
///
/// 在 Rust 1.41 之前，如果目標類型不屬於當前 crate，則無法直接實現 [`From`]。
/// 例如，使用以下代碼:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// 由於 Rust 的孤立規則過去要嚴格一些，因此無法在較舊的語言版本中進行編譯。
/// 要繞過它，您可以直接實現 [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// 重要的是要了解 [`Into`] 不提供 [`From`] 實現 (就像 [`From`] 與 [`Into`] 一樣)。
/// 因此，您應該始終嘗試實現 [`From`]，如果無法實現 [`From`]，則應退回到 [`Into`]。
///
/// # Examples
///
/// [`String`] 實現 [Into`]`<`[`Vec`]`<`[`u8`]`>>`:
///
/// 為了表示我們希望泛型函數採用所有可以轉換為指定類型 `T` 的參數，我們可以使用 [Into`] 的 trait bound<T>`。
///
/// 例如: 函數 `is_hello` 接受所有可以轉換為 [`Vec`]`<`[`u8`] >> 的參數。
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// 執行轉換。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// 用於在消耗輸入值的同時進行值到值的轉換。它是 [`Into`] 的倒數。
///
/// 與標準 [`Into`] 相比，人們應該總是更喜歡實施 `From`，因為由於標準庫中的全面實現，實現 `From` 會自動為 [`Into`] 提供一個 [`Into`] 的實現。
///
///
/// 僅當針對 Rust 1.41 之前的版本並將其轉換為當前 crate 以外的類型時，才實現 [`Into`]。
/// `From` 由於 Rust 的孤立規則，無法在較早版本中進行這些類型的轉換。
/// 有關更多詳細信息，請參見 [`Into`]。
///
/// 在通用函數上指定 trait bounds 時，最好使用 [`Into`]。
/// 這樣，直接實現 [`Into`] 的類型也可以用作參數。
///
/// `From` 在執行錯誤處理時也非常有用。當構造一個可能失敗的函數時，返回類型通常為 `Result<T, E>` 形式。
/// `From` trait 通過允許函數返回封裝了多種錯誤類型的單個錯誤類型，簡化了錯誤處理。有關更多詳細信息，請參見 "Examples" 部分和 [the book][book]。
///
/// **Note: trait 一定不能失敗 **。如果轉換失敗，請使用 [`TryFrom`]。
///
/// # 通用實現
///
/// - `From<T> for U` 意味著 [`Into`]`<U>用於 T`</u>
/// - `From` 是自反的，這意味著 `From<T> for T` 已實現
///
/// # Examples
///
/// [`String`] 實現 `From<&str>`:
///
/// 從 `&str` 到字符串的顯式轉換如下:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// 在執行錯誤處理時，通常對於您自己的錯誤類型實現 `From` 很有用。
/// 通過將基礎錯誤類型轉換為封裝了基礎錯誤類型的我們自己的自定義錯誤類型，我們可以返回單個錯誤類型，而不會丟失有關基礎原因的信息。
/// '?' 運算符通過調用 `Into<CliError>::into` 自動將基礎錯誤類型轉換為我們的自定義錯誤類型，該 `Into<CliError>::into` 是在實現 `From` 時自動提供的。
/// 然後，編譯器會推斷應使用 `Into` 的哪種實現。
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// 執行轉換。
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// 嘗試使用 `self` 進行轉換，這可能會或可能不會很昂貴。
///
/// 庫作者通常不應該直接實現此 trait，而應該更喜歡實現 [`TryFrom`] trait，該功能提供了更大的靈活性並免費提供了等效的 `TryInto` 實現，這要歸功於標準庫中的一攬子實現。
/// 有關此的更多信息，請參見 [`Into`] 的文檔。
///
/// # 實施 `TryInto`
///
/// 這與實現 [`Into`] 受到相同的限制和推理，有關詳細信息，請參見此處。
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// 發生轉換錯誤時返回的類型。
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// 執行轉換。
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// 簡單安全的類型轉換在某些情況下可能會以受控方式失敗。它是 [`TryInto`] 的倒數。
///
/// 當您執行的類型轉換可能會成功完成但可能還需要特殊處理時，這很有用。
/// 例如，無法使用 [`From`] trait 將 [`i64`] 轉換為 [`i32`]，因為 [`i64`] 可能包含 [`i32`] 無法表示的值，因此轉換將丟失數據。
///
/// 這可以通過將 [`i64`] 截斷為 [`i32`] (本質上給 [`i64`] 的值取 [`i32::MAX`] 模) 或通過簡單地返回 [`i32::MAX`] 或其他方法來處理。
/// [`From`] trait 用於完美的轉換，因此 `TryFrom` trait 會通知程序員類型轉換何時會變差，並讓他們決定如何處理它。
///
/// # 通用實現
///
/// - `TryFrom<T> for U` 意味著 [`TryInto`]`<U>用於 T`</u>
/// - [`try_from`] 是自反的，這意味著 `TryFrom<T> for T` 已實現且不會失敗 - 用於在 `T` 類型的值上調用 `T::try_from()` 的關聯 `Error` 類型為 [`Infallible`]。
/// 當 [`!`] 類型穩定後，[`Infallible`] 和 [`!`] 將等效。
///
/// `TryFrom<T>` 可以實現如下:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// 如前所述，[`i32`] 實現了 TryTry <`[`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // 默默地截斷 `big_number`，事實之後需要檢測並處理該截斷。
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // 由於 `big_number` 太大而無法容納在 `i32` 中，因此返回錯誤。
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // 返回 `Ok(3)`。
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// 發生轉換錯誤時返回的類型。
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// 執行轉換。
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// 通用 IMPLS
////////////////////////////////////////////////////////////////////////////////

// 隨著提起＆
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// 越過 &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): 用以下更通用的替換替換＆/＆mut 的上述 impls:
// // 越過 Deref
// 展示 <D: ?Sized + Deref<Target: AsRef<U>>，U: ? Sized> <U>D 的 AsRef {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut 抬起 &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): 用以下更通用的替代替換 &mut 的上述隱含內容:
// // AsMut 越過 DerefMut
// 展示 <D: ?Sized + Deref<Target: AsMut<U>>，U: ? Sized> <U>D 的 AsMut {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// 從暗示到
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// 從 (因此進入) 是反身的
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **穩定性注意事項:** 該暗示尚不存在，但我們 "reserving space" 會將其添加到 future 中。
/// 有關詳細信息，請參見 [rust-lang/rust#64715][#64715]。
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): 而是進行有原則的修復。
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom 表示 TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// 可靠的轉換在語義上等同於錯誤類型沒有錯誤的可靠的轉換。
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// 混凝土 IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// 無錯誤錯誤類型
////////////////////////////////////////////////////////////////////////////////

/// 永遠不會發生的錯誤的錯誤類型。
///
/// 由於此枚舉沒有變體，因此這種類型的值永遠不會實際存在。
/// 這對於使用 [`Result`] 並參數化錯誤類型的通用 API 很有用，以指示結果始終為 [`Ok`]。
///
/// 例如，對於存在反向 [`Into`] 實現的所有類型，[`TryFrom`] trait (返回 [`Result`] 的轉換) 都具有通用實現。
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future 兼容性
///
/// 該枚舉與 [the `!`“never”type][never] 具有相同的作用，在此版本的 Rust 中不穩定。
/// 當 `!` 穩定後，我們計劃使 `Infallible` 成為它的類型別名:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …並最終棄用 `Infallible`。
///
/// 但是，在一種情況下，可以在將 `!` 穩定為完整類型之前使用 `!` 語法: 在函數的返回類型位置。
/// 具體來說，可以實現兩種不同的函數指針類型:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` 為枚舉時，此代碼有效。
/// 但是，當 `Infallible` 成為 never type 的別名時，兩個 `impl` 將開始重疊，因此將被語言的 trait 一致性規則所禁止。
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}