//! 該模塊實現了 `Any` trait，它可以通過運行時反射來動態鍵入任何 `'static` 類型。
//!
//! `Any` 本身可以用來獲取 `TypeId`，並用作 trait 對象時具有更多功能。
//! 作為 `&dyn Any` (借用的 trait 對象)，它具有 `is` 和 `downcast_ref` 方法，以測試所包含的值是否為給定類型，並獲取對該類型的內部值的引用。
//! 作為 `&mut dyn Any`，還有 `downcast_mut` 方法，用於獲取對內部值的可變引用。
//! `Box<dyn Any>` 添加了 `downcast` 方法，該方法嘗試轉換為 `Box<T>`。
//! 有關完整的詳細信息，請參見 [`Box`] 文檔。
//!
//! 請注意，`&dyn Any` 僅限於測試值是否為指定的具體類型，而不能用於測試某個類型是否實現 trait。
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # 智能指針和 `dyn Any`
//!
//! 將 `Any` 用作 trait 對象時 (尤其是對於 `Box<dyn Any>` 或 `Arc<dyn Any>` 之類的類型) 要記住的一個行為是，僅對值調用 `.type_id()` 會生成 *容器* 的 `TypeId`，而不是基礎 trait 對象。
//!
//! 可以通過將智能指針轉換為 `&dyn Any` 來避免，這將返回對象的 `TypeId`。
//! 例如:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // 您更可能希望這樣做:
//! let actual_id = (&*boxed).type_id();
//! // ... 比這個:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! 考慮一下我們要註銷傳遞給函數的值的情況。
//! 我們知道我們正在實現的值實現了 Debug，但是我們不知道它的具體類型。我們要對某些類型進行特殊處理: 在這種情況下，應先打印 String 值的長度，然後再打印它們的值。
//! 我們在編譯時不知道我們值的具體類型，因此我們需要使用運行時反射。
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // 用於實現 Debug 的任何類型的 Logger 函數。
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // 嘗試將我們的值轉換為 `String`。
//!     // 如果成功，我們要輸出 String 的長度及其值。
//!     // 如果不是，那是另一種類型: 只需將其打印出來而沒有裝飾。
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // 此功能要先註銷其參數，然後再使用它。
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... 做一些其他的工作
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// 任何 trait
///////////////////////////////////////////////////////////////////////////////

/// trait 來模擬動態類型。
///
/// 大多數類型實現 `Any`。但是，任何包含非 `靜態` 引用的類型都不會。
/// 有關更多詳細信息，請參見 [module-level documentation][mod]。
///
/// [mod]: crate::any
// 儘管我們依靠不安全代碼 (例如 `downcast`) 中唯一的 impl 的 `type_id` 函數的細節來實現，但 trait 並不是不安全的。通常，這將是一個問題，但是由於 `Any` 的唯一含義是全面實現，因此沒有其他代碼可以實現 `Any`。
//
// 我們可以合理地使此 trait 不安全 - 因為我們控制所有實現，因此不會造成破壞 - 但我們選擇不這樣做，因為這既不是必需的，而且可能使用戶混淆不安全的 traits 和不安全的方法 (即，`type_id` 仍然可以安全調用，但我們可能希望在文檔中進行說明。
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// 獲取 `self` 的 `TypeId`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// 任何 trait 對象的擴展方法。
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// 確保可以打印出例如連接螺紋的結果，並因此可以與 `unwrap` 一起使用。
// 如果調度與向上轉換一起使用，則最終可能不再需要。
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// 如果裝箱的類型與 `T` 相同，則返回 `true`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // 獲取實例化此函數的類型的 `TypeId`。
        let t = TypeId::of::<T>();

        // 在 trait 對象 (`self`) 中獲取該類型的 `TypeId`。
        let concrete = self.type_id();

        // 比較兩個 `TypeId` 的相等性。
        t == concrete
    }

    /// 如果是 `T`，則返回對裝箱值的一些引用; 如果不是，則返回 `None`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // 安全: 只需檢查我們是否指向正確的類型，我們就可以依靠
            // 檢查內存安全性，因為我們對所有類型都實現了 Any; 沒有其他跡象可能會存在，因為它們會與我們的跡象發生衝突。
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// 如果是 `T`，則返回對裝箱值的一些可變引用; 如果不是，則返回 `None`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // 安全: 只需檢查我們是否指向正確的類型，我們就可以依靠
            // 檢查內存安全性，因為我們對所有類型都實現了 Any; 沒有其他跡象可能會存在，因為它們會與我們的跡象發生衝突。
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// 轉發到在 `Any` 類型上定義的方法。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// 轉發到在 `Any` 類型上定義的方法。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// 轉發到在 `Any` 類型上定義的方法。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// 轉發到在 `Any` 類型上定義的方法。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// 轉發到在 `Any` 類型上定義的方法。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// 轉發到在 `Any` 類型上定義的方法。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID 及其方法
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` 代表類型的全局唯一標識符。
///
/// 每個 `TypeId` 是一個不透明的對象，它不允許檢查內部內容，但可以進行基本操作，例如克隆，比較，打印和顯示。
///
///
/// `TypeId` 當前僅適用於歸因於 `'static` 的類型，但是可以在 future 中消除此限制。
///
/// 雖然 `TypeId` 實現 `Hash`，`PartialOrd` 和 `Ord`，但值得注意的是，在 Rust 版本之間，哈希值和順序將有所不同。
/// 當心在代碼中依賴它們!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// 返回已實例化此泛型函數的類型的 `TypeId`。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// 以字符串切片的形式返回類型的名稱。
///
/// # Note
///
/// 這旨在用於診斷。
/// 除了作為盡力而為的類型描述之外，未指定返回的字符串的確切內容和格式。
/// 例如，在 `type_name::<Option<String>>()` 可能返回的字符串中，有 `"Option<String>"` 和 `"std::option::Option<std::string::String>"`。
///
///
/// 返回的字符串不得視為一種類型的唯一標識符，因為多種類型可能會映射到同一類型名稱。
/// 同樣，不能保證類型的所有部分都將出現在返回的字符串中: 例如，當前不包含生存期說明符。
/// 此外，輸出可能會在編譯器的版本之間改變。
///
/// 當前的實現使用與編譯器診斷和 debuginfo 相同的基礎結構，但這不能保證。
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// 以字符串切片形式返回指向的值的類型的名稱。
/// 這與 `type_name::<T>()` 相同，但是可以在不容易獲得變量類型的地方使用。
///
/// # Note
///
/// 這旨在用於診斷。除了作為該類型的盡力描述之外，未指定字符串的確切內容和格式。
/// 例如，`type_name_of_val::<Option<String>>(None)` 可以返回 `"Option<String>"` 或 `"std::option::Option<std::string::String>"`，但不能返回 `"foobar"`。
///
/// 此外，輸出可能會在編譯器的版本之間改變。
///
/// 此函數不能解析 trait 對象，這意味著 `type_name_of_val(&7u32 as &dyn Debug)` 可以返回 `"dyn Debug"`，但不能返回 `"u32"`。
///
/// 類型名稱不應視為類型的唯一標識符;
/// 多個類型可以共享相同的類型名稱。
///
/// 當前的實現使用與編譯器診斷和 debuginfo 相同的基礎結構，但這不能保證。
///
/// # Examples
///
/// 打印默認的整數和浮點類型。
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}