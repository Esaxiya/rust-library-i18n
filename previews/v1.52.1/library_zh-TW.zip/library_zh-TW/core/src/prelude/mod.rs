//! libcore prelude
//!
//! 該模塊適用於 libcore 的用戶，這些用戶也未鏈接到 libstd。
//! 當以與標準庫的 prelude 相同的方式使用 `#![no_std]` 時，默認情況下將導入此模塊。
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 核心 prelude 的 2015 版本。
///
/// 有關更多信息，請參見 [module-level documentation](self)。
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 核心 prelude 的 2018 版本。
///
/// 有關更多信息，請參見 [module-level documentation](self)。
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 核心 prelude 的 2021 版本。
///
/// 有關更多信息，請參見 [module-level documentation](self)。
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: 添加更多東西。
}